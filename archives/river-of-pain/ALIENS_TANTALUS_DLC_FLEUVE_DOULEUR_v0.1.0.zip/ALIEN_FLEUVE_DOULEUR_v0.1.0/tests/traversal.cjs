'use strict';
const fs=require('node:fs'),path=require('node:path');
const ROOT=path.join(__dirname,'..'),D=require('../src/river-of-pain/data.js'),C=require('../src/river-of-pain/core.js');
// The pilot only uses movement, interactions and equipment. No teleport, task completion or invulnerability API.
function runCampaign(mode='hybrid',difficulty='story'){
 const sim=new C.Simulation(C.createState(difficulty,mode)),trace=[],timing={ticks:0,inputs:0};let previous='';
 const step=(input={},n=1)=>{for(let i=0;i<n;i++){sim.update(.05,input);sim.drain();timing.ticks++;if(sim.s.status==='dead')throw Error('Mort pendant '+sim.chapter.title+' / '+sim.objective?.id+' @ '+sim.s.room);}};
 function aid(){const p=sim.s.player;if(p.hp<75&&p.medkits)sim.heal();if(p.ammo===0&&p.reserve)sim.reload();const enemies=sim.ensureRoom().enemies.filter(e=>e.hp>0&&C.dist(e,p)<370);if(enemies.length&&p.flares&&!sim.ensureRoom().flares.some(f=>C.dist(f,p)<400))sim.flare();}
 function walk(target){target={x:target.x,z:mode==='classic'?.7:target.z};let stalled=0,prev=Infinity;
  for(let tick=0;tick<3500;tick++){
   aid();let distance=C.dist(sim.s.player,target);if(distance<12)return;
   if(sim.s.status!=='playing')return;
   let wp=C.localPath(sim.room,sim.s.player,target,mode)[0]||target;
   const p=sim.s.player,dx=wp.x-p.x,dz=(wp.z-p.z)*600,l=Math.hypot(dx,dz)||1;
   const enemy=sim.ensureRoom().enemies.find(e=>e.hp>0&&Math.abs(e.z-p.z)<.09&&(e.x-p.x)*p.facing>0&&Math.abs(e.x-p.x)<470);
   step({x:dx/l,z:dz/l,fire:!!enemy,sprint:!sim.s.escort&&p.stamina>12,crouch:sim.character.child&&distance<260});
   if(Math.abs(prev-distance)<.1)stalled++;else stalled=0;prev=distance;
   if(stalled>120)throw Error('Coincé dans '+sim.s.room+' vers '+JSON.stringify(target)+' / pos '+JSON.stringify(p));
  }throw Error('Délai de marche '+sim.s.room+' '+JSON.stringify(target));
 }
 function useTarget(target,type){walk(target);const before={room:sim.s.room,obj:sim.s.objective,escort:!!sim.s.escort};for(let i=0;i<160;i++){aid();if(sim.s.room!==before.room||sim.s.objective!==before.obj||!!sim.s.escort!==before.escort||sim.s.status!=='playing')return;if(!sim.s.work){sim.interact();sim.drain();}step({},1);}
  throw Error('Interaction sans effet '+type+' '+target.id+' candidates '+sim.candidates().map(x=>x.label));
 }
 for(let safety=0;safety<800;safety++){
  if(sim.s.status==='complete')break;
  if(sim.s.status==='chapterDone'){trace.push({chapter:sim.s.chapter+1,title:sim.chapter.title,time:Math.round(sim.s.elapsed),health:sim.s.player.hp,shots:sim.s.stats.shots,escorts:sim.s.stats.escorts});sim.nextChapter();sim.drain();continue;}
  const key=sim.s.chapter+':'+sim.s.objective+':'+sim.s.room+':'+!!sim.s.escort;
  if(previous===key)throw Error('Boucle sans progression '+key);previous=key;
  const objective=sim.objective,targetRoom=sim.s.escort?.goal||objective.room;
  if(sim.s.room!==targetRoom){const route=C.route(sim.s.room,targetRoom,sim.s.character,sim.s.flags);if(route.length<2)throw Error('Route absente '+key+' '+targetRoom);const portal=sim.room.portals.find(p=>p.to===route[1]);useTarget(portal,'passage');}
  else if(sim.s.escort){for(let i=0;i<300&&sim.s.escort;i++){aid();step({},1);}if(sim.s.escort)throw Error('Escorte bloquée à destination');}
  else {const object=sim.room.objects.find(o=>o.id===objective.id);useTarget(object,'objectif');}
 }
 if(sim.s.status!=='complete')throw Error('Campagne inachevée : '+sim.s.status);
 trace.push({chapter:16,title:sim.chapter.title,time:Math.round(sim.s.elapsed),health:sim.s.player.hp});
 return {mode,difficulty,passed:true,status:sim.s.status,chapters:trace,stats:sim.s.stats,visited:sim.s.visited.length,elapsedSeconds:sim.s.elapsed,...timing,method:'Sim.update movement + interact + equipment; no teleport/completeTask call/health mutation',state:sim.s};
}
if(require.main===module){const results=[];for(const difficulty of ['story','standard','nightmare'])for(const mode of ['hybrid','classic']){try{const r=runCampaign(mode,difficulty);console.log(mode,difficulty,'PASS',r.elapsedSeconds,r.stats);const {state,...report}=r;results.push(report);}catch(e){console.error(mode,'FAIL',e.stack);results.push({mode,passed:false,error:e.message});}}
 fs.writeFileSync(path.join(ROOT,'docs','TRAVERSAL_RESULTS.json'),JSON.stringify(results,null,2));if(results.some(x=>!x.passed))process.exitCode=1;}
module.exports={runCampaign};
