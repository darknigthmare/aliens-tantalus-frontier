import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,rm,access,symlink} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {install} from '../tools/install.mjs';
const root=await mkdtemp(join(tmpdir(),'rop-installer-')),results=[];
const HTML='<!doctype html><html><body><nav id="title-menu"></nav><section data-panel="archives"></section><script type="module" src="/src/app.js"></script></body></html>';
const oldPackage=JSON.stringify({name:'aliens-tantalus-frontier',version:'86.0.0'});
async function test(name,fn){try{await fn();results.push({name,passed:true});}catch(e){results.push({name,passed:false,error:e.message});console.error('FAIL',name,e.message);}}
async function fixture(name){const p=join(root,name);await mkdir(join(p,'src'),{recursive:true});await writeFile(join(p,'index.html'),HTML);await writeFile(join(p,'package.json'),oldPackage);await writeFile(join(p,'src','content.js'),'export const sentinel = "CATALOGUE_INCHANGE";');return p;}
try{
 const p=await fixture('regular');
 await test('Installation additive sur fixture des ancrages observés',async()=>{const r=await install(p);assert.equal(r.action,'installed');const h=await readFile(join(p,'index.html'),'utf8');assert.ok(h.includes('/src/river-of-pain/launcher.js'));assert.equal(await readFile(join(p,'package.json'),'utf8'),oldPackage);assert.equal(await readFile(join(p,'src','content.js'),'utf8'),'export const sentinel = "CATALOGUE_INCHANGE";');});
 await test('Deuxième exécution sans doublon',async()=>{assert.equal((await install(p)).action,'already-installed');assert.equal((await readFile(join(p,'index.html'),'utf8')).match(/src="\/src\/river-of-pain\/launcher.js"/g).length,1);});
 await test('Retrait restauré octet pour octet',async()=>{assert.equal((await install(p,{remove:true})).action,'removed');assert.equal(await readFile(join(p,'index.html'),'utf8'),HTML);await assert.rejects(access(join(p,'src','river-of-pain')));});
 const conflict=await fixture('conflict');await install(conflict);
 await test('Refus si index modifié après installation',async()=>{await writeFile(join(conflict,'index.html'),(await readFile(join(conflict,'index.html'),'utf8'))+'<!--change-->');await assert.rejects(install(conflict,{remove:true}),/index.html a changé/);assert.ok((await readFile(join(conflict,'index.html'),'utf8')).endsWith('<!--change-->'));});
 const payloadConflict=await fixture('payload-conflict');await install(payloadConflict);
 await test('Refus si un module du DLC a été modifié',async()=>{await writeFile(join(payloadConflict,'src/river-of-pain/core.js'),'// custom');await assert.rejects(install(payloadConflict,{remove:true}),/divergent/);assert.equal(await readFile(join(payloadConflict,'src/river-of-pain/core.js'),'utf8'),'// custom');});
 const failure=await fixture('failure');
 await test('Échec injecté après copie : restauration',async()=>{await assert.rejects(install(failure,{failAfterCopy:true}),/TEST_ONLY/);assert.equal(await readFile(join(failure,'index.html'),'utf8'),HTML);await assert.rejects(access(join(failure,'src/river-of-pain')));});
 const occupied=await fixture('occupied');await mkdir(join(occupied,'src/river-of-pain'));
 await test('Dossier inconnu existant jamais écrasé',async()=>{await writeFile(join(occupied,'src/river-of-pain/custom.txt'),'keep');await assert.rejects(install(occupied),/existe déjà/);assert.equal(await readFile(join(occupied,'src/river-of-pain/custom.txt'),'utf8'),'keep');});
 const symlinked=await fixture('symlink');await symlink(join(root,'regular','src'),join(symlinked,'src/river-of-pain'));
 await test('Lien symbolique de destination refusé',async()=>{await assert.rejects(install(symlinked),/symbolique/);assert.equal(await readFile(join(symlinked,'index.html'),'utf8'),HTML);});
 const other=await fixture('other');await writeFile(join(other,'package.json'),JSON.stringify({name:'other'}));
 await test('Autre projet refusé',async()=>{await assert.rejects(install(other),/n’est pas le projet/);assert.equal(await readFile(join(other,'index.html'),'utf8'),HTML);});
 const absent=await fixture('absent');await writeFile(join(absent,'index.html'),'<html><body>Another shell</body></html>');
 await test('Ancrages manquants refusés',async()=>{await assert.rejects(install(absent),/Structure hôte inconnue/);await assert.rejects(access(join(absent,'src/river-of-pain')));});
}finally{await rm(root,{recursive:true,force:true});}
await writeFile(join(dirname(fileURLToPath(import.meta.url)),'../docs/INSTALLER_TEST_RESULTS.json'),JSON.stringify({passed:results.every(r=>r.passed),cases:results.length,scope:'Fixtures using the observed host DOM, not the complete Tantalus repository',results},null,2));
console.log(results.filter(x=>x.passed).length+'/'+results.length+' installer cases passed');if(results.some(x=>!x.passed))process.exitCode=1;
