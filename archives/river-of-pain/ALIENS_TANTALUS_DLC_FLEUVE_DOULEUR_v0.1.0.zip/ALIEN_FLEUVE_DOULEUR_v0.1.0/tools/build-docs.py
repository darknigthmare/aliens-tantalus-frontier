#!/usr/bin/env python3
from pathlib import Path
from html import escape
import base64,json
R=Path(__file__).resolve().parents[1]
D=json.loads((R/'docs/CONTENT_MANIFEST.json').read_text(encoding='utf-8'))
rooms={r['id']:r for r in D['rooms']}

lines=['# Codex de level design — Hadley’s Hope', '', 'Version 0.1.0-candidate.1 · données extraites du contenu réellement livré.', '',
'## Contrat de cette version', '',
'Les 36 lieux sont des définitions distinctes reliées par 45 arêtes bidirectionnelles. Ils partagent un moteur de rendu et des familles de modules : ce ne sont pas 36 illustrations finales uniques. Tous les passages ont une extrémité de retour. Les portails, objectifs et couvertures utilisent les mêmes coordonnées que la simulation. Les dimensions en mètres sont des intentions de blocage, pas des mesures extraites du roman ; le cadrage et l’échelle verticale restent à affiner.', '',
'Le déplacement est horizontal avec une profondeur continue dans les salles compatibles. Les passages étroits et les conduits sont latéraux. Les escaliers, échelles et monte-charges changent la salle et le niveau déclaré ; aucune animation de cabine ni ascension continue n’est simulée.', '',
'## Composition et lisibilité', '',
'Le découpage HORIZON → SKYLINE → FAR → MID → WALL → FIXTURES → FLOOR → ACTORS → NEAR → FOREGROUND sert de vocabulaire commun. Le moteur compose montagnes et silhouette coloniale en parallaxe, structure murale, mobilier et portes, sol, acteurs triés en profondeur, effets et montants proches. Toutes les couches ne possèdent pas un facteur de parallaxe indépendant dans chaque salle.', '',
'Le HUD est placé au-dessus de la bande de marche. Le bas de l’image reste réservé aux pieds, seuils, couvertures et dangers. Le plan et le carnet mettent la simulation en pause. Les messages temporaires ne bloquent pas les commandes. Les grilles réservées à Newt sont identifiées au moment de l’interaction.', '',
'Les couvertures sont deux îlots lorsqu’une salle possède de la profondeur. Les chemins du fond et de l’avant restent reliés. Une décoration murale non collisionnable ne devient pas un obstacle invisible. La conversion en vue latérale conserve le graphe et les objectifs, mais concentre les projections au même plan.', '',
'## États et interactions', '',
'Les objets récupérés, notes lues, créatures déjà rencontrées, flaques d’acide, fusées encore actives, marqueurs de mission et portes soudées sont sauvegardés. Une salle déjà visitée n’est pas recréée à chaque entrée. Un nouveau stade de crise peut ajouter une rencontre prévue par le moteur. Les trois difficultés modifient les coefficients de perception, vitesse et dégâts ; elles ne possèdent pas encore des scripts d’événements différents.', '',
'La soudure B est physique : elle verrouille un lien bidirectionnel et retient les poursuites associées. Les tâches de scénario intitulées fermer, renforcer ou réarmer enregistrent une progression, mais ne calculent pas une simulation complète des cloisons ou de la distribution d’énergie. Le véhicule et les ascenseurs sont des postes d’interaction. Les missions d’escorte utilisent un suivi de position et un contrôle de proximité à la porte, sans santé propre ni panique avancée du compagnon.', '',
'## Campagne', '']
for c in D['chapters']:
    char=D['characters'][c['character']]
    lines += [f"### {c['index']+1:02d} — {c['title']}", '', f"**Point de vue : {char['name']} · {c['timeLabel']} · départ : {rooms[c['start']]['name']}.**", '',c['synopsis'],'', '| Étape | Lieu | Action réelle | Identifiant |','|---|---|---|---|']
    for i,o in enumerate(c['objectives']):
        obj=next(x for x in rooms[o['room']]['objects'] if x['id']==o['id'])
        lines.append(f"| {i+1} | {rooms[o['room']]['name']} | {o['label']} ({obj['kind']}) | `{o['id']}` |")
    lines += ['',f"Dialogue original d’ouverture, {c['dialogue']['speaker']} : « {c['dialogue']['text']} »",'']
lines += ['## Fiches pièce par pièce','','Les coordonnées x sont en unités du moteur ; z est la position normalisée dans le plan du sol. Les noms de bâtiments et les étages servent à rendre le réseau lisible. Ils ne constituent pas un plan officiel de Hadley’s Hope.','']
for r in D['rooms']:
    lines += [f"### {r['id']} — {r['name']}", '',f"**{r['building']} · niveau {r['floor']} · famille {r['kind']} · largeur {r['width']} u · z {r['minZ']} à {r['maxZ']}.**",'',f"Repère architectural : {r['landmark']}.",'',
    '#### Accès et continuité','', '| Destination | Type | x / z | Condition |','|---|---|---|---|']
    for p in r['portals']:
        condition='Enfant uniquement' if p['childOnly'] else 'Accès scientifique' if p['requires'] else 'Accès général'
        lines.append(f"| {rooms[p['to']]['name']} | {p['kind']} | {p['x']} / {p['z']} | {condition} |")
    lines += ['','#### Fonction des éléments placés','', '| Élément | x / z | Couche | Collision | Fonction |','|---|---|---|---|---|']
    for p in r['props']:
        lines.append(f"| `{p['kind']}` | {p['x']} / {p['z']} | {p['layer']} | {'Oui' if p['collidable'] else 'Non'} | {p['purpose']} |")
    lines += ['', '#### Points d’interaction', '', '| Objet | x / z | Chapitre | Fonction |','|---|---|---|---|']
    for o in r['objects']:
        chapter=str(o['chapter']+1) if 'chapter' in o else 'Optionnel'
        lines.append(f"| {o['label']} | {o['x']} / {o['z']} | {chapter} | {o['kind']} |")
    if not r['objects']: lines.append('| Aucun objectif fixe | — | — | Pièce de liaison |')
    lines += ['', '#### Garde-fous de production','',
    f"Conserver les retours de chacun des {len(r['portals'])} passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.", '',
    'Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.', '']
    if r['kind']=='vent': lines += ['Conduit : Newt reste sans arme. Aucun adulte ne franchit les liens marqués enfant uniquement. La cache n’est pas un point de sortie de la planète. La hauteur visuelle du volume et la reptation complète demandent encore une passe artistique.', '']
    elif r['kind'] in ('hive','derelict'): lines += ['Volume organique : les silhouettes biomécaniques provisoires ne suffisent pas à certifier la fidélité au décor. Le relief de résine et les animations des organismes doivent être remplacés/étoffés avant une validation artistique. Ne pas ajouter un boss reine détruisant la continuité de la campagne.', '']
    else: lines += ['Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.', '']
lines += ['## Validation et étapes restantes','','Les résultats exécutés sont dans `CORE_TEST_RESULTS.json`, `TRAVERSAL_RESULTS.json`, `INSTALLER_TEST_RESULTS.json` et `BROWSER_TEST_RESULTS.json`. Une validation de graphe ou de collision ne vaut pas validation artistique.', '',
'Priorités suivantes : intégration au moteur natif et aux atlas partagés ; reprise des proportions et silhouettes du décor ; scènes jouables plus longues et moins dépendantes d’une simple interaction temporisée ; comportement protecteur et vulnérabilité des escortés ; lecture détaillée du roman pour un rapprochement scène par scène. Aucune de ces tâches n’est déclarée déjà terminée.', '']
(R/'docs/CODEX_LEVEL_DESIGN.md').write_text('\n'.join(lines),encoding='utf-8')

core=json.loads((R/'docs/CORE_TEST_RESULTS.json').read_text())
trav=json.loads((R/'docs/TRAVERSAL_RESULTS.json').read_text())
install=json.loads((R/'docs/INSTALLER_TEST_RESULTS.json').read_text())
browser=json.loads((R/'docs/BROWSER_TEST_RESULTS.json').read_text())
qa='''# Rapport de validation exécutée

Version 0.1.0-candidate.1 — 29 septembre 2026.

## Résultats

'''+f"- Moteur et contenu : {sum(t['passed'] for t in core['results'])}/{core['cases']} groupes de tests passés.\n- Parcours complets du modèle : {sum(t['passed'] for t in trav)}/{len(trav)} — deux vues × trois difficultés.\n- Installateur sur fixtures : {sum(t['passed'] for t in install['results'])}/{install['cases']} tests passés.\n- Recette navigateur : {sum(t['passed'] for t in browser['cases'])}/{len(browser['cases'])} contrôles passés, {len(browser['errors'])} erreur JavaScript relevée.\n- Captures finales : {len(browser['captures'])} images du runtime Chromium.\n\n"+'''## Ce que ces résultats établissent

Les parcours du modèle démarrent au premier chapitre, se déplacent par `Simulation.update`, utilisent des objets à proximité, traversent les véritables portails, consomment de l’équipement et mènent les deux escortes jusqu’à destination. Ils n’appellent pas directement `completeTask`, ne téléportent pas le personnage et ne modifient pas sa santé. Ils traversent les 49 objectifs, puis atteignent la fin du chapitre 16.

Cette recette est une validation structurelle automatisée. Son trajet optimisé d’environ sept minutes de simulation n’inclut pas les temps de lecture et ne représente pas une session utilisateur mesurée. Les différences de difficulté sont modestes sur ce trajet ; l’équilibrage doit être approfondi.

Les tests unitaires vérifient notamment les retours de portes, les points d’interaction hors obstacles, les droits des conduits, le verrou du hangar, la profondeur, les projectiles, la recharge, les soins, l’acide, les fusées, les portes soudées, la poursuite inter-pièces, les importations invalides et les points de reprise. Certains de ces tests utilisent explicitement des états synthétiques ciblés ; ils ne sont pas comptés comme des parcours physiques complets.

La recette navigateur charge le contenu exact du fichier HTML autonome avec Playwright dans Chromium. Le premier objectif et le passage vers le sas sont exécutés avec les commandes clavier. Les scènes médicales, de ruche et de Newt sont obtenues en important des sauvegardes de test validées : leurs captures ne sont pas présentées comme une partie complète jouée manuellement. Les marqueurs et états correspondants sont enregistrés dans le JSON navigateur.

## Limites de l’environnement

Le CLI agent-browser n’était pas installé. La navigation `file://` a été refusée par la politique de Chromium de l’environnement ; aucun contournement de cette politique n’a été utilisé. `page.set_content` permet le contrôle du document exact et de son runtime, mais produit une origine opaque : `localStorage` y est indisponible. Le message de repli, l’import, l’export JSON et le codec de sauvegarde ont été testés ; la persistance native après fermeture/réouverture du navigateur doit être vérifiée sur la machine cible.

Aucun serveur hôte complet, aucun déploiement Vercel, aucune manette ni aucun téléphone physique n’a été testé. Le contrôle tactile est une émulation de pointeur Chromium. Le lanceur et son installateur ont été testés sur des fixtures reproduisant les ancrages observés du dépôt, pas sur les 440 campagnes réellement chargées.

## Corrections intervenues pendant la recette

Le repère cartographique du relais, initialement superposé à celui de l’aire d’atterrissage, a été séparé. Le HUD recouvrant la bande de marche a été déplacé vers le haut. La soudure manuelle utilise désormais une action temporisée et bloque effectivement les poursuivants à la porte. Les importations contrôlent aussi les états de poursuite et les valeurs de distribution électrique. Les notes du carnet ont été réécrites en documents de terrain ; les explications de production restent dans les documents et écrans dédiés.

Deux erreurs du pilote de test ont également été corrigées : la détection de fin d’une interaction temporisée et l’identifiant supposé absent « missing », qui est en fait un objectif valide. Ces corrections ne sont pas présentées comme des corrections de bug du jeu.

## Qualification

**Candidat local jouable validé sur le périmètre décrit. Non qualifié comme DLC final, adaptation intégrale 1:1 ou intégration native complète.**
'''
(R/'docs/QA_REPORT.md').write_text(qa,encoding='utf-8')

style='''body{margin:0;background:#08171c;color:#c8d8d0;font:15px/1.75 Arial,Helvetica,sans-serif}main{max-width:1120px;margin:auto;padding:44px 28px 70px}header{padding:30px 0 40px;border-bottom:1px solid #45635e}small,.kicker{font:11px/1.5 monospace;letter-spacing:.15em;color:#a8b89c}h1{font-size:clamp(36px,5vw,62px);line-height:1.1;font-weight:400;letter-spacing:.04em;color:#e1e5d4;margin:18px 0}h2{font-size:27px;color:#dee1c6;font-weight:400;margin-top:48px}h3{font-size:17px;color:#d5dcc4}a{color:#d4c796}strong{color:#e0e8cc}.lead{font-size:20px;max-width:820px;color:#b9caba}.notice{border-left:3px solid #c7b785;padding:17px 22px;background:#11272c}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:30px 0}.metrics>div{padding:20px;background:#132b2d;border-top:1px solid #628575}.metrics b{display:block;font:34px monospace;color:#d9debd}.metrics span{display:block;font:11px monospace;margin-top:8px;color:#a9bfb0}table{width:100%;border-collapse:collapse;font-size:13px;margin:20px 0}td,th{text-align:left;padding:12px;border-bottom:1px solid #425f595a;vertical-align:top}th{color:#cedabe;font-size:10px;letter-spacing:.1em}figure{margin:28px 0;background:#10272b;border:1px solid #435d565c}figure img{display:block;width:100%;height:auto}figure.portrait{max-width:390px;margin-left:auto;margin-right:auto}figcaption{padding:17px 21px;font-size:13px}figcaption small{display:block;font-size:9px;margin-top:8px;letter-spacing:.04em;color:#8fac9f}.cols{display:grid;grid-template-columns:1fr 1fr;gap:30px}.tag{display:inline-block;padding:4px 9px;background:#233e3e;color:#d0dabc;font:10px monospace}.foot{font-size:11px;color:#92aaa2;border-top:1px solid #405e55;padding-top:20px;margin-top:45px}code{font-size:12px;overflow-wrap:anywhere;color:#cdd3b0}@media(max-width:650px){.metrics{grid-template-columns:1fr 1fr}.cols{grid-template-columns:1fr}td,th{padding:8px 5px;font-size:11px}main{padding:20px 17px}}'''
html=f'''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Rapport illustré — Fleuve de la Douleur 0.1</title><style>{style}</style></head><body><main><header><p class="kicker">TANTALUS FRONTIER / ARCHIVES MIRE / 29 SEPTEMBRE 2026</p><h1>ALIEN<br>FLEUVE DE LA DOULEUR</h1><p class="lead">Hadley’s Hope · Les dernières lumières</p><span class="tag">0.1.0-CANDIDATE.1 · LIVRAISON LOCALE</span></header><p class="notice"><strong>Une première campagne jouable, pas un DLC final.</strong> Les plans, dialogues, notes de terrain et dessins par code sont originaux. Le moteur tourne indépendamment de Tantalus. Le raccord natif, la fidélité scène par scène et les atlas définitifs restent à réaliser.</p><div class="metrics"><div><b>16</b><span>CHAPITRES</span></div><div><b>36</b><span>LIEUX RELIÉS</span></div><div><b>49</b><span>OBJECTIFS PHYSIQUES</span></div><div><b>24</b><span>NOTES ORIGINALES</span></div></div><h2>Ce qui est jouable</h2><div class="cols"><div><h3>La colonie avant et pendant la crise</h3><p>Des logements aux salles médicales, du garage aux soubassements du processeur : 45 connexions relient le parcours. Le changement de pièce se fait par une porte, une grille ou un accès identifié. Les quatre points de vue sont Brackett, Anne, Paris et Newt.</p></div><div><h3>Deux présentations, un même parcours</h3><p>La vue latérale et le déplacement avec profondeur partagent les objectifs. Le tir tient compte de la profondeur et des couvertures. Les réserves sont limitées ; les soins, fusées, portes soudées et dangers persistent dans la sauvegarde du DLC.</p></div></div><h2>Les captures du runtime</h2><p>Ces images proviennent de Chromium exécutant le fichier autonome. Aucune image d’intention n’a été substituée au jeu. Les scènes tardives sont chargées par des sauvegardes de test explicitement signalées ci-dessous.</p>'''
for i,c in enumerate(browser['captures']):
    file=R/c['file'];b64=base64.b64encode(file.read_bytes()).decode('ascii')
    setup='Parcours clavier réel / interface normale' if c['setup']=='Normal UI and physical input' else 'État de test importé dans le moteur ; pas une partie complète jouée manuellement'
    if 'viewport' in c['setup']:setup+=' · émulation portrait'
    cls=' class="portrait"' if 'portrait' in file.name else ''
    html+=f'<figure{cls}><img src="data:image/png;base64,{b64}" alt="{escape(c["description"])}"><figcaption><strong>{i+1:02d} / </strong>{escape(c["description"])}<small>{setup} · salle {escape(c["state"]["room"])} · chapitre {c["state"]["chapter"]}</small></figcaption></figure>'
html+='''<h2>Qualification réellement exécutée</h2><table><thead><tr><th>PÉRIMÈTRE</th><th>RÉSULTAT</th><th>CE QUE CELA NE PROUVE PAS</th></tr></thead><tbody>'''
for label,result,limit in [('Moteur et contenu','90 / 90 groupes de tests','Ne qualifie pas les graphismes comme définitifs.'),('Parcours du modèle','6 / 6 ; 49 objectifs et 2 escortes','Pas six essais humains. Pas de durée de jeu utilisateur certifiée.'),('Installateur','10 / 10 sur fixtures','Pas de build ni de recette des 440 campagnes hôtes.'),('Navigateur','16 / 16 ; aucune erreur JS relevée','Origine opaque : stockage natif non qualifié.'),('Images du jeu','7 captures finales','Scènes tardives initialisées pour la recette, pas chronologie complète en vidéo.')]:
    html+=f'<tr><td>{label}</td><td>{result}</td><td>{limit}</td></tr>'
html+='''</tbody></table><p>Le pilote de parcours emploie les déplacements, les portes, les objets et l’équipement. Il ne téléporte pas le joueur et ne valide pas directement les objectifs. Son trajet optimisé dure environ sept minutes de simulation, sans lecture. Ce résultat appelle encore du travail sur la longueur des scènes et l’équilibrage.</p><h2>Les 16 chapitres de cette version</h2><table><thead><tr><th>#</th><th>CHAPITRE</th><th>POINT DE VUE</th><th>OBJECTIFS</th></tr></thead><tbody>'''
for c in D['chapters']:html+=f'<tr><td>{c["index"]+1:02d}</td><td>{escape(c["title"])}</td><td>{escape(D["characters"][c["character"]]["name"])}</td><td>{len(c["objectives"])}</td></tr>'
html+='''</tbody></table><h2>Raccord au projet principal</h2><p>L’installateur ajoute <code>src/river-of-pain/</code> et un lanceur balisé dans <code>index.html</code>. Il n’écrase pas le catalogue et ne remplace pas le moteur natif. Le bouton ouvre une autre page ; les deux simulations ne tournent pas en superposition. Les fichiers modifiés après installation sont protégés par un contrôle d’empreinte lors du retrait.</p><p>Campagne de référence : <code>v36_campaign_acheron_river_of_pain</code>. L’écho Frontière 2204 et les ressources du Tantalus restent inchangés. Aucun push GitHub ni déploiement Vercel n’a été effectué.</p><h2>Limites à garder visibles</h2><p>Le rendu actuel est constitué de formes dessinées par code : ce ne sont pas les sprites finaux du jeu principal. Les intérieurs utilisent des familles de modules et leurs proportions demandent une passe artistique. Les interactions de véhicule ne sont pas du pilotage. Les escortes ne simulent pas encore les blessures et la protection. Les marqueurs d’électricité et de barricade ne sont pas une simulation complète de la colonie.</p><p>Le CLI agent-browser était absent. Chromium a bloqué la navigation <code>file://</code> ; les tests ont utilisé <code>page.set_content</code> avec le HTML exact, sans modifier sa politique de sécurité. Dans ce contexte, le message « sauvegarde locale indisponible » est attendu. Le codec de sauvegarde et l’export JSON sont contrôlés ; la persistance native sur la machine cible reste à vérifier.</p><h2>Sources et fidélité</h2><p>Le cadre reprend le roman de Christopher Golden, présenté par Titan Books comme un récit de la colonie et des Jorden sur LV-426. L’auteur explique son intention de prélude à <em>Aliens</em> dans l’entretien AvPGalaxy. L’adaptation audio française s’intitule <em>Le Fleuve des souffrances</em>. Les détails secondaires retenus sont documentés comme tels dans le dossier de sources.</p><p>Le roman intégral n’a pas été consulté. Ces 16 chapitres et 49 objectifs sont une condensation créative, pas une reproduction de ses chapitres. Les dialogues et notes sont originaux. La version s’arrête avec Newt encore dans la colonie, séparée du groupe parti à bord du vaisseau scientifique.</p><div class="foot">Dossier associé : README.md · docs/CODEX_LEVEL_DESIGN.md · docs/SOURCES_ET_CONTINUITE.md · docs/QA_REPORT.md · résultats JSON · tests reproductibles. Projet de fan non officiel. Aucun droit de commercialisation de la franchise n’est conféré.</div></main></body></html>'''
(R/'RAPPORT_ILLUSTRE.html').write_text(html,encoding='utf-8')
print('Codex:',len(lines),'lignes logiques. Rapport illustré:',len(html.encode('utf-8')),'octets.')
