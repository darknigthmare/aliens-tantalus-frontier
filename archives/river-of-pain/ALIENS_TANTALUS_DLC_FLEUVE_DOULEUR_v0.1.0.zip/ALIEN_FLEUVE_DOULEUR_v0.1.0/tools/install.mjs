#!/usr/bin/env node
/** Non-destructive installer. Run: node tools/install.mjs /path/to/aliens-tantalus-frontier [--remove] */
import {readFile,writeFile,cp,mkdir,rm,lstat,realpath,readdir} from 'node:fs/promises';
import {resolve,join,dirname,relative} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const packageRoot=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const payload=join(packageRoot,'src','river-of-pain');
const marker='<!-- RIVER-OF-PAIN-LAUNCHER v0.1.0 -->';
const injection=`${marker}\n  <script type="module" src="/src/river-of-pain/launcher.js"></script>\n  <!-- /RIVER-OF-PAIN-LAUNCHER -->\n`;
const sha=b=>createHash('sha256').update(b).digest('hex');
async function exists(p){try{await lstat(p);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}}
async function rejectSymlinks(root,rel){const pieces=rel.split(/[\\/]/).filter(Boolean);let p=root;for(const item of pieces){p=join(p,item);if(await exists(p)){if((await lstat(p)).isSymbolicLink())throw Error('Lien symbolique refusé : '+p);}}}
async function inventory(dir,prefix=''){const out=[];for(const x of (await readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){const rel=prefix+x.name;if(x.isSymbolicLink())throw Error('Payload symlink refused.');if(x.isDirectory())out.push(...await inventory(join(dir,x.name),rel+'/'));else if(x.isFile()){const b=await readFile(join(dir,x.name));out.push({path:rel,size:b.length,sha256:sha(b)});}}return out;}
async function checkFiles(target,files){for(const f of files){const file=join(target,f.path);await rejectSymlinks(target,f.path);if(!await exists(file)||sha(await readFile(file))!==f.sha256)throw Error('Fichier divergent : '+f.path);}const actual=await inventory(target);if(actual.length!==files.length)throw Error('Des fichiers supplémentaires sont présents dans le DLC.');}
export async function install(target,{remove=false,failAfterCopy=false}={}){
 if(!target)throw Error('Indiquez le dossier du projet Tantalus Frontier.');
 const root=await realpath(resolve(target));if(root===packageRoot)throw Error('La destination doit être le projet Tantalus, pas cette archive.');
 for(const rel of ['index.html','package.json','src/river-of-pain','.dlc-installations/river-of-pain-v0.1.0.json','.dlc-backups/river-of-pain-v0.1.0/index.html'])await rejectSymlinks(root,rel);
 const dest=join(root,'src','river-of-pain'),indexPath=join(root,'index.html'),statePath=join(root,'.dlc-installations','river-of-pain-v0.1.0.json'),backupPath=join(root,'.dlc-backups','river-of-pain-v0.1.0','index.html');
 const pkg=JSON.parse(await readFile(join(root,'package.json'),'utf8'));if(pkg.name!=='aliens-tantalus-frontier')throw Error('Ce dossier n’est pas le projet aliens-tantalus-frontier.');
 const current=await readFile(indexPath,'utf8');const state=await exists(statePath)?JSON.parse(await readFile(statePath,'utf8')):null;
 if(state){if(state.version!=='0.1.0-candidate.1'||!Array.isArray(state.files))throw Error('Journal d’installation incompatible.');if(sha(current)!==state.indexAfter)throw Error('index.html a changé depuis l’installation. Désinstallation automatique refusée pour préserver vos modifications.');await checkFiles(dest,state.files);
  if(!remove)return {ok:true,action:'already-installed',files:state.files.length};
  const original=await readFile(backupPath,'utf8');if(sha(original)!==state.indexBefore)throw Error('Sauvegarde de index.html altérée.');
  // Reversible removal: originals are validated before modifying anything.
  await writeFile(indexPath,original);try{await rm(dest,{recursive:true});await rm(statePath);}catch(e){await writeFile(indexPath,current);await cp(payload,dest,{recursive:true});await writeFile(statePath,JSON.stringify(state,null,2));throw e;}
  return {ok:true,action:'removed',files:state.files.length};
 }
 if(remove)throw Error('Aucune installation enregistrée à retirer.');
 if(!current.includes('/src/app.js')||!current.includes('id="title-menu"')||!current.includes('data-panel="archives"')||!/<\/body>/i.test(current))throw Error('Structure hôte inconnue. Aucun fichier n’a été changé.');
 if(current.includes(marker)||await exists(dest))throw Error('Un DLC ou un marqueur existe déjà sans journal reconnu. Installation arrêtée sans écrasement.');
 const files=await inventory(payload),after=current.replace(/<\/body>/i,injection+'</body>');
 let copied=false,changed=false;
 try{
  await mkdir(dirname(backupPath),{recursive:true});await writeFile(backupPath,current);
  await mkdir(dirname(dest),{recursive:true});copied=true;await cp(payload,dest,{recursive:true,errorOnExist:true,force:false});
  if(failAfterCopy)throw Error('TEST_ONLY_FAILURE_AFTER_COPY');
  await checkFiles(dest,files);await writeFile(indexPath,after);changed=true;
  await mkdir(dirname(statePath),{recursive:true});await writeFile(statePath,JSON.stringify({id:'river-of-pain',version:'0.1.0-candidate.1',observedHostVersion:pkg.version,referenceCommit:'496996f5ea557d970ec625aa346876f3eaed1c5f',indexBefore:sha(current),indexAfter:sha(after),files},null,2));
  return {ok:true,action:'installed',files:files.length,hostVersion:pkg.version,qualification:'Only additive files and launcher; full host build not certified.'};
 }catch(e){if(changed)await writeFile(indexPath,current);if(copied)await rm(dest,{recursive:true,force:true});await rm(statePath,{force:true});throw e;}
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{const target=process.argv.slice(2).find(x=>!x.startsWith('--'));console.log(JSON.stringify(await install(target,{remove:process.argv.includes('--remove')}),null,2));}
 catch(e){console.error('Installation arrêtée : '+e.message);process.exitCode=1;}
}
