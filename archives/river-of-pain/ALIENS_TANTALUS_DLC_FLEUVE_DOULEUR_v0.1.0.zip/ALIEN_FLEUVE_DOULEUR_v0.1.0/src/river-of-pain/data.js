/* Authored DLC content. See docs/SOURCES_ET_CONTINUITE.md for provenance. */
(function(root){
const data = {
  "manifest": {
    "id": "river-of-pain",
    "version": "0.1.0-candidate.1",
    "title": "ALIEN — Fleuve de la Douleur",
    "subtitle": "Hadley’s Hope · Les dernières lumières",
    "sourceTitle": "Alien: River of Pain",
    "sourceAuthor": "Christopher Golden",
    "frenchAudioTitle": "Alien — Le Fleuve des souffrances",
    "year": 2179,
    "mode": "MIRE",
    "campaignId": "v36_campaign_acheron_river_of_pain",
    "pairId": "pair_v36_campaign_acheron_river_of_pain",
    "frontierCampaignId": "frontier_v36_campaign_acheron_river_of_pain",
    "frontierPolicy": "preserved_unmodified",
    "saveKey": "atf.dlc.river-of-pain.v1.profile1",
    "saveSchema": 1,
    "baseCommit": "496996f5ea557d970ec625aa346876f3eaed1c5f",
    "implementation": "isolated_playable_runtime_with_host_launcher",
    "limitations": [
      "Architecture et dialogues originaux : pas de reconstruction 1:1 certifiée du roman.",
      "Décors procéduraux et personnages articulés dessinés par code, pas les atlas finaux du jeu hôte.",
      "Aucun roman intégral consulté ; détails secondaires appuyés sur synthèses signalées.",
      "Lanceur additionnel : le runtime natif et les 440 campagnes du jeu hôte ne sont pas remplacés.",
      "Pas de publication GitHub ou Vercel."
    ],
    "counts": {
      "chapters": 16,
      "rooms": 36,
      "links": 45,
      "objectives": 49,
      "archives": 24,
      "props": 231,
      "characters": 4
    }
  },
  "rooms": [
    {
      "id": "pad",
      "name": "Aire d’atterrissage",
      "building": "Périmètre",
      "floor": 0,
      "kind": "exterior",
      "width": 2900,
      "map": [
        0,
        2
      ],
      "theme": "pad",
      "landmark": "Tour de contrôle et feux d’approche",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "amber",
      "dimensionsM": [
        69.0,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "pad>airlock",
          "to": "airlock",
          "x": 170,
          "z": 0.69,
          "kind": "sas",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "pad-set-0",
          "kind": "beacon",
          "x": 442,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "orientation du trajet"
        },
        {
          "id": "pad-set-1",
          "kind": "antenna",
          "x": 845,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "pad-set-2",
          "kind": "fuel",
          "x": 1248,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "pad-set-3",
          "kind": "beacon",
          "x": 1652,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "orientation du trajet"
        },
        {
          "id": "pad-set-4",
          "kind": "cable",
          "x": 2055,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "pad-set-5",
          "kind": "tractor",
          "x": 2458,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "pad-cover1",
          "kind": "crate",
          "x": 1102,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "pad-cover2",
          "kind": "rock",
          "x": 1943,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "welcome",
          "label": "Retrouver Paris",
          "kind": "talk",
          "x": 667,
          "z": 0.81,
          "description": "Vous verrez la tempête plus souvent que le ciel. Les familles, elles, sont ici toute l’année.",
          "chapter": 0
        },
        {
          "id": "stretcher",
          "label": "Prendre en charge le retour des prospecteurs",
          "kind": "talk",
          "x": 1102,
          "z": 0.81,
          "description": "Gardez le couloir libre. Je veux des gens qui respirent, pas une foule autour du lit.",
          "chapter": 4
        },
        {
          "id": "a01",
          "label": "Bordereau d’arrivée",
          "kind": "archive",
          "x": 2378.0,
          "z": 0.43,
          "description": "Bienvenue à Hadley’s Hope. Les nouveaux arrivants doivent se présenter au contrôle colonial avant l’attribution des logements. Ne laissez pas de bagages dans le sas : les équipes de nuit y font passer le matériel lourd."
        }
      ],
      "spawns": [
        {
          "id": "pad-east",
          "x": 2845,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "pad-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "pad-cover1",
          "x": 1102,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "crate"
        },
        {
          "id": "pad-cover2",
          "x": 1943,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "rock"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "airlock",
      "name": "Sas des arrivants",
      "building": "Accueil",
      "floor": 0,
      "kind": "side",
      "width": 1800,
      "map": [
        1,
        2
      ],
      "theme": "airlock",
      "landmark": "Double porte pressurisée, douche de décontamination",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "cold",
      "dimensionsM": [
        42.9,
        2.8,
        3.4
      ],
      "portals": [
        {
          "id": "airlock>pad",
          "to": "pad",
          "x": 170,
          "z": 0.7,
          "kind": "sas",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "airlock>concourse",
          "to": "concourse",
          "x": 1630,
          "z": 0.7,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "airlock-set-0",
          "kind": "shower",
          "x": 372,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "airlock-set-1",
          "kind": "locker",
          "x": 636,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "airlock-set-2",
          "kind": "fan",
          "x": 900,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "airlock-set-3",
          "kind": "panel",
          "x": 1164,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "airlock-set-4",
          "kind": "lamp",
          "x": 1428,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        }
      ],
      "objects": [],
      "spawns": [
        {
          "id": "airlock-east",
          "x": 1745,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "airlock-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "concourse",
      "name": "Coursive centrale",
      "building": "Accueil",
      "floor": 0,
      "kind": "depth",
      "width": 3000,
      "map": [
        2,
        2
      ],
      "theme": "concourse",
      "landmark": "Signalétique des blocs, galerie vitrée",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        71.4,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "concourse>airlock",
          "to": "airlock",
          "x": 170,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "concourse>ops",
          "to": "ops",
          "x": 2830,
          "z": 0.69,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "concourse>hab",
          "to": "hab",
          "x": 840,
          "z": 0.28,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "concourse>med",
          "to": "med",
          "x": 1440,
          "z": 0.28,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "concourse>garage",
          "to": "garage",
          "x": 2040,
          "z": 0.28,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "concourse-set-0",
          "kind": "bench",
          "x": 420,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "concourse-set-1",
          "kind": "window",
          "x": 780,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "concourse-set-2",
          "kind": "sign",
          "x": 1140,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "concourse-set-3",
          "kind": "vending",
          "x": 1500,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "concourse-set-4",
          "kind": "window",
          "x": 1860,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "concourse-set-5",
          "kind": "fan",
          "x": 2220,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "concourse-set-6",
          "kind": "bench",
          "x": 2580,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "concourse-cover1",
          "kind": "machine",
          "x": 1140,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "concourse-cover2",
          "kind": "cart",
          "x": 2010,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [],
      "spawns": [
        {
          "id": "concourse-east",
          "x": 2945,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "concourse-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "concourse-cover1",
          "x": 1140,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "concourse-cover2",
          "x": 2010,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "ops",
      "name": "Contrôle colonial",
      "building": "Administration",
      "floor": 1,
      "kind": "depth",
      "width": 2400,
      "map": [
        2,
        1
      ],
      "theme": "ops",
      "landmark": "Baie de supervision et consoles de communications",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "amber",
      "dimensionsM": [
        57.1,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "ops>concourse",
          "to": "concourse",
          "x": 170,
          "z": 0.69,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "ops>briefing",
          "to": "briefing",
          "x": 2230,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "ops>relay",
          "to": "relay",
          "x": 672,
          "z": 0.28,
          "kind": "coursive",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "ops-set-0",
          "kind": "console",
          "x": 400,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "poste de travail"
        },
        {
          "id": "ops-set-1",
          "kind": "screen",
          "x": 720,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "ops-set-2",
          "kind": "console",
          "x": 1040,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "poste de travail"
        },
        {
          "id": "ops-set-3",
          "kind": "antenna",
          "x": 1360,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "ops-set-4",
          "kind": "screen",
          "x": 1680,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "ops-set-5",
          "kind": "map",
          "x": 2000,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "ops-cover1",
          "kind": "machine",
          "x": 912,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "ops-cover2",
          "kind": "cart",
          "x": 1608,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "brief",
          "label": "Consulter le tableau de service",
          "kind": "terminal",
          "x": 552,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 0
        },
        {
          "id": "missing",
          "label": "Relever les dernières balises PDT",
          "kind": "terminal",
          "x": 912,
          "z": 0.81,
          "description": "On marque chaque porte derrière nous. Je refuse de perdre quelqu’un à un embranchement.",
          "chapter": 7
        },
        {
          "id": "a02",
          "label": "Grille de prospection",
          "kind": "archive",
          "x": 1967.9999999999998,
          "z": 0.43,
          "description": "Secteur de relevé ajouté à la tournée des Jorden. Coordonnées transmises par liaison Compagnie. Priorité haute. L’équipe de prospection demande une raison ; aucune précision reçue à ce jour."
        }
      ],
      "spawns": [
        {
          "id": "ops-east",
          "x": 2345,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "ops-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "ops-cover1",
          "x": 912,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "ops-cover2",
          "x": 1608,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "briefing",
      "name": "Poste de la garnison",
      "building": "Administration",
      "floor": 1,
      "kind": "side",
      "width": 2200,
      "map": [
        3,
        1
      ],
      "theme": "barracks",
      "landmark": "Casiers individuels et table de service",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "cold",
      "dimensionsM": [
        52.4,
        2.8,
        3.4
      ],
      "portals": [
        {
          "id": "briefing>ops",
          "to": "ops",
          "x": 170,
          "z": 0.7,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "briefing-set-0",
          "kind": "locker",
          "x": 383,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "briefing-set-1",
          "kind": "rifle-rack",
          "x": 670,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "briefing-set-2",
          "kind": "table",
          "x": 957,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "briefing-set-3",
          "kind": "locker",
          "x": 1243,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "briefing-set-4",
          "kind": "radio",
          "x": 1530,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "briefing-set-5",
          "kind": "locker",
          "x": 1817,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        }
      ],
      "objects": [
        {
          "id": "locker",
          "label": "Prendre la dotation",
          "kind": "supply",
          "x": 506,
          "z": 0.7,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 0
        },
        {
          "id": "a03",
          "label": "Ordre du jour",
          "kind": "archive",
          "x": 1804.0,
          "z": 0.7,
          "description": "Relève du poste central à six heures. Révision des joints du garage reportée. Les patrouilles devront signaler toute conduite qui siffle : le processeur six nous a déjà coûté assez de sommeil."
        },
        {
          "id": "cache-briefing",
          "label": "Réserve de terrain",
          "kind": "pickup",
          "x": 1166.0,
          "z": 0.7,
          "description": "Soins et dotation de terrain. Une seule collecte par parcours."
        }
      ],
      "spawns": [
        {
          "id": "briefing-east",
          "x": 2145,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "briefing-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "hab",
      "name": "Coursive résidentielle",
      "building": "Habitat",
      "floor": 1,
      "kind": "side",
      "width": 2700,
      "map": [
        3,
        2
      ],
      "theme": "hab",
      "landmark": "Portes numérotées et fenêtres des logements",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "cold",
      "dimensionsM": [
        64.3,
        2.8,
        3.4
      ],
      "portals": [
        {
          "id": "hab>concourse",
          "to": "concourse",
          "x": 170,
          "z": 0.7,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "hab>jorden",
          "to": "jorden",
          "x": 2530,
          "z": 0.7,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "hab>recreation",
          "to": "recreation",
          "x": 756,
          "z": 0.7,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "hab>wash",
          "to": "wash",
          "x": 1296,
          "z": 0.7,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "hab-set-0",
          "kind": "hab-door",
          "x": 425,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "hab-set-1",
          "kind": "window",
          "x": 795,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "hab-set-2",
          "kind": "hab-door",
          "x": 1165,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "hab-set-3",
          "kind": "plant",
          "x": 1535,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "hab-set-4",
          "kind": "hab-door",
          "x": 1905,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "hab-set-5",
          "kind": "drawing",
          "x": 2275,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "trace de vie familiale"
        }
      ],
      "objects": [],
      "spawns": [
        {
          "id": "hab-east",
          "x": 2645,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "hab-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "jorden",
      "name": "Logement des Jorden",
      "building": "Habitat",
      "floor": 1,
      "kind": "depth",
      "width": 1850,
      "map": [
        4,
        2
      ],
      "theme": "quarters",
      "landmark": "Table familiale, lits et dessins d’enfant",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "amber",
      "dimensionsM": [
        44.0,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "jorden>hab",
          "to": "hab",
          "x": 170,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "jorden>vent_hab",
          "to": "vent_hab",
          "x": 1680,
          "z": 0.69,
          "kind": "conduit",
          "childOnly": true,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "jorden-set-0",
          "kind": "bed",
          "x": 354,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "jorden-set-1",
          "kind": "table",
          "x": 582,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "jorden-set-2",
          "kind": "drawing",
          "x": 811,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "trace de vie familiale"
        },
        {
          "id": "jorden-set-3",
          "kind": "cupboard",
          "x": 1039,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "jorden-set-4",
          "kind": "bed",
          "x": 1268,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "jorden-set-5",
          "kind": "toy",
          "x": 1496,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "jorden-cover1",
          "kind": "machine",
          "x": 703,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "jorden-cover2",
          "kind": "cart",
          "x": 1240,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "family",
          "label": "Préparer la tournée",
          "kind": "talk",
          "x": 426,
          "z": 0.81,
          "description": "On peut retarder les relevés. Pas le chauffage du bloc.",
          "chapter": 1
        },
        {
          "id": "a04",
          "label": "Une table pour quatre",
          "kind": "archive",
          "x": 1517.0,
          "z": 0.43,
          "description": "Anne — Il reste des provisions au réfectoire. Tim a encore déplacé ses affaires dans les conduits. J’ai remis la petite couverture sur le lit de Becky. On rentrera avant que le chauffage recommence à faire du bruit."
        }
      ],
      "spawns": [
        {
          "id": "jorden-east",
          "x": 1795,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "jorden-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "jorden-cover1",
          "x": 703,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "jorden-cover2",
          "x": 1240,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "mess",
      "name": "Réfectoire",
      "building": "Habitat",
      "floor": 0,
      "kind": "depth",
      "width": 2600,
      "map": [
        4,
        3
      ],
      "theme": "mess",
      "landmark": "Tables, cuisine et distributeurs",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        61.9,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "mess>recreation",
          "to": "recreation",
          "x": 170,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "mess>wash",
          "to": "wash",
          "x": 2430,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "mess>stores",
          "to": "stores",
          "x": 728,
          "z": 0.28,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "mess-set-0",
          "kind": "vending",
          "x": 417,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "mess-set-1",
          "kind": "stove",
          "x": 770,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "mess-set-2",
          "kind": "table",
          "x": 1123,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "mess-set-3",
          "kind": "table",
          "x": 1477,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "mess-set-4",
          "kind": "table",
          "x": 1830,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "mess-set-5",
          "kind": "sink",
          "x": 2183,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "mess-cover1",
          "kind": "machine",
          "x": 988,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "mess-cover2",
          "kind": "cart",
          "x": 1742,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "provisions",
          "label": "Récupérer les provisions",
          "kind": "supply",
          "x": 598,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 1
        },
        {
          "id": "civilian",
          "label": "Accompagner un colon jusqu’au magasin",
          "kind": "escort",
          "x": 988,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 8,
          "escortTo": "stores",
          "escortName": "Colon du bloc C"
        },
        {
          "id": "ration",
          "label": "Trouver de quoi manger",
          "kind": "supply",
          "x": 1378,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 14
        }
      ],
      "spawns": [
        {
          "id": "mess-east",
          "x": 2545,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "mess-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "mess-cover1",
          "x": 988,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "mess-cover2",
          "x": 1742,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "recreation",
      "name": "Centre de loisirs",
      "building": "Habitat",
      "floor": 0,
      "kind": "depth",
      "width": 2250,
      "map": [
        3,
        3
      ],
      "theme": "recreation",
      "landmark": "Jeux, bancs et accès à la maintenance",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        53.6,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "recreation>hab",
          "to": "hab",
          "x": 170,
          "z": 0.69,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "recreation>mess",
          "to": "mess",
          "x": 2080,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "recreation>vent_hab",
          "to": "vent_hab",
          "x": 630,
          "z": 0.28,
          "kind": "grille",
          "childOnly": true,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "recreation-set-0",
          "kind": "arcade",
          "x": 417,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "recreation-set-1",
          "kind": "bench",
          "x": 771,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "recreation-set-2",
          "kind": "arcade",
          "x": 1125,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "recreation-set-3",
          "kind": "table",
          "x": 1479,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "recreation-set-4",
          "kind": "drawing",
          "x": 1833,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "trace de vie familiale"
        },
        {
          "id": "recreation-cover1",
          "kind": "machine",
          "x": 855,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "recreation-cover2",
          "kind": "cart",
          "x": 1508,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "a05",
          "label": "Les chemins de Tim",
          "kind": "archive",
          "x": 1845.0,
          "z": 0.43,
          "description": "Après la grille qui vibre, tourner à gauche. Ne pas poser le pied sur la plaque claire. Elle résonne jusque dans le couloir. Tim dit qu’il connaît un chemin encore plus court."
        }
      ],
      "spawns": [
        {
          "id": "recreation-east",
          "x": 2195,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "recreation-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "recreation-cover1",
          "x": 855,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "recreation-cover2",
          "x": 1508,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "med",
      "name": "Infirmerie",
      "building": "Médical",
      "floor": 0,
      "kind": "depth",
      "width": 2800,
      "map": [
        2,
        3
      ],
      "theme": "med",
      "landmark": "Lits isolés, vitres d’observation et moniteurs",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "amber",
      "dimensionsM": [
        66.7,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "med>concourse",
          "to": "concourse",
          "x": 170,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "med>isolation",
          "to": "isolation",
          "x": 2630,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "med>clinic_store",
          "to": "clinic_store",
          "x": 784,
          "z": 0.28,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "med>science",
          "to": "science",
          "x": 1344,
          "z": 0.28,
          "kind": "sas",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "med-set-0",
          "kind": "bed",
          "x": 433,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "med-set-1",
          "kind": "monitor",
          "x": 820,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "med-set-2",
          "kind": "bed",
          "x": 1207,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "med-set-3",
          "kind": "sink",
          "x": 1593,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "med-set-4",
          "kind": "medicine",
          "x": 1980,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "med-set-5",
          "kind": "bed",
          "x": 2367,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "med-cover1",
          "kind": "machine",
          "x": 1064,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "med-cover2",
          "kind": "cart",
          "x": 1876,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "triage",
          "label": "Transmettre le bilan à Komiskey",
          "kind": "terminal",
          "x": 644,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 4
        },
        {
          "id": "patient_log",
          "label": "Consulter le registre des patients",
          "kind": "terminal",
          "x": 1064,
          "z": 0.81,
          "description": "Ce n’est pas une cargaison. C’est mon mari.",
          "chapter": 5
        },
        {
          "id": "a06",
          "label": "Priorité médicale",
          "kind": "archive",
          "x": 2296.0,
          "z": 0.43,
          "description": "Couloir médical dégagé en permanence. Un seul membre de la famille admis auprès des patients. Les demandes de transfert vers le laboratoire doivent être validées par le personnel soignant."
        },
        {
          "id": "cache-med",
          "label": "Réserve de terrain",
          "kind": "pickup",
          "x": 1484.0,
          "z": 0.86,
          "description": "Soins et dotation de terrain. Une seule collecte par parcours."
        }
      ],
      "spawns": [
        {
          "id": "med-east",
          "x": 2745,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "med-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "med-cover1",
          "x": 1064,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "med-cover2",
          "x": 1876,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "isolation",
      "name": "Chambre d’isolement",
      "building": "Médical",
      "floor": 0,
      "kind": "side",
      "width": 1700,
      "map": [
        1,
        3
      ],
      "theme": "isolation",
      "landmark": "Lit d’observation et hublot de quarantaine",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "cold",
      "dimensionsM": [
        40.5,
        2.8,
        3.4
      ],
      "portals": [
        {
          "id": "isolation>med",
          "to": "med",
          "x": 170,
          "z": 0.7,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "isolation>vent_med",
          "to": "vent_med",
          "x": 1530,
          "z": 0.7,
          "kind": "grille",
          "childOnly": true,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "isolation-set-0",
          "kind": "bed",
          "x": 362,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "isolation-set-1",
          "kind": "monitor",
          "x": 606,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "isolation-set-2",
          "kind": "glass",
          "x": 850,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "isolation-set-3",
          "kind": "sink",
          "x": 1094,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "isolation-set-4",
          "kind": "specimen",
          "x": 1338,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        }
      ],
      "objects": [
        {
          "id": "quarantine",
          "label": "Fermer l’isolement médical",
          "kind": "seal",
          "x": 391,
          "z": 0.7,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 4
        },
        {
          "id": "a07",
          "label": "Le hublot",
          "kind": "archive",
          "x": 1394.0,
          "z": 0.7,
          "description": "L’isolement reste fermé. La vitre ne doit pas être ouverte pour faciliter une observation. Toute intervention sur le patient nécessite deux personnes et un accès libre au sas."
        }
      ],
      "spawns": [
        {
          "id": "isolation-east",
          "x": 1645,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "isolation-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "science",
      "name": "Laboratoire de la Compagnie",
      "building": "Recherche",
      "floor": 0,
      "kind": "depth",
      "width": 2400,
      "map": [
        1,
        4
      ],
      "theme": "lab",
      "landmark": "Paillasses, cuves et racks de confinement",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        57.1,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "science>med",
          "to": "med",
          "x": 170,
          "z": 0.69,
          "kind": "sas",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "science>records",
          "to": "records",
          "x": 2230,
          "z": 0.69,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "science>service",
          "to": "service",
          "x": 672,
          "z": 0.28,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "science>hangar",
          "to": "hangar",
          "x": 1152,
          "z": 0.28,
          "kind": "sas",
          "childOnly": false,
          "requires": "scienceClearance"
        }
      ],
      "props": [
        {
          "id": "science-set-0",
          "kind": "specimen",
          "x": 400,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "science-set-1",
          "kind": "console",
          "x": 720,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "poste de travail"
        },
        {
          "id": "science-set-2",
          "kind": "specimen",
          "x": 1040,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "science-set-3",
          "kind": "sink",
          "x": 1360,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "science-set-4",
          "kind": "microscope",
          "x": 1680,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "science-set-5",
          "kind": "tank",
          "x": 2000,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "science-cover1",
          "kind": "machine",
          "x": 912,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "science-cover2",
          "kind": "cart",
          "x": 1608,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "orders",
          "label": "Lire la directive scientifique",
          "kind": "terminal",
          "x": 552,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 5
        },
        {
          "id": "hidalgo",
          "label": "Recevoir la transmission de Brackett",
          "kind": "talk",
          "x": 912,
          "z": 0.81,
          "description": "La sortie existe. Nous allons la rendre accessible à ceux qui sont encore avec nous.",
          "chapter": 12,
          "grantFlag": "scienceClearance"
        },
        {
          "id": "a08",
          "label": "Mainmise",
          "kind": "archive",
          "x": 1967.9999999999998,
          "z": 0.43,
          "description": "L’échantillon doit demeurer sur place. Les résultats d’observation passent par le canal scientifique avant toute transmission extérieure. Les urgences médicales ne dispensent pas de renseigner la chaîne de possession."
        }
      ],
      "spawns": [
        {
          "id": "science-east",
          "x": 2345,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "science-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "science-cover1",
          "x": 912,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "science-cover2",
          "x": 1608,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "records",
      "name": "Salle des archives",
      "building": "Recherche",
      "floor": 1,
      "kind": "side",
      "width": 1800,
      "map": [
        0,
        4
      ],
      "theme": "records",
      "landmark": "Bandes de données et baie réseau",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "amber",
      "dimensionsM": [
        42.9,
        2.8,
        3.4
      ],
      "portals": [
        {
          "id": "records>science",
          "to": "science",
          "x": 170,
          "z": 0.7,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "records>relay",
          "to": "relay",
          "x": 1630,
          "z": 0.7,
          "kind": "coursive",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "records-set-0",
          "kind": "rack",
          "x": 372,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "records-set-1",
          "kind": "rack",
          "x": 636,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "records-set-2",
          "kind": "console",
          "x": 900,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "poste de travail"
        },
        {
          "id": "records-set-3",
          "kind": "rack",
          "x": 1164,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "records-set-4",
          "kind": "screen",
          "x": 1428,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        }
      ],
      "objects": [
        {
          "id": "copy",
          "label": "Conserver une copie des échanges",
          "kind": "terminal",
          "x": 414,
          "z": 0.7,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 5
        },
        {
          "id": "a09",
          "label": "Transmission conservée",
          "kind": "archive",
          "x": 1476.0,
          "z": 0.7,
          "description": "Copie locale créée. Si la liaison est coupée, garder les bandes hors de la baie principale. La suppression d’un message ne doit pas supprimer la preuve qu’il a été reçu."
        }
      ],
      "spawns": [
        {
          "id": "records-east",
          "x": 1745,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "records-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "garage",
      "name": "Garage des prospecteurs",
      "building": "Logistique",
      "floor": 0,
      "kind": "depth",
      "width": 3200,
      "map": [
        3,
        4
      ],
      "theme": "garage",
      "landmark": "Tracteur de prospection sur sa voie de service",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        76.2,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "garage>concourse",
          "to": "concourse",
          "x": 170,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "garage>survey",
          "to": "survey",
          "x": 3030,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "garage>service",
          "to": "service",
          "x": 896,
          "z": 0.28,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "garage>road",
          "to": "road",
          "x": 1536,
          "z": 0.28,
          "kind": "sas",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "garage-set-0",
          "kind": "tractor",
          "x": 512,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "garage-set-1",
          "kind": "tools",
          "x": 1056,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "garage-set-2",
          "kind": "fuel",
          "x": 1600,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "garage-set-3",
          "kind": "gantry",
          "x": 2144,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "garage-set-4",
          "kind": "wheel",
          "x": 2688,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "garage-cover1",
          "kind": "machine",
          "x": 1216,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "garage-cover2",
          "kind": "cart",
          "x": 2144,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "rescue_kit",
          "label": "Prendre le matériel de secours",
          "kind": "supply",
          "x": 736,
          "z": 0.81,
          "description": "Coupez l’arrivée avant de toucher aux vannes. Ici, une mauvaise décision se propage à tout le réseau.",
          "chapter": 2
        },
        {
          "id": "tractor",
          "label": "Préparer le tracteur",
          "kind": "vehicle",
          "x": 1216,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 3
        },
        {
          "id": "a10",
          "label": "Tracteur des prospecteurs",
          "kind": "archive",
          "x": 2624.0,
          "z": 0.43,
          "description": "Le tracteur revient couvert d’une poussière que les filtres n’arrêtent pas correctement. Vérifier les joints avant toute autre sortie. Ne pas déposer les bottes de prospection dans les casiers propres."
        },
        {
          "id": "cache-garage",
          "label": "Réserve de terrain",
          "kind": "pickup",
          "x": 1696.0,
          "z": 0.86,
          "description": "Soins et dotation de terrain. Une seule collecte par parcours."
        }
      ],
      "spawns": [
        {
          "id": "garage-east",
          "x": 3145,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "garage-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "garage-cover1",
          "x": 1216,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "garage-cover2",
          "x": 2144,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "survey",
      "name": "Bureau des prospecteurs",
      "building": "Logistique",
      "floor": 0,
      "kind": "depth",
      "width": 2500,
      "map": [
        4,
        4
      ],
      "theme": "survey",
      "landmark": "Cartes topographiques et postes radio",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        59.5,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "survey>garage",
          "to": "garage",
          "x": 170,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "survey>stores",
          "to": "stores",
          "x": 2330,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "survey>vent_survey",
          "to": "vent_survey",
          "x": 700,
          "z": 0.28,
          "kind": "grille",
          "childOnly": true,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "survey-set-0",
          "kind": "map",
          "x": 442,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "survey-set-1",
          "kind": "console",
          "x": 846,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "poste de travail"
        },
        {
          "id": "survey-set-2",
          "kind": "radio",
          "x": 1250,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "survey-set-3",
          "kind": "tools",
          "x": 1654,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "survey-set-4",
          "kind": "shelf",
          "x": 2058,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "survey-cover1",
          "kind": "machine",
          "x": 950,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "survey-cover2",
          "kind": "cart",
          "x": 1675,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "coordinates",
          "label": "Recevoir la grille de prospection",
          "kind": "terminal",
          "x": 575,
          "z": 0.81,
          "description": "La radio passe mal. Je laisse une balise : personne ne retrouvera cette passe de nuit.",
          "chapter": 3
        },
        {
          "id": "barricade",
          "label": "Renforcer la fermeture du bureau",
          "kind": "seal",
          "x": 950,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 9
        },
        {
          "id": "last_power",
          "label": "Alimenter le verrou une dernière fois",
          "kind": "power",
          "x": 1325,
          "z": 0.81,
          "description": "Ne te retourne pas. Compte les virages comme quand vous jouiez.",
          "chapter": 11
        },
        {
          "id": "vent_open",
          "label": "Dégager l’accès au conduit",
          "kind": "seal",
          "x": 1700,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 11
        },
        {
          "id": "newt_escape",
          "label": "Mettre Newt à l’abri",
          "kind": "talk",
          "x": 575,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 11
        },
        {
          "id": "luisa",
          "label": "Dégager Luisa et la conduire au hangar",
          "kind": "escort",
          "x": 950,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 12,
          "escortTo": "hangar",
          "escortName": "Luisa",
          "grantFlag": "scienceClearance"
        },
        {
          "id": "a11",
          "label": "Un bureau transformé",
          "kind": "archive",
          "x": 2050.0,
          "z": 0.43,
          "description": "Des familles attendent près des cartes. Elles veulent savoir quel bâtiment tient encore. Ne pas donner une destination tant qu’une patrouille n’a pas confirmé le passage."
        }
      ],
      "spawns": [
        {
          "id": "survey-east",
          "x": 2445,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "survey-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "survey-cover1",
          "x": 950,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "survey-cover2",
          "x": 1675,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "stores",
      "name": "Magasin de fret",
      "building": "Logistique",
      "floor": 0,
      "kind": "depth",
      "width": 3100,
      "map": [
        4,
        5
      ],
      "theme": "stores",
      "landmark": "Palettes, rack de levage et allées dégagées",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "amber",
      "dimensionsM": [
        73.8,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "stores>survey",
          "to": "survey",
          "x": 170,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "stores>power",
          "to": "power",
          "x": 2930,
          "z": 0.69,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "stores>mess",
          "to": "mess",
          "x": 868,
          "z": 0.28,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "stores-set-0",
          "kind": "crate",
          "x": 458,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "stores-set-1",
          "kind": "shelf",
          "x": 895,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "stores-set-2",
          "kind": "pallet",
          "x": 1332,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "stores-set-3",
          "kind": "gantry",
          "x": 1768,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "stores-set-4",
          "kind": "crate",
          "x": 2205,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "stores-set-5",
          "kind": "shelf",
          "x": 2642,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "stores-cover1",
          "kind": "machine",
          "x": 1178,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "stores-cover2",
          "kind": "cart",
          "x": 2077,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "shelter",
          "label": "Mettre le refuge provisoire sous tension",
          "kind": "power",
          "x": 713,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 8
        },
        {
          "id": "welding",
          "label": "Récupérer un poste à souder",
          "kind": "supply",
          "x": 1178,
          "z": 0.81,
          "description": "La porte n’a pas besoin de tenir toute la nuit. Seulement assez longtemps pour les enfants.",
          "chapter": 9
        },
        {
          "id": "a12",
          "label": "Refuge provisoire",
          "kind": "archive",
          "x": 2542.0,
          "z": 0.43,
          "description": "Le fret peut attendre. Dégager deux allées jusqu’à la porte et réserver les couvertures aux enfants. Les caisses contre le mur ne seront ouvertes qu’en présence d’un responsable."
        },
        {
          "id": "cache-stores",
          "label": "Réserve de terrain",
          "kind": "pickup",
          "x": 1643.0,
          "z": 0.86,
          "description": "Soins et dotation de terrain. Une seule collecte par parcours."
        }
      ],
      "spawns": [
        {
          "id": "stores-east",
          "x": 3045,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "stores-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "stores-cover1",
          "x": 1178,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "stores-cover2",
          "x": 2077,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "power",
      "name": "Distribution électrique",
      "building": "Maintenance",
      "floor": -1,
      "kind": "depth",
      "width": 2600,
      "map": [
        3,
        5
      ],
      "theme": "power",
      "landmark": "Deux banques de coupe-circuits et conduites",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        61.9,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "power>stores",
          "to": "stores",
          "x": 170,
          "z": 0.69,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "power>pump",
          "to": "pump",
          "x": 2430,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "power>coolant",
          "to": "coolant",
          "x": 728,
          "z": 0.28,
          "kind": "échelle",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "power-set-0",
          "kind": "transformer",
          "x": 417,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "power-set-1",
          "kind": "panel",
          "x": 770,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "power-set-2",
          "kind": "transformer",
          "x": 1123,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "power-set-3",
          "kind": "panel",
          "x": 1477,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "power-set-4",
          "kind": "cable",
          "x": 1830,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "power-set-5",
          "kind": "coil",
          "x": 2183,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "power-cover1",
          "kind": "machine",
          "x": 988,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "power-cover2",
          "kind": "cart",
          "x": 1742,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "grid",
          "label": "Réarmer le départ habitat",
          "kind": "power",
          "x": 598,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 1
        },
        {
          "id": "emergency",
          "label": "Rétablir le circuit de secours",
          "kind": "power",
          "x": 988,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 9
        },
        {
          "id": "withdraw",
          "label": "Fermer derrière le groupe",
          "kind": "seal",
          "x": 1378,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 10
        },
        {
          "id": "a13",
          "label": "Deux circuits",
          "kind": "archive",
          "x": 2132.0,
          "z": 0.43,
          "description": "Les départs habitat et médical partagent encore un relais. En cas de surcharge, couper les appareils non essentiels avant de réarmer. Un deuxième claquement signifie qu’il faut laisser le coupe-circuit ouvert."
        }
      ],
      "spawns": [
        {
          "id": "power-east",
          "x": 2545,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "power-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "power-cover1",
          "x": 988,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "power-cover2",
          "x": 1742,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "pump",
      "name": "Station de pompage",
      "building": "Maintenance",
      "floor": -1,
      "kind": "depth",
      "width": 2400,
      "map": [
        2,
        5
      ],
      "theme": "pump",
      "landmark": "Collecteurs, vannes et caniveaux protégés",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        57.1,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "pump>power",
          "to": "power",
          "x": 170,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "pump>service",
          "to": "service",
          "x": 2230,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "pump>approach",
          "to": "approach",
          "x": 672,
          "z": 0.28,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "pump-set-0",
          "kind": "tank",
          "x": 432,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "pump-set-1",
          "kind": "pipe",
          "x": 816,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "pump-set-2",
          "kind": "valve",
          "x": 1200,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "pump-set-3",
          "kind": "tank",
          "x": 1584,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "pump-set-4",
          "kind": "valve",
          "x": 1968,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "pump-cover1",
          "kind": "machine",
          "x": 912,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "pump-cover2",
          "kind": "cart",
          "x": 1608,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "reroute",
          "label": "Détourner la pression du passage",
          "kind": "valve",
          "x": 552,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 7
        },
        {
          "id": "a14",
          "label": "Sous les logements",
          "kind": "archive",
          "x": 1967.9999999999998,
          "z": 0.43,
          "description": "La vanne de retour résiste à froid. Ne pas la forcer tant que le manomètre indique une différence de pression. On a besoin d’eau, pas d’une galerie noyée."
        },
        {
          "id": "cache-pump",
          "label": "Réserve de terrain",
          "kind": "pickup",
          "x": 1272.0,
          "z": 0.86,
          "description": "Soins et dotation de terrain. Une seule collecte par parcours."
        }
      ],
      "spawns": [
        {
          "id": "pump-east",
          "x": 2345,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "pump-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "pump-cover1",
          "x": 912,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "pump-cover2",
          "x": 1608,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "service",
      "name": "Galerie technique",
      "building": "Maintenance",
      "floor": -1,
      "kind": "side",
      "width": 3000,
      "map": [
        2,
        4
      ],
      "theme": "service",
      "landmark": "Passage sous les bâtiments, conduites continues",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "amber",
      "dimensionsM": [
        71.4,
        2.8,
        3.4
      ],
      "portals": [
        {
          "id": "service>pump",
          "to": "pump",
          "x": 170,
          "z": 0.7,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "service>science",
          "to": "science",
          "x": 2830,
          "z": 0.7,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "service>garage",
          "to": "garage",
          "x": 840,
          "z": 0.7,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "service-set-0",
          "kind": "pipe",
          "x": 492,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "service-set-1",
          "kind": "fan",
          "x": 996,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "service-set-2",
          "kind": "pipe",
          "x": 1500,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "service-set-3",
          "kind": "cable",
          "x": 2004,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "service-set-4",
          "kind": "pipe",
          "x": 2508,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        }
      ],
      "objects": [
        {
          "id": "trail",
          "label": "Suivre les traces dans la galerie",
          "kind": "scan",
          "x": 690,
          "z": 0.7,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 7
        }
      ],
      "spawns": [
        {
          "id": "service-east",
          "x": 2945,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "service-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "road",
      "name": "Piste du plateau",
      "building": "Périmètre",
      "floor": 0,
      "kind": "exterior",
      "width": 3700,
      "map": [
        5,
        4
      ],
      "theme": "road",
      "landmark": "Piquets de balisage, roches et ravines non praticables",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        88.1,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "road>garage",
          "to": "garage",
          "x": 170,
          "z": 0.69,
          "kind": "sas",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "road>plateau",
          "to": "plateau",
          "x": 3530,
          "z": 0.69,
          "kind": "piste",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "road>processor6",
          "to": "processor6",
          "x": 1036,
          "z": 0.28,
          "kind": "piste",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "road-set-0",
          "kind": "beacon",
          "x": 562,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "orientation du trajet"
        },
        {
          "id": "road-set-1",
          "kind": "rock",
          "x": 1206,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "road-set-2",
          "kind": "rock",
          "x": 1850,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "road-set-3",
          "kind": "beacon",
          "x": 2494,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "orientation du trajet"
        },
        {
          "id": "road-set-4",
          "kind": "wreck",
          "x": 3138,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "road-cover1",
          "kind": "crate",
          "x": 1406,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "road-cover2",
          "kind": "rock",
          "x": 2479,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [],
      "spawns": [
        {
          "id": "road-east",
          "x": 3645,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "road-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "road-cover1",
          "x": 1406,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "crate"
        },
        {
          "id": "road-cover2",
          "x": 2479,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "rock"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "plateau",
      "name": "Plateau des relevés",
      "building": "Périmètre",
      "floor": 0,
      "kind": "exterior",
      "width": 2900,
      "map": [
        6,
        4
      ],
      "theme": "plateau",
      "landmark": "Tracteur arrêté au pied de formations rocheuses",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        69.0,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "plateau>road",
          "to": "road",
          "x": 170,
          "z": 0.69,
          "kind": "piste",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "plateau>derelict",
          "to": "derelict",
          "x": 2730,
          "z": 0.69,
          "kind": "brèche",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "plateau-set-0",
          "kind": "tractor",
          "x": 482,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "plateau-set-1",
          "kind": "rock",
          "x": 966,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "plateau-set-2",
          "kind": "beacon",
          "x": 1450,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "orientation du trajet"
        },
        {
          "id": "plateau-set-3",
          "kind": "rock",
          "x": 1934,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "plateau-set-4",
          "kind": "cable",
          "x": 2418,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "plateau-cover1",
          "kind": "crate",
          "x": 1102,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "plateau-cover2",
          "kind": "rock",
          "x": 1943,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "beacon",
          "label": "Poser une balise sur le plateau",
          "kind": "beacon",
          "x": 667,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 3
        }
      ],
      "spawns": [
        {
          "id": "plateau-east",
          "x": 2845,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "plateau-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "plateau-cover1",
          "x": 1102,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "crate"
        },
        {
          "id": "plateau-cover2",
          "x": 1943,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "rock"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "derelict",
      "name": "Seuil de l’épave",
      "building": "Épave",
      "floor": 0,
      "kind": "derelict",
      "width": 2500,
      "map": [
        7,
        4
      ],
      "theme": "derelict",
      "landmark": "Arches biomécaniques et coque affaissée",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "amber",
      "dimensionsM": [
        59.5,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "derelict>plateau",
          "to": "plateau",
          "x": 170,
          "z": 0.69,
          "kind": "brèche",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "derelict-set-0",
          "kind": "rib",
          "x": 442,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "derelict-set-1",
          "kind": "rib",
          "x": 846,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "derelict-set-2",
          "kind": "fossil",
          "x": 1250,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "derelict-set-3",
          "kind": "rib",
          "x": 1654,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "derelict-set-4",
          "kind": "egg",
          "x": 2058,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "derelict-cover1",
          "kind": "machine",
          "x": 950,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "derelict-cover2",
          "kind": "rock",
          "x": 1675,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "threshold",
          "label": "Examiner le seuil de l’épave",
          "kind": "scan",
          "x": 575,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 3
        },
        {
          "id": "a16",
          "label": "Une coque étrangère",
          "kind": "archive",
          "x": 2050.0,
          "z": 0.43,
          "description": "Le métal n’a pas la couleur du métal. Les arches se poursuivent au-delà du faisceau et la radio ne tient plus. Balise posée près du seuil. Ne pas déplacer le tracteur sans prévenir."
        }
      ],
      "spawns": [
        {
          "id": "derelict-east",
          "x": 2445,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "derelict-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "derelict-cover1",
          "x": 950,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "derelict-cover2",
          "x": 1675,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "rock"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "processor6",
      "name": "Processeur six",
      "building": "Terraformage",
      "floor": 0,
      "kind": "depth",
      "width": 3000,
      "map": [
        5,
        5
      ],
      "theme": "processor",
      "landmark": "Passerelle industrielle et conduites sous pression",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        71.4,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "processor6>road",
          "to": "road",
          "x": 170,
          "z": 0.69,
          "kind": "piste",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "processor6-set-0",
          "kind": "turbine",
          "x": 492,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "processor6-set-1",
          "kind": "valve",
          "x": 996,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "processor6-set-2",
          "kind": "turbine",
          "x": 1500,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "processor6-set-3",
          "kind": "gantry",
          "x": 2004,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "processor6-set-4",
          "kind": "pipe",
          "x": 2508,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "processor6-cover1",
          "kind": "machine",
          "x": 1140,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "processor6-cover2",
          "kind": "cart",
          "x": 2010,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "pressure",
          "label": "Isoler la conduite endommagée",
          "kind": "valve",
          "x": 690,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 2
        },
        {
          "id": "incident",
          "label": "Récupérer le rapport d’intervention",
          "kind": "terminal",
          "x": 1140,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 2
        },
        {
          "id": "a15",
          "label": "Intervention interrompue",
          "kind": "archive",
          "x": 2460.0,
          "z": 0.43,
          "description": "Balisage incomplet sur la piste. Rester du même côté des piquets au retour. La tempête efface les traces de roues en quelques minutes."
        },
        {
          "id": "cache-processor6",
          "label": "Réserve de terrain",
          "kind": "pickup",
          "x": 1590.0,
          "z": 0.86,
          "description": "Soins et dotation de terrain. Une seule collecte par parcours."
        }
      ],
      "spawns": [
        {
          "id": "processor6-east",
          "x": 2945,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "processor6-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "processor6-cover1",
          "x": 1140,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "processor6-cover2",
          "x": 2010,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "approach",
      "name": "Accès au processeur un",
      "building": "Terraformage",
      "floor": 0,
      "kind": "exterior",
      "width": 3200,
      "map": [
        1,
        5
      ],
      "theme": "approach",
      "landmark": "Pylônes, sas de maintenance et énormes échangeurs",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        76.2,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "approach>pump",
          "to": "pump",
          "x": 170,
          "z": 0.69,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "approach>lift",
          "to": "lift",
          "x": 3030,
          "z": 0.69,
          "kind": "monte-charge",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "approach-set-0",
          "kind": "tower",
          "x": 512,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "approach-set-1",
          "kind": "beacon",
          "x": 1056,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "orientation du trajet"
        },
        {
          "id": "approach-set-2",
          "kind": "pipe",
          "x": 1600,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "approach-set-3",
          "kind": "tower",
          "x": 2144,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "approach-set-4",
          "kind": "beacon",
          "x": 2688,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "orientation du trajet"
        },
        {
          "id": "approach-cover1",
          "kind": "crate",
          "x": 1216,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "approach-cover2",
          "kind": "rock",
          "x": 2144,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [],
      "spawns": [
        {
          "id": "approach-east",
          "x": 3145,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "approach-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "approach-cover1",
          "x": 1216,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "crate"
        },
        {
          "id": "approach-cover2",
          "x": 2144,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "rock"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "lift",
      "name": "Monte-charge du processeur",
      "building": "Terraformage",
      "floor": -1,
      "kind": "side",
      "width": 1800,
      "map": [
        1,
        6
      ],
      "theme": "lift",
      "landmark": "Cabine de fret et paliers identifiés",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "amber",
      "dimensionsM": [
        42.9,
        2.8,
        3.4
      ],
      "portals": [
        {
          "id": "lift>approach",
          "to": "approach",
          "x": 170,
          "z": 0.7,
          "kind": "monte-charge",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "lift>hive",
          "to": "hive",
          "x": 1630,
          "z": 0.7,
          "kind": "monte-charge",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "lift-set-0",
          "kind": "cable",
          "x": 405,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "lift-set-1",
          "kind": "panel",
          "x": 735,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "lift-set-2",
          "kind": "gantry",
          "x": 1065,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "lift-set-3",
          "kind": "lamp",
          "x": 1395,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        }
      ],
      "objects": [
        {
          "id": "descent",
          "label": "Commander le monte-charge",
          "kind": "terminal",
          "x": 414,
          "z": 0.7,
          "description": "N’approchez pas des parois. Repliez-vous par les balises ; ne tirez que pour ouvrir le passage.",
          "chapter": 10
        }
      ],
      "spawns": [
        {
          "id": "lift-east",
          "x": 1745,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "lift-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "hive",
      "name": "Soubassements envahis",
      "building": "Terraformage",
      "floor": -2,
      "kind": "hive",
      "width": 3000,
      "map": [
        2,
        6
      ],
      "theme": "hive",
      "landmark": "Résine sur les structures industrielles, balises PDT",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        71.4,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "hive>lift",
          "to": "lift",
          "x": 170,
          "z": 0.69,
          "kind": "monte-charge",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "hive>coolant",
          "to": "coolant",
          "x": 2830,
          "z": 0.69,
          "kind": "passerelle",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "hive-set-0",
          "kind": "resin",
          "x": 450,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "progression de la contamination"
        },
        {
          "id": "hive-set-1",
          "kind": "cocoon",
          "x": 870,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "hive-set-2",
          "kind": "rib",
          "x": 1290,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "hive-set-3",
          "kind": "resin",
          "x": 1710,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "progression de la contamination"
        },
        {
          "id": "hive-set-4",
          "kind": "egg",
          "x": 2130,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "hive-set-5",
          "kind": "cocoon",
          "x": 2550,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "hive-cover1",
          "kind": "machine",
          "x": 1140,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "hive-cover2",
          "kind": "cart",
          "x": 2010,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "pdt",
          "label": "Retrouver la source des signaux",
          "kind": "scan",
          "x": 690,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 10
        },
        {
          "id": "a17",
          "label": "Signaux immobiles",
          "kind": "archive",
          "x": 2460.0,
          "z": 0.43,
          "description": "Plusieurs balises répondent sous le processeur. Aucun déplacement depuis la dernière lecture. Garder une distance avec les parois et ne pas rompre le contact radio."
        }
      ],
      "spawns": [
        {
          "id": "hive-east",
          "x": 2945,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "hive-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "hive-cover1",
          "x": 1140,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "hive-cover2",
          "x": 2010,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "coolant",
      "name": "Galerie du refroidissement",
      "building": "Terraformage",
      "floor": -2,
      "kind": "hive",
      "width": 2700,
      "map": [
        3,
        6
      ],
      "theme": "coolant",
      "landmark": "Passage étroit entre les échangeurs, ruche en arrière-plan",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        64.3,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "coolant>hive",
          "to": "hive",
          "x": 170,
          "z": 0.69,
          "kind": "passerelle",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "coolant>power",
          "to": "power",
          "x": 2530,
          "z": 0.69,
          "kind": "échelle",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "coolant-set-0",
          "kind": "tank",
          "x": 462,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "coolant-set-1",
          "kind": "resin",
          "x": 906,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "progression de la contamination"
        },
        {
          "id": "coolant-set-2",
          "kind": "cocoon",
          "x": 1350,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "coolant-set-3",
          "kind": "tank",
          "x": 1794,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "coolant-set-4",
          "kind": "rib",
          "x": 2238,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "coolant-cover1",
          "kind": "machine",
          "x": 1026,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "coolant-cover2",
          "kind": "cart",
          "x": 1809,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "fallback",
          "label": "Baliser la route de repli",
          "kind": "beacon",
          "x": 621,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 10
        },
        {
          "id": "a18",
          "label": "Aucun trophée",
          "kind": "archive",
          "x": 2214.0,
          "z": 0.43,
          "description": "Repli par le refroidissement. Les lampes portatives indiquent la sortie, pas les embranchements. Si une lampe s’éteint, revenir vers la précédente plutôt que suivre un bruit."
        }
      ],
      "spawns": [
        {
          "id": "coolant-east",
          "x": 2645,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "coolant-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "coolant-cover1",
          "x": 1026,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "coolant-cover2",
          "x": 1809,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "vent_hab",
      "name": "Conduits de l’habitat",
      "building": "Ventilation",
      "floor": 1,
      "kind": "vent",
      "width": 2600,
      "map": [
        4,
        1
      ],
      "theme": "vent",
      "landmark": "Jonctions basses, grilles et câbles de repérage",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "amber",
      "dimensionsM": [
        61.9,
        1.1,
        3.4
      ],
      "portals": [
        {
          "id": "vent_hab>jorden",
          "to": "jorden",
          "x": 170,
          "z": 0.7,
          "kind": "conduit",
          "childOnly": true,
          "requires": null
        },
        {
          "id": "vent_hab>vent_med",
          "to": "vent_med",
          "x": 2430,
          "z": 0.7,
          "kind": "conduit",
          "childOnly": true,
          "requires": null
        },
        {
          "id": "vent_hab>vent_survey",
          "to": "vent_survey",
          "x": 728,
          "z": 0.7,
          "kind": "conduit",
          "childOnly": true,
          "requires": null
        },
        {
          "id": "vent_hab>recreation",
          "to": "recreation",
          "x": 1248,
          "z": 0.7,
          "kind": "grille",
          "childOnly": true,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "vent_hab-set-0",
          "kind": "grille",
          "x": 452,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "vent_hab-set-1",
          "kind": "cable",
          "x": 876,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "vent_hab-set-2",
          "kind": "grille",
          "x": 1300,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "vent_hab-set-3",
          "kind": "fan",
          "x": 1724,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "vent_hab-set-4",
          "kind": "drawing",
          "x": 2148,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "trace de vie familiale"
        }
      ],
      "objects": [
        {
          "id": "marks",
          "label": "Retrouver les repères de Tim",
          "kind": "trace",
          "x": 598,
          "z": 0.7,
          "description": "Le tuyau qui vibre revient vers la cuisine. Celui qui siffle va à l’infirmerie.",
          "chapter": 6
        },
        {
          "id": "route",
          "label": "Vérifier le chemin de retour",
          "kind": "trace",
          "x": 988,
          "z": 0.7,
          "description": "Je suis là. Je suis encore là.",
          "chapter": 15
        }
      ],
      "spawns": [
        {
          "id": "vent_hab-east",
          "x": 2545,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "vent_hab-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "vent_med",
      "name": "Conduits de l’infirmerie",
      "building": "Ventilation",
      "floor": 1,
      "kind": "vent",
      "width": 2400,
      "map": [
        1,
        1
      ],
      "theme": "vent",
      "landmark": "Grilles d’observation et courbe de service",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "cold",
      "dimensionsM": [
        57.1,
        1.1,
        3.4
      ],
      "portals": [
        {
          "id": "vent_med>vent_hab",
          "to": "vent_hab",
          "x": 170,
          "z": 0.7,
          "kind": "conduit",
          "childOnly": true,
          "requires": null
        },
        {
          "id": "vent_med>isolation",
          "to": "isolation",
          "x": 2230,
          "z": 0.7,
          "kind": "grille",
          "childOnly": true,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "vent_med-set-0",
          "kind": "grille",
          "x": 480,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "vent_med-set-1",
          "kind": "cable",
          "x": 960,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "vent_med-set-2",
          "kind": "grille",
          "x": 1440,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "vent_med-set-3",
          "kind": "pipe",
          "x": 1920,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        }
      ],
      "objects": [
        {
          "id": "listen",
          "label": "Écouter derrière la grille",
          "kind": "listen",
          "x": 552,
          "z": 0.7,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 6
        }
      ],
      "spawns": [
        {
          "id": "vent_med-east",
          "x": 2345,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "vent_med-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "vent_survey",
      "name": "Conduits des prospecteurs",
      "building": "Ventilation",
      "floor": 0,
      "kind": "vent",
      "width": 2350,
      "map": [
        5,
        3
      ],
      "theme": "vent",
      "landmark": "Grille de secours au-dessus de la dernière barricade",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "cold",
      "dimensionsM": [
        56.0,
        1.1,
        3.4
      ],
      "portals": [
        {
          "id": "vent_survey>vent_hab",
          "to": "vent_hab",
          "x": 170,
          "z": 0.7,
          "kind": "conduit",
          "childOnly": true,
          "requires": null
        },
        {
          "id": "vent_survey>survey",
          "to": "survey",
          "x": 2180,
          "z": 0.7,
          "kind": "grille",
          "childOnly": true,
          "requires": null
        },
        {
          "id": "vent_survey>refuge",
          "to": "refuge",
          "x": 658,
          "z": 0.7,
          "kind": "conduit",
          "childOnly": true,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "vent_survey-set-0",
          "kind": "grille",
          "x": 474,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "vent_survey-set-1",
          "kind": "cable",
          "x": 941,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "vent_survey-set-2",
          "kind": "grille",
          "x": 1409,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "vent_survey-set-3",
          "kind": "resin",
          "x": 1876,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "progression de la contamination"
        }
      ],
      "objects": [
        {
          "id": "silence",
          "label": "Passer sans attirer la créature",
          "kind": "listen",
          "x": 540,
          "z": 0.7,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 14
        }
      ],
      "spawns": [
        {
          "id": "vent_survey-east",
          "x": 2295,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "vent_survey-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "refuge",
      "name": "Cache des conduits",
      "building": "Ventilation",
      "floor": 0,
      "kind": "vent",
      "width": 1750,
      "map": [
        5,
        2
      ],
      "theme": "refuge",
      "landmark": "Petit renfoncement hors des axes de ventilation",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "amber",
      "dimensionsM": [
        41.7,
        1.1,
        3.4
      ],
      "portals": [
        {
          "id": "refuge>vent_survey",
          "to": "vent_survey",
          "x": 170,
          "z": 0.7,
          "kind": "conduit",
          "childOnly": true,
          "requires": null
        },
        {
          "id": "refuge>wash",
          "to": "wash",
          "x": 1580,
          "z": 0.7,
          "kind": "grille",
          "childOnly": true,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "refuge-set-0",
          "kind": "toy",
          "x": 399,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "refuge-set-1",
          "kind": "blanket",
          "x": 716,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "refuge-set-2",
          "kind": "ration",
          "x": 1034,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "refuge-set-3",
          "kind": "drawing",
          "x": 1351,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "trace de vie familiale"
        }
      ],
      "objects": [
        {
          "id": "cache",
          "label": "Préparer une petite cache",
          "kind": "stash",
          "x": 402,
          "z": 0.7,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 6
        },
        {
          "id": "hide",
          "label": "Regagner la cache",
          "kind": "stash",
          "x": 665,
          "z": 0.7,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 15
        },
        {
          "id": "a21",
          "label": "La petite cache",
          "kind": "archive",
          "x": 1435.0,
          "z": 0.7,
          "description": "La couverture reste au fond. On peut voir le couloir sans coller les yeux à la grille. Quand les pas s’arrêtent, attendre encore. Toujours attendre encore."
        }
      ],
      "spawns": [
        {
          "id": "refuge-east",
          "x": 1695,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "refuge-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "hangar",
      "name": "Hangar scientifique",
      "building": "Recherche",
      "floor": 0,
      "kind": "depth",
      "width": 3300,
      "map": [
        0,
        5
      ],
      "theme": "hangar",
      "landmark": "Navette de service, passerelle et réserves de carburant",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "cold",
      "dimensionsM": [
        78.6,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "hangar>science",
          "to": "science",
          "x": 170,
          "z": 0.69,
          "kind": "sas",
          "childOnly": false,
          "requires": "scienceClearance"
        },
        {
          "id": "hangar>shuttle",
          "to": "shuttle",
          "x": 3130,
          "z": 0.69,
          "kind": "passerelle",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "hangar-set-0",
          "kind": "shuttle",
          "x": 522,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "hangar-set-1",
          "kind": "fuel",
          "x": 1086,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "hangar-set-2",
          "kind": "gantry",
          "x": 1650,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "hangar-set-3",
          "kind": "console",
          "x": 2214,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "poste de travail"
        },
        {
          "id": "hangar-set-4",
          "kind": "pallet",
          "x": 2778,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "hangar-cover1",
          "kind": "machine",
          "x": 1254,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "hangar-cover2",
          "kind": "cart",
          "x": 2211,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "clearance",
          "label": "Déverrouiller la navette scientifique",
          "kind": "terminal",
          "x": 759,
          "z": 0.81,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 12
        },
        {
          "id": "boarding",
          "label": "Vérifier l’embarquement",
          "kind": "talk",
          "x": 1254,
          "z": 0.81,
          "description": "Aucune trajectoire imposée. Nous choisissons où nous allons.",
          "chapter": 13
        },
        {
          "id": "a19",
          "label": "Accès réservé",
          "kind": "archive",
          "x": 2706.0,
          "z": 0.43,
          "description": "Embarquement scientifique réservé. Réservoirs vérifiés. Le code d’accès ne doit pas être communiqué sur le réseau général. Un officier de service conteste la restriction ; demande en attente."
        },
        {
          "id": "cache-hangar",
          "label": "Réserve de terrain",
          "kind": "pickup",
          "x": 1749.0,
          "z": 0.86,
          "description": "Soins et dotation de terrain. Une seule collecte par parcours."
        }
      ],
      "spawns": [
        {
          "id": "hangar-east",
          "x": 3245,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "hangar-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "hangar-cover1",
          "x": 1254,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "hangar-cover2",
          "x": 2211,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "shuttle",
      "name": "Navette de la Compagnie",
      "building": "Recherche",
      "floor": 0,
      "kind": "side",
      "width": 2150,
      "map": [
        0,
        6
      ],
      "theme": "shuttle",
      "landmark": "Sas arrière, sièges et commandes de navigation",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "cold",
      "dimensionsM": [
        51.2,
        2.8,
        3.4
      ],
      "portals": [
        {
          "id": "shuttle>hangar",
          "to": "hangar",
          "x": 170,
          "z": 0.7,
          "kind": "passerelle",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "shuttle-set-0",
          "kind": "seat",
          "x": 407,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "shuttle-set-1",
          "kind": "seat",
          "x": 741,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "shuttle-set-2",
          "kind": "console",
          "x": 1075,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "poste de travail"
        },
        {
          "id": "shuttle-set-3",
          "kind": "screen",
          "x": 1409,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "shuttle-set-4",
          "kind": "hatch",
          "x": 1743,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        }
      ],
      "objects": [
        {
          "id": "autopilot",
          "label": "Désengager la trajectoire automatique",
          "kind": "terminal",
          "x": 494,
          "z": 0.7,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 13
        },
        {
          "id": "departure",
          "label": "Décoller",
          "kind": "launch",
          "x": 817,
          "z": 0.7,
          "description": "Gardez la voie de retour ouverte.",
          "chapter": 13
        },
        {
          "id": "a20",
          "label": "Quatre sièges occupés",
          "kind": "archive",
          "x": 1763.0,
          "z": 0.7,
          "description": "Brackett. Paris. Mori. Luisa. Quatre présences à bord. Le sas est fermé. La liste n’est pas celle que nous espérions remplir."
        }
      ],
      "spawns": [
        {
          "id": "shuttle-east",
          "x": 2095,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "shuttle-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "wash",
      "name": "Buanderie",
      "building": "Habitat",
      "floor": 0,
      "kind": "depth",
      "width": 1850,
      "map": [
        5,
        1
      ],
      "theme": "wash",
      "landmark": "Machines, linge abandonné et évier de service",
      "minZ": 0.25,
      "maxZ": 0.9,
      "light": "amber",
      "dimensionsM": [
        44.0,
        9,
        3.4
      ],
      "portals": [
        {
          "id": "wash>refuge",
          "to": "refuge",
          "x": 170,
          "z": 0.69,
          "kind": "grille",
          "childOnly": true,
          "requires": null
        },
        {
          "id": "wash>mess",
          "to": "mess",
          "x": 1680,
          "z": 0.69,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "wash>hab",
          "to": "hab",
          "x": 518,
          "z": 0.28,
          "kind": "escalier",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "wash-set-0",
          "kind": "washer",
          "x": 377,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "wash-set-1",
          "kind": "washer",
          "x": 651,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "wash-set-2",
          "kind": "linen",
          "x": 925,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "wash-set-3",
          "kind": "sink",
          "x": 1199,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "wash-set-4",
          "kind": "washer",
          "x": 1473,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "wash-cover1",
          "kind": "machine",
          "x": 703,
          "z": 0.56,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        },
        {
          "id": "wash-cover2",
          "kind": "cart",
          "x": 1240,
          "z": 0.57,
          "layer": "ACTORS",
          "collidable": true,
          "purpose": "obstacle contournable et cachette basse"
        }
      ],
      "objects": [
        {
          "id": "water",
          "label": "Récupérer de l’eau",
          "kind": "supply",
          "x": 426,
          "z": 0.81,
          "description": "Pas la grande porte. Jamais la grande porte quand on entend les tuyaux.",
          "chapter": 14
        },
        {
          "id": "a22",
          "label": "L’eau du lendemain",
          "kind": "archive",
          "x": 1517.0,
          "z": 0.43,
          "description": "L’eau coule moins fort à cet évier. Ne pas ouvrir le robinet entièrement. Une bouteille pleine tient dans le passage si on la pousse devant soi."
        }
      ],
      "spawns": [
        {
          "id": "wash-east",
          "x": 1795,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "wash-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [
        {
          "id": "wash-cover1",
          "x": 703,
          "z": 0.56,
          "w": 160,
          "d": 0.13,
          "prop": "machine"
        },
        {
          "id": "wash-cover2",
          "x": 1240,
          "z": 0.57,
          "w": 190,
          "d": 0.14,
          "prop": "cart"
        }
      ],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "relay",
      "name": "Relais de communications",
      "building": "Administration",
      "floor": 1,
      "kind": "side",
      "width": 1950,
      "map": [
        0,
        1
      ],
      "theme": "relay",
      "landmark": "Baie relais et émetteurs directionnels",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "cold",
      "dimensionsM": [
        46.4,
        2.8,
        3.4
      ],
      "portals": [
        {
          "id": "relay>records",
          "to": "records",
          "x": 170,
          "z": 0.7,
          "kind": "coursive",
          "childOnly": false,
          "requires": null
        },
        {
          "id": "relay>ops",
          "to": "ops",
          "x": 1780,
          "z": 0.7,
          "kind": "coursive",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "relay-set-0",
          "kind": "rack",
          "x": 424,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "relay-set-1",
          "kind": "antenna",
          "x": 791,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "relay-set-2",
          "kind": "console",
          "x": 1159,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "poste de travail"
        },
        {
          "id": "relay-set-3",
          "kind": "rack",
          "x": 1526,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        }
      ],
      "objects": [
        {
          "id": "a23",
          "label": "Ligne sans réponse",
          "kind": "archive",
          "x": 1599.0,
          "z": 0.7,
          "description": "Relais alimenté, aucune réponse. Les contrôles locaux sont bons. Répéter l’appel à intervalle court et conserver chaque tentative dans la mémoire de secours."
        }
      ],
      "spawns": [
        {
          "id": "relay-east",
          "x": 1895,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "relay-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    },
    {
      "id": "clinic_store",
      "name": "Réserve médicale",
      "building": "Médical",
      "floor": 0,
      "kind": "side",
      "width": 1700,
      "map": [
        2,
        0
      ],
      "theme": "clinic_store",
      "landmark": "Tiroirs de soins et stockage réfrigéré",
      "minZ": 0.7,
      "maxZ": 0.7,
      "light": "cold",
      "dimensionsM": [
        40.5,
        2.8,
        3.4
      ],
      "portals": [
        {
          "id": "clinic_store>med",
          "to": "med",
          "x": 170,
          "z": 0.7,
          "kind": "porte",
          "childOnly": false,
          "requires": null
        }
      ],
      "props": [
        {
          "id": "clinic_store-set-0",
          "kind": "medicine",
          "x": 392,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "clinic_store-set-1",
          "kind": "shelf",
          "x": 698,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "clinic_store-set-2",
          "kind": "fridge",
          "x": 1002,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        },
        {
          "id": "clinic_store-set-3",
          "kind": "medicine",
          "x": 1308,
          "z": 0.22,
          "layer": "FIXTURES",
          "collidable": false,
          "purpose": "fonction propre au lieu"
        }
      ],
      "objects": [
        {
          "id": "medstock",
          "label": "Prendre les soins d’urgence",
          "kind": "supply",
          "x": 391,
          "z": 0.7,
          "description": "Restez derrière moi. Nous allons jusqu’à la lumière suivante, puis à la suivante.",
          "chapter": 8
        },
        {
          "id": "a24",
          "label": "Dernière réserve",
          "kind": "archive",
          "x": 1394.0,
          "z": 0.7,
          "description": "Dernier relevé des réserves. Les trousses emportées ne seront pas remplacées avant réapprovisionnement. Signaler un tiroir vide au lieu de le refermer comme si de rien n’était."
        },
        {
          "id": "cache-clinic_store",
          "label": "Réserve de terrain",
          "kind": "pickup",
          "x": 901.0,
          "z": 0.7,
          "description": "Soins et dotation de terrain. Une seule collecte par parcours."
        }
      ],
      "spawns": [
        {
          "id": "clinic_store-east",
          "x": 1645,
          "z": 0.72,
          "portal": "maintenance-east"
        },
        {
          "id": "clinic_store-west",
          "x": 55,
          "z": 0.7,
          "portal": "maintenance-west"
        }
      ],
      "cover": [],
      "layerPlan": [
        "HORIZON",
        "SKYLINE",
        "FAR",
        "MID",
        "WALL",
        "FIXTURES",
        "FLOOR",
        "ACTORS",
        "NEAR",
        "FOREGROUND"
      ]
    }
  ],
  "chapters": [
    {
      "id": "rop-01",
      "index": 0,
      "title": "La relève",
      "character": "brackett",
      "start": "pad",
      "phase": 0,
      "objectives": [
        {
          "id": "welcome",
          "room": "pad",
          "label": "Retrouver Paris"
        },
        {
          "id": "brief",
          "room": "ops",
          "label": "Consulter le tableau de service"
        },
        {
          "id": "locker",
          "room": "briefing",
          "label": "Prendre la dotation"
        }
      ],
      "synopsis": "Brackett prend ses fonctions dans une colonie qui ressemble encore à une ville.",
      "dialogue": {
        "speaker": "Paris",
        "text": "Vous verrez la tempête plus souvent que le ciel. Les familles, elles, sont ici toute l’année.",
        "origin": "dialogue_original"
      },
      "timeLabel": "Avant la crise",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-02",
      "index": 1,
      "title": "Les gens d’ici",
      "character": "anne",
      "start": "jorden",
      "phase": 0,
      "objectives": [
        {
          "id": "family",
          "room": "jorden",
          "label": "Préparer la tournée"
        },
        {
          "id": "provisions",
          "room": "mess",
          "label": "Récupérer les provisions"
        },
        {
          "id": "grid",
          "room": "power",
          "label": "Réarmer le départ habitat"
        }
      ],
      "synopsis": "Anne traverse les lieux ordinaires que la crise rendra bientôt méconnaissables.",
      "dialogue": {
        "speaker": "Anne",
        "text": "On peut retarder les relevés. Pas le chauffage du bloc.",
        "origin": "dialogue_original"
      },
      "timeLabel": "Avant la crise",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-03",
      "index": 2,
      "title": "Sous pression",
      "character": "brackett",
      "start": "garage",
      "phase": 0,
      "objectives": [
        {
          "id": "rescue_kit",
          "room": "garage",
          "label": "Prendre le matériel de secours"
        },
        {
          "id": "pressure",
          "room": "processor6",
          "label": "Isoler la conduite endommagée"
        },
        {
          "id": "incident",
          "room": "processor6",
          "label": "Récupérer le rapport d’intervention"
        }
      ],
      "synopsis": "Une intervention industrielle expose les tensions de la garnison. Séquence de jeu condensée autour du processeur six.",
      "dialogue": {
        "speaker": "Paris",
        "text": "Coupez l’arrivée avant de toucher aux vannes. Ici, une mauvaise décision se propage à tout le réseau.",
        "origin": "dialogue_original"
      },
      "timeLabel": "Avant la crise",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-04",
      "index": 3,
      "title": "Les coordonnées",
      "character": "anne",
      "start": "survey",
      "phase": 0,
      "objectives": [
        {
          "id": "coordinates",
          "room": "survey",
          "label": "Recevoir la grille de prospection"
        },
        {
          "id": "tractor",
          "room": "garage",
          "label": "Préparer le tracteur"
        },
        {
          "id": "beacon",
          "room": "plateau",
          "label": "Poser une balise sur le plateau"
        },
        {
          "id": "threshold",
          "room": "derelict",
          "label": "Examiner le seuil de l’épave"
        }
      ],
      "synopsis": "La sortie des Jorden rejoint le lieu désigné par la Compagnie. La découverte de Russ est traitée hors champ.",
      "dialogue": {
        "speaker": "Anne",
        "text": "La radio passe mal. Je laisse une balise : personne ne retrouvera cette passe de nuit.",
        "origin": "dialogue_original"
      },
      "timeLabel": "Avant la crise",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-05",
      "index": 4,
      "title": "La porte blanche",
      "character": "brackett",
      "start": "pad",
      "phase": 1,
      "objectives": [
        {
          "id": "stretcher",
          "room": "pad",
          "label": "Prendre en charge le retour des prospecteurs"
        },
        {
          "id": "quarantine",
          "room": "isolation",
          "label": "Fermer l’isolement médical"
        },
        {
          "id": "triage",
          "room": "med",
          "label": "Transmettre le bilan à Komiskey"
        }
      ],
      "synopsis": "Le retour des prospecteurs met l’infirmerie au centre de toutes les décisions.",
      "dialogue": {
        "speaker": "Komiskey",
        "text": "Gardez le couloir libre. Je veux des gens qui respirent, pas une foule autour du lit.",
        "origin": "dialogue_original"
      },
      "timeLabel": "Premiers incidents",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-06",
      "index": 5,
      "title": "Priorité de recherche",
      "character": "anne",
      "start": "med",
      "phase": 1,
      "objectives": [
        {
          "id": "patient_log",
          "room": "med",
          "label": "Consulter le registre des patients"
        },
        {
          "id": "orders",
          "room": "science",
          "label": "Lire la directive scientifique"
        },
        {
          "id": "copy",
          "room": "records",
          "label": "Conserver une copie des échanges"
        }
      ],
      "synopsis": "Les priorités médicales et celles de la Compagnie divergent.",
      "dialogue": {
        "speaker": "Anne",
        "text": "Ce n’est pas une cargaison. C’est mon mari.",
        "origin": "dialogue_original"
      },
      "timeLabel": "Premiers incidents",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-07",
      "index": 6,
      "title": "Derrière les grilles",
      "character": "newt",
      "start": "jorden",
      "phase": 1,
      "objectives": [
        {
          "id": "marks",
          "room": "vent_hab",
          "label": "Retrouver les repères de Tim"
        },
        {
          "id": "listen",
          "room": "vent_med",
          "label": "Écouter derrière la grille"
        },
        {
          "id": "cache",
          "room": "refuge",
          "label": "Préparer une petite cache"
        }
      ],
      "synopsis": "Les jeux dans les conduits deviennent un apprentissage de la survie. Aucun combat pour Newt.",
      "dialogue": {
        "speaker": "Newt",
        "text": "Le tuyau qui vibre revient vers la cuisine. Celui qui siffle va à l’infirmerie.",
        "origin": "dialogue_original"
      },
      "timeLabel": "Premiers incidents",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-08",
      "index": 7,
      "title": "Les absents",
      "character": "brackett",
      "start": "ops",
      "phase": 2,
      "objectives": [
        {
          "id": "missing",
          "room": "ops",
          "label": "Relever les dernières balises PDT"
        },
        {
          "id": "trail",
          "room": "service",
          "label": "Suivre les traces dans la galerie"
        },
        {
          "id": "reroute",
          "room": "pump",
          "label": "Détourner la pression du passage"
        }
      ],
      "synopsis": "Les disparitions ont désormais une géographie. Les itinéraires sûrs commencent à se refermer.",
      "dialogue": {
        "speaker": "Brackett",
        "text": "On marque chaque porte derrière nous. Je refuse de perdre quelqu’un à un embranchement.",
        "origin": "dialogue_original"
      },
      "timeLabel": "La colonie se ferme",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-09",
      "index": 8,
      "title": "Les lumières rouges",
      "character": "paris",
      "start": "med",
      "phase": 2,
      "objectives": [
        {
          "id": "medstock",
          "room": "clinic_store",
          "label": "Prendre les soins d’urgence"
        },
        {
          "id": "civilian",
          "room": "mess",
          "label": "Accompagner un colon jusqu’au magasin"
        },
        {
          "id": "shelter",
          "room": "stores",
          "label": "Mettre le refuge provisoire sous tension"
        }
      ],
      "synopsis": "Paris maintient une route pour les habitants. L’escorte représente une survie locale, pas une évacuation historique supplémentaire.",
      "dialogue": {
        "speaker": "Paris",
        "text": "Restez derrière moi. Nous allons jusqu’à la lumière suivante, puis à la suivante.",
        "origin": "dialogue_original"
      },
      "timeLabel": "La colonie se ferme",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-10",
      "index": 9,
      "title": "Fermer, tenir",
      "character": "anne",
      "start": "survey",
      "phase": 2,
      "objectives": [
        {
          "id": "welding",
          "room": "stores",
          "label": "Récupérer un poste à souder"
        },
        {
          "id": "barricade",
          "room": "survey",
          "label": "Renforcer la fermeture du bureau"
        },
        {
          "id": "emergency",
          "room": "power",
          "label": "Rétablir le circuit de secours"
        }
      ],
      "synopsis": "Les prospecteurs transforment leurs outils en moyens de défense.",
      "dialogue": {
        "speaker": "Anne",
        "text": "La porte n’a pas besoin de tenir toute la nuit. Seulement assez longtemps pour les enfants.",
        "origin": "dialogue_original"
      },
      "timeLabel": "La colonie se ferme",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-11",
      "index": 10,
      "title": "Sous le processeur",
      "character": "brackett",
      "start": "approach",
      "phase": 3,
      "objectives": [
        {
          "id": "descent",
          "room": "lift",
          "label": "Commander le monte-charge"
        },
        {
          "id": "pdt",
          "room": "hive",
          "label": "Retrouver la source des signaux"
        },
        {
          "id": "fallback",
          "room": "coolant",
          "label": "Baliser la route de repli"
        },
        {
          "id": "withdraw",
          "room": "power",
          "label": "Fermer derrière le groupe"
        }
      ],
      "synopsis": "Le passage dans la ruche est un échec de sauvetage, pas une chasse à la reine.",
      "dialogue": {
        "speaker": "Brackett",
        "text": "N’approchez pas des parois. Repliez-vous par les balises ; ne tirez que pour ouvrir le passage.",
        "origin": "dialogue_original"
      },
      "timeLabel": "La chute",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-12",
      "index": 11,
      "title": "La dernière porte",
      "character": "anne",
      "start": "survey",
      "phase": 3,
      "objectives": [
        {
          "id": "last_power",
          "room": "survey",
          "label": "Alimenter le verrou une dernière fois"
        },
        {
          "id": "vent_open",
          "room": "survey",
          "label": "Dégager l’accès au conduit"
        },
        {
          "id": "newt_escape",
          "room": "survey",
          "label": "Mettre Newt à l’abri"
        }
      ],
      "synopsis": "La défense des Jorden ne change pas leur destin. Le point de vue quitte Anne au moment où Newt passe la grille.",
      "dialogue": {
        "speaker": "Anne",
        "text": "Ne te retourne pas. Compte les virages comme quand vous jouiez.",
        "origin": "dialogue_original"
      },
      "timeLabel": "La chute",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-13",
      "index": 12,
      "title": "Une issue réservée",
      "character": "paris",
      "start": "science",
      "phase": 3,
      "objectives": [
        {
          "id": "hidalgo",
          "room": "science",
          "label": "Recevoir la transmission de Brackett"
        },
        {
          "id": "luisa",
          "room": "survey",
          "label": "Dégager Luisa et la conduire au hangar"
        },
        {
          "id": "clearance",
          "room": "hangar",
          "label": "Déverrouiller la navette scientifique"
        }
      ],
      "synopsis": "Brackett transmet l’indication d’Hidalgo : la Compagnie dispose d’une issue. Luisa suit Paris jusqu’au hangar.",
      "dialogue": {
        "speaker": "Paris",
        "text": "La sortie existe. Nous allons la rendre accessible à ceux qui sont encore avec nous.",
        "origin": "dialogue_original"
      },
      "timeLabel": "La chute",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-14",
      "index": 13,
      "title": "La trajectoire imposée",
      "character": "brackett",
      "start": "hangar",
      "phase": 3,
      "objectives": [
        {
          "id": "boarding",
          "room": "hangar",
          "label": "Vérifier l’embarquement"
        },
        {
          "id": "autopilot",
          "room": "shuttle",
          "label": "Désengager la trajectoire automatique"
        },
        {
          "id": "departure",
          "room": "shuttle",
          "label": "Décoller"
        }
      ],
      "synopsis": "Brackett, Paris, Mori et Luisa quittent la colonie. Newt n’est pas à bord.",
      "dialogue": {
        "speaker": "Brackett",
        "text": "Aucune trajectoire imposée. Nous choisissons où nous allons.",
        "origin": "dialogue_original"
      },
      "timeLabel": "La chute",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-15",
      "index": 14,
      "title": "Il reste quelqu’un",
      "character": "newt",
      "start": "refuge",
      "phase": 3,
      "objectives": [
        {
          "id": "water",
          "room": "wash",
          "label": "Récupérer de l’eau"
        },
        {
          "id": "ration",
          "room": "mess",
          "label": "Trouver de quoi manger"
        },
        {
          "id": "silence",
          "room": "vent_survey",
          "label": "Passer sans attirer la créature"
        }
      ],
      "synopsis": "Le point de vue revient dans les conduits. Il faut survivre avec presque rien.",
      "dialogue": {
        "speaker": "Newt",
        "text": "Pas la grande porte. Jamais la grande porte quand on entend les tuyaux.",
        "origin": "dialogue_original"
      },
      "timeLabel": "La chute",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    },
    {
      "id": "rop-16",
      "index": 15,
      "title": "Jusqu’au prochain bruit",
      "character": "newt",
      "start": "refuge",
      "phase": 3,
      "objectives": [
        {
          "id": "route",
          "room": "vent_hab",
          "label": "Vérifier le chemin de retour"
        },
        {
          "id": "hide",
          "room": "refuge",
          "label": "Regagner la cache"
        }
      ],
      "synopsis": "La cache devient le dernier lieu habité du parcours. La suite appartient à l’arrivée du Sulaco.",
      "dialogue": {
        "speaker": "Newt",
        "text": "Je suis là. Je suis encore là.",
        "origin": "dialogue_original"
      },
      "timeLabel": "La chute",
      "provenance": "condensation_originale_appuyee_sur_synopsis_publics",
      "originalObjectives": true,
      "fidelity": "premise_and_selected_events_not_scene_by_scene"
    }
  ],
  "characters": {
    "brackett": {
      "name": "Demian Brackett",
      "role": "Capitaine · garnison coloniale",
      "height": 76,
      "weapon": "M41A",
      "clip": 30,
      "reserve": 90,
      "medkits": 2,
      "flares": 3,
      "color": "#8c9875",
      "child": false
    },
    "paris": {
      "name": "Julisa Paris",
      "role": "Marine · garnison coloniale",
      "height": 73,
      "weapon": "M41A",
      "clip": 30,
      "reserve": 75,
      "medkits": 3,
      "flares": 3,
      "color": "#8c9f99",
      "child": false
    },
    "anne": {
      "name": "Anne Jorden",
      "role": "Prospectrice · Hadley’s Hope",
      "height": 71,
      "weapon": null,
      "clip": 0,
      "reserve": 0,
      "medkits": 2,
      "flares": 4,
      "color": "#b39366",
      "child": false
    },
    "newt": {
      "name": "Rebecca « Newt » Jorden",
      "role": "Habitat · conduits",
      "height": 44,
      "weapon": null,
      "clip": 0,
      "reserve": 0,
      "medkits": 0,
      "flares": 0,
      "color": "#b49a7b",
      "child": true
    }
  },
  "archives": [
    {
      "id": "a01",
      "title": "Bordereau d’arrivée",
      "text": "Bienvenue à Hadley’s Hope. Les nouveaux arrivants doivent se présenter au contrôle colonial avant l’attribution des logements. Ne laissez pas de bagages dans le sas : les équipes de nuit y font passer le matériel lourd.",
      "room": "pad",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a02",
      "title": "Grille de prospection",
      "text": "Secteur de relevé ajouté à la tournée des Jorden. Coordonnées transmises par liaison Compagnie. Priorité haute. L’équipe de prospection demande une raison ; aucune précision reçue à ce jour.",
      "room": "ops",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a03",
      "title": "Ordre du jour",
      "text": "Relève du poste central à six heures. Révision des joints du garage reportée. Les patrouilles devront signaler toute conduite qui siffle : le processeur six nous a déjà coûté assez de sommeil.",
      "room": "briefing",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a04",
      "title": "Une table pour quatre",
      "text": "Anne — Il reste des provisions au réfectoire. Tim a encore déplacé ses affaires dans les conduits. J’ai remis la petite couverture sur le lit de Becky. On rentrera avant que le chauffage recommence à faire du bruit.",
      "room": "jorden",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a05",
      "title": "Les chemins de Tim",
      "text": "Après la grille qui vibre, tourner à gauche. Ne pas poser le pied sur la plaque claire. Elle résonne jusque dans le couloir. Tim dit qu’il connaît un chemin encore plus court.",
      "room": "recreation",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a06",
      "title": "Priorité médicale",
      "text": "Couloir médical dégagé en permanence. Un seul membre de la famille admis auprès des patients. Les demandes de transfert vers le laboratoire doivent être validées par le personnel soignant.",
      "room": "med",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a07",
      "title": "Le hublot",
      "text": "L’isolement reste fermé. La vitre ne doit pas être ouverte pour faciliter une observation. Toute intervention sur le patient nécessite deux personnes et un accès libre au sas.",
      "room": "isolation",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a08",
      "title": "Mainmise",
      "text": "L’échantillon doit demeurer sur place. Les résultats d’observation passent par le canal scientifique avant toute transmission extérieure. Les urgences médicales ne dispensent pas de renseigner la chaîne de possession.",
      "room": "science",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a09",
      "title": "Transmission conservée",
      "text": "Copie locale créée. Si la liaison est coupée, garder les bandes hors de la baie principale. La suppression d’un message ne doit pas supprimer la preuve qu’il a été reçu.",
      "room": "records",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a10",
      "title": "Tracteur des prospecteurs",
      "text": "Le tracteur revient couvert d’une poussière que les filtres n’arrêtent pas correctement. Vérifier les joints avant toute autre sortie. Ne pas déposer les bottes de prospection dans les casiers propres.",
      "room": "garage",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a11",
      "title": "Un bureau transformé",
      "text": "Des familles attendent près des cartes. Elles veulent savoir quel bâtiment tient encore. Ne pas donner une destination tant qu’une patrouille n’a pas confirmé le passage.",
      "room": "survey",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a12",
      "title": "Refuge provisoire",
      "text": "Le fret peut attendre. Dégager deux allées jusqu’à la porte et réserver les couvertures aux enfants. Les caisses contre le mur ne seront ouvertes qu’en présence d’un responsable.",
      "room": "stores",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a13",
      "title": "Deux circuits",
      "text": "Les départs habitat et médical partagent encore un relais. En cas de surcharge, couper les appareils non essentiels avant de réarmer. Un deuxième claquement signifie qu’il faut laisser le coupe-circuit ouvert.",
      "room": "power",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a14",
      "title": "Sous les logements",
      "text": "La vanne de retour résiste à froid. Ne pas la forcer tant que le manomètre indique une différence de pression. On a besoin d’eau, pas d’une galerie noyée.",
      "room": "pump",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a15",
      "title": "Intervention interrompue",
      "text": "Balisage incomplet sur la piste. Rester du même côté des piquets au retour. La tempête efface les traces de roues en quelques minutes.",
      "room": "processor6",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a16",
      "title": "Une coque étrangère",
      "text": "Le métal n’a pas la couleur du métal. Les arches se poursuivent au-delà du faisceau et la radio ne tient plus. Balise posée près du seuil. Ne pas déplacer le tracteur sans prévenir.",
      "room": "derelict",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a17",
      "title": "Signaux immobiles",
      "text": "Plusieurs balises répondent sous le processeur. Aucun déplacement depuis la dernière lecture. Garder une distance avec les parois et ne pas rompre le contact radio.",
      "room": "hive",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a18",
      "title": "Aucun trophée",
      "text": "Repli par le refroidissement. Les lampes portatives indiquent la sortie, pas les embranchements. Si une lampe s’éteint, revenir vers la précédente plutôt que suivre un bruit.",
      "room": "coolant",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a19",
      "title": "Accès réservé",
      "text": "Embarquement scientifique réservé. Réservoirs vérifiés. Le code d’accès ne doit pas être communiqué sur le réseau général. Un officier de service conteste la restriction ; demande en attente.",
      "room": "hangar",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a20",
      "title": "Quatre sièges occupés",
      "text": "Brackett. Paris. Mori. Luisa. Quatre présences à bord. Le sas est fermé. La liste n’est pas celle que nous espérions remplir.",
      "room": "shuttle",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a21",
      "title": "La petite cache",
      "text": "La couverture reste au fond. On peut voir le couloir sans coller les yeux à la grille. Quand les pas s’arrêtent, attendre encore. Toujours attendre encore.",
      "room": "refuge",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a22",
      "title": "L’eau du lendemain",
      "text": "L’eau coule moins fort à cet évier. Ne pas ouvrir le robinet entièrement. Une bouteille pleine tient dans le passage si on la pousse devant soi.",
      "room": "wash",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a23",
      "title": "Ligne sans réponse",
      "text": "Relais alimenté, aucune réponse. Les contrôles locaux sont bons. Répéter l’appel à intervalle court et conserver chaque tentative dans la mémoire de secours.",
      "room": "relay",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    },
    {
      "id": "a24",
      "title": "Dernière réserve",
      "text": "Dernier relevé des réserves. Les trousses emportées ne seront pas remplacées avant réapprovisionnement. Signaler un tiroir vide au lieu de le refermer comme si de rien n’était.",
      "room": "clinic_store",
      "origin": "texte_original_de_codex",
      "sourceStatus": "interpretation_de_game_design"
    }
  ],
  "sources": [
    {
      "id": "S1",
      "title": "Titan Books — Alien: River of Pain",
      "url": "https://titanbooks.com/6486-alien-river-of-pain-book-3/",
      "type": "editeur",
      "use": "Auteur, prémisse, colonie, famille Jorden, garnison, épave"
    },
    {
      "id": "S2",
      "title": "Audible France — ALIEN Audible Original",
      "url": "https://www.audible.fr/series/ALIEN-Audible-Original-Livres-Audio/B07MXJYR1P",
      "type": "editeur_audio",
      "use": "Titre français Le Fleuve des souffrances ; distinguer adaptation sonore et roman"
    },
    {
      "id": "S3",
      "title": "Christopher Golden — entretien AvPGalaxy",
      "url": "https://www.avpgalaxy.net/website/interviews/christopher-golden/",
      "type": "entretien_auteur",
      "use": "Intention de prélude à Aliens et liens avec les récits préexistants"
    },
    {
      "id": "S4",
      "title": "AvP Central — Demian Brackett",
      "url": "https://www.avpcentral.com/demian-brackett",
      "type": "source_secondaire",
      "use": "Brackett, Paris, Mori, Luisa ; issue distincte du sort de Newt, navette distincte de l’Onager ; à recouper sur le roman intégral"
    },
    {
      "id": "S5",
      "title": "AvP Central — Hadley’s Hope colonists",
      "url": "https://www.avpcentral.com/hadleys-hope-colonists",
      "type": "source_secondaire",
      "use": "Identification des personnages secondaires ; ne pas fusionner médecins et Draper de continuités différentes"
    }
  ]
};
if(typeof module!=="undefined" && module.exports)module.exports=data;
root.ROP_DATA=data;
})(typeof globalThis!=="undefined"?globalThis:this);
