/* River of Pain — deterministic simulation, no DOM or host-game save dependencies. */
(function(root){
'use strict';
const D=root.ROP_DATA || (typeof require==='function'?require('./data.js'):null);
const rooms=new Map(D.rooms.map(r=>[r.id,r]));
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const clone=o=>JSON.parse(JSON.stringify(o));
const dist=(a,b)=>Math.hypot(a.x-b.x,(a.z-b.z)*600);
const pair=(a,b)=>[a,b].sort().join('|');
const finite=n=>typeof n==='number'&&Number.isFinite(n);
const armed=c=>Boolean(D.characters[c].weapon);
const settings={story:{damage:.5,enemySpeed:.74,notice:.8},standard:{damage:1,enemySpeed:1,notice:1},nightmare:{damage:1.35,enemySpeed:1.16,notice:1.18}};
function roomDef(id){return rooms.get(id);}
function allowedPortal(portal,state){return (!portal.childOnly||D.characters[state.character].child)&&(!portal.requires||state.flags[portal.requires]);}
function route(from,to,character,flags={}){
  if(from===to)return [from];const visited=new Set([from]), queue=[[from]];
  while(queue.length){const path=queue.shift(), r=rooms.get(path[path.length-1]);if(!r)continue;
    for(const p of r.portals){if(p.childOnly&&!D.characters[character].child||p.requires&&!flags[p.requires]||visited.has(p.to))continue;
      const n=[...path,p.to];if(p.to===to)return n;visited.add(p.to);queue.push(n);}}
  return [];
}
function obstacleAt(r,x,z,radius=16,mode='hybrid'){
  if(x<38||x>r.width-38)return true;
  if(z<r.minZ-.002||z>r.maxZ+.002)return true;
  return r.cover.some(c=>Math.abs(x-c.x)<c.w/2+radius && Math.abs(z-c.z)<c.d/2+radius/700);
}
function lineBlocked(r,a,b){
  const steps=Math.max(2,Math.ceil(dist(a,b)/22));
  for(let i=1;i<steps;i++){const t=i/steps,x=a.x+(b.x-a.x)*t,z=a.z+(b.z-a.z)*t;if(r.cover.some(c=>Math.abs(x-c.x)<c.w/2&&Math.abs(z-c.z)<c.d/2))return true;}return false;
}
// Small graph search for agents in the playable floor plane, independent of artwork.
function localPath(r,a,b,mode='hybrid'){
  if(!lineBlocked(r,a,b))return [clone(b)];
  const step=90,zStep=.08, min=r.minZ, cols=Math.ceil(r.width/step), rows=Math.max(1,Math.ceil((r.maxZ-min)/zStep)+1);
  const cell=o=>[clamp(Math.round(o.x/step),1,cols-1),clamp(Math.round((o.z-min)/zStep),0,rows-1)];
  const point=(x,z)=>({x:clamp(x*step,45,r.width-45),z:clamp(min+z*zStep,r.minZ,r.maxZ)});
  const start=cell(a),end=cell(b),id=(x,z)=>x+','+z; const q=[start], seen=new Map([[id(...start),null]]);let found=null;
  while(q.length){const c=q.shift();if(Math.abs(c[0]-end[0])<=1&&Math.abs(c[1]-end[1])<=1){found=c;break;}
    for(const [dx,dz] of [[-1,0],[1,0],[0,-1],[0,1]]){const x=c[0]+dx,z=c[1]+dz,k=id(x,z);if(x<1||x>=cols||z<0||z>=rows||seen.has(k))continue;
      const p=point(x,z);if(obstacleAt(r,p.x,p.z,18,mode))continue;seen.set(k,c);q.push([x,z]);}}
  if(!found)return [];
  const path=[clone(b)];let c=found;while(c){path.push(point(...c));c=seen.get(id(...c));}path.reverse();if(path.length>1)path.shift();return path;
}
function createState(difficulty='standard',mode='hybrid'){
 const chapter=D.chapters[0], p=D.characters[chapter.character];return {schema:1,version:D.manifest.version,chapter:0,objective:0,character:chapter.character,room:chapter.start,
  phase:0,mode:mode==='classic'?'classic':'hybrid',difficulty:settings[difficulty]?difficulty:'standard',status:'playing',elapsed:0,
  player:{x:330,z:.7,hp:100,stamina:100,facing:1,crouch:false,noise:0,hurt:0,walk:0,ammo:p.clip,reserve:p.reserve,medkits:p.medkits,flares:p.flares,reload:0},
  world:{},pursuers:[],flags:{},archives:[],collected:[],visited:[chapter.start],doors:{},escort:null,work:null,
  stats:{shots:0,shotsHit:0,kills:0,hits:0,deaths:0,temporaryShelters:0,escorts:0,chapters:[]},log:[],power:0,finished:false};
}
function validateState(s){
 if(!s||typeof s!=='object'||Array.isArray(s)||s.schema!==1)throw Error('Format de sauvegarde incompatible.');
 if(!Number.isInteger(s.chapter)||s.chapter<0||s.chapter>=D.chapters.length)throw Error('Chapitre invalide.');
 if(!rooms.has(s.room)||!D.characters[s.character]||s.character!==D.chapters[s.chapter].character)throw Error('Lieu ou personnage invalide.');
 if(!Number.isInteger(s.objective)||s.objective<0||s.objective>D.chapters[s.chapter].objectives.length)throw Error('Progression invalide.');
 if(!['playing','chapterDone','dead','complete'].includes(s.status)||!settings[s.difficulty]||!['hybrid','classic'].includes(s.mode))throw Error('État de partie invalide.');
 if(!finite(s.elapsed)||s.elapsed<0||s.elapsed>1e9||!Number.isInteger(s.phase)||s.phase<0||s.phase>3)throw Error('Chronologie invalide.');
 const p=s.player,r=rooms.get(s.room);if(!p||!finite(p.x)||p.x<0||p.x>r.width||!finite(p.z)||p.z<0||p.z>1)throw Error('Position invalide.');
 for(const k of ['hp','stamina','ammo','reserve','medkits','flares','noise','hurt','walk','reload'])if(!finite(p[k])||p[k]<0||p[k]>100000)throw Error('Valeur de personnage invalide : '+k);
 if(p.hp>100||p.stamina>100||![-1,1].includes(p.facing)||typeof p.crouch!=='boolean')throw Error('État du personnage invalide.');
 if(typeof s.finished!=='boolean'||!finite(s.power)||s.power<0||s.power>100)throw Error('Systèmes de colonie invalides.');
 if(!Array.isArray(s.pursuers))s.pursuers=[];
 if(s.pursuers.length>16||s.pursuers.some(v=>!v||!rooms.has(v.from)||!rooms.has(v.to)||!finite(v.delay)||v.delay<0||v.delay>30||!v.enemy||!['adult','facehugger'].includes(v.enemy.kind)||!finite(v.enemy.hp)||v.enemy.hp<=0||v.enemy.hp>300))throw Error('Poursuite invalide.');
 for(const v of s.pursuers){v.enemy.path=[];if(!rooms.get(v.from).portals.some(p=>p.to===v.to&&!p.childOnly))throw Error('Passage de poursuite invalide.');}
 if(!s.world||typeof s.world!=='object'||Array.isArray(s.world)||Object.keys(s.world).length>36)throw Error('Monde invalide.');
 for(const [rid,v] of Object.entries(s.world)){
  const rr=rooms.get(rid);if(!rr||!v||!Array.isArray(v.enemies)||v.enemies.length>12||!Array.isArray(v.acid)||v.acid.length>24||!Array.isArray(v.flares)||v.flares.length>12)throw Error('État de salle invalide.');
  for(const e of v.enemies){if(!e||!finite(e.x)||e.x<0||e.x>rr.width||!finite(e.z)||e.z<0||e.z>1||!finite(e.hp)||e.hp<0||e.hp>300||!['adult','facehugger'].includes(e.kind)||!['patrol','search','chase','windup','retreat','dead'].includes(e.state))throw Error('Créature invalide.');
   for(const k of ['cooldown','notice','windup','repath','timer'])if(!finite(e[k])||e[k]<0||e[k]>100000)throw Error('Minuterie de créature invalide.'); e.path=[];}
  for(const e of [...v.acid,...v.flares])if(!finite(e.x)||!finite(e.z)||!finite(e.ttl)||e.ttl<0||e.ttl>60)throw Error('Danger invalide.');
  if(!finite(v.spawnPhase)||v.spawnPhase<0||v.spawnPhase>3)throw Error('Phase de salle invalide.');
 }
 for(const key of ['archives','collected','visited'])if(!Array.isArray(s[key])||s[key].length>400||s[key].some(x=>typeof x!=='string'||x.length>100))throw Error('Inventaire de progression invalide.');
 if(s.archives.some(x=>!D.archives.some(a=>a.id===x))||s.visited.some(x=>!rooms.has(x)))throw Error('Archive ou lieu inconnu.');
 const objIds=new Set(D.rooms.flatMap(r=>r.objects.map(o=>o.id)));if(s.collected.some(x=>!objIds.has(x)))throw Error('Objet inconnu.');
 if(!s.flags||typeof s.flags!=='object'||Array.isArray(s.flags)||Object.entries(s.flags).some(([k,v])=>k==='__proto__'||k==='constructor'||k.length>80||typeof v!=='boolean'))throw Error('Marqueur invalide.');
 const allPairs=new Set(D.rooms.flatMap(r=>r.portals.map(p=>pair(r.id,p.to))));
 if(!s.doors||typeof s.doors!=='object'||Object.entries(s.doors).some(([k,v])=>!allPairs.has(k)||!['open','sealed'].includes(v)))throw Error('Porte invalide.');
 if(s.escort&&(!rooms.has(s.escort.room)||!rooms.has(s.escort.goal)||!finite(s.escort.x)||!finite(s.escort.z)||typeof s.escort.name!=='string'||s.escort.name.length>70))throw Error('Escorte invalide.');
 if(s.escort)s.escort.path=[];
 if(!s.stats||!Array.isArray(s.stats.chapters)||s.stats.chapters.some(x=>!Number.isInteger(x)||x<0||x>=16))throw Error('Statistiques invalides.');
 for(const k of ['shots','shotsHit','kills','hits','deaths','temporaryShelters','escorts'])if(!Number.isInteger(s.stats[k])||s.stats[k]<0||s.stats[k]>1e8)throw Error('Statistique invalide.');
 if(!Array.isArray(s.log)||s.log.length>80||s.log.some(x=>typeof x!=='string'||x.length>500))throw Error('Journal invalide.');
 s.work=null;p.hurt=0;return s;
}
function parseSave(text){
 if(typeof text!=='string'||text.length>1024*1024)throw Error('Fichier de sauvegarde trop volumineux.');
 const envelope=JSON.parse(text);if(envelope.id!=='river-of-pain'||envelope.schema!==1)throw Error('Ce fichier ne correspond pas à Hadley’s Hope.');
 validateState(envelope.state);if(envelope.checkpoint)validateState(envelope.checkpoint);return envelope;
}
class Simulation{
 constructor(state=createState()){this.s=validateState(clone(state));this.events=[];this.bullets=[];this.particles=[];this.cooldown=0;this.portalCooldown=0;this.checkpoint=clone(this.s);this.ensureRoom();}
 emit(type,detail={}){this.events.push({type,...detail});}
 notify(text){this.s.log.unshift(text);this.s.log=this.s.log.slice(0,60);this.emit('notice',{text});}
 get room(){return rooms.get(this.s.room);}
 get chapter(){return D.chapters[this.s.chapter];}
 get objective(){return this.chapter.objectives[this.s.objective]||null;}
 get character(){return D.characters[this.s.character];}
 ensureRoom(){
  const s=this.s,r=this.room; if(!s.world[r.id])s.world[r.id]={enemies:[],acid:[],flares:[],spawnPhase:0};
  const w=s.world[r.id];const threat=['service','pump','stores','power','med','science','hive','coolant','survey','hangar','wash','mess','concourse','road'];
  if(s.phase>=2&&w.spawnPhase<s.phase&&threat.includes(r.id)){
   const count=r.kind==='hive'?2:1;
   for(let i=0;i<count;i++){
    const anchor=r.spawns[i]; if(dist(anchor,s.player)<480)continue;
    const kind=(r.id==='med'||r.id==='wash')?'facehugger':'adult';
    w.enemies.push({id:r.id+'-'+s.phase+'-'+i,x:anchor.x,z:s.mode==='classic'?.7:anchor.z,hp:kind==='adult'?72:24,kind,
     state:'patrol',facing:i?1:-1,notice:0,cooldown:0,windup:0,repath:0,path:[],timer:0,origin:{x:anchor.x,z:anchor.z}});
   }
   w.spawnPhase=s.phase;
  }
  return w;
 }
 move(body,dx,dz,speed,dt){
  const r=this.room;if(r.minZ===r.maxZ||this.s.mode==='classic')dz=0;
  const mag=Math.hypot(dx,dz);if(mag>1){dx/=mag;dz/=mag;}
  const nx=clamp(body.x+dx*speed*dt,42,r.width-42),nz=clamp(body.z+dz*speed*dt/600,r.minZ,r.maxZ);
  if(!obstacleAt(r,nx,body.z,14,this.s.mode))body.x=nx;
  if(!obstacleAt(r,body.x,nz,14,this.s.mode))body.z=nz;
 }
 near(a,b,threshold=96){return Math.abs(a.x-b.x)<threshold&&(this.s.mode==='classic'||Math.abs(a.z-b.z)<.14);}
 candidates(){
  const s=this.s,p=s.player,r=this.room;if(s.status!=='playing')return [];
  const out=[];
  for(const o of r.objects){
   if(o.chapter!==undefined&&(o.chapter!==s.chapter||o.id!==this.objective?.id))continue;
   if(s.collected.includes(o.id)||o.kind==='archive'&&s.archives.includes(o.id))continue;
   if(s.escort&&o.id===s.escort.task)continue;
   if(this.near(p,o,105))out.push({type:'object',ref:o,priority:o.chapter!==undefined?0:o.kind==='archive'?1:2,label:o.label});
  }
  for(const v of r.portals)if(this.near(p,v,90)){
   const blocked=v.childOnly&&!this.character.child;
   const locked=v.requires&&!s.flags[v.requires];const sealed=s.doors[pair(r.id,v.to)]==='sealed';
   out.push({type:'portal',ref:v,priority:3,label:blocked?'Conduit trop étroit':locked?'Accès scientifique verrouillé':sealed?'Désouder · '+rooms.get(v.to).name:rooms.get(v.to).name,blocked,locked,sealed});
  }
  return out.sort((a,b)=>a.priority-b.priority||dist(p,a.ref)-dist(p,b.ref));
 }
 interact(){
  if(this.s.status!=='playing'||this.s.work||this.portalCooldown>0)return;
  const c=this.candidates()[0];if(!c){this.notify('Approchez-vous d’une porte, d’un poste ou d’un objet.');return;}
  if(c.type==='portal'){
   if(c.blocked){this.notify('Ce conduit ne laisse passer qu’un enfant.');return;}
   if(c.locked){this.notify('La Compagnie a réservé cet accès. Il faut obtenir l’autorisation.');return;}
   if(c.sealed){this.s.work={kind:'unseal',id:pair(this.s.room,c.ref.to),timer:0,duration:1.25,x:this.s.player.x,z:this.s.player.z};return;}
   this.enter(c.ref);return;
  }
  const o=c.ref;
  if(o.kind==='archive'){
   this.s.archives.push(o.id);this.emit('archive',{id:o.id});this.notify('Document conservé : '+o.label);this.emit('save');return;
  }
  if(o.kind==='pickup'){
   this.s.collected.push(o.id);if(armed(this.s.character)){this.s.player.reserve+=30;this.s.player.medkits++;}else if(!this.character.child){this.s.player.medkits++;this.s.player.flares++;}else this.s.player.hp=clamp(this.s.player.hp+15,0,100);
   this.notify('Réserve récupérée.');this.emit('save');return;
  }
  if(o.kind==='escort'){
   if(o.grantFlag)this.s.flags[o.grantFlag]=true;
   this.s.escort={name:o.escortName,room:this.s.room,x:o.x-60,z:o.z,goal:o.escortTo,task:o.id,path:[],repath:0,walk:0};
   this.notify(o.escortName+' vous suit. Destination : '+rooms.get(o.escortTo).name+'.');this.emit('save');return;
  }
  this.s.work={kind:'task',id:o.id,timer:0,duration:['power','seal','valve'].includes(o.kind)?2.2:.9,x:this.s.player.x,z:this.s.player.z};
 }
 enter(portal){
  const s=this.s;if(!allowedPortal(portal,s)||s.doors[pair(s.room,portal.to)]==='sealed')return false;
  if(s.escort&&s.escort.room===s.room&&dist(s.escort,s.player)>210){this.notify('Votre compagnon doit vous rejoindre avant de passer.');return false;}
  const old=s.room, oldWorld=this.ensureRoom(), dest=rooms.get(portal.to),back=dest.portals.find(p=>p.to===old);if(!back)return false;
  if(!portal.childOnly&&dest.kind!=='vent'){
   const chasers=oldWorld.enemies.filter(e=>e.hp>0&&e.notice>.52&&dist(e,s.player)<950).slice(0,2);
   for(const e of chasers){if(s.pursuers.length<16){s.pursuers.push({from:old,to:dest.id,delay:2.5,enemy:clone(e)});oldWorld.enemies=oldWorld.enemies.filter(v=>v.id!==e.id);}}
   if(chasers.length)this.notify('Du mouvement derrière la porte. Ne restez pas au seuil.');
  }
  s.room=dest.id; s.player.x=clamp(back.x+(back.x<dest.width/2?75:-75),45,dest.width-45);
  s.player.z=s.mode==='classic'?.7:clamp(back.z,dest.minZ,dest.maxZ);
  if(obstacleAt(dest,s.player.x,s.player.z)){s.player.x=back.x;s.player.z=clamp(back.z,dest.minZ,dest.maxZ);}
  if(s.escort){s.escort.room=dest.id;s.escort.x=s.player.x+(s.player.x<dest.width/2?-45:45);s.escort.z=s.player.z;s.escort.path=[];}
  if(!s.visited.includes(dest.id))s.visited.push(dest.id);
  s.work=null;this.bullets=[];this.portalCooldown=.7;this.ensureRoom();this.emit('room',{from:old,to:dest.id,kind:portal.kind});this.emit('save');return true;
 }
 toggleDoor(){if(this.s.work||this.s.status!=='playing')return;const c=this.candidates().find(c=>c.type==='portal'&&!c.blocked&&!c.locked);if(!c)return;
  if(!this.s.flags.welder){this.notify('Il faut un poste à souder.');return;}
  const k=pair(this.s.room,c.ref.to);this.s.work={kind:this.s.doors[k]==='sealed'?'unseal':'weld',id:k,timer:0,duration:1.25,x:this.s.player.x,z:this.s.player.z};}
 completeTask(id){
  const s=this.s,t=this.objective;if(!t||t.id!==id)return false;
  const o=rooms.get(t.room).objects.find(o=>o.id===id);if(o.grantFlag)s.flags[o.grantFlag]=true;
  if(o.kind==='power'){s.power++;s.flags[id]=true;}
  if(o.kind==='seal')s.flags['reinforced-'+t.room]=true;
  if(id==='welding')s.flags.welder=true;
  if(id==='shelter')s.stats.temporaryShelters++;
  if(id==='newt_escape')s.flags.newtInVents=true;
  if(id==='departure')s.flags.fourDeparted=true;
  if(id==='locker'){s.player.ammo=30;s.player.reserve=90;}
  s.collected.push(id);s.objective++;this.notify('Objectif accompli · '+o.label);this.emit('objective',{id});
  if(s.objective===this.chapter.objectives.length){s.stats.chapters.push(s.chapter);s.status=s.chapter===D.chapters.length-1?'complete':'chapterDone';
   if(s.status==='complete'){s.finished=true;this.emit('complete');}else this.emit('chapterDone');}
  this.emit('save');return true;
 }
 nextChapter(){
  const s=this.s;if(s.status!=='chapterDone')return false;
  const from=s.character;s.chapter++;s.objective=0;const c=this.chapter;
  s.character=c.character;s.room=c.start;s.phase=c.phase;s.status='playing';s.work=null;s.escort=null;
  const def=this.character; const last={...s.player};
  s.player={x:330,z:.7,hp:Math.max(last.hp,70),stamina:100,facing:1,crouch:false,noise:0,hurt:0,walk:0,ammo:def.clip,reserve:def.reserve,medkits:def.medkits,flares:def.flares,reload:0};
  if(from===s.character){s.player.ammo=last.ammo;s.player.reserve=last.reserve;s.player.medkits=last.medkits;s.player.flares=last.flares;}
  if(!s.visited.includes(s.room))s.visited.push(s.room);this.bullets=[];this.ensureRoom();this.checkpoint=clone(s);this.emit('chapter',{index:s.chapter});this.emit('save');return true;
 }
 retry(){const deaths=this.s.stats.deaths+1;this.s=clone(this.checkpoint);this.s.stats.deaths=deaths;this.s.status='playing';this.s.work=null;this.bullets=[];this.events=[];this.ensureRoom();this.emit('room',{to:this.s.room});this.emit('save');}
 setMode(mode){if(!['classic','hybrid'].includes(mode))return;this.s.mode=mode;
  if(mode==='classic'){this.s.player.z=.7;if(this.s.escort)this.s.escort.z=.7;for(const w of Object.values(this.s.world))for(const e of w.enemies)e.z=.7;}
  else this.s.player.z=clamp(this.s.player.z,this.room.minZ,this.room.maxZ);
  this.bullets=[];this.s.work=null;this.emit('save');}
 fire(){const s=this.s,p=s.player;if(s.status!=='playing'||!armed(s.character)||p.reload>0||this.cooldown>0||s.work)return false;
  if(p.ammo<=0){this.reload();return false;}p.ammo--;p.noise=1;s.stats.shots++;this.cooldown=.17;
  this.bullets.push({x:p.x+p.facing*31,z:p.z,dir:p.facing,ttl:.8,previous:p.x,damage:26});this.emit('shot');return true;}
 reload(){const p=this.s.player;if(!armed(this.s.character)||p.reload||p.ammo>=30||p.reserve<=0)return false;p.reload=1.7;this.emit('reload');return true;}
 heal(){const p=this.s.player;if(this.s.status!=='playing'||p.medkits<=0||p.hp>=100)return false;p.medkits--;p.hp=clamp(p.hp+40,0,100);this.emit('save');this.notify('Soin appliqué.');return true;}
 flare(){const s=this.s,p=s.player;if(s.status!=='playing'||p.flares<=0||this.character.child)return false;
  p.flares--;this.ensureRoom().flares.push({x:clamp(p.x+p.facing*150,45,this.room.width-45),z:p.z,ttl:18});p.noise=.65;this.emit('flare');this.emit('save');return true;}
 hit(damage){const s=this.s,p=s.player;if(p.hurt>0||s.status!=='playing')return;p.hp=clamp(p.hp-damage*settings[s.difficulty].damage,0,100);p.hurt=1.1;s.stats.hits++;s.work=null;this.emit('hit');
  if(p.hp<=0){s.status='dead';this.emit('dead');}}
 update(dt,input={}){
  dt=clamp(dt,0,1/20);const s=this.s;if(s.status!=='playing')return;
  const p=s.player,r=this.room,w=this.ensureRoom(),tune=settings[s.difficulty];s.elapsed+=dt;this.cooldown=Math.max(0,this.cooldown-dt);this.portalCooldown=Math.max(0,this.portalCooldown-dt);
  p.hurt=Math.max(0,p.hurt-dt);p.noise=Math.max(0,p.noise-dt*.42);
  if(p.reload>0){p.reload=Math.max(0,p.reload-dt);if(p.reload===0){const n=Math.min(30-p.ammo,p.reserve);p.ammo+=n;p.reserve-=n;this.emit('loaded');}}
  p.crouch=!!input.crouch;let speed=this.character.child?200:250;const moving=!!(input.x||input.z);
  if(input.sprint&&!p.crouch&&p.stamina>0&&moving){speed*=1.45;p.stamina=Math.max(0,p.stamina-dt*21);p.noise=Math.max(p.noise,.7);}else p.stamina=clamp(p.stamina+dt*15,0,100);
  if(p.crouch)speed*=.53;if(input.x)p.facing=input.x>0?1:-1;
  const oldX=p.x,oldZ=p.z;this.move(p,input.x||0,input.z||0,speed,dt);
  if(Math.abs(oldX-p.x)+Math.abs(oldZ-p.z)>0.001){p.walk+=dt*speed/18;p.noise=Math.max(p.noise,p.crouch?.03:.22);}
  if(input.fire)this.fire();
  if(s.work){
   if(dist(p,s.work)>38){s.work=null;this.notify('Action interrompue.');}
   else {s.work.timer+=dt;if(s.work.timer>=s.work.duration){const task=s.work;s.work=null;if(task.kind==='unseal'||task.kind==='weld'){s.doors[task.id]=task.kind==='weld'?'sealed':'open';this.notify(task.kind==='weld'?'Porte soudée.':'Porte libérée.');this.emit('save');}else this.completeTask(task.id);}}
  }
  // Pursuers use the same actual door connection. Sealing it holds them on the far side.
  for(const chase of s.pursuers){if(s.doors[pair(chase.from,chase.to)]==='sealed')continue;chase.delay=Math.max(0,chase.delay-dt);if(chase.delay===0){
    const dest=rooms.get(chase.to),back=dest.portals.find(p=>p.to===chase.from);
    if(!s.world[dest.id])s.world[dest.id]={enemies:[],acid:[],flares:[],spawnPhase:0};
    const e=chase.enemy;e.x=back.x;e.z=s.mode==='classic'?.7:back.z;e.path=[];e.notice=.7;e.state='chase';e.cooldown=.6;e.windup=0;e.repath=0;e.timer=0;e.facing=e.x<dest.width/2?1:-1;
    if(s.world[dest.id].enemies.length<12&&!s.world[dest.id].enemies.some(v=>v.id===e.id))s.world[dest.id].enemies.push(e);chase.delivered=true;
    if(s.room===dest.id)this.notify('La porte ne les a pas arrêtés.');
  }}s.pursuers=s.pursuers.filter(p=>!p.delivered);
  for(const f of w.flares)f.ttl-=dt;w.flares=w.flares.filter(f=>f.ttl>0);
  for(const acid of w.acid){acid.ttl-=dt;if(Math.abs(p.x-acid.x)<38&&Math.abs(p.z-acid.z)<.08)this.hit(12);}w.acid=w.acid.filter(a=>a.ttl>0);
  for(const b of this.bullets){b.previous=b.x;b.x+=b.dir*1120*dt;b.ttl-=dt;
   if(lineBlocked(r,{x:b.previous,z:b.z},b))b.ttl=0;
   if(b.ttl>0)for(const e of w.enemies){if(e.hp<=0||Math.abs(e.z-b.z)>.09)continue;
    if(e.x>=Math.min(b.previous,b.x)-14&&e.x<=Math.max(b.previous,b.x)+14){e.hp=Math.max(0,e.hp-b.damage);e.notice=1;e.state='chase';s.stats.shotsHit++;b.ttl=0;this.emit('impact',{x:e.x,z:e.z});
     if(e.hp===0){e.state='dead';s.stats.kills++;w.acid.push({x:e.x,z:e.z,ttl:25});this.emit('kill');}break;}}
  }
  this.bullets=this.bullets.filter(b=>b.ttl>0&&b.x>0&&b.x<r.width);
  for(const e of w.enemies){
   if(e.hp<=0)continue;e.cooldown=Math.max(0,e.cooldown-dt);e.timer+=dt;e.repath=Math.max(0,e.repath-dt);
   const d=dist(e,p),fl=w.flares.find(f=>dist(f,e)<320);const sight=d<(p.crouch?245:610)*tune.notice&&!lineBlocked(r,e,p);
   const heard=d<p.noise*850;const sees=sight||heard;
   if(fl){e.state='retreat';e.notice=Math.max(0,e.notice-dt);e.path=[];this.move(e,e.x<fl.x?-1:1,0,165*tune.enemySpeed,dt);continue;}
   if(sees)e.notice=clamp(e.notice+dt*(heard?1.2:1.55),0,1);else e.notice=Math.max(0,e.notice-dt*.18);
   if(e.state==='windup'){
    e.windup=Math.max(0,e.windup-dt);if(e.windup===0){if(d<80&&!lineBlocked(r,e,p))this.hit(e.kind==='adult'?30:20);e.cooldown=1.15;e.state='chase';}continue;}
   if(e.notice>.52){e.state='chase';if(d<63&&e.cooldown<=0){e.state='windup';e.windup=.65;continue;}
    if(e.repath<=0){e.path=localPath(r,e,p,s.mode);e.repath=.65;}
    const target=e.path[0]||p;if(dist(e,target)<28)e.path.shift();const dx=target.x-e.x,dz=(target.z-e.z)*600,len=Math.hypot(dx,dz)||1;
    this.move(e,dx/len,dz/len,(e.kind==='adult'?138:183)*tune.enemySpeed,dt);if(Math.abs(dx)>2)e.facing=Math.sign(dx);
   }else{
    e.state=e.notice>.12?'search':'patrol';const dx=e.facing;const before=e.x;this.move(e,dx,0,45,dt);
    if(Math.abs(e.x-before)<.01||e.x<100||e.x>r.width-100||e.timer>5.7){e.facing*=-1;e.timer=0;}
   }
  }
  if(s.escort&&s.escort.room===s.room){
   const e=s.escort;e.repath=Math.max(0,(e.repath||0)-dt);
   if(dist(e,p)>68){if(e.repath===0){e.path=localPath(r,e,p,s.mode);e.repath=.6;}const target=e.path[0]||p;if(dist(e,target)<25)e.path.shift();
    const dx=target.x-e.x,dz=(target.z-e.z)*600,len=Math.hypot(dx,dz)||1;this.move(e,dx/len,dz/len,222,dt);e.walk=(e.walk||0)+dt*12;}
   if(s.room===e.goal&&dist(e,p)<170){const task=e.task;s.escort=null;s.stats.escorts++;this.completeTask(task);}
  }
 }
 save(){return JSON.stringify({id:'river-of-pain',schema:1,savedAt:new Date().toISOString(),state:this.s,checkpoint:this.checkpoint});}
 load(text){const env=parseSave(text);this.s=clone(env.state);this.checkpoint=clone(env.checkpoint||env.state);this.events=[];this.bullets=[];this.ensureRoom();this.emit('room',{to:this.s.room});return true;}
 drain(){return this.events.splice(0);}
}
const api={Simulation,createState,validateState,parseSave,roomDef,route,localPath,obstacleAt,lineBlocked,allowedPortal,dist,clamp,settings};
root.ROP_CORE=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
