# ALIEN — Fleuve de la Douleur
## Hadley’s Hope · Les dernières lumières

**Version 0.1.0-candidate.1 · livraison locale du 29 septembre 2026.**

Une première campagne jouable de fan inspirée de *Alien: River of Pain*, de Christopher Golden. Ce dossier contient le code source du DLC, une édition HTML autonome, un lanceur additionnel pour Tantalus Frontier, les tests et leurs résultats, un codex de level design et un rapport illustré de captures réelles du runtime.

**Ce n’est pas une copie complète de Tantalus Frontier, une adaptation intégrale certifiée du roman, ni un DLC aux graphismes définitifs.** Les plans, interactions, dialogues et notes de terrain sont originaux. Le roman intégral n’a pas été consulté. Les événements retenus sont appuyés sur les sources publiques décrites dans `docs/SOURCES_ET_CONTINUITE.md`.

## Jouer

Décompressez l’archive et ouvrez **JOUER.html** dans un navigateur récent. Sous Windows, `LANCER_WINDOWS.bat` ouvre ce même fichier. Aucun téléchargement d’image, police ou bibliothèque n’est requis par le jeu. Aucun compte et aucune connexion serveur de jeu ne sont utilisés.

Le navigateur peut restreindre le stockage local des fichiers HTML. La progression se sauvegarde sous une clé propre au DLC lorsqu’il l’autorise. En cas d’avertissement, utilisez **Échap → Exporter** avant de quitter, puis **Charger un fichier** pour reprendre. Le fonctionnement de l’export a été vérifié dans Chromium ; la persistance native `localStorage` n’a pas pu être qualifiée sur l’origine opaque de l’environnement de test.

Une autre possibilité est `python tools/serve.py`, puis l’adresse locale affichée par le script. Ce serveur n’écoute que sur la boucle locale de votre machine. L’environnement de livraison ayant bloqué la navigation `file://`, les tests graphiques ont chargé le HTML exact via `page.set_content` ; aucune politique de sécurité du navigateur n’a été modifiée.

## Contenu réellement fourni

| Élément | Livraison |
|---|---:|
| Chapitres jouables à objectifs | 16 |
| Lieux distincts et reliés | 36 |
| Connexions bidirectionnelles | 45 |
| Objectifs physiques | 49 |
| Notes originales du carnet | 24 |
| Placements de décor sémantiques | 231 |
| Personnages jouables | 4 |
| Escortes à mener physiquement | 2 |
| Présentations | 2D latérale / déplacement avec profondeur |
| Difficultés | Récit / Survie / Cauchemar |

Les 231 éléments sont **des placements**, pas 231 images uniques. Les personnages et décors sont dessinés par code dans Canvas ; aucun atlas final du jeu principal n’a été intégré. Les 10 noms de couches du codex sont une convention d’organisation ; le moteur n’implémente pas dix simulations ou dix plans jouables indépendants.

## Commandes

Q/D ou A/D, flèches gauche/droite : marcher. Z/S ou W/S, flèches haut/bas : se déplacer dans la profondeur des salles compatibles. C : basculer accroupi. Ctrl : s’accroupir tant que la touche reste maintenue. Maj : courir. E : interagir ou passer une porte. F : tirer avec un personnage armé. R : recharger. H : soin. X : fusée de détresse. B : souder/dessouder une porte accessible après acquisition du poste à souder. Tab : plan. J : carnet. Échap : pause et options.

Newt n’a ni arme ni fusée. Anne n’a pas d’arme. Les commandes tactiles sont affichées sur un appareil à pointeur grossier ; leur affichage et leur relâchement ont été contrôlés en émulation Chromium, pas sur téléphone physique. Aucune manette n’est prise en charge dans cette version.

## Installer le lanceur dans Tantalus Frontier

Faites d’abord une copie de travail de votre projet. Depuis le dossier de ce DLC, avec Node.js 20 ou ultérieur :

```sh
node tools/install.mjs "/chemin/vers/aliens-tantalus-frontier"
```

L’installateur vérifie le nom du projet et les ancrages `title-menu`, `archives` et `/src/app.js`. Il copie uniquement `src/river-of-pain/` et ajoute un script balisé dans `index.html`. Un bouton est ajouté au menu principal et aux archives. Il ouvre une page séparée, **pas une superposition faisant tourner deux simulations simultanément**. Le menu du DLC propose le retour au Tantalus lorsque l’accès vient du lanceur.

La lecture de `scripts/build.mjs` du dépôt de référence montre une copie récursive de `src`, ce qui motive cet emplacement. Le build complet de Tantalus n’a toutefois pas été exécuté dans cette livraison. Les tests d’installation utilisent une fixture des ancrages observés, pas les 440 campagnes du dépôt.

Pour retirer le lanceur :

```sh
node tools/install.mjs "/chemin/vers/aliens-tantalus-frontier" --remove
```

La copie originale de `index.html` est conservée sous `.dlc-backups/river-of-pain-v0.1.0/`. La réexécution ne double pas le lanceur. Un index ou un module modifié après installation provoque un refus plutôt qu’un écrasement. Les liens symboliques sur les chemins concernés sont refusés. La restauration automatique couvre les erreurs capturées ; elle ne prétend pas rendre une coupure de courant atomique.

## Frontière et continuité

La campagne liée est `v36_campaign_acheron_river_of_pain`. Son couple existant est `pair_v36_campaign_acheron_river_of_pain`. Son écho `frontier_v36_campaign_acheron_river_of_pain` reste inchangé. Aucun doublon de campagne n’est injecté dans le catalogue, aucune unité Echo-9 n’est tuée ou améliorée et aucune ressource Frontière n’est attribuée.

Le lanceur réutilise ces identifiants comme métadonnées, **sans remplacer l’entrée dans le moteur natif**. La sauvegarde indépendante est `atf.dlc.river-of-pain.v1.profile1`. Cette livraison n’inclut pas de nouvel écho jouable 2204.

## Vérifier et reconstruire

```sh
npm test
python tools/build-content.py
python tools/build-standalone.py
python tests/browser.py
```

Le runtime ne dépend d’aucun paquet npm. La recette navigateur demande Python et Playwright (`requirements-dev.txt`) ainsi qu’un Chromium ; définir `CHROMIUM_PATH` si son chemin n’est pas `/usr/bin/chromium`. Les résultats sont dans `docs/*RESULTS.json`.

## État de production

Les six parcours automatisés du modèle arrivent à la fin sans téléportation, validation forcée d’objectif ou invulnérabilité. Leur trajet optimisé dure environ sept minutes de simulation, sans le temps de lecture : **ce chiffre ne représente pas une durée de jeu mesurée auprès de joueurs**. Les trois difficultés doivent encore être différenciées par un vrai travail d’équilibrage et des essais humains.

La verticalité est un réseau de changements de salle par escaliers, échelles et monte-charges ; ce n’est pas une physique de déplacement vertical continu. Le tracteur, le monte-charge et la navette sont des interactions de mission et des décors, pas des véhicules librement pilotables. Les escortés suivent et franchissent les portes, mais n’ont pas de santé ni d’IA de protection avancée. Les créatures poursuivent une transition réellement empruntée ; il n’y a pas de simulation globale persistante de ruche dans toutes les salles.

Les interventions scénarisées sur l’électricité et les barricades valident des marqueurs de progression ; elles ne constituent pas encore une simulation électrique distribuée ou un système complet de sièges. La soudure manuelle B bloque réellement un passage et retient une poursuite programmée. Une porte soudée ne sera pas automatiquement détruite par un ennemi dans cette version.

**Aucun push GitHub ni déploiement Vercel n’a été effectué.** Le dépôt de référence a été lu au commit `496996f5ea557d970ec625aa346876f3eaed1c5f`. Le moteur natif complet, ses atlas, les autres DLC et leurs sauvegardes n’ont pas fait l’objet d’une recette de non-régression globale.
