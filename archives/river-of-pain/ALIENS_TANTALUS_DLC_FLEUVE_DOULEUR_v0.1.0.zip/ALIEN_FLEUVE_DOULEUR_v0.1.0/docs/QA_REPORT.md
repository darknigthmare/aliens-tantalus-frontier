# Rapport de validation exécutée

Version 0.1.0-candidate.1 — 29 septembre 2026.

## Résultats

- Moteur et contenu : 90/90 groupes de tests passés.
- Parcours complets du modèle : 6/6 — deux vues × trois difficultés.
- Installateur sur fixtures : 10/10 tests passés.
- Recette navigateur : 16/16 contrôles passés, 0 erreur JavaScript relevée.
- Captures finales : 7 images du runtime Chromium.

## Ce que ces résultats établissent

Les parcours du modèle démarrent au premier chapitre, se déplacent par `Simulation.update`, utilisent des objets à proximité, traversent les véritables portails, consomment de l’équipement et mènent les deux escortes jusqu’à destination. Ils n’appellent pas directement `completeTask`, ne téléportent pas le personnage et ne modifient pas sa santé. Ils traversent les 49 objectifs, puis atteignent la fin du chapitre 16.

Cette recette est une validation structurelle automatisée. Son trajet optimisé d’environ sept minutes de simulation n’inclut pas les temps de lecture et ne représente pas une session utilisateur mesurée. Les différences de difficulté sont modestes sur ce trajet ; l’équilibrage doit être approfondi.

Les tests unitaires vérifient notamment les retours de portes, les points d’interaction hors obstacles, les droits des conduits, le verrou du hangar, la profondeur, les projectiles, la recharge, les soins, l’acide, les fusées, les portes soudées, la poursuite inter-pièces, les importations invalides et les points de reprise. Certains de ces tests utilisent explicitement des états synthétiques ciblés ; ils ne sont pas comptés comme des parcours physiques complets.

La recette navigateur charge le contenu exact du fichier HTML autonome avec Playwright dans Chromium. Le premier objectif et le passage vers le sas sont exécutés avec les commandes clavier. Les scènes médicales, de ruche et de Newt sont obtenues en important des sauvegardes de test validées : leurs captures ne sont pas présentées comme une partie complète jouée manuellement. Les marqueurs et états correspondants sont enregistrés dans le JSON navigateur.

## Limites de l’environnement

Le CLI agent-browser n’était pas installé. La navigation `file://` a été refusée par la politique de Chromium de l’environnement ; aucun contournement de cette politique n’a été utilisé. `page.set_content` permet le contrôle du document exact et de son runtime, mais produit une origine opaque : `localStorage` y est indisponible. Le message de repli, l’import, l’export JSON et le codec de sauvegarde ont été testés ; la persistance native après fermeture/réouverture du navigateur doit être vérifiée sur la machine cible.

Aucun serveur hôte complet, aucun déploiement Vercel, aucune manette ni aucun téléphone physique n’a été testé. Le contrôle tactile est une émulation de pointeur Chromium. Le lanceur et son installateur ont été testés sur des fixtures reproduisant les ancrages observés du dépôt, pas sur les 440 campagnes réellement chargées.

## Corrections intervenues pendant la recette

Le repère cartographique du relais, initialement superposé à celui de l’aire d’atterrissage, a été séparé. Le HUD recouvrant la bande de marche a été déplacé vers le haut. La soudure manuelle utilise désormais une action temporisée et bloque effectivement les poursuivants à la porte. Les importations contrôlent aussi les états de poursuite et les valeurs de distribution électrique. Les notes du carnet ont été réécrites en documents de terrain ; les explications de production restent dans les documents et écrans dédiés.

Deux erreurs du pilote de test ont également été corrigées : la détection de fin d’une interaction temporisée et l’identifiant supposé absent « missing », qui est en fait un objectif valide. Ces corrections ne sont pas présentées comme des corrections de bug du jeu.

## Qualification

**Candidat local jouable validé sur le périmètre décrit. Non qualifié comme DLC final, adaptation intégrale 1:1 ou intégration native complète.**
