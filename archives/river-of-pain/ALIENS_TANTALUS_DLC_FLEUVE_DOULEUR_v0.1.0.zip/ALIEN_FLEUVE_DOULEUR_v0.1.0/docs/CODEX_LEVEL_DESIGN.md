# Codex de level design — Hadley’s Hope

Version 0.1.0-candidate.1 · données extraites du contenu réellement livré.

## Contrat de cette version

Les 36 lieux sont des définitions distinctes reliées par 45 arêtes bidirectionnelles. Ils partagent un moteur de rendu et des familles de modules : ce ne sont pas 36 illustrations finales uniques. Tous les passages ont une extrémité de retour. Les portails, objectifs et couvertures utilisent les mêmes coordonnées que la simulation. Les dimensions en mètres sont des intentions de blocage, pas des mesures extraites du roman ; le cadrage et l’échelle verticale restent à affiner.

Le déplacement est horizontal avec une profondeur continue dans les salles compatibles. Les passages étroits et les conduits sont latéraux. Les escaliers, échelles et monte-charges changent la salle et le niveau déclaré ; aucune animation de cabine ni ascension continue n’est simulée.

## Composition et lisibilité

Le découpage HORIZON → SKYLINE → FAR → MID → WALL → FIXTURES → FLOOR → ACTORS → NEAR → FOREGROUND sert de vocabulaire commun. Le moteur compose montagnes et silhouette coloniale en parallaxe, structure murale, mobilier et portes, sol, acteurs triés en profondeur, effets et montants proches. Toutes les couches ne possèdent pas un facteur de parallaxe indépendant dans chaque salle.

Le HUD est placé au-dessus de la bande de marche. Le bas de l’image reste réservé aux pieds, seuils, couvertures et dangers. Le plan et le carnet mettent la simulation en pause. Les messages temporaires ne bloquent pas les commandes. Les grilles réservées à Newt sont identifiées au moment de l’interaction.

Les couvertures sont deux îlots lorsqu’une salle possède de la profondeur. Les chemins du fond et de l’avant restent reliés. Une décoration murale non collisionnable ne devient pas un obstacle invisible. La conversion en vue latérale conserve le graphe et les objectifs, mais concentre les projections au même plan.

## États et interactions

Les objets récupérés, notes lues, créatures déjà rencontrées, flaques d’acide, fusées encore actives, marqueurs de mission et portes soudées sont sauvegardés. Une salle déjà visitée n’est pas recréée à chaque entrée. Un nouveau stade de crise peut ajouter une rencontre prévue par le moteur. Les trois difficultés modifient les coefficients de perception, vitesse et dégâts ; elles ne possèdent pas encore des scripts d’événements différents.

La soudure B est physique : elle verrouille un lien bidirectionnel et retient les poursuites associées. Les tâches de scénario intitulées fermer, renforcer ou réarmer enregistrent une progression, mais ne calculent pas une simulation complète des cloisons ou de la distribution d’énergie. Le véhicule et les ascenseurs sont des postes d’interaction. Les missions d’escorte utilisent un suivi de position et un contrôle de proximité à la porte, sans santé propre ni panique avancée du compagnon.

## Campagne

### 01 — La relève

**Point de vue : Demian Brackett · Avant la crise · départ : Aire d’atterrissage.**

Brackett prend ses fonctions dans une colonie qui ressemble encore à une ville.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Aire d’atterrissage | Retrouver Paris (talk) | `welcome` |
| 2 | Contrôle colonial | Consulter le tableau de service (terminal) | `brief` |
| 3 | Poste de la garnison | Prendre la dotation (supply) | `locker` |

Dialogue original d’ouverture, Paris : « Vous verrez la tempête plus souvent que le ciel. Les familles, elles, sont ici toute l’année. »

### 02 — Les gens d’ici

**Point de vue : Anne Jorden · Avant la crise · départ : Logement des Jorden.**

Anne traverse les lieux ordinaires que la crise rendra bientôt méconnaissables.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Logement des Jorden | Préparer la tournée (talk) | `family` |
| 2 | Réfectoire | Récupérer les provisions (supply) | `provisions` |
| 3 | Distribution électrique | Réarmer le départ habitat (power) | `grid` |

Dialogue original d’ouverture, Anne : « On peut retarder les relevés. Pas le chauffage du bloc. »

### 03 — Sous pression

**Point de vue : Demian Brackett · Avant la crise · départ : Garage des prospecteurs.**

Une intervention industrielle expose les tensions de la garnison. Séquence de jeu condensée autour du processeur six.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Garage des prospecteurs | Prendre le matériel de secours (supply) | `rescue_kit` |
| 2 | Processeur six | Isoler la conduite endommagée (valve) | `pressure` |
| 3 | Processeur six | Récupérer le rapport d’intervention (terminal) | `incident` |

Dialogue original d’ouverture, Paris : « Coupez l’arrivée avant de toucher aux vannes. Ici, une mauvaise décision se propage à tout le réseau. »

### 04 — Les coordonnées

**Point de vue : Anne Jorden · Avant la crise · départ : Bureau des prospecteurs.**

La sortie des Jorden rejoint le lieu désigné par la Compagnie. La découverte de Russ est traitée hors champ.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Bureau des prospecteurs | Recevoir la grille de prospection (terminal) | `coordinates` |
| 2 | Garage des prospecteurs | Préparer le tracteur (vehicle) | `tractor` |
| 3 | Plateau des relevés | Poser une balise sur le plateau (beacon) | `beacon` |
| 4 | Seuil de l’épave | Examiner le seuil de l’épave (scan) | `threshold` |

Dialogue original d’ouverture, Anne : « La radio passe mal. Je laisse une balise : personne ne retrouvera cette passe de nuit. »

### 05 — La porte blanche

**Point de vue : Demian Brackett · Premiers incidents · départ : Aire d’atterrissage.**

Le retour des prospecteurs met l’infirmerie au centre de toutes les décisions.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Aire d’atterrissage | Prendre en charge le retour des prospecteurs (talk) | `stretcher` |
| 2 | Chambre d’isolement | Fermer l’isolement médical (seal) | `quarantine` |
| 3 | Infirmerie | Transmettre le bilan à Komiskey (terminal) | `triage` |

Dialogue original d’ouverture, Komiskey : « Gardez le couloir libre. Je veux des gens qui respirent, pas une foule autour du lit. »

### 06 — Priorité de recherche

**Point de vue : Anne Jorden · Premiers incidents · départ : Infirmerie.**

Les priorités médicales et celles de la Compagnie divergent.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Infirmerie | Consulter le registre des patients (terminal) | `patient_log` |
| 2 | Laboratoire de la Compagnie | Lire la directive scientifique (terminal) | `orders` |
| 3 | Salle des archives | Conserver une copie des échanges (terminal) | `copy` |

Dialogue original d’ouverture, Anne : « Ce n’est pas une cargaison. C’est mon mari. »

### 07 — Derrière les grilles

**Point de vue : Rebecca « Newt » Jorden · Premiers incidents · départ : Logement des Jorden.**

Les jeux dans les conduits deviennent un apprentissage de la survie. Aucun combat pour Newt.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Conduits de l’habitat | Retrouver les repères de Tim (trace) | `marks` |
| 2 | Conduits de l’infirmerie | Écouter derrière la grille (listen) | `listen` |
| 3 | Cache des conduits | Préparer une petite cache (stash) | `cache` |

Dialogue original d’ouverture, Newt : « Le tuyau qui vibre revient vers la cuisine. Celui qui siffle va à l’infirmerie. »

### 08 — Les absents

**Point de vue : Demian Brackett · La colonie se ferme · départ : Contrôle colonial.**

Les disparitions ont désormais une géographie. Les itinéraires sûrs commencent à se refermer.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Contrôle colonial | Relever les dernières balises PDT (terminal) | `missing` |
| 2 | Galerie technique | Suivre les traces dans la galerie (scan) | `trail` |
| 3 | Station de pompage | Détourner la pression du passage (valve) | `reroute` |

Dialogue original d’ouverture, Brackett : « On marque chaque porte derrière nous. Je refuse de perdre quelqu’un à un embranchement. »

### 09 — Les lumières rouges

**Point de vue : Julisa Paris · La colonie se ferme · départ : Infirmerie.**

Paris maintient une route pour les habitants. L’escorte représente une survie locale, pas une évacuation historique supplémentaire.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Réserve médicale | Prendre les soins d’urgence (supply) | `medstock` |
| 2 | Réfectoire | Accompagner un colon jusqu’au magasin (escort) | `civilian` |
| 3 | Magasin de fret | Mettre le refuge provisoire sous tension (power) | `shelter` |

Dialogue original d’ouverture, Paris : « Restez derrière moi. Nous allons jusqu’à la lumière suivante, puis à la suivante. »

### 10 — Fermer, tenir

**Point de vue : Anne Jorden · La colonie se ferme · départ : Bureau des prospecteurs.**

Les prospecteurs transforment leurs outils en moyens de défense.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Magasin de fret | Récupérer un poste à souder (supply) | `welding` |
| 2 | Bureau des prospecteurs | Renforcer la fermeture du bureau (seal) | `barricade` |
| 3 | Distribution électrique | Rétablir le circuit de secours (power) | `emergency` |

Dialogue original d’ouverture, Anne : « La porte n’a pas besoin de tenir toute la nuit. Seulement assez longtemps pour les enfants. »

### 11 — Sous le processeur

**Point de vue : Demian Brackett · La chute · départ : Accès au processeur un.**

Le passage dans la ruche est un échec de sauvetage, pas une chasse à la reine.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Monte-charge du processeur | Commander le monte-charge (terminal) | `descent` |
| 2 | Soubassements envahis | Retrouver la source des signaux (scan) | `pdt` |
| 3 | Galerie du refroidissement | Baliser la route de repli (beacon) | `fallback` |
| 4 | Distribution électrique | Fermer derrière le groupe (seal) | `withdraw` |

Dialogue original d’ouverture, Brackett : « N’approchez pas des parois. Repliez-vous par les balises ; ne tirez que pour ouvrir le passage. »

### 12 — La dernière porte

**Point de vue : Anne Jorden · La chute · départ : Bureau des prospecteurs.**

La défense des Jorden ne change pas leur destin. Le point de vue quitte Anne au moment où Newt passe la grille.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Bureau des prospecteurs | Alimenter le verrou une dernière fois (power) | `last_power` |
| 2 | Bureau des prospecteurs | Dégager l’accès au conduit (seal) | `vent_open` |
| 3 | Bureau des prospecteurs | Mettre Newt à l’abri (talk) | `newt_escape` |

Dialogue original d’ouverture, Anne : « Ne te retourne pas. Compte les virages comme quand vous jouiez. »

### 13 — Une issue réservée

**Point de vue : Julisa Paris · La chute · départ : Laboratoire de la Compagnie.**

Brackett transmet l’indication d’Hidalgo : la Compagnie dispose d’une issue. Luisa suit Paris jusqu’au hangar.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Laboratoire de la Compagnie | Recevoir la transmission de Brackett (talk) | `hidalgo` |
| 2 | Bureau des prospecteurs | Dégager Luisa et la conduire au hangar (escort) | `luisa` |
| 3 | Hangar scientifique | Déverrouiller la navette scientifique (terminal) | `clearance` |

Dialogue original d’ouverture, Paris : « La sortie existe. Nous allons la rendre accessible à ceux qui sont encore avec nous. »

### 14 — La trajectoire imposée

**Point de vue : Demian Brackett · La chute · départ : Hangar scientifique.**

Brackett, Paris, Mori et Luisa quittent la colonie. Newt n’est pas à bord.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Hangar scientifique | Vérifier l’embarquement (talk) | `boarding` |
| 2 | Navette de la Compagnie | Désengager la trajectoire automatique (terminal) | `autopilot` |
| 3 | Navette de la Compagnie | Décoller (launch) | `departure` |

Dialogue original d’ouverture, Brackett : « Aucune trajectoire imposée. Nous choisissons où nous allons. »

### 15 — Il reste quelqu’un

**Point de vue : Rebecca « Newt » Jorden · La chute · départ : Cache des conduits.**

Le point de vue revient dans les conduits. Il faut survivre avec presque rien.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Buanderie | Récupérer de l’eau (supply) | `water` |
| 2 | Réfectoire | Trouver de quoi manger (supply) | `ration` |
| 3 | Conduits des prospecteurs | Passer sans attirer la créature (listen) | `silence` |

Dialogue original d’ouverture, Newt : « Pas la grande porte. Jamais la grande porte quand on entend les tuyaux. »

### 16 — Jusqu’au prochain bruit

**Point de vue : Rebecca « Newt » Jorden · La chute · départ : Cache des conduits.**

La cache devient le dernier lieu habité du parcours. La suite appartient à l’arrivée du Sulaco.

| Étape | Lieu | Action réelle | Identifiant |
|---|---|---|---|
| 1 | Conduits de l’habitat | Vérifier le chemin de retour (trace) | `route` |
| 2 | Cache des conduits | Regagner la cache (stash) | `hide` |

Dialogue original d’ouverture, Newt : « Je suis là. Je suis encore là. »

## Fiches pièce par pièce

Les coordonnées x sont en unités du moteur ; z est la position normalisée dans le plan du sol. Les noms de bâtiments et les étages servent à rendre le réseau lisible. Ils ne constituent pas un plan officiel de Hadley’s Hope.

### pad — Aire d’atterrissage

**Périmètre · niveau 0 · famille exterior · largeur 2900 u · z 0.25 à 0.9.**

Repère architectural : Tour de contrôle et feux d’approche.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Sas des arrivants | sas | 170 / 0.69 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `beacon` | 442 / 0.22 | FIXTURES | Non | orientation du trajet |
| `antenna` | 845 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fuel` | 1248 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `beacon` | 1652 / 0.22 | FIXTURES | Non | orientation du trajet |
| `cable` | 2055 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tractor` | 2458 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `crate` | 1102 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `rock` | 1943 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Retrouver Paris | 667 / 0.81 | 1 | talk |
| Prendre en charge le retour des prospecteurs | 1102 / 0.81 | 5 | talk |
| Bordereau d’arrivée | 2378.0 / 0.43 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 1 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### airlock — Sas des arrivants

**Accueil · niveau 0 · famille side · largeur 1800 u · z 0.7 à 0.7.**

Repère architectural : Double porte pressurisée, douche de décontamination.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Aire d’atterrissage | sas | 170 / 0.7 | Accès général |
| Coursive centrale | porte | 1630 / 0.7 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `shower` | 372 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `locker` | 636 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fan` | 900 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `panel` | 1164 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `lamp` | 1428 / 0.22 | FIXTURES | Non | fonction propre au lieu |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Aucun objectif fixe | — | — | Pièce de liaison |

#### Garde-fous de production

Conserver les retours de chacun des 2 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### concourse — Coursive centrale

**Accueil · niveau 0 · famille depth · largeur 3000 u · z 0.25 à 0.9.**

Repère architectural : Signalétique des blocs, galerie vitrée.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Sas des arrivants | porte | 170 / 0.69 | Accès général |
| Contrôle colonial | escalier | 2830 / 0.69 | Accès général |
| Coursive résidentielle | escalier | 840 / 0.28 | Accès général |
| Infirmerie | porte | 1440 / 0.28 | Accès général |
| Garage des prospecteurs | porte | 2040 / 0.28 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `bench` | 420 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `window` | 780 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `sign` | 1140 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `vending` | 1500 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `window` | 1860 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fan` | 2220 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `bench` | 2580 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 1140 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 2010 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Aucun objectif fixe | — | — | Pièce de liaison |

#### Garde-fous de production

Conserver les retours de chacun des 5 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### ops — Contrôle colonial

**Administration · niveau 1 · famille depth · largeur 2400 u · z 0.25 à 0.9.**

Repère architectural : Baie de supervision et consoles de communications.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Coursive centrale | escalier | 170 / 0.69 | Accès général |
| Poste de la garnison | porte | 2230 / 0.69 | Accès général |
| Relais de communications | coursive | 672 / 0.28 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `console` | 400 / 0.22 | FIXTURES | Non | poste de travail |
| `screen` | 720 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` | 1040 / 0.22 | FIXTURES | Non | poste de travail |
| `antenna` | 1360 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `screen` | 1680 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `map` | 2000 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 912 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 1608 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Consulter le tableau de service | 552 / 0.81 | 1 | terminal |
| Relever les dernières balises PDT | 912 / 0.81 | 8 | terminal |
| Grille de prospection | 1967.9999999999998 / 0.43 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 3 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### briefing — Poste de la garnison

**Administration · niveau 1 · famille side · largeur 2200 u · z 0.7 à 0.7.**

Repère architectural : Casiers individuels et table de service.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Contrôle colonial | porte | 170 / 0.7 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `locker` | 383 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rifle-rack` | 670 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` | 957 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `locker` | 1243 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `radio` | 1530 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `locker` | 1817 / 0.22 | FIXTURES | Non | fonction propre au lieu |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Prendre la dotation | 506 / 0.7 | 1 | supply |
| Ordre du jour | 1804.0 / 0.7 | Optionnel | archive |
| Réserve de terrain | 1166.0 / 0.7 | Optionnel | pickup |

#### Garde-fous de production

Conserver les retours de chacun des 1 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### hab — Coursive résidentielle

**Habitat · niveau 1 · famille side · largeur 2700 u · z 0.7 à 0.7.**

Repère architectural : Portes numérotées et fenêtres des logements.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Coursive centrale | escalier | 170 / 0.7 | Accès général |
| Logement des Jorden | porte | 2530 / 0.7 | Accès général |
| Centre de loisirs | escalier | 756 / 0.7 | Accès général |
| Buanderie | escalier | 1296 / 0.7 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `hab-door` | 425 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `window` | 795 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `hab-door` | 1165 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `plant` | 1535 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `hab-door` | 1905 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `drawing` | 2275 / 0.22 | FIXTURES | Non | trace de vie familiale |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Aucun objectif fixe | — | — | Pièce de liaison |

#### Garde-fous de production

Conserver les retours de chacun des 4 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### jorden — Logement des Jorden

**Habitat · niveau 1 · famille depth · largeur 1850 u · z 0.25 à 0.9.**

Repère architectural : Table familiale, lits et dessins d’enfant.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Coursive résidentielle | porte | 170 / 0.69 | Accès général |
| Conduits de l’habitat | conduit | 1680 / 0.69 | Enfant uniquement |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `bed` | 354 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` | 582 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `drawing` | 811 / 0.22 | FIXTURES | Non | trace de vie familiale |
| `cupboard` | 1039 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `bed` | 1268 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `toy` | 1496 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 703 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 1240 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Préparer la tournée | 426 / 0.81 | 2 | talk |
| Une table pour quatre | 1517.0 / 0.43 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 2 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### mess — Réfectoire

**Habitat · niveau 0 · famille depth · largeur 2600 u · z 0.25 à 0.9.**

Repère architectural : Tables, cuisine et distributeurs.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Centre de loisirs | porte | 170 / 0.69 | Accès général |
| Buanderie | porte | 2430 / 0.69 | Accès général |
| Magasin de fret | porte | 728 / 0.28 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `vending` | 417 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `stove` | 770 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` | 1123 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` | 1477 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` | 1830 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `sink` | 2183 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 988 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 1742 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Récupérer les provisions | 598 / 0.81 | 2 | supply |
| Accompagner un colon jusqu’au magasin | 988 / 0.81 | 9 | escort |
| Trouver de quoi manger | 1378 / 0.81 | 15 | supply |

#### Garde-fous de production

Conserver les retours de chacun des 3 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### recreation — Centre de loisirs

**Habitat · niveau 0 · famille depth · largeur 2250 u · z 0.25 à 0.9.**

Repère architectural : Jeux, bancs et accès à la maintenance.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Coursive résidentielle | escalier | 170 / 0.69 | Accès général |
| Réfectoire | porte | 2080 / 0.69 | Accès général |
| Conduits de l’habitat | grille | 630 / 0.28 | Enfant uniquement |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `arcade` | 417 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `bench` | 771 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `arcade` | 1125 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` | 1479 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `drawing` | 1833 / 0.22 | FIXTURES | Non | trace de vie familiale |
| `machine` | 855 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 1508 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Les chemins de Tim | 1845.0 / 0.43 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 3 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### med — Infirmerie

**Médical · niveau 0 · famille depth · largeur 2800 u · z 0.25 à 0.9.**

Repère architectural : Lits isolés, vitres d’observation et moniteurs.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Coursive centrale | porte | 170 / 0.69 | Accès général |
| Chambre d’isolement | porte | 2630 / 0.69 | Accès général |
| Réserve médicale | porte | 784 / 0.28 | Accès général |
| Laboratoire de la Compagnie | sas | 1344 / 0.28 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `bed` | 433 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `monitor` | 820 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `bed` | 1207 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `sink` | 1593 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `medicine` | 1980 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `bed` | 2367 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 1064 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 1876 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Transmettre le bilan à Komiskey | 644 / 0.81 | 5 | terminal |
| Consulter le registre des patients | 1064 / 0.81 | 6 | terminal |
| Priorité médicale | 2296.0 / 0.43 | Optionnel | archive |
| Réserve de terrain | 1484.0 / 0.86 | Optionnel | pickup |

#### Garde-fous de production

Conserver les retours de chacun des 4 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### isolation — Chambre d’isolement

**Médical · niveau 0 · famille side · largeur 1700 u · z 0.7 à 0.7.**

Repère architectural : Lit d’observation et hublot de quarantaine.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Infirmerie | porte | 170 / 0.7 | Accès général |
| Conduits de l’infirmerie | grille | 1530 / 0.7 | Enfant uniquement |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `bed` | 362 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `monitor` | 606 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `glass` | 850 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `sink` | 1094 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `specimen` | 1338 / 0.22 | FIXTURES | Non | fonction propre au lieu |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Fermer l’isolement médical | 391 / 0.7 | 5 | seal |
| Le hublot | 1394.0 / 0.7 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 2 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### science — Laboratoire de la Compagnie

**Recherche · niveau 0 · famille depth · largeur 2400 u · z 0.25 à 0.9.**

Repère architectural : Paillasses, cuves et racks de confinement.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Infirmerie | sas | 170 / 0.69 | Accès général |
| Salle des archives | escalier | 2230 / 0.69 | Accès général |
| Galerie technique | escalier | 672 / 0.28 | Accès général |
| Hangar scientifique | sas | 1152 / 0.28 | Accès scientifique |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `specimen` | 400 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` | 720 / 0.22 | FIXTURES | Non | poste de travail |
| `specimen` | 1040 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `sink` | 1360 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `microscope` | 1680 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tank` | 2000 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 912 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 1608 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Lire la directive scientifique | 552 / 0.81 | 6 | terminal |
| Recevoir la transmission de Brackett | 912 / 0.81 | 13 | talk |
| Mainmise | 1967.9999999999998 / 0.43 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 4 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### records — Salle des archives

**Recherche · niveau 1 · famille side · largeur 1800 u · z 0.7 à 0.7.**

Repère architectural : Bandes de données et baie réseau.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Laboratoire de la Compagnie | escalier | 170 / 0.7 | Accès général |
| Relais de communications | coursive | 1630 / 0.7 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `rack` | 372 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rack` | 636 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` | 900 / 0.22 | FIXTURES | Non | poste de travail |
| `rack` | 1164 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `screen` | 1428 / 0.22 | FIXTURES | Non | fonction propre au lieu |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Conserver une copie des échanges | 414 / 0.7 | 6 | terminal |
| Transmission conservée | 1476.0 / 0.7 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 2 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### garage — Garage des prospecteurs

**Logistique · niveau 0 · famille depth · largeur 3200 u · z 0.25 à 0.9.**

Repère architectural : Tracteur de prospection sur sa voie de service.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Coursive centrale | porte | 170 / 0.69 | Accès général |
| Bureau des prospecteurs | porte | 3030 / 0.69 | Accès général |
| Galerie technique | escalier | 896 / 0.28 | Accès général |
| Piste du plateau | sas | 1536 / 0.28 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `tractor` | 512 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tools` | 1056 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fuel` | 1600 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `gantry` | 2144 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `wheel` | 2688 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 1216 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 2144 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Prendre le matériel de secours | 736 / 0.81 | 3 | supply |
| Préparer le tracteur | 1216 / 0.81 | 4 | vehicle |
| Tracteur des prospecteurs | 2624.0 / 0.43 | Optionnel | archive |
| Réserve de terrain | 1696.0 / 0.86 | Optionnel | pickup |

#### Garde-fous de production

Conserver les retours de chacun des 4 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### survey — Bureau des prospecteurs

**Logistique · niveau 0 · famille depth · largeur 2500 u · z 0.25 à 0.9.**

Repère architectural : Cartes topographiques et postes radio.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Garage des prospecteurs | porte | 170 / 0.69 | Accès général |
| Magasin de fret | porte | 2330 / 0.69 | Accès général |
| Conduits des prospecteurs | grille | 700 / 0.28 | Enfant uniquement |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `map` | 442 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` | 846 / 0.22 | FIXTURES | Non | poste de travail |
| `radio` | 1250 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tools` | 1654 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `shelf` | 2058 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 950 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 1675 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Recevoir la grille de prospection | 575 / 0.81 | 4 | terminal |
| Renforcer la fermeture du bureau | 950 / 0.81 | 10 | seal |
| Alimenter le verrou une dernière fois | 1325 / 0.81 | 12 | power |
| Dégager l’accès au conduit | 1700 / 0.81 | 12 | seal |
| Mettre Newt à l’abri | 575 / 0.81 | 12 | talk |
| Dégager Luisa et la conduire au hangar | 950 / 0.81 | 13 | escort |
| Un bureau transformé | 2050.0 / 0.43 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 3 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### stores — Magasin de fret

**Logistique · niveau 0 · famille depth · largeur 3100 u · z 0.25 à 0.9.**

Repère architectural : Palettes, rack de levage et allées dégagées.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Bureau des prospecteurs | porte | 170 / 0.69 | Accès général |
| Distribution électrique | escalier | 2930 / 0.69 | Accès général |
| Réfectoire | porte | 868 / 0.28 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `crate` | 458 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `shelf` | 895 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `pallet` | 1332 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `gantry` | 1768 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `crate` | 2205 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `shelf` | 2642 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 1178 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 2077 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Mettre le refuge provisoire sous tension | 713 / 0.81 | 9 | power |
| Récupérer un poste à souder | 1178 / 0.81 | 10 | supply |
| Refuge provisoire | 2542.0 / 0.43 | Optionnel | archive |
| Réserve de terrain | 1643.0 / 0.86 | Optionnel | pickup |

#### Garde-fous de production

Conserver les retours de chacun des 3 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### power — Distribution électrique

**Maintenance · niveau -1 · famille depth · largeur 2600 u · z 0.25 à 0.9.**

Repère architectural : Deux banques de coupe-circuits et conduites.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Magasin de fret | escalier | 170 / 0.69 | Accès général |
| Station de pompage | porte | 2430 / 0.69 | Accès général |
| Galerie du refroidissement | échelle | 728 / 0.28 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `transformer` | 417 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `panel` | 770 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `transformer` | 1123 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `panel` | 1477 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cable` | 1830 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `coil` | 2183 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 988 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 1742 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Réarmer le départ habitat | 598 / 0.81 | 2 | power |
| Rétablir le circuit de secours | 988 / 0.81 | 10 | power |
| Fermer derrière le groupe | 1378 / 0.81 | 11 | seal |
| Deux circuits | 2132.0 / 0.43 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 3 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### pump — Station de pompage

**Maintenance · niveau -1 · famille depth · largeur 2400 u · z 0.25 à 0.9.**

Repère architectural : Collecteurs, vannes et caniveaux protégés.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Distribution électrique | porte | 170 / 0.69 | Accès général |
| Galerie technique | porte | 2230 / 0.69 | Accès général |
| Accès au processeur un | escalier | 672 / 0.28 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `tank` | 432 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `pipe` | 816 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `valve` | 1200 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tank` | 1584 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `valve` | 1968 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 912 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 1608 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Détourner la pression du passage | 552 / 0.81 | 8 | valve |
| Sous les logements | 1967.9999999999998 / 0.43 | Optionnel | archive |
| Réserve de terrain | 1272.0 / 0.86 | Optionnel | pickup |

#### Garde-fous de production

Conserver les retours de chacun des 3 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### service — Galerie technique

**Maintenance · niveau -1 · famille side · largeur 3000 u · z 0.7 à 0.7.**

Repère architectural : Passage sous les bâtiments, conduites continues.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Station de pompage | porte | 170 / 0.7 | Accès général |
| Laboratoire de la Compagnie | escalier | 2830 / 0.7 | Accès général |
| Garage des prospecteurs | escalier | 840 / 0.7 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `pipe` | 492 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fan` | 996 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `pipe` | 1500 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cable` | 2004 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `pipe` | 2508 / 0.22 | FIXTURES | Non | fonction propre au lieu |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Suivre les traces dans la galerie | 690 / 0.7 | 8 | scan |

#### Garde-fous de production

Conserver les retours de chacun des 3 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### road — Piste du plateau

**Périmètre · niveau 0 · famille exterior · largeur 3700 u · z 0.25 à 0.9.**

Repère architectural : Piquets de balisage, roches et ravines non praticables.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Garage des prospecteurs | sas | 170 / 0.69 | Accès général |
| Plateau des relevés | piste | 3530 / 0.69 | Accès général |
| Processeur six | piste | 1036 / 0.28 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `beacon` | 562 / 0.22 | FIXTURES | Non | orientation du trajet |
| `rock` | 1206 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rock` | 1850 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `beacon` | 2494 / 0.22 | FIXTURES | Non | orientation du trajet |
| `wreck` | 3138 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `crate` | 1406 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `rock` | 2479 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Aucun objectif fixe | — | — | Pièce de liaison |

#### Garde-fous de production

Conserver les retours de chacun des 3 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### plateau — Plateau des relevés

**Périmètre · niveau 0 · famille exterior · largeur 2900 u · z 0.25 à 0.9.**

Repère architectural : Tracteur arrêté au pied de formations rocheuses.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Piste du plateau | piste | 170 / 0.69 | Accès général |
| Seuil de l’épave | brèche | 2730 / 0.69 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `tractor` | 482 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rock` | 966 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `beacon` | 1450 / 0.22 | FIXTURES | Non | orientation du trajet |
| `rock` | 1934 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cable` | 2418 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `crate` | 1102 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `rock` | 1943 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Poser une balise sur le plateau | 667 / 0.81 | 4 | beacon |

#### Garde-fous de production

Conserver les retours de chacun des 2 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### derelict — Seuil de l’épave

**Épave · niveau 0 · famille derelict · largeur 2500 u · z 0.25 à 0.9.**

Repère architectural : Arches biomécaniques et coque affaissée.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Plateau des relevés | brèche | 170 / 0.69 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `rib` | 442 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rib` | 846 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fossil` | 1250 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rib` | 1654 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `egg` | 2058 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 950 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `rock` | 1675 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Examiner le seuil de l’épave | 575 / 0.81 | 4 | scan |
| Une coque étrangère | 2050.0 / 0.43 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 1 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume organique : les silhouettes biomécaniques provisoires ne suffisent pas à certifier la fidélité au décor. Le relief de résine et les animations des organismes doivent être remplacés/étoffés avant une validation artistique. Ne pas ajouter un boss reine détruisant la continuité de la campagne.

### processor6 — Processeur six

**Terraformage · niveau 0 · famille depth · largeur 3000 u · z 0.25 à 0.9.**

Repère architectural : Passerelle industrielle et conduites sous pression.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Piste du plateau | piste | 170 / 0.69 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `turbine` | 492 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `valve` | 996 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `turbine` | 1500 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `gantry` | 2004 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `pipe` | 2508 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 1140 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 2010 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Isoler la conduite endommagée | 690 / 0.81 | 3 | valve |
| Récupérer le rapport d’intervention | 1140 / 0.81 | 3 | terminal |
| Intervention interrompue | 2460.0 / 0.43 | Optionnel | archive |
| Réserve de terrain | 1590.0 / 0.86 | Optionnel | pickup |

#### Garde-fous de production

Conserver les retours de chacun des 1 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### approach — Accès au processeur un

**Terraformage · niveau 0 · famille exterior · largeur 3200 u · z 0.25 à 0.9.**

Repère architectural : Pylônes, sas de maintenance et énormes échangeurs.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Station de pompage | escalier | 170 / 0.69 | Accès général |
| Monte-charge du processeur | monte-charge | 3030 / 0.69 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `tower` | 512 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `beacon` | 1056 / 0.22 | FIXTURES | Non | orientation du trajet |
| `pipe` | 1600 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tower` | 2144 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `beacon` | 2688 / 0.22 | FIXTURES | Non | orientation du trajet |
| `crate` | 1216 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `rock` | 2144 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Aucun objectif fixe | — | — | Pièce de liaison |

#### Garde-fous de production

Conserver les retours de chacun des 2 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### lift — Monte-charge du processeur

**Terraformage · niveau -1 · famille side · largeur 1800 u · z 0.7 à 0.7.**

Repère architectural : Cabine de fret et paliers identifiés.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Accès au processeur un | monte-charge | 170 / 0.7 | Accès général |
| Soubassements envahis | monte-charge | 1630 / 0.7 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `cable` | 405 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `panel` | 735 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `gantry` | 1065 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `lamp` | 1395 / 0.22 | FIXTURES | Non | fonction propre au lieu |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Commander le monte-charge | 414 / 0.7 | 11 | terminal |

#### Garde-fous de production

Conserver les retours de chacun des 2 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### hive — Soubassements envahis

**Terraformage · niveau -2 · famille hive · largeur 3000 u · z 0.25 à 0.9.**

Repère architectural : Résine sur les structures industrielles, balises PDT.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Monte-charge du processeur | monte-charge | 170 / 0.69 | Accès général |
| Galerie du refroidissement | passerelle | 2830 / 0.69 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `resin` | 450 / 0.22 | FIXTURES | Non | progression de la contamination |
| `cocoon` | 870 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rib` | 1290 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `resin` | 1710 / 0.22 | FIXTURES | Non | progression de la contamination |
| `egg` | 2130 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cocoon` | 2550 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 1140 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 2010 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Retrouver la source des signaux | 690 / 0.81 | 11 | scan |
| Signaux immobiles | 2460.0 / 0.43 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 2 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume organique : les silhouettes biomécaniques provisoires ne suffisent pas à certifier la fidélité au décor. Le relief de résine et les animations des organismes doivent être remplacés/étoffés avant une validation artistique. Ne pas ajouter un boss reine détruisant la continuité de la campagne.

### coolant — Galerie du refroidissement

**Terraformage · niveau -2 · famille hive · largeur 2700 u · z 0.25 à 0.9.**

Repère architectural : Passage étroit entre les échangeurs, ruche en arrière-plan.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Soubassements envahis | passerelle | 170 / 0.69 | Accès général |
| Distribution électrique | échelle | 2530 / 0.69 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `tank` | 462 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `resin` | 906 / 0.22 | FIXTURES | Non | progression de la contamination |
| `cocoon` | 1350 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tank` | 1794 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rib` | 2238 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 1026 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 1809 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Baliser la route de repli | 621 / 0.81 | 11 | beacon |
| Aucun trophée | 2214.0 / 0.43 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 2 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume organique : les silhouettes biomécaniques provisoires ne suffisent pas à certifier la fidélité au décor. Le relief de résine et les animations des organismes doivent être remplacés/étoffés avant une validation artistique. Ne pas ajouter un boss reine détruisant la continuité de la campagne.

### vent_hab — Conduits de l’habitat

**Ventilation · niveau 1 · famille vent · largeur 2600 u · z 0.7 à 0.7.**

Repère architectural : Jonctions basses, grilles et câbles de repérage.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Logement des Jorden | conduit | 170 / 0.7 | Enfant uniquement |
| Conduits de l’infirmerie | conduit | 2430 / 0.7 | Enfant uniquement |
| Conduits des prospecteurs | conduit | 728 / 0.7 | Enfant uniquement |
| Centre de loisirs | grille | 1248 / 0.7 | Enfant uniquement |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `grille` | 452 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cable` | 876 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `grille` | 1300 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fan` | 1724 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `drawing` | 2148 / 0.22 | FIXTURES | Non | trace de vie familiale |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Retrouver les repères de Tim | 598 / 0.7 | 7 | trace |
| Vérifier le chemin de retour | 988 / 0.7 | 16 | trace |

#### Garde-fous de production

Conserver les retours de chacun des 4 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Conduit : Newt reste sans arme. Aucun adulte ne franchit les liens marqués enfant uniquement. La cache n’est pas un point de sortie de la planète. La hauteur visuelle du volume et la reptation complète demandent encore une passe artistique.

### vent_med — Conduits de l’infirmerie

**Ventilation · niveau 1 · famille vent · largeur 2400 u · z 0.7 à 0.7.**

Repère architectural : Grilles d’observation et courbe de service.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Conduits de l’habitat | conduit | 170 / 0.7 | Enfant uniquement |
| Chambre d’isolement | grille | 2230 / 0.7 | Enfant uniquement |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `grille` | 480 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cable` | 960 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `grille` | 1440 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `pipe` | 1920 / 0.22 | FIXTURES | Non | fonction propre au lieu |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Écouter derrière la grille | 552 / 0.7 | 7 | listen |

#### Garde-fous de production

Conserver les retours de chacun des 2 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Conduit : Newt reste sans arme. Aucun adulte ne franchit les liens marqués enfant uniquement. La cache n’est pas un point de sortie de la planète. La hauteur visuelle du volume et la reptation complète demandent encore une passe artistique.

### vent_survey — Conduits des prospecteurs

**Ventilation · niveau 0 · famille vent · largeur 2350 u · z 0.7 à 0.7.**

Repère architectural : Grille de secours au-dessus de la dernière barricade.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Conduits de l’habitat | conduit | 170 / 0.7 | Enfant uniquement |
| Bureau des prospecteurs | grille | 2180 / 0.7 | Enfant uniquement |
| Cache des conduits | conduit | 658 / 0.7 | Enfant uniquement |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `grille` | 474 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cable` | 941 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `grille` | 1409 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `resin` | 1876 / 0.22 | FIXTURES | Non | progression de la contamination |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Passer sans attirer la créature | 540 / 0.7 | 15 | listen |

#### Garde-fous de production

Conserver les retours de chacun des 3 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Conduit : Newt reste sans arme. Aucun adulte ne franchit les liens marqués enfant uniquement. La cache n’est pas un point de sortie de la planète. La hauteur visuelle du volume et la reptation complète demandent encore une passe artistique.

### refuge — Cache des conduits

**Ventilation · niveau 0 · famille vent · largeur 1750 u · z 0.7 à 0.7.**

Repère architectural : Petit renfoncement hors des axes de ventilation.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Conduits des prospecteurs | conduit | 170 / 0.7 | Enfant uniquement |
| Buanderie | grille | 1580 / 0.7 | Enfant uniquement |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `toy` | 399 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `blanket` | 716 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `ration` | 1034 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `drawing` | 1351 / 0.22 | FIXTURES | Non | trace de vie familiale |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Préparer une petite cache | 402 / 0.7 | 7 | stash |
| Regagner la cache | 665 / 0.7 | 16 | stash |
| La petite cache | 1435.0 / 0.7 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 2 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Conduit : Newt reste sans arme. Aucun adulte ne franchit les liens marqués enfant uniquement. La cache n’est pas un point de sortie de la planète. La hauteur visuelle du volume et la reptation complète demandent encore une passe artistique.

### hangar — Hangar scientifique

**Recherche · niveau 0 · famille depth · largeur 3300 u · z 0.25 à 0.9.**

Repère architectural : Navette de service, passerelle et réserves de carburant.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Laboratoire de la Compagnie | sas | 170 / 0.69 | Accès scientifique |
| Navette de la Compagnie | passerelle | 3130 / 0.69 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `shuttle` | 522 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fuel` | 1086 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `gantry` | 1650 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` | 2214 / 0.22 | FIXTURES | Non | poste de travail |
| `pallet` | 2778 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 1254 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 2211 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Déverrouiller la navette scientifique | 759 / 0.81 | 13 | terminal |
| Vérifier l’embarquement | 1254 / 0.81 | 14 | talk |
| Accès réservé | 2706.0 / 0.43 | Optionnel | archive |
| Réserve de terrain | 1749.0 / 0.86 | Optionnel | pickup |

#### Garde-fous de production

Conserver les retours de chacun des 2 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### shuttle — Navette de la Compagnie

**Recherche · niveau 0 · famille side · largeur 2150 u · z 0.7 à 0.7.**

Repère architectural : Sas arrière, sièges et commandes de navigation.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Hangar scientifique | passerelle | 170 / 0.7 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `seat` | 407 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `seat` | 741 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` | 1075 / 0.22 | FIXTURES | Non | poste de travail |
| `screen` | 1409 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `hatch` | 1743 / 0.22 | FIXTURES | Non | fonction propre au lieu |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Désengager la trajectoire automatique | 494 / 0.7 | 14 | terminal |
| Décoller | 817 / 0.7 | 14 | launch |
| Quatre sièges occupés | 1763.0 / 0.7 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 1 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### wash — Buanderie

**Habitat · niveau 0 · famille depth · largeur 1850 u · z 0.25 à 0.9.**

Repère architectural : Machines, linge abandonné et évier de service.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Cache des conduits | grille | 170 / 0.69 | Enfant uniquement |
| Réfectoire | porte | 1680 / 0.69 | Accès général |
| Coursive résidentielle | escalier | 518 / 0.28 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `washer` | 377 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `washer` | 651 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `linen` | 925 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `sink` | 1199 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `washer` | 1473 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `machine` | 703 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` | 1240 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Récupérer de l’eau | 426 / 0.81 | 15 | supply |
| L’eau du lendemain | 1517.0 / 0.43 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 3 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### relay — Relais de communications

**Administration · niveau 1 · famille side · largeur 1950 u · z 0.7 à 0.7.**

Repère architectural : Baie relais et émetteurs directionnels.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Salle des archives | coursive | 170 / 0.7 | Accès général |
| Contrôle colonial | coursive | 1780 / 0.7 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `rack` | 424 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `antenna` | 791 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` | 1159 / 0.22 | FIXTURES | Non | poste de travail |
| `rack` | 1526 / 0.22 | FIXTURES | Non | fonction propre au lieu |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Ligne sans réponse | 1599.0 / 0.7 | Optionnel | archive |

#### Garde-fous de production

Conserver les retours de chacun des 2 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

### clinic_store — Réserve médicale

**Médical · niveau 0 · famille side · largeur 1700 u · z 0.7 à 0.7.**

Repère architectural : Tiroirs de soins et stockage réfrigéré.

#### Accès et continuité

| Destination | Type | x / z | Condition |
|---|---|---|---|
| Infirmerie | porte | 170 / 0.7 | Accès général |

#### Fonction des éléments placés

| Élément | x / z | Couche | Collision | Fonction |
|---|---|---|---|---|
| `medicine` | 392 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `shelf` | 698 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fridge` | 1002 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `medicine` | 1308 / 0.22 | FIXTURES | Non | fonction propre au lieu |

#### Points d’interaction

| Objet | x / z | Chapitre | Fonction |
|---|---|---|---|
| Prendre les soins d’urgence | 391 / 0.7 | 9 | supply |
| Dernière réserve | 1394.0 / 0.7 | Optionnel | archive |
| Réserve de terrain | 901.0 / 0.7 | Optionnel | pickup |

#### Garde-fous de production

Conserver les retours de chacun des 1 passages ; ne pas déplacer uniquement le dessin d’une porte. Vérifier son point d’arrivée et sa zone d’interaction après chaque retouche.

Ne pas poser un élément solide sur un objet de quête, un seuil ou une zone d’apparition. Préserver le chemin entre les deux côtés des couvertures. Les éléments de fond doivent rester attachés à leur plan lorsque la caméra défile. Les meubles ordinaires doivent rester reconnaissables après la crise ; ne pas les remplacer tous par des caisses.

Volume colonial : conserver un usage humain crédible et distinguer circulation, rangement et poste de travail. La foule d’ambiance actuelle est simplifiée et ne représente pas encore des habitants à horaires et dialogues individuels.

## Validation et étapes restantes

Les résultats exécutés sont dans `CORE_TEST_RESULTS.json`, `TRAVERSAL_RESULTS.json`, `INSTALLER_TEST_RESULTS.json` et `BROWSER_TEST_RESULTS.json`. Une validation de graphe ou de collision ne vaut pas validation artistique.

Priorités suivantes : intégration au moteur natif et aux atlas partagés ; reprise des proportions et silhouettes du décor ; scènes jouables plus longues et moins dépendantes d’une simple interaction temporisée ; comportement protecteur et vulnérabilité des escortés ; lecture détaillée du roman pour un rapprochement scène par scène. Aucune de ces tâches n’est déclarée déjà terminée.
