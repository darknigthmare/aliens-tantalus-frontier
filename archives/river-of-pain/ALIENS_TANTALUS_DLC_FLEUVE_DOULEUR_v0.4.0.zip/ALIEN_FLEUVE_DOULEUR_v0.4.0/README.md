# Alien — Fleuve de la Douleur · 0.4.0-candidate.1

## Hadley’s Hope · Le seuil du silence

Cette archive est la suite cumulative de la 0.3. Elle contient le DLC jouable autonome, ses sources, son codex, ses tests et ses captures. **Ce n’est pas le jeu Tantalus complet ni une intégration à son moteur natif.**

### Jouer

Extraire toute l’archive. Ouvrir `JOUER.html`, ou `LANCER_WINDOWS.bat` sous Windows. Le HTML autonome ne demande ni installation Node ni accès réseau. Une politique d’entreprise ou de navigateur peut bloquer certains fichiers locaux ; aucun contournement de sécurité n’est intégré. L’import/export JSON reste la méthode de transfert entre versions.

Pour servir les fichiers sur une machine autorisant un serveur local, `python tools/serve.py` affiche une adresse à ouvrir dans le navigateur. Cette commande est fournie mais sa navigation HTTP a été bloquée dans l’environnement de recette.

### Reprendre une sauvegarde

Depuis l’ancienne version, Pause → EXPORTER. Dans cette version, Pause → IMPORTER, choisir le JSON et confirmer CHARGER. Les fichiers réels 0.1, 0.2 et 0.3 ont été testés. Le moteur accepte aussi un export 0.4 en plein trajet ; il reprend la portion restante.

La sauvegarde locale alterne deux copies validées et lit encore l’ancienne clé sans la réécrire. La persistance native après fermeture n’a pas été qualifiée dans le navigateur de test : conserver un export JSON reste utile. Une erreur de stockage est affichée, pas transformée en fausse confirmation.

### Commandes

| Action | Commande |
|---|---|
| Marcher / profondeur | Q D / Z S, ou flèches |
| Interagir / passer une porte | E |
| Écouter un seuil / dossier des relevés | N / O |
| Tir / visée sur place | F / ESPACE + directions |
| Pointer et tirer | Bouton gauche maintenu |
| Se baisser / courir | C / Maj |
| Lampe / détecteur marine | L / T |
| Cachette / soudure | G / B |
| Équipement / détours | I / U |
| Plan / pause | Tab / Échap |
| Soins / fusée / rechargement | H / X / R |
| Repère de repli | M |

Newt et Anne n’obtiennent ni arme ni détecteur. Pendant la préparation d’un franchissement, bouger l’annule ; une fois engagé, le trajet se termine sans déplacement libre. Le dossier et le plan mettent la lecture en pause ; l’écoute sur le terrain ne le fait pas.

### Ce qui est ajouté

21 liaisons temporisées (4 sas, 12 escalier, 3 échelle, 2 monte-charge), dont deux liaisons de monte-charge avec secours automatique si le circuit est coupé. Écoute exposée de 1,6 s, douze relevés conservés, échos du détecteur à travers un accès voisin autorisé. Copie locale de secours et préférences de lecture : contraste, 100/115/130 %, animations atténuées.

Les 42 pièces, 57 liens, 49 objectifs, six détours et 30 documents restent présents. Les 489 props sont des placements, pas des sprites uniques. Voir `docs/CODEX_LEVEL_DESIGN.md` pour les emprises, points de retour et temps de chaque raccord.

### Lanceur facultatif pour Tantalus

Sur une copie locale du projet hôte :

```sh
node tools/install.mjs /chemin/vers/tantalus
node tools/install.mjs /chemin/vers/tantalus --upgrade
node tools/install.mjs /chemin/vers/tantalus --remove
```

L’installateur ajoute un répertoire et un accès au menu. Il ne remplace ni `src/app.js`, ni le catalogue, ni les sauvegardes hôtes. `--upgrade` accepte les versions précédentes reconnues et intactes ; un conflit ou une modification personnelle provoque un refus. La vraie montée 0.3 → 0.4 est éprouvée sur un shell de test, pas sur le dépôt natif complet. Aucun push ni déploiement.

### Sources et recette reproductible

Node 20 ou supérieur pour les tests du modèle ; Python 3 pour la reconstruction. Les tests navigateur demandent Playwright pour Python et un Chromium local. `CHROMIUM_PATH` permet de changer le chemin du binaire ; défaut `/usr/bin/chromium`. L’archive ne fournit pas ces logiciels.

```sh
npm run build
npm test
npm run test:browser
node tests/upgrade-real.mjs /chemin/vers/la/0.3.0/originale
npm run docs
python tools/verify-delivery.py
python tools/package-release.py
```

`RAPPORT_ILLUSTRE.html` embarque ses captures ; `docs/QA_REPORT.md` décrit les limites. Les JSON contiennent les résultats détaillés. `docs/history/v03/` est l’historique, pas une certification de cette version.

DLC autonome avec lanceur additionnel, pas le jeu Tantalus complet ni son GameEngine natif. Aucun push GitHub ni déploiement Vercel. Dessins stylisés par code, pas atlas définitifs ou reconstitution 1:1. Roman intégral non consulté : plans, dialogues, tâches et documents sont une condensation originale. L’écho Frontière 2204 et les sauvegardes du moteur hôte ne sont pas modifiés.
