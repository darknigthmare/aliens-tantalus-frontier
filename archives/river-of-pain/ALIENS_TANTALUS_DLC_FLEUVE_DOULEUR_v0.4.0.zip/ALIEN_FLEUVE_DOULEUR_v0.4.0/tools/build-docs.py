#!/usr/bin/env python3
"""Generate 0.4 room codex and illustrated delivery report from the shipped data and completed QA.
Refuses incomplete or failed suites. Standard library only; does not publish anything.
"""
from pathlib import Path
from html import escape
from collections import Counter
import base64, json, hashlib, re
R=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((R/'docs'/n).read_text(encoding='utf-8'))
D=read('CONTENT_MANIFEST.json');rooms={r['id']:r for r in D['rooms']};m=D['manifest'];v=m['version'];cnt=m['counts']
assert v=='0.4.0-candidate.1'
fmt=lambda n: str(round(n,3)).rstrip('0').rstrip('.') if isinstance(n,float) else str(n)
cell=lambda s:str(s).replace('|',' / ').replace('\n',' ')
limitations='DLC autonome avec lanceur additionnel, pas le jeu Tantalus complet ni son GameEngine natif. Aucun push GitHub ni déploiement Vercel. Dessins stylisés par code, pas atlas définitifs ou reconstitution 1:1. Roman intégral non consulté : plans, dialogues, tâches et documents sont une condensation originale. L’écho Frontière 2204 et les sauvegardes du moteur hôte ne sont pas modifiés.'
model_names=['CORE_TEST_RESULTS','COLONY_TEST_RESULTS','EXPLORATION_TEST_RESULTS','PASSAGES_TEST_RESULTS','PERSISTENCE_TEST_RESULTS']
browser_names=['BROWSER_TEST_RESULTS','BROWSER_V02_TEST_RESULTS','BROWSER_V03_TEST_RESULTS','BROWSER_V04_TEST_RESULTS']
reports={n:read(n+'.json') for n in model_names+browser_names+['INSTALLER_TEST_RESULTS','REAL_UPGRADE_TEST_RESULTS']}
for n,r in reports.items():
 if not r.get('passed'):raise RuntimeError('Recette incomplète ou en échec : '+n)
 if r.get('version',v)!=v:raise RuntimeError('Rapport d’une autre version : '+n)
tr=read('TRAVERSAL_RESULTS.json');alltr=read('TRAVERSAL_EXPLORATION_RESULTS.json')
assert len(tr)==len(alltr)==6 and all(r['passed'] for r in tr+alltr)
assert all(r['visited']==42 and len(r['detours'])==6 for r in alltr)
num=lambda n:reports[n]['cases'] if isinstance(reports[n]['cases'],int) else len(reports[n]['cases'])
model=sum(num(n) for n in model_names);browser=sum(num(n) for n in browser_names)
caprows=sum((reports[n]['captures'] for n in browser_names),[]);caps={Path(c['file']).name:c for c in caprows}
assert len(caps)==len(caprows)
for c in caprows:assert (R/c['file']).is_file() and c.get('setup')
timings={'escalier':(.45,1.4),'échelle':(.5,1.8),'monte-charge':(1.2,2.4),'sas':(1.1,1.1)}
seen=set();links=[]
for r in D['rooms']:
 for p in r['portals']:
  key=tuple(sorted([r['id'],p['to']]))
  if key in seen:continue
  seen.add(key)
  if p['kind'] in timings:links.append((r,p))
assert len(links)==21
by_kind=Counter(p['kind'] for _,p in links)
principles=(R/'docs/DOCTRINE_V04.md').read_text(encoding='utf-8')
lines=['# ALIEN — Fleuve de la Douleur','',f'## Codex de level design · {v}','',m['subtitle'],'',limitations,'',principles]
lines += ['## Registre des 21 liaisons temporisées','', 'Les liaisons ci-dessous se parcourent dans les deux sens. Les points de départ et de retour détaillés dans chaque fiche de pièce restent les coordonnées de référence. Les temps sont des secondes de simulation, pas des mesures du film ou du roman.','', '| Origine | Destination | Nature | Niveaux | Préparation exposée | Trajet engagé |','|---|---|---|---|---:|---:|']
for r,p in links:
 b,t=timings[p['kind']];lines += [f"| {r['name']} | {rooms[p['to']]['name']} | {p['kind']} | {r['floor']} → {rooms[p['to']]['floor']} | {fmt(b)} s | {fmt(t)} s |"]
lines += ['','## Registre des six détours','']
for j in D['jobs']:
 r=rooms[j['room']];free=next(p for p in r['portals'] if not p['requires']);gate=next(p for p in r['portals'] if p['requires'])
 lines += [f"### {j['title']} · `{j['id']}`",'',f"**{r['name']} · {'Newt seule' if j['childOnly'] else 'Personnage adulte'}**",'',j['steps'][0]['description'],'',f"Boucle : {rooms[free['to']]['name']} → {r['name']} → {rooms[gate['to']]['name']}. L’entrée depuis {rooms[free['to']]['name']} ne demande pas d’avoir déjà ouvert la sortie.",'','| Étape | Salle | Action | x / z | Temps sur place |','|---|---|---|---|---|']
 for i,t in enumerate(j['steps']):lines.append(f"| {i+1} | {rooms[t['room']]['name']} | {t['label']} | {fmt(t['x'])} / {fmt(t['z'])} | {t['duration']} s |")
 reward={'medkit':'une trousse de soins','flare':'deux fusées','battery':'réserve de lampe remise à 100 %','food':'25 points de santé, maximum 100'}[j['reward']]
 a=next(a for a in D['archives'] if a['id']==j['archive'])
 lines += ['',f"Pièce emportée : **{j['item']}**. La pose exige cette étape, le bon personnage et la proximité. L’éloignement ou une blessure interrompt la pose sans effacer la pièce.",'',f"Effet : `{j['flag']}` autorise les deux portails. Récompense : {reward}, une seule fois ; document `{a['id']}` — {a['title']}. Le compteur de campagne principale ne change pas.",'']
lines += ['## Rencontres ajoutées et annonce','', '| ID / pièce | Nature | Stade minimum | Seuil x | Ancrage x / z | Préavis |','|---|---|---:|---:|---|---:|']
for e in D['encounters']:lines.append(f"| `{e['id']}` / {rooms[e['room']]['name']} | {e['type']} | {e['minPhase']} | {e['triggerX']} | {e['spawnX']} / {e['spawnZ']} | {e['warning']} s |")
for e in D['encounters']:lines += ['',f"**{e['id']}** — {e['label']}"]
lines += ['','## Campagne principale : 49 objectifs conservés','']
for c in D['chapters']:
 lines += [f"### {c['index']+1:02d} — {c['title']}",'',f"**{D['characters'][c['character']]['name']} · {c['timeLabel']} · {rooms[c['start']]['name']}**",'',c['synopsis'],'','| Ordre | Lieu | Action réelle | Type |','|---|---|---|---|']
 for i,t in enumerate(c['objectives']):
  o=next(o for o in rooms[t['room']]['objects'] if o['id']==t['id']);lines.append(f"| {i+1} | {rooms[t['room']]['name']} | {o['label']} | `{o['kind']}` |")
 lines += ['',f"Dialogue original de jeu : **{c['dialogue']['speaker']}** — « {c['dialogue']['text']} »",'']
lines += ['## Tableaux et collecteurs : solutions de recette','']
for bid,b in D['boards'].items():
 lines += [f"### {b['title']} · `{bid}`",'',f"{rooms[b['room']]['name']} · circuit `{b['circuit']}` · capacité {b['capacity']}.",'',b['hint'],'','| Commande | Charge | État requis | Initial |','|---|---:|---|---|']
 for i,c in enumerate(b['channels']):lines.append(f"| {c[0]} | {c[1]} | {'Actif' if c[2] else 'Coupé'} | {'Actif' if b['initial'][i] else 'Coupé'} |")
 lines += ['']
lines += ['## Les 42 fiches de pièce','']
for r in D['rooms']:
 a=r['architecture'];lines += [f"### {r['name']} · `{r['id']}`",'',f"**{r['building']} · niveau {r['floor']} · {r['kind']} · {r['width']} unités · z {r['minZ']}–{r['maxZ']}**",'',f"Repère d’orientation : {r['landmark']}. Profil `{a['style']}` / `{a['variant']}`, circuit `{a['circuit']}`, emprise `{r['layoutProfile']}`.",'',f"Blocage métrique déclaré : {r['dimensionsM']} ; intention originale, pas mesure du roman. {a['wallModules']} travées murales déclarées. Les facteurs de parallaxe d’architecture sont des métadonnées de production, pas tous des variables autonomes du renderer.",'','#### Entrées, retours et droits','', '| Sortie | Nature | Départ x / z | Retour x / z | Condition |','|---|---|---|---|---|']
 for p in r['portals']:
  back=next(q for q in rooms[p['to']]['portals'] if q['to']==r['id']);cond=('Newt ; ' if p['childOnly'] else '')+(p['requires'] or 'Libre')
  lines.append(f"| {rooms[p['to']]['name']} | {p['kind']} | {fmt(p['x'])} / {fmt(p['z'])} | {fmt(back['x'])} / {fmt(back['z'])} | {cond} |")
 for p in r['portals']:
  if p['kind'] in timings:
   board,travel=timings[p['kind']]
   extra=' Circuit coupé : +1,6 s de trajet.' if p['kind']=='monte-charge' else ''
   lines += ['',f"Raccord vers **{rooms[p['to']]['name']}** : préparation exposée {fmt(board)} s, puis trajet borné {fmt(travel)} s.{extra} Arrivée au portail inverse ; annulation par mouvement ou blessure avant engagement. Les menus ne permettent pas de contourner les droits d’accès."]
 lines += ['', 'Lecture des seuils : les observations sont datées, locales et non garanties. L’écoute ne rend pas cette pièce sûre. Les emprises et points de retour ci-dessous restent la référence de placement.']
 lines += ['','#### Obstacles : emprise commune au rendu et au moteur','', '| ID | Nature | Centre x / z | Largeur / profondeur |','|---|---|---|---|']
 if not r['cover']:lines += ['| Aucun | Passage latéral dégagé | — | — |']
 for c in r['cover']:lines.append(f"| `{c['id']}` | {c['prop']} | {fmt(c['x'])} / {fmt(c['z'])} | {fmt(c['w'])} / {fmt(c['d'])} |")
 lines += ['','#### Décors : fonction avant densité','', '| ID / objet | x / z | Couche | Solide | Rôle et placement |','|---|---|---|---|---|']
 for p in r['props']:lines.append(f"| `{p['id']}` / {p['kind']} | {fmt(p['x'])} / {fmt(p['z'])} | {p['layer']} | {'Oui' if p['collidable'] else 'Non'} | {cell(p['purpose'])} |")
 lines += ['','#### Interactions et cachettes','', '| ID / action | x / z | Condition d’apparition | Type |','|---|---|---|---|']
 for o in r['objects']:
  cond='Chapitre '+str(o['chapter']+1) if 'chapter' in o else 'Détour '+o['job']+' / étape '+str(o['step']+1) if o['kind']=='side-task' else 'Facultatif'
  lines.append(f"| `{o['id']}` · {cell(o['label'])} | {fmt(o['x'])} / {fmt(o['z'])} | {cond} | {o['kind']} |")
 if r['phaseDressing']:
  lines += ['','#### État de crise visible','', '| Élément | x / z | Stade minimum |','|---|---|---:|']
  for q in r['phaseDressing']:lines.append(f"| {q['kind']} | {fmt(q['x'])} / {fmt(q['z'])} | {q['fromPhase']} |")
 for h in D['hazards']:
  if h['room']==r['id']:lines += ['',f"Danger local `{h['id']}` : x {h['x']}, z {h['z']}. Valeurs de recette : `{json.dumps(h,ensure_ascii=False)}`."]
 for e in D['encounters']:
  if e['room']==r['id']:lines += ['',f"Rencontre `{e['id']}` : annonce de {e['warning']} s au passage x ≥ {e['triggerX']}, à partir du stade {e['minPhase']}. Consulter son état de sauvegarde avant tout ajout d’ennemi."]
 lines += ['','#### Garde-fous de cette pièce','',f"Les {len(r['portals'])} retours, {len(r['objects'])} points d’interaction et {len(r['cover'])} obstacles sont issus du même contenu que le runtime. La recette géométrique a marché de l’entrée vers chaque point dans les deux vues. Elle contrôle l’accessibilité, pas une partie humaine complète ni l’équilibrage de chaque rencontre.",'', 'Ne pas ajouter de collision aux accessoires muraux sans modifier le plan local et relancer la recette. Ne pas déplacer un seuil sans déplacer son point de retour. Ne pas transformer un décor d’observation en porte non documentée. Préserver la bande z = 0,7 pour le mode classique.','']
lines += ['## Documents originaux','']
for a in D['archives']:
 lines += [f"### {a['id']} — {a['title']}",'',str(a.get('text',a.get('body',''))),'']
lines += ['## Qualification courante','',f'{model} groupes/cas du modèle, dont {num("PASSAGES_TEST_RESULTS")} pour les seuils et {num("PERSISTENCE_TEST_RESULTS")} pour le stockage abstrait. Douze parcours complets retestés. {num("INSTALLER_TEST_RESULTS")} cas d’installateur sur projets de test et {num("REAL_UPGRADE_TEST_RESULTS")} avec les vrais fichiers 0.3. {browser} contrôles dans Chromium et {len(caps)} captures décrites. Voir QA_REPORT.md pour les périmètres et limites.','',limitations]
codex='\n'.join(lines)+'\n';(R/'docs/CODEX_LEVEL_DESIGN.md').write_text(codex,encoding='utf-8')
qa=f'''# Qualification locale — {v}

Les valeurs ci-dessous sont relues depuis les résultats exécutés sur cette version. Aucun total historique n’est utilisé pour annoncer une réussite courante. Les documents sous `history/` décrivent les livraisons précédentes et ne qualifient pas cette archive.

| Suite exécutée | Réussite | Portée |
|---|---:|---|
| core.cjs | {num('CORE_TEST_RESULTS')}/{num('CORE_TEST_RESULTS')} | États, contenu courant, sauvegarde, collisions et interactions héritées |
| colony.cjs | {num('COLONY_TEST_RESULTS')}/{num('COLONY_TEST_RESULTS')} | Tableaux, cachettes, lampe, soudures, ressources et escortes |
| exploration.cjs | {num('EXPLORATION_TEST_RESULTS')}/{num('EXPLORATION_TEST_RESULTS')} | Détours, empreintes, géométrie 42 pièces × 2 vues, visée et mémoire |
| passages.cjs | {num('PASSAGES_TEST_RESULTS')}/{num('PASSAGES_TEST_RESULTS')} | 84 franchissements orientés (21 × 2 sens × 2 vues), annulation, secours, escorte, import en trajet, écoute, limites du détecteur et migrations |
| persistence.cjs | {num('PERSISTENCE_TEST_RESULTS')}/{num('PERSISTENCE_TEST_RESULTS')} | Stockage mémoire simulé : alternance, somme de contrôle, copies tronquées, quota, refus d’écrasement et anciennes clés |
| traversal.cjs | 6/6 | Parcours principal : deux vues × trois difficultés |
| traversal-exploration.cjs | 6/6 | 42 pièces, 49 objectifs, deux escortes, six détours et raccourcis aller/retour |
| installer.mjs | {num('INSTALLER_TEST_RESULTS')}/{num('INSTALLER_TEST_RESULTS')} | Projets de test, installation, idempotence, conflits, restauration, chemins dangereux et montées de version simulées |
| upgrade-real.mjs | {num('REAL_UPGRADE_TEST_RESULTS')}/{num('REAL_UPGRADE_TEST_RESULTS')} | Vrais modules et installateur de l’archive 0.3 sur un shell hôte de test, puis 0.4 et restauration |
| browser.py | {num('BROWSER_TEST_RESULTS')}/{num('BROWSER_TEST_RESULTS')} | Début au clavier, véritable export, menu/plan, tailles et relâchement tactile émulé |
| browser-v02.py | {num('BROWSER_V02_TEST_RESULTS')}/{num('BROWSER_V02_TEST_RESULTS')} | Régression de l’équipement, tableaux, accompagnement et véritable fichier 0.1 |
| browser-v03.py | {num('BROWSER_V03_TEST_RESULTS')}/{num('BROWSER_V03_TEST_RESULTS')} | Régression des détours, cartes, intrusions, visée et véritable fichier 0.2 |
| browser-v04.py | {num('BROWSER_V04_TEST_RESULTS')}/{num('BROWSER_V04_TEST_RESULTS')} | Véritable fichier 0.3, quatre raccords, copie JSON en plein trajet, écoute/échos, Newt et options de lecture |

Total du modèle : **{model}/{model}**. Total navigateur : **{browser}/{browser}**, sans erreur JavaScript relevée. Ces compteurs désignent des assertions ou groupes de tests, pas autant de sessions humaines.

## Ce que les parcours complets prouvent

Les douze pilotes utilisent `Simulation.update`, les déplacements et les commandes du modèle. Ils n’appellent pas de validation forcée des objectifs, ne téléportent pas le personnage et ne réécrivent pas sa santé. Les soins autorisés et l’assistance de chapitre restent actifs. Ils connaissent les chemins et les solutions ; ce ne sont pas des joueurs découvrant les niveaux. Les six détours adultes sont réalisés tôt par le pilote, pas éprouvés comme une campagne humaine tardive. Les nouvelles écoutes et les cas extrêmes de détecteur sont éprouvés séparément dans les fixtures, pas revendiqués comme pratiqués à chaque seuil pendant chaque parcours.

Les 84 passages orientés préparent volontairement l’état nécessaire (personnage, accès débloqués) avant d’utiliser E et le temps du modèle. Ce sont des tests localisés, pas 84 parcours entiers. Les règles de sauvegarde refusent les états incohérents.

## Captures et navigateur

Les {len(caps)} captures sont produites par Chromium exécutant le HTML autonome exact. Le début de jeu a été actionné au clavier. Les scènes tardives sont des sauvegardes préparées, validées puis importées par l’interface. Les fichiers JSON associés donnent leur pièce, chapitre et méthode d’initialisation. Une association de test ne constitue pas un nouvel événement canonique du roman. Le rapport ne substitue aucune illustration d’intention à un écran de jeu.

Le CLI agent-browser était absent. La navigation HTTP locale a renvoyé `net::ERR_BLOCKED_BY_ADMINISTRATOR`. La recette a donc utilisé Playwright et `page.set_content` sans modifier l’origine ni la politique du navigateur. Aucune requête externe n’est nécessaire au HTML autonome. Les suites ont été rejouées séquentiellement après un premier lancement trop long ; les résultats retenus sont les exécutions achevées. Le rendu desktop est fermé avant le contexte tactile indépendant pour libérer ses ressources.

## Sauvegarde : distinction indispensable

Les essais de copies altérées et de quota utilisent un objet `MemoryStorage` de test : ils qualifient le protocole, pas localStorage natif. La fermeture/réouverture du navigateur, les quotas réels, l’onglet concurrent et les politiques de navigation privée restent non qualifiés. Le vrai téléchargement EXPORTER et le vrai import par sélecteur de fichier sont éprouvés, y compris au milieu d’une cabine engagée : arrivée unique et santé du compagnon conservée.

Les fichiers `real-v01-save.json`, `real-v02-save.json` et `real-v03-save.json` sont des exports provenant des livraisons précédentes, pas des objets récents renommés. L’import les migre sans changer leurs objectifs ou munitions. Les préférences sont appliquées dans le DOM, mais leur persistance après fermeture n’est pas qualifiée.

## Corrections issues de cette recette

La réserve de pompage `cache-pump` a été déplacée de x = 1272 à 1450 pour ne plus intercepter l’interaction de l’échelle en vue latérale. Les anciennes recettes navigateur qui attendaient une transition immédiate attendent désormais l’arrivée réelle. Le HUD de combat se masque pendant le trajet engagé ; le vieux message d’annulation est retiré au départ suivant. L’échelle ne laisse plus l’arme dessinée en main. Les numéros dans le puits désignent des guidages, pas des étages supplémentaires fictifs. Les réglages portrait ont été contrôlés avec un texte à 130 %.

## Limites de production

Raccord animé borné, pas puits continu exploratoire. Combat normal suspendu pendant le trajet engagé ; préparation et écoute exposées. Pièces hors champ non simulées en continu. Pas de véhicule pilotable. Pas d’essai sur manette physique, téléphone réel, Safari/iPhone, coopération réseau ou moteur Tantalus natif. Pas d’évaluation humaine de difficulté/durée ou de bande-son définitive.

{limitations}
'''
(R/'docs/QA_REPORT.md').write_text(qa,encoding='utf-8')
readme=f'''# Alien — Fleuve de la Douleur · {v}

## Hadley’s Hope · Le seuil du silence

Cette archive est la suite cumulative de la 0.3. Elle contient le DLC jouable autonome, ses sources, son codex, ses tests et ses captures. **Ce n’est pas le jeu Tantalus complet ni une intégration à son moteur natif.**

### Jouer

Extraire toute l’archive. Ouvrir `JOUER.html`, ou `LANCER_WINDOWS.bat` sous Windows. Le HTML autonome ne demande ni installation Node ni accès réseau. Une politique d’entreprise ou de navigateur peut bloquer certains fichiers locaux ; aucun contournement de sécurité n’est intégré. L’import/export JSON reste la méthode de transfert entre versions.

Pour servir les fichiers sur une machine autorisant un serveur local, `python tools/serve.py` affiche une adresse à ouvrir dans le navigateur. Cette commande est fournie mais sa navigation HTTP a été bloquée dans l’environnement de recette.

### Reprendre une sauvegarde

Depuis l’ancienne version, Pause → EXPORTER. Dans cette version, Pause → IMPORTER, choisir le JSON et confirmer CHARGER. Les fichiers réels 0.1, 0.2 et 0.3 ont été testés. Le moteur accepte aussi un export 0.4 en plein trajet ; il reprend la portion restante.

La sauvegarde locale alterne deux copies validées et lit encore l’ancienne clé sans la réécrire. La persistance native après fermeture n’a pas été qualifiée dans le navigateur de test : conserver un export JSON reste utile. Une erreur de stockage est affichée, pas transformée en fausse confirmation.

### Commandes

| Action | Commande |
|---|---|
| Marcher / profondeur | Q D / Z S, ou flèches |
| Interagir / passer une porte | E |
| Écouter un seuil / dossier des relevés | N / O |
| Tir / visée sur place | F / ESPACE + directions |
| Pointer et tirer | Bouton gauche maintenu |
| Se baisser / courir | C / Maj |
| Lampe / détecteur marine | L / T |
| Cachette / soudure | G / B |
| Équipement / détours | I / U |
| Plan / pause | Tab / Échap |
| Soins / fusée / rechargement | H / X / R |
| Repère de repli | M |

Newt et Anne n’obtiennent ni arme ni détecteur. Pendant la préparation d’un franchissement, bouger l’annule ; une fois engagé, le trajet se termine sans déplacement libre. Le dossier et le plan mettent la lecture en pause ; l’écoute sur le terrain ne le fait pas.

### Ce qui est ajouté

21 liaisons temporisées ({', '.join(f'{n} {k}' for k,n in by_kind.items())}), dont deux liaisons de monte-charge avec secours automatique si le circuit est coupé. Écoute exposée de 1,6 s, douze relevés conservés, échos du détecteur à travers un accès voisin autorisé. Copie locale de secours et préférences de lecture : contraste, 100/115/130 %, animations atténuées.

Les 42 pièces, 57 liens, 49 objectifs, six détours et 30 documents restent présents. Les 489 props sont des placements, pas des sprites uniques. Voir `docs/CODEX_LEVEL_DESIGN.md` pour les emprises, points de retour et temps de chaque raccord.

### Lanceur facultatif pour Tantalus

Sur une copie locale du projet hôte :

```sh
node tools/install.mjs /chemin/vers/tantalus
node tools/install.mjs /chemin/vers/tantalus --upgrade
node tools/install.mjs /chemin/vers/tantalus --remove
```

L’installateur ajoute un répertoire et un accès au menu. Il ne remplace ni `src/app.js`, ni le catalogue, ni les sauvegardes hôtes. `--upgrade` accepte les versions précédentes reconnues et intactes ; un conflit ou une modification personnelle provoque un refus. La vraie montée 0.3 → 0.4 est éprouvée sur un shell de test, pas sur le dépôt natif complet. Aucun push ni déploiement.

### Sources et recette reproductible

Node 20 ou supérieur pour les tests du modèle ; Python 3 pour la reconstruction. Les tests navigateur demandent Playwright pour Python et un Chromium local. `CHROMIUM_PATH` permet de changer le chemin du binaire ; défaut `/usr/bin/chromium`. L’archive ne fournit pas ces logiciels.

```sh
npm run build
npm test
npm run test:browser
node tests/upgrade-real.mjs /chemin/vers/la/0.3.0/originale
npm run docs
python tools/verify-delivery.py
python tools/package-release.py
```

`RAPPORT_ILLUSTRE.html` embarque ses captures ; `docs/QA_REPORT.md` décrit les limites. Les JSON contiennent les résultats détaillés. `docs/history/v03/` est l’historique, pas une certification de cette version.

{limitations}
'''
(R/'README.md').write_text(readme,encoding='utf-8')
(R/'docs/CHANGELOG_0_4.md').write_text(f'''# {v} — Le seuil du silence

Base cumulative : archive 0.3 intacte. Registre `passages.revision = 4` ajouté ; format externe de campagne 1 conservé. Aucun nouveau chapitre, créature ou pièce annoncé.

- Raccords : {len(links)} liens, quatre familles visuelles, préparation interrompable, trajet engagé, secours automatique, escorte et reprise JSON.
- Écoute N : 1,6 seconde exposée, quatre types de relevé, douze observations datées dans SEUILS/O.
- Détecteur : échos d’une pièce voisine à travers un seuil proche, autorisé et non soudé ; aucun repérage précis hors champ.
- Persistance : deux slots, validation sémantique et contrôle d’altération accidentelle, ancienne clé conservée. Stockage réel non qualifié.
- Lisibilité : retrait HUD de combat pendant raccord, messages obsolètes retirés, contraste et taille de lecture, mode animations atténuées.
- Correction : cache-pump éloignée de l’échelle ; accès revérifiés dans les deux sens et deux vues.

{model} groupes/cas de modèle, douze parcours, {num('INSTALLER_TEST_RESULTS')} tests d’installateur et {num('REAL_UPGRADE_TEST_RESULTS')} de montée réelle sur shell, {browser} contrôles navigateur. Les détails et exclusions priment sur ces totaux.

{limitations}
''',encoding='utf-8')
# Curated screenshots, all linked to the exact browser evidence record.
selected=[
('02-arrivee.png','La colonie reste le point de départ','Début de partie au clavier : le parcours principal n’a pas été remplacé.'),
('27-montecharge-v04.png','Un trajet lisible, pas un saut instantané','Cabine du processeur et compagnon. Préparation exposée, puis raccord engagé borné. Le combat normal est suspendu pendant le trajet.'),
('28-escalier-v04.png','Des paliers reliés','L’escalier annonce origine et destination. Son animation n’est pas un étage supplémentaire librement explorable.'),
('29-echelle-v04.png','L’échelle a son franchissement','La posture garde l’arme abaissée. Les droits et points de retour restent ceux du graphe.'),
('30-sas-v04.png','Le cycle du sas','L’engagement ferme le raccord avant l’arrivée. Le menu ne peut pas transformer ce passage en téléportation libre.'),
('31-secours-v04.png','L’entraînement de secours','Sur un circuit coupé, le monte-charge termine son trajet plus lentement. Ce n’est pas une nouvelle réparation ou une commande de manivelle.'),
('32-ecoute-detecteur-v04.png','Avant d’ouvrir','L’écoute produit un indice qualitatif. Le détecteur peut recevoir un écho proche au-delà du seuil, sans afficher la position exacte hors champ.'),
('33-dossier-seuils-v04.png','Une observation vieillit','Le dossier conserve origine, destination et ancienneté des douze derniers relevés. « Rien perçu » ne garantit pas la sécurité.'),
('34-newt-ecoute-v04.png','Newt écoute, sans arme','Les grilles restent utilisables selon les droits du personnage. L’écoute ne lui donne ni détecteur ni arsenal.'),
('35-options-portrait-v04.png','Lecture agrandie','Contraste renforcé et taille 130 %. Capture d’un viewport émulé, pas d’un téléphone physique.'),
('36-seuils-portrait-v04.png','Les relevés en portrait','Le dossier se déroule dans le dialogue et conserve le focus clavier. Les animations atténuées ne suppriment pas les délais de gameplay.')]
figures=[]
for i,(name,title,description) in enumerate(selected,1):
 c=caps[name];b=(R/c['file']).read_bytes();encoded=base64.b64encode(b).decode();isportrait='portrait' in name
 setup=c['setup'];state=c.get('state',{});context=' ; '.join(f'{k} : {state[k]}' for k in ['chapter','room'] if k in state)
 figures.append(f'<figure id="capture-{i}" class="{"portrait" if isportrait else "landscape"}"><img src="data:image/png;base64,{encoded}" alt="{escape(title)}"><figcaption><span class="eyebrow">CAPTURE {i:02d} / RUNTIME CHROMIUM</span><h3>{escape(title)}</h3><p>{escape(description)}</p><details><summary>Préparation et preuve</summary><p>{escape(setup)}. {escape(context)}</p><code>{escape(c["file"])} · SHA-256 {hashlib.sha256(b).hexdigest()}</code></details></figcaption></figure>')
css='''*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#071318;color:#c7d9d5;font:16px/1.75 Arial,Helvetica,sans-serif}main{max-width:1180px;margin:auto;padding:48px 30px 64px}header{border-top:2px solid #9cbaa3;border-bottom:1px solid #40585a;padding:40px 0 36px}.eyebrow{font:11px/1.5 monospace;letter-spacing:.14em;color:#a9bca7}h1{font-size:clamp(38px,7vw,76px);font-weight:400;letter-spacing:.07em;line-height:1.07;margin:20px 0;color:#e4e9d6}h2{font-size:29px;line-height:1.2;font-weight:400;margin:56px 0 24px;color:#e4e9d6}h3{font-size:21px;font-weight:400;margin:12px 0;color:#e4e9d6}.subtitle{font-size:24px;color:#c7d4ae}.tag{display:inline-block;border:1px solid #6a8982;padding:7px 12px;font:11px monospace;letter-spacing:.1em}a{color:#d7d4aa}nav{display:flex;flex-wrap:wrap;gap:12px;margin:24px 0}nav a{padding:7px 12px;border:1px solid #4e6965;text-decoration:none}p{margin:12px 0}.notice{background:#152729;border-left:3px solid #c6b57d;padding:19px 23px;margin:24px 0}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin:30px 0}.metrics article{padding:20px;background:#11252a;border-top:1px solid #6f8f80}.metrics b{display:block;font:37px monospace;color:#e2e4bb}.metrics span{display:block;font:11px/1.6 monospace;letter-spacing:.08em;margin-top:8px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:26px}.grid article{padding:25px;background:#102125}table{width:100%;border-collapse:collapse;font-size:14px}th,td{text-align:left;vertical-align:top;padding:13px 10px;border-bottom:1px solid #3e5b5755}th{font:11px monospace;letter-spacing:.07em;color:#c4d4af}.table-wrap{overflow:auto}figure{margin:34px 0;background:#10242a;border:1px solid #476463}figure img{display:block;width:100%;height:auto}figcaption{padding:24px 28px}.portrait{max-width:550px;margin-left:auto;margin-right:auto}.portrait img{max-height:840px;object-fit:contain;background:#051015}details{font-size:12px;color:#9fb6af;margin-top:15px}summary{cursor:pointer}code{font:11px/1.6 monospace;overflow-wrap:anywhere}footer{border-top:1px solid #45615a;margin-top:45px;padding-top:25px;font-size:12px;color:#9cb3aa}strong{color:#e4e8d5}@media(max-width:700px){main{padding:25px 17px}.metrics{grid-template-columns:1fr 1fr}.grid{grid-template-columns:1fr}figcaption{padding:18px}table{font-size:12px}th,td{padding:10px 6px}}@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}}'''
html=f'''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fleuve de la Douleur — Rapport v0.4</title><style>{css}</style></head><body><main><header><p class="eyebrow">ALIENS / TANTALUS FRONTIER / LIVRAISON LOCALE · 29 SEPTEMBRE 2026</p><h1>LE SEUIL<br>DU SILENCE</h1><p class="subtitle">Alien — Fleuve de la Douleur</p><span class="tag">{v.upper()}</span></header><nav aria-label="Documents de livraison"><a href="JOUER.html">JOUER</a><a href="docs/CODEX_LEVEL_DESIGN.md">CODEX DES PIÈCES</a><a href="docs/QA_REPORT.md">QUALIFICATION</a><a href="README.md">INSTALLATION</a></nav><p class="notice"><strong>Une suite jouable de la 0.3, pas une refonte du moteur hôte.</strong> Les 42 pièces et six détours sont conservés. Cette passe transforme certains changements de pièce en franchissements lisibles et ajoute une prise d’information au seuil. Les dessins restent provisoires.</p><div class="metrics"><article><b>21</b><span>LIAISONS TEMPORISÉES</span></article><article><b>1,6 s</b><span>ÉCOUTE EXPOSÉE</span></article><article><b>12</b><span>RELEVÉS CONSERVÉS</span></article><article><b>2</b><span>COPIES LOCALES VALIDÉES</span></article></div><h2>Ce qui change en jeu</h2><section class="grid"><article><p class="eyebrow">FRANCHIR</p><h3>Décider avant de s’engager</h3><p>Escaliers, échelles, sas et deux liaisons de monte-charge utilisent une préparation interrompable et un raccord animé. Le compagnon doit suivre et être proche. Une coupure allonge le trajet du monte-charge.</p><p><strong>Le raccord n’est pas un puits exploratoire continu.</strong> Le combat normal est suspendu après engagement ; préparation et écoute restent exposées.</p></article><article><p class="eyebrow">ÉCOUTER</p><h3>Un indice, pas une certitude</h3><p>N écoute pendant 1,6 seconde ; O ouvre les douze derniers relevés. Le détecteur marine distingue aussi des échos proches derrière un accès autorisé. Aucune révélation de toute la colonie ni position précise hors champ.</p><p>Newt écoute les grilles, mais reste sans arme ni détecteur.</p></article><article><p class="eyebrow">REPRENDRE</p><h3>Un transfert vérifié</h3><p>Les exports réels 0.1, 0.2 et 0.3 sont repris. Un export 0.4 au milieu du trajet continue le temps restant et conserve le compagnon.</p><p>Le protocole de deux copies est testé en mémoire simulée. La persistance native après fermeture reste à qualifier.</p></article><article><p class="eyebrow">LIRE</p><h3>Moins d’obstacles d’interface</h3><p>Le HUD de combat laisse la place au raccord. Le mode animations atténuées, le contraste renforcé et la lecture à 130 % conservent les mêmes règles de jeu.</p><p>La réserve de pompage a été éloignée de l’échelle qu’elle masquait en vue latérale.</p></article></section><h2>Le même contenu, approfondi</h2><div class="table-wrap"><table><thead><tr><th>CONTENU</th><th>LIVRAISON 0.4</th><th>STATUT</th></tr></thead><tbody><tr><td>Campagne</td><td>16 chapitres / 49 objectifs</td><td>Conservée</td></tr><tr><td>Exploration</td><td>42 pièces / 57 liens</td><td>21 liens temporisés ; accès inchangés</td></tr><tr><td>Détours</td><td>6 / 18 étapes</td><td>Conservés, raccourcis aller/retour</td></tr><tr><td>Décor</td><td>489 props / 118 ajouts de crise</td><td>Placements, pas sprites uniques</td></tr><tr><td>Codex</td><td>{len(codex.splitlines())} lignes</td><td>Généré depuis les données courantes</td></tr></tbody></table></div><h2>Captures du jeu en exécution</h2><p>Les scènes tardives sont des sauvegardes de test importées par l’interface ; elles ne proviennent pas d’une partie complète jouée manuellement. Les relevés et raccords montrés sont ceux du runtime, sans concept art ajouté. Chaque image expose sa préparation et son empreinte.</p>{''.join(figures)}<h2>Résultats retenus</h2><div class="table-wrap"><table><thead><tr><th>RECETTE</th><th>RÉSULTAT</th><th>INTERPRÉTATION</th></tr></thead><tbody><tr><td>Modèle et sauvegarde abstraite</td><td>{model}/{model}</td><td>Dont {num('PASSAGES_TEST_RESULTS')} cas seuils et {num('PERSISTENCE_TEST_RESULTS')} cas de stockage simulé</td></tr><tr><td>Parcours complets</td><td>12/12</td><td>Deux vues × trois difficultés, avec et sans détours</td></tr><tr><td>Installateur</td><td>{num('INSTALLER_TEST_RESULTS')}/{num('INSTALLER_TEST_RESULTS')} + {num('REAL_UPGRADE_TEST_RESULTS')}/{num('REAL_UPGRADE_TEST_RESULTS')}</td><td>Projets de test, dont vrais fichiers 0.3</td></tr><tr><td>Navigateur</td><td>{browser}/{browser}</td><td>Chromium ; zéro erreur JavaScript relevée</td></tr></tbody></table></div><p>Les pilotes connaissent les itinéraires et solutions. Ils vérifient la continuité sans téléportation ni validation forcée, pas la difficulté ou la durée auprès de joueurs. {len(caps)} captures détaillées sont fournies ; {len(selected)} sont reprises dans ce rapport.</p><p class="notice"><strong>Stockage réel non certifié.</strong> L’environnement a bloqué la navigation HTTP locale. Le HTML autonome a été exécuté avec Playwright dans une origine opaque, sans changer la politique du navigateur. Les tests de quota/copies altérées utilisent un stockage mémoire simulé. L’import/export JSON réel est vérifié.</p><footer>{escape(limitations)}<p>La source hôte mentionnée dans les métadonnées est héritée des livraisons précédentes, pas une vérification nouvelle du dépôt. Aucun service distant n’a été modifié. Les fichiers CHECKSUMS.sha256 et DELIVERY_MANIFEST.json identifient les octets de l’archive.</p></footer></main></body></html>'''
(R/'RAPPORT_ILLUSTRE.html').write_text(html,encoding='utf-8')
(R/'docs/DOCUMENTATION_BUILD.json').write_text(json.dumps({'version':v,'modelCases':model,'browserCases':browser,'capturedImages':len(caps),'illustratedImages':len(selected),'codexLines':len(codex.splitlines()),'connectors':dict(by_kind),'source':'CONTENT_MANIFEST and current completed reports'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'version':v,'model':model,'browser':browser,'captures':len(caps),'codexLines':len(codex.splitlines())},ensure_ascii=False))
