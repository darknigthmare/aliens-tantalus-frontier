# Qualification locale — 0.4.0-candidate.1

Les valeurs ci-dessous sont relues depuis les résultats exécutés sur cette version. Aucun total historique n’est utilisé pour annoncer une réussite courante. Les documents sous `history/` décrivent les livraisons précédentes et ne qualifient pas cette archive.

| Suite exécutée | Réussite | Portée |
|---|---:|---|
| core.cjs | 96/96 | États, contenu courant, sauvegarde, collisions et interactions héritées |
| colony.cjs | 75/75 | Tableaux, cachettes, lampe, soudures, ressources et escortes |
| exploration.cjs | 149/149 | Détours, empreintes, géométrie 42 pièces × 2 vues, visée et mémoire |
| passages.cjs | 118/118 | 84 franchissements orientés (21 × 2 sens × 2 vues), annulation, secours, escorte, import en trajet, écoute, limites du détecteur et migrations |
| persistence.cjs | 18/18 | Stockage mémoire simulé : alternance, somme de contrôle, copies tronquées, quota, refus d’écrasement et anciennes clés |
| traversal.cjs | 6/6 | Parcours principal : deux vues × trois difficultés |
| traversal-exploration.cjs | 6/6 | 42 pièces, 49 objectifs, deux escortes, six détours et raccourcis aller/retour |
| installer.mjs | 28/28 | Projets de test, installation, idempotence, conflits, restauration, chemins dangereux et montées de version simulées |
| upgrade-real.mjs | 4/4 | Vrais modules et installateur de l’archive 0.3 sur un shell hôte de test, puis 0.4 et restauration |
| browser.py | 16/16 | Début au clavier, véritable export, menu/plan, tailles et relâchement tactile émulé |
| browser-v02.py | 17/17 | Régression de l’équipement, tableaux, accompagnement et véritable fichier 0.1 |
| browser-v03.py | 27/27 | Régression des détours, cartes, intrusions, visée et véritable fichier 0.2 |
| browser-v04.py | 28/28 | Véritable fichier 0.3, quatre raccords, copie JSON en plein trajet, écoute/échos, Newt et options de lecture |

Total du modèle : **456/456**. Total navigateur : **88/88**, sans erreur JavaScript relevée. Ces compteurs désignent des assertions ou groupes de tests, pas autant de sessions humaines.

## Ce que les parcours complets prouvent

Les douze pilotes utilisent `Simulation.update`, les déplacements et les commandes du modèle. Ils n’appellent pas de validation forcée des objectifs, ne téléportent pas le personnage et ne réécrivent pas sa santé. Les soins autorisés et l’assistance de chapitre restent actifs. Ils connaissent les chemins et les solutions ; ce ne sont pas des joueurs découvrant les niveaux. Les six détours adultes sont réalisés tôt par le pilote, pas éprouvés comme une campagne humaine tardive. Les nouvelles écoutes et les cas extrêmes de détecteur sont éprouvés séparément dans les fixtures, pas revendiqués comme pratiqués à chaque seuil pendant chaque parcours.

Les 84 passages orientés préparent volontairement l’état nécessaire (personnage, accès débloqués) avant d’utiliser E et le temps du modèle. Ce sont des tests localisés, pas 84 parcours entiers. Les règles de sauvegarde refusent les états incohérents.

## Captures et navigateur

Les 36 captures sont produites par Chromium exécutant le HTML autonome exact. Le début de jeu a été actionné au clavier. Les scènes tardives sont des sauvegardes préparées, validées puis importées par l’interface. Les fichiers JSON associés donnent leur pièce, chapitre et méthode d’initialisation. Une association de test ne constitue pas un nouvel événement canonique du roman. Le rapport ne substitue aucune illustration d’intention à un écran de jeu.

Le CLI agent-browser était absent. La navigation HTTP locale a renvoyé `net::ERR_BLOCKED_BY_ADMINISTRATOR`. La recette a donc utilisé Playwright et `page.set_content` sans modifier l’origine ni la politique du navigateur. Aucune requête externe n’est nécessaire au HTML autonome. Les suites ont été rejouées séquentiellement après un premier lancement trop long ; les résultats retenus sont les exécutions achevées. Le rendu desktop est fermé avant le contexte tactile indépendant pour libérer ses ressources.

## Sauvegarde : distinction indispensable

Les essais de copies altérées et de quota utilisent un objet `MemoryStorage` de test : ils qualifient le protocole, pas localStorage natif. La fermeture/réouverture du navigateur, les quotas réels, l’onglet concurrent et les politiques de navigation privée restent non qualifiés. Le vrai téléchargement EXPORTER et le vrai import par sélecteur de fichier sont éprouvés, y compris au milieu d’une cabine engagée : arrivée unique et santé du compagnon conservée.

Les fichiers `real-v01-save.json`, `real-v02-save.json` et `real-v03-save.json` sont des exports provenant des livraisons précédentes, pas des objets récents renommés. L’import les migre sans changer leurs objectifs ou munitions. Les préférences sont appliquées dans le DOM, mais leur persistance après fermeture n’est pas qualifiée.

## Corrections issues de cette recette

La réserve de pompage `cache-pump` a été déplacée de x = 1272 à 1450 pour ne plus intercepter l’interaction de l’échelle en vue latérale. Les anciennes recettes navigateur qui attendaient une transition immédiate attendent désormais l’arrivée réelle. Le HUD de combat se masque pendant le trajet engagé ; le vieux message d’annulation est retiré au départ suivant. L’échelle ne laisse plus l’arme dessinée en main. Les numéros dans le puits désignent des guidages, pas des étages supplémentaires fictifs. Les réglages portrait ont été contrôlés avec un texte à 130 %.

## Limites de production

Raccord animé borné, pas puits continu exploratoire. Combat normal suspendu pendant le trajet engagé ; préparation et écoute exposées. Pièces hors champ non simulées en continu. Pas de véhicule pilotable. Pas d’essai sur manette physique, téléphone réel, Safari/iPhone, coopération réseau ou moteur Tantalus natif. Pas d’évaluation humaine de difficulté/durée ou de bande-son définitive.

DLC autonome avec lanceur additionnel, pas le jeu Tantalus complet ni son GameEngine natif. Aucun push GitHub ni déploiement Vercel. Dessins stylisés par code, pas atlas définitifs ou reconstitution 1:1. Roman intégral non consulté : plans, dialogues, tâches et documents sont une condensation originale. L’écho Frontière 2204 et les sauvegardes du moteur hôte ne sont pas modifiés.
