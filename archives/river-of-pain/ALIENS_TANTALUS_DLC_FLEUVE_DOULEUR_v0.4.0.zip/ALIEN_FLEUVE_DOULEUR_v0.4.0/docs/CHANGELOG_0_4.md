# 0.4.0-candidate.1 — Le seuil du silence

Base cumulative : archive 0.3 intacte. Registre `passages.revision = 4` ajouté ; format externe de campagne 1 conservé. Aucun nouveau chapitre, créature ou pièce annoncé.

- Raccords : 21 liens, quatre familles visuelles, préparation interrompable, trajet engagé, secours automatique, escorte et reprise JSON.
- Écoute N : 1,6 seconde exposée, quatre types de relevé, douze observations datées dans SEUILS/O.
- Détecteur : échos d’une pièce voisine à travers un seuil proche, autorisé et non soudé ; aucun repérage précis hors champ.
- Persistance : deux slots, validation sémantique et contrôle d’altération accidentelle, ancienne clé conservée. Stockage réel non qualifié.
- Lisibilité : retrait HUD de combat pendant raccord, messages obsolètes retirés, contraste et taille de lecture, mode animations atténuées.
- Correction : cache-pump éloignée de l’échelle ; accès revérifiés dans les deux sens et deux vues.

456 groupes/cas de modèle, douze parcours, 28 tests d’installateur et 4 de montée réelle sur shell, 88 contrôles navigateur. Les détails et exclusions priment sur ces totaux.

DLC autonome avec lanceur additionnel, pas le jeu Tantalus complet ni son GameEngine natif. Aucun push GitHub ni déploiement Vercel. Dessins stylisés par code, pas atlas définitifs ou reconstitution 1:1. Roman intégral non consulté : plans, dialogues, tâches et documents sont une condensation originale. L’écho Frontière 2204 et les sauvegardes du moteur hôte ne sont pas modifiés.
