# Historique — ne qualifie pas la version 0.4

Les documents sous ce dossier proviennent de la 0.3 ou des historiques qu’elle contenait. Les résultats, limites et noms de version décrivent ces livraisons anciennes. Pour la livraison courante, lire ../QA_REPORT.md, ../CODEX_LEVEL_DESIGN.md et les JSON directement sous docs/.
