# Qualification locale — 0.3.0-candidate.1

Les résultats ci-dessous sont relus depuis les rapports de cette livraison. Ce ne sont pas des totaux cumulés empruntés aux versions précédentes. Aucun essai humain multi-profil, appareil physique, moteur Tantalus natif ou déploiement n’est certifié.

| Suite | Réussite | Ce que cela établit |
|---|---:|---|
| core.cjs | 96/96 | Validation, états, collisions et contrat de contenu courant |
| colony.cjs | 75/75 | Systèmes hérités : tableaux, lampe, cachettes, escortes, soudures |
| exploration.cjs | 149/149 | Six détours, huit axes de tir, mémoire, avertissements, migration et 42 × 2 parcours géométriques |
| traversal.cjs | 6/6 | Nouvelle partie → 49 objectifs → fin, deux vues × trois difficultés |
| traversal-exploration.cjs | 6/6 | Même campagne + 18 étapes facultatives, 42 pièces visitées et six raccourcis traversés aller/retour |
| installer.mjs | 28/28 | Shells de test ; idempotence, upgrade 0.1/0.2, rollback, conflits, liens symboliques, chemins sortants |
| upgrade-real.mjs | 4/4 | Vrais fichiers de la 0.2 et son ancien installateur sur shell de test, pas moteur hôte natif |
| browser.py | 16/16 | UI de base, premier objectif/porte au clavier, export, refus import, trois tailles, pointer release tactile émulé |
| browser-v02.py | 17/17 | Régression des tableaux, escortes, lampe, cache, équipement et véritable export 0.1 |
| browser-v03.py | 27/27 | Détours, cartes, import réel 0.2, ressources, raccourci, visée, intrusions et portrait |

## Méthode et limites

Les pilotes de campagne utilisent Simulation.update, déplacement, équipement, interactions et commandes des tableaux. Ils ne téléportent pas, n’appellent pas completeTask et ne changent pas la santé directement. Ils exploitent en revanche la connaissance des objectifs, du graphe et des chemins : ce ne sont pas des joueurs découvrant le niveau. Les ressources de départ, l’assistance de chapitre et les mécanismes de soins du jeu restent actifs. Leurs minutes de simulation ne mesurent pas la durée d’une partie humaine.

Les tests unitaires initialisent volontairement des scènes. Les captures tardives sont des sauvegardes validées importées par le dialogue normal, puis des commandes d’interface. Les fichiers de traces indiquent cette préparation. Elles ne constituent pas une preuve d’une partie entière jouée manuellement. Les 26 PNG sont des captures du renderer en exécution, non des concept arts.

Le CLI agent-browser était absent. Chromium via Playwright a exécuté le fichier autonome exact avec page.set_content. La navigation HTTP locale a répondu ERR_BLOCKED_BY_ADMINISTRATOR ; aucune politique de navigateur n’a été modifiée. localStorage persistant n’est donc pas qualifié. Le refus propre et l’import/export JSON sont testés. Le jeu ne fait aucune requête réseau dans ces recettes.

Les deux vues partagent les objectifs et les mécanismes de difficulté. Ces réglages ne prétendent pas fournir trois mises en scène entièrement différentes. Aucun test matériel de manette, Safari/iPhone, coopération réseau ou bande-son finale. Les rencontres nouvelles ont été vérifiées isolément ; le pilote complet réalise les détours adultes avant la crise et ne certifie pas leur équilibrage humain tardif.

## Corrections effectuées pendant cette passe

La géométrie héritée a été différenciée sans perdre la bande classique. Les projections des cachettes, PNJ d’interaction et jets de vapeur ont été recollées à leur plan réel en classique. La visée fixe avec Maj ne consomme plus du souffle comme une course. La terrasse n’affiche plus de conduites de plafond suspendues dans le ciel : un parapet rejoint son sol. Le mobilier des nouvelles annexes est regroupé par postes au lieu d’un espacement automatique. Un sélecteur de recette PLAN a été corrigé pour désigner le bouton du dialogue plutôt que le bouton de fond homonyme.

## Préservation

L’archive 0.2 n’a pas été modifiée. Le code de sauvegarde conserve les espaces de noms du DLC. Le champ exploration est migré, et une position ancienne devenue solide est replacée au point libre proche avec message dans le journal. Les autres jeux ne sont pas importés. L’installateur ne touche ni package.json, ni src/app.js, ni le catalogue ; il ajoute son répertoire et un lanceur.

Cette livraison reste un DLC autonome avec lanceur additionnel. Le GameEngine natif de Tantalus, ses atlas, ses sauvegardes et l’écho Frontière 2204 ne sont pas modifiés. Aucun push GitHub ni déploiement Vercel. Les personnages et décors sont dessinés par code : graphisme stylisé provisoire, pas assets définitifs ni reconstitution 1:1. Le roman intégral n’a pas été consulté ; pièces, dialogues, documents et manœuvres sont une condensation originale.
