# 0.3.0-candidate.1 — Les chemins de traverse

Base : 0.2.0-candidate.1, conservée. Format de sauvegarde principal 1 ; systèmes de colonie 2 ; exploration 3.

42 lieux (+6), 57 connexions (+12), 489 props placés (+78), 118 ajouts de crise (+10), 24 cachettes (+6), 30 notes (+6). Les 16 chapitres, 49 objectifs principaux, deux escortes et six tableaux sont conservés. Six nouveaux détours, 18 étapes, six déverrouillages réciproques et six séquences localisées (trois intrusions, une ombre, deux ambiances).

Modules ajoutés : exploration.js (états/validation) et field-visuals.js (emprises/annonces/visée). Core enrichi pour la dernière position connue, les projectiles directionnels, les actions optionnelles et la migration des positions anciennes. Rendu/architecture corrigés pour le mode classique et le toit. UI enrichie de la carte locale, des niveaux, destinations et détours. Installateur 0.1/0.2→0.3 avec rollback.

Cette livraison reste un DLC autonome avec lanceur additionnel. Le GameEngine natif de Tantalus, ses atlas, ses sauvegardes et l’écho Frontière 2204 ne sont pas modifiés. Aucun push GitHub ni déploiement Vercel. Les personnages et décors sont dessinés par code : graphisme stylisé provisoire, pas assets définitifs ni reconstitution 1:1. Le roman intégral n’a pas été consulté ; pièces, dialogues, documents et manœuvres sont une condensation originale.
