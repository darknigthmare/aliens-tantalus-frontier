## Périmètre de la passe 0.4

La version 0.4 prolonge le même parcours : 16 chapitres de jeu, 42 pièces, 57 connexions bidirectionnelles, 49 objectifs principaux et six détours facultatifs de trois étapes. Elle n’ajoute pas artificiellement de chapitres ou de pièces. Les 489 placements de props, 118 ajouts conditionnels de crise, 62 obstacles, 24 cachettes, six tableaux et 30 documents restent des données distinctes du contenu livré. Un placement n’est pas un sprite unique.

Les nouveaux systèmes portent sur 21 liaisons temporisées, l’écoute aux seuils, les échos du détecteur derrière une porte et une sauvegarde locale à deux copies. Les systèmes de la 0.3 — détours, empreintes, visée, mémoire ennemie, carte locale — sont conservés et retestés.

## Franchissement : préparation exposée, trajet engagé

E près d’un vrai accès vérifie les droits du personnage, le verrou, la soudure, sa proximité, l’absence de tâche incompatible et la présence de son compagnon. Un escalier, une échelle, une liaison de monte-charge ou un sas engage d’abord une préparation. Pendant cette préparation, les ennemis de la pièce et les dangers continuent ; un déplacement ou une blessure du joueur ou du compagnon annule le départ. Un compagnon qui attend ou reste loin empêche l’engagement.

Après engagement, le rendu montre un raccord animé borné. La position logique reste dans la pièce de départ jusqu’à la fin du temps de trajet ; le point d’arrivée utilise le vrai portail inverse. Les deux liaisons de monte-charge appartiennent au secteur du processeur, pas à deux bâtiments supplémentaires. Une coupure du circuit active l’entraînement de secours et allonge le trajet du monte-charge de 1,6 seconde. Ce secours est automatique, pas une nouvelle manivelle interactive.

**Limite importante : ce ne sont pas des volumes continus librement explorables.** Une fois le trajet engagé, le temps écoulé et la progression du raccord avancent, mais la mise à jour normale du combat est suspendue. On ne peut ni tirer, ni se déplacer librement, ni changer de projection pendant ce raccord. Aucun axe vertical jouable, physique de cabine universelle ou IA naviguant dans le puits n’est ajouté. Les autres portes et pistes restent des transitions directes. Les véhicules ne sont pas pilotables.

Le menu Pause arrête le trajet. Un export puis un import au milieu de la séquence reprend le temps restant et n’effectue qu’une arrivée. La sauvegarde refuse une liaison inexistante, un type incompatible, une durée invalide ou un point d’origine incohérent. Le mode « atténuer les animations » conserve le temps de franchissement et le progrès de la barre, mais immobilise le cadrage et la position animée intermédiaire.

## Écouter sans révéler toute la colonie

N, le bouton ÉCOUTER ou l’action du dossier SEUILS lance une écoute de 1,6 seconde à proximité d’une porte ou d’une grille. L’écoute elle-même ne met jamais le monde en pause. Un déplacement significatif, un bruit trop fort, une attaque, un tir ou une fusée interrompt la manœuvre. Une cachette ne permet pas une écoute à distance. Newt peut écouter les grilles, sans obtenir d’arme ni de détecteur.

Le résultat est qualitatif : rien de perçu, signal masqué, mouvement ou danger. Un poursuivant en attente au seuil ou une créature proche en état d’attaque renforce le danger. Une soudure atténue la portée du côté opposé, mais les coups contre une cloison sous pression restent perceptibles. « Aucun mouvement perçu » n’est pas un certificat de pièce sûre.

Le moteur initialise au besoin l’état déterministe d’une seule pièce voisine pour évaluer le seuil. Cette opération ne marque pas le lieu comme visité, ne résout aucun objectif et ne dévoile pas toute sa géométrie. Les pièces hors champ ne sont pas continuellement simulées : il s’agit d’une lecture locale des états, pas d’un modèle acoustique ou d’un directeur global à la Alien: Isolation.

Le dossier SEUILS, ouvert avec O, conserve les douze derniers relevés avec origine, destination et ancienneté. Son ouverture met la lecture en pause, comme le plan. Les observations ne sont pas actualisées magiquement : il faut retourner écouter. L’indice sur le terrain signale son ancienneté au-delà de 30 secondes.

## Détecteur : contacts locaux et échos de proximité

Le détecteur reste réservé à Brackett et Paris. Il conserve les contacts de la pièce courante et peut recevoir un écho depuis une pièce voisine à travers un accès réel, autorisé, non soudé et proche du joueur. Il ne traverse pas plusieurs pièces et ne fournit pas les coordonnées exactes d’une créature hors champ : le repère distant est celui du seuil.

La règle utilise une distance interne : joueur → portail, marge de transmission, portail opposé → créature. Le HUD distingue l’écho distant par « AU-DELÀ DU SEUIL ». Ce sont des distances de gameplay, pas une mesure scientifique. Les salles voisines ne deviennent pas visitées et les grilles réservées à Newt ne deviennent pas des passages pour adultes.

## Sauvegardes : deux copies validées, pas une promesse matérielle

Le format JSON de campagne conserve son identifiant propre, distinct de Tantalus. Les exports réels 0.1, 0.2 et 0.3 sont acceptés et initialisent le registre de franchissement sans inventer des écoutes antérieures. Les positions anciennes couvertes par une emprise modifiée conservent la migration de proximité déjà introduite en 0.3.

Le stockage local 0.4 alterne deux emplacements, suffixés `.slot0` et `.slot1`, sous la clé du DLC. Chaque enveloppe contient une séquence, le JSON et une somme de contrôle non cryptographique destinée aux altérations accidentelles. Le JSON est également validé par le modèle. Une écriture est relue avant d’être déclarée réussie ; la copie précédente valide reste disponible. Si la plus récente est tronquée ou incohérente, la lecture utilise l’autre copie. Si les deux sont invalides, aucune sauvegarde automatique ne doit les écraser silencieusement : un remplacement demande l’action explicite du joueur.

L’ancienne clé reste lisible et n’est ni supprimée ni réécrite. Les autres espaces de sauvegarde ne sont pas touchés. Les préférences utilisent une autre clé propre au DLC : contraste, taille de lecture, animations et volume. L’activation audio reste volontaire ; aucune piste protégée n’est embarquée.

**Qualification limitée :** le protocole de double copie est testé avec un stockage mémoire explicitement simulé, y compris les exceptions de quota, les valeurs tronquées et les échecs de relecture. Le navigateur d’essai a bloqué l’adresse HTTP locale ; le HTML exact a donc été exécuté dans une origine opaque avec `set_content`. La persistance native après fermeture/réouverture, le mode privé, les quotas réels et l’accès simultané depuis plusieurs onglets ne sont pas certifiés. L’import/export JSON par l’interface, y compris en plein trajet, est vérifié dans Chromium.

## Circulation, plans et collisions conservés

Dix-huit pièces possèdent une organisation d’obstacles individualisée. Les 62 emprises physiques utilisent les mêmes dimensions pour la collision, le socle visible et le plan local. Les détails muraux ne bloquent pas. Cela ne certifie pas une silhouette artistique pixel par pixel. Les montants, profils de pièce et propriétés de parallaxe constituent une architecture stylisée ; toutes les métadonnées de production ne pilotent pas un facteur indépendant dans le renderer.

La réserve `cache-pump` de la station de pompage a été éloignée de l’échelle de la dérivation : x = 1450, z = 0,86. Son ancien emplacement interceptait E avant l’échelle en vue latérale. Les identifiants, le nombre d’objets et les récompenses restent inchangés.

Le plan colonial indique les 42 lieux et trace un itinéraire sans déplacement automatique. Il ne constitue pas un plan officiel ou un brouillard de guerre. Les accès conservent les verrous et les restrictions de personnage. Le plan local affiche obstacles, interactions, portes, cachettes, balises et compagnon. Le mode classique concentre le jeu sur z = 0,7 tout en conservant les meubles du fond à leur profondeur de décor.

Les unités x/z et les champs `dimensionsM` sont des choix de blocage originaux, pas des mesures du roman. Les parcours de test utilisent les déplacements jusqu’aux points d’action. Les pilotes complets connaissent les solutions et les itinéraires : ils prouvent la continuité, pas une durée humaine ni un équilibrage de découverte.

## Menaces et survie conservées

Le tir profond utilise huit directions du plan x/z ; il ne vise pas verticalement le plafond. ESPACE maintenu avec une direction vise sur place ; F tire. Les projectiles rencontrent les obstacles. La visée fixe avec Maj ne simule pas une course inexistante. Anne et Newt restent désarmées.

Les adversaires conservent une dernière position perçue et une mémoire de huit secondes. Après perte de trace, ils cherchent localement au lieu de suivre en permanence une position silencieuse invisible. Une entrée en cachette observée reste dangereuse. Trois intrusions scénarisées possèdent un préavis et un point d’apparition éloigné du joueur et du compagnon ; les trois autres événements sont une ombre et deux ambiances. Aucun nouveau type de xénomorphe n’est ajouté en 0.4.

Les quatre répartiteurs et deux collecteurs restent des puzzles discrets de trois commandes. La lecture met le jeu en pause, puis une manœuvre exposée de 1,4 seconde termine l’action. Les deux jets de pression possèdent une emprise et un collecteur associé. Les coupures modifient la lumière, les ventilateurs et la perception selon les règles de la 0.2, sans supprimer arbitrairement les portes.

Les compagnons d’escorte gardent santé, tension, suivre/attendre, réassurance et soins partagés. Leur mort provoque l’échec de la tentative. Une soudure sous pression peut céder ; sans poursuivant, elle ne s’use pas seule. Les réserves sont conservées par protagoniste. L’assistance de début de chapitre rétablit au moins 70 % de santé : règle de progression non canonique. Les douze dernières balises de repli restent communes à cette reconstitution.

## Lisibilité et continuité narrative

Le HUD de combat est retiré pendant le raccord engagé, et restauré à l’arrivée. Un ancien message d’annulation disparaît à l’engagement suivant. Le haut du cadre indique l’état de franchissement ; le bas reste libre pour le terrain. Contraste renforcé, lecture à 100/115/130 % et animations atténuées sont proposés dans Pause. Les contrôles portrait sont vérifiés par émulation, pas sur matériel réel.

La chronologie hérite de la 0.3 : ni secours extérieur réussi ajouté, ni évacuation de Newt, ni reine tuée. Les annexes, tâches, textes et 16 chapitres sont des créations de gameplay, non les chapitres du livre. Le roman intégral n’a pas été consulté. Les scènes de capture préparées ne requalifient pas une association de personnage ou de lieu comme événement authentifié. L’écho Frontière 2204, le moteur hôte et ses sauvegardes ne sont pas modifiés.
