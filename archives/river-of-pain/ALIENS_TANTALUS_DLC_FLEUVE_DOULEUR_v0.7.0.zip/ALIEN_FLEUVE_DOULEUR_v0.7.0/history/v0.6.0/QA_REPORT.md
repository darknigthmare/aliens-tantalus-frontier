# Qualification locale — 0.6.0-candidate.1

Ces résultats sont issus des suites achevées sur le code livré. Les comptes archivés sous `history/` ne sont pas ajoutés. Les compteurs désignent des assertions ou groupes de contrôles, pas autant de joueurs, de machines ou de sessions humaines.

| Suite actuelle | Réussite | Portée |
|---|---:|---|
| core.cjs | 96/96 | État, progression, collisions et format de sauvegarde |
| colony.cjs | 75/75 | Tableaux, cachettes, batterie, soudures et escortes |
| exploration.cjs | 149/149 | Détours, géométrie des 42 pièces, visée et mémoire |
| passages.cjs | 118/118 | 21 raccords dans les deux sens et vues ; écoute, échos et migrations |
| persistence.cjs | 18/18 | Stockage mémoire simulé : deux copies, intégrité, quotas et refus d’écrasement |
| life.cjs | 141/141 | Habitants, thèmes, réserves, recettes, leurres portables et imports |
| defense.cjs | 121/121 | Volets, occupation, tirs, contournement, frappes, alarmes, Newt et vrais anciens exports |
| installer.mjs | 28/28 | Shells hôtes de test, idempotence, conflits, mise à niveau et restauration |
| upgrade-real.mjs | 4/4 | Vrais fichiers/installateur 0.5 puis payload 0.6 sur un shell hôte de test |
| browser.py | 16/16 | Début au clavier, vrai export, menus, scènes tardives séparées et tactile émulé |
| browser-v02.py | 17/17 | Survie et véritable export 0.1 dans le runtime courant |
| browser-v03.py | 27/27 | Détours, cartes, visée et véritable export 0.2 |
| browser-v04.py | 28/28 | Raccords, écoute, échos et véritable export 0.3 |
| browser-v05.py | 29/29 | Conversations, réserves, assemblage, leurres et véritable export 0.4 |
| browser-v06.py | 28/28 | Deux sessions séquentielles : volets, rupture, Newt, alarmes, vrai export 0.5 et nouveaux exports |

**Modèle : 718/718. Navigateur : 145/145.** Aucun événement d’erreur JavaScript relevé dans les recettes achevées. Les parcours suivants sont comptés séparément.

| Pilote complet | Nombre | Contenu effectivement parcouru |
|---|---:|---|
| traversal.cjs | 6/6 | Deux vues × trois difficultés ; campagne principale et deux escortes |
| traversal-exploration.cjs | 6/6 | Même campagne, 42 pièces, six détours et leurs raccourcis aller/retour |
| traversal-life.cjs | 6/6 | Ajoute 12 résidents, 24 sujets, 12 réserves, trois fabrications et trois poses |
| traversal-defense.cjs | 6/6 | Ajoute les sept volets accessibles tôt, fermés/rouverts des deux côtés, et les quatre avertisseurs |

## Ce que les 24 parcours prouvent

Les pilotes commencent une partie neuve. Ils marchent avec `Simulation.update`, utilisent les commandes, les soins disponibles et les solutions des tableaux. Ils ne téléportent pas les personnages, ne valident pas directement les objectifs et ne réécrivent pas leur santé. L’assistance de santé entre chapitres reste une règle de jeu active.

Le nouveau tour manipule les sept volets accessibles avant la crise : 14 fermetures, 14 réouvertures, traversées des bandes ouvertes et un cycle sur chacun des quatre avertisseurs. Il accomplit aussi les habitants, réserves, détours et 49 objectifs. Le huitième volet, dans le hangar scientifique, reste derrière son autorisation scénaristique et est vérifié séparément en scène préparée. Le pilote ne supprime pas cette autorisation pour gonfler son compte.

Ces tours sont optimisés et connaissent les routes. Ils ne prouvent pas la difficulté d’une découverte humaine ni l’utilité de chaque défense pendant une attaque. Les frappes, le contournement profond, le passage des petits parasites, l’occupation, les interruptions, la destruction des avertisseurs et la priorité d’une cible visible font l’objet de fixtures locales explicites dans `defense.cjs`. Les valeurs attendues sont vérifiées après simulation, pas simplement inscrites dans le rapport.

## Navigateur : méthode et difficultés rencontrées

Le CLI agent-browser est absent. L’essai HTTP local de cette passe a renvoyé `ERR_BLOCKED_BY_ADMINISTRATOR` ; le résultat est conservé dans `SMOKE_V06.json`. Les recettes utilisent le fichier autonome exact avec Playwright `set_content`, dans l’origine opaque autorisée, sans changement d’origine ni contournement de politique. Les événements réseau et erreurs de page sont collectés.

Les premières tentatives ont révélé des attentes fragiles basées sur un nombre de millisecondes murales : les frames ne progressaient pas toujours assez vite pour terminer une manœuvre avant l’assertion. Les recettes attendent désormais la progression normale de la simulation ou l’état observable demandé. Elles ne font pas avancer le moteur artificiellement. Les temps exacts sont vérifiés dans les tests du modèle ; aucune performance en images par seconde n’est certifiée.

Les scènes tardives du premier script et les deux groupes de la recette 0.6 utilisent des pages ou sessions distinctes afin de borner les ressources du navigateur. Un premier lancement interrompu ou un résultat partiel n’est pas compté comme une réussite. Les rapports retenus sont ceux dont l’exécution est achevée et sans échec.

## Exports réels, pas stockage natif certifié

Les fichiers `real-v01-save.json` à `real-v05-save.json` proviennent des anciennes livraisons. Le fichier 0.5 est le vrai export de balise en armement de l’archive précédente, pas un état récent renommé. La migration n’invente ni manipulation de volet, ni cycle d’alarme, ni ressources supplémentaires.

Dans le navigateur courant, un volet est fermé par les boutons, heurté par le déplacement puis endommagé par un tir au clavier. Le vrai téléchargement JSON est relu puis importé : fermeture et intégrité sont conservées. Un autre fichier est téléchargé pendant les quatre secondes d’armement d’un avertisseur. Son import reprend le délai sans second prélèvement.

Le protocole local à deux copies est éprouvé avec `MemoryStorage` simulé. Le stockage natif après fermeture/réouverture, les quotas réels, le mode privé et les onglets concurrents restent non qualifiés. Un test de protocole n’est pas une preuve de comportement du stockage natif.

## Captures et lecture visuelle

58 captures actuelles sont décrites par les résultats des six recettes navigateur. Elles proviennent de Chromium exécutant le HTML exact. Les scènes ciblées sont des sauvegardes préparées, validées, puis importées par le sélecteur de fichier ordinaire. Leurs pièces, personnages et méthodes sont enregistrés dans les rapports. Les captures ne constituent ni des scènes du roman nouvellement authentifiées ni une campagne entière jouée à la main.

Le dossier des dispositifs est contrôlé à 130 % en 1280×720, 844×390 et 390×844. Le portrait et les commandes tactiles sont émulés ; aucune certification de téléphone réel, Safari/iPhone ou manette matérielle n’est annoncée. Le rapport illustré est contrôlé séparément contre ses PNG sources.

## Corrections issues de la passe

Le placement des volets évite les trajets ordinaires des résidents ; une fermeture réellement occupée reste refusée. Les commandes sont triées indépendamment du panneau pour ne pas masquer la tête d’un acteur devant. Les segments de navigation et de tir emploient les emprises actives exactes, sans échantillonnage susceptible de sauter un obstacle mince. Une poursuite garde sa dernière position perçue tant que sa mémoire reste valide ; elle ne devient pas omnisciente.

Le passage de vue est refusé s’il enfermerait le joueur ou son compagnon dans un solide. Le sélecteur affiche alors la vue conservée. L’ouverture d’un volet ne répare pas ses dégâts, sa destruction ne recrée pas de mécanisme et Newt conserve une libération accessible des deux côtés.

## Limites maintenues

DLC autonome avec lanceur additionnel, pas le jeu Tantalus complet ni son GameEngine natif. Aucun push GitHub ni déploiement Vercel. Dessins stylisés par code, pas atlas définitifs ou reconstitution 1:1. Roman intégral non consulté : plans, dialogues, tâches et documents sont une condensation originale. L’écho Frontière 2204 et les sauvegardes du moteur hôte ne sont pas modifiés.

Les résidents restent locaux aux stades 0/1, pas une population autonome dans toute la colonie. Les alarmes sont locales et n’ajoutent pas d’ennemis. Les volets changent d’état après une manipulation, pas lamelle par lamelle. Les raccords restent bornés, pas un axe vertical continu. Pas de véhicule pilotable, coopération réseau, durée humaine, équilibrage final ou atlas définitif certifié.
