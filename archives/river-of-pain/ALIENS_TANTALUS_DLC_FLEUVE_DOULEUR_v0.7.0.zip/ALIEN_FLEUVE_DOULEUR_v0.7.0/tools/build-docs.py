#!/usr/bin/env python3
"""Build current codex/report from shipped content and completed current tests. No publishing."""
from pathlib import Path
from html import escape
from collections import Counter
import base64, json, hashlib
R=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((R/'docs'/n).read_text(encoding='utf-8'))
D=read('CONTENT_MANIFEST.json');rooms={r['id']:r for r in D['rooms']};m=D['manifest'];v=m['version'];cnt=m['counts']
assert v=='0.7.0-candidate.1'
fmt=lambda n:str(round(n,3)).rstrip('0').rstrip('.') if isinstance(n,float) else str(n)
cell=lambda s:str(s).replace('|',' / ').replace('\n',' ')
limitations='DLC autonome avec lanceur additionnel, pas le jeu Tantalus complet ni son GameEngine natif. Aucun push GitHub ni déploiement Vercel. Dessins stylisés par code provisoires, pas atlas définitifs ou reconstitution 1:1. Roman intégral non consulté : plans, dialogues, tâches et documents sont une condensation originale. L’écho Frontière 2204 et les sauvegardes du moteur hôte ne sont pas modifiés.'
model_names=['CORE_TEST_RESULTS','COLONY_TEST_RESULTS','EXPLORATION_TEST_RESULTS','PASSAGES_TEST_RESULTS','PERSISTENCE_TEST_RESULTS','LIFE_TEST_RESULTS','DEFENSE_TEST_RESULTS','DUCT_TEST_RESULTS']
browser_names=['BROWSER_V07A','BROWSER_V07B','BROWSER_V07C']
reports={n:read(n+'.json') for n in model_names+browser_names+['INSTALLER_TEST_RESULTS','REAL_UPGRADE_TEST_RESULTS']}
sha=hashlib.sha256((R/'JOUER.html').read_bytes()).hexdigest()
for n,r in reports.items():
 assert r.get('passed'),n
 assert r.get('version',v)==v,n
 if n in browser_names:assert r['html_sha256']==sha,n+' must be rerun on current standalone'
num=lambda n:reports[n]['cases'] if isinstance(reports[n]['cases'],int) else len(reports[n]['cases'])
model=sum(num(n) for n in model_names);browser=sum(num(n) for n in browser_names)
tr_names=['TRAVERSAL_RESULTS','TRAVERSAL_EXPLORATION_RESULTS','TRAVERSAL_LIFE_RESULTS','TRAVERSAL_DEFENSE_RESULTS','TRAVERSAL_DUCT_RESULTS']
for n in tr_names:
 q=read(n+'.json');rr=q if isinstance(q,list) else q['cases'];assert len(rr)==6,n
 assert all(t['passed'] for t in rr),n
caprows=sum((reports[n]['captures'] for n in browser_names),[]);caps={Path(c['file']).name:c for c in caprows}
assert len(caps)==len(caprows)==12
for c in caprows:assert (R/c['file']).is_file() and c.get('setup')
timings={'escalier':(.45,1.4),'échelle':(.5,1.8),'monte-charge':(1.2,2.4),'sas':(1.1,1.1)}
seen=set();links=[]
for r in D['rooms']:
 for p in r['portals']:
  key=tuple(sorted([r['id'],p['to']]))
  if key in seen:continue
  seen.add(key)
  if p['kind'] in timings:links.append((r,p))
assert len(links)==21
by_kind=Counter(p['kind'] for _,p in links)
principles=(R/'docs/DOCTRINE_V07.md').read_text(encoding='utf-8')
lines=['# ALIEN — Fleuve de la Douleur','',f'## Codex de level design · {v}','',m['subtitle'],'',limitations,'',principles]

lines += ['## Cinq gaines et dix grilles techniques','', '| Gaine | Bouche / pièce / x / z | Bouche opposée / pièce / x / z | Temps de transfert |','|---|---|---|---|']
by_mouth={d['id']:d for d in D['ducts']['mouths']}
for route in D['ducts']['routes']:
 a,b=[by_mouth[k] for k in route['ends']]
 lines += [f"| {route['label']} · `{route['id']}` | {a['code']} · {rooms[a['room']]['name']} · {a['x']} / {a['z']} | {b['code']} · {rooms[b['room']]['name']} · {b['x']} / {b['z']} | {fmt(route['duration'])} s |"]
lines += ['', 'Ces liaisons transportent seulement des adultes existants : elles ne sont pas les 57 connexions jouables du plan colonial. Préparation 1,1 s, sortie annoncée 2,4 s, dégagement 300 unités internes. Verrouiller 2 s, libérer 1,2 s, écouter 1,7 s. Aucun volume de gaine librement exploratoire ajouté.','']

lines += ['## Huit volets dans les pièces','', '| Volet | Pièce | Emprise x / z ; largeur / profondeur | Commandes gauche et droite x / z |','|---|---|---|---|']
for d in D['defense']['shutters']:
 lines.append(f"| {d['label']} · `{d['id']}` | {rooms[d['room']]['name']} | {d['x']} / {d['z']} ; {d['w']} / {d['d']} | "+' ; '.join(f"{a['x']} / {a['z']}" for a in d['controls'])+' |')
lines += ['', 'En vue classique, z = 0,7 et profondeur de volet = 0,10. L’emprise devient physique seulement à fermeture réussie. Intégrité 100 ; fermeture 2,6 s, ouverture adulte 1,6 s, libération Newt 1,1 s. Pas de réparation.','', '## Quatre avertisseurs locaux','', '| Avertisseur | Pièce / circuit | x / z | Programmation → délai → signal | Réarmement / cycles |','|---|---|---|---|---|']
for d in D['defense']['alarms']:
 lines.append(f"| {d['label']} · `{d['id']}` | {rooms[d['room']]['name']} / {d['circuit']} | {d['x']} / {d['z']} | 1,2 s → 4 s → 10 s | 45 s / 2 |")
lines += ['','Les cycles expirent hors champ, pas les parcours des ennemis. Un circuit coupé éteint le signal sans rembourser le cycle. La commande exige la présence d’un adulte à portée.','']
lines += ['## Douze personnes de service originales','']
for d in D['life']['residents']:
 lines += [f"### {d['name']} · `{d['id']}`",'',f"**{d['role']} · {rooms[d['room']]['name']} · stades 0 et 1 uniquement**",'',f"Silhouette : hauteur {d['height']}, accessoire `{d['tool']}`, apparence `{d['hair']}`. Trajet local : "+' → '.join(f"({q['x']} / {q['z']})" for q in d['points'])+'. Retrait : '+str(d['refuge'])+'.','',f"Avant la crise : « {d['intro'][0]} »",'',f"Premiers incidents : « {d['intro'][1]} »",'']
 for t in d['topics']:lines += [f"**{t['label']}** · `{t['id']}`",'',t['text'],'']
 lines += ['Ces réponses doivent être demandées sur place pour être conservées. Aucun suivi à distance, crédit de mission ou sort canonique attribué.','']
lines += ['## Réserves finies et établis','', '| Réserve / identifiant | Pièce | Point x / z | Contenu initial |','|---|---|---|---|']
for d in D['life']['containers']:lines.append(f"| {d['label']} · `{d['id']}` | {rooms[d['room']]['name']} | {d['x']} / {d['z']} | "+' ; '.join(f"{n} {D['life']['items'][k]['label']}" for k,n in d['items'].items())+' |')
lines += ['', 'Les contenus sont partagés entre les protagonistes. Les prises respectent les capacités ; les surplus restent dans le meuble.','', '| Établi / identifiant | Pièce | Point x / z | Recettes |','|---|---|---|---|']
for d in D['life']['benches']:lines.append(f"| {d['label']} · `{d['id']}` | {rooms[d['room']]['name']} | {d['x']} / {d['z']} | Balise sonore / recharge de lampe |")
lines += ['','Les stations ne sont pas des couvertures collisionnables supplémentaires. Le point ci-dessus est la cible physique de l’interaction, avec une portée de proximité.','']
lines += ['## Registre des 21 liaisons temporisées','', 'Les liaisons ci-dessous se parcourent dans les deux sens. Les points de départ et de retour détaillés dans chaque fiche de pièce restent les coordonnées de référence. Les temps sont des secondes de simulation, pas des mesures du film ou du roman.','', '| Origine | Destination | Nature | Niveaux | Préparation exposée | Trajet engagé |','|---|---|---|---|---:|---:|']
for r,p in links:
 b,t=timings[p['kind']];lines += [f"| {r['name']} | {rooms[p['to']]['name']} | {p['kind']} | {r['floor']} → {rooms[p['to']]['floor']} | {fmt(b)} s | {fmt(t)} s |"]
lines += ['','## Registre des six détours','']
for j in D['jobs']:
 r=rooms[j['room']];free=next(p for p in r['portals'] if not p['requires']);gate=next(p for p in r['portals'] if p['requires'])
 lines += [f"### {j['title']} · `{j['id']}`",'',f"**{r['name']} · {'Newt seule' if j['childOnly'] else 'Personnage adulte'}**",'',j['steps'][0]['description'],'',f"Boucle : {rooms[free['to']]['name']} → {r['name']} → {rooms[gate['to']]['name']}. L’entrée depuis {rooms[free['to']]['name']} ne demande pas d’avoir déjà ouvert la sortie.",'','| Étape | Salle | Action | x / z | Temps sur place |','|---|---|---|---|---|']
 for i,t in enumerate(j['steps']):lines.append(f"| {i+1} | {rooms[t['room']]['name']} | {t['label']} | {fmt(t['x'])} / {fmt(t['z'])} | {t['duration']} s |")
 reward={'medkit':'une trousse de soins','flare':'deux fusées','battery':'réserve de lampe remise à 100 %','food':'25 points de santé, maximum 100'}[j['reward']]
 a=next(a for a in D['archives'] if a['id']==j['archive'])
 lines += ['',f"Pièce emportée : **{j['item']}**. La pose exige cette étape, le bon personnage et la proximité. L’éloignement ou une blessure interrompt la pose sans effacer la pièce.",'',f"Effet : `{j['flag']}` autorise les deux portails. Récompense : {reward}, une seule fois ; document `{a['id']}` — {a['title']}. Le compteur de campagne principale ne change pas.",'']
lines += ['## Rencontres ajoutées et annonce','', '| ID / pièce | Nature | Stade minimum | Seuil x | Ancrage x / z | Préavis |','|---|---|---:|---:|---|---:|']
for e in D['encounters']:lines.append(f"| `{e['id']}` / {rooms[e['room']]['name']} | {e['type']} | {e['minPhase']} | {e['triggerX']} | {e['spawnX']} / {e['spawnZ']} | {e['warning']} s |")
for e in D['encounters']:lines += ['',f"**{e['id']}** — {e['label']}"]
lines += ['','## Campagne principale : 49 objectifs conservés','']
for c in D['chapters']:
 lines += [f"### {c['index']+1:02d} — {c['title']}",'',f"**{D['characters'][c['character']]['name']} · {c['timeLabel']} · {rooms[c['start']]['name']}**",'',c['synopsis'],'','| Ordre | Lieu | Action réelle | Type |','|---|---|---|---|']
 for i,t in enumerate(c['objectives']):
  o=next(o for o in rooms[t['room']]['objects'] if o['id']==t['id']);lines.append(f"| {i+1} | {rooms[t['room']]['name']} | {o['label']} | `{o['kind']}` |")
 lines += ['',f"Dialogue original de jeu : **{c['dialogue']['speaker']}** — « {c['dialogue']['text']} »",'']
lines += ['## Tableaux et collecteurs : solutions de recette','']
for bid,b in D['boards'].items():
 lines += [f"### {b['title']} · `{bid}`",'',f"{rooms[b['room']]['name']} · circuit `{b['circuit']}` · capacité {b['capacity']}.",'',b['hint'],'','| Commande | Charge | État requis | Initial |','|---|---:|---|---|']
 for i,c in enumerate(b['channels']):lines.append(f"| {c[0]} | {c[1]} | {'Actif' if c[2] else 'Coupé'} | {'Actif' if b['initial'][i] else 'Coupé'} |")
 lines += ['']
lines += ['## Les 42 fiches de pièce','']
for r in D['rooms']:
 a=r['architecture'];lines += [f"### {r['name']} · `{r['id']}`",'',f"**{r['building']} · niveau {r['floor']} · {r['kind']} · {r['width']} unités · z {r['minZ']}–{r['maxZ']}**",'',f"Repère d’orientation : {r['landmark']}. Profil `{a['style']}` / `{a['variant']}`, circuit `{a['circuit']}`, emprise `{r['layoutProfile']}`.",'',f"Blocage métrique déclaré : {r['dimensionsM']} ; intention originale, pas mesure du roman. {a['wallModules']} travées murales déclarées. Les facteurs de parallaxe d’architecture sont des métadonnées de production, pas tous des variables autonomes du renderer.",'','#### Entrées, retours et droits','', '| Sortie | Nature | Départ x / z | Retour x / z | Condition |','|---|---|---|---|---|']
 for p in r['portals']:
  back=next(q for q in rooms[p['to']]['portals'] if q['to']==r['id']);cond=('Newt ; ' if p['childOnly'] else '')+(p['requires'] or 'Libre')
  lines.append(f"| {rooms[p['to']]['name']} | {p['kind']} | {fmt(p['x'])} / {fmt(p['z'])} | {fmt(back['x'])} / {fmt(back['z'])} | {cond} |")
 for p in r['portals']:
  if p['kind'] in timings:
   board,travel=timings[p['kind']]
   extra=' Circuit coupé : +1,6 s de trajet.' if p['kind']=='monte-charge' else ''
   lines += ['',f"Raccord vers **{rooms[p['to']]['name']}** : préparation exposée {fmt(board)} s, puis trajet borné {fmt(travel)} s.{extra} Arrivée au portail inverse ; annulation par mouvement ou blessure avant engagement. Les menus ne permettent pas de contourner les droits d’accès."]
 lines += ['', 'Lecture des seuils : les observations sont datées, locales et non garanties. L’écoute ne rend pas cette pièce sûre. Les emprises et points de retour ci-dessous restent la référence de placement.']
 lines += ['','#### Obstacles : emprise commune au rendu et au moteur','', '| ID | Nature | Centre x / z | Largeur / profondeur |','|---|---|---|---|']
 if not r['cover']:lines += ['| Aucun | Passage latéral dégagé | — | — |']
 for c in r['cover']:lines.append(f"| `{c['id']}` | {c['prop']} | {fmt(c['x'])} / {fmt(c['z'])} | {fmt(c['w'])} / {fmt(c['d'])} |")
 lines += ['','#### Décors : fonction avant densité','', '| ID / objet | x / z | Couche | Solide | Rôle et placement |','|---|---|---|---|---|']
 for p in r['props']:lines.append(f"| `{p['id']}` / {p['kind']} | {fmt(p['x'])} / {fmt(p['z'])} | {p['layer']} | {'Oui' if p['collidable'] else 'Non'} | {cell(p['purpose'])} |")
 lines += ['','#### Interactions et cachettes','', '| ID / action | x / z | Condition d’apparition | Type |','|---|---|---|---|']
 for o in r['objects']:
  cond='Chapitre '+str(o['chapter']+1) if 'chapter' in o else 'Détour '+o['job']+' / étape '+str(o['step']+1) if o['kind']=='side-task' else 'Facultatif'
  lines.append(f"| `{o['id']}` · {cell(o['label'])} | {fmt(o['x'])} / {fmt(o['z'])} | {cond} | {o['kind']} |")
 if r['phaseDressing']:
  lines += ['','#### État de crise visible','', '| Élément | x / z | Stade minimum |','|---|---|---:|']
  for q in r['phaseDressing']:lines.append(f"| {q['kind']} | {fmt(q['x'])} / {fmt(q['z'])} | {q['fromPhase']} |")
 for h in D['hazards']:
  if h['room']==r['id']:lines += ['',f"Danger local `{h['id']}` : x {h['x']}, z {h['z']}. Valeurs de recette : `{json.dumps(h,ensure_ascii=False)}`."]
 for e in D['encounters']:
  if e['room']==r['id']:lines += ['',f"Rencontre `{e['id']}` : annonce de {e['warning']} s au passage x ≥ {e['triggerX']}, à partir du stade {e['minPhase']}. Consulter son état de sauvegarde avant tout ajout d’ennemi."]
 localpeople=[d for d in D['life']['residents'] if d['room']==r['id']];localboxes=[d for d in D['life']['containers'] if d['room']==r['id']];localbenches=[d for d in D['life']['benches'] if d['room']==r['id']]
 if localpeople or localboxes or localbenches:
  lines += ['','#### Vie coloniale et stations de la 0.5','']
  for d in localpeople:lines += [f"**{d['name']}** · {d['role']}. Routine 0/1 : "+' → '.join(f"({q['x']} / {q['z']})" for q in d['points'])+'. P permet de sélectionner sa conversation sans emprunter un accès voisin.','']
  for d in localboxes:lines += [f"**{d['label']}** · `{d['id']}` à ({d['x']} / {d['z']}). Fermoir fermé → ouverture exposée → contenu fini → surplus ou état vide. Contenu : "+' ; '.join(f"{n} {D['life']['items'][k]['label']}" for k,n in d['items'].items())+'. Pas de remplissage après une visite.','']
  for d in localbenches:lines += [f"**{d['label']}** · `{d['id']}` à ({d['x']} / {d['z']}). Adulte proche ; deux recettes, coût débité seulement au terme. Aucun usage à distance ni atelier pour Newt.",'']
 localshutters=[d for d in D['defense']['shutters'] if d['room']==r['id']];localalarms=[d for d in D['defense']['alarms'] if d['room']==r['id']]
 if localshutters or localalarms:
  lines += ['','#### Dispositifs physiques de la 0.6','']
  for d in localshutters:
   lines += [f"**{d['label']}** · `{d['id']}`. Centre {d['x']} / {d['z']}, emprise {d['w']} / {d['d']}. Commandes : "+' ; '.join(f"({a['x']} / {a['z']})" for a in d['controls'])+'. Fermeture 2,6 s ; ouverture adulte 1,6 s ; Newt 1,1 s. Occupation vérifiée au début et au terme. Pas d’écrasement ni d’éjection.','', 'Contournement profond s’il existe ; sinon les adultes annoncent leurs frappes. Petits parasites sous le panneau. Intégrité non réparée après ouverture ; rupture définitive à zéro.','']
  for d in localalarms:
   lines += [f"**{d['label']}** · `{d['id']}` à ({d['x']} / {d['z']}). Circuit `{d['circuit']}`, adulte proche. 1,2 s de travail, 4 s de délai, 10 s de signal, 45 s de réarmement et deux cycles maximum. Portées de jeu 950 / 470 selon obstruction. Une cible visible reste prioritaire. Aucune apparition d’ennemi n’est produite par ce poste.",'']

 for mouth in D['ducts']['mouths']:
  if mouth['room']==r['id']:
   other=next(by_mouth[x] for x in next(a for a in D['ducts']['routes'] if a['id']==mouth['route'])['ends'] if x!=mouth['id'])
   lines += ['', '#### Bouche technique de la 0.7', '', f"**{mouth['code']} · {mouth['label']}** · `{mouth['id']}` à ({mouth['x']} / {mouth['z']}). Gaine `{mouth['route']}` vers **{rooms[other['room']]['name']}**, bouche {other['code']}. Grille ouverte initialement, intégrité 100. E à portée ou dossier 4 ; écouter 1,7 s, verrouiller 2 s, libérer 1,2 s. Newt écoute seulement.", '', 'Cette station ne bloque pas la marche et ne constitue pas une porte du joueur. Une sortie de créature existante attend la pièce active, 2,4 s de préavis et un dégagement de 300 unités internes. Les dégâts de grille et le transfert se sauvegardent ; une libération ne répare pas le verrou.','']

 lines += ['','#### Garde-fous de cette pièce','',f"Les {len(r['portals'])} retours, {len(r['objects'])} points d’interaction et {len(r['cover'])} obstacles sont issus du même contenu que le runtime. La recette géométrique a marché de l’entrée vers chaque point dans les deux vues. Elle contrôle l’accessibilité, pas une partie humaine complète ni l’équilibrage de chaque rencontre.",'', 'Ne pas ajouter de collision aux accessoires muraux sans modifier le plan local et relancer la recette. Ne pas déplacer un seuil sans déplacer son point de retour. Ne pas transformer un décor d’observation en porte non documentée. Préserver la bande z = 0,7 pour le mode classique.','']
lines += ['## Documents originaux','']
for a in D['archives']:
 lines += [f"### {a['id']} — {a['title']}",'',str(a.get('text',a.get('body',''))),'']
lines += ['## Qualification courante','',f'{model} groupes/cas du modèle, dont {num("PASSAGES_TEST_RESULTS")} pour les seuils et {num("PERSISTENCE_TEST_RESULTS")} pour le stockage abstrait. Trente parcours complets retestés. {num("INSTALLER_TEST_RESULTS")} cas d’installateur sur projets de test et {num("REAL_UPGRADE_TEST_RESULTS")} avec les vrais fichiers 0.6. {browser} contrôles dans Chromium et {len(caps)} captures décrites. Voir QA_REPORT.md pour les périmètres et limites.','',limitations]
codex='\n'.join(lines)+'\n';(R/'docs/CODEX_LEVEL_DESIGN.md').write_text(codex,encoding='utf-8')

css='''*{box-sizing:border-box}body{margin:0;background:#091a21;color:#c6d3ca;font:16px/1.75 Arial,Helvetica,sans-serif}main{max-width:1180px;margin:auto;padding:48px 30px 70px}header{border-bottom:1px solid #4e6b64;padding:18px 0 38px}.eyebrow,.tag{font:11px/1.6 monospace;letter-spacing:.16em;color:#a7bfad}h1{font-size:clamp(38px,6.5vw,78px);font-weight:400;line-height:1.05;letter-spacing:.055em;color:#e0e5d2;margin:28px 0}h2{font-size:29px;font-weight:400;color:#e3e5cd;margin-top:56px;line-height:1.25}h3{color:#d6ddc8;font-size:20px;font-weight:400}.subtitle{font-size:22px}.tag{display:inline-block;border:1px solid #608277;padding:8px 12px}nav{display:flex;gap:18px;flex-wrap:wrap;padding:22px 0}a{color:#c8d4b7;text-decoration:none;border-bottom:1px solid #6c8d7b}a:hover{color:#fff}p{max-width:960px}.notice{padding:22px 25px;border-left:3px solid #bdb58a;background:#162c32}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin:30px 0}.metrics article{padding:22px;border-top:1px solid #648579;background:#122930}.metrics b{display:block;font:38px monospace;color:#dfe4c5}.metrics span{display:block;font:11px monospace;margin-top:9px;letter-spacing:.1em;color:#9eb7aa}.grid{display:grid;grid-template-columns:1fr 1fr;gap:30px}.grid article{padding:8px 0}.table-wrap{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;vertical-align:top;border-bottom:1px solid #355953;padding:14px 12px}th{font:11px monospace;color:#afc3ac;letter-spacing:.1em}figure{margin:32px 0;border:1px solid #385b58;background:#10292f}figure img{display:block;width:100%;height:auto}figcaption{padding:20px 24px;font-size:14px}figcaption b{font-weight:400;color:#e2e5cd}details{margin-top:10px;color:#9db8ab;font-size:12px}summary{cursor:pointer;letter-spacing:.05em}code,small{display:block;overflow-wrap:anywhere;font-size:10px}.portrait{max-width:420px;margin-left:auto;margin-right:auto}footer{border-top:1px solid #3f615b;margin-top:50px;padding-top:30px;font-size:13px;color:#8fab9f}@media(max-width:660px){main{padding:22px 18px 50px}.metrics{grid-template-columns:1fr 1fr;gap:10px}.metrics article{padding:16px}.grid{grid-template-columns:1fr;gap:10px}h2{font-size:25px}th,td{padding:11px 7px;font-size:12px}figcaption{padding:15px}}'''

labels={
'CORE_TEST_RESULTS':('core.cjs','État, progression, collisions, codec'),
'COLONY_TEST_RESULTS':('colony.cjs','Tableaux, cachettes, soudures, escortes'),
'EXPLORATION_TEST_RESULTS':('exploration.cjs','Géométrie, détours, visée, mémoire'),
'PASSAGES_TEST_RESULTS':('passages.cjs','Raccords, écoute de seuil, détecteur'),
'PERSISTENCE_TEST_RESULTS':('persistence.cjs','MemoryStorage simulé, pas stockage natif certifié'),
'LIFE_TEST_RESULTS':('life.cjs','Habitants, coffres, ateliers, balises'),
'DEFENSE_TEST_RESULTS':('defense.cjs','Volets, alarmes, contournements, tirs'),
'DUCT_TEST_RESULTS':('ducts.cjs','Propriété unique, grilles, préavis, proximité, pression, migrations'),
'INSTALLER_TEST_RESULTS':('installer.mjs','Hôtes de test, conflits, restauration'),
'REAL_UPGRADE_TEST_RESULTS':('upgrade-real.mjs','Vrai payload 0.6 → 0.7 sur un shell hôte de test'),
'BROWSER_V07A':('browser-v07.py A','Début au clavier, ancien export 0.6, verrouillage, relevé et carte'),
'BROWSER_V07B':('browser-v07.py B','Adulte existant, transfert, préavis, pression, exports réels, Newt'),
'BROWSER_V07C':('browser-v07.py C','Formats courts à 130 %, commandes, menus hérités, interruption')}
rows=[f'| {labels[n][0]} | {num(n)}/{num(n)} | {labels[n][1]} |' for n in model_names+['INSTALLER_TEST_RESULTS','REAL_UPGRADE_TEST_RESULTS']+browser_names]
http=reports['BROWSER_V07A']['http']
http_text=('La navigation HTTP locale a réussi ; elle ne constitue pas une recette de fermeture/réouverture ou des quotas natifs.' if http['loaded'] else 'La navigation HTTP locale a été refusée : '+http['error'].split('\n')[0]+'. Le HTML exact a été exécuté avec set_content dans une origine opaque autorisée, sans changement de politique ni contournement.')
qa=f'''# Qualification locale — {v}

Les résultats ci-dessous viennent des suites réellement achevées sur les sources courantes. Aucun compteur historique n’est additionné. Le hash SHA-256 du HTML utilisé par les trois sessions navigateur est `{sha}`. Les assertions et groupes ne désignent pas autant de joueurs ou de machines.

| Suite | Résultat | Portée |
|---|---:|---|
{chr(10).join(rows)}

**Modèle : {model}/{model}. Navigateur courant : {browser}/{browser}.** Les anciens 145 contrôles navigateur de la 0.6 ne sont pas revendiqués comme rejoués. Les {len(caps)} captures sont décrites dans les rapports BROWSER_V07A/B/C.json. Les cinq familles de parcours sont comptées séparément.

| Pilote | Résultat | Portée |
|---|---:|---|
| traversal.cjs | 6/6 | Campagne principale, deux vues × trois difficultés |
| traversal-exploration.cjs | 6/6 | Six détours et leurs raccourcis |
| traversal-life.cjs | 6/6 | Résidents, conversations, réserves, fabrication et pose |
| traversal-defense.cjs | 6/6 | Volets et alarmes accessibles tôt, puis campagne |
| traversal-ducts.cjs | 6/6 | Dix grilles fermées/libérées/écoutées sur place, héritage et campagne |

## Continuité, pas une durée de jeu humaine

Les trente pilotes utilisent les déplacements et commandes du modèle depuis une partie neuve. Ils ne téléportent pas le joueur, ne réécrivent pas sa santé et n’appellent pas de validation forcée d’objectif. Les soins disponibles et l’assistance de début de chapitre restent actifs. Les pilotes connaissent itinéraires et solutions ; aucune difficulté finale ou durée de campagne humaine n’est déduite de leurs chronomètres.

Le tour des dix grilles est effectué avant la crise. Les vrais transferts tardifs éventuels ne remplacent pas les tests localisés : créature sous pression, sortie occupée, perception, compagnon proche, mort pendant entrée, pièce pleine et rupture sont vérifiés séparément. Les fixtures tardives du navigateur sont des sauvegardes explicitement préparées, validées puis chargées par le sélecteur ordinaire. Pas de modification de position, de santé ou de temps pendant l’interaction navigateur.

## Navigateur et stockage

CLI agent-browser absent dans cet environnement. {http_text}

Les boutons et touches commandent la simulation normale. Les attentes portent sur l’état observable ou son temps réellement écoulé, jamais sur une écriture de la minuterie. Les trois sessions sont séparées pour borner leurs ressources. Une première attente échouée visait le libellé historique « PIÈCE COURANTE » ; le bouton réel est « PIÈCE ACTUELLE ». Le sélecteur de test a été corrigé, puis la session entière a été rejouée. Seules les recettes finales achevées sont retenues.

Les exports JSON d’une grille verrouillée, d’un adulte en transport et d’une grille endommagée sont téléchargés puis réimportés. L’identité, la santé et la propriété unique sont conservées, sans double manipulation ou nouvelle créature. Les fichiers real-v01-save.json à real-v06-save.json proviennent des anciennes livraisons ; ils ne sont pas des états courants renommés. Les six sont vérifiés par le modèle ; le vrai 0.6 est aussi importé par le navigateur courant.

Le protocole de double copie et ses erreurs de quota restent éprouvés avec MemoryStorage explicitement simulé. La persistance native après fermeture reste non qualifiée, comme le mode privé, plusieurs onglets simultanés et les quotas réels. La réussite de l’import/export ne certifie pas ces comportements.

## Corrections découvertes pendant cette passe

Le verrouillage vérifie désormais toute présence d’un adulte à la bouche, même s’il n’est pas déjà dans l’état d’entrée. La vérification est refaite à la fin du travail. Une balle mortelle efface l’entrée de gaine du cadavre, pour qu’un export ne contienne pas une créature morte prétendument engagée. Les grilles libérées ne récupèrent pas de santé. Le menu affichait un ancien numéro 0.5 : sa version visible est maintenant 0.7. Le raccourci 4 est inscrit dans l’aide. Le libellé du détecteur est maintenant hors du masque arrondi du radar, pour ne plus en rogner les lettres.

## Captures, documents et périmètre non couvert

Les PNG sont des captures de Chromium exécutant le HTML fourni, pas des illustrations d’intention. Le rapport associe chaque image à la méthode de préparation et à sa pièce. Les formats portrait et paysage courts sont émulés ; ils ne certifient ni téléphone, ni Safari, ni manette physique. Les tests du rapport illustré sont documentaires, séparés des {browser} contrôles du jeu.

Les mises à niveau utilisent le vrai module et l’installateur 0.6 dans un shell de test ; aucun build de l’hôte Tantalus complet n’est revendiqué. Les grilles sont des stations non collisionnables, les gaines des transports discrets, pas des salles pour le joueur ou un réseau d’IA continu. Les sorties hors champ restent en attente, et occuper leur dégagement peut volontairement retarder une arrivée. Les autres limitations de production restent visibles.

{limitations}
'''
(R/'docs/QA_REPORT.md').write_text(qa,encoding='utf-8')
# Publish only screenshots whose current run is recorded and whose actual PNG exists.
order=['01-title-v07.png','03-first-task-v07.png','02-duct-panel-v07.png','04-locked-grille-v07.png','05-listening-record-v07.png','06-local-plan-v07.png','07-exit-warning-v07.png','08-existing-adult-v07.png','09-grille-under-pressure-v07.png','10-grille-torn-v07.png','11-grilles-portrait-v07.png','12-grilles-landscape-v07.png']
fig=[];image_hashes=[]
for i,name in enumerate(order):
 c=caps[name];blob=(R/c['file']).read_bytes();digest=hashlib.sha256(blob).hexdigest();image_hashes.append({'file':c['file'],'sha256':digest})
 cls=' class="portrait"' if 'portrait' in name else ''
 st=c['state'];where=rooms[st['room']]['name'];person=D['characters'][st['character']]['name']
 fig.append(f'<figure id="capture-{i}"{cls}><img src="data:image/png;base64,{base64.b64encode(blob).decode()}" alt="{escape(c["description"],quote=True)}"><figcaption><b>{i+1:02d} — {escape(c["description"])}</b><details><summary>Provenance et contexte</summary><p>{escape(c["setup"])}. {escape(where)} · {escape(person)} · chapitre {st["chapter"]+1}. Ces associations préparées ne sont pas des événements nouvellement authentifiés du roman.</p><code>{escape(c["file"])} · SHA-256 {digest}</code></details></figcaption></figure>')
table=''.join(f'<tr><td>{escape(labels[n][0])}</td><td>{num(n)}/{num(n)}</td><td>{escape(labels[n][1])}</td></tr>' for n in model_names+['INSTALLER_TEST_RESULTS','REAL_UPGRADE_TEST_RESULTS']+browser_names)
html=f'''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fleuve de la Douleur — Rapport v0.7</title><style>{css}</style></head><body><main>
<header><p class="eyebrow">ALIENS: TANTALUS FRONTIER / ARCHIVES MIRE / LIVRAISON LOCALE</p><h1>ALIEN<br>FLEUVE DE<br>LA DOULEUR</h1><p class="subtitle">Dans le souffle des gaines</p><span class="tag">0.7.0-CANDIDATE.1 · 29 SEPTEMBRE 2026</span></header>
<nav><a href="JOUER.html">JOUER</a><a href="docs/CODEX_LEVEL_DESIGN.md">CODEX</a><a href="docs/QA_REPORT.md">RÉSULTATS DÉTAILLÉS</a><a href="README.md">INSTALLATION</a></nav>
<p class="notice">Une créature quitte une pièce, la même créature revient ailleurs. Cette passe ajoute des transferts de maintenance à identité conservée, pas une génération d’ennemis supplémentaire. Le DLC reste autonome ; le moteur natif de Tantalus n’est pas fusionné.</p>
<div class="metrics"><article><b>05</b><span>GAINES TECHNIQUES</span></article><article><b>10</b><span>GRILLES LOCALES</span></article><article><b>{model}</b><span>CONTRÔLES MODÈLE</span></article><article><b>30</b><span>PARCOURS SCRIPTÉS</span></article></div>
<h2>Une présence qui change de pièce</h2><div class="grid"><article><h3>Pas de clone dans les gaines</h3><p>Un adulte existant peut quitter la pièce après avoir perdu sa cible. Son identifiant et sa santé sont transportés. Les petits parasites restent exclus de ce réseau. La perception humaine reste prioritaire.</p></article><article><h3>Sorties annoncées</h3><p>Après le trajet, la bouche vibre pendant 2,4 secondes. Une zone libre est exigée autour du joueur et de son escorte. Si elle reste occupée, l’arrivée attend : aucun personnage n’est déplacé pour créer une attaque.</p></article><article><h3>Un verrou temporaire</h3><p>Deux secondes sur place pour verrouiller, 1,2 pour libérer. Une grille endommagée ne se répare pas en l’ouvrant. L’adulte déjà engagé peut l’arracher, puis un nouvel avertissement précède la sortie.</p></article><article><h3>Écouter et repartir</h3><p>La touche 4 ouvre le dossier local. Une écoute demande 1,7 seconde exposée ; les douze derniers relevés restent datés. Un écho de détecteur indique la bouche, pas la position exacte de la créature hors champ.</p></article></div>
<h2>Les captures du jeu</h2><p>Les douze images suivantes viennent du HTML réellement exécuté par Chromium. Le début au clavier et les scènes préparées sont distingués dans chaque figure. Aucune illustration d’intention n’est utilisée à la place du niveau.</p>
{''.join(fig)}
<h2>Résultats de la recette courante</h2><p><strong>Modèle : {model}/{model}. Navigateur ciblé : {browser}/{browser}. Parcours complets : 30/30.</strong> Les anciens 145 contrôles navigateur 0.6 ne sont pas additionnés. Les pilotes connaissent les solutions ; ils ne donnent pas une durée humaine ni un verdict d’équilibrage.</p><div class="table-wrap"><table><thead><tr><th>SUITE</th><th>RÉSULTAT</th><th>PORTÉE</th></tr></thead><tbody>{table}</tbody></table></div>
<h2>Conserver sa progression</h2><p>Les véritables exports 0.1 à 0.6 sont validés par le modèle ; un export 0.6 est aussi chargé par l’interface. Trois nouveaux téléchargements JSON vérifient grille verrouillée, adulte en transport et grille sous pression. Le même adulte ne revient pas à la source après l’import.</p>
<p class="notice">La persistance native après fermeture reste non qualifiée. MemoryStorage teste le protocole, pas le stockage matériel du navigateur. {escape(http_text)}</p>
<h2>Ce qui reste hors périmètre</h2><p>Cinq transports discrets, pas des espaces de ventilation continus ni un directeur d’IA global. L’arrivée attend la pièce active ; rester près d’une bouche peut la retarder. Les véhicules ne sont pas pilotables. Les dessins restent provisoires. Les nouveaux tracés ne constituent pas un plan certifié du livre.</p>
<footer><p>{escape(limitations)}</p><p>Rapport lié au HTML SHA-256 <code>{sha}</code></p><p>Le paquet conserve les sources et documents de référence utiles sans réimbriquer les archives ou les anciennes galeries d’images.</p></footer></main></body></html>'''
(R/'RAPPORT_ILLUSTRE.html').write_text(html,encoding='utf-8')
meta={'version':v,'passed':True,'codexLines':len(codex.splitlines()),'modelCases':model,'browserCases':browser,'traversals':30,'currentCaptures':len(caps),'reportFigures':len(order),'imageHashes':image_hashes,'standaloneSHA256':sha,'reportSHA256':hashlib.sha256(html.encode()).hexdigest(),'counts':cnt}
(R/'docs/DOCUMENTATION_BUILD.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:meta[k] for k in ['version','codexLines','modelCases','browserCases','traversals','currentCaptures','reportFigures']},ensure_ascii=False,indent=2))
