#!/usr/bin/env python3
"""Verify current byte relationships, report provenance and reproducible standalone."""
from pathlib import Path
import json,hashlib,subprocess,re,base64,sys
R=Path(__file__).resolve().parents[1];sha=lambda b:hashlib.sha256(b).hexdigest();cases=[]
def check(name,condition):
 if not condition:raise AssertionError(name)
 cases.append({'name':name,'passed':True})
read=lambda p:json.loads((R/p).read_text())
js=R/'src/river-of-pain';source=(js/'index.html').read_text();modules=re.findall(r'<script src="([^"]+)"></script>',source)
source=source.replace('<link rel="stylesheet" href="style.css">','<style>'+(js/'style.css').read_text()+'</style>')
for name in modules:
 code=(js/name).read_text();source=source.replace(f'<script src="{name}"></script>','<script>\n'+re.sub(r'</script',r'<\\/script',code,flags=re.I)+'\n</script>')
check('Standalone égale ses vingt modules et son CSS',len(modules)==20 and source.encode()==(R/'JOUER.html').read_bytes())
check('Aucun script ou stylesheet externe requis',not re.search(r'<script[^>]+src=|<link[^>]+stylesheet',source))
for p in sorted(js.glob('*.js')):
 result=subprocess.run(['node','--check',str(p)],capture_output=True,text=True);check('Syntaxe '+p.name,result.returncode==0)
D=read('docs/CONTENT_MANIFEST.json');c=D['manifest']['counts'];check('Version exacte',D['manifest']['version']=='0.7.0-candidate.1')
for k,actual in [('rooms',len(D['rooms'])),('props',sum(len(r['props']) for r in D['rooms'])),('links',sum(len(r['portals']) for r in D['rooms'])//2),('objectives',sum(len(ch['objectives']) for ch in D['chapters'])),('archives',len(D['archives'])),('optionalSteps',sum(len(j['steps']) for j in D['jobs'])),('maintenanceDucts',len(D['ducts']['routes'])),('ductMouths',len(D['ducts']['mouths']))]:check('Comptage réel '+k,c[k]==actual)
check('57 liens joueurs distincts des cinq gaines',c['links']==57 and c['maintenanceDucts']==5 and c['ductMouths']==10)
for route in D['ducts']['routes']:
 ends=[m for m in D['ducts']['mouths'] if m['route']==route['id']];check('Deux extrémités réelles '+route['id'],len(ends)==2 and len({e['room'] for e in ends})==2 and set(route['ends'])=={e['id'] for e in ends})
check('Héritage volets et avertisseurs',len(D['defense']['shutters'])==8 and len(D['defense']['alarms'])==4)
check('Campagne et détours préservés',c['rooms']==42 and c['objectives']==49 and c['optionalSteps']==18)
for i in range(1,7):
 f=R/f'tests/fixtures/real-v0{i}-save.json';v=json.loads(f.read_text());check('Véritable ancienne version déclarée '+f.name,v['id']=='river-of-pain' and v['state']['version']==f'0.{i}.0-candidate.1')
caprows=[]
for part in 'ABC':
 d=read(f'docs/BROWSER_V07{part}.json');check('Recette navigateur actuelle '+part,d['passed'] and d['html_sha256']==sha((R/'JOUER.html').read_bytes()));caprows+=d['captures']
for cap in caprows:
 p=R/cap['file'];check('PNG réel avec provenance '+p.name,p.is_file() and p.read_bytes().startswith(b'\x89PNG\r\n\x1a\n') and bool(cap['setup']))
for p in sorted((R/'captures').glob('*.json')):
 result=subprocess.run(['node','-e',"const fs=require('fs'),C=require('./src/river-of-pain/core.js');const s=C.parseSave(fs.readFileSync(process.argv[1],'utf8'));if(s.state.version!=='0.7.0-candidate.1')process.exit(2)",str(p)],cwd=R,capture_output=True,text=True)
 check('Export navigateur réellement relu par le codec '+p.name,result.returncode==0)
encoded=re.findall(r'<img src="data:image/png;base64,([^"]+)"',(R/'RAPPORT_ILLUSTRE.html').read_text());digests={sha((R/c['file']).read_bytes()) for c in caprows}
check('Douze figures correspondent aux PNG courants',len(encoded)==12 and all(sha(base64.b64decode(b)) in digests for b in encoded))
visual=read('docs/REPORT_VISUAL_RESULTS.json');check('Rapport documentaire réellement testé',visual['passed'] and visual['reportSHA256']==sha((R/'RAPPORT_ILLUSTRE.html').read_bytes()))
binding=read('docs/QUALIFICATION_MODEL.json');actual={p.relative_to(R).as_posix():sha(p.read_bytes()) for p in sorted(js.iterdir()) if p.is_file()};check('Résultats modèle liés exactement aux sources courantes',binding['passed'] and binding['sourceDigests']==actual)
check('Instructions actuelles et option de suppression valide','0.7.0' in (R/'README.md').read_text().split('\n')[0] and '--remove' in (R/'README.md').read_text() and '--uninstall' not in (R/'README.md').read_text())
files=['src/river-of-pain/data.js','docs/CONTENT_MANIFEST.json','JOUER.html'];before={p:sha((R/p).read_bytes()) for p in files}
subprocess.run([sys.executable,'tools/build-content.py'],cwd=R,check=True,capture_output=True);subprocess.run([sys.executable,'tools/build-standalone.py'],cwd=R,check=True,capture_output=True)
check('Reconstruction reproductible des données et du HTML',before=={p:sha((R/p).read_bytes()) for p in files})
report={'version':'0.7.0-candidate.1','passed':True,'cases':cases,'standaloneSHA256':before['JOUER.html'],'sourceDigests':actual,'scope':'File relationships, parser checks and deterministic rebuild; separate from gameplay and document totals.'}
(R/'docs/DELIVERY_VALIDATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(len(cases),'delivery checks PASS')
