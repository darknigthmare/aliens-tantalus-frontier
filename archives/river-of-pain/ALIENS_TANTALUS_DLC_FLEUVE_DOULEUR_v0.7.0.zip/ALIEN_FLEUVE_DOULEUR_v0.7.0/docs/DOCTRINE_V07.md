## Périmètre de la passe 0.7

La même campagne conserve 16 chapitres de jeu, 42 pièces, 57 connexions jouables bidirectionnelles, 49 objectifs principaux, deux escortes et six détours facultatifs de trois étapes. Les 489 placements de décor ne sont pas 489 dessins uniques. Les éléments de crise, cachettes, habitants, réserves, volets et alarmes ne sont pas recomptés comme nouvelles pièces.

Cinq gaines techniques à deux extrémités ajoutent dix bouches de maintenance. Elles servent aux adultes xénomorphes existants et aux interactions locales de leurs grilles. Elles ne sont pas des portes pour le joueur, ni cinq nouvelles pièces. Les conduits jouables réservés à Newt sont distincts et inchangés. Ces tracés et toutes leurs durées sont des créations de gameplay, pas un plan officiel du roman.

## Entrée : déplacer une créature, ne pas en fabriquer une

À partir du stade de crise 2, un adulte vivant peut prendre une gaine proche lorsqu’il a perdu sa cible et sa mémoire de perception. La vue du joueur ou du compagnon, une mémoire récente, un repli devant une fusée et une attaque engagée restent prioritaires. Un petit parasite de type facehugger n’emprunte pas ce nouveau réseau. La gaine ne recrute aucun ennemi hors du contenu existant.

L’adulte rejoint la bouche par la navigation locale et prépare son entrée durant 1,1 seconde. Il reste dans la pièce et peut être touché pendant cette préparation. Une perception renouvelée annule l’entrée. Une balle mortelle supprime l’entrée en cours : un cadavre n’est pas transporté ni rendu vivant après import.

Au départ, la même créature, avec son identifiant et sa santé, est retirée du tableau de la pièce source et placée dans un registre de transfert. Elle n’a jamais deux propriétaires simultanément. La gaine conserve au plus un transfert et les temps de repos évitent une boucle instantanée : 12 secondes pour la liaison, 24 secondes pour l’adulte après arrivée. Les cinq trajets durent de 4 à 5,6 secondes de simulation.

Les deux grilles doivent être ouvertes ou arrachées pour qu’un nouveau départ soit autorisé. Verrouiller la bouche source derrière un adulte déjà engagé ne le rappelle pas, ne le duplique pas et ne le tue pas. Il se trouve déjà dans la liaison. Une grille fermée à destination après son départ peut le retenir.

## Sortie : annonce, dégagement et limites hors champ

Les minuteries de transport avancent pendant le jeu, même hors de la pièce courante et pendant un raccord engagé du personnage. Les menus et l’échec les suspendent. Ce registre temporel n’est pas une simulation physique de la gaine, ni une IA continue de toute la colonie.

La sortie ne se matérialise que lorsque la pièce de destination est active et que le joueur n’est pas en raccord. La grille vibre et un avertissement de 2,4 secondes précède l’arrivée. Une zone de dégagement de 300 unités internes doit rester libre autour du joueur et du compagnon. Il s’agit d’une distance de jeu x/z, pas de mètres. Une obstruction ou une population de douze entrées ennemies déjà atteinte empêche également la matérialisation.

Si le joueur ou son compagnon reste trop près, le moteur maintient le transfert et réinitialise le préavis ; il ne pousse, ne blesse et ne téléporte personne pour forcer une apparition. On peut donc volontairement retarder cette sortie en occupant sa zone. Ce garde-fou de prototype n’est pas un comportement naturel garanti du xénomorphe. Les créatures hors champ ne poursuivent pas un itinéraire autonome complet et ne traversent pas plusieurs gaines en chaîne sans simulation locale.

L’arrivée conserve identité et santé, engage une recherche locale et un bref délai de reprise d’attaque, pas une frappe instantanée. Elle ne livre pas à l’adversaire la position d’un joueur silencieux caché. Le nombre d’adultes n’augmente pas du seul fait du passage.

## Verrouiller, libérer, subir la pression

E ouvre le dossier lorsque la grille est l’interaction prioritaire. La touche 4 ouvre explicitement GAINES TECHNIQUES, également accessible depuis l’équipement. Le dossier ne liste que les bouches de la pièce courante. Les boutons expliquent les refus de distance, de personnage ou d’état. Aucune commande à distance n’existe.

Un adulte humain à portée verrouille en 2 secondes et libère en 1,2 seconde. La lecture du dossier met le monde en pause ; la manipulation se déroule ensuite avec dangers et ennemis actifs. Un déplacement ou une blessure interrompt le travail avant son effet. L’occupation de la bouche par un adulte xénomorphe est vérifiée au départ et à la fin. La fermeture ne retire pas une créature du monde pour libérer artificiellement la grille.

Une grille neuve possède 100 d’intégrité. Sa libération ne la répare pas. Une créature arrivée dans la gaine face à une grille fermée annonce des coups de 0,9 seconde qui retirent chacun 34 points. Trois coups suffisent donc à l’arracher. Les frappes n’avancent qu’avec la destination active, pas dans une pièce abandonnée hors champ. Après rupture, un préavis complet de sortie est encore requis. Les débris restent visibles et aucun verrou ne peut être reconstitué gratuitement.

Ces grilles ferment une bouche technique, pas le passage du joueur dans toute la pièce. Les stations restent non collisionnables pour ses déplacements et ne remplacent pas les huit volets de confinement de la 0.6. Elles ne sont pas de nouvelles couvertures balistiques. Les règles des portes soudées, des volets et de leurs petits parasites sont conservées séparément.

Newt peut écouter mais ne peut ni verrouiller ni libérer les grilles industrielles de cette passe. Elle ne reçoit ni arme, ni détecteur, ni recette supplémentaire. Anne peut actionner un verrou sans devenir un personnage armé.

## Écoute et détecteur : des indices locaux

L’écoute d’une grille demande 1,7 seconde de calme sur place. Un bruit excessif, un déplacement ou une blessure interrompt la manœuvre. Le dossier mémorise au plus douze relevés : identifiant de bouche, date de jeu et indice qualitatif. Frottements, pression contre un verrou ou signal masqué n’affichent pas l’identité exacte d’un ennemi hors champ. « Aucun mouvement perçu » ne constitue pas une certification de sécurité.

La lecture du dossier suspend le jeu mais ne rafraîchit pas les relevés. L’ancienne écoute N aux portes et son dossier O restent indépendants. Le détecteur de Brackett ou Paris peut recevoir un écho de gaine proche lorsqu’un transfert approche de sa sortie, à travers une grille non verrouillée. Le point affiché est celui de la bouche ; ce n’est pas la position précise d’une créature dans un réseau cartographié. Newt ne gagne pas ce capteur.

## Rendu, plan et accessibilité

Les dix stations sont ancrées sur le terrain, triées en profondeur et dessinées sous forme de montant, bouche, grille et verrou. Les états ouvert, fermé endommagé et arraché se distinguent. Les vibrations et poussières annoncent une arrivée ; l’option d’animations atténuées réduit les mouvements, pas le délai de sécurité. Les signaux sonores restent procéduraux et facultatifs.

L’intitulé du contact a été sorti du masque arrondi de l’écran radar, qui en rognait le début. Le plan local ajoute G01A à G05B sans les transformer en destinations du graphe de portes. Le registre reste défilant à 130 % de texte sur écran portrait et paysage court. La ligne de version du menu initial, héritée à tort en 0.5 dans le shell précédent, est corrigée en 0.7.

## Persistance, validation et retours au point de contrôle

Le format externe de campagne reste `river-of-pain`, schéma 1. Le registre `ducts.revision = 7` conserve grilles, dégâts, repos, créatures transportées, préavis, coups en cours et relevés. Les vrais exports 0.1 à 0.6 reçoivent des grilles ouvertes et aucun transfert fictif. Le contenu des coffres, les objectifs et les poches antérieures ne sont pas réinitialisés.

Un travail manuel de verrouillage inachevé est annulé à l’import, sans fausse manipulation validée. Un adulte déjà transporté reprend son temps restant, sa santé et son propriétaire unique. Les doublons entre pièce et gaine, liaisons inconnues, minuteries hors bornes, grilles incohérentes et entrées d’ennemis morts sont refusés. Un point de contrôle restaure tout le monde à son état enregistré ; une action effectuée ensuite n’est pas arbitrairement conservée après une mort.

Le protocole à deux copies locales reste éprouvé avec MemoryStorage simulé. Il ne certifie pas le stockage natif après fermeture du navigateur, les quotas réels, les onglets concurrents ou le mode privé. Les téléchargements et imports JSON par les boutons ordinaires sont éprouvés séparément. Les archives intégrales précédentes restent des livraisons distinctes ; le paquet courant n’imbrique pas leurs captures pour gonfler sa taille.

## Recette et limites de production

Les tests du modèle couvrent les deux sens, les deux vues, les priorités de perception, l’identité unique, la sécurité des sorties, la pression des grilles et les migrations. Cinq familles de six pilotes parcourent la campagne depuis une partie neuve. Le dernier tour ajoute les dix grilles, fermées, libérées et écoutées sur place pendant le calme, puis termine les activités héritées et la campagne. Les scènes de menace sous pression sont éprouvées séparément avec des sauvegardes préparées, pas revendiquées comme trente parties humaines.

Ces pilotes connaissent routes et solutions. Ils vérifient la continuité, pas la difficulté de découverte, la durée humaine ou des performances sur la machine du joueur. La recette navigateur courante est ciblée sur trois sessions 0.7 et n’additionne pas les 145 anciens contrôles 0.6 comme s’ils avaient été rejoués.

Les dessins restent stylisés et provisoires. Les véhicules ne sont toujours pas pilotables et les raccords d’escaliers ou monte-charges restent bornés, non des volumes verticaux continus. Aucune nouvelle issue canonique, évacuation de Newt ou mort de reine n’est ajoutée. Le moteur hôte, ses sauvegardes et l’écho Frontière 2204 ne sont pas modifiés. Aucun push GitHub ni déploiement Vercel.
