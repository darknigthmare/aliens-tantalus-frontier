# 0.7.0-candidate.1 — Dans le souffle des gaines

Base : vraie archive 0.6.0, empreinte dans SOURCE_V07.json. Même campagne, mêmes 42 pièces et 57 liens jouables ; les cinq nouvelles gaines ne sont pas des salles ni des portes du joueur.

## Ajouts exécutables

Cinq gaines / dix bouches. Transfert d’adultes déjà existants à identité et santé conservées ; choix après perte de perception ; entrée exposée ; un seul propriétaire ; temps de trajet ; sortie annoncée ; dégagement du joueur et de son escorte. Verrouillage et écoute de grille sur place, pression destructrice et garde-fous d’occupation. Dossier 4 / équipement, emplacements G du plan local, écho local du détecteur.

Registre de sauvegarde `ducts.revision = 7` validé et migré depuis les vraies sauvegardes 0.1 à 0.6. Menus et mort suspendent les délais ; les minuteries de transport avancent hors champ, mais les sorties et attaques de grille exigent la destination active.

## Corrections

Fermeture refusée si un adulte occupe la bouche, même hors état d’entrée ; condition répétée au terme. Mort par balle annule proprement l’entrée en cours. Numéro visible du menu corrigé. Libellé de portée du détecteur déplacé hors du masque arrondi qui rognait ses lettres. Sources et build autonome reconstruits à l’identique et vérifiés.

## Qualification de cette livraison

830 contrôles du modèle, trente pilotes complets, 28 cas d’installateur et quatre mises à niveau avec le vrai payload 0.6 sur un hôte de test. 47 contrôles navigateur courants dans trois sessions, douze captures de jeu. Dix-huit contrôles documentaires du rapport et 69 vérifications de livraison sont séparés du gameplay. Les anciens 145 contrôles navigateur 0.6 ne sont pas additionnés.

## Pas de changement de statut de production

Toujours autonome, pas intégré au GameEngine natif, aucun push ou déploiement. Graphisme stylisé provisoire ; roman intégral non consulté ; plans et règles originaux. Pas de population/IA globale continue, pas de gaines traversables par le joueur, pas de véhicule pilotable. Stockage natif après fermeture non qualifié ; import/export réels vérifiés. Archives précédentes conservées séparément, pas réimbriquées dans le nouveau ZIP.
