# ALIEN — Fleuve de la Douleur · 0.7.0-candidate.1

## Hadley’s Hope · Dans le souffle des gaines

Prototype jouable autonome non officiel pour le projet Aliens: Tantalus Frontier. Suite réelle de la 0.6, dont les sources ont été copiées et modifiées. Ce paquet n’est pas le jeu principal complet et n’intègre pas son moteur natif. Aucune publication distante.

## Jouer

Extraire l’archive dans un dossier, puis ouvrir `JOUER.html` dans un navigateur de bureau récent. Sous Windows, `LANCER_WINDOWS.bat` ouvre le même fichier. Aucun serveur, compte, installation Node ou téléchargement d’assets n’est requis pour cette version autonome. Les sources modulaires sont sous `src/river-of-pain`.

Déplacement Q/D ou A/D ; Z/S ou W/S pour la profondeur ; E utiliser ; F tirer ; R recharger ; C s’accroupir ; Maj courir ; Espace + direction viser sur place ; souris maintenue viser/tirer ; I équipement ; Tab plan ; J carnet ; Échap pause. Anne et Newt sont désarmées.

L lampe, T détecteur des Marines, G cachette, X fusée, H soins, B soudure, V suivre/attendre, M balise de repli, N écouter une porte, O relevés de seuils, U détours, P conversation proche, Y registre colonial, K balise sonore, Entrée dispositifs de confinement. **4 : dossier des grilles techniques de la pièce** ; les mêmes actions sont accessibles depuis l’équipement. Une grille n’est pas une porte traversable par le joueur.

## Nouveauté

Cinq gaines de maintenance relient dix bouches. Des adultes xénomorphes déjà existants peuvent les emprunter après avoir perdu leur cible, à partir du stade 2. Identité et santé sont transportées, aucun ennemi n’est créé. Sortie annoncée 2,4 s, zone de dégagement, grilles verrouillables en 2 s et libérables en 1,2 s. Écoute locale 1,7 s. Une grille peut céder sous la pression, sans réparation gratuite ; Newt écoute seulement. Le codex décrit les limites hors champ et les règles exactes.

## Sauvegardes

Pause → EXPORTER produit un fichier JSON ; Pause → IMPORTER charge un fichier enregistré. Les véritables exports 0.1 à 0.6 sont acceptés et testés. Conserver une copie extérieure du JSON reste utile. Le stockage local natif peut être restreint par l’origine ou le navigateur : sa persistance après fermeture n’est pas certifiée par cette livraison. Les tests MemoryStorage qualifient uniquement le protocole à deux copies. Import/export réels testés dans Chromium.

## Installation facultative dans une copie de Tantalus

Node 20 ou plus est nécessaire seulement pour l’installateur et les tests. Depuis ce dossier :

```sh
node tools/install.mjs /chemin/vers/la-copie-de-tantalus
node tools/install.mjs /chemin/vers/la-copie-de-tantalus --upgrade
node tools/install.mjs /chemin/vers/la-copie-de-tantalus --remove
```

L’installateur ajoute un lanceur vers le runtime autonome dans le menu du projet hôte compatible. Il contrôle les empreintes, refuse les conflits, sauvegarde et restaure les fichiers concernés. Il ne fusionne pas GameEngine, SaveSystem ni les sauvegardes MIRE natives. Tester sur une copie. Les tests hôtes inclus utilisent un shell de test, pas le dépôt complet. Aucun push GitHub ou déploiement Vercel.

## Reconstruction et tests

```sh
npm run build
npm test
npm run test:browser
npm run docs
npm run test:report
npm run verify
npm run package
```

Python 3 et Node 20+ pour build/modèle ; Playwright Python et Chromium pour les tests navigateur. `tests/browser-v07.py` utilise `/usr/bin/chromium` : adapter ce chemin à la machine cible. La recette tente HTTP local puis, en cas de restriction, exécute le HTML exact dans une origine opaque autorisée, sans contourner la politique du navigateur. Les résultats ne sont pas des tests de Safari, téléphone ou manette réels.

Le test `upgrade-real.mjs` exige le dossier extrait de la **vraie version 0.6** en argument et n’est pas lancé automatiquement par `npm test`. Le résultat de la livraison est inclus. Les scripts navigateur v01–v06 sous `tests` sont conservés comme sources historiques, ne font pas partie de `test:browser` 0.7 et leurs anciens compteurs ne qualifient pas cette version.

`RAPPORT_ILLUSTRE.html` contient les captures courantes intégrées. `docs/QA_REPORT.md` décrit les tests exécutés. `docs/CODEX_LEVEL_DESIGN.md` décrit les pièces et les mécanismes. `DELIVERY_MANIFEST.json` et `CHECKSUMS.sha256` servent à contrôler le contenu reçu.

## Production et sources

Graphisme par code provisoire ; aucune nouvelle image générée ou illustration promotionnelle substituée à une capture de jeu. Roman intégral non consulté, textes et raccords de gameplay originaux, pas adaptation 1:1 certifiée. Les cinq gaines ne sont pas un directeur global ou un espace physique continu. Les anciens ZIP ne sont pas réimbriqués dans ce paquet. Voir `LICENSE_NOTICE.md`, `docs/SOURCES_ET_CONTINUITE.md` et les rapports historiques conservés.
