# Alien — Fleuve de la Douleur · 0.6.0-candidate.1

## Hadley’s Hope — Tenir les passages

Extension cumulative de la 0.5 : huit volets locaux, quatre avertisseurs, navigation et ordre des impacts révisés. La campagne conserve 16 chapitres, 42 pièces, 57 liaisons, 49 objectifs et six détours.

DLC autonome avec lanceur additionnel, pas le jeu Tantalus complet ni son GameEngine natif. Aucun push GitHub ni déploiement Vercel. Dessins stylisés par code, pas atlas définitifs ou reconstitution 1:1. Roman intégral non consulté : plans, dialogues, tâches et documents sont une condensation originale. L’écho Frontière 2204 et les sauvegardes du moteur hôte ne sont pas modifiés.

## Jouer immédiatement

Extraire toute l’archive, puis ouvrir **JOUER.html** dans un navigateur de bureau, ou **LANCER_WINDOWS.bat** sous Windows. Le HTML est autonome, sans téléchargement de scripts ni de graphismes. Les sources modulaires restent dans `src/river-of-pain`.

Au premier lancement : NOUVELLE PARTIE, puis PRENDRE LE CONTRÔLE. Le son est facultatif. La sauvegarde automatique tente son stockage propre au DLC ; exporter régulièrement en JSON reste recommandé dans ce prototype, car la persistance native n’a pas été qualifiée dans l’environnement de recette.

## Commandes

| Action | Clavier |
|---|---|
| Marcher / profondeur | Q-D ou A-D, Z-S ou W-S, flèches |
| Se baisser / courir | C / Maj |
| Interagir | E |
| Dispositifs de la pièce | ENTRÉE, ou bouton depuis I |
| Équipement / plan | I / Tab |
| Viser sur place et tirer | Espace + directions / F |
| Viser et tirer au pointeur | Bouton gauche maintenu sur le terrain |
| Lampe / détecteur des Marines | L / T |
| Cachette / écouter au seuil | G / N |
| Souder une porte | B, personnages autorisés seulement |
| Suivre-attendre du compagnon | V |
| Soins / fusée / rechargement | H / X / R |
| Poser une balise sonore / un repère | K / M |
| Parler / contacts | P / Y |
| Détours / relevés de seuil / carnet | U / O / J |
| Pause | Échap |

ENTRÉE ne remplace pas V. Le dossier local ne permet aucune action à distance. Un volet conserve ses dégâts, et un avertisseur dépend du courant. Une cible humaine visible reste prioritaire sur le signal. Newt peut libérer une poignée basse, pas fermer le volet ou déclencher l’alarme.

## Reprendre un export 0.1 à 0.5

Ouvrir Pause → Importer, sélectionner le JSON, choisir CHARGER puis REPRENDRE LE PARCOURS. Les vrais fichiers des cinq versions ont été testés. Les coffres, poches et objectifs sont conservés ; les nouveaux dispositifs sont initialisés sans actions antérieures fictives. Un travail inachevé est annulé à l’import, tandis qu’un signal déjà programmé garde son délai et son cycle.

Les fichiers JSON contiennent la partie et son point de contrôle. Reprendre après mort restaure ce dernier : les actions réalisées depuis ne sont pas conservées artificiellement. Les deux copies locales alternées ne touchent jamais les sauvegardes du Tantalus natif.

## Lanceur facultatif dans une copie de Tantalus

Nécessite Node.js 20 ou ultérieur. Depuis ce dossier, indiquer le dossier de la copie de Tantalus :

```sh
node tools/install.mjs "CHEMIN_VERS_TANTALUS"
```

Une installation antérieure intacte se remplace avec :

```sh
node tools/install.mjs "CHEMIN_VERS_TANTALUS" --upgrade
```

Retrait réversible :

```sh
node tools/install.mjs "CHEMIN_VERS_TANTALUS" --remove
```

L’installateur vérifie les empreintes et refuse un dossier inconnu ou modifié. Il ajoute uniquement un lanceur et les fichiers du module. Il ne fusionne pas GameEngine, SaveSystem, le catalogue MIRE ou les autres DLC. Les tests utilisent des shells hôtes de test ; aucun build complet du dépôt distant, push ou déploiement n’est revendiqué.

## Reproduire les vérifications

```sh
npm run build
npm test
node tests/upgrade-real.mjs "CHEMIN_VERS_L_ARCHIVE_0.5_EXTRAITE"
npm run test:browser
npm run docs
npm run test:report
python tools/verify-delivery.py
python tools/package-release.py
```

La recette navigateur utilise Python, Playwright et Chromium ; `CHROMIUM_PATH` peut indiquer son exécutable. Dans l’environnement de livraison il se trouve à `/usr/bin/chromium`. Le test de vraie mise à niveau nécessite les octets de l’ancienne archive ; ils ne sont pas reconstruits à partir d’un faux numéro de version. Les rapports d’historique ne qualifient pas le code courant.

## Documents

`RAPPORT_ILLUSTRE.html` : captures embarquées et portée de la livraison. `docs/CODEX_LEVEL_DESIGN.md` : fiches des 42 pièces et équipements. `docs/QA_REPORT.md` : résultats et limites. `docs/SOURCE_V06.json` : provenance de la 0.5. `DELIVERY_MANIFEST.json` et `CHECKSUMS.sha256` : identité des octets livrés.

Modèle : 718 cas/groupes réussis ; 24 parcours automatisés ; 145 contrôles navigateur. Ces chiffres ne sont pas une certification commerciale ou une partie humaine de la campagne.
