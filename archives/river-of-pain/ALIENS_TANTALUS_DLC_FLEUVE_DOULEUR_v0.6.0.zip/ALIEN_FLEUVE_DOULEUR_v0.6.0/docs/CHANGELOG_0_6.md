# Changements — 0.6.0-candidate.1

Huit volets locaux, quatre avertisseurs et dossier ENTRÉE / équipement. Fermeture occupée refusée ; manipulation exposée ; libération Newt des deux côtés. Intégrité conservée à la réouverture, rupture définitive. Adultes contournent ou frappent ; petits parasites passent dessous. Avertisseurs finis, courant requis, signal local et destructible, sans création d’ennemis.

Navigation par segments libres et coins élargis des obstacles ; impacts classés par premier obstacle réel ; garde-fou de projection classique. Rendu des commandes trié indépendamment. Sauvegardes réelles 0.1 à 0.5 migrées sans inventer de ressources ; véritables exports/imports des nouveaux états vérifiés.

42 pièces, 57 liens, 49 objectifs, six détours et systèmes 0.5 conservés. 718 cas/groupes du modèle, 24 parcours et 145 contrôles navigateur achevés. Ni intégration native, publication, assets définitifs, simulation hors champ intégrale ou véhicule pilotable.
