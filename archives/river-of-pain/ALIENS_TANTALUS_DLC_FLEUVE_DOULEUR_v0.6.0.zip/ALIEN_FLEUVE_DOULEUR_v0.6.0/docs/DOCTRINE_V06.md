## Périmètre de la passe 0.6

La 0.6 prolonge les mêmes 16 chapitres, 42 pièces, 57 connexions bidirectionnelles, 49 objectifs et six détours. Elle ajoute huit volets mécaniques dans les pièces et quatre avertisseurs locaux. Ces équipements ne sont ni de nouvelles pièces ni douze missions supplémentaires. Les 62 couvertures statiques sont conservées ; jusqu’à huit emprises dynamiques s’y ajoutent lorsque leurs volets sont fermés. Les 489 placements de décor, 118 éléments conditionnels, 24 cachettes, 30 notes, 12 résidents, 24 sujets, 12 contenants et trois établis restent comptés séparément.

Les appareils, leurs durées et leurs règles sont des créations de gameplay. Ils ne sont pas des appareils relevés dans un plan officiel de Hadley’s Hope. Les mécanismes de cette passe ne changent pas le destin narratif de Newt et ne provoquent ni secours extérieur ni évacuation supplémentaire.

## Volets : agir sur le terrain, pas depuis une carte

E propose un appareil lorsqu’il est l’interaction prioritaire. ENTRÉE ouvre explicitement le dossier DISPOSITIFS LOCAUX, également disponible depuis l’équipement. Le dossier montre uniquement les appareils de la pièce courante. Une commande hors de portée est désactivée et explique pourquoi. Une entrée dans le dossier ne ferme aucun volet à distance. V conserve l’ordre suivre/attendre du compagnon.

Chaque volet possède deux commandes, situées de part et d’autre de son emprise. La fermeture prend 2,6 secondes et la libération adulte 1,6 seconde. La lecture se fait en pause, mais la manipulation reprend dans le monde avec les ennemis et dangers actifs. Une blessure annule le travail ; s’éloigner de plus de 38 unités de son point de départ l’interrompt aussi. Le mécanisme produit du bruit. L’état physique ne change qu’au terme de l’action : les lamelles ne sont pas une simulation mécanique continue.

La descente est refusée si le joueur, son compagnon, une créature vivante ou un résident occupe l’emprise. La même vérification est refaite à la fin : un acteur qui entre pendant la préparation empêche la fermeture. Cette sûreté n’éjecte, n’écrase ou ne téléporte personne. Les points de pose ont été écartés des routines habituelles des habitants ; une intrusion imprévue continue de bloquer la fermeture.

## Une couverture temporaire, pas une pièce invulnérable

Le volet fermé bloque les adultes, les déplacements du joueur et du compagnon, les tirs et la ligne de vue traversant son volume au sol. Il commence à 100 d’intégrité. Une balle le dégrade de quatre points ; une frappe d’adulte de 36 points après une préparation de 0,85 seconde. Ces nombres sont des valeurs de jeu. Il n’existe pas de réparation dans cette passe. Rouvrir ne restitue aucune intégrité. À zéro, le volet devient un débris traversable et ne peut plus être réarmé.

Dans une pièce avec profondeur, une allée libre reste une route possible. L’adulte essaie de la contourner au lieu de frapper un obstacle évitable. Si aucune route ne rejoint sa dernière position perçue, il s’approche du volet bloquant, annonce sa frappe, puis l’attaque. Le temps de préparation et le délai entre coups donnent un avertissement. Les petits parasites de type facehugger se glissent sous les volets : ils n’utilisent pas leur collision de déplacement, mais le volet continue de masquer leur ligne de vue et d’arrêter les projectiles.

Le volet ne bloque pas arbitrairement le graphe colonial ; il bloque une portion de la pièce. Les accès restent à leurs vraies positions. Le parcours principal est conservé et toutes les ouvertures conservent les restrictions d’autorisation existantes, notamment le hangar scientifique. Aucun appareil ne doit devenir un moyen de contourner cette autorisation.

## Newt : libération de secours, pas équipement militaire

Newt peut tirer la poignée basse de chaque côté d’un volet fermé en 1,1 seconde. Elle ne peut pas l’abaisser et ne peut pas programmer les avertisseurs industriels. La libération reste une action à portée et exposée, pas une ouverture depuis les menus à distance. Anne peut utiliser les mécanismes d’adulte sans recevoir d’arme. Brackett et Paris conservent leur armement propre.

## Avertisseurs : laisser quatre secondes pour s’éloigner

Quatre avertisseurs utilisent le circuit de leur pièce. Une programmation physique de 1,2 seconde consomme un cycle, puis laisse quatre secondes avant le signal. Celui-ci dure dix secondes, avec des pulsations espacées de 1,5 seconde. Un réarmement de 45 secondes court à partir du déclenchement. Deux cycles au maximum sont disponibles par avertisseur pour toute la reconstitution. Ils ne se rechargent pas au changement de chapitre ou de personnage.

Une coupure interdit la programmation. Si le courant disparaît après déclenchement, le signal s’éteint sans rendre le cycle dépensé. Une créature peut atteindre et détruire l’avertisseur. Il reste alors hors service ; ce n’est ni un explosif ni un piège infligeant des dégâts.

Le signal peut orienter une créature qui a perdu une cible humaine dans la même pièce. La portée de recette est 950 unités sans obstruction, 470 avec une obstruction pertinente. Une personne visible ou un compagnon exposé reste prioritaire : le signal ne supprime pas magiquement la vue. Les dispositifs portables déjà fabriqués restent disponibles. Aucun avertisseur ne crée d’ennemi ou n’attire une créature depuis toute la colonie.

Les minuteries avancent hors champ et pendant les raccords engagés ; les menus les suspendent. Les créatures hors champ ne sont toujours pas simulées en continu. La portée et les pulsations sont des règles de gameplay, pas une modélisation acoustique physique.

## Navigation et ordre des impacts

Le chemin local utilise désormais les coins des obstacles agrandis du rayon de l’acteur. Chaque segment doit être libre. Le suivi ralentit près du point de passage et le rejoint avant de changer de direction ; il ne coupe plus un angle simplement parce que le prochain repère est proche. Une fermeture, une ouverture ou une rupture invalide les chemins concernés. Les compagnons utilisent les mêmes emprises actives.

L’intersection d’un tir avec une couverture est analytique : un obstacle mince ne disparaît plus entre deux échantillons espacés. Le moteur compare l’obstacle et la créature rencontrés le long du segment et applique l’impact le plus proche. Une cible derrière un volet n’est pas touchée avant lui. Les diagonales restent celles du sol x/z, pas une visée verticale vers le plafond.

Une poursuite déjà engagée conserve son niveau de recherche tant que la mémoire de huit secondes reste valide ; elle continue vers la dernière position perçue, pas vers une position silencieuse inconnue. Cette correction évite un abandon artificiel après une première frappe. L’expiration de la mémoire est conservée. Les leurres ne remplacent pas la perception d’une personne exposée.

Le passage à la vue classique est refusé si sa projection placerait le joueur ou son compagnon dans un obstacle. Le sélecteur revient à la vue réellement conservée. Un ennemi dont la projection serait dans une emprise est recalé sur un appui horizontal libre : c’est une sécurité de projection, pas une nouvelle capacité de déplacement. Aucune promesse de collision artistique pixel par pixel n’est faite.

## Rendu et lecture

Les volets et avertisseurs possèdent un dessin séparé dans le tri en profondeur. Le socle du volet correspond à son emprise physique. Les deux commandes sont triées indépendamment du panneau, pour ne pas recouvrir le visage du joueur situé devant. Le volet montre son ouverture, ses dégâts ou ses débris. L’avertisseur montre le délai, le signal et l’état hors service. Une frappe ennemie annoncée possède une indication au-dessus de la créature.

Le plan local ajoute les repères CF et les avertisseurs, ainsi que l’emprise dynamique réellement fermée. La carte coloniale conserve ses 57 liaisons ; les dispositifs n’ajoutent pas de téléportation. Le dossier est défilant et testé à 130 % sur les formats 1280×720, 844×390 et 390×844. Le mode d’animations atténuées ne supprime pas les délais de danger. L’audio procédural reste facultatif et aucune piste protégée n’est ajoutée.

## Sauvegardes et import

Le registre `defense.revision = 6` conserve les états et intégrités des huit volets, les cycles et minuteries des quatre avertisseurs ainsi que les statistiques de manipulation. Une fermeture ou programmation inachevée est annulée à l’import, sans consommer d’action supplémentaire. Un signal déjà programmé reprend son délai et son cycle sans double prélèvement. Les raccords engagés conservent leur reprise indépendante.

Les fichiers réels 0.1 à 0.5 restent acceptés. Ils reçoivent des volets ouverts et avertisseurs neufs, sans fabriquer des actions passées. Leurs coffres, poches et progrès restent ceux de l’export. Les états incohérents sont refusés : identifiant manquant, intégrité impossible, minuteur hors bornes, volet détruit en parfait état ou personnage coincé dans un volet fermé. Une reprise après échec restaure le point de contrôle, y compris les équipements : « persistant » ne signifie pas conservation des actions faites après ce point de contrôle.

Le protocole local à deux copies reste testé avec un stockage mémoire simulé. La tentative HTTP locale de cette passe a renvoyé `ERR_BLOCKED_BY_ADMINISTRATOR`. Le HTML exact est testé dans l’origine opaque autorisée via `set_content`, sans contourner cette politique. Le stockage natif après fermeture, les onglets concurrents et les quotas réels restent non qualifiés. Les véritables téléchargements et imports JSON du volet endommagé et de l’alarme en délai sont vérifiés séparément.

## Portée de la recette

Les quatre familles de parcours démarrent une partie neuve et utilisent les déplacements, les interactions et l’équipement autorisés. Le nouveau tour ferme et rouvre les sept volets accessibles avant la crise depuis leurs deux côtés, traverse les bandes ouvertes et programme les quatre avertisseurs, puis termine aussi les habitants, les réserves, les détours et la campagne. Le volet du hangar reste derrière son autorisation scénaristique ; il est testé séparément dans les deux sens et les deux vues avec une scène préparée, comme les attaques et les cas d’occupation.

Les tests ne se font pas passer pour des parties humaines. Les pilotes connaissent les chemins et les solutions ; les images de scènes préparées sont identifiées dans leurs rapports. Aucun résultat n’est une mesure de durée humaine, une certification de difficulté ou un essai de performance sur la machine du joueur.

## Héritage conservé et limites

Les systèmes de la 0.5 restent actifs : routines locales des douze habitants aux stades 0/1, thèmes effectivement lus, réserves finies et couvercles ouverts, poches propres aux adultes, établis et leurres portables. Les 21 raccords restent bornés et le combat normal est suspendu pendant leur trajet engagé. La préparation, l’écoute et les manipulations restent exposées. Il n’existe toujours pas de véhicule pilotable ni d’axe vertical continu librement exploratoire.

Les deux escortes, la soudure des portes, les tableaux, les jets, les cachettes, le détecteur et la lampe conservent leurs règles. Les dessins restent stylisés et provisoires, sans nouvel atlas définitif. Le moteur hôte, ses sauvegardes et l’écho Frontière 2204 ne sont pas modifiés. Aucun push GitHub ni déploiement Vercel n’est effectué.
