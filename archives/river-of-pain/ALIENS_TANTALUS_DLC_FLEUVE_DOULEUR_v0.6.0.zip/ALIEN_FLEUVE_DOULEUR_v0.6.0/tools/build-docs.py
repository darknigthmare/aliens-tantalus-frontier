#!/usr/bin/env python3
"""Generate 0.6 room codex and illustrated delivery report from the shipped data and completed QA.
Refuses incomplete or failed suites. Standard library only; does not publish anything.
"""
from pathlib import Path
from html import escape
from collections import Counter
import base64, json, hashlib, re
R=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((R/'docs'/n).read_text(encoding='utf-8'))
D=read('CONTENT_MANIFEST.json');rooms={r['id']:r for r in D['rooms']};m=D['manifest'];v=m['version'];cnt=m['counts']
assert v=='0.6.0-candidate.1'
fmt=lambda n: str(round(n,3)).rstrip('0').rstrip('.') if isinstance(n,float) else str(n)
cell=lambda s:str(s).replace('|',' / ').replace('\n',' ')
limitations='DLC autonome avec lanceur additionnel, pas le jeu Tantalus complet ni son GameEngine natif. Aucun push GitHub ni déploiement Vercel. Dessins stylisés par code, pas atlas définitifs ou reconstitution 1:1. Roman intégral non consulté : plans, dialogues, tâches et documents sont une condensation originale. L’écho Frontière 2204 et les sauvegardes du moteur hôte ne sont pas modifiés.'
model_names=['CORE_TEST_RESULTS','COLONY_TEST_RESULTS','EXPLORATION_TEST_RESULTS','PASSAGES_TEST_RESULTS','PERSISTENCE_TEST_RESULTS','LIFE_TEST_RESULTS','DEFENSE_TEST_RESULTS']
browser_names=['BROWSER_TEST_RESULTS','BROWSER_V02_TEST_RESULTS','BROWSER_V03_TEST_RESULTS','BROWSER_V04_TEST_RESULTS','BROWSER_V05_TEST_RESULTS','BROWSER_V06_TEST_RESULTS']
reports={n:read(n+'.json') for n in model_names+browser_names+['INSTALLER_TEST_RESULTS','REAL_UPGRADE_TEST_RESULTS']}
for n,r in reports.items():
 if not r.get('passed'):raise RuntimeError('Recette incomplète ou en échec : '+n)
 if r.get('version',v)!=v:raise RuntimeError('Rapport d’une autre version : '+n)
tr=read('TRAVERSAL_RESULTS.json');alltr=read('TRAVERSAL_EXPLORATION_RESULTS.json')
assert len(tr)==len(alltr)==6 and all(r['passed'] for r in tr+alltr)
assert all(r['visited']==42 and len(r['detours'])==6 for r in alltr)
lifetr=read('TRAVERSAL_LIFE_RESULTS.json');assert lifetr['passed'] and len(lifetr['cases'])==6
deftr=read('TRAVERSAL_DEFENSE_RESULTS.json');assert deftr['passed'] and len(deftr['cases'])==6
num=lambda n:reports[n]['cases'] if isinstance(reports[n]['cases'],int) else len(reports[n]['cases'])
model=sum(num(n) for n in model_names);browser=sum(num(n) for n in browser_names)
caprows=sum((reports[n]['captures'] for n in browser_names),[]);caps={Path(c['file']).name:c for c in caprows}
assert len(caps)==len(caprows)
for c in caprows:assert (R/c['file']).is_file() and c.get('setup')
timings={'escalier':(.45,1.4),'échelle':(.5,1.8),'monte-charge':(1.2,2.4),'sas':(1.1,1.1)}
seen=set();links=[]
for r in D['rooms']:
 for p in r['portals']:
  key=tuple(sorted([r['id'],p['to']]))
  if key in seen:continue
  seen.add(key)
  if p['kind'] in timings:links.append((r,p))
assert len(links)==21
by_kind=Counter(p['kind'] for _,p in links)
principles=(R/'docs/DOCTRINE_V06.md').read_text(encoding='utf-8')
lines=['# ALIEN — Fleuve de la Douleur','',f'## Codex de level design · {v}','',m['subtitle'],'',limitations,'',principles]
lines += ['## Huit volets dans les pièces','', '| Volet | Pièce | Emprise x / z ; largeur / profondeur | Commandes gauche et droite x / z |','|---|---|---|---|']
for d in D['defense']['shutters']:
 lines.append(f"| {d['label']} · `{d['id']}` | {rooms[d['room']]['name']} | {d['x']} / {d['z']} ; {d['w']} / {d['d']} | "+' ; '.join(f"{a['x']} / {a['z']}" for a in d['controls'])+' |')
lines += ['', 'En vue classique, z = 0,7 et profondeur de volet = 0,10. L’emprise devient physique seulement à fermeture réussie. Intégrité 100 ; fermeture 2,6 s, ouverture adulte 1,6 s, libération Newt 1,1 s. Pas de réparation.','', '## Quatre avertisseurs locaux','', '| Avertisseur | Pièce / circuit | x / z | Programmation → délai → signal | Réarmement / cycles |','|---|---|---|---|---|']
for d in D['defense']['alarms']:
 lines.append(f"| {d['label']} · `{d['id']}` | {rooms[d['room']]['name']} / {d['circuit']} | {d['x']} / {d['z']} | 1,2 s → 4 s → 10 s | 45 s / 2 |")
lines += ['','Les cycles expirent hors champ, pas les parcours des ennemis. Un circuit coupé éteint le signal sans rembourser le cycle. La commande exige la présence d’un adulte à portée.','']
lines += ['## Douze personnes de service originales','']
for d in D['life']['residents']:
 lines += [f"### {d['name']} · `{d['id']}`",'',f"**{d['role']} · {rooms[d['room']]['name']} · stades 0 et 1 uniquement**",'',f"Silhouette : hauteur {d['height']}, accessoire `{d['tool']}`, apparence `{d['hair']}`. Trajet local : "+' → '.join(f"({q['x']} / {q['z']})" for q in d['points'])+'. Retrait : '+str(d['refuge'])+'.','',f"Avant la crise : « {d['intro'][0]} »",'',f"Premiers incidents : « {d['intro'][1]} »",'']
 for t in d['topics']:lines += [f"**{t['label']}** · `{t['id']}`",'',t['text'],'']
 lines += ['Ces réponses doivent être demandées sur place pour être conservées. Aucun suivi à distance, crédit de mission ou sort canonique attribué.','']
lines += ['## Réserves finies et établis','', '| Réserve / identifiant | Pièce | Point x / z | Contenu initial |','|---|---|---|---|']
for d in D['life']['containers']:lines.append(f"| {d['label']} · `{d['id']}` | {rooms[d['room']]['name']} | {d['x']} / {d['z']} | "+' ; '.join(f"{n} {D['life']['items'][k]['label']}" for k,n in d['items'].items())+' |')
lines += ['', 'Les contenus sont partagés entre les protagonistes. Les prises respectent les capacités ; les surplus restent dans le meuble.','', '| Établi / identifiant | Pièce | Point x / z | Recettes |','|---|---|---|---|']
for d in D['life']['benches']:lines.append(f"| {d['label']} · `{d['id']}` | {rooms[d['room']]['name']} | {d['x']} / {d['z']} | Balise sonore / recharge de lampe |")
lines += ['','Les stations ne sont pas des couvertures collisionnables supplémentaires. Le point ci-dessus est la cible physique de l’interaction, avec une portée de proximité.','']
lines += ['## Registre des 21 liaisons temporisées','', 'Les liaisons ci-dessous se parcourent dans les deux sens. Les points de départ et de retour détaillés dans chaque fiche de pièce restent les coordonnées de référence. Les temps sont des secondes de simulation, pas des mesures du film ou du roman.','', '| Origine | Destination | Nature | Niveaux | Préparation exposée | Trajet engagé |','|---|---|---|---|---:|---:|']
for r,p in links:
 b,t=timings[p['kind']];lines += [f"| {r['name']} | {rooms[p['to']]['name']} | {p['kind']} | {r['floor']} → {rooms[p['to']]['floor']} | {fmt(b)} s | {fmt(t)} s |"]
lines += ['','## Registre des six détours','']
for j in D['jobs']:
 r=rooms[j['room']];free=next(p for p in r['portals'] if not p['requires']);gate=next(p for p in r['portals'] if p['requires'])
 lines += [f"### {j['title']} · `{j['id']}`",'',f"**{r['name']} · {'Newt seule' if j['childOnly'] else 'Personnage adulte'}**",'',j['steps'][0]['description'],'',f"Boucle : {rooms[free['to']]['name']} → {r['name']} → {rooms[gate['to']]['name']}. L’entrée depuis {rooms[free['to']]['name']} ne demande pas d’avoir déjà ouvert la sortie.",'','| Étape | Salle | Action | x / z | Temps sur place |','|---|---|---|---|---|']
 for i,t in enumerate(j['steps']):lines.append(f"| {i+1} | {rooms[t['room']]['name']} | {t['label']} | {fmt(t['x'])} / {fmt(t['z'])} | {t['duration']} s |")
 reward={'medkit':'une trousse de soins','flare':'deux fusées','battery':'réserve de lampe remise à 100 %','food':'25 points de santé, maximum 100'}[j['reward']]
 a=next(a for a in D['archives'] if a['id']==j['archive'])
 lines += ['',f"Pièce emportée : **{j['item']}**. La pose exige cette étape, le bon personnage et la proximité. L’éloignement ou une blessure interrompt la pose sans effacer la pièce.",'',f"Effet : `{j['flag']}` autorise les deux portails. Récompense : {reward}, une seule fois ; document `{a['id']}` — {a['title']}. Le compteur de campagne principale ne change pas.",'']
lines += ['## Rencontres ajoutées et annonce','', '| ID / pièce | Nature | Stade minimum | Seuil x | Ancrage x / z | Préavis |','|---|---|---:|---:|---|---:|']
for e in D['encounters']:lines.append(f"| `{e['id']}` / {rooms[e['room']]['name']} | {e['type']} | {e['minPhase']} | {e['triggerX']} | {e['spawnX']} / {e['spawnZ']} | {e['warning']} s |")
for e in D['encounters']:lines += ['',f"**{e['id']}** — {e['label']}"]
lines += ['','## Campagne principale : 49 objectifs conservés','']
for c in D['chapters']:
 lines += [f"### {c['index']+1:02d} — {c['title']}",'',f"**{D['characters'][c['character']]['name']} · {c['timeLabel']} · {rooms[c['start']]['name']}**",'',c['synopsis'],'','| Ordre | Lieu | Action réelle | Type |','|---|---|---|---|']
 for i,t in enumerate(c['objectives']):
  o=next(o for o in rooms[t['room']]['objects'] if o['id']==t['id']);lines.append(f"| {i+1} | {rooms[t['room']]['name']} | {o['label']} | `{o['kind']}` |")
 lines += ['',f"Dialogue original de jeu : **{c['dialogue']['speaker']}** — « {c['dialogue']['text']} »",'']
lines += ['## Tableaux et collecteurs : solutions de recette','']
for bid,b in D['boards'].items():
 lines += [f"### {b['title']} · `{bid}`",'',f"{rooms[b['room']]['name']} · circuit `{b['circuit']}` · capacité {b['capacity']}.",'',b['hint'],'','| Commande | Charge | État requis | Initial |','|---|---:|---|---|']
 for i,c in enumerate(b['channels']):lines.append(f"| {c[0]} | {c[1]} | {'Actif' if c[2] else 'Coupé'} | {'Actif' if b['initial'][i] else 'Coupé'} |")
 lines += ['']
lines += ['## Les 42 fiches de pièce','']
for r in D['rooms']:
 a=r['architecture'];lines += [f"### {r['name']} · `{r['id']}`",'',f"**{r['building']} · niveau {r['floor']} · {r['kind']} · {r['width']} unités · z {r['minZ']}–{r['maxZ']}**",'',f"Repère d’orientation : {r['landmark']}. Profil `{a['style']}` / `{a['variant']}`, circuit `{a['circuit']}`, emprise `{r['layoutProfile']}`.",'',f"Blocage métrique déclaré : {r['dimensionsM']} ; intention originale, pas mesure du roman. {a['wallModules']} travées murales déclarées. Les facteurs de parallaxe d’architecture sont des métadonnées de production, pas tous des variables autonomes du renderer.",'','#### Entrées, retours et droits','', '| Sortie | Nature | Départ x / z | Retour x / z | Condition |','|---|---|---|---|---|']
 for p in r['portals']:
  back=next(q for q in rooms[p['to']]['portals'] if q['to']==r['id']);cond=('Newt ; ' if p['childOnly'] else '')+(p['requires'] or 'Libre')
  lines.append(f"| {rooms[p['to']]['name']} | {p['kind']} | {fmt(p['x'])} / {fmt(p['z'])} | {fmt(back['x'])} / {fmt(back['z'])} | {cond} |")
 for p in r['portals']:
  if p['kind'] in timings:
   board,travel=timings[p['kind']]
   extra=' Circuit coupé : +1,6 s de trajet.' if p['kind']=='monte-charge' else ''
   lines += ['',f"Raccord vers **{rooms[p['to']]['name']}** : préparation exposée {fmt(board)} s, puis trajet borné {fmt(travel)} s.{extra} Arrivée au portail inverse ; annulation par mouvement ou blessure avant engagement. Les menus ne permettent pas de contourner les droits d’accès."]
 lines += ['', 'Lecture des seuils : les observations sont datées, locales et non garanties. L’écoute ne rend pas cette pièce sûre. Les emprises et points de retour ci-dessous restent la référence de placement.']
 lines += ['','#### Obstacles : emprise commune au rendu et au moteur','', '| ID | Nature | Centre x / z | Largeur / profondeur |','|---|---|---|---|']
 if not r['cover']:lines += ['| Aucun | Passage latéral dégagé | — | — |']
 for c in r['cover']:lines.append(f"| `{c['id']}` | {c['prop']} | {fmt(c['x'])} / {fmt(c['z'])} | {fmt(c['w'])} / {fmt(c['d'])} |")
 lines += ['','#### Décors : fonction avant densité','', '| ID / objet | x / z | Couche | Solide | Rôle et placement |','|---|---|---|---|---|']
 for p in r['props']:lines.append(f"| `{p['id']}` / {p['kind']} | {fmt(p['x'])} / {fmt(p['z'])} | {p['layer']} | {'Oui' if p['collidable'] else 'Non'} | {cell(p['purpose'])} |")
 lines += ['','#### Interactions et cachettes','', '| ID / action | x / z | Condition d’apparition | Type |','|---|---|---|---|']
 for o in r['objects']:
  cond='Chapitre '+str(o['chapter']+1) if 'chapter' in o else 'Détour '+o['job']+' / étape '+str(o['step']+1) if o['kind']=='side-task' else 'Facultatif'
  lines.append(f"| `{o['id']}` · {cell(o['label'])} | {fmt(o['x'])} / {fmt(o['z'])} | {cond} | {o['kind']} |")
 if r['phaseDressing']:
  lines += ['','#### État de crise visible','', '| Élément | x / z | Stade minimum |','|---|---|---:|']
  for q in r['phaseDressing']:lines.append(f"| {q['kind']} | {fmt(q['x'])} / {fmt(q['z'])} | {q['fromPhase']} |")
 for h in D['hazards']:
  if h['room']==r['id']:lines += ['',f"Danger local `{h['id']}` : x {h['x']}, z {h['z']}. Valeurs de recette : `{json.dumps(h,ensure_ascii=False)}`."]
 for e in D['encounters']:
  if e['room']==r['id']:lines += ['',f"Rencontre `{e['id']}` : annonce de {e['warning']} s au passage x ≥ {e['triggerX']}, à partir du stade {e['minPhase']}. Consulter son état de sauvegarde avant tout ajout d’ennemi."]
 localpeople=[d for d in D['life']['residents'] if d['room']==r['id']];localboxes=[d for d in D['life']['containers'] if d['room']==r['id']];localbenches=[d for d in D['life']['benches'] if d['room']==r['id']]
 if localpeople or localboxes or localbenches:
  lines += ['','#### Vie coloniale et stations de la 0.5','']
  for d in localpeople:lines += [f"**{d['name']}** · {d['role']}. Routine 0/1 : "+' → '.join(f"({q['x']} / {q['z']})" for q in d['points'])+'. P permet de sélectionner sa conversation sans emprunter un accès voisin.','']
  for d in localboxes:lines += [f"**{d['label']}** · `{d['id']}` à ({d['x']} / {d['z']}). Fermoir fermé → ouverture exposée → contenu fini → surplus ou état vide. Contenu : "+' ; '.join(f"{n} {D['life']['items'][k]['label']}" for k,n in d['items'].items())+'. Pas de remplissage après une visite.','']
  for d in localbenches:lines += [f"**{d['label']}** · `{d['id']}` à ({d['x']} / {d['z']}). Adulte proche ; deux recettes, coût débité seulement au terme. Aucun usage à distance ni atelier pour Newt.",'']
 localshutters=[d for d in D['defense']['shutters'] if d['room']==r['id']];localalarms=[d for d in D['defense']['alarms'] if d['room']==r['id']]
 if localshutters or localalarms:
  lines += ['','#### Dispositifs physiques de la 0.6','']
  for d in localshutters:
   lines += [f"**{d['label']}** · `{d['id']}`. Centre {d['x']} / {d['z']}, emprise {d['w']} / {d['d']}. Commandes : "+' ; '.join(f"({a['x']} / {a['z']})" for a in d['controls'])+'. Fermeture 2,6 s ; ouverture adulte 1,6 s ; Newt 1,1 s. Occupation vérifiée au début et au terme. Pas d’écrasement ni d’éjection.','', 'Contournement profond s’il existe ; sinon les adultes annoncent leurs frappes. Petits parasites sous le panneau. Intégrité non réparée après ouverture ; rupture définitive à zéro.','']
  for d in localalarms:
   lines += [f"**{d['label']}** · `{d['id']}` à ({d['x']} / {d['z']}). Circuit `{d['circuit']}`, adulte proche. 1,2 s de travail, 4 s de délai, 10 s de signal, 45 s de réarmement et deux cycles maximum. Portées de jeu 950 / 470 selon obstruction. Une cible visible reste prioritaire. Aucune apparition d’ennemi n’est produite par ce poste.",'']
 lines += ['','#### Garde-fous de cette pièce','',f"Les {len(r['portals'])} retours, {len(r['objects'])} points d’interaction et {len(r['cover'])} obstacles sont issus du même contenu que le runtime. La recette géométrique a marché de l’entrée vers chaque point dans les deux vues. Elle contrôle l’accessibilité, pas une partie humaine complète ni l’équilibrage de chaque rencontre.",'', 'Ne pas ajouter de collision aux accessoires muraux sans modifier le plan local et relancer la recette. Ne pas déplacer un seuil sans déplacer son point de retour. Ne pas transformer un décor d’observation en porte non documentée. Préserver la bande z = 0,7 pour le mode classique.','']
lines += ['## Documents originaux','']
for a in D['archives']:
 lines += [f"### {a['id']} — {a['title']}",'',str(a.get('text',a.get('body',''))),'']
lines += ['## Qualification courante','',f'{model} groupes/cas du modèle, dont {num("PASSAGES_TEST_RESULTS")} pour les seuils et {num("PERSISTENCE_TEST_RESULTS")} pour le stockage abstrait. Vingt-quatre parcours complets retestés. {num("INSTALLER_TEST_RESULTS")} cas d’installateur sur projets de test et {num("REAL_UPGRADE_TEST_RESULTS")} avec les vrais fichiers 0.5. {browser} contrôles dans Chromium et {len(caps)} captures décrites. Voir QA_REPORT.md pour les périmètres et limites.','',limitations]
codex='\n'.join(lines)+'\n';(R/'docs/CODEX_LEVEL_DESIGN.md').write_text(codex,encoding='utf-8')

css='''*{box-sizing:border-box}body{margin:0;background:#091a21;color:#c6d3ca;font:16px/1.75 Arial,Helvetica,sans-serif}main{max-width:1180px;margin:auto;padding:48px 30px 70px}header{border-bottom:1px solid #4e6b64;padding:18px 0 38px}.eyebrow,.tag{font:11px/1.6 monospace;letter-spacing:.16em;color:#a7bfad}h1{font-size:clamp(38px,6.5vw,78px);font-weight:400;line-height:1.05;letter-spacing:.055em;color:#e0e5d2;margin:28px 0}h2{font-size:29px;font-weight:400;color:#e3e5cd;margin-top:56px;line-height:1.25}h3{color:#d6ddc8;font-size:20px;font-weight:400}.subtitle{font-size:22px}.tag{display:inline-block;border:1px solid #608277;padding:8px 12px}nav{display:flex;gap:18px;flex-wrap:wrap;padding:22px 0}a{color:#c8d4b7;text-decoration:none;border-bottom:1px solid #6c8d7b}a:hover{color:#fff}p{max-width:960px}.notice{padding:22px 25px;border-left:3px solid #bdb58a;background:#162c32}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin:30px 0}.metrics article{padding:22px;border-top:1px solid #648579;background:#122930}.metrics b{display:block;font:38px monospace;color:#dfe4c5}.metrics span{display:block;font:11px monospace;margin-top:9px;letter-spacing:.1em;color:#9eb7aa}.grid{display:grid;grid-template-columns:1fr 1fr;gap:30px}.grid article{padding:8px 0}.table-wrap{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;vertical-align:top;border-bottom:1px solid #355953;padding:14px 12px}th{font:11px monospace;color:#afc3ac;letter-spacing:.1em}figure{margin:32px 0;border:1px solid #385b58;background:#10292f}figure img{display:block;width:100%;height:auto}figcaption{padding:20px 24px;font-size:14px}figcaption b{font-weight:400;color:#e2e5cd}details{margin-top:10px;color:#9db8ab;font-size:12px}summary{cursor:pointer;letter-spacing:.05em}code,small{display:block;overflow-wrap:anywhere;font-size:10px}.portrait{max-width:420px;margin-left:auto;margin-right:auto}footer{border-top:1px solid #3f615b;margin-top:50px;padding-top:30px;font-size:13px;color:#8fab9f}@media(max-width:660px){main{padding:22px 18px 50px}.metrics{grid-template-columns:1fr 1fr;gap:10px}.metrics article{padding:16px}.grid{grid-template-columns:1fr;gap:10px}h2{font-size:25px}th,td{padding:11px 7px;font-size:12px}figcaption{padding:15px}}'''

suite_labels={
 'CORE_TEST_RESULTS':('core.cjs','État, progression, collisions et format de sauvegarde'),
 'COLONY_TEST_RESULTS':('colony.cjs','Tableaux, cachettes, batterie, soudures et escortes'),
 'EXPLORATION_TEST_RESULTS':('exploration.cjs','Détours, géométrie des 42 pièces, visée et mémoire'),
 'PASSAGES_TEST_RESULTS':('passages.cjs','21 raccords dans les deux sens et vues ; écoute, échos et migrations'),
 'PERSISTENCE_TEST_RESULTS':('persistence.cjs','Stockage mémoire simulé : deux copies, intégrité, quotas et refus d’écrasement'),
 'LIFE_TEST_RESULTS':('life.cjs','Habitants, thèmes, réserves, recettes, leurres portables et imports'),
 'DEFENSE_TEST_RESULTS':('defense.cjs','Volets, occupation, tirs, contournement, frappes, alarmes, Newt et vrais anciens exports'),
 'INSTALLER_TEST_RESULTS':('installer.mjs','Shells hôtes de test, idempotence, conflits, mise à niveau et restauration'),
 'REAL_UPGRADE_TEST_RESULTS':('upgrade-real.mjs','Vrais fichiers/installateur 0.5 puis payload 0.6 sur un shell hôte de test'),
 'BROWSER_TEST_RESULTS':('browser.py','Début au clavier, vrai export, menus, scènes tardives séparées et tactile émulé'),
 'BROWSER_V02_TEST_RESULTS':('browser-v02.py','Survie et véritable export 0.1 dans le runtime courant'),
 'BROWSER_V03_TEST_RESULTS':('browser-v03.py','Détours, cartes, visée et véritable export 0.2'),
 'BROWSER_V04_TEST_RESULTS':('browser-v04.py','Raccords, écoute, échos et véritable export 0.3'),
 'BROWSER_V05_TEST_RESULTS':('browser-v05.py','Conversations, réserves, assemblage, leurres et véritable export 0.4'),
 'BROWSER_V06_TEST_RESULTS':('browser-v06.py','Deux sessions séquentielles : volets, rupture, Newt, alarmes, vrai export 0.5 et nouveaux exports')}
rows=[]
for name in model_names+['INSTALLER_TEST_RESULTS','REAL_UPGRADE_TEST_RESULTS']+browser_names:
 label,scope=suite_labels[name];n=num(name);rows.append(f'| {label} | {n}/{n} | {scope} |')
qa=f'''# Qualification locale — {v}

Ces résultats sont issus des suites achevées sur le code livré. Les comptes archivés sous `history/` ne sont pas ajoutés. Les compteurs désignent des assertions ou groupes de contrôles, pas autant de joueurs, de machines ou de sessions humaines.

| Suite actuelle | Réussite | Portée |
|---|---:|---|
{chr(10).join(rows)}

**Modèle : {model}/{model}. Navigateur : {browser}/{browser}.** Aucun événement d’erreur JavaScript relevé dans les recettes achevées. Les parcours suivants sont comptés séparément.

| Pilote complet | Nombre | Contenu effectivement parcouru |
|---|---:|---|
| traversal.cjs | 6/6 | Deux vues × trois difficultés ; campagne principale et deux escortes |
| traversal-exploration.cjs | 6/6 | Même campagne, 42 pièces, six détours et leurs raccourcis aller/retour |
| traversal-life.cjs | 6/6 | Ajoute 12 résidents, 24 sujets, 12 réserves, trois fabrications et trois poses |
| traversal-defense.cjs | 6/6 | Ajoute les sept volets accessibles tôt, fermés/rouverts des deux côtés, et les quatre avertisseurs |

## Ce que les 24 parcours prouvent

Les pilotes commencent une partie neuve. Ils marchent avec `Simulation.update`, utilisent les commandes, les soins disponibles et les solutions des tableaux. Ils ne téléportent pas les personnages, ne valident pas directement les objectifs et ne réécrivent pas leur santé. L’assistance de santé entre chapitres reste une règle de jeu active.

Le nouveau tour manipule les sept volets accessibles avant la crise : 14 fermetures, 14 réouvertures, traversées des bandes ouvertes et un cycle sur chacun des quatre avertisseurs. Il accomplit aussi les habitants, réserves, détours et 49 objectifs. Le huitième volet, dans le hangar scientifique, reste derrière son autorisation scénaristique et est vérifié séparément en scène préparée. Le pilote ne supprime pas cette autorisation pour gonfler son compte.

Ces tours sont optimisés et connaissent les routes. Ils ne prouvent pas la difficulté d’une découverte humaine ni l’utilité de chaque défense pendant une attaque. Les frappes, le contournement profond, le passage des petits parasites, l’occupation, les interruptions, la destruction des avertisseurs et la priorité d’une cible visible font l’objet de fixtures locales explicites dans `defense.cjs`. Les valeurs attendues sont vérifiées après simulation, pas simplement inscrites dans le rapport.

## Navigateur : méthode et difficultés rencontrées

Le CLI agent-browser est absent. L’essai HTTP local de cette passe a renvoyé `ERR_BLOCKED_BY_ADMINISTRATOR` ; le résultat est conservé dans `SMOKE_V06.json`. Les recettes utilisent le fichier autonome exact avec Playwright `set_content`, dans l’origine opaque autorisée, sans changement d’origine ni contournement de politique. Les événements réseau et erreurs de page sont collectés.

Les premières tentatives ont révélé des attentes fragiles basées sur un nombre de millisecondes murales : les frames ne progressaient pas toujours assez vite pour terminer une manœuvre avant l’assertion. Les recettes attendent désormais la progression normale de la simulation ou l’état observable demandé. Elles ne font pas avancer le moteur artificiellement. Les temps exacts sont vérifiés dans les tests du modèle ; aucune performance en images par seconde n’est certifiée.

Les scènes tardives du premier script et les deux groupes de la recette 0.6 utilisent des pages ou sessions distinctes afin de borner les ressources du navigateur. Un premier lancement interrompu ou un résultat partiel n’est pas compté comme une réussite. Les rapports retenus sont ceux dont l’exécution est achevée et sans échec.

## Exports réels, pas stockage natif certifié

Les fichiers `real-v01-save.json` à `real-v05-save.json` proviennent des anciennes livraisons. Le fichier 0.5 est le vrai export de balise en armement de l’archive précédente, pas un état récent renommé. La migration n’invente ni manipulation de volet, ni cycle d’alarme, ni ressources supplémentaires.

Dans le navigateur courant, un volet est fermé par les boutons, heurté par le déplacement puis endommagé par un tir au clavier. Le vrai téléchargement JSON est relu puis importé : fermeture et intégrité sont conservées. Un autre fichier est téléchargé pendant les quatre secondes d’armement d’un avertisseur. Son import reprend le délai sans second prélèvement.

Le protocole local à deux copies est éprouvé avec `MemoryStorage` simulé. Le stockage natif après fermeture/réouverture, les quotas réels, le mode privé et les onglets concurrents restent non qualifiés. Un test de protocole n’est pas une preuve de comportement du stockage natif.

## Captures et lecture visuelle

{len(caps)} captures actuelles sont décrites par les résultats des six recettes navigateur. Elles proviennent de Chromium exécutant le HTML exact. Les scènes ciblées sont des sauvegardes préparées, validées, puis importées par le sélecteur de fichier ordinaire. Leurs pièces, personnages et méthodes sont enregistrés dans les rapports. Les captures ne constituent ni des scènes du roman nouvellement authentifiées ni une campagne entière jouée à la main.

Le dossier des dispositifs est contrôlé à 130 % en 1280×720, 844×390 et 390×844. Le portrait et les commandes tactiles sont émulés ; aucune certification de téléphone réel, Safari/iPhone ou manette matérielle n’est annoncée. Le rapport illustré est contrôlé séparément contre ses PNG sources.

## Corrections issues de la passe

Le placement des volets évite les trajets ordinaires des résidents ; une fermeture réellement occupée reste refusée. Les commandes sont triées indépendamment du panneau pour ne pas masquer la tête d’un acteur devant. Les segments de navigation et de tir emploient les emprises actives exactes, sans échantillonnage susceptible de sauter un obstacle mince. Une poursuite garde sa dernière position perçue tant que sa mémoire reste valide ; elle ne devient pas omnisciente.

Le passage de vue est refusé s’il enfermerait le joueur ou son compagnon dans un solide. Le sélecteur affiche alors la vue conservée. L’ouverture d’un volet ne répare pas ses dégâts, sa destruction ne recrée pas de mécanisme et Newt conserve une libération accessible des deux côtés.

## Limites maintenues

{limitations}

Les résidents restent locaux aux stades 0/1, pas une population autonome dans toute la colonie. Les alarmes sont locales et n’ajoutent pas d’ennemis. Les volets changent d’état après une manipulation, pas lamelle par lamelle. Les raccords restent bornés, pas un axe vertical continu. Pas de véhicule pilotable, coopération réseau, durée humaine, équilibrage final ou atlas définitif certifié.
'''
(R/'docs/QA_REPORT.md').write_text(qa,encoding='utf-8')
readme=f'''# Alien — Fleuve de la Douleur · {v}

## Hadley’s Hope — Tenir les passages

Extension cumulative de la 0.5 : huit volets locaux, quatre avertisseurs, navigation et ordre des impacts révisés. La campagne conserve 16 chapitres, 42 pièces, 57 liaisons, 49 objectifs et six détours.

{limitations}

## Jouer immédiatement

Extraire toute l’archive, puis ouvrir **JOUER.html** dans un navigateur de bureau, ou **LANCER_WINDOWS.bat** sous Windows. Le HTML est autonome, sans téléchargement de scripts ni de graphismes. Les sources modulaires restent dans `src/river-of-pain`.

Au premier lancement : NOUVELLE PARTIE, puis PRENDRE LE CONTRÔLE. Le son est facultatif. La sauvegarde automatique tente son stockage propre au DLC ; exporter régulièrement en JSON reste recommandé dans ce prototype, car la persistance native n’a pas été qualifiée dans l’environnement de recette.

## Commandes

| Action | Clavier |
|---|---|
| Marcher / profondeur | Q-D ou A-D, Z-S ou W-S, flèches |
| Se baisser / courir | C / Maj |
| Interagir | E |
| Dispositifs de la pièce | ENTRÉE, ou bouton depuis I |
| Équipement / plan | I / Tab |
| Viser sur place et tirer | Espace + directions / F |
| Viser et tirer au pointeur | Bouton gauche maintenu sur le terrain |
| Lampe / détecteur des Marines | L / T |
| Cachette / écouter au seuil | G / N |
| Souder une porte | B, personnages autorisés seulement |
| Suivre-attendre du compagnon | V |
| Soins / fusée / rechargement | H / X / R |
| Poser une balise sonore / un repère | K / M |
| Parler / contacts | P / Y |
| Détours / relevés de seuil / carnet | U / O / J |
| Pause | Échap |

ENTRÉE ne remplace pas V. Le dossier local ne permet aucune action à distance. Un volet conserve ses dégâts, et un avertisseur dépend du courant. Une cible humaine visible reste prioritaire sur le signal. Newt peut libérer une poignée basse, pas fermer le volet ou déclencher l’alarme.

## Reprendre un export 0.1 à 0.5

Ouvrir Pause → Importer, sélectionner le JSON, choisir CHARGER puis REPRENDRE LE PARCOURS. Les vrais fichiers des cinq versions ont été testés. Les coffres, poches et objectifs sont conservés ; les nouveaux dispositifs sont initialisés sans actions antérieures fictives. Un travail inachevé est annulé à l’import, tandis qu’un signal déjà programmé garde son délai et son cycle.

Les fichiers JSON contiennent la partie et son point de contrôle. Reprendre après mort restaure ce dernier : les actions réalisées depuis ne sont pas conservées artificiellement. Les deux copies locales alternées ne touchent jamais les sauvegardes du Tantalus natif.

## Lanceur facultatif dans une copie de Tantalus

Nécessite Node.js 20 ou ultérieur. Depuis ce dossier, indiquer le dossier de la copie de Tantalus :

```sh
node tools/install.mjs "CHEMIN_VERS_TANTALUS"
```

Une installation antérieure intacte se remplace avec :

```sh
node tools/install.mjs "CHEMIN_VERS_TANTALUS" --upgrade
```

Retrait réversible :

```sh
node tools/install.mjs "CHEMIN_VERS_TANTALUS" --remove
```

L’installateur vérifie les empreintes et refuse un dossier inconnu ou modifié. Il ajoute uniquement un lanceur et les fichiers du module. Il ne fusionne pas GameEngine, SaveSystem, le catalogue MIRE ou les autres DLC. Les tests utilisent des shells hôtes de test ; aucun build complet du dépôt distant, push ou déploiement n’est revendiqué.

## Reproduire les vérifications

```sh
npm run build
npm test
node tests/upgrade-real.mjs "CHEMIN_VERS_L_ARCHIVE_0.5_EXTRAITE"
npm run test:browser
npm run docs
npm run test:report
python tools/verify-delivery.py
python tools/package-release.py
```

La recette navigateur utilise Python, Playwright et Chromium ; `CHROMIUM_PATH` peut indiquer son exécutable. Dans l’environnement de livraison il se trouve à `/usr/bin/chromium`. Le test de vraie mise à niveau nécessite les octets de l’ancienne archive ; ils ne sont pas reconstruits à partir d’un faux numéro de version. Les rapports d’historique ne qualifient pas le code courant.

## Documents

`RAPPORT_ILLUSTRE.html` : captures embarquées et portée de la livraison. `docs/CODEX_LEVEL_DESIGN.md` : fiches des 42 pièces et équipements. `docs/QA_REPORT.md` : résultats et limites. `docs/SOURCE_V06.json` : provenance de la 0.5. `DELIVERY_MANIFEST.json` et `CHECKSUMS.sha256` : identité des octets livrés.

Modèle : {model} cas/groupes réussis ; 24 parcours automatisés ; {browser} contrôles navigateur. Ces chiffres ne sont pas une certification commerciale ou une partie humaine de la campagne.
'''
(R/'README.md').write_text(readme,encoding='utf-8')
(R/'docs/CHANGELOG_0_6.md').write_text(f'''# Changements — {v}

Huit volets locaux, quatre avertisseurs et dossier ENTRÉE / équipement. Fermeture occupée refusée ; manipulation exposée ; libération Newt des deux côtés. Intégrité conservée à la réouverture, rupture définitive. Adultes contournent ou frappent ; petits parasites passent dessous. Avertisseurs finis, courant requis, signal local et destructible, sans création d’ennemis.

Navigation par segments libres et coins élargis des obstacles ; impacts classés par premier obstacle réel ; garde-fou de projection classique. Rendu des commandes trié indépendamment. Sauvegardes réelles 0.1 à 0.5 migrées sans inventer de ressources ; véritables exports/imports des nouveaux états vérifiés.

42 pièces, 57 liens, 49 objectifs, six détours et systèmes 0.5 conservés. {model} cas/groupes du modèle, 24 parcours et {browser} contrôles navigateur achevés. Ni intégration native, publication, assets définitifs, simulation hors champ intégrale ou véhicule pilotable.
''',encoding='utf-8')
selected=['51-dispositifs-v06.png','52-volet-ferme-v06.png','53-plan-volet-v06.png','54-newt-secours-v06.png','55-frappe-annoncee-v06.png','56-volet-detruit-v06.png','57-alarme-active-v06.png','58-dispositifs-portrait-v06.png','40-conversation-v05.png','44-coffre-ouvert-v05.png','45-etabli-v05.png','27-montecharge-v04.png']
figures=[]
for i,name in enumerate(selected,1):
 c=caps[name];b=(R/c['file']).read_bytes();portrait='portrait' if 'portrait' in name else ''
 figures.append(f'<figure id="capture-{i}" class="{portrait}"><img src="data:image/png;base64,{base64.b64encode(b).decode()}" alt="{escape(c["description"])}"><figcaption><b>{i:02d} / {escape(c["description"])}</b><details><summary>Préparation et provenance</summary><p>{escape(c["setup"])}</p><code>{escape(c["file"])}</code><small>SHA-256 : {hashlib.sha256(b).hexdigest()}</small></details></figcaption></figure>')
html=f'''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fleuve de la Douleur — Rapport v0.6</title><style>{css}</style></head><body><main><header><p class="eyebrow">ALIENS / TANTALUS FRONTIER / LIVRAISON LOCALE · 29 SEPTEMBRE 2026</p><h1>TENIR<br>LES PASSAGES</h1><p class="subtitle">Alien — Fleuve de la Douleur</p><span class="tag">{v.upper()}</span></header><nav aria-label="Documents de livraison"><a href="JOUER.html">JOUER</a><a href="docs/CODEX_LEVEL_DESIGN.md">CODEX DES PIÈCES</a><a href="docs/QA_REPORT.md">QUALIFICATION</a><a href="README.md">INSTALLATION</a></nav><p class="notice"><strong>Une suite jouable de la 0.5, toujours autonome.</strong> Gagner du temps avec un volet, puis faire chercher ailleurs sans effacer ce que la créature a vu. La campagne est conservée ; le moteur hôte et ses sauvegardes ne sont pas remplacés.</p><div class="metrics"><article><b>8</b><span>VOLETS MÉCANIQUES</span></article><article><b>4</b><span>AVERTISSEURS LOCAUX</span></article><article><b>42</b><span>PIÈCES CONSERVÉES</span></article><article><b>49</b><span>OBJECTIFS PRINCIPAUX</span></article></div><h2>Une défense n’est pas un refuge garanti</h2><section class="grid"><article><p class="eyebrow">MANŒUVRER</p><h3>Deux commandes et une vraie emprise</h3><p>Fermer prend 2,6 secondes dans le monde. Une blessure, un éloignement ou une occupation empêchent la réussite. Le volet bloque les adultes, les tirs et la vue qui le traversent. Les petits parasites passent dessous.</p><p>Newt peut libérer la poignée basse de chaque côté en 1,1 seconde, mais pas fermer le volet.</p></article><article><p class="eyebrow">RETARDER</p><h3>Contourner ou briser</h3><p>Une créature adulte prend une allée libre lorsqu’elle existe. Sinon elle rejoint le volet bloquant, annonce sa frappe et peut finir par le détruire. Rouvrir ne répare pas l’intégrité ; les débris restent traversables.</p><p>Les attaques ne passent pas artificiellement à travers le panneau.</p></article><article><p class="eyebrow">DÉTOURNER</p><h3>Quatre secondes pour partir</h3><p>Programmer un avertisseur prend 1,2 seconde. Après quatre secondes de délai, il émet dix secondes. Le circuit doit être alimenté et chaque poste ne possède que deux cycles. Une créature peut le détruire.</p><p>Le signal reste local ; une personne visible reste prioritaire.</p></article><article><p class="eyebrow">CONSERVER</p><h3>Un état, pas une remise à neuf</h3><p>Volets endommagés, alarmes en délai et cycles consommés restent dans les exports. Les vraies sauvegardes 0.1 à 0.5 conservent leurs ressources et leur progression. Les nouveaux équipements ne fabriquent aucun souvenir de manipulation.</p><p>Les tests d’export sont réels ; la persistance native après fermeture reste non qualifiée.</p></article></section><h2>Ce que cette passe ne remplace pas</h2><div class="table-wrap"><table><thead><tr><th>SOCLE</th><th>CONTENU CONSERVÉ</th><th>LIMITE</th></tr></thead><tbody><tr><td>Campagne</td><td>16 chapitres / 49 objectifs / deux escortes</td><td>Découpage original, pas 16 chapitres officiels du roman</td></tr><tr><td>Exploration</td><td>42 pièces / 57 liaisons / six détours</td><td>Aucun voyage instantané de menu</td></tr><tr><td>Vie coloniale</td><td>12 résidents / 24 sujets / 12 réserves / trois établis</td><td>Routines locales, pas population globale</td></tr><tr><td>Géométrie</td><td>62 obstacles statiques + huit volets dynamiques</td><td>Empreintes communes ; pas collision artistique pixel par pixel</td></tr><tr><td>Décor</td><td>489 placements / 118 éléments conditionnels</td><td>Ce ne sont pas autant de sprites uniques</td></tr><tr><td>Raccords</td><td>21 liaisons temporisées</td><td>Pas d’axe vertical continu ni véhicule pilotable</td></tr></tbody></table></div><h2>Captures réelles de la livraison</h2><p>Ces images montrent Chromium exécutant le fichier autonome. Les scènes ciblées sont initialisées par des sauvegardes préparées, validées et importées. Une capture de test ne constitue pas une campagne complète jouée manuellement ni une nouvelle scène authentifiée du roman.</p>{''.join(figures)}<h2>Résultats achevés sur le code courant</h2><div class="table-wrap"><table><thead><tr><th>RECETTE</th><th>RÉSULTAT</th><th>PORTÉE</th></tr></thead><tbody><tr><td>Modèle et protocole de stockage</td><td>{model}/{model}</td><td>Dont {num('DEFENSE_TEST_RESULTS')} cas/groupes pour les défenses</td></tr><tr><td>Parcours complets</td><td>24/24</td><td>Deux vues × trois difficultés, quatre variantes de parcours</td></tr><tr><td>Installateur</td><td>{num('INSTALLER_TEST_RESULTS')}/{num('INSTALLER_TEST_RESULTS')} + {num('REAL_UPGRADE_TEST_RESULTS')}/{num('REAL_UPGRADE_TEST_RESULTS')}</td><td>Shells de test ; vrais fichiers 0.5 pour la mise à niveau</td></tr><tr><td>Navigateur</td><td>{browser}/{browser}</td><td>Chromium ; aucune erreur JavaScript relevée</td></tr></tbody></table></div><p>Le nouveau pilote utilise les sept volets accessibles avant la crise depuis leurs deux commandes, les quatre avertisseurs, puis termine la campagne, les détours et la vie coloniale. Le volet du hangar et les attaques sont testés séparément dans des scènes préparées. Aucun parcours ne force les objectifs ou la santé. Les pilotes connaissent les routes : ce n’est pas une mesure de difficulté ou de durée humaine.</p><p>{len(caps)} captures sont documentées, dont {len(selected)} présentées ici. Le codex compte {len(codex.splitlines())} lignes et détaille les emprises, commandes, règles, routines et retours de chaque pièce.</p><p class="notice"><strong>Qualification locale, pas certification commerciale.</strong> La navigation HTTP locale est bloquée ; le HTML exact a été chargé dans l’origine opaque autorisée, sans contournement. Le protocole des deux copies est testé en mémoire simulée. Les véritables imports et exports JSON, eux, sont éprouvés. Les contrôles portrait ne constituent pas des essais sur téléphone physique.</p><footer>{escape(limitations)}<p>Les métadonnées du commit hôte sont héritées, pas une nouvelle consultation du dépôt. Aucun service distant n’a été modifié. CHECKSUMS.sha256 et DELIVERY_MANIFEST.json identifient les octets livrés.</p></footer></main></body></html>'''
(R/'RAPPORT_ILLUSTRE.html').write_text(html,encoding='utf-8')
(R/'docs/DOCUMENTATION_BUILD.json').write_text(json.dumps({'version':v,'modelCases':model,'browserCases':browser,'capturedImages':len(caps),'illustratedImages':len(selected),'codexLines':len(codex.splitlines()),'connectors':dict(by_kind),'localShutters':8,'localAlarms':4,'fullTraversals':24,'source':'CONTENT_MANIFEST and current completed reports'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'version':v,'model':model,'browser':browser,'captures':len(caps),'codexLines':len(codex.splitlines())},ensure_ascii=False))
