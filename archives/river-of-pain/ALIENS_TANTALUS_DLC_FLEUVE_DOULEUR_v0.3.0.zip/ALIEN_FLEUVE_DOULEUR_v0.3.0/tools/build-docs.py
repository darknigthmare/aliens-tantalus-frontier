#!/usr/bin/env python3
"""Generate current 0.3 documentation from actual data and completed test reports.
Uses only the Python standard library. Images are real Chromium captures.
"""
from pathlib import Path
from html import escape
import base64,json,hashlib,re
R=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((R/'docs'/n).read_text())
D=read('CONTENT_MANIFEST.json');rooms={r['id']:r for r in D['rooms']};m=D['manifest'];v=m['version'];cnt=m['counts']
fmt=lambda n: str(round(n,3)).rstrip('0').rstrip('.') if isinstance(n,float) else str(n)
cell=lambda s:str(s).replace('|',' / ').replace('\n',' ')
limitations="Cette livraison reste un DLC autonome avec lanceur additionnel. Le GameEngine natif de Tantalus, ses atlas, ses sauvegardes et l’écho Frontière 2204 ne sont pas modifiés. Aucun push GitHub ni déploiement Vercel. Les personnages et décors sont dessinés par code : graphisme stylisé provisoire, pas assets définitifs ni reconstitution 1:1. Le roman intégral n’a pas été consulté ; pièces, dialogues, documents et manœuvres sont une condensation originale."
reports={n:read(n+'.json') for n in ['CORE_TEST_RESULTS','COLONY_TEST_RESULTS','EXPLORATION_TEST_RESULTS','INSTALLER_TEST_RESULTS','REAL_UPGRADE_TEST_RESULTS','BROWSER_TEST_RESULTS','BROWSER_V02_TEST_RESULTS','BROWSER_V03_TEST_RESULTS']}
for n,r in reports.items():
 if not r.get('passed'):raise RuntimeError('Recette non terminée ou en échec : '+n)
tr=read('TRAVERSAL_RESULTS.json');alltr=read('TRAVERSAL_EXPLORATION_RESULTS.json')
assert len(tr)==len(alltr)==6 and all(r['passed'] for r in tr+alltr)
assert all(r['visited']==42 and len(r['detours'])==6 for r in alltr)
num=lambda n:reports[n]['cases'] if isinstance(reports[n]['cases'],int) else len(reports[n]['cases'])
core=num('CORE_TEST_RESULTS');col=num('COLONY_TEST_RESULTS');ex=num('EXPLORATION_TEST_RESULTS');inst=num('INSTALLER_TEST_RESULTS');real=num('REAL_UPGRADE_TEST_RESULTS');browser=sum(num(n) for n in ['BROWSER_TEST_RESULTS','BROWSER_V02_TEST_RESULTS','BROWSER_V03_TEST_RESULTS'])
caprows=sum((reports[n]['captures'] for n in ['BROWSER_TEST_RESULTS','BROWSER_V02_TEST_RESULTS','BROWSER_V03_TEST_RESULTS']),[]);caps={Path(c['file']).name:c for c in caprows}
assert len(caps)==len(caprows)
principles="""## Périmètre de la passe 0.3

Le scénario principal conserve 16 chapitres courts et 49 objectifs. Six annexes ajoutent six détours de trois manœuvres chacun : observer, retrouver une pièce, revenir l’installer. Les 18 étapes optionnelles ne gonflent pas artificiellement le compteur des 49 objectifs. Elles déverrouillent six liaisons dans les deux sens, attribuent six nouvelles notes originales et une petite ressource. Les déplacements restent physiques ; aucun menu ne permet de terminer ces interventions ou de voyager instantanément.

La colonie comprend 42 pièces et 57 connexions bidirectionnelles. Les 489 placements de props ne sont pas 489 sprites uniques. Les 118 éléments conditionnels de crise, les 24 cachettes, les six tableaux et les deux jets de pression sont comptés séparément. Les 23 étiquettes architecturales partagent des fonctions de rendu. Les six annexes n’utilisent plus une suite régulièrement espacée d’accessoires : le mobilier est regroupé en postes de travail, rangements et accès, avec un rôle inscrit pour chaque placement.

## Circulation, plans et collisions

Dix-huit salles possèdent des emprises de couverture spécifiquement réorganisées : treize lieux existants et cinq nouvelles salles avec profondeur. Le sixième nouveau lieu est un conduit latéral sans couverture. Les 62 obstacles physiques de l’ensemble utilisent la même largeur et la même profondeur dans la collision, le socle visible et le plan de pièce. Les détails muraux restent non collisionnables. Cette concordance des emprises ne certifie pas une silhouette artistique pixel par pixel.

Le plan colonial montre les liaisons, leurs conditions et les niveaux. Le choix d’une destination trace une route avec les droits du personnage courant, mais ne le déplace pas. Une cloison soudée reste sur le graphe parce qu’une désoudure est possible sur place. Une grille réservée à Newt n’est pas un raccourci adulte. Le plan local montre le sol, les obstacles, les entrées P1/P2, les cachettes, notes, objets actifs, compagnon et balises. Les salles non encore visitées restent visibles comme repères du plan colonial : ce n’est pas un brouillard de guerre.

En présentation classique, le personnage et les interactions sont sur z = 0,7 ; les accessoires et couvertures conservent leur profondeur de décor. Cela évite de projeter un meuble de fond sur la silhouette du personnage alors qu’il ne bloque pas sa marche. Les salles latérales et conduits ne deviennent pas des volumes de déplacement profond. Les escaliers, échelles, monte-charges et véhicules restent des transitions ou postes d’interaction, pas des animations continues de franchissement ou des véhicules pilotables.

L’unité x est une unité de simulation. La distance interne emploie 600 × la différence de z ; le renderer projette le sol avec la hauteur du canvas. Les champs dimensionsM et les niveaux sont des choix de blocage originaux, pas un plan officiel de Hadley’s Hope. Le halo d’un point d’interaction n’est pas une zone de téléportation. Le rayon de collision du joueur est pris en compte par les déplacements ; les tests parcourent le chemin jusqu’à chaque objet et chaque passage dans les deux présentations.

## Visée et perte de trace

ESPACE maintenu avec une direction oriente le tir sur place ; F tire. Le pointeur maintenu sur le terrain vise et tire, avec quantification sur huit directions du plan de sol. Ce n’est pas une visée verticale vers un plafond : les diagonales couvrent x et la profondeur z. La présentation classique et les conduits limitent la direction à gauche/droite. Les projectiles rencontrent les couvertures ; le segment parcouru à chaque pas de simulation est testé contre les créatures. Le rechargement, les réserves et les fusées restent limités.

La visée fixe ne produit plus une fausse course avec Maj : ni déplacement, ni bruit de pas ni dépense de souffle liée à une course inexistante. Newt et Anne restent sans arme. Un tir interrompu par un menu ou le relâchement du pointeur ne doit pas rester bloqué actif.

Les adversaires retiennent une dernière position perçue, avec une mémoire de huit secondes renouvelée par la vue ou le bruit. Ils ne suivent plus la position silencieuse courante derrière un obstacle sans preuve récente. L’expiration de cette mémoire fait retomber la poursuite vers une recherche locale. Le bruit et les fusées restent des règles de gameplay, pas une simulation acoustique réaliste. Un compagnon exposé peut donner une nouvelle position. Une entrée en cachette observée peut aussi trahir le joueur : la dissimulation n’est pas l’invulnérabilité.

Les trois intrusions nouvelles ont un ancrage et un avertissement avant l’apparition. Elles n’apparaissent pas à moins de 380 unités de simulation du joueur ou du compagnon ; le moteur attend aussi si six adversaires sont déjà vivants dans la salle. La minuterie ne progresse que dans sa pièce. Les trois autres séquences sont une ombre et deux signaux d’ambiance, pas trois types d’ennemis supplémentaires. Une rencontre déjà résolue reste enregistrée dans la sauvegarde. Cette couche est ponctuelle et ne constitue pas un directeur d’IA de type Alien: Isolation.

## Systèmes conservés de la 0.2

Les quatre répartiteurs et deux collecteurs conservent trois commandes, capacité et consigne. Mauvaise combinaison et surcharge refusent la validation. La lecture met le jeu en pause ; la manœuvre suivante se termine en 1,4 seconde dans le monde et peut être interrompue. Les coupures changent lumière, ventilateurs concernés et perception, sans effacer des portes. Les jets de pression se neutralisent par leur collecteur. Ce sont des règles discrètes, pas des modèles électriques ou hydrauliques scientifiques.

Les 24 cachettes s’utilisent avec G ou E ; une direction ou E permet de ressortir. Lampe, détecteur, tir et fusées sont neutralisés en cache. La lampe a une réserve ; le détecteur des Marines ne lit que les créatures vivantes de la pièce courante. Les deux escortes gardent santé, tension, suivre/attendre, réassurance et soins partagés. Leur mort met fin à la tentative ; aucune survie canonique supplémentaire n’est attribuée à leur jauge.

Les soudures retiennent les poursuivants puis peuvent céder sous leur pression. Sans poursuivant, elles ne s’usent pas seules. Les réserves sont conservées par protagoniste ; les nouveaux chapitres rétablissent au moins 70 % de santé, une assistance de progression explicitement non canonique. Les douze dernières balises de repli restent visibles sur le terrain et le plan.

## Persistance et restauration

Les exports 0.1 et 0.2 sont acceptés. Les nouvelles données d’exploration sont initialisées sans réinventer la progression passée. Si une ancienne position est recouverte par une emprise réorganisée, une migration cherche l’appui libre le plus proche et signale cet ajustement dans le journal. Elle ne change ni le chapitre ni les ressources du personnage. Les nouveaux imports incohérents (étape, direction, minuterie ou raccourci) sont refusés.

Les étapes de détour, pièces emportées, accès débloqués, notes et rencontres persistent entre les pièces et les points de vue. Comme le reste du monde, ils sont rétablis à l’état du point de contrôle lors d’une reprise après échec : « accès persistant » ne signifie pas conservation de toute action effectuée après ce point de contrôle. L’import/export JSON est éprouvé avec de vrais fichiers des versions précédentes. La persistance native localStorage reste non qualifiée dans l’origine opaque utilisée par les tests Chromium.

## Coexistence narrative

Les annexes et interventions n’ajoutent ni appel de secours réussi, ni évacuation de Newt, ni mort de reine. La terrasse remet seulement une liaison interne en service. L’atelier ne rend pas le tracteur pilotable. La dérivation possède une voie sèche, pas de nage. Le renfoncement des câbles reste accessible uniquement à Newt. Les 16 chapitres sont un découpage de jeu original, non les chapitres du livre. Les noms des personnages et les fins héritées ne sont pas présentés comme revérifiés sur un texte intégral pour cette passe.
"""
lines=['# ALIEN — Fleuve de la Douleur','',f'## Codex de level design · {v}','',m['subtitle'],'',limitations,'',principles,'## Registre des six détours','']
for j in D['jobs']:
 r=rooms[j['room']];free=next(p for p in r['portals'] if not p['requires']);gate=next(p for p in r['portals'] if p['requires'])
 lines += [f"### {j['title']} · `{j['id']}`",'',f"**{r['name']} · {'Newt seule' if j['childOnly'] else 'Personnage adulte'}**",'',j['steps'][0]['description'],'',f"Boucle : {rooms[free['to']]['name']} → {r['name']} → {rooms[gate['to']]['name']}. L’entrée depuis {rooms[free['to']]['name']} ne demande pas d’avoir déjà ouvert la sortie.",'','| Étape | Salle | Action | x / z | Temps sur place |','|---|---|---|---|---|']
 for i,t in enumerate(j['steps']):lines.append(f"| {i+1} | {rooms[t['room']]['name']} | {t['label']} | {fmt(t['x'])} / {fmt(t['z'])} | {t['duration']} s |")
 reward={'medkit':'une trousse de soins','flare':'deux fusées','battery':'réserve de lampe remise à 100 %','food':'25 points de santé, maximum 100'}[j['reward']]
 a=next(a for a in D['archives'] if a['id']==j['archive'])
 lines += ['',f"Pièce emportée : **{j['item']}**. La pose exige cette étape, le bon personnage et la proximité. L’éloignement ou une blessure interrompt la pose sans effacer la pièce.",'',f"Effet : `{j['flag']}` autorise les deux portails. Récompense : {reward}, une seule fois ; document `{a['id']}` — {a['title']}. Le compteur de campagne principale ne change pas.",'']
lines += ['## Rencontres ajoutées et annonce','', '| ID / pièce | Nature | Stade minimum | Seuil x | Ancrage x / z | Préavis |','|---|---|---:|---:|---|---:|']
for e in D['encounters']:lines.append(f"| `{e['id']}` / {rooms[e['room']]['name']} | {e['type']} | {e['minPhase']} | {e['triggerX']} | {e['spawnX']} / {e['spawnZ']} | {e['warning']} s |")
for e in D['encounters']:lines += ['',f"**{e['id']}** — {e['label']}"]
lines += ['','## Campagne principale : 49 objectifs conservés','']
for c in D['chapters']:
 lines += [f"### {c['index']+1:02d} — {c['title']}",'',f"**{D['characters'][c['character']]['name']} · {c['timeLabel']} · {rooms[c['start']]['name']}**",'',c['synopsis'],'','| Ordre | Lieu | Action réelle | Type |','|---|---|---|---|']
 for i,t in enumerate(c['objectives']):
  o=next(o for o in rooms[t['room']]['objects'] if o['id']==t['id']);lines.append(f"| {i+1} | {rooms[t['room']]['name']} | {o['label']} | `{o['kind']}` |")
 lines += ['',f"Dialogue original de jeu : **{c['dialogue']['speaker']}** — « {c['dialogue']['text']} »",'']
lines += ['## Tableaux et collecteurs : solutions de recette','']
for bid,b in D['boards'].items():
 lines += [f"### {b['title']} · `{bid}`",'',f"{rooms[b['room']]['name']} · circuit `{b['circuit']}` · capacité {b['capacity']}.",'',b['hint'],'','| Commande | Charge | État requis | Initial |','|---|---:|---|---|']
 for i,c in enumerate(b['channels']):lines.append(f"| {c[0]} | {c[1]} | {'Actif' if c[2] else 'Coupé'} | {'Actif' if b['initial'][i] else 'Coupé'} |")
 lines += ['']
lines += ['## Les 42 fiches de pièce','']
for r in D['rooms']:
 a=r['architecture'];lines += [f"### {r['name']} · `{r['id']}`",'',f"**{r['building']} · niveau {r['floor']} · {r['kind']} · {r['width']} unités · z {r['minZ']}–{r['maxZ']}**",'',f"Repère d’orientation : {r['landmark']}. Profil `{a['style']}` / `{a['variant']}`, circuit `{a['circuit']}`, emprise `{r['layoutProfile']}`.",'',f"Blocage métrique déclaré : {r['dimensionsM']} ; intention originale, pas mesure du roman. {a['wallModules']} travées murales déclarées. Les facteurs de parallaxe d’architecture sont des métadonnées de production, pas tous des variables autonomes du renderer.",'','#### Entrées, retours et droits','', '| Sortie | Nature | Départ x / z | Retour x / z | Condition |','|---|---|---|---|---|']
 for p in r['portals']:
  back=next(q for q in rooms[p['to']]['portals'] if q['to']==r['id']);cond=('Newt ; ' if p['childOnly'] else '')+(p['requires'] or 'Libre')
  lines.append(f"| {rooms[p['to']]['name']} | {p['kind']} | {fmt(p['x'])} / {fmt(p['z'])} | {fmt(back['x'])} / {fmt(back['z'])} | {cond} |")
 lines += ['','#### Obstacles : emprise commune au rendu et au moteur','', '| ID | Nature | Centre x / z | Largeur / profondeur |','|---|---|---|---|']
 if not r['cover']:lines += ['| Aucun | Passage latéral dégagé | — | — |']
 for c in r['cover']:lines.append(f"| `{c['id']}` | {c['prop']} | {fmt(c['x'])} / {fmt(c['z'])} | {fmt(c['w'])} / {fmt(c['d'])} |")
 lines += ['','#### Décors : fonction avant densité','', '| ID / objet | x / z | Couche | Solide | Rôle et placement |','|---|---|---|---|---|']
 for p in r['props']:lines.append(f"| `{p['id']}` / {p['kind']} | {fmt(p['x'])} / {fmt(p['z'])} | {p['layer']} | {'Oui' if p['collidable'] else 'Non'} | {cell(p['purpose'])} |")
 lines += ['','#### Interactions et cachettes','', '| ID / action | x / z | Condition d’apparition | Type |','|---|---|---|---|']
 for o in r['objects']:
  cond='Chapitre '+str(o['chapter']+1) if 'chapter' in o else 'Détour '+o['job']+' / étape '+str(o['step']+1) if o['kind']=='side-task' else 'Facultatif'
  lines.append(f"| `{o['id']}` · {cell(o['label'])} | {fmt(o['x'])} / {fmt(o['z'])} | {cond} | {o['kind']} |")
 if r['phaseDressing']:
  lines += ['','#### État de crise visible','', '| Élément | x / z | Stade minimum |','|---|---|---:|']
  for q in r['phaseDressing']:lines.append(f"| {q['kind']} | {fmt(q['x'])} / {fmt(q['z'])} | {q['fromPhase']} |")
 for h in D['hazards']:
  if h['room']==r['id']:lines += ['',f"Danger local `{h['id']}` : x {h['x']}, z {h['z']}. Valeurs de recette : `{json.dumps(h,ensure_ascii=False)}`."]
 for e in D['encounters']:
  if e['room']==r['id']:lines += ['',f"Rencontre `{e['id']}` : annonce de {e['warning']} s au passage x ≥ {e['triggerX']}, à partir du stade {e['minPhase']}. Consulter son état de sauvegarde avant tout ajout d’ennemi."]
 lines += ['','#### Garde-fous de cette pièce','',f"Les {len(r['portals'])} retours, {len(r['objects'])} points d’interaction et {len(r['cover'])} obstacles sont issus du même contenu que le runtime. La recette géométrique a marché de l’entrée vers chaque point dans les deux vues. Elle contrôle l’accessibilité, pas une partie humaine complète ni l’équilibrage de chaque rencontre.",'', 'Ne pas ajouter de collision aux accessoires muraux sans modifier le plan local et relancer la recette. Ne pas déplacer un seuil sans déplacer son point de retour. Ne pas transformer un décor d’observation en porte non documentée. Préserver la bande z = 0,7 pour le mode classique.','']
lines += ['## Documents originaux','']
for a in D['archives']:
 lines += [f"### {a['id']} — {a['title']}",'',str(a.get('text',a.get('body',''))),'']
lines += ['## Qualification','',f"{core} cas du cœur, {col} des systèmes de colonie et {ex} d’exploration/géométrie. Six parcours principaux et six parcours avec tous les détours. {inst} cas d’installateur sur fixtures, plus {real} cas utilisant les vrais modules et l’installateur 0.2 sur shell de test. {browser} contrôles Chromium. Voir QA_REPORT.md et les JSON pour les détails.",'',limitations]
codex='\n'.join(lines)+'\n';(R/'docs/CODEX_LEVEL_DESIGN.md').write_text(codex)
qa=f'''# Qualification locale — {v}

Les résultats ci-dessous sont relus depuis les rapports de cette livraison. Ce ne sont pas des totaux cumulés empruntés aux versions précédentes. Aucun essai humain multi-profil, appareil physique, moteur Tantalus natif ou déploiement n’est certifié.

| Suite | Réussite | Ce que cela établit |
|---|---:|---|
| core.cjs | {core}/{core} | Validation, états, collisions et contrat de contenu courant |
| colony.cjs | {col}/{col} | Systèmes hérités : tableaux, lampe, cachettes, escortes, soudures |
| exploration.cjs | {ex}/{ex} | Six détours, huit axes de tir, mémoire, avertissements, migration et 42 × 2 parcours géométriques |
| traversal.cjs | 6/6 | Nouvelle partie → 49 objectifs → fin, deux vues × trois difficultés |
| traversal-exploration.cjs | 6/6 | Même campagne + 18 étapes facultatives, 42 pièces visitées et six raccourcis traversés aller/retour |
| installer.mjs | {inst}/{inst} | Shells de test ; idempotence, upgrade 0.1/0.2, rollback, conflits, liens symboliques, chemins sortants |
| upgrade-real.mjs | {real}/{real} | Vrais fichiers de la 0.2 et son ancien installateur sur shell de test, pas moteur hôte natif |
| browser.py | {num('BROWSER_TEST_RESULTS')}/{num('BROWSER_TEST_RESULTS')} | UI de base, premier objectif/porte au clavier, export, refus import, trois tailles, pointer release tactile émulé |
| browser-v02.py | {num('BROWSER_V02_TEST_RESULTS')}/{num('BROWSER_V02_TEST_RESULTS')} | Régression des tableaux, escortes, lampe, cache, équipement et véritable export 0.1 |
| browser-v03.py | {num('BROWSER_V03_TEST_RESULTS')}/{num('BROWSER_V03_TEST_RESULTS')} | Détours, cartes, import réel 0.2, ressources, raccourci, visée, intrusions et portrait |

## Méthode et limites

Les pilotes de campagne utilisent Simulation.update, déplacement, équipement, interactions et commandes des tableaux. Ils ne téléportent pas, n’appellent pas completeTask et ne changent pas la santé directement. Ils exploitent en revanche la connaissance des objectifs, du graphe et des chemins : ce ne sont pas des joueurs découvrant le niveau. Les ressources de départ, l’assistance de chapitre et les mécanismes de soins du jeu restent actifs. Leurs minutes de simulation ne mesurent pas la durée d’une partie humaine.

Les tests unitaires initialisent volontairement des scènes. Les captures tardives sont des sauvegardes validées importées par le dialogue normal, puis des commandes d’interface. Les fichiers de traces indiquent cette préparation. Elles ne constituent pas une preuve d’une partie entière jouée manuellement. Les {len(caps)} PNG sont des captures du renderer en exécution, non des concept arts.

Le CLI agent-browser était absent. Chromium via Playwright a exécuté le fichier autonome exact avec page.set_content. La navigation HTTP locale a répondu ERR_BLOCKED_BY_ADMINISTRATOR ; aucune politique de navigateur n’a été modifiée. localStorage persistant n’est donc pas qualifié. Le refus propre et l’import/export JSON sont testés. Le jeu ne fait aucune requête réseau dans ces recettes.

Les deux vues partagent les objectifs et les mécanismes de difficulté. Ces réglages ne prétendent pas fournir trois mises en scène entièrement différentes. Aucun test matériel de manette, Safari/iPhone, coopération réseau ou bande-son finale. Les rencontres nouvelles ont été vérifiées isolément ; le pilote complet réalise les détours adultes avant la crise et ne certifie pas leur équilibrage humain tardif.

## Corrections effectuées pendant cette passe

La géométrie héritée a été différenciée sans perdre la bande classique. Les projections des cachettes, PNJ d’interaction et jets de vapeur ont été recollées à leur plan réel en classique. La visée fixe avec Maj ne consomme plus du souffle comme une course. La terrasse n’affiche plus de conduites de plafond suspendues dans le ciel : un parapet rejoint son sol. Le mobilier des nouvelles annexes est regroupé par postes au lieu d’un espacement automatique. Un sélecteur de recette PLAN a été corrigé pour désigner le bouton du dialogue plutôt que le bouton de fond homonyme.

## Préservation

L’archive 0.2 n’a pas été modifiée. Le code de sauvegarde conserve les espaces de noms du DLC. Le champ exploration est migré, et une position ancienne devenue solide est replacée au point libre proche avec message dans le journal. Les autres jeux ne sont pas importés. L’installateur ne touche ni package.json, ni src/app.js, ni le catalogue ; il ajoute son répertoire et un lanceur.

{limitations}
'''
(R/'docs/QA_REPORT.md').write_text(qa)
(R/'docs/CHANGELOG_0_3.md').write_text(f'''# {v} — Les chemins de traverse

Base : 0.2.0-candidate.1, conservée. Format de sauvegarde principal 1 ; systèmes de colonie 2 ; exploration 3.

42 lieux (+6), 57 connexions (+12), 489 props placés (+78), 118 ajouts de crise (+10), 24 cachettes (+6), 30 notes (+6). Les 16 chapitres, 49 objectifs principaux, deux escortes et six tableaux sont conservés. Six nouveaux détours, 18 étapes, six déverrouillages réciproques et six séquences localisées (trois intrusions, une ombre, deux ambiances).

Modules ajoutés : exploration.js (états/validation) et field-visuals.js (emprises/annonces/visée). Core enrichi pour la dernière position connue, les projectiles directionnels, les actions optionnelles et la migration des positions anciennes. Rendu/architecture corrigés pour le mode classique et le toit. UI enrichie de la carte locale, des niveaux, destinations et détours. Installateur 0.1/0.2→0.3 avec rollback.

{limitations}
''')
readme=f'''# ALIEN — Fleuve de la Douleur · {v}

## {m['subtitle']}

Archive du DLC autonome, de ses sources, du codex et des preuves de test. **Ce n’est pas une archive du jeu Tantalus complet.**

{limitations}

## Jouer

Extraire l’archive puis ouvrir **JOUER.html**. **LANCER_WINDOWS.bat** ouvre ce même fichier sous Windows. Le jeu ne requiert ni installation, compte, CDN ou asset externe. Sources modulaires : src/river-of-pain/index.html. Alternative sur votre machine : python tools/serve.py, puis l’adresse affichée. La recette locale de cette livraison a utilisé le HTML autonome, pas un changement de sécurité du navigateur.

## Nouveautés 0.3

Six annexes reliées : office de cuisine, atelier biomédical, terrasse des antennes, atelier de manutention, dérivation des eaux grises et renfoncement des câbles. Chaque détour demande trois interventions physiques et ouvre une boucle facultative ; le dernier est réservé à Newt. La campagne reste terminable sans les réaliser. Le monde passe à 42 lieux et 57 connexions, sans modifier les 49 objectifs principaux.

Le plan combine vue coloniale, niveaux, destination et emprises de la pièce actuelle. Il ne téléporte pas. Les couvertures ont une géométrie visible partagée avec le moteur. Visée sur huit directions du sol, souris ou clavier ; deux directions seulement en classique/conduits. Les créatures cherchent une dernière position perçue plutôt qu’un joueur silencieux connu en permanence. Six séquences localisées enrichissent les annexes, dont trois seulement font apparaître un adversaire.

Les 489 placements et 118 détails conditionnels ne sont pas autant de sprites uniques. Les accessoires des annexes ont des placements regroupés et documentés. Graphismes et son synthétisé restent provisoires.

## Commandes

| Action | Commande |
|---|---|
| Déplacement / profondeur | Q D ou A D / Z S ou W S / flèches |
| Interagir / tirer | E / F |
| Visée fixe | ESPACE + directions ; F pour tirer |
| Visée/tir au pointeur | Clic gauche maintenu sur le terrain |
| Se baisser / courir | C / Maj |
| Recharger / soins / fusée | R / H / X |
| Souder ou libérer une porte | B, adulte équipé près du seuil |
| Sac / plan / carnet / pause | I / Tab / J / Échap |
| Détours facultatifs | U ou bouton DÉTOURS |
| Lampe / détecteur / cache | L / T / G |
| Suivre-attendre / balise | V / M |

Le sac donne les ordres de réassurance et partage des soins avec le compagnon proche. Newt ne tire pas et n’utilise pas l’équipement des Marines. Les cartes, carnets et tableaux mettent le temps en pause. L’écran tactile propose des commandes de base ; manette matérielle et téléphone physique non qualifiés.

## Reprendre une sauvegarde 0.1 ou 0.2

Exporter un JSON depuis Pause avant de changer de version. Dans la 0.3 : Pause → IMPORTER, choisir le fichier, confirmer CHARGER. Les anciens exports réels sont testés. Les nouvelles données sont initialisées ; une ancienne position devenue solide peut être rapprochée d’un appui libre, sans changement des ressources. Les dotations jamais sauvegardées des anciens protagonistes ne peuvent pas être reconstituées rétroactivement.

Le namespace atf.dlc.river-of-pain.v1.profile1 est inchangé. L’import refuse les fichiers étrangers et incohérents. La persistance native localStorage n’a pas été qualifiée dans l’origine opaque des tests ; l’export/import JSON l’a été. Les reprises après mort restaurent le point de contrôle, y compris l’état des détours à ce moment.

## Lanceur facultatif dans Tantalus

Installation neuve sur une copie de votre projet :

```sh
node tools/install.mjs "/chemin/vers/aliens-tantalus-frontier"
```

Installation 0.1 ou 0.2 gérée et intacte :

```sh
node tools/install.mjs "/chemin/vers/aliens-tantalus-frontier" --upgrade
```

Retrait : même commande avec --remove. Le retrait restaure le shell d’avant le DLC, pas l’ancienne version du DLC. Les empreintes et sauvegardes sont vérifiées avant changement. Un index modifié, module personnel, fichier supplémentaire, lien symbolique ou journal divergent provoque un refus. Ne pas effacer les journaux pour forcer un remplacement. Les copies de sécurité restent sous .dlc-backups.

Ce lanceur ouvre le runtime autonome ; il ne branche pas le DLC au moteur ni aux sauvegardes de Tantalus. Les tests portent sur des shells de test, dont un reçoit les vrais fichiers et l’installateur 0.2.

## Reproduire

```sh
npm run build
npm test
python tests/browser.py
python tests/browser-v02.py
python tests/browser-v03.py
# Facultatif : archive 0.2 originale extraite, pour la recette de vraie mise à niveau
node tests/upgrade-real.mjs /chemin/vers/ALIEN_FLEUVE_DOULEUR_v0.2.0
npm run docs
python tools/package-release.py
```

Node 20+, Python 3.10+. Les seules dépendances de recette navigateur sont Playwright et Chromium ; CHROMIUM_PATH indique le binaire. Pas de dépendance requise pour simplement jouer. build-docs et package-release exigent les rapports réussis, dont la recette de vraie mise à niveau.

## Résultats et lecture

{core}+{col}+{ex} cas moteur/états/géométrie ; six parcours de campagne et six avec tous les détours ; {inst} tests d’installateur et {real} contrôles sur vraie 0.2 ; {browser} contrôles Chromium sans erreur JS relevée. Ce n’est pas une certification commerciale, artistique ou humaine de l’équilibrage.

RAPPORT_ILLUSTRE.html embarque une sélection de vraies captures. Les {len(caps)} PNG et leurs états de préparation sont dans captures/ et les JSON navigateur. docs/CODEX_LEVEL_DESIGN.md détaille les 42 pièces et chaque objet. docs/QA_REPORT.md distingue unités, pilotes, fixtures et limitations. docs/SOURCES_ET_CONTINUITE.md conserve le corpus antérieur, sans nouvelle prétention de vérification intégrale du roman.
'''
(R/'README.md').write_text(readme)
# Human-readable report with actual image bytes and exact setup captions.
selected=['20-atelier-biomedical.png','21-palan-alerte.png','22-antennes.png','23-eaux-grises.png','24-renfoncement-newt.png','16-plan-colonial.png','18-plan-local-office.png','17-piece-emportee.png','19-visee.png','26-medical-classique.png','25-detours-portrait.png']
css='''*{box-sizing:border-box}body{margin:0;background:#08181f;color:#c0d1c9;font:16px/1.75 system-ui,sans-serif}main{max-width:1200px;margin:auto;padding:50px 32px 75px}header{border-bottom:1px solid #45655e;padding:25px 0 40px}h1{font-weight:450;font-size:clamp(34px,5vw,64px);line-height:1.12;color:#e1e8ca;letter-spacing:.045em}h2{font-weight:450;font-size:29px;margin-top:48px;color:#d8e2bd}h3{font-size:19px;font-weight:500;color:#c8dbb6}.eyebrow,.tag{font:11px monospace;letter-spacing:.12em;color:#9ebfb2}.lead{font-size:25px;color:#adcab9}.tag{display:inline-block;border:1px solid #809c83;padding:9px 14px}.notice{padding:20px 24px;background:#152f36;border-left:3px solid #b4bc83;font-size:14px}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:30px 0}.metric{padding:22px;background:#163239;border-top:1px solid #7f9c8c}.metric b{display:block;font:38px monospace;color:#dce8b6}.metric span{font:11px monospace;color:#a5bcae}.cols{display:grid;grid-template-columns:1fr 1fr;gap:28px}.cols article{border-top:1px solid #4a6f61;padding-top:10px}table{width:100%;border-collapse:collapse;font-size:13px}td,th{padding:13px 10px;border-bottom:1px solid #3b5a51;text-align:left;vertical-align:top}th{font:11px monospace;color:#c1cdac}figure{margin:28px 0;background:#102b32;border:1px solid #405f56}figure img{display:block;width:100%}figcaption{padding:18px 23px;font-size:14px}figcaption small{display:block;margin-top:8px;color:#92b3a2;font-size:11px}.portrait{max-width:390px;margin:28px auto}code{font-size:12px;overflow-wrap:anywhere;color:#d1c99f}a{color:#d7d6a5}footer{margin-top:45px;border-top:1px solid #476755;padding-top:20px;font-size:12px;color:#98b6a5}@media(max-width:680px){main{padding:22px 15px}.metrics{grid-template-columns:1fr 1fr}.cols{grid-template-columns:1fr}td,th{padding:9px 5px}.metric{padding:16px}}'''
h=f'''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fleuve de la Douleur — Rapport 0.3</title><style>{css}</style></head><body><main><header><p class="eyebrow">ALIENS TANTALUS FRONTIER / ARCHIVES MIRE / 29 SEPTEMBRE 2026</p><h1>ALIEN<br>FLEUVE DE LA DOULEUR</h1><p class="lead">{escape(m['subtitle'])}</p><span class="tag">{escape(v.upper())} · LIVRAISON LOCALE</span></header><p class="notice"><strong>Une suite cumulative de la 0.2.</strong> Six annexes, six chemins de service et une visée de profondeur enrichissent la campagne existante. Ni recommencement du projet ni jeu Tantalus complet : ce runtime reste autonome, avec graphisme stylisé provisoire.</p><div class="metrics">'''
for n,label in [(42,'PIÈCES RELIÉES'),(6,'DÉTOURS / 18 ÉTAPES'),(57,'CONNEXIONS'),(49,'OBJECTIFS PRINCIPAUX CONSERVÉS')]:h+=f'<div class="metric"><b>{n}</b><span>{label}</span></div>'
h+='''</div><h2>Ce qui se joue maintenant</h2><div class="cols"><article><h3>Ouvrir les chemins de service</h3><p>Chaque annexe possède une entrée libre et une sortie à réparer. Observation, collecte d’une pièce ailleurs puis retour sur place libèrent une liaison réciproque. Les notes, pièces emportées et accès suivent la progression. Rien n’est validé depuis le plan.</p></article><article><h3>Lire chaque pièce</h3><p>Le plan local reprend les 62 obstacles du moteur et leurs dimensions. Dix-huit layouts sont réorganisés. La vue classique ne plaque plus les meubles de fond sur le personnage. Les accessoires des annexes sont regroupés autour des postes et des accès ; la terrasse possède un vrai bord de toit, pas des conduites suspendues dans le ciel.</p></article><article><h3>Viser et semer</h3><p>ESPACE + directions vise sur place ; F tire. Le pointeur maintenu vise et tire sur huit directions du sol. Les couvertures interceptent les projectiles. Un poursuivant garde sa dernière position perçue au lieu de recevoir celle d’un joueur silencieux hors de vue.</p></article><article><h3>Conserver la tension</h3><p>Trois intrusions annoncées, une ombre de conduit et deux signaux d’ambiance complètent les annexes. Le spawn attend une distance sûre. Newt reste désarmée et seule à passer par le renfoncement des câbles. La 0.3 n’ajoute pas d’évacuation historique.</p></article></div><h2>Captures réelles de la livraison</h2><p>Chromium exécute le HTML autonome. Les images ne sont ni des maquettes ni des photographies. La préparation de chaque scène est indiquée ci-dessous ; les scènes tardives ne sont pas présentées comme une partie complète jouée manuellement.</p>'''
for i,n in enumerate(selected):
 c=caps[n];b64=base64.b64encode((R/c['file']).read_bytes()).decode();cl=' class="portrait"' if 'portrait' in n else ''
 h+=f'<figure{cl}><img src="data:image/png;base64,{b64}" alt="{escape(c["description"])}"><figcaption><strong>{i+1:02d} / </strong>{escape(c["description"])}<small>{escape(c["setup"])}</small></figcaption></figure>'
h+=f'''<h2>Recette exécutée sur cette passe</h2><table><thead><tr><th>ÉTENDUE</th><th>RÉSULTAT</th><th>PORTÉE</th></tr></thead><tbody><tr><td>Moteur, systèmes, exploration et géométrie</td><td>{core} + {col} + {ex} cas réussis</td><td>Inclut 42 pièces × deux vues, huit axes de tir et migration.</td></tr><tr><td>Campagne principale</td><td>6/6 parcours</td><td>49 objectifs et deux escortes depuis Nouvelle partie.</td></tr><tr><td>Campagne et tous les détours</td><td>6/6 parcours</td><td>42 pièces, 18 étapes facultatives et six raccourcis aller/retour.</td></tr><tr><td>Installateur</td><td>{inst}/{inst} + {real}/{real}</td><td>Fixtures puis vraie 0.2 sur shell de test. Pas de build Tantalus natif.</td></tr><tr><td>Chromium</td><td>{browser}/{browser} contrôles</td><td>Aucune erreur JS relevée, {len(caps)} PNG conservés. Appareils physiques non qualifiés.</td></tr></tbody></table><p>Le pilote connaît les objectifs et les chemins. Il emploie marche, équipement et interactions, sans téléportation, validation forcée ou mutation de santé. Ses minutes ne sont pas une durée de jeu humaine. Les intrusions tardives sont éprouvées par scènes contrôlées ; l’équilibrage auprès de joueurs reste à faire.</p><h2>Jouer et reprendre</h2><p>Extraire l’archive, ouvrir <code>JOUER.html</code> ou <code>LANCER_WINDOWS.bat</code>. Les exports JSON 0.1 et 0.2 passent par la même commande IMPORTER. Une position ancienne devenue solide est déplacée vers l’appui libre proche et signalée dans le journal.</p><p>Installation 0.1/0.2 gérée et intacte : <code>node tools/install.mjs DOSSIER_TANTALUS --upgrade</code>. Le retrait <code>--remove</code> restaure le shell avant DLC. Des fichiers personnels modifiés entraînent un refus, jamais une substitution silencieuse.</p><p class="notice">{escape(limitations)} Le CLI agent-browser était absent et la navigation locale bloquée par le navigateur de recette. Le HTML exact a été chargé par set_content sans modifier la sécurité. Persistance localStorage non qualifiée ; import/export JSON vérifiés.</p><footer>Codex de production : <code>docs/CODEX_LEVEL_DESIGN.md</code>. Tests : <code>docs/QA_REPORT.md</code> et JSON. {len(selected)} captures intégrées à ce rapport sur {len(caps)} PNG conservés. Les sources publiques et limites narratives sont reprises du corpus antérieur, sans nouvelle lecture intégrale du roman.</footer></main></body></html>'''
(R/'RAPPORT_ILLUSTRE.html').write_text(h)
# Exact source lineage; no suggestion of reading the current GitHub branch.
p=R/'docs/SOURCES_ET_CONTINUITE.md';s=p.read_text().replace('Fleuve de la Douleur 0.2','Fleuve de la Douleur 0.3').replace('passe de code 0.2','passe de code 0.3').replace('plan des 36 salles','plan des 42 salles').replace('les 24 documents de terrain','les 30 documents de terrain')
if '## Annexes 0.3' not in s:s+='\n## Annexes 0.3\n\nLes six nouvelles pièces, leurs 18 interventions, six documents et six séquences sont des créations de jeu, pas des scènes authentifiées du roman. La terrasse n’ajoute qu’une liaison interne. La dérivation est sèche, le tracteur reste immobilisé et le renfoncement est réservé à Newt. La frontière 2204 reste inchangée.\n'
p.write_text(s)
summary={'version':v,'codexLines':len(codex.splitlines()),'codexWords':len(codex.split()),'reportCaptures':len(selected),'allCaptures':len(caps),'modelCases':core+col+ex,'installerCases':inst,'realUpgradeCases':real,'browserCases':browser,'mainTraversals':len(tr),'completeTraversals':len(alltr),'standaloneSha256':hashlib.sha256((R/'JOUER.html').read_bytes()).hexdigest()}
(R/'docs/RELEASE_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
