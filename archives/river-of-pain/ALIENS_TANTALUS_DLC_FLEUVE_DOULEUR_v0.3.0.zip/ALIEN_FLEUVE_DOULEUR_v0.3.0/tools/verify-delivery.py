#!/usr/bin/env python3
"""Check shipped byte relationships. Does not substitute for gameplay tests."""
from pathlib import Path
import json,hashlib,subprocess,re,base64
R=Path(__file__).resolve().parents[1];sha=lambda b:hashlib.sha256(b).hexdigest();cases=[]
def check(name,condition):
 if not condition:raise AssertionError(name)
 cases.append({'name':name,'passed':True})
js=R/'src/river-of-pain';source=(js/'index.html').read_text().replace('<link rel="stylesheet" href="style.css">','<style>'+(js/'style.css').read_text()+'</style>')
for name in ['data.js','colony.js','exploration.js','core.js','render.js','architecture.js','field-visuals.js','ui.js']:
 code=(js/name).read_text();source=source.replace(f'<script src="{name}"></script>','<script>\n'+re.sub(r'</script',r'<\\/script',code,flags=re.I)+'\n</script>')
check('Standalone égale exactement ses huit sources et son CSS',source.encode()==(R/'JOUER.html').read_bytes())
check('Aucun script src ni stylesheet externe non inclus',not re.search(r'<script[^>]+src=|<link[^>]+stylesheet',source))
for p in js.glob('*.js'):
 result=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
 check('Syntaxe JavaScript '+p.name,result.returncode==0)
D=json.loads((R/'docs/CONTENT_MANIFEST.json').read_text());c=D['manifest']['counts']
for k,actual in [('rooms',len(D['rooms'])),('props',sum(len(r['props']) for r in D['rooms'])),('links',sum(len(r['portals']) for r in D['rooms'])//2),('objectives',sum(len(ch['objectives']) for ch in D['chapters'])),('archives',len(D['archives'])),('optionalSteps',sum(len(j['steps']) for j in D['jobs']))]:check('Comptage réel '+k,c[k]==actual)
for old in ['real-v01-save.json','real-v02-save.json']:
 fixture=json.loads((R/'tests/fixtures'/old).read_text());check('Authenticité structurelle de la fixture '+old,fixture['id']=='river-of-pain' and fixture['state']['version'] in ['0.1.0-candidate.1','0.2.0-candidate.1'])
caprows=[]
for n in ['BROWSER_TEST_RESULTS','BROWSER_V02_TEST_RESULTS','BROWSER_V03_TEST_RESULTS']:
 d=json.loads((R/'docs'/f'{n}.json').read_text());check('Rapport courant '+n,d['passed'] and d.get('version')==D['manifest']['version']);caprows+=d['captures']
for cap in caprows:
 p=R/cap['file'];check('Capture décrite et réelle '+p.name,p.is_file() and p.read_bytes().startswith(b'\x89PNG\r\n\x1a\n') and bool(cap['setup']))
encoded=re.findall(r'<img src="data:image/png;base64,([^"]+)"',(R/'RAPPORT_ILLUSTRE.html').read_text());digests={sha((R/c['file']).read_bytes()) for c in caprows}
check('Onze captures du rapport correspondent aux PNG vérifiés',len(encoded)==11 and all(sha(base64.b64decode(b)) in digests for b in encoded))
check('Aucune ancienne version dans les titres de livraison',all('0.3' in (R/p).read_text().split('\n')[0] for p in ['README.md','docs/QA_REPORT.md']))
# Regenerating content must be deterministic and preserve the verified gameplay bytes.
files=['src/river-of-pain/data.js','docs/CONTENT_MANIFEST.json','JOUER.html'];before={p:sha((R/p).read_bytes()) for p in files}
subprocess.run(['python','tools/build-content.py'],cwd=R,check=True,capture_output=True);subprocess.run(['python','tools/build-standalone.py'],cwd=R,check=True,capture_output=True)
check('Reconstruction reproductible des données et du jeu',before=={p:sha((R/p).read_bytes()) for p in files})
report={'passed':True,'cases':cases,'standaloneSha256':before['JOUER.html'],'sourceDigests':{p.name:sha(p.read_bytes()) for p in js.iterdir() if p.is_file()},'scope':'Byte relationships, JavaScript parse checks and rebuilt-content determinism; gameplay evidence in separate suites'}
(R/'docs/DELIVERY_VALIDATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(str(len(cases))+' delivery checks PASS')
