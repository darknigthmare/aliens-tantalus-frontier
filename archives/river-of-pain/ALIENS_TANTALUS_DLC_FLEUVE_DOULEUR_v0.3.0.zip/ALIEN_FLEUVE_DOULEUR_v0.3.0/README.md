# ALIEN — Fleuve de la Douleur · 0.3.0-candidate.1

## Hadley’s Hope · Les chemins de traverse

Archive du DLC autonome, de ses sources, du codex et des preuves de test. **Ce n’est pas une archive du jeu Tantalus complet.**

Cette livraison reste un DLC autonome avec lanceur additionnel. Le GameEngine natif de Tantalus, ses atlas, ses sauvegardes et l’écho Frontière 2204 ne sont pas modifiés. Aucun push GitHub ni déploiement Vercel. Les personnages et décors sont dessinés par code : graphisme stylisé provisoire, pas assets définitifs ni reconstitution 1:1. Le roman intégral n’a pas été consulté ; pièces, dialogues, documents et manœuvres sont une condensation originale.

## Jouer

Extraire l’archive puis ouvrir **JOUER.html**. **LANCER_WINDOWS.bat** ouvre ce même fichier sous Windows. Le jeu ne requiert ni installation, compte, CDN ou asset externe. Sources modulaires : src/river-of-pain/index.html. Alternative sur votre machine : python tools/serve.py, puis l’adresse affichée. La recette locale de cette livraison a utilisé le HTML autonome, pas un changement de sécurité du navigateur.

## Nouveautés 0.3

Six annexes reliées : office de cuisine, atelier biomédical, terrasse des antennes, atelier de manutention, dérivation des eaux grises et renfoncement des câbles. Chaque détour demande trois interventions physiques et ouvre une boucle facultative ; le dernier est réservé à Newt. La campagne reste terminable sans les réaliser. Le monde passe à 42 lieux et 57 connexions, sans modifier les 49 objectifs principaux.

Le plan combine vue coloniale, niveaux, destination et emprises de la pièce actuelle. Il ne téléporte pas. Les couvertures ont une géométrie visible partagée avec le moteur. Visée sur huit directions du sol, souris ou clavier ; deux directions seulement en classique/conduits. Les créatures cherchent une dernière position perçue plutôt qu’un joueur silencieux connu en permanence. Six séquences localisées enrichissent les annexes, dont trois seulement font apparaître un adversaire.

Les 489 placements et 118 détails conditionnels ne sont pas autant de sprites uniques. Les accessoires des annexes ont des placements regroupés et documentés. Graphismes et son synthétisé restent provisoires.

## Commandes

| Action | Commande |
|---|---|
| Déplacement / profondeur | Q D ou A D / Z S ou W S / flèches |
| Interagir / tirer | E / F |
| Visée fixe | ESPACE + directions ; F pour tirer |
| Visée/tir au pointeur | Clic gauche maintenu sur le terrain |
| Se baisser / courir | C / Maj |
| Recharger / soins / fusée | R / H / X |
| Souder ou libérer une porte | B, adulte équipé près du seuil |
| Sac / plan / carnet / pause | I / Tab / J / Échap |
| Détours facultatifs | U ou bouton DÉTOURS |
| Lampe / détecteur / cache | L / T / G |
| Suivre-attendre / balise | V / M |

Le sac donne les ordres de réassurance et partage des soins avec le compagnon proche. Newt ne tire pas et n’utilise pas l’équipement des Marines. Les cartes, carnets et tableaux mettent le temps en pause. L’écran tactile propose des commandes de base ; manette matérielle et téléphone physique non qualifiés.

## Reprendre une sauvegarde 0.1 ou 0.2

Exporter un JSON depuis Pause avant de changer de version. Dans la 0.3 : Pause → IMPORTER, choisir le fichier, confirmer CHARGER. Les anciens exports réels sont testés. Les nouvelles données sont initialisées ; une ancienne position devenue solide peut être rapprochée d’un appui libre, sans changement des ressources. Les dotations jamais sauvegardées des anciens protagonistes ne peuvent pas être reconstituées rétroactivement.

Le namespace atf.dlc.river-of-pain.v1.profile1 est inchangé. L’import refuse les fichiers étrangers et incohérents. La persistance native localStorage n’a pas été qualifiée dans l’origine opaque des tests ; l’export/import JSON l’a été. Les reprises après mort restaurent le point de contrôle, y compris l’état des détours à ce moment.

## Lanceur facultatif dans Tantalus

Installation neuve sur une copie de votre projet :

```sh
node tools/install.mjs "/chemin/vers/aliens-tantalus-frontier"
```

Installation 0.1 ou 0.2 gérée et intacte :

```sh
node tools/install.mjs "/chemin/vers/aliens-tantalus-frontier" --upgrade
```

Retrait : même commande avec --remove. Le retrait restaure le shell d’avant le DLC, pas l’ancienne version du DLC. Les empreintes et sauvegardes sont vérifiées avant changement. Un index modifié, module personnel, fichier supplémentaire, lien symbolique ou journal divergent provoque un refus. Ne pas effacer les journaux pour forcer un remplacement. Les copies de sécurité restent sous .dlc-backups.

Ce lanceur ouvre le runtime autonome ; il ne branche pas le DLC au moteur ni aux sauvegardes de Tantalus. Les tests portent sur des shells de test, dont un reçoit les vrais fichiers et l’installateur 0.2.

## Reproduire

```sh
npm run build
npm test
python tests/browser.py
python tests/browser-v02.py
python tests/browser-v03.py
# Facultatif : archive 0.2 originale extraite, pour la recette de vraie mise à niveau
node tests/upgrade-real.mjs /chemin/vers/ALIEN_FLEUVE_DOULEUR_v0.2.0
npm run docs
python tools/package-release.py
```

Node 20+, Python 3.10+. Les seules dépendances de recette navigateur sont Playwright et Chromium ; CHROMIUM_PATH indique le binaire. Pas de dépendance requise pour simplement jouer. build-docs et package-release exigent les rapports réussis, dont la recette de vraie mise à niveau.

## Résultats et lecture

96+75+149 cas moteur/états/géométrie ; six parcours de campagne et six avec tous les détours ; 28 tests d’installateur et 4 contrôles sur vraie 0.2 ; 60 contrôles Chromium sans erreur JS relevée. Ce n’est pas une certification commerciale, artistique ou humaine de l’équilibrage.

RAPPORT_ILLUSTRE.html embarque une sélection de vraies captures. Les 26 PNG et leurs états de préparation sont dans captures/ et les JSON navigateur. docs/CODEX_LEVEL_DESIGN.md détaille les 42 pièces et chaque objet. docs/QA_REPORT.md distingue unités, pilotes, fixtures et limitations. docs/SOURCES_ET_CONTINUITE.md conserve le corpus antérieur, sans nouvelle prétention de vérification intégrale du roman.
