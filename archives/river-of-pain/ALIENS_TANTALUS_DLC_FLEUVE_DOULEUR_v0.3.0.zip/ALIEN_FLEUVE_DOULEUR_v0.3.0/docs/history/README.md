# Preuve antérieure conservée

SAVE_MIGRATION_V01_TO_V02.json appartient à la livraison 0.2. Elle n’entre pas dans les comptes de qualification 0.3. Les vérifications actuelles des anciens exports se trouvent dans COLONY_TEST_RESULTS.json, EXPLORATION_TEST_RESULTS.json et les rapports navigateur à la racine de docs/.
