#!/usr/bin/env python3
"""Generate 0.5 room codex and illustrated delivery report from the shipped data and completed QA.
Refuses incomplete or failed suites. Standard library only; does not publish anything.
"""
from pathlib import Path
from html import escape
from collections import Counter
import base64, json, hashlib, re
R=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((R/'docs'/n).read_text(encoding='utf-8'))
D=read('CONTENT_MANIFEST.json');rooms={r['id']:r for r in D['rooms']};m=D['manifest'];v=m['version'];cnt=m['counts']
assert v=='0.5.0-candidate.1'
fmt=lambda n: str(round(n,3)).rstrip('0').rstrip('.') if isinstance(n,float) else str(n)
cell=lambda s:str(s).replace('|',' / ').replace('\n',' ')
limitations='DLC autonome avec lanceur additionnel, pas le jeu Tantalus complet ni son GameEngine natif. Aucun push GitHub ni déploiement Vercel. Dessins stylisés par code, pas atlas définitifs ou reconstitution 1:1. Roman intégral non consulté : plans, dialogues, tâches et documents sont une condensation originale. L’écho Frontière 2204 et les sauvegardes du moteur hôte ne sont pas modifiés.'
model_names=['CORE_TEST_RESULTS','COLONY_TEST_RESULTS','EXPLORATION_TEST_RESULTS','PASSAGES_TEST_RESULTS','PERSISTENCE_TEST_RESULTS','LIFE_TEST_RESULTS']
browser_names=['BROWSER_TEST_RESULTS','BROWSER_V02_TEST_RESULTS','BROWSER_V03_TEST_RESULTS','BROWSER_V04_TEST_RESULTS','BROWSER_V05_TEST_RESULTS']
reports={n:read(n+'.json') for n in model_names+browser_names+['INSTALLER_TEST_RESULTS','REAL_UPGRADE_TEST_RESULTS']}
for n,r in reports.items():
 if not r.get('passed'):raise RuntimeError('Recette incomplète ou en échec : '+n)
 if r.get('version',v)!=v:raise RuntimeError('Rapport d’une autre version : '+n)
tr=read('TRAVERSAL_RESULTS.json');alltr=read('TRAVERSAL_EXPLORATION_RESULTS.json')
assert len(tr)==len(alltr)==6 and all(r['passed'] for r in tr+alltr)
assert all(r['visited']==42 and len(r['detours'])==6 for r in alltr)
lifetr=read('TRAVERSAL_LIFE_RESULTS.json');assert lifetr['passed'] and len(lifetr['cases'])==6
num=lambda n:reports[n]['cases'] if isinstance(reports[n]['cases'],int) else len(reports[n]['cases'])
model=sum(num(n) for n in model_names);browser=sum(num(n) for n in browser_names)
caprows=sum((reports[n]['captures'] for n in browser_names),[]);caps={Path(c['file']).name:c for c in caprows}
assert len(caps)==len(caprows)
for c in caprows:assert (R/c['file']).is_file() and c.get('setup')
timings={'escalier':(.45,1.4),'échelle':(.5,1.8),'monte-charge':(1.2,2.4),'sas':(1.1,1.1)}
seen=set();links=[]
for r in D['rooms']:
 for p in r['portals']:
  key=tuple(sorted([r['id'],p['to']]))
  if key in seen:continue
  seen.add(key)
  if p['kind'] in timings:links.append((r,p))
assert len(links)==21
by_kind=Counter(p['kind'] for _,p in links)
principles=(R/'docs/DOCTRINE_V05.md').read_text(encoding='utf-8')
lines=['# ALIEN — Fleuve de la Douleur','',f'## Codex de level design · {v}','',m['subtitle'],'',limitations,'',principles]
lines += ['## Douze personnes de service originales','']
for d in D['life']['residents']:
 lines += [f"### {d['name']} · `{d['id']}`",'',f"**{d['role']} · {rooms[d['room']]['name']} · stades 0 et 1 uniquement**",'',f"Silhouette : hauteur {d['height']}, accessoire `{d['tool']}`, apparence `{d['hair']}`. Trajet local : "+' → '.join(f"({q['x']} / {q['z']})" for q in d['points'])+'. Retrait : '+str(d['refuge'])+'.','',f"Avant la crise : « {d['intro'][0]} »",'',f"Premiers incidents : « {d['intro'][1]} »",'']
 for t in d['topics']:lines += [f"**{t['label']}** · `{t['id']}`",'',t['text'],'']
 lines += ['Ces réponses doivent être demandées sur place pour être conservées. Aucun suivi à distance, crédit de mission ou sort canonique attribué.','']
lines += ['## Réserves finies et établis','', '| Réserve / identifiant | Pièce | Point x / z | Contenu initial |','|---|---|---|---|']
for d in D['life']['containers']:lines.append(f"| {d['label']} · `{d['id']}` | {rooms[d['room']]['name']} | {d['x']} / {d['z']} | "+' ; '.join(f"{n} {D['life']['items'][k]['label']}" for k,n in d['items'].items())+' |')
lines += ['', 'Les contenus sont partagés entre les protagonistes. Les prises respectent les capacités ; les surplus restent dans le meuble.','', '| Établi / identifiant | Pièce | Point x / z | Recettes |','|---|---|---|---|']
for d in D['life']['benches']:lines.append(f"| {d['label']} · `{d['id']}` | {rooms[d['room']]['name']} | {d['x']} / {d['z']} | Balise sonore / recharge de lampe |")
lines += ['','Les stations ne sont pas des couvertures collisionnables supplémentaires. Le point ci-dessus est la cible physique de l’interaction, avec une portée de proximité.','']
lines += ['## Registre des 21 liaisons temporisées','', 'Les liaisons ci-dessous se parcourent dans les deux sens. Les points de départ et de retour détaillés dans chaque fiche de pièce restent les coordonnées de référence. Les temps sont des secondes de simulation, pas des mesures du film ou du roman.','', '| Origine | Destination | Nature | Niveaux | Préparation exposée | Trajet engagé |','|---|---|---|---|---:|---:|']
for r,p in links:
 b,t=timings[p['kind']];lines += [f"| {r['name']} | {rooms[p['to']]['name']} | {p['kind']} | {r['floor']} → {rooms[p['to']]['floor']} | {fmt(b)} s | {fmt(t)} s |"]
lines += ['','## Registre des six détours','']
for j in D['jobs']:
 r=rooms[j['room']];free=next(p for p in r['portals'] if not p['requires']);gate=next(p for p in r['portals'] if p['requires'])
 lines += [f"### {j['title']} · `{j['id']}`",'',f"**{r['name']} · {'Newt seule' if j['childOnly'] else 'Personnage adulte'}**",'',j['steps'][0]['description'],'',f"Boucle : {rooms[free['to']]['name']} → {r['name']} → {rooms[gate['to']]['name']}. L’entrée depuis {rooms[free['to']]['name']} ne demande pas d’avoir déjà ouvert la sortie.",'','| Étape | Salle | Action | x / z | Temps sur place |','|---|---|---|---|---|']
 for i,t in enumerate(j['steps']):lines.append(f"| {i+1} | {rooms[t['room']]['name']} | {t['label']} | {fmt(t['x'])} / {fmt(t['z'])} | {t['duration']} s |")
 reward={'medkit':'une trousse de soins','flare':'deux fusées','battery':'réserve de lampe remise à 100 %','food':'25 points de santé, maximum 100'}[j['reward']]
 a=next(a for a in D['archives'] if a['id']==j['archive'])
 lines += ['',f"Pièce emportée : **{j['item']}**. La pose exige cette étape, le bon personnage et la proximité. L’éloignement ou une blessure interrompt la pose sans effacer la pièce.",'',f"Effet : `{j['flag']}` autorise les deux portails. Récompense : {reward}, une seule fois ; document `{a['id']}` — {a['title']}. Le compteur de campagne principale ne change pas.",'']
lines += ['## Rencontres ajoutées et annonce','', '| ID / pièce | Nature | Stade minimum | Seuil x | Ancrage x / z | Préavis |','|---|---|---:|---:|---|---:|']
for e in D['encounters']:lines.append(f"| `{e['id']}` / {rooms[e['room']]['name']} | {e['type']} | {e['minPhase']} | {e['triggerX']} | {e['spawnX']} / {e['spawnZ']} | {e['warning']} s |")
for e in D['encounters']:lines += ['',f"**{e['id']}** — {e['label']}"]
lines += ['','## Campagne principale : 49 objectifs conservés','']
for c in D['chapters']:
 lines += [f"### {c['index']+1:02d} — {c['title']}",'',f"**{D['characters'][c['character']]['name']} · {c['timeLabel']} · {rooms[c['start']]['name']}**",'',c['synopsis'],'','| Ordre | Lieu | Action réelle | Type |','|---|---|---|---|']
 for i,t in enumerate(c['objectives']):
  o=next(o for o in rooms[t['room']]['objects'] if o['id']==t['id']);lines.append(f"| {i+1} | {rooms[t['room']]['name']} | {o['label']} | `{o['kind']}` |")
 lines += ['',f"Dialogue original de jeu : **{c['dialogue']['speaker']}** — « {c['dialogue']['text']} »",'']
lines += ['## Tableaux et collecteurs : solutions de recette','']
for bid,b in D['boards'].items():
 lines += [f"### {b['title']} · `{bid}`",'',f"{rooms[b['room']]['name']} · circuit `{b['circuit']}` · capacité {b['capacity']}.",'',b['hint'],'','| Commande | Charge | État requis | Initial |','|---|---:|---|---|']
 for i,c in enumerate(b['channels']):lines.append(f"| {c[0]} | {c[1]} | {'Actif' if c[2] else 'Coupé'} | {'Actif' if b['initial'][i] else 'Coupé'} |")
 lines += ['']
lines += ['## Les 42 fiches de pièce','']
for r in D['rooms']:
 a=r['architecture'];lines += [f"### {r['name']} · `{r['id']}`",'',f"**{r['building']} · niveau {r['floor']} · {r['kind']} · {r['width']} unités · z {r['minZ']}–{r['maxZ']}**",'',f"Repère d’orientation : {r['landmark']}. Profil `{a['style']}` / `{a['variant']}`, circuit `{a['circuit']}`, emprise `{r['layoutProfile']}`.",'',f"Blocage métrique déclaré : {r['dimensionsM']} ; intention originale, pas mesure du roman. {a['wallModules']} travées murales déclarées. Les facteurs de parallaxe d’architecture sont des métadonnées de production, pas tous des variables autonomes du renderer.",'','#### Entrées, retours et droits','', '| Sortie | Nature | Départ x / z | Retour x / z | Condition |','|---|---|---|---|---|']
 for p in r['portals']:
  back=next(q for q in rooms[p['to']]['portals'] if q['to']==r['id']);cond=('Newt ; ' if p['childOnly'] else '')+(p['requires'] or 'Libre')
  lines.append(f"| {rooms[p['to']]['name']} | {p['kind']} | {fmt(p['x'])} / {fmt(p['z'])} | {fmt(back['x'])} / {fmt(back['z'])} | {cond} |")
 for p in r['portals']:
  if p['kind'] in timings:
   board,travel=timings[p['kind']]
   extra=' Circuit coupé : +1,6 s de trajet.' if p['kind']=='monte-charge' else ''
   lines += ['',f"Raccord vers **{rooms[p['to']]['name']}** : préparation exposée {fmt(board)} s, puis trajet borné {fmt(travel)} s.{extra} Arrivée au portail inverse ; annulation par mouvement ou blessure avant engagement. Les menus ne permettent pas de contourner les droits d’accès."]
 lines += ['', 'Lecture des seuils : les observations sont datées, locales et non garanties. L’écoute ne rend pas cette pièce sûre. Les emprises et points de retour ci-dessous restent la référence de placement.']
 lines += ['','#### Obstacles : emprise commune au rendu et au moteur','', '| ID | Nature | Centre x / z | Largeur / profondeur |','|---|---|---|---|']
 if not r['cover']:lines += ['| Aucun | Passage latéral dégagé | — | — |']
 for c in r['cover']:lines.append(f"| `{c['id']}` | {c['prop']} | {fmt(c['x'])} / {fmt(c['z'])} | {fmt(c['w'])} / {fmt(c['d'])} |")
 lines += ['','#### Décors : fonction avant densité','', '| ID / objet | x / z | Couche | Solide | Rôle et placement |','|---|---|---|---|---|']
 for p in r['props']:lines.append(f"| `{p['id']}` / {p['kind']} | {fmt(p['x'])} / {fmt(p['z'])} | {p['layer']} | {'Oui' if p['collidable'] else 'Non'} | {cell(p['purpose'])} |")
 lines += ['','#### Interactions et cachettes','', '| ID / action | x / z | Condition d’apparition | Type |','|---|---|---|---|']
 for o in r['objects']:
  cond='Chapitre '+str(o['chapter']+1) if 'chapter' in o else 'Détour '+o['job']+' / étape '+str(o['step']+1) if o['kind']=='side-task' else 'Facultatif'
  lines.append(f"| `{o['id']}` · {cell(o['label'])} | {fmt(o['x'])} / {fmt(o['z'])} | {cond} | {o['kind']} |")
 if r['phaseDressing']:
  lines += ['','#### État de crise visible','', '| Élément | x / z | Stade minimum |','|---|---|---:|']
  for q in r['phaseDressing']:lines.append(f"| {q['kind']} | {fmt(q['x'])} / {fmt(q['z'])} | {q['fromPhase']} |")
 for h in D['hazards']:
  if h['room']==r['id']:lines += ['',f"Danger local `{h['id']}` : x {h['x']}, z {h['z']}. Valeurs de recette : `{json.dumps(h,ensure_ascii=False)}`."]
 for e in D['encounters']:
  if e['room']==r['id']:lines += ['',f"Rencontre `{e['id']}` : annonce de {e['warning']} s au passage x ≥ {e['triggerX']}, à partir du stade {e['minPhase']}. Consulter son état de sauvegarde avant tout ajout d’ennemi."]
 localpeople=[d for d in D['life']['residents'] if d['room']==r['id']];localboxes=[d for d in D['life']['containers'] if d['room']==r['id']];localbenches=[d for d in D['life']['benches'] if d['room']==r['id']]
 if localpeople or localboxes or localbenches:
  lines += ['','#### Vie coloniale et stations de la 0.5','']
  for d in localpeople:lines += [f"**{d['name']}** · {d['role']}. Routine 0/1 : "+' → '.join(f"({q['x']} / {q['z']})" for q in d['points'])+'. P permet de sélectionner sa conversation sans emprunter un accès voisin.','']
  for d in localboxes:lines += [f"**{d['label']}** · `{d['id']}` à ({d['x']} / {d['z']}). Fermoir fermé → ouverture exposée → contenu fini → surplus ou état vide. Contenu : "+' ; '.join(f"{n} {D['life']['items'][k]['label']}" for k,n in d['items'].items())+'. Pas de remplissage après une visite.','']
  for d in localbenches:lines += [f"**{d['label']}** · `{d['id']}` à ({d['x']} / {d['z']}). Adulte proche ; deux recettes, coût débité seulement au terme. Aucun usage à distance ni atelier pour Newt.",'']
 lines += ['','#### Garde-fous de cette pièce','',f"Les {len(r['portals'])} retours, {len(r['objects'])} points d’interaction et {len(r['cover'])} obstacles sont issus du même contenu que le runtime. La recette géométrique a marché de l’entrée vers chaque point dans les deux vues. Elle contrôle l’accessibilité, pas une partie humaine complète ni l’équilibrage de chaque rencontre.",'', 'Ne pas ajouter de collision aux accessoires muraux sans modifier le plan local et relancer la recette. Ne pas déplacer un seuil sans déplacer son point de retour. Ne pas transformer un décor d’observation en porte non documentée. Préserver la bande z = 0,7 pour le mode classique.','']
lines += ['## Documents originaux','']
for a in D['archives']:
 lines += [f"### {a['id']} — {a['title']}",'',str(a.get('text',a.get('body',''))),'']
lines += ['## Qualification courante','',f'{model} groupes/cas du modèle, dont {num("PASSAGES_TEST_RESULTS")} pour les seuils et {num("PERSISTENCE_TEST_RESULTS")} pour le stockage abstrait. Dix-huit parcours complets retestés. {num("INSTALLER_TEST_RESULTS")} cas d’installateur sur projets de test et {num("REAL_UPGRADE_TEST_RESULTS")} avec les vrais fichiers 0.4. {browser} contrôles dans Chromium et {len(caps)} captures décrites. Voir QA_REPORT.md pour les périmètres et limites.','',limitations]
codex='\n'.join(lines)+'\n';(R/'docs/CODEX_LEVEL_DESIGN.md').write_text(codex,encoding='utf-8')
qa=f'''# Qualification locale — {v}

Ces résultats correspondent aux suites achevées sur cette version. Les comptes des versions archivées dans `history/` ne sont pas additionnés. Les cas du modèle et les observations navigateur sont des assertions ou groupes, pas autant de sessions humaines.

| Suite | Réussite | Portée réelle |
|---|---:|---|
| core.cjs | {num('CORE_TEST_RESULTS')}/{num('CORE_TEST_RESULTS')} | État, progression, collisions, codec et interactions héritées |
| colony.cjs | {num('COLONY_TEST_RESULTS')}/{num('COLONY_TEST_RESULTS')} | Tableaux, caches, batterie, soudures, escortes |
| exploration.cjs | {num('EXPLORATION_TEST_RESULTS')}/{num('EXPLORATION_TEST_RESULTS')} | Géométrie des 42 pièces, détours, visée et mémoire |
| passages.cjs | {num('PASSAGES_TEST_RESULTS')}/{num('PASSAGES_TEST_RESULTS')} | 84 franchissements orientés, annulations, écoute, détecteur et migrations |
| persistence.cjs | {num('PERSISTENCE_TEST_RESULTS')}/{num('PERSISTENCE_TEST_RESULTS')} | Stockage mémoire simulé : double copie, intégrité, erreurs de quota et refus d’écrasement |
| life.cjs | {num('LIFE_TEST_RESULTS')}/{num('LIFE_TEST_RESULTS')} | Résidents, 24 thèmes, contenants, recettes, balises, limites de personnage et refus d’imports incohérents |
| traversal.cjs | 6/6 | Campagne principale, deux vues × trois difficultés |
| traversal-exploration.cjs | 6/6 | Même campagne avec six détours et leurs passages aller/retour |
| traversal-life.cjs | 6/6 | Campagne, détours, 12 résidents, 24 sujets, 12 réserves, trois fabrications et trois poses |
| installer.mjs | {num('INSTALLER_TEST_RESULTS')}/{num('INSTALLER_TEST_RESULTS')} | Projets hôtes de test, conflits, restauration et mises à niveau simulées |
| upgrade-real.mjs | {num('REAL_UPGRADE_TEST_RESULTS')}/{num('REAL_UPGRADE_TEST_RESULTS')} | Vrais fichiers/installateur 0.4, puis payload 0.5 et restauration sur un shell hôte de test |
| browser.py | {num('BROWSER_TEST_RESULTS')}/{num('BROWSER_TEST_RESULTS')} | Début au clavier, export réel, mouvement, menus et tactile émulé |
| browser-v02.py | {num('BROWSER_V02_TEST_RESULTS')}/{num('BROWSER_V02_TEST_RESULTS')} | Régression des systèmes de survie et véritable export 0.1 |
| browser-v03.py | {num('BROWSER_V03_TEST_RESULTS')}/{num('BROWSER_V03_TEST_RESULTS')} | Régression des détours, cartes et visée ; véritable export 0.2 |
| browser-v04.py | {num('BROWSER_V04_TEST_RESULTS')}/{num('BROWSER_V04_TEST_RESULTS')} | Raccords, écoute, détecteur et véritable export 0.3 |
| browser-v05.py | {num('BROWSER_V05_TEST_RESULTS')}/{num('BROWSER_V05_TEST_RESULTS')} | Conversations, réserves, assemblage, diversion, vrai export 0.4 et exports actuels coffre/balise |

**Modèle : {model}/{model}. Navigateur : {browser}/{browser}, aucune erreur JavaScript relevée.** Les 18 parcours sont comptés séparément. {len(caps)} captures actuelles sont décrites par les JSON des cinq recettes navigateur.

## Méthode et limites des parcours

Les pilotes démarrent une nouvelle partie et utilisent les déplacements via `Simulation.update`, les interactions, les commandes de jeu, les soins disponibles et les solutions des tableaux. Ils n’appellent pas la validation forcée des objectifs, ne téléportent pas le personnage et ne réécrivent pas sa santé. Le rétablissement de santé entre chapitres et les ressources prévus par le jeu restent actifs.

Les six parcours de vie coloniale visitent les douze résidents pendant la période calme, lisent les 24 sujets, ouvrent onze réserves avec un adulte puis la boîte des conduits avec Newt, fabriquent et posent une balise sur chacun des trois établis, terminent les six détours et les 49 objectifs avec les deux escortes. Les minuteries des balises sont laissées aller jusqu’à leur expiration. Ce tour précoce ne prouve pas l’équilibrage d’une découverte tardive ni l’utilité tactique de chaque réserve sous attaque.

L’attraction et la destruction d’une balise sont éprouvées séparément dans des fixtures locales où la créature et le leurre sont préparés explicitement. Les tests de priorité confirment qu’un joueur vu n’est pas oublié au profit du bip. Aucune simulation acoustique scientifique ni IA globale de type Alien: Isolation n’est revendiquée.

## Navigateur et captures

Le CLI agent-browser est absent. Une nouvelle tentative HTTP locale a renvoyé `net::ERR_BLOCKED_BY_ADMINISTRATOR` ; le fichier HTML autonome exact est donc chargé avec Playwright `set_content`, dans l’origine opaque autorisée, sans modification des politiques de sécurité. Les captures viennent de Chromium exécutant réellement le moteur, pas d’images d’intention.

Les premières scènes emploient les commandes du menu et le clavier. Les scènes tardives ou ciblées chargent des sauvegardes préparées, validées et importées par le sélecteur de fichier ordinaire. Chaque capture du rapport indique sa méthode d’initialisation. Une scène de fixture ne constitue pas une scène nouvellement authentifiée du roman ni une partie entière jouée manuellement.

Le véritable export d’un coffre ouvert puis partiellement vidé est téléchargé et relu : l’objet récupéré ne revient pas et le surplus est conservé. Un autre vrai fichier exporté après fabrication et pose reprend la balise pendant son armement, sans double prélèvement. Les contrôles portrait sont des émulations Chromium, pas des tests de matériel téléphonique ou de Safari/iPhone.

## Persistance : ne pas confondre protocole et stockage natif

Les deux emplacements alternés sont testés avec `MemoryStorage` explicitement simulé. Leur robustesse face à une chaîne tronquée ou une exception ne certifie pas localStorage après fermeture, les quotas réels, le mode privé ou plusieurs onglets concurrents. Ces périmètres restent non qualifiés. Les véritables imports et exports JSON sont, eux, vérifiés dans le navigateur.

Les fichiers `real-v01-save.json` à `real-v04-save.json` sont des exports réels des anciennes livraisons. Ils ne sont pas des états récents simplement renommés. Leur provenance est décrite dans les rapports d’historique et dans les sources de chaque test. Le codec initialise la vie coloniale sans attribuer de contacts, de coffres ouverts ou de composants antérieurs fictifs.

## Corrections issues de la recette

Deux réserves proches de l’appui initial d’un résident ont été séparées lors de l’export du contenu. Les interactions inutilisables n’éclipsent plus un résident accessible. La commande P et son équivalent dans le registre permettent de parler près d’une porte valide sans déclencher le franchissement. La profondeur des balises se replie réellement vers z = 0,7 lors du passage au mode classique. La recette d’équipement attend maintenant les sept actions réellement présentes, tout en conservant les six anciennes.

## Limites de production maintenues

Résidents locaux aux stades 0/1, pas population simulée dans toute la colonie, pas système de mort/évacuation des nouveaux civils. Stations de fouille non collisionnables, distinctes des 62 obstacles. Raccords bornés, pas axe vertical continu ni véhicule pilotable. Aucune certification de manette physique, multijoueur, difficulté humaine, durée de campagne ou bande-son définitive.

{limitations}
'''
(R/'docs/QA_REPORT.md').write_text(qa,encoding='utf-8')
readme=f'''# ALIEN — Fleuve de la Douleur · {v}

## Ceux qui habitaient ici

Cette archive cumulative poursuit la 0.4. Elle contient le DLC autonome jouable, les sources modulaires, le codex pièce par pièce, les tests et les captures. **Ce n’est pas le jeu Tantalus complet ni une intégration au GameEngine natif.**

### Jouer

Ouvrez `JOUER.html` dans un navigateur de bureau. Le fichier est autonome, sans téléchargement d’assets. `LANCER_WINDOWS.bat` ouvre ce fichier sous Windows. Le dossier `src/river-of-pain/index.html` est l’entrée modulaire alternative ; il n’est pas nécessaire pour le fichier autonome.

L’accès à une sauvegarde locale dépend du navigateur et de l’origine du fichier. Exportez un JSON avec Pause → EXPORTER pour garder une copie transportable. La persistance native après fermeture reste non qualifiée dans l’environnement de test.

### Reprendre la 0.1, 0.2, 0.3 ou 0.4

Dans l’ancienne version : Pause → EXPORTER. Dans celle-ci : Pause → IMPORTER, choisissez le fichier et confirmez CHARGER. Les quatre véritables fichiers historiques ont été testés. Les rencontres de résidents et composants commencent vides ; votre progression principale n’est pas réinventée.

Les exports conservent coffres ouverts, surplus, sujets lus, poches et balises. Une fouille ou fabrication inachevée est annulée à l’import sans consommer de composants ; recommencez-la. Un raccord de la 0.4 déjà engagé reprend, lui, son temps restant.

### Nouveautés réellement jouables

Douze habitants originaux avec routine locale avant l’effondrement, deux sujets chacun et registre des rencontres. Douze contenants à ouverture lente/discrète ou rapide/bruyante, couvercle persistant et ressources finies. Trois établis : balise sonore ou recharge de lampe. Les balises sont non explosives, posées au sol, avec trois secondes d’armement et douze de bips ; une créature qui a perdu sa cible peut les chercher puis les détruire. Les victimes visibles restent prioritaires.

Les 42 pièces, 16 chapitres, 49 objectifs principaux, deux escortes, six détours, 21 raccords, 24 cachettes et 30 notes sont conservés. Les 24 sujets de résidents sont séparés du compteur de notes. Les nouveaux habitants ne sont pas des personnages attribués au roman.

### Commandes

| Action | Commande |
|---|---|
| Marcher et profondeur | Q/D et Z/S ; A/D et W/S ; flèches |
| Interagir avec le point prioritaire | E |
| Parler explicitement à un résident proche | P ; ou COLONIE → PARLER |
| Registre des personnes rencontrées | Y ou COLONIE |
| Poser une balise sonore | K ; ou ÉQUIPEMENT → Balise sonore |
| Tirer, recharger | F, R ; pointeur maintenu pour viser/tirer |
| Visée fixe | Espace + directions |
| Se baisser, courir | C, Maj |
| Soins, fusée, soudure | H, X, B |
| Lampe, détecteur, cachette | L, T, G |
| Plan, carnet, équipement, détours | Tab, J, I, U |
| Écouter, dossier de seuils | N, O |
| Suivre/attendre, repère de repli | V, M |
| Pause | Échap |

Newt ne tire pas, ne soude pas, ne prend pas de composants de bricolage et ne pose pas de balise sonore. Anne ne possède pas d’arme. Les fenêtres de lecture mettent le jeu en pause ; les ouvertures et fabrications se font ensuite en temps réel.

### Installation facultative du lanceur Tantalus

```sh
node tools/install.mjs /chemin/vers/aliens-tantalus-frontier
# Depuis une ancienne installation reconnue et intacte :
node tools/install.mjs /chemin/vers/aliens-tantalus-frontier --upgrade
# Restaurer l’index initial :
node tools/install.mjs /chemin/vers/aliens-tantalus-frontier --remove
```

L’installateur ajoute un répertoire et un accès au menu/archives. Il ne remplace ni le moteur natif, ni le catalogue, ni les sauvegardes de Tantalus. Les fichiers touchés sont vérifiés ; une modification personnelle ou un conflit provoque un refus. La vraie montée 0.4 → 0.5 a été testée avec les modules des deux archives sur un shell hôte de test, pas sur le dépôt complet. Aucun push ni déploiement.

### Reproduire les vérifications

Node.js 20+ et Python 3 suffisent aux tests du modèle et à la reconstruction. Les scripts navigateur demandent Playwright et Chromium. Le chemin par défaut est `/usr/bin/chromium` ; utilisez `CHROMIUM_PATH` sur un autre système. Aucun téléphone ou contrôleur physique n’est simulé comme réellement testé.

```sh
npm run build
npm test
npm run test:life-traversal
node tests/upgrade-real.mjs /chemin/vers/la/0.4.0/originale
npm run test:browser
npm run docs
npm run test:report
python tools/verify-delivery.py
python tools/package-release.py
```

Les scripts de publication ne contactent aucun service distant : `package-release.py` produit seulement un ZIP local. Les deux installations antérieures intactes restent séparées pendant la recette de montée de version.

### Résultats et limites

{model} tests/groupes du modèle, 18 parcours automatisés, {num('INSTALLER_TEST_RESULTS')} cas d’installation sur fixtures et {num('REAL_UPGRADE_TEST_RESULTS')} sur vrais payloads, {browser} contrôles navigateur. Les pilotes connaissent les solutions ; aucune durée humaine ni difficulté commerciale n’est certifiée. Le rapport incorpore ses images et indique lesquelles utilisent des scènes préparées.

`docs/QA_REPORT.md` détaille les périmètres ; `docs/CODEX_LEVEL_DESIGN.md` décrit les pièces et systèmes. Les documents `docs/history/` concernent les versions antérieures et ne qualifient pas cette livraison.

{limitations}
'''
(R/'README.md').write_text(readme,encoding='utf-8')
(R/'docs/CHANGELOG_0_5.md').write_text(f'''# Changements — {v}

Base réelle : archive originale 0.4 ; version cumulative, pas une reconstruction depuis une description.

## Ajoutés

12 résidents originaux, routines locales 0/1, apparences/accessoires et deux sujets chacun ; registre Y, préparation de conversation et commande de proximité P. Remplacement des figurants anonymes répétés de l’ancien rendu.

12 réserves avec contenu fini, ouverture discrète ou rapide, fermoir persistant, prise partielle et restrictions de personnage. Trois établis et deux recettes à coûts différés. Poches de composants propres à chaque adulte.

Balises sonores non explosives : délai, pulsations, attraction conditionnelle, priorité aux humains vus, destruction/expiration, débris et persistance. Repères locaux des stations/personnes sur le plan.

## Conservés et vérifiés

16 chapitres / 42 pièces / 57 liens / 49 objectifs / 6 détours / 2 escortes / 30 notes. Les 21 raccords, écoutes, caches, puzzles, armes et deux copies de stockage sont conservés. Registre de sauvegarde life révision 5 ; enveloppe externe schéma 1 inchangée.

## Limites

Les nouvelles personnes sont du gameplay original, pas une attribution au livre. Pas de simulation globale de population ou d’ennemis hors champ. Aucun raccord natif au moteur Tantalus, aucun véhicule pilotable, aucun asset final. Persistance native non qualifiée ; véritables exports/imports JSON éprouvés. Aucun push ni déploiement.
''',encoding='utf-8')
selected=['39-colonist-v05.png','40-conversation-v05.png','41-registre-v05.png','42-fermoir-v05.png','43-reserve-v05.png','44-coffre-ouvert-v05.png','45-etabli-v05.png','46-balise-v05.png','47-plan-local-v05.png','48-etabli-portrait-v05.png','49-reserve-portrait-v05.png','27-montecharge-v04.png']
figures=[]
for i,name in enumerate(selected,1):
 c=caps[name];b=(R/c['file']).read_bytes();portrait=' portrait' if 'portrait' in name else ''
 figures.append(f'''<figure id="capture-{i}" class="{portrait}"><img src="data:image/png;base64,{base64.b64encode(b).decode()}" alt="{escape(c['description'])}"><figcaption><b>{i:02d} / {escape(c['description'])}</b><details><summary>Préparation et provenance</summary><p>{escape(c['setup'])}</p><code>{escape(c['file'])}</code><small>SHA-256 : {hashlib.sha256(b).hexdigest()}</small></details></figcaption></figure>''')
css='''*{box-sizing:border-box}body{margin:0;background:#091a21;color:#c6d3ca;font:16px/1.75 Arial,Helvetica,sans-serif}main{max-width:1180px;margin:auto;padding:48px 30px 70px}header{border-bottom:1px solid #4e6b64;padding:18px 0 38px}.eyebrow,.tag{font:11px/1.6 monospace;letter-spacing:.16em;color:#a7bfad}h1{font-size:clamp(38px,6.5vw,78px);font-weight:400;line-height:1.05;letter-spacing:.055em;color:#e0e5d2;margin:28px 0}h2{font-size:29px;font-weight:400;color:#e3e5cd;margin-top:56px;line-height:1.25}h3{color:#d6ddc8;font-size:20px;font-weight:400}.subtitle{font-size:22px}.tag{display:inline-block;border:1px solid #608277;padding:8px 12px}nav{display:flex;gap:18px;flex-wrap:wrap;padding:22px 0}a{color:#c8d4b7;text-decoration:none;border-bottom:1px solid #6c8d7b}a:hover{color:#fff}p{max-width:960px}.notice{padding:22px 25px;border-left:3px solid #bdb58a;background:#162c32}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin:30px 0}.metrics article{padding:22px;border-top:1px solid #648579;background:#122930}.metrics b{display:block;font:38px monospace;color:#dfe4c5}.metrics span{display:block;font:11px monospace;margin-top:9px;letter-spacing:.1em;color:#9eb7aa}.grid{display:grid;grid-template-columns:1fr 1fr;gap:30px}.grid article{padding:8px 0}.table-wrap{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;vertical-align:top;border-bottom:1px solid #355953;padding:14px 12px}th{font:11px monospace;color:#afc3ac;letter-spacing:.1em}figure{margin:32px 0;border:1px solid #385b58;background:#10292f}figure img{display:block;width:100%;height:auto}figcaption{padding:20px 24px;font-size:14px}figcaption b{font-weight:400;color:#e2e5cd}details{margin-top:10px;color:#9db8ab;font-size:12px}summary{cursor:pointer;letter-spacing:.05em}code,small{display:block;overflow-wrap:anywhere;font-size:10px}.portrait{max-width:420px;margin-left:auto;margin-right:auto}footer{border-top:1px solid #3f615b;margin-top:50px;padding-top:30px;font-size:13px;color:#8fab9f}@media(max-width:660px){main{padding:22px 18px 50px}.metrics{grid-template-columns:1fr 1fr;gap:10px}.metrics article{padding:16px}.grid{grid-template-columns:1fr;gap:10px}h2{font-size:25px}th,td{padding:11px 7px;font-size:12px}figcaption{padding:15px}}'''
html=f'''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fleuve de la Douleur — Rapport v0.5</title><style>{css}</style></head><body><main><header><p class="eyebrow">ALIENS / TANTALUS FRONTIER / LIVRAISON LOCALE · 29 SEPTEMBRE 2026</p><h1>CEUX QUI<br>HABITAIENT ICI</h1><p class="subtitle">Alien — Fleuve de la Douleur</p><span class="tag">{v.upper()}</span></header><nav aria-label="Documents de livraison"><a href="JOUER.html">JOUER</a><a href="docs/CODEX_LEVEL_DESIGN.md">CODEX DES PIÈCES</a><a href="docs/QA_REPORT.md">QUALIFICATION</a><a href="README.md">INSTALLATION</a></nav><p class="notice"><strong>Une suite jouable de la 0.4, toujours autonome.</strong> Les lieux et la campagne sont conservés. Cette passe ajoute des personnes de service, des réserves finies et une diversion que l’on assemble et pose physiquement. Pas de remplacement du moteur hôte ni d’assets définitifs.</p><div class="metrics"><article><b>12</b><span>RÉSIDENTS ORIGINAUX</span></article><article><b>24</b><span>SUJETS À DEMANDER</span></article><article><b>12</b><span>RÉSERVES FINIES</span></article><article><b>3</b><span>ÉTABLIS ACTIFS</span></article></div><h2>Ce qui change dans le niveau</h2><section class="grid"><article><p class="eyebrow">RENCONTRER</p><h3>Des postes, des noms, des souvenirs</h3><p>Les résidents marchent, attendent, se tournent vers le joueur et se retirent après un bruit important. E ou P engage un échange à proximité. Les réponses demandées restent dans Y, sans suivi magique de leur position.</p><p><strong>Routines locales avant l’effondrement.</strong> Pas de simulation globale de population, de morts ou d’évacuations supplémentaires.</p></article><article><p class="eyebrow">FOUILLER</p><h3>Le contenu ne revient pas</h3><p>Une ouverture discrète prend 3,2 secondes ; forcer demande 1,05 seconde mais fait du bruit. La manipulation reste exposée. Le couvercle ouvert, les ressources récupérées et les surplus sont conservés.</p><p>Les prises respectent les capacités et les restrictions de Newt ou d’Anne.</p></article><article><p class="eyebrow">ASSEMBLER</p><h3>Un coût seulement après réussite</h3><p>Une pile, un fil et un boîtier donnent une balise sonore après 2,4 secondes sur un établi. Une pile peut aussi recharger la lampe. Un mouvement ou une blessure interrompt le travail sans détruire les composants.</p><p>Les poches restent propres à chaque adulte. Newt n’utilise pas ces outils.</p></article><article><p class="eyebrow">DÉTOURNER</p><h3>Faire chercher ailleurs, pas effacer la menace</h3><p>La balise posée avec K attend trois secondes puis émet douze secondes. Une créature ayant perdu sa cible peut chercher les bips ; une personne visible reste prioritaire. La créature peut briser la balise.</p><p>Aucune explosion, aucun dégât de zone et aucune attraction à travers toute la colonie.</p></article></section><h2>Le socle conservé</h2><div class="table-wrap"><table><thead><tr><th>CONTENU</th><th>VERSION 0.5</th><th>DISTINCTION</th></tr></thead><tbody><tr><td>Campagne</td><td>16 chapitres / 49 objectifs / 2 escortes</td><td>Les conversations n’ajoutent pas de faux objectifs</td></tr><tr><td>Exploration</td><td>42 pièces / 57 liens / 6 détours</td><td>Pas de téléportation de menu</td></tr><tr><td>Passages</td><td>21 raccords temporisés</td><td>Pas un puits vertical continu</td></tr><tr><td>Décor hérité</td><td>489 placements / 118 ajouts de crise</td><td>Pas autant de sprites uniques</td></tr><tr><td>Archives</td><td>30 notes + 24 sujets séparés</td><td>Textes originaux de gameplay</td></tr><tr><td>Codex</td><td>{len(codex.splitlines())} lignes</td><td>Pièces, stations, routines, sauvegardes et limites</td></tr></tbody></table></div><h2>Captures réelles du jeu</h2><p>Les scènes ciblées sont préparées par sauvegardes validées puis importées via l’interface. Les actions montrées sont celles du runtime, pas du concept art ni une partie entière jouée manuellement. Les coffres et balises font aussi l’objet de véritables exports téléchargés et réimportés.</p>{''.join(figures)}<h2>Résultats exécutés</h2><div class="table-wrap"><table><thead><tr><th>RECETTE</th><th>RÉSULTAT</th><th>PORTÉE</th></tr></thead><tbody><tr><td>Modèle et stockage abstrait</td><td>{model}/{model}</td><td>Dont {num('LIFE_TEST_RESULTS')} nouveaux cas de vie coloniale</td></tr><tr><td>Parcours complets</td><td>18/18</td><td>Principaux, avec détours, puis avec tour de vie coloniale</td></tr><tr><td>Installateur</td><td>{num('INSTALLER_TEST_RESULTS')}/{num('INSTALLER_TEST_RESULTS')} + {num('REAL_UPGRADE_TEST_RESULTS')}/{num('REAL_UPGRADE_TEST_RESULTS')}</td><td>Shells de test ; vrais fichiers 0.4 pour la montée de version</td></tr><tr><td>Navigateur</td><td>{browser}/{browser}</td><td>Chromium ; aucune erreur JavaScript relevée</td></tr></tbody></table></div><p>Le pilote de vie coloniale rencontre les 12 personnes, lit 24 sujets, ouvre 12 réserves et assemble/pose trois balises avant de terminer le parcours principal et les détours. Il connaît les itinéraires. L’attraction ennemie est qualifiée séparément, pas attribuée à ce tour précoce. Ces essais ne certifient pas une durée ou une difficulté humaine. {len(caps)} captures sont fournies ; {len(selected)} sont présentées ici.</p><p class="notice"><strong>Stockage réel non certifié.</strong> L’URL HTTP locale a de nouveau été bloquée. Le HTML exact a été exécuté dans l’origine opaque autorisée, sans contourner la politique du navigateur. Le protocole des deux copies est testé en mémoire simulée ; les imports/exports JSON réels sont vérifiés, notamment pour les quatre anciennes versions, le coffre et la balise.</p><footer>{escape(limitations)}<p>Le commit hôte des métadonnées est hérité, pas une nouvelle vérification du dépôt. Aucun service distant n’a été modifié. Les empreintes de CHECKSUMS.sha256 et DELIVERY_MANIFEST.json identifient les octets livrés.</p></footer></main></body></html>'''
(R/'RAPPORT_ILLUSTRE.html').write_text(html,encoding='utf-8')
(R/'docs/DOCUMENTATION_BUILD.json').write_text(json.dumps({'version':v,'modelCases':model,'browserCases':browser,'capturedImages':len(caps),'illustratedImages':len(selected),'codexLines':len(codex.splitlines()),'connectors':dict(by_kind),'newResidents':12,'newContainers':12,'newBenches':3,'fullTraversals':18,'source':'CONTENT_MANIFEST and current completed reports'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'version':v,'model':model,'browser':browser,'captures':len(caps),'codexLines':len(codex.splitlines())},ensure_ascii=False))
