## Périmètre de la passe 0.5

La version 0.5 prolonge la 0.4 : 16 chapitres, 42 pièces, 57 connexions bidirectionnelles, 49 objectifs principaux et six détours de trois étapes. Aucun nouveau chapitre ou lieu n’est artificiellement compté. Les 489 placements de props, 118 éléments de crise, 62 obstacles, 24 cachettes, six tableaux, deux jets et 30 notes restent distincts des nouvelles stations et personnes. Un placement n’est pas un sprite unique.

La nouveauté tient à 12 résidents originaux, 24 sujets de conversation, 12 réserves finies, trois établis et deux recettes. Les résidents remplacent les silhouettes anonymes répétées de l’ancien rendu ; les personnages associés aux objectifs scénaristiques sont conservés. Les stations interactives et accessoires des habitants sont dessinés par code dans le même passage de rendu trié en profondeur. Ils ne sont pas des atlas définitifs ni 12 personnalités issues du roman.

## Résidents : ce que la routine simule réellement

Chaque personne possède un nom, un métier, une silhouette, un accessoire de poste, trois points de routine, une attente, un sens de marche et un point de retrait. Les routines existent aux stades 0 et 1 uniquement, dans la pièce actuellement simulée. Elles sont interrompues au stade 2. L’absence ultérieure d’une personne n’est pas une preuve de mort ou d’évacuation et ne change pas la chronologie de Newt ou des personnages du roman.

Une personne se déplace le long d’un trajet horizontal à profondeur fixe. Elle s’arrête lorsque le joueur s’approche et lui fait face. Un bruit important du joueur à proximité la fait gagner son point de retrait et se baisser. Les résidents ne forment pas une population autonome simulée dans tout le graphe ; ils ne traversent pas les portes, n’ont pas d’inventaire dérobable, de santé de combat ou de nouvelle quête d’évacuation. Ils ne bloquent pas la marche du joueur. Ces limites évitent de faire passer une scène d’ambiance pour une simulation complète de survivants.

Leur état local est conservé. Changer de pièce ne les fait pas avancer hors champ. Au changement de stade encore autorisé, leur routine est réinitialisée sur son premier appui. Le dialogue d’introduction change entre le calme et les premiers incidents ; les deux sujets utiles restent relisibles.

## Converser : proximité, interruption et registre

E lance l’échange quand la personne est l’interaction prioritaire. P sélectionne explicitement la personne proche, sans franchir une porte qui se trouverait aussi à portée. Le registre Y fournit la même action avec un bouton PARLER lorsqu’une personne est à proximité. Il ne permet jamais un dialogue à distance.

L’approche engage une préparation de 0,85 seconde dans le monde. Le joueur doit être calme ; une menace visible trop proche ou une personne en alarme interdit le démarrage. Le déplacement, une blessure ou la perte des conditions de calme interrompt la préparation. Une fois la conversation ouverte, sa lecture met la simulation en pause, comme les autres dossiers du DLC. Ce n’est pas une conversation en combat temps réel.

Les deux boutons de sujet enregistrent uniquement les réponses effectivement demandées. Le registre conserve la pièce, le stade et l’instant du dernier échange. Sa relecture ne suit pas la personne en direct, ne crée pas une rencontre, ne valide aucun objectif et n’augmente pas les 30 notes de campagne. Les 24 sujets sont comptés séparément. Les textes sont des créations originales de gameplay ; aucun passage du roman n’est reproduit.

## Réserves : ouvrir, prendre ou laisser

Douze contenants ont une identité stable et un contenu fini, commun aux quatre points de vue. Avant ouverture, E propose deux méthodes. OUVRIR DOUCEMENT dure 3,2 secondes et maintient un bruit faible ; FORCER LE FERMOIR dure 1,05 seconde et produit un bruit élevé. Le choix se lit en pause, puis le travail s’exécute dans le monde exposé. Un déplacement ou une blessure annule l’ouverture ; le contenu reste intact.

Le fermoir ouvert est persistant et visible sur le casier, la mallette ou le tiroir. E ouvre ensuite la liste de contenu. Une collecte partielle laisse le surplus ; une ligne épuisée reste épuisée en changeant de pièce ou de personnage. Rien n’est ajouté automatiquement au simple passage près d’un meuble. Une réserve vide reste présente dans le niveau.

Les piles, fils, boîtiers et balises restent dans les poches propres à chaque adulte. Les plafonds sont six piles, six fils, quatre boîtiers et deux balises emportées. Les réserves de munitions sont plafonnées à 150 lors de la prise, les trousses à huit et les fusées à huit. Un surplus n’est pas détruit. Anne ne prend pas les munitions. Newt ne récupère ni composants de bricolage, ni munitions, ni fusées ou balises sonores ; les portions froides lui sont autorisées.

Une portion froide est consommée sur place pour restaurer au maximum 25 points d’état, sans dépasser 100. Elle n’est pas gaspillée à pleine santé et ne devient pas un système de faim. La liste d’objets se consulte en pause, comme le reste de l’équipement. Ces ressources sont une économie de prototype, non une quantité certifiée du roman.

## Établis et coûts différés

Trois établis accueillent les adultes à portée physique. La recette de balise consomme une pile, un fil et un boîtier après 2,4 secondes de travail. La recette de recharge utilise une pile après 1,6 seconde pour ajouter au plus 45 points de lampe. L’ancienne récupération lente de batterie lampe éteinte reste active ; une pile apporte une recharge immédiate supplémentaire, pas le seul moyen de retrouver de la lumière.

Les boutons désactivés indiquent les composants manquants, la capacité atteinte, la lampe pleine ou l’interdiction propre à Newt. Les coûts sont vérifiés au début et à la fin. Les composants ne sont débités qu’après réussite. Un déplacement ou une blessure annule la manœuvre sans débiter de matériel.

Comme les anciennes tâches manuelles, une fouille ou un assemblage en cours n’est pas repris à mi-course après un import : le travail est annulé et les composants sont encore là. Il faut recommencer la manœuvre. Cela se distingue des raccords engagés de la 0.4, qui reprennent leur minuterie.

## Balise sonore : un leurre local non explosif

K ou la tuile d’équipement pose une balise aux pieds du personnage. L’action consomme une balise emportée ; deux seulement peuvent être actives simultanément dans le graphe. Elle demande trois secondes d’armement, puis émet durant douze secondes, avec un bip toutes les 1,5 seconde. Il faut s’éloigner avant le premier signal.

Une créature dans la pièce courante peut retenir la position d’un bip si elle a perdu le joueur. La portée interne vaut 700 unités sans obstruction et 385 à travers les obstacles concernés. Ce n’est pas une simulation acoustique scientifique. Le son ne recrute pas une créature dans une autre pièce et ne livre pas la position d’un adversaire hors champ au joueur.

Une cible humaine visible, un compagnon exposé ou une entrée en cachette observée reste prioritaire : le bip n’efface pas magiquement un contact visuel. Une créature arrivée à portée de la balise pendant un bip peut la détruire. Elle n’explose pas et ne cause pas de dégâts de zone. L’expiration laisse un boîtier éteint ; la destruction laisse un débris. Les huit derniers boîtiers restent dessinés. Ni l’un ni l’autre ne rend les composants.

Les minuteries des balises avancent aussi hors champ et pendant un raccord engagé, mais les créatures hors champ ne sont pas simulées en continu. Les menus mettent ces minuteries en pause. Un export et un import conservent le propriétaire, le délai et les secondes restantes sans double prélèvement. Le passage à la présentation classique aligne la profondeur physique de la balise sur celle du plan de jeu.

## Rendu, plan et priorité d’interaction

Les stations, personnes et boîtiers font partie du tri des acteurs ; les objets de fond ne deviennent pas des aplats au-dessus du joueur. La réserve peut afficher un fermoir fermé, un couvercle ouvert avec contenu ou un état épuisé. Le plan local ajoute les repères C pour les réserves et A pour les établis, ainsi que les habitants et balises présents dans la pièce. Le registre de contacts n’est pas une carte de suivi.

Les stations sont des points d’interaction non collisionnables, pas quinze nouvelles couvertures physiques. Les 62 obstacles restent la référence de collision du terrain. Une station ne bloque pas une route de campagne ; elle doit rester suffisamment séparée des actions existantes pour que E n’intercepte pas une sortie. La commande P est la sélection explicite du résident lorsque plusieurs usages sont proches. Un accès interdit n’est pas prioritaire sur une action utilisable.

La vue latérale projette les interactions sur z = 0,7. Les routines ont un trajet horizontal compatible avec ce mode. Les sprites et portraits restent stylisés et provisoires ; la silhouette artistique ne constitue pas une validation de collision pixel par pixel. Le rapport utilise uniquement des captures du moteur, avec provenance des fixtures affichée.

## Persistance et migration

Le format externe de campagne reste `river-of-pain`, schéma 1. Le registre `life.revision = 5` ajoute routines, contacts, contenus restants, poches, balises, débris et statistiques. Les vraies sauvegardes 0.1 à 0.4 reçoivent des registres vides, sans inventer des échanges passés ni du matériel. Les anciens points de contrôle migrent aussi. Une reprise après mort restaure le point de contrôle : une collecte effectuée après celui-ci n’est pas conservée arbitrairement.

Les identifiants inconnus, thèmes dupliqués, inventaires hors capacité, contenu incohérent d’un coffre fermé, propriétaires interdits ou minuteries impossibles sont rejetés. Cette validation et la somme de contrôle locale visent la robustesse du prototype, pas un système antitriche multijoueur.

Les deux copies locales alternées, leur validation et la clé héritée sont conservées. Leur protocole est éprouvé avec un stockage mémoire simulé. L’environnement de cette passe a de nouveau refusé l’URL HTTP locale avec `ERR_BLOCKED_BY_ADMINISTRATOR`. Le HTML exact a été exécuté par `set_content`, sans contourner cette politique ni changer l’origine. La persistance native après fermeture, le mode privé, les quotas réels et les onglets concurrents restent non qualifiés. En revanche, les véritables téléchargements/imports JSON d’un coffre partiellement vidé et d’une balise en armement sont testés.

## Systèmes hérités et limites maintenues

Les 21 liaisons temporisées conservent une préparation exposée puis un raccord animé borné. Le combat normal est suspendu pendant le trajet engagé ; ce n’est pas un puits ou un escalier librement exploratoire. Les deux liaisons de monte-charge ont un secours plus lent sur circuit coupé. Les véhicules ne sont pas pilotables.

L’écoute N dure 1,6 seconde sans pause et O ouvre les douze derniers relevés. Le détecteur marine peut lire un écho au-delà d’un accès proche, sans position exacte dans toute la colonie. Les 24 cachettes ne rendent pas invincible ; une entrée observée peut trahir le personnage. Les six tableaux et les deux jets conservent leurs conséquences locales, pas une simulation industrielle scientifique.

Les deux escortes gardent santé, tension, suivre/attendre et soins partagés. Leur mort échoue la tentative. Les soudures sous pression peuvent céder. La mémoire ennemie conserve la dernière position perçue, pas une connaissance omnisciente d’une position silencieuse. La visée profonde couvre huit directions du sol, pas un axe vertical de plafond.

Les trois intrusions annoncées et trois ambiances restent en place. Les nouveaux résidents n’ajoutent ni sauvetage de Newt, ni mort de reine, ni secours extérieur réussi. L’écho Frontière 2204, le catalogue et les sauvegardes du moteur natif ne sont pas touchés.

## Portée des essais

Les suites du modèle vérifient des fixtures locales explicites, plus 18 parcours automatisés depuis une nouvelle partie : six principaux, six avec détours, six avec détours et le tour de vie coloniale. Le dernier pilote rencontre les douze adultes de service avant la crise, lit 24 sujets, ouvre 12 réserves, fabrique puis pose trois balises aux trois établis et termine le parcours principal. Le coffre des conduits est ouvert par Newt. Aucun soin, objectif ou lieu n’est téléporté ou forcé par ce pilote ; il emploie les commandes de jeu et connaît déjà les routes.

Les trois balises du tour de colonie sont assemblées tôt, dans le calme. Leur attraction et leur destruction par une créature sont éprouvées séparément dans les fixtures du modèle et du navigateur. Ne pas prétendre que le pilote humain a joué ces rencontres ni que ces tours optimisés prouvent l’équilibrage d’une découverte tardive. Les captures de scènes préparées sont signalées ; aucune durée de campagne humaine n’est annoncée.
