# Qualification locale — 0.5.0-candidate.1

Ces résultats correspondent aux suites achevées sur cette version. Les comptes des versions archivées dans `history/` ne sont pas additionnés. Les cas du modèle et les observations navigateur sont des assertions ou groupes, pas autant de sessions humaines.

| Suite | Réussite | Portée réelle |
|---|---:|---|
| core.cjs | 96/96 | État, progression, collisions, codec et interactions héritées |
| colony.cjs | 75/75 | Tableaux, caches, batterie, soudures, escortes |
| exploration.cjs | 149/149 | Géométrie des 42 pièces, détours, visée et mémoire |
| passages.cjs | 118/118 | 84 franchissements orientés, annulations, écoute, détecteur et migrations |
| persistence.cjs | 18/18 | Stockage mémoire simulé : double copie, intégrité, erreurs de quota et refus d’écrasement |
| life.cjs | 141/141 | Résidents, 24 thèmes, contenants, recettes, balises, limites de personnage et refus d’imports incohérents |
| traversal.cjs | 6/6 | Campagne principale, deux vues × trois difficultés |
| traversal-exploration.cjs | 6/6 | Même campagne avec six détours et leurs passages aller/retour |
| traversal-life.cjs | 6/6 | Campagne, détours, 12 résidents, 24 sujets, 12 réserves, trois fabrications et trois poses |
| installer.mjs | 28/28 | Projets hôtes de test, conflits, restauration et mises à niveau simulées |
| upgrade-real.mjs | 4/4 | Vrais fichiers/installateur 0.4, puis payload 0.5 et restauration sur un shell hôte de test |
| browser.py | 16/16 | Début au clavier, export réel, mouvement, menus et tactile émulé |
| browser-v02.py | 17/17 | Régression des systèmes de survie et véritable export 0.1 |
| browser-v03.py | 27/27 | Régression des détours, cartes et visée ; véritable export 0.2 |
| browser-v04.py | 28/28 | Raccords, écoute, détecteur et véritable export 0.3 |
| browser-v05.py | 29/29 | Conversations, réserves, assemblage, diversion, vrai export 0.4 et exports actuels coffre/balise |

**Modèle : 597/597. Navigateur : 117/117, aucune erreur JavaScript relevée.** Les 18 parcours sont comptés séparément. 49 captures actuelles sont décrites par les JSON des cinq recettes navigateur.

## Méthode et limites des parcours

Les pilotes démarrent une nouvelle partie et utilisent les déplacements via `Simulation.update`, les interactions, les commandes de jeu, les soins disponibles et les solutions des tableaux. Ils n’appellent pas la validation forcée des objectifs, ne téléportent pas le personnage et ne réécrivent pas sa santé. Le rétablissement de santé entre chapitres et les ressources prévus par le jeu restent actifs.

Les six parcours de vie coloniale visitent les douze résidents pendant la période calme, lisent les 24 sujets, ouvrent onze réserves avec un adulte puis la boîte des conduits avec Newt, fabriquent et posent une balise sur chacun des trois établis, terminent les six détours et les 49 objectifs avec les deux escortes. Les minuteries des balises sont laissées aller jusqu’à leur expiration. Ce tour précoce ne prouve pas l’équilibrage d’une découverte tardive ni l’utilité tactique de chaque réserve sous attaque.

L’attraction et la destruction d’une balise sont éprouvées séparément dans des fixtures locales où la créature et le leurre sont préparés explicitement. Les tests de priorité confirment qu’un joueur vu n’est pas oublié au profit du bip. Aucune simulation acoustique scientifique ni IA globale de type Alien: Isolation n’est revendiquée.

## Navigateur et captures

Le CLI agent-browser est absent. Une nouvelle tentative HTTP locale a renvoyé `net::ERR_BLOCKED_BY_ADMINISTRATOR` ; le fichier HTML autonome exact est donc chargé avec Playwright `set_content`, dans l’origine opaque autorisée, sans modification des politiques de sécurité. Les captures viennent de Chromium exécutant réellement le moteur, pas d’images d’intention.

Les premières scènes emploient les commandes du menu et le clavier. Les scènes tardives ou ciblées chargent des sauvegardes préparées, validées et importées par le sélecteur de fichier ordinaire. Chaque capture du rapport indique sa méthode d’initialisation. Une scène de fixture ne constitue pas une scène nouvellement authentifiée du roman ni une partie entière jouée manuellement.

Le véritable export d’un coffre ouvert puis partiellement vidé est téléchargé et relu : l’objet récupéré ne revient pas et le surplus est conservé. Un autre vrai fichier exporté après fabrication et pose reprend la balise pendant son armement, sans double prélèvement. Les contrôles portrait sont des émulations Chromium, pas des tests de matériel téléphonique ou de Safari/iPhone.

## Persistance : ne pas confondre protocole et stockage natif

Les deux emplacements alternés sont testés avec `MemoryStorage` explicitement simulé. Leur robustesse face à une chaîne tronquée ou une exception ne certifie pas localStorage après fermeture, les quotas réels, le mode privé ou plusieurs onglets concurrents. Ces périmètres restent non qualifiés. Les véritables imports et exports JSON sont, eux, vérifiés dans le navigateur.

Les fichiers `real-v01-save.json` à `real-v04-save.json` sont des exports réels des anciennes livraisons. Ils ne sont pas des états récents simplement renommés. Leur provenance est décrite dans les rapports d’historique et dans les sources de chaque test. Le codec initialise la vie coloniale sans attribuer de contacts, de coffres ouverts ou de composants antérieurs fictifs.

## Corrections issues de la recette

Deux réserves proches de l’appui initial d’un résident ont été séparées lors de l’export du contenu. Les interactions inutilisables n’éclipsent plus un résident accessible. La commande P et son équivalent dans le registre permettent de parler près d’une porte valide sans déclencher le franchissement. La profondeur des balises se replie réellement vers z = 0,7 lors du passage au mode classique. La recette d’équipement attend maintenant les sept actions réellement présentes, tout en conservant les six anciennes.

## Limites de production maintenues

Résidents locaux aux stades 0/1, pas population simulée dans toute la colonie, pas système de mort/évacuation des nouveaux civils. Stations de fouille non collisionnables, distinctes des 62 obstacles. Raccords bornés, pas axe vertical continu ni véhicule pilotable. Aucune certification de manette physique, multijoueur, difficulté humaine, durée de campagne ou bande-son définitive.

DLC autonome avec lanceur additionnel, pas le jeu Tantalus complet ni son GameEngine natif. Aucun push GitHub ni déploiement Vercel. Dessins stylisés par code, pas atlas définitifs ou reconstitution 1:1. Roman intégral non consulté : plans, dialogues, tâches et documents sont une condensation originale. L’écho Frontière 2204 et les sauvegardes du moteur hôte ne sont pas modifiés.
