# Changements — 0.5.0-candidate.1

Base réelle : archive originale 0.4 ; version cumulative, pas une reconstruction depuis une description.

## Ajoutés

12 résidents originaux, routines locales 0/1, apparences/accessoires et deux sujets chacun ; registre Y, préparation de conversation et commande de proximité P. Remplacement des figurants anonymes répétés de l’ancien rendu.

12 réserves avec contenu fini, ouverture discrète ou rapide, fermoir persistant, prise partielle et restrictions de personnage. Trois établis et deux recettes à coûts différés. Poches de composants propres à chaque adulte.

Balises sonores non explosives : délai, pulsations, attraction conditionnelle, priorité aux humains vus, destruction/expiration, débris et persistance. Repères locaux des stations/personnes sur le plan.

## Conservés et vérifiés

16 chapitres / 42 pièces / 57 liens / 49 objectifs / 6 détours / 2 escortes / 30 notes. Les 21 raccords, écoutes, caches, puzzles, armes et deux copies de stockage sont conservés. Registre de sauvegarde life révision 5 ; enveloppe externe schéma 1 inchangée.

## Limites

Les nouvelles personnes sont du gameplay original, pas une attribution au livre. Pas de simulation globale de population ou d’ennemis hors champ. Aucun raccord natif au moteur Tantalus, aucun véhicule pilotable, aucun asset final. Persistance native non qualifiée ; véritables exports/imports JSON éprouvés. Aucun push ni déploiement.
