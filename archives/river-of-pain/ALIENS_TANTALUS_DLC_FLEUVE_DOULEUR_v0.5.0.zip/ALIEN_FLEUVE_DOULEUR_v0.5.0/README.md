# ALIEN — Fleuve de la Douleur · 0.5.0-candidate.1

## Ceux qui habitaient ici

Cette archive cumulative poursuit la 0.4. Elle contient le DLC autonome jouable, les sources modulaires, le codex pièce par pièce, les tests et les captures. **Ce n’est pas le jeu Tantalus complet ni une intégration au GameEngine natif.**

### Jouer

Ouvrez `JOUER.html` dans un navigateur de bureau. Le fichier est autonome, sans téléchargement d’assets. `LANCER_WINDOWS.bat` ouvre ce fichier sous Windows. Le dossier `src/river-of-pain/index.html` est l’entrée modulaire alternative ; il n’est pas nécessaire pour le fichier autonome.

L’accès à une sauvegarde locale dépend du navigateur et de l’origine du fichier. Exportez un JSON avec Pause → EXPORTER pour garder une copie transportable. La persistance native après fermeture reste non qualifiée dans l’environnement de test.

### Reprendre la 0.1, 0.2, 0.3 ou 0.4

Dans l’ancienne version : Pause → EXPORTER. Dans celle-ci : Pause → IMPORTER, choisissez le fichier et confirmez CHARGER. Les quatre véritables fichiers historiques ont été testés. Les rencontres de résidents et composants commencent vides ; votre progression principale n’est pas réinventée.

Les exports conservent coffres ouverts, surplus, sujets lus, poches et balises. Une fouille ou fabrication inachevée est annulée à l’import sans consommer de composants ; recommencez-la. Un raccord de la 0.4 déjà engagé reprend, lui, son temps restant.

### Nouveautés réellement jouables

Douze habitants originaux avec routine locale avant l’effondrement, deux sujets chacun et registre des rencontres. Douze contenants à ouverture lente/discrète ou rapide/bruyante, couvercle persistant et ressources finies. Trois établis : balise sonore ou recharge de lampe. Les balises sont non explosives, posées au sol, avec trois secondes d’armement et douze de bips ; une créature qui a perdu sa cible peut les chercher puis les détruire. Les victimes visibles restent prioritaires.

Les 42 pièces, 16 chapitres, 49 objectifs principaux, deux escortes, six détours, 21 raccords, 24 cachettes et 30 notes sont conservés. Les 24 sujets de résidents sont séparés du compteur de notes. Les nouveaux habitants ne sont pas des personnages attribués au roman.

### Commandes

| Action | Commande |
|---|---|
| Marcher et profondeur | Q/D et Z/S ; A/D et W/S ; flèches |
| Interagir avec le point prioritaire | E |
| Parler explicitement à un résident proche | P ; ou COLONIE → PARLER |
| Registre des personnes rencontrées | Y ou COLONIE |
| Poser une balise sonore | K ; ou ÉQUIPEMENT → Balise sonore |
| Tirer, recharger | F, R ; pointeur maintenu pour viser/tirer |
| Visée fixe | Espace + directions |
| Se baisser, courir | C, Maj |
| Soins, fusée, soudure | H, X, B |
| Lampe, détecteur, cachette | L, T, G |
| Plan, carnet, équipement, détours | Tab, J, I, U |
| Écouter, dossier de seuils | N, O |
| Suivre/attendre, repère de repli | V, M |
| Pause | Échap |

Newt ne tire pas, ne soude pas, ne prend pas de composants de bricolage et ne pose pas de balise sonore. Anne ne possède pas d’arme. Les fenêtres de lecture mettent le jeu en pause ; les ouvertures et fabrications se font ensuite en temps réel.

### Installation facultative du lanceur Tantalus

```sh
node tools/install.mjs /chemin/vers/aliens-tantalus-frontier
# Depuis une ancienne installation reconnue et intacte :
node tools/install.mjs /chemin/vers/aliens-tantalus-frontier --upgrade
# Restaurer l’index initial :
node tools/install.mjs /chemin/vers/aliens-tantalus-frontier --remove
```

L’installateur ajoute un répertoire et un accès au menu/archives. Il ne remplace ni le moteur natif, ni le catalogue, ni les sauvegardes de Tantalus. Les fichiers touchés sont vérifiés ; une modification personnelle ou un conflit provoque un refus. La vraie montée 0.4 → 0.5 a été testée avec les modules des deux archives sur un shell hôte de test, pas sur le dépôt complet. Aucun push ni déploiement.

### Reproduire les vérifications

Node.js 20+ et Python 3 suffisent aux tests du modèle et à la reconstruction. Les scripts navigateur demandent Playwright et Chromium. Le chemin par défaut est `/usr/bin/chromium` ; utilisez `CHROMIUM_PATH` sur un autre système. Aucun téléphone ou contrôleur physique n’est simulé comme réellement testé.

```sh
npm run build
npm test
npm run test:life-traversal
node tests/upgrade-real.mjs /chemin/vers/la/0.4.0/originale
npm run test:browser
npm run docs
npm run test:report
python tools/verify-delivery.py
python tools/package-release.py
```

Les scripts de publication ne contactent aucun service distant : `package-release.py` produit seulement un ZIP local. Les deux installations antérieures intactes restent séparées pendant la recette de montée de version.

### Résultats et limites

597 tests/groupes du modèle, 18 parcours automatisés, 28 cas d’installation sur fixtures et 4 sur vrais payloads, 117 contrôles navigateur. Les pilotes connaissent les solutions ; aucune durée humaine ni difficulté commerciale n’est certifiée. Le rapport incorpore ses images et indique lesquelles utilisent des scènes préparées.

`docs/QA_REPORT.md` détaille les périmètres ; `docs/CODEX_LEVEL_DESIGN.md` décrit les pièces et systèmes. Les documents `docs/history/` concernent les versions antérieures et ne qualifient pas cette livraison.

DLC autonome avec lanceur additionnel, pas le jeu Tantalus complet ni son GameEngine natif. Aucun push GitHub ni déploiement Vercel. Dessins stylisés par code, pas atlas définitifs ou reconstitution 1:1. Roman intégral non consulté : plans, dialogues, tâches et documents sont une condensation originale. L’écho Frontière 2204 et les sauvegardes du moteur hôte ne sont pas modifiés.
