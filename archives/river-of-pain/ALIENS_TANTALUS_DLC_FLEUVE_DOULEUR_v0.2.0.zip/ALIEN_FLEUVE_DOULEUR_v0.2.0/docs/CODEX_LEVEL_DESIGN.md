# ALIEN — Fleuve de la Douleur

## Codex de level design · 0.2.0-candidate.1

Hadley’s Hope — Les réseaux se brisent

Cette version reste un moteur autonome avec lanceur additionnel. Le moteur natif de Tantalus, ses atlas, ses sauvegardes et l’écho Frontière 2204 ne sont pas modifiés. Aucun push GitHub, build du dépôt hôte complet ou déploiement Vercel n’a été effectué. Les décors et personnages sont dessinés par code ; ce ne sont pas des assets finaux ni une reproduction photoréaliste. Le roman intégral n’a pas été consulté. Plans, tâches, dialogues, règles et documents restent une condensation originale, non une adaptation 1:1 certifiée.

## Ce qui change réellement en 0.2

Les quatre tableaux d’alimentation et les deux collecteurs de pression remplacent les anciens simples délais d’action. Chacun possède trois commandes, une consigne, une capacité et une combinaison à respecter. Un mauvais routage ou une surcharge ne valide pas l’objectif. Le temps est suspendu pendant la lecture du tableau ; la manœuvre de 1,4 seconde s’achève ensuite dans le monde et peut être interrompue par un déplacement ou une attaque. Ce sont des puzzles discrets, pas une simulation électrique ou hydraulique scientifique.

Cinq secteurs classent l’alimentation des lieux. Habitat et maintenance passent au secours au stade 2 ; médical et recherche au stade 3 ; le périmètre ne subit pas cette coupure. Un réarmement s’applique au circuit lié à la mission, pour le stade courant. Il modifie la présentation lumineuse, les ventilateurs concernés et la perception ennemie ; une nouvelle phase peut entraîner une nouvelle panne. Une porte n’est pas arbitrairement supprimée par une coupure.

Deux jets de pression périodiques possèdent une position, une profondeur et des dégâts. Ils deviennent inoffensifs après la validation du collecteur associé. La vue latérale projette le risque sur le plan de jeu ; en profondeur, une autre allée permet de l’éviter. Le calendrier de la vapeur est une règle de gameplay.

Dix-huit cachettes utilisent un point d’entrée physique. G ou E fait entrer ; E ou une direction fait ressortir. Lampe, détecteur, tir et fusée sont neutralisés pendant la dissimulation. Un adversaire qui a vu l’entrée à courte distance peut rejoindre la cache et débusquer le joueur. Une cachette n’est donc pas une pause ni une invulnérabilité sous poursuite.

Les deux compagnons d’escorte ont une santé, une tension et un ordre suivre/attendre. Une forte tension ralentit leur marche. Rassurer nécessite la proximité et consomme du souffle ; soigner partage les trousses du joueur. Un compagnon éloigné ou en attente bloque le changement de pièce. Sa mort provoque l’échec et le retour au point de contrôle ; aucune survie historique supplémentaire n’est attribuée à cet indicateur.

Les cloisons soudées retiennent les poursuites et possèdent une intégrité. À partir du stade 2, les poursuivants peuvent éroder la soudure jusqu’à rupture. Sans pression ennemie, elle ne s’use pas toute seule. Les liens sont bidirectionnels. Certaines tâches de scénario ouvrent ou ferment réellement le lien. L’interaction E permet le déverrouillage prévu par le jeu ; les formes et durées de cette opération restent simplifiées. Newt ne peut pas utiliser B pour souder.

Chaque protagoniste conserve ses munitions, trousses, fusées et réserve de lampe entre ses chapitres. Les premières prises de contrôle donnent sa dotation propre. Le début d’un nouveau chapitre rétablit au moins 70 % de santé : il s’agit d’une assistance de progression, pas d’une guérison canonique. Les balises de repli sont communes à cette reconstitution, limitées aux douze dernières et visibles au sol ainsi que sur le plan. Le détecteur des Marines mesure uniquement les créatures vivantes de la pièce courante, pas des contacts à travers tout le graphe.

## Composition et garde-fous

Les 36 lieux restent reliés par 45 connexions bidirectionnelles. Il y a 23 étiquettes de profil architectural, plusieurs utilisant la même famille de rendu : ce ne sont pas 23 moteurs graphiques différents ni 36 illustrations uniques. Le nombre 411 compte des placements de props, pas des dessins uniques. Les 108 ajouts de crise sont des placements conditionnels séparés : papiers, flèches de repli, lampes endommagées et traces de brûlure. Les 18 cachettes sont des objets interactifs, comptés séparément.

Les pièces habitées ont un traitement domestique ; l’infirmerie et les laboratoires des travées vitrées ; les galeries des réseaux de tuyaux ; les hangars des structures de manutention ; la ruche une résine posée sur des appuis industriels. Le haut du cadre est occupé par l’architecture plutôt que par une bande vide. Les vitrages d’observation sont du décor, pas de fausses portes jouables. Les hauteurs et dimensions sont des intentions de blocage originales, non des mesures issues du livre.

Le sol et ses interactions partagent le repère du moteur. Les acteurs sont triés par profondeur. Les couvertures collisionnables demeurent les deux îlots préexistants dans les grandes salles ; leur nature graphique est adaptée au lieu. Les petits accessoires et les décors muraux sont non collisionnables. Certaines correspondances de silhouette et d’emprise demandent encore un travail d’assets final ; cette passe ne certifie pas une collision parfaite pixel par pixel.

Le renderer conserve ses parallaxes de montagnes, structures et premier plan. Les facteurs détaillés dans les métadonnées d’architecture constituent des intentions de production : ils ne sont pas tous des paramètres indépendants reliés au renderer. Les plafonds, vitrages et supports sont générés par les profils de pièce. Les ascenseurs, escaliers et véhicules restent des transitions ou postes d’interaction ; aucune cabine continue ni conduite de véhicule n’est ajoutée.

Le HUD reste au-dessus de la bande principale de marche. Le plan, l’équipement, le carnet et les tableaux suspendent la simulation. Le champ de jeu n’est pas remplacé par une page de boutons. Les raccourcis sont doublés par les menus lorsque possible ; les contrôles tactiles sont éprouvés par émulation, pas sur un téléphone physique. La manette matérielle n’est pas qualifiée.

## Coordonnées

`x` est une unité de simulation horizontale ; `z` est une profondeur normalisée, convertie en distance par le modèle. La distance du détecteur emploie une échelle de jeu. Les champs `dimensionsM`, étages et variantes sont des choix de level design, pas un relevé officiel de Hadley’s Hope. Une transition de point de vue entre chapitres n’est pas une téléportation libre du personnage.

## Campagne : tâches réellement définies

### 01 — La relève

**Demian Brackett · Avant la crise · Aire d’atterrissage**

Brackett prend ses fonctions dans une colonie qui ressemble encore à une ville.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Aire d’atterrissage | Retrouver Paris · `talk` | Interaction physique héritée |
| 2 | Contrôle colonial | Consulter le tableau de service · `terminal` | Interaction physique héritée |
| 3 | Poste de la garnison | Prendre la dotation · `supply` | Interaction physique héritée |

Dialogue original : **Paris** — « Vous verrez la tempête plus souvent que le ciel. Les familles, elles, sont ici toute l’année. »

### 02 — Les gens d’ici

**Anne Jorden · Avant la crise · Logement des Jorden**

Anne traverse les lieux ordinaires que la crise rendra bientôt méconnaissables.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Logement des Jorden | Préparer la tournée · `talk` | Interaction physique héritée |
| 2 | Réfectoire | Récupérer les provisions · `supply` | Interaction physique héritée |
| 3 | Distribution électrique | Réarmer le départ habitat · `power` | Tableau à trois commandes |

Dialogue original : **Anne** — « On peut retarder les relevés. Pas le chauffage du bloc. »

### 03 — Sous pression

**Demian Brackett · Avant la crise · Garage des prospecteurs**

Une intervention industrielle expose les tensions de la garnison. Séquence de jeu condensée autour du processeur six.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Garage des prospecteurs | Prendre le matériel de secours · `supply` | Interaction physique héritée |
| 2 | Processeur six | Isoler la conduite endommagée · `valve` | Tableau à trois commandes |
| 3 | Processeur six | Récupérer le rapport d’intervention · `terminal` | Interaction physique héritée |

Dialogue original : **Paris** — « Coupez l’arrivée avant de toucher aux vannes. Ici, une mauvaise décision se propage à tout le réseau. »

### 04 — Les coordonnées

**Anne Jorden · Avant la crise · Bureau des prospecteurs**

La sortie des Jorden rejoint le lieu désigné par la Compagnie. La découverte de Russ est traitée hors champ.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Bureau des prospecteurs | Recevoir la grille de prospection · `terminal` | Interaction physique héritée |
| 2 | Garage des prospecteurs | Préparer le tracteur · `vehicle` | Interaction physique héritée |
| 3 | Plateau des relevés | Poser une balise sur le plateau · `beacon` | Interaction physique héritée |
| 4 | Seuil de l’épave | Examiner le seuil de l’épave · `scan` | Interaction physique héritée |

Dialogue original : **Anne** — « La radio passe mal. Je laisse une balise : personne ne retrouvera cette passe de nuit. »

### 05 — La porte blanche

**Demian Brackett · Premiers incidents · Aire d’atterrissage**

Le retour des prospecteurs met l’infirmerie au centre de toutes les décisions.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Aire d’atterrissage | Prendre en charge le retour des prospecteurs · `talk` | Interaction physique héritée |
| 2 | Chambre d’isolement | Fermer l’isolement médical · `seal` | Lien de cloison modifié |
| 3 | Infirmerie | Transmettre le bilan à Komiskey · `terminal` | Interaction physique héritée |

Dialogue original : **Komiskey** — « Gardez le couloir libre. Je veux des gens qui respirent, pas une foule autour du lit. »

### 06 — Priorité de recherche

**Anne Jorden · Premiers incidents · Infirmerie**

Les priorités médicales et celles de la Compagnie divergent.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Infirmerie | Consulter le registre des patients · `terminal` | Interaction physique héritée |
| 2 | Laboratoire de la Compagnie | Lire la directive scientifique · `terminal` | Interaction physique héritée |
| 3 | Salle des archives | Conserver une copie des échanges · `terminal` | Interaction physique héritée |

Dialogue original : **Anne** — « Ce n’est pas une cargaison. C’est mon mari. »

### 07 — Derrière les grilles

**Rebecca « Newt » Jorden · Premiers incidents · Logement des Jorden**

Les jeux dans les conduits deviennent un apprentissage de la survie. Aucun combat pour Newt.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Conduits de l’habitat | Retrouver les repères de Tim · `trace` | Interaction physique héritée |
| 2 | Conduits de l’infirmerie | Écouter derrière la grille · `listen` | Interaction physique héritée |
| 3 | Cache des conduits | Préparer une petite cache · `stash` | Interaction physique héritée |

Dialogue original : **Newt** — « Le tuyau qui vibre revient vers la cuisine. Celui qui siffle va à l’infirmerie. »

### 08 — Les absents

**Demian Brackett · La colonie se ferme · Contrôle colonial**

Les disparitions ont désormais une géographie. Les itinéraires sûrs commencent à se refermer.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Contrôle colonial | Relever les dernières balises PDT · `terminal` | Interaction physique héritée |
| 2 | Galerie technique | Suivre les traces dans la galerie · `scan` | Interaction physique héritée |
| 3 | Station de pompage | Détourner la pression du passage · `valve` | Tableau à trois commandes |

Dialogue original : **Brackett** — « On marque chaque porte derrière nous. Je refuse de perdre quelqu’un à un embranchement. »

### 09 — Les lumières rouges

**Julisa Paris · La colonie se ferme · Infirmerie**

Paris maintient une route pour les habitants. L’escorte représente une survie locale, pas une évacuation historique supplémentaire.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Réserve médicale | Prendre les soins d’urgence · `supply` | Interaction physique héritée |
| 2 | Réfectoire | Accompagner un colon jusqu’au magasin · `escort` | Santé, tension et arrivée physique |
| 3 | Magasin de fret | Mettre le refuge provisoire sous tension · `power` | Tableau à trois commandes |

Dialogue original : **Paris** — « Restez derrière moi. Nous allons jusqu’à la lumière suivante, puis à la suivante. »

### 10 — Fermer, tenir

**Anne Jorden · La colonie se ferme · Bureau des prospecteurs**

Les prospecteurs transforment leurs outils en moyens de défense.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Magasin de fret | Récupérer un poste à souder · `supply` | Interaction physique héritée |
| 2 | Bureau des prospecteurs | Renforcer la fermeture du bureau · `seal` | Lien de cloison modifié |
| 3 | Distribution électrique | Rétablir le circuit de secours · `power` | Tableau à trois commandes |

Dialogue original : **Anne** — « La porte n’a pas besoin de tenir toute la nuit. Seulement assez longtemps pour les enfants. »

### 11 — Sous le processeur

**Demian Brackett · La chute · Accès au processeur un**

Le passage dans la ruche est un échec de sauvetage, pas une chasse à la reine.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Monte-charge du processeur | Commander le monte-charge · `terminal` | Interaction physique héritée |
| 2 | Soubassements envahis | Retrouver la source des signaux · `scan` | Interaction physique héritée |
| 3 | Galerie du refroidissement | Baliser la route de repli · `beacon` | Interaction physique héritée |
| 4 | Distribution électrique | Fermer derrière le groupe · `seal` | Lien de cloison modifié |

Dialogue original : **Brackett** — « N’approchez pas des parois. Repliez-vous par les balises ; ne tirez que pour ouvrir le passage. »

### 12 — La dernière porte

**Anne Jorden · La chute · Bureau des prospecteurs**

La défense des Jorden ne change pas leur destin. Le point de vue quitte Anne au moment où Newt passe la grille.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Bureau des prospecteurs | Alimenter le verrou une dernière fois · `power` | Tableau à trois commandes |
| 2 | Bureau des prospecteurs | Dégager l’accès au conduit · `seal` | Lien de cloison modifié |
| 3 | Bureau des prospecteurs | Mettre Newt à l’abri · `talk` | Interaction physique héritée |

Dialogue original : **Anne** — « Ne te retourne pas. Compte les virages comme quand vous jouiez. »

### 13 — Une issue réservée

**Julisa Paris · La chute · Laboratoire de la Compagnie**

Brackett transmet l’indication d’Hidalgo : la Compagnie dispose d’une issue. Luisa suit Paris jusqu’au hangar.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Laboratoire de la Compagnie | Recevoir la transmission de Brackett · `talk` | Interaction physique héritée |
| 2 | Bureau des prospecteurs | Dégager Luisa et la conduire au hangar · `escort` | Santé, tension et arrivée physique |
| 3 | Hangar scientifique | Déverrouiller la navette scientifique · `terminal` | Interaction physique héritée |

Dialogue original : **Paris** — « La sortie existe. Nous allons la rendre accessible à ceux qui sont encore avec nous. »

### 14 — La trajectoire imposée

**Demian Brackett · La chute · Hangar scientifique**

Brackett, Paris, Mori et Luisa quittent la colonie. Newt n’est pas à bord.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Hangar scientifique | Vérifier l’embarquement · `talk` | Interaction physique héritée |
| 2 | Navette de la Compagnie | Désengager la trajectoire automatique · `terminal` | Interaction physique héritée |
| 3 | Navette de la Compagnie | Décoller · `launch` | Interaction physique héritée |

Dialogue original : **Brackett** — « Aucune trajectoire imposée. Nous choisissons où nous allons. »

### 15 — Il reste quelqu’un

**Rebecca « Newt » Jorden · La chute · Cache des conduits**

Le point de vue revient dans les conduits. Il faut survivre avec presque rien.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Buanderie | Récupérer de l’eau · `supply` | Interaction physique héritée |
| 2 | Réfectoire | Trouver de quoi manger · `supply` | Interaction physique héritée |
| 3 | Conduits des prospecteurs | Passer sans attirer la créature · `listen` | Interaction physique héritée |

Dialogue original : **Newt** — « Pas la grande porte. Jamais la grande porte quand on entend les tuyaux. »

### 16 — Jusqu’au prochain bruit

**Rebecca « Newt » Jorden · La chute · Cache des conduits**

La cache devient le dernier lieu habité du parcours. La suite appartient à l’arrivée du Sulaco.

| Étape | Lieu | Interaction | Condition nouvelle |
|---|---|---|---|
| 1 | Conduits de l’habitat | Vérifier le chemin de retour · `trace` | Interaction physique héritée |
| 2 | Cache des conduits | Regagner la cache · `stash` | Interaction physique héritée |

Dialogue original : **Newt** — « Je suis là. Je suis encore là. »

## Tableaux et collecteurs

### Départ du bloc habitat · `grid`

Distribution électrique · Circuit `habitat` · Capacité 4.

Alimentez le chauffage et les logements. La buanderie peut attendre.

| Commande | Charge | Réglage attendu | État initial |
|---|---:|---|---|
| Chauffage | 3 | Actif / ouvert | Coupé / fermé |
| Éclairage des logements | 1 | Actif / ouvert | Coupé / fermé |
| Buanderie | 2 | Coupé / fermé | Actif / ouvert |

### Tableau du refuge provisoire · `shelter`

Magasin de fret · Circuit `industry` · Capacité 3.

Gardez la lumière et l’air. Le treuil doit rester coupé.

| Commande | Charge | Réglage attendu | État initial |
|---|---:|---|---|
| Éclairage du refuge | 1 | Actif / ouvert | Coupé / fermé |
| Ventilation du refuge | 2 | Actif / ouvert | Coupé / fermé |
| Treuil de fret | 3 | Coupé / fermé | Actif / ouvert |

### Secours de la maintenance · `emergency`

Distribution électrique · Circuit `industry` · Capacité 4.

Répartissez la réserve entre les pompes et les paliers.

| Commande | Charge | Réglage attendu | État initial |
|---|---:|---|---|
| Pompes de circulation | 2 | Actif / ouvert | Coupé / fermé |
| Éclairage des paliers | 2 | Actif / ouvert | Coupé / fermé |
| Atelier des prospecteurs | 3 | Coupé / fermé | Actif / ouvert |

### Dernière réserve du bureau · `last_power`

Bureau des prospecteurs · Circuit `habitat` · Capacité 2.

Le verrou et la balise. Rien d’autre ne doit tirer sur cette batterie.

| Commande | Charge | Réglage attendu | État initial |
|---|---:|---|---|
| Verrou de la porte | 1 | Actif / ouvert | Coupé / fermé |
| Balise du conduit | 1 | Actif / ouvert | Coupé / fermé |
| Radio générale | 2 | Coupé / fermé | Actif / ouvert |

### Collecteur du processeur six · `pressure`

Processeur six · Circuit `industry` · Capacité 2.

Fermez l’arrivée principale, ouvrez la purge et la dérivation.

| Commande | Charge | Réglage attendu | État initial |
|---|---:|---|---|
| Arrivée principale | 1 | Coupé / fermé | Actif / ouvert |
| Purge protégée | 1 | Actif / ouvert | Coupé / fermé |
| Dérivation de secours | 1 | Actif / ouvert | Coupé / fermé |

### Collecteur de la station de pompage · `reroute`

Station de pompage · Circuit `industry` · Capacité 2.

Isolez le passage, puis ouvrez le retour et la soupape.

| Commande | Charge | Réglage attendu | État initial |
|---|---:|---|---|
| Conduite du passage | 1 | Coupé / fermé | Actif / ouvert |
| Retour au réservoir | 1 | Actif / ouvert | Coupé / fermé |
| Soupape de sécurité | 1 | Actif / ouvert | Coupé / fermé |

## Registre pièce par pièce

### pad — Aire d’atterrissage

**Périmètre · niveau 0 · largeur 2900 u · profondeur 0.25–0.9**

Repère : Tour de contrôle et feux d’approche. Profil `exterior` / `approach_lights` ; circuit `perimeter` ; 9 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Sas des arrivants | sas | 170 / 0.69 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `beacon` / `pad-set-0` | 442 / 0.22 | FIXTURES | Non | orientation du trajet |
| `antenna` / `pad-set-1` | 845 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fuel` / `pad-set-2` | 1248 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `beacon` / `pad-set-3` | 1652 / 0.22 | FIXTURES | Non | orientation du trajet |
| `cable` / `pad-set-4` | 2055 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tractor` / `pad-set-5` | 2458 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `crate` / `pad-cover1` | 1102 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `rock` / `pad-cover2` | 1943 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `survey-stake` / `pad-detail-0` | 348 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `floodlight` / `pad-detail-1` | 899 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `cable-spool` / `pad-detail-2` | 1450 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `barrier` / `pad-detail-3` | 2001 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `rock-fragment` / `pad-detail-4` | 2552 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Retrouver Paris | 667 / 0.81 | 1 | `talk` |
| Prendre en charge le retour des prospecteurs | 1102 / 0.81 | 5 | `talk` |
| Bordereau d’arrivée | 2378.0 / 0.43 | Optionnel | `archive` |

**Contrôle de production :** préserver les 1 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### airlock — Sas des arrivants

**Accueil · niveau 0 · largeur 1800 u · profondeur 0.7–0.7**

Repère : Double porte pressurisée, douche de décontamination. Profil `decontamination` / `double_bulkhead` ; circuit `habitat` ; 5 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Aire d’atterrissage | sas | 170 / 0.7 | Libre |
| Coursive centrale | porte | 1630 / 0.7 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `shower` / `airlock-set-0` | 372 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `locker` / `airlock-set-1` | 636 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fan` / `airlock-set-2` | 900 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `panel` / `airlock-set-3` | 1164 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `lamp` / `airlock-set-4` | 1428 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `oxygen` / `airlock-detail-0` | 433 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `hose-reel` / `airlock-detail-1` | 558 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `warning-board` / `airlock-detail-2` | 900 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `vent-cover` / `airlock-detail-3` | 1242 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `ceiling-light` / `airlock-detail-4` | 438 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Se cacher dans le placard de service | 520 / 0.7 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 414 / 0.77 | 1 |
| `emergency-arrow` | 882 / 0.77 | 2 |
| `broken-light` | 1332 / 0.77 | 2 |
| `scorch` | 1584 / 0.77 | 3 |

**Contrôle de production :** préserver les 2 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### concourse — Coursive centrale

**Accueil · niveau 0 · largeur 3000 u · profondeur 0.25–0.9**

Repère : Signalétique des blocs, galerie vitrée. Profil `concourse` / `glazed_gallery` ; circuit `habitat` ; 9 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Sas des arrivants | porte | 170 / 0.69 | Libre |
| Contrôle colonial | escalier | 2830 / 0.69 | Libre |
| Coursive résidentielle | escalier | 840 / 0.28 | Libre |
| Infirmerie | porte | 1440 / 0.28 | Libre |
| Garage des prospecteurs | porte | 2040 / 0.28 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `bench` / `concourse-set-0` | 420 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `window` / `concourse-set-1` | 780 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `sign` / `concourse-set-2` | 1140 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `vending` / `concourse-set-3` | 1500 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `window` / `concourse-set-4` | 1860 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fan` / `concourse-set-5` | 2220 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `bench` / `concourse-set-6` | 2580 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `bench` / `concourse-cover1` | 1140 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `vending` / `concourse-cover2` | 2010 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `noticeboard` / `concourse-detail-0` | 360 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `ceiling-light` / `concourse-detail-1` | 1147 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `fire-cabinet` / `concourse-detail-2` | 1717 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `wall-clock` / `concourse-detail-3` | 2070 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `pipe-elbow` / `concourse-detail-4` | 2640 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 690 / 0.77 | 1 |
| `emergency-arrow` | 1470 / 0.77 | 2 |
| `broken-light` | 2220 / 0.77 | 2 |
| `scorch` | 2640 / 0.77 | 3 |

**Contrôle de production :** préserver les 5 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### ops — Contrôle colonial

**Administration · niveau 1 · largeur 2400 u · profondeur 0.25–0.9**

Repère : Baie de supervision et consoles de communications. Profil `command` / `observation_bay` ; circuit `research` ; 7 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Coursive centrale | escalier | 170 / 0.69 | Libre |
| Poste de la garnison | porte | 2230 / 0.69 | Libre |
| Relais de communications | coursive | 672 / 0.28 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `console` / `ops-set-0` | 400 / 0.22 | FIXTURES | Non | poste de travail |
| `screen` / `ops-set-1` | 720 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` / `ops-set-2` | 1040 / 0.22 | FIXTURES | Non | poste de travail |
| `antenna` / `ops-set-3` | 1360 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `screen` / `ops-set-4` | 1680 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `map` / `ops-set-5` | 2000 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` / `ops-cover1` | 912 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `console` / `ops-cover2` | 1608 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `chair` / `ops-detail-0` | 1156 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `noticeboard` / `ops-detail-1` | 744 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `radio-mast` / `ops-detail-2` | 1200 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `wall-clock` / `ops-detail-3` | 1656 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `ceiling-light` / `ops-detail-4` | 366 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Consulter le tableau de service | 552 / 0.81 | 1 | `terminal` |
| Relever les dernières balises PDT | 912 / 0.81 | 8 | `terminal` |
| Grille de prospection | 1967.9999999999998 / 0.43 | Optionnel | `archive` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 552 / 0.77 | 1 |
| `emergency-arrow` | 1176 / 0.77 | 2 |
| `broken-light` | 1776 / 0.77 | 2 |
| `scorch` | 2112 / 0.77 | 3 |

**Contrôle de production :** préserver les 3 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### briefing — Poste de la garnison

**Administration · niveau 1 · largeur 2200 u · profondeur 0.7–0.7**

Repère : Casiers individuels et table de service. Profil `barracks` / `locker_bays` ; circuit `habitat` ; 6 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Contrôle colonial | porte | 170 / 0.7 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `locker` / `briefing-set-0` | 383 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rifle-rack` / `briefing-set-1` | 670 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` / `briefing-set-2` | 957 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `locker` / `briefing-set-3` | 1243 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `radio` / `briefing-set-4` | 1530 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `locker` / `briefing-set-5` | 1817 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `hanging-coat` / `briefing-detail-0` | 698 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `rifle-case` / `briefing-detail-1` | 682 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `noticeboard` / `briefing-detail-2` | 1100 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `wall-clock` / `briefing-detail-3` | 1518 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `ceiling-light` / `briefing-detail-4` | 1936 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Prendre la dotation | 506 / 0.7 | 1 | `supply` |
| Ordre du jour | 1804.0 / 0.7 | Optionnel | `archive` |
| Réserve de terrain | 1166.0 / 0.7 | Optionnel | `pickup` |
| Se cacher dans le placard de service | 725 / 0.7 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 506 / 0.77 | 1 |
| `emergency-arrow` | 1078 / 0.77 | 2 |
| `broken-light` | 1628 / 0.77 | 2 |
| `scorch` | 1936 / 0.77 | 3 |

**Contrôle de production :** préserver les 1 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### hab — Coursive résidentielle

**Habitat · niveau 1 · largeur 2700 u · profondeur 0.7–0.7**

Repère : Portes numérotées et fenêtres des logements. Profil `residential` / `numbered_alcoves` ; circuit `habitat` ; 8 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Coursive centrale | escalier | 170 / 0.7 | Libre |
| Logement des Jorden | porte | 2530 / 0.7 | Libre |
| Centre de loisirs | escalier | 756 / 0.7 | Libre |
| Buanderie | escalier | 1296 / 0.7 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `hab-door` / `hab-set-0` | 425 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `window` / `hab-set-1` | 795 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `hab-door` / `hab-set-2` | 1165 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `plant` / `hab-set-3` | 1535 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `hab-door` / `hab-set-4` | 1905 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `drawing` / `hab-set-5` | 2275 / 0.22 | FIXTURES | Non | trace de vie familiale |
| `door-plaque` / `hab-detail-0` | 324 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `fire-cabinet` / `hab-detail-1` | 1054 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `pipe-elbow` / `hab-detail-2` | 1567 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `ceiling-light` / `hab-detail-3` | 1863 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `noticeboard` / `hab-detail-4` | 2376 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Se cacher dans le placard de service | 2349 / 0.7 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 621 / 0.77 | 1 |
| `emergency-arrow` | 1323 / 0.77 | 2 |
| `broken-light` | 1998 / 0.77 | 2 |
| `scorch` | 2376 / 0.77 | 3 |

**Contrôle de production :** préserver les 4 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### jorden — Logement des Jorden

**Habitat · niveau 1 · largeur 1850 u · profondeur 0.25–0.9**

Repère : Table familiale, lits et dessins d’enfant. Profil `domestic` / `low_ceiling` ; circuit `habitat` ; 5 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Coursive résidentielle | porte | 170 / 0.69 | Libre |
| Conduits de l’habitat | conduit | 1680 / 0.69 | Enfant |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `bed` / `jorden-set-0` | 354 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` / `jorden-set-1` | 582 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `drawing` / `jorden-set-2` | 811 / 0.22 | FIXTURES | Non | trace de vie familiale |
| `cupboard` / `jorden-set-3` | 1039 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `bed` / `jorden-set-4` | 1268 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `toy` / `jorden-set-5` | 1496 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` / `jorden-cover1` | 703 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cupboard` / `jorden-cover2` | 1240 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `photo` / `jorden-detail-0` | 222 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `mug` / `jorden-detail-1` | 574 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `hanging-coat` / `jorden-detail-2` | 925 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `bed-lamp` / `jorden-detail-3` | 1276 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `vent-cover` / `jorden-detail-4` | 1628 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Préparer la tournée | 426 / 0.81 | 2 | `talk` |
| Une table pour quatre | 1517.0 / 0.43 | Optionnel | `archive` |
| Se cacher dans le placard de service | 771 / 0.82 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 426 / 0.77 | 1 |
| `emergency-arrow` | 906 / 0.77 | 2 |
| `broken-light` | 1369 / 0.77 | 2 |
| `scorch` | 1628 / 0.77 | 3 |

**Contrôle de production :** préserver les 2 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### mess — Réfectoire

**Habitat · niveau 0 · largeur 2600 u · profondeur 0.25–0.9**

Repère : Tables, cuisine et distributeurs. Profil `canteen` / `kitchen_pass` ; circuit `habitat` ; 8 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Centre de loisirs | porte | 170 / 0.69 | Libre |
| Buanderie | porte | 2430 / 0.69 | Libre |
| Magasin de fret | porte | 728 / 0.28 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `vending` / `mess-set-0` | 417 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `stove` / `mess-set-1` | 770 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` / `mess-set-2` | 1123 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` / `mess-set-3` | 1477 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` / `mess-set-4` | 1830 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `sink` / `mess-set-5` | 2183 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` / `mess-cover1` | 988 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `table` / `mess-cover2` | 1742 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `chair` / `mess-detail-0` | 1180 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `mug` / `mess-detail-1` | 1240 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `kitchen-hood` / `mess-detail-2` | 1517 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `tray` / `mess-detail-3` | 1794 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `fire-cabinet` / `mess-detail-4` | 342 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Récupérer les provisions | 598 / 0.81 | 2 | `supply` |
| Accompagner un colon jusqu’au magasin | 988 / 0.81 | 9 | `escort` |
| Trouver de quoi manger | 1378 / 0.81 | 15 | `supply` |
| Se cacher dans le placard de service | 2262 / 0.82 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 598 / 0.77 | 1 |
| `emergency-arrow` | 1274 / 0.77 | 2 |
| `broken-light` | 1924 / 0.77 | 2 |
| `scorch` | 2288 / 0.77 | 3 |

**Contrôle de production :** préserver les 3 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### recreation — Centre de loisirs

**Habitat · niveau 0 · largeur 2250 u · profondeur 0.25–0.9**

Repère : Jeux, bancs et accès à la maintenance. Profil `leisure` / `recessed_arcades` ; circuit `habitat` ; 7 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Coursive résidentielle | escalier | 170 / 0.69 | Libre |
| Réfectoire | porte | 2080 / 0.69 | Libre |
| Conduits de l’habitat | grille | 630 / 0.28 | Enfant |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `arcade` / `recreation-set-0` | 417 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `bench` / `recreation-set-1` | 771 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `arcade` / `recreation-set-2` | 1125 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` / `recreation-set-3` | 1479 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `drawing` / `recreation-set-4` | 1833 / 0.22 | FIXTURES | Non | trace de vie familiale |
| `arcade` / `recreation-cover1` | 855 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `bench` / `recreation-cover2` | 1508 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `chair` / `recreation-detail-0` | 921 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `noticeboard` / `recreation-detail-1` | 698 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `mug` / `recreation-detail-2` | 1125 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `wall-clock` / `recreation-detail-3` | 1553 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `fire-cabinet` / `recreation-detail-4` | 384 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Les chemins de Tim | 1845.0 / 0.43 | Optionnel | `archive` |
| Se cacher dans le placard de service | 462 / 0.82 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 518 / 0.77 | 1 |
| `emergency-arrow` | 1102 / 0.77 | 2 |
| `broken-light` | 1665 / 0.77 | 2 |
| `scorch` | 1980 / 0.77 | 3 |

**Contrôle de production :** préserver les 3 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### med — Infirmerie

**Médical · niveau 0 · largeur 2800 u · profondeur 0.25–0.9**

Repère : Lits isolés, vitres d’observation et moniteurs. Profil `medical` / `observation_partitions` ; circuit `medical` ; 8 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Coursive centrale | porte | 170 / 0.69 | Libre |
| Chambre d’isolement | porte | 2630 / 0.69 | Libre |
| Réserve médicale | porte | 784 / 0.28 | Libre |
| Laboratoire de la Compagnie | sas | 1344 / 0.28 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `bed` / `med-set-0` | 433 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `monitor` / `med-set-1` | 820 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `bed` / `med-set-2` | 1207 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `sink` / `med-set-3` | 1593 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `medicine` / `med-set-4` | 1980 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `bed` / `med-set-5` | 2367 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `bed` / `med-cover1` | 1064 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cart` / `med-cover2` | 1876 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `privacy-screen` / `med-detail-0` | 336 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `oxygen` / `med-detail-1` | 1736 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `medical-cross` / `med-detail-2` | 1400 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `wall-clock` / `med-detail-3` | 1932 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `gurney` / `med-detail-4` | 2464 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Transmettre le bilan à Komiskey | 644 / 0.81 | 5 | `terminal` |
| Consulter le registre des patients | 1064 / 0.81 | 6 | `terminal` |
| Priorité médicale | 2296.0 / 0.43 | Optionnel | `archive` |
| Réserve de terrain | 1484.0 / 0.86 | Optionnel | `pickup` |
| Se cacher dans le placard de service | 2436 / 0.82 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 644 / 0.77 | 1 |
| `emergency-arrow` | 1372 / 0.77 | 2 |
| `broken-light` | 2072 / 0.77 | 2 |
| `scorch` | 2464 / 0.77 | 3 |

**Contrôle de production :** préserver les 4 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### isolation — Chambre d’isolement

**Médical · niveau 0 · largeur 1700 u · profondeur 0.7–0.7**

Repère : Lit d’observation et hublot de quarantaine. Profil `medical` / `sealed_observation` ; circuit `medical` ; 5 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Infirmerie | porte | 170 / 0.7 | Libre |
| Conduits de l’infirmerie | grille | 1530 / 0.7 | Enfant |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `bed` / `isolation-set-0` | 362 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `monitor` / `isolation-set-1` | 606 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `glass` / `isolation-set-2` | 850 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `sink` / `isolation-set-3` | 1094 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `specimen` / `isolation-set-4` | 1338 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `privacy-screen` / `isolation-detail-0` | 638 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `oxygen` / `isolation-detail-1` | 527 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `medical-cross` / `isolation-detail-2` | 850 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `wall-clock` / `isolation-detail-3` | 1173 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `gurney` / `isolation-detail-4` | 667 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Fermer l’isolement médical | 391 / 0.7 | 5 | `seal` |
| Le hublot | 1394.0 / 0.7 | Optionnel | `archive` |
| Se cacher dans le placard de service | 533 / 0.7 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 391 / 0.77 | 1 |
| `emergency-arrow` | 833 / 0.77 | 2 |
| `broken-light` | 1258 / 0.77 | 2 |
| `scorch` | 1496 / 0.77 | 3 |

**Contrôle de production :** préserver les 2 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### science — Laboratoire de la Compagnie

**Recherche · niveau 0 · largeur 2400 u · profondeur 0.25–0.9**

Repère : Paillasses, cuves et racks de confinement. Profil `laboratory` / `containment_bays` ; circuit `research` ; 7 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Infirmerie | sas | 170 / 0.69 | Libre |
| Salle des archives | escalier | 2230 / 0.69 | Libre |
| Galerie technique | escalier | 672 / 0.28 | Libre |
| Hangar scientifique | sas | 1152 / 0.28 | scienceClearance |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `specimen` / `science-set-0` | 400 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` / `science-set-1` | 720 / 0.22 | FIXTURES | Non | poste de travail |
| `specimen` / `science-set-2` | 1040 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `sink` / `science-set-3` | 1360 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `microscope` / `science-set-4` | 1680 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tank` / `science-set-5` | 2000 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `lab-bench` / `science-cover1` | 912 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `specimen` / `science-cover2` | 1608 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `glass-cabinet` / `science-detail-0` | 1373 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `lab-bench` / `science-detail-1` | 1395 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `oxygen` / `science-detail-2` | 1417 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `warning-board` / `science-detail-3` | 1656 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `vent-cover` / `science-detail-4` | 2112 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Lire la directive scientifique | 552 / 0.81 | 6 | `terminal` |
| Recevoir la transmission de Brackett | 912 / 0.81 | 13 | `talk` |
| Mainmise | 1967.9999999999998 / 0.43 | Optionnel | `archive` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 552 / 0.77 | 1 |
| `emergency-arrow` | 1176 / 0.77 | 2 |
| `broken-light` | 1776 / 0.77 | 2 |
| `scorch` | 2112 / 0.77 | 3 |

**Contrôle de production :** préserver les 4 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### records — Salle des archives

**Recherche · niveau 1 · largeur 1800 u · profondeur 0.7–0.7**

Repère : Bandes de données et baie réseau. Profil `archive` / `server_aisles` ; circuit `research` ; 5 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Laboratoire de la Compagnie | escalier | 170 / 0.7 | Libre |
| Relais de communications | coursive | 1630 / 0.7 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `rack` / `records-set-0` | 372 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rack` / `records-set-1` | 636 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` / `records-set-2` | 900 / 0.22 | FIXTURES | Non | poste de travail |
| `rack` / `records-set-3` | 1164 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `screen` / `records-set-4` | 1428 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `server` / `records-detail-0` | 650 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `tape-reel` / `records-detail-1` | 558 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `cable-tray` / `records-detail-2` | 900 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `vent-cover` / `records-detail-3` | 1242 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `wall-clock` / `records-detail-4` | 1584 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Conserver une copie des échanges | 414 / 0.7 | 6 | `terminal` |
| Transmission conservée | 1476.0 / 0.7 | Optionnel | `archive` |
| Se cacher dans le placard de service | 777 / 0.7 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 414 / 0.77 | 1 |
| `emergency-arrow` | 882 / 0.77 | 2 |
| `broken-light` | 1332 / 0.77 | 2 |
| `scorch` | 1584 / 0.77 | 3 |

**Contrôle de production :** préserver les 2 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### garage — Garage des prospecteurs

**Logistique · niveau 0 · largeur 3200 u · profondeur 0.25–0.9**

Repère : Tracteur de prospection sur sa voie de service. Profil `hangar` / `overhead_crane` ; circuit `industry` ; 9 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Coursive centrale | porte | 170 / 0.69 | Libre |
| Bureau des prospecteurs | porte | 3030 / 0.69 | Libre |
| Galerie technique | escalier | 896 / 0.28 | Libre |
| Piste du plateau | sas | 1536 / 0.28 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `tractor` / `garage-set-0` | 512 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tools` / `garage-set-1` | 1056 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fuel` / `garage-set-2` | 1600 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `gantry` / `garage-set-3` | 2144 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `wheel` / `garage-set-4` | 2688 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tools` / `garage-cover1` | 1216 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `wheel` / `garage-cover2` | 2144 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `chain-hoist` / `garage-detail-0` | 384 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `warning-board` / `garage-detail-1` | 992 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `hose-reel` / `garage-detail-2` | 1817 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `tool-board` / `garage-detail-3` | 2208 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `ceiling-light` / `garage-detail-4` | 2816 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Prendre le matériel de secours | 736 / 0.81 | 3 | `supply` |
| Préparer le tracteur | 1216 / 0.81 | 4 | `vehicle` |
| Tracteur des prospecteurs | 2624.0 / 0.43 | Optionnel | `archive` |
| Réserve de terrain | 1696.0 / 0.86 | Optionnel | `pickup` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 736 / 0.77 | 1 |
| `emergency-arrow` | 1568 / 0.77 | 2 |
| `broken-light` | 2368 / 0.77 | 2 |
| `scorch` | 2816 / 0.77 | 3 |

**Contrôle de production :** préserver les 4 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### survey — Bureau des prospecteurs

**Logistique · niveau 0 · largeur 2500 u · profondeur 0.25–0.9**

Repère : Cartes topographiques et postes radio. Profil `command` / `survey_wall` ; circuit `habitat` ; 7 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Garage des prospecteurs | porte | 170 / 0.69 | Libre |
| Magasin de fret | porte | 2330 / 0.69 | Libre |
| Conduits des prospecteurs | grille | 700 / 0.28 | Enfant |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `map` / `survey-set-0` | 442 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` / `survey-set-1` | 846 / 0.22 | FIXTURES | Non | poste de travail |
| `radio` / `survey-set-2` | 1250 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tools` / `survey-set-3` | 1654 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `shelf` / `survey-set-4` | 2058 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `table` / `survey-cover1` | 950 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `crate` / `survey-cover2` | 1675 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `chair` / `survey-detail-0` | 1168 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `noticeboard` / `survey-detail-1` | 775 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `radio-mast` / `survey-detail-2` | 1467 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `wall-clock` / `survey-detail-3` | 1725 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `ceiling-light` / `survey-detail-4` | 354 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Recevoir la grille de prospection | 575 / 0.81 | 4 | `terminal` |
| Renforcer la fermeture du bureau | 950 / 0.81 | 10 | `seal` |
| Alimenter le verrou une dernière fois | 1325 / 0.81 | 12 | `power` |
| Dégager l’accès au conduit | 1700 / 0.81 | 12 | `seal` |
| Mettre Newt à l’abri | 575 / 0.81 | 12 | `talk` |
| Dégager Luisa et la conduire au hangar | 950 / 0.81 | 13 | `escort` |
| Un bureau transformé | 2050.0 / 0.43 | Optionnel | `archive` |
| Se cacher dans le placard de service | 429 / 0.82 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 575 / 0.77 | 1 |
| `emergency-arrow` | 1225 / 0.77 | 2 |
| `broken-light` | 1850 / 0.77 | 2 |
| `scorch` | 2200 / 0.77 | 3 |

**Contrôle de production :** préserver les 3 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### stores — Magasin de fret

**Logistique · niveau 0 · largeur 3100 u · profondeur 0.25–0.9**

Repère : Palettes, rack de levage et allées dégagées. Profil `warehouse` / `loading_racks` ; circuit `industry` ; 9 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Bureau des prospecteurs | porte | 170 / 0.69 | Libre |
| Distribution électrique | escalier | 2930 / 0.69 | Libre |
| Réfectoire | porte | 868 / 0.28 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `crate` / `stores-set-0` | 458 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `shelf` / `stores-set-1` | 895 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `pallet` / `stores-set-2` | 1332 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `gantry` / `stores-set-3` | 1768 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `crate` / `stores-set-4` | 2205 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `shelf` / `stores-set-5` | 2642 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `crate` / `stores-cover1` | 1178 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `pallet` / `stores-cover2` | 2077 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `hand-truck` / `stores-detail-0` | 372 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `tool-board` / `stores-detail-1` | 961 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `warning-board` / `stores-detail-2` | 1550 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `fire-cabinet` / `stores-detail-3` | 2139 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `cable-tray` / `stores-detail-4` | 2728 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Mettre le refuge provisoire sous tension | 713 / 0.81 | 9 | `power` |
| Récupérer un poste à souder | 1178 / 0.81 | 10 | `supply` |
| Refuge provisoire | 2542.0 / 0.43 | Optionnel | `archive` |
| Réserve de terrain | 1643.0 / 0.86 | Optionnel | `pickup` |
| Se cacher dans le placard de service | 2697 / 0.82 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 713 / 0.77 | 1 |
| `emergency-arrow` | 1519 / 0.77 | 2 |
| `broken-light` | 2294 / 0.77 | 2 |
| `scorch` | 2728 / 0.77 | 3 |

**Contrôle de production :** préserver les 3 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### power — Distribution électrique

**Maintenance · niveau -1 · largeur 2600 u · profondeur 0.25–0.9**

Repère : Deux banques de coupe-circuits et conduites. Profil `industrial` / `busbar_banks` ; circuit `industry` ; 8 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Magasin de fret | escalier | 170 / 0.69 | Libre |
| Station de pompage | porte | 2430 / 0.69 | Libre |
| Galerie du refroidissement | échelle | 728 / 0.28 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `transformer` / `power-set-0` | 417 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `panel` / `power-set-1` | 770 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `transformer` / `power-set-2` | 1123 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `panel` / `power-set-3` | 1477 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cable` / `power-set-4` | 1830 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `coil` / `power-set-5` | 2183 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `transformer` / `power-cover1` | 988 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `coil` / `power-cover2` | 1742 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `gauge` / `power-detail-0` | 312 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `pipe-elbow` / `power-detail-1` | 1240 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `pump-motor` / `power-detail-2` | 1517 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `warning-board` / `power-detail-3` | 1794 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `cable-tray` / `power-detail-4` | 342 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Réarmer le départ habitat | 598 / 0.81 | 2 | `power` |
| Rétablir le circuit de secours | 988 / 0.81 | 10 | `power` |
| Fermer derrière le groupe | 1378 / 0.81 | 11 | `seal` |
| Deux circuits | 2132.0 / 0.43 | Optionnel | `archive` |
| Se cacher dans le placard de service | 2262 / 0.82 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 598 / 0.77 | 1 |
| `emergency-arrow` | 1274 / 0.77 | 2 |
| `broken-light` | 1924 / 0.77 | 2 |
| `scorch` | 2288 / 0.77 | 3 |

**Contrôle de production :** préserver les 3 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### pump — Station de pompage

**Maintenance · niveau -1 · largeur 2400 u · profondeur 0.25–0.9**

Repère : Collecteurs, vannes et caniveaux protégés. Profil `industrial` / `collector_wall` ; circuit `industry` ; 7 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Distribution électrique | porte | 170 / 0.69 | Libre |
| Galerie technique | porte | 2230 / 0.69 | Libre |
| Accès au processeur un | escalier | 672 / 0.28 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `tank` / `pump-set-0` | 432 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `pipe` / `pump-set-1` | 816 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `valve` / `pump-set-2` | 1200 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tank` / `pump-set-3` | 1584 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `valve` / `pump-set-4` | 1968 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tank` / `pump-cover1` | 912 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `pump-motor` / `pump-cover2` | 1608 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `gauge` / `pump-detail-0` | 288 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `pipe-elbow` / `pump-detail-1` | 961 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `pump-motor` / `pump-detail-2` | 1417 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `warning-board` / `pump-detail-3` | 1656 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `cable-tray` / `pump-detail-4` | 366 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Détourner la pression du passage | 552 / 0.81 | 8 | `valve` |
| Sous les logements | 1967.9999999999998 / 0.43 | Optionnel | `archive` |
| Réserve de terrain | 1272.0 / 0.86 | Optionnel | `pickup` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 552 / 0.77 | 1 |
| `emergency-arrow` | 1176 / 0.77 | 2 |
| `broken-light` | 1776 / 0.77 | 2 |
| `scorch` | 2112 / 0.77 | 3 |

Danger `jet-pump` à 1870 / 0.82 : actif 2.0 s sur 6.8 s ; dommage nominal 10 avec coefficient de difficulté. Neutralisation : `reroute`.

**Contrôle de production :** préserver les 3 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### service — Galerie technique

**Maintenance · niveau -1 · largeur 3000 u · profondeur 0.7–0.7**

Repère : Passage sous les bâtiments, conduites continues. Profil `maintenance` / `pipe_trench` ; circuit `industry` ; 9 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Station de pompage | porte | 170 / 0.7 | Libre |
| Laboratoire de la Compagnie | escalier | 2830 / 0.7 | Libre |
| Garage des prospecteurs | escalier | 840 / 0.7 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `pipe` / `service-set-0` | 492 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fan` / `service-set-1` | 996 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `pipe` / `service-set-2` | 1500 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cable` / `service-set-3` | 2004 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `pipe` / `service-set-4` | 2508 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `gauge` / `service-detail-0` | 360 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `pipe-elbow` / `service-detail-1` | 1147 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `vent-cover` / `service-detail-2` | 1500 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `cable-tray` / `service-detail-3` | 2070 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `fire-cabinet` / `service-detail-4` | 2640 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Suivre les traces dans la galerie | 690 / 0.7 | 8 | `scan` |
| Se cacher dans le placard de service | 2610 / 0.7 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 690 / 0.77 | 1 |
| `emergency-arrow` | 1470 / 0.77 | 2 |
| `broken-light` | 2220 / 0.77 | 2 |
| `scorch` | 2640 / 0.77 | 3 |

**Contrôle de production :** préserver les 3 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### road — Piste du plateau

**Périmètre · niveau 0 · largeur 3700 u · profondeur 0.25–0.9**

Repère : Piquets de balisage, roches et ravines non praticables. Profil `exterior` / `rock_cutting` ; circuit `perimeter` ; 11 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Garage des prospecteurs | sas | 170 / 0.69 | Libre |
| Plateau des relevés | piste | 3530 / 0.69 | Libre |
| Processeur six | piste | 1036 / 0.28 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `beacon` / `road-set-0` | 562 / 0.22 | FIXTURES | Non | orientation du trajet |
| `rock` / `road-set-1` | 1206 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rock` / `road-set-2` | 1850 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `beacon` / `road-set-3` | 2494 / 0.22 | FIXTURES | Non | orientation du trajet |
| `wreck` / `road-set-4` | 3138 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `crate` / `road-cover1` | 1406 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `rock` / `road-cover2` | 2479 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `survey-stake` / `road-detail-0` | 444 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `floodlight` / `road-detail-1` | 1364 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `cable-spool` / `road-detail-2` | 1850 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `barrier` / `road-detail-3` | 2553 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `rock-fragment` / `road-detail-4` | 3256 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|

**Contrôle de production :** préserver les 3 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### plateau — Plateau des relevés

**Périmètre · niveau 0 · largeur 2900 u · profondeur 0.25–0.9**

Repère : Tracteur arrêté au pied de formations rocheuses. Profil `exterior` / `survey_ridge` ; circuit `perimeter` ; 9 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Piste du plateau | piste | 170 / 0.69 | Libre |
| Seuil de l’épave | brèche | 2730 / 0.69 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `tractor` / `plateau-set-0` | 482 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rock` / `plateau-set-1` | 966 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `beacon` / `plateau-set-2` | 1450 / 0.22 | FIXTURES | Non | orientation du trajet |
| `rock` / `plateau-set-3` | 1934 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cable` / `plateau-set-4` | 2418 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `crate` / `plateau-cover1` | 1102 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `rock` / `plateau-cover2` | 1943 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `survey-stake` / `plateau-detail-0` | 348 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `floodlight` / `plateau-detail-1` | 899 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `cable-spool` / `plateau-detail-2` | 1450 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `barrier` / `plateau-detail-3` | 2001 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `rock-fragment` / `plateau-detail-4` | 2552 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Poser une balise sur le plateau | 667 / 0.81 | 4 | `beacon` |

**Contrôle de production :** préserver les 2 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### derelict — Seuil de l’épave

**Épave · niveau 0 · largeur 2500 u · profondeur 0.25–0.9**

Repère : Arches biomécaniques et coque affaissée. Profil `derelict` / `organic_vault` ; circuit `perimeter` ; 7 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Plateau des relevés | brèche | 170 / 0.69 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `rib` / `derelict-set-0` | 442 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rib` / `derelict-set-1` | 846 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fossil` / `derelict-set-2` | 1250 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rib` / `derelict-set-3` | 1654 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `egg` / `derelict-set-4` | 2058 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rib` / `derelict-cover1` | 950 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `rock` / `derelict-cover2` | 1675 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `rib` / `derelict-detail-0` | 734 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `rib` / `derelict-detail-1` | 775 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `rock-fragment` / `derelict-detail-2` | 1250 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `fossil` / `derelict-detail-3` | 1725 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `egg` / `derelict-detail-4` | 2200 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Examiner le seuil de l’épave | 575 / 0.81 | 4 | `scan` |
| Une coque étrangère | 2050.0 / 0.43 | Optionnel | `archive` |

**Contrôle de production :** préserver les 1 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### processor6 — Processeur six

**Terraformage · niveau 0 · largeur 3000 u · profondeur 0.25–0.9**

Repère : Passerelle industrielle et conduites sous pression. Profil `industrial` / `heat_exchangers` ; circuit `industry` ; 9 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Piste du plateau | piste | 170 / 0.69 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `turbine` / `processor6-set-0` | 492 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `valve` / `processor6-set-1` | 996 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `turbine` / `processor6-set-2` | 1500 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `gantry` / `processor6-set-3` | 2004 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `pipe` / `processor6-set-4` | 2508 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `turbine` / `processor6-cover1` | 1140 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `pipe` / `processor6-cover2` | 2010 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `gauge` / `processor6-detail-0` | 360 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `pipe-elbow` / `processor6-detail-1` | 930 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `pump-motor` / `processor6-detail-2` | 1717 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `warning-board` / `processor6-detail-3` | 2070 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `cable-tray` / `processor6-detail-4` | 2640 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Isoler la conduite endommagée | 690 / 0.81 | 3 | `valve` |
| Récupérer le rapport d’intervention | 1140 / 0.81 | 3 | `terminal` |
| Intervention interrompue | 2460.0 / 0.43 | Optionnel | `archive` |
| Réserve de terrain | 1590.0 / 0.86 | Optionnel | `pickup` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 690 / 0.77 | 1 |
| `emergency-arrow` | 1470 / 0.77 | 2 |
| `broken-light` | 2220 / 0.77 | 2 |
| `scorch` | 2640 / 0.77 | 3 |

Danger `jet-processor6` à 2350 / 0.82 : actif 2.1 s sur 6 s ; dommage nominal 12 avec coefficient de difficulté. Neutralisation : `pressure`.

**Contrôle de production :** préserver les 1 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### approach — Accès au processeur un

**Terraformage · niveau 0 · largeur 3200 u · profondeur 0.25–0.9**

Repère : Pylônes, sas de maintenance et énormes échangeurs. Profil `exterior` / `processor_columns` ; circuit `industry` ; 9 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Station de pompage | escalier | 170 / 0.69 | Libre |
| Monte-charge du processeur | monte-charge | 3030 / 0.69 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `tower` / `approach-set-0` | 512 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `beacon` / `approach-set-1` | 1056 / 0.22 | FIXTURES | Non | orientation du trajet |
| `pipe` / `approach-set-2` | 1600 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tower` / `approach-set-3` | 2144 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `beacon` / `approach-set-4` | 2688 / 0.22 | FIXTURES | Non | orientation du trajet |
| `crate` / `approach-cover1` | 1216 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `rock` / `approach-cover2` | 2144 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `survey-stake` / `approach-detail-0` | 384 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `floodlight` / `approach-detail-1` | 992 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `cable-spool` / `approach-detail-2` | 1600 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `barrier` / `approach-detail-3` | 2208 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `rock-fragment` / `approach-detail-4` | 2816 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|

**Contrôle de production :** préserver les 2 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### lift — Monte-charge du processeur

**Terraformage · niveau -1 · largeur 1800 u · profondeur 0.7–0.7**

Repère : Cabine de fret et paliers identifiés. Profil `shaft` / `counterweights` ; circuit `industry` ; 5 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Accès au processeur un | monte-charge | 170 / 0.7 | Libre |
| Soubassements envahis | monte-charge | 1630 / 0.7 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `cable` / `lift-set-0` | 405 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `panel` / `lift-set-1` | 735 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `gantry` / `lift-set-2` | 1065 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `lamp` / `lift-set-3` | 1395 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `chain-hoist` / `lift-detail-0` | 650 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `warning-board` / `lift-detail-1` | 558 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `cable-tray` / `lift-detail-2` | 900 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `gauge` / `lift-detail-3` | 1242 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `ceiling-light` / `lift-detail-4` | 655 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Commander le monte-charge | 414 / 0.7 | 11 | `terminal` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 414 / 0.77 | 1 |
| `emergency-arrow` | 882 / 0.77 | 2 |
| `broken-light` | 1332 / 0.77 | 2 |
| `scorch` | 1584 / 0.77 | 3 |

**Contrôle de production :** préserver les 2 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### hive — Soubassements envahis

**Terraformage · niveau -2 · largeur 3000 u · profondeur 0.25–0.9**

Repère : Résine sur les structures industrielles, balises PDT. Profil `hive` / `resin_on_steel` ; circuit `industry` ; 9 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Monte-charge du processeur | monte-charge | 170 / 0.69 | Libre |
| Galerie du refroidissement | passerelle | 2830 / 0.69 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `resin` / `hive-set-0` | 450 / 0.22 | FIXTURES | Non | progression de la contamination |
| `cocoon` / `hive-set-1` | 870 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rib` / `hive-set-2` | 1290 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `resin` / `hive-set-3` | 1710 / 0.22 | FIXTURES | Non | progression de la contamination |
| `egg` / `hive-set-4` | 2130 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cocoon` / `hive-set-5` | 2550 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `resin` / `hive-cover1` | 1140 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `cocoon` / `hive-cover2` | 2010 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `resin` / `hive-detail-0` | 360 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `resin` / `hive-detail-1` | 930 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `cocoon` / `hive-detail-2` | 1500 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `pipe-elbow` / `hive-detail-3` | 2070 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `cable-tray` / `hive-detail-4` | 2640 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Retrouver la source des signaux | 690 / 0.81 | 11 | `scan` |
| Signaux immobiles | 2460.0 / 0.43 | Optionnel | `archive` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 690 / 0.77 | 1 |
| `emergency-arrow` | 1470 / 0.77 | 2 |
| `broken-light` | 2220 / 0.77 | 2 |
| `scorch` | 2640 / 0.77 | 3 |

**Contrôle de production :** préserver les 2 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### coolant — Galerie du refroidissement

**Terraformage · niveau -2 · largeur 2700 u · profondeur 0.25–0.9**

Repère : Passage étroit entre les échangeurs, ruche en arrière-plan. Profil `hive` / `buried_exchangers` ; circuit `industry` ; 8 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Soubassements envahis | passerelle | 170 / 0.69 | Libre |
| Distribution électrique | échelle | 2530 / 0.69 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `tank` / `coolant-set-0` | 462 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `resin` / `coolant-set-1` | 906 / 0.22 | FIXTURES | Non | progression de la contamination |
| `cocoon` / `coolant-set-2` | 1350 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tank` / `coolant-set-3` | 1794 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `rib` / `coolant-set-4` | 2238 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `tank` / `coolant-cover1` | 1026 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `resin` / `coolant-cover2` | 1809 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `resin` / `coolant-detail-0` | 324 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `resin` / `coolant-detail-1` | 837 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `cocoon` / `coolant-detail-2` | 1350 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `pipe-elbow` / `coolant-detail-3` | 1863 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `cable-tray` / `coolant-detail-4` | 2376 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Baliser la route de repli | 621 / 0.81 | 11 | `beacon` |
| Aucun trophée | 2214.0 / 0.43 | Optionnel | `archive` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 621 / 0.77 | 1 |
| `emergency-arrow` | 1323 / 0.77 | 2 |
| `broken-light` | 1998 / 0.77 | 2 |
| `scorch` | 2376 / 0.77 | 3 |

**Contrôle de production :** préserver les 2 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### vent_hab — Conduits de l’habitat

**Ventilation · niveau 1 · largeur 2600 u · profondeur 0.7–0.7**

Repère : Jonctions basses, grilles et câbles de repérage. Profil `vent` / `habitat_branch` ; circuit `habitat` ; 8 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Logement des Jorden | conduit | 170 / 0.7 | Enfant |
| Conduits de l’infirmerie | conduit | 2430 / 0.7 | Enfant |
| Conduits des prospecteurs | conduit | 728 / 0.7 | Enfant |
| Centre de loisirs | grille | 1248 / 0.7 | Enfant |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `grille` / `vent_hab-set-0` | 452 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cable` / `vent_hab-set-1` | 876 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `grille` / `vent_hab-set-2` | 1300 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fan` / `vent_hab-set-3` | 1724 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `drawing` / `vent_hab-set-4` | 2148 / 0.22 | FIXTURES | Non | trace de vie familiale |
| `duct-junction` / `vent_hab-detail-0` | 1614 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `vent-cover` / `vent_hab-detail-1` | 806 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `cable-tray` / `vent_hab-detail-2` | 1517 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `bolt-panel` / `vent_hab-detail-3` | 1794 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `trace-mark` / `vent_hab-detail-4` | 2288 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Retrouver les repères de Tim | 598 / 0.7 | 7 | `trace` |
| Vérifier le chemin de retour | 988 / 0.7 | 16 | `trace` |
| Se glisser dans le renfoncement | 2262 / 0.7 | Optionnel | `hide` |

**Contrôle de production :** préserver les 4 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### vent_med — Conduits de l’infirmerie

**Ventilation · niveau 1 · largeur 2400 u · profondeur 0.7–0.7**

Repère : Grilles d’observation et courbe de service. Profil `vent` / `observation_grille` ; circuit `medical` ; 7 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Conduits de l’habitat | conduit | 170 / 0.7 | Enfant |
| Chambre d’isolement | grille | 2230 / 0.7 | Enfant |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `grille` / `vent_med-set-0` | 480 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cable` / `vent_med-set-1` | 960 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `grille` / `vent_med-set-2` | 1440 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `pipe` / `vent_med-set-3` | 1920 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `duct-junction` / `vent_med-detail-0` | 722 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `vent-cover` / `vent_med-detail-1` | 744 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `cable-tray` / `vent_med-detail-2` | 1200 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `bolt-panel` / `vent_med-detail-3` | 1656 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `trace-mark` / `vent_med-detail-4` | 2112 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Écouter derrière la grille | 552 / 0.7 | 7 | `listen` |

**Contrôle de production :** préserver les 2 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### vent_survey — Conduits des prospecteurs

**Ventilation · niveau 0 · largeur 2350 u · profondeur 0.7–0.7**

Repère : Grille de secours au-dessus de la dernière barricade. Profil `vent` / `survey_branch` ; circuit `habitat` ; 7 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Conduits de l’habitat | conduit | 170 / 0.7 | Enfant |
| Bureau des prospecteurs | grille | 2180 / 0.7 | Enfant |
| Cache des conduits | conduit | 658 / 0.7 | Enfant |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `grille` / `vent_survey-set-0` | 474 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `cable` / `vent_survey-set-1` | 941 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `grille` / `vent_survey-set-2` | 1409 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `resin` / `vent_survey-set-3` | 1876 / 0.22 | FIXTURES | Non | progression de la contamination |
| `duct-junction` / `vent_survey-detail-0` | 933 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `vent-cover` / `vent_survey-detail-1` | 728 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `cable-tray` / `vent_survey-detail-2` | 1175 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `bolt-panel` / `vent_survey-detail-3` | 1622 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `trace-mark` / `vent_survey-detail-4` | 2068 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Passer sans attirer la créature | 540 / 0.7 | 15 | `listen` |
| Se glisser dans le renfoncement | 2044 / 0.7 | Optionnel | `hide` |

**Contrôle de production :** préserver les 3 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### refuge — Cache des conduits

**Ventilation · niveau 0 · largeur 1750 u · profondeur 0.7–0.7**

Repère : Petit renfoncement hors des axes de ventilation. Profil `refuge` / `service_recess` ; circuit `habitat` ; 5 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Conduits des prospecteurs | conduit | 170 / 0.7 | Enfant |
| Buanderie | grille | 1580 / 0.7 | Enfant |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `toy` / `refuge-set-0` | 399 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `blanket` / `refuge-set-1` | 716 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `ration` / `refuge-set-2` | 1034 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `drawing` / `refuge-set-3` | 1351 / 0.22 | FIXTURES | Non | trace de vie familiale |
| `mug` / `refuge-detail-0` | 861 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `photo` / `refuge-detail-1` | 542 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `trace-mark` / `refuge-detail-2` | 875 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `bolt-panel` / `refuge-detail-3` | 1208 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `vent-cover` / `refuge-detail-4` | 1540 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Préparer une petite cache | 402 / 0.7 | 7 | `stash` |
| Regagner la cache | 665 / 0.7 | 16 | `stash` |
| La petite cache | 1435.0 / 0.7 | Optionnel | `archive` |
| Se glisser dans le renfoncement | 1040 / 0.7 | Optionnel | `hide` |

**Contrôle de production :** préserver les 2 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### hangar — Hangar scientifique

**Recherche · niveau 0 · largeur 3300 u · profondeur 0.25–0.9**

Repère : Navette de service, passerelle et réserves de carburant. Profil `hangar` / `shuttle_bay` ; circuit `research` ; 10 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Laboratoire de la Compagnie | sas | 170 / 0.69 | scienceClearance |
| Navette de la Compagnie | passerelle | 3130 / 0.69 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `shuttle` / `hangar-set-0` | 522 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fuel` / `hangar-set-1` | 1086 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `gantry` / `hangar-set-2` | 1650 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` / `hangar-set-3` | 2214 / 0.22 | FIXTURES | Non | poste de travail |
| `pallet` / `hangar-set-4` | 2778 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fuel` / `hangar-cover1` | 1254 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `pallet` / `hangar-cover2` | 2211 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `chain-hoist` / `hangar-detail-0` | 396 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `warning-board` / `hangar-detail-1` | 1023 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `hose-reel` / `hangar-detail-2` | 1867 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `tool-board` / `hangar-detail-3` | 2277 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `ceiling-light` / `hangar-detail-4` | 2904 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Déverrouiller la navette scientifique | 759 / 0.81 | 13 | `terminal` |
| Vérifier l’embarquement | 1254 / 0.81 | 14 | `talk` |
| Accès réservé | 2706.0 / 0.43 | Optionnel | `archive` |
| Réserve de terrain | 1749.0 / 0.86 | Optionnel | `pickup` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 759 / 0.77 | 1 |
| `emergency-arrow` | 1617 / 0.77 | 2 |
| `broken-light` | 2442 / 0.77 | 2 |
| `scorch` | 2904 / 0.77 | 3 |

**Contrôle de production :** préserver les 2 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### shuttle — Navette de la Compagnie

**Recherche · niveau 0 · largeur 2150 u · profondeur 0.7–0.7**

Repère : Sas arrière, sièges et commandes de navigation. Profil `shuttle` / `pressure_shell` ; circuit `research` ; 6 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Hangar scientifique | passerelle | 170 / 0.7 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `seat` / `shuttle-set-0` | 407 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `seat` / `shuttle-set-1` | 741 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` / `shuttle-set-2` | 1075 / 0.22 | FIXTURES | Non | poste de travail |
| `screen` / `shuttle-set-3` | 1409 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `hatch` / `shuttle-set-4` | 1743 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `hanging-coat` / `shuttle-detail-0` | 692 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `oxygen` / `shuttle-detail-1` | 666 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `warning-board` / `shuttle-detail-2` | 1075 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `vent-cover` / `shuttle-detail-3` | 1484 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `ceiling-light` / `shuttle-detail-4` | 1892 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Désengager la trajectoire automatique | 494 / 0.7 | 14 | `terminal` |
| Décoller | 817 / 0.7 | 14 | `launch` |
| Quatre sièges occupés | 1763.0 / 0.7 | Optionnel | `archive` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 494 / 0.77 | 1 |
| `emergency-arrow` | 1054 / 0.77 | 2 |
| `broken-light` | 1591 / 0.77 | 2 |
| `scorch` | 1892 / 0.77 | 3 |

**Contrôle de production :** préserver les 1 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### wash — Buanderie

**Habitat · niveau 0 · largeur 1850 u · profondeur 0.25–0.9**

Repère : Machines, linge abandonné et évier de service. Profil `utility` / `laundry_racks` ; circuit `habitat` ; 5 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Cache des conduits | grille | 170 / 0.69 | Enfant |
| Réfectoire | porte | 1680 / 0.69 | Libre |
| Coursive résidentielle | escalier | 518 / 0.28 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `washer` / `wash-set-0` | 377 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `washer` / `wash-set-1` | 651 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `linen` / `wash-set-2` | 925 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `sink` / `wash-set-3` | 1199 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `washer` / `wash-set-4` | 1473 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `washer` / `wash-cover1` | 703 / 0.56 | ACTORS | Oui | obstacle contournable et cachette basse |
| `linen` / `wash-cover2` | 1240 / 0.57 | ACTORS | Oui | obstacle contournable et cachette basse |
| `hanging-coat` / `wash-detail-0` | 873 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `hose-reel` / `wash-detail-1` | 791 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `vent-cover` / `wash-detail-2` | 925 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `wall-clock` / `wash-detail-3` | 1276 / 0.38 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `fire-cabinet` / `wash-detail-4` | 866 / 0.38 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Récupérer de l’eau | 426 / 0.81 | 15 | `supply` |
| L’eau du lendemain | 1517.0 / 0.43 | Optionnel | `archive` |
| Se cacher dans le placard de service | 771 / 0.82 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 426 / 0.77 | 1 |
| `emergency-arrow` | 906 / 0.77 | 2 |
| `broken-light` | 1369 / 0.77 | 2 |
| `scorch` | 1628 / 0.77 | 3 |

**Contrôle de production :** préserver les 3 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### relay — Relais de communications

**Administration · niveau 1 · largeur 1950 u · profondeur 0.7–0.7**

Repère : Baie relais et émetteurs directionnels. Profil `archive` / `relay_backbone` ; circuit `research` ; 6 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Salle des archives | coursive | 170 / 0.7 | Libre |
| Contrôle colonial | coursive | 1780 / 0.7 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `rack` / `relay-set-0` | 424 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `antenna` / `relay-set-1` | 791 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `console` / `relay-set-2` | 1159 / 0.22 | FIXTURES | Non | poste de travail |
| `rack` / `relay-set-3` | 1526 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `server` / `relay-detail-0` | 451 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `tape-reel` / `relay-detail-1` | 604 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `cable-tray` / `relay-detail-2` | 975 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `vent-cover` / `relay-detail-3` | 1346 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `wall-clock` / `relay-detail-4` | 1716 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Ligne sans réponse | 1599.0 / 0.7 | Optionnel | `archive` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 448 / 0.77 | 1 |
| `emergency-arrow` | 956 / 0.77 | 2 |
| `broken-light` | 1443 / 0.77 | 2 |
| `scorch` | 1716 / 0.77 | 3 |

**Contrôle de production :** préserver les 2 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.

### clinic_store — Réserve médicale

**Médical · niveau 0 · largeur 1700 u · profondeur 0.7–0.7**

Repère : Tiroirs de soins et stockage réfrigéré. Profil `medical` / `cold_storage` ; circuit `medical` ; 5 modules muraux déclarés.

#### Accès physiques

| Destination | Genre | Position x / z | Condition |
|---|---|---|---|
| Infirmerie | porte | 170 / 0.7 | Libre |

#### Décors placés

| Élément / ID | Position x / z | Couche | Collision | Usage |
|---|---|---|---|---|
| `medicine` / `clinic_store-set-0` | 392 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `shelf` / `clinic_store-set-1` | 698 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `fridge` / `clinic_store-set-2` | 1002 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `medicine` / `clinic_store-set-3` | 1308 / 0.22 | FIXTURES | Non | fonction propre au lieu |
| `privacy-screen` / `clinic_store-detail-0` | 638 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `oxygen` / `clinic_store-detail-1` | 527 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |
| `medical-cross` / `clinic_store-detail-2` | 850 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `wall-clock` / `clinic_store-detail-3` | 1173 / 0.7 | FIXTURES | Non | Usage quotidien, identité du lieu et orientation |
| `gurney` / `clinic_store-detail-4` | 1496 / 0.7 | ACTORS | Non | Usage quotidien, identité du lieu et orientation |

#### Objets et cachettes

| Interaction | Position x / z | Chapitre | Type |
|---|---|---|---|
| Prendre les soins d’urgence | 391 / 0.7 | 9 | `supply` |
| Dernière réserve | 1394.0 / 0.7 | Optionnel | `archive` |
| Réserve de terrain | 901.0 / 0.7 | Optionnel | `pickup` |
| Se cacher dans le placard de service | 533 / 0.7 | Optionnel | `hide` |

#### Changements visuels de crise

| Ajout | Position x / z | Dès le stade |
|---|---|---|
| `paper-trail` | 391 / 0.77 | 1 |
| `emergency-arrow` | 833 / 0.77 | 2 |
| `broken-light` | 1258 / 0.77 | 2 |
| `scorch` | 1496 / 0.77 | 3 |

**Contrôle de production :** préserver les 1 retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.
