# Recette de livraison — 0.2.0-candidate.1

Tests exécutés sur le runtime autonome et projets de test de l’installateur. Ce ne sont pas des tests du moteur Tantalus natif, ni des essais humains.

| Périmètre | Résultat | Preuve |
|---|---:|---|
| Modèle hérité | 90/90 groupes | CORE_TEST_RESULTS.json |
| Systèmes 0.2 et migration | 75/75 groupes | COLONY_TEST_RESULTS.json |
| Campagne | 6/6 parcours | TRAVERSAL_RESULTS.json |
| Installation / upgrade / rollback | 22/22 cas | INSTALLER_TEST_RESULTS.json |
| Chromium | 33/33 contrôles | BROWSER_TEST_RESULTS.json + BROWSER_V02_TEST_RESULTS.json |

Les six pilotes utilisent les déplacements, équipements, interactions, commandes de tableau et attentes du modèle. Pas de téléportation, mutation de santé, validation forcée d’objectif ou invulnérabilité. Chacun termine 49 objectifs et deux escortes. Leur durée optimisée est comprise entre 412.8 et 419.9 secondes de simulation : ce n’est PAS une estimation de durée pour un joueur.

Les tests système isolés emploient volontairement des fixtures et des mutations de position/état pour vérifier un cas précis ; ils ne doivent pas être confondus avec ces parcours. Le fichier tests/fixtures/real-v01-save.json est le véritable export de navigateur livré dans l’archive 0.1, pas un format ancien supposé. Il est chargé dans le modèle et par l’interface du navigateur.

Chromium exécute le contenu exact de JOUER.html via set_content. Une navigation locale HTTP a été essayée et bloquée (ERR_BLOCKED_BY_ADMINISTRATOR). Aucun contournement de cette politique n’a été utilisé. agent-browser est absent (commande essayée) ; Playwright et /usr/bin/chromium ont servi à la recette. L’enregistrement natif localStorage reste NON qualifié dans l’origine opaque. Le repli explicite, l’import/export et les erreurs d’import sont testés. Aucun essai Safari, Firefox, téléphone physique ou manette matérielle n’est revendiqué.

Les scènes tardives du rapport sont des sauvegardes de test validées et importées par l’interface. Ce sont des captures du jeu en exécution, pas des images d’intention ; ce n’est pas une vidéo d’une partie complète jouée manuellement.

Cette version reste un moteur autonome avec lanceur additionnel. Le moteur natif de Tantalus, ses atlas, ses sauvegardes et l’écho Frontière 2204 ne sont pas modifiés. Aucun push GitHub, build du dépôt hôte complet ou déploiement Vercel n’a été effectué. Les décors et personnages sont dessinés par code ; ce ne sont pas des assets finaux ni une reproduction photoréaliste. Le roman intégral n’a pas été consulté. Plans, tâches, dialogues, règles et documents restent une condensation originale, non une adaptation 1:1 certifiée.
