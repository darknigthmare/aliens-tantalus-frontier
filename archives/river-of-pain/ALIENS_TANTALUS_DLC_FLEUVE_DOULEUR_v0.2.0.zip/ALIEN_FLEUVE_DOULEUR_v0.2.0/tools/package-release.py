#!/usr/bin/env python3
"""Package local source, tests and evidence. No publishing and no host mutation."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
exclude={'CHECKSUMS.sha256','DELIVERY_MANIFEST.json'}
files=[]
for p in sorted(R.rglob('*')):
    if p.is_symlink():raise RuntimeError('Symlink refused: '+str(p))
    if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc' or p.name in exclude:continue
    b=p.read_bytes();files.append({'path':p.relative_to(R).as_posix(),'size':len(b),'sha256':sha(b)})
data=json.loads((R/'docs/CONTENT_MANIFEST.json').read_text())
for name in ['CORE_TEST_RESULTS','COLONY_TEST_RESULTS','INSTALLER_TEST_RESULTS','BROWSER_TEST_RESULTS','BROWSER_V02_TEST_RESULTS']:
    assert json.loads((R/'docs'/f'{name}.json').read_text())['passed'],name
manifest={'id':'river-of-pain','version':data['manifest']['version'],'delivery':'Local standalone DLC, modular source, safe optional host launcher; NOT full Tantalus game', 'published':False,'nativeEngineIntegrated':False,'inheritedBaseCommit':data['manifest']['baseCommit'],'inheritedSourceArchiveSHA256':'706eeb6b49456e4c3a4d5505380da7a17f1ddb97e1fe015a2d66371bf5f2d01c','counts':data['manifest']['counts'],'standaloneSHA256':sha((R/'JOUER.html').read_bytes()),'evidence':'docs/QA_REPORT.md','files':files,'excludedFromOwnHashList':sorted(exclude)}
(R/'DELIVERY_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(R/'CHECKSUMS.sha256').write_text(''.join(f'{f["sha256"]}  {f["path"]}\n' for f in files)+f'{sha((R/"DELIVERY_MANIFEST.json").read_bytes())}  DELIVERY_MANIFEST.json\n')
archive=R.parent/'ALIENS_TANTALUS_DLC_FLEUVE_DOULEUR_v0.2.0.zip'
paths=[R/f['path'] for f in files]+[R/'CHECKSUMS.sha256',R/'DELIVERY_MANIFEST.json']
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for p in sorted(paths):z.write(p,R.name+'/'+p.relative_to(R).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for p in paths:assert z.read(R.name+'/'+p.relative_to(R).as_posix())==p.read_bytes()
result={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'entries':len(paths),'crc':'PASS','allArchivedBytesMatchSource':True,'standalone':manifest['standaloneSHA256']}
(archive.parent/'FLEUVE_DOULEUR_v02_DELIVERY.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
