#!/usr/bin/env python3
"""Generate v02 documentation and embedded screenshot report from shipped data/evidence."""
from pathlib import Path
from html import escape
import base64, json
R=Path(__file__).resolve().parents[1]
D=json.loads((R/'docs/CONTENT_MANIFEST.json').read_text());rooms={r['id']:r for r in D['rooms']};counts=D['manifest']['counts'];version=D['manifest']['version']
limitations='''Cette version reste un moteur autonome avec lanceur additionnel. Le moteur natif de Tantalus, ses atlas, ses sauvegardes et l’écho Frontière 2204 ne sont pas modifiés. Aucun push GitHub, build du dépôt hôte complet ou déploiement Vercel n’a été effectué. Les décors et personnages sont dessinés par code ; ce ne sont pas des assets finaux ni une reproduction photoréaliste. Le roman intégral n’a pas été consulté. Plans, tâches, dialogues, règles et documents restent une condensation originale, non une adaptation 1:1 certifiée.'''
principles='''## Ce qui change réellement en 0.2

Les quatre tableaux d’alimentation et les deux collecteurs de pression remplacent les anciens simples délais d’action. Chacun possède trois commandes, une consigne, une capacité et une combinaison à respecter. Un mauvais routage ou une surcharge ne valide pas l’objectif. Le temps est suspendu pendant la lecture du tableau ; la manœuvre de 1,4 seconde s’achève ensuite dans le monde et peut être interrompue par un déplacement ou une attaque. Ce sont des puzzles discrets, pas une simulation électrique ou hydraulique scientifique.

Cinq secteurs classent l’alimentation des lieux. Habitat et maintenance passent au secours au stade 2 ; médical et recherche au stade 3 ; le périmètre ne subit pas cette coupure. Un réarmement s’applique au circuit lié à la mission, pour le stade courant. Il modifie la présentation lumineuse, les ventilateurs concernés et la perception ennemie ; une nouvelle phase peut entraîner une nouvelle panne. Une porte n’est pas arbitrairement supprimée par une coupure.

Deux jets de pression périodiques possèdent une position, une profondeur et des dégâts. Ils deviennent inoffensifs après la validation du collecteur associé. La vue latérale projette le risque sur le plan de jeu ; en profondeur, une autre allée permet de l’éviter. Le calendrier de la vapeur est une règle de gameplay.

Dix-huit cachettes utilisent un point d’entrée physique. G ou E fait entrer ; E ou une direction fait ressortir. Lampe, détecteur, tir et fusée sont neutralisés pendant la dissimulation. Un adversaire qui a vu l’entrée à courte distance peut rejoindre la cache et débusquer le joueur. Une cachette n’est donc pas une pause ni une invulnérabilité sous poursuite.

Les deux compagnons d’escorte ont une santé, une tension et un ordre suivre/attendre. Une forte tension ralentit leur marche. Rassurer nécessite la proximité et consomme du souffle ; soigner partage les trousses du joueur. Un compagnon éloigné ou en attente bloque le changement de pièce. Sa mort provoque l’échec et le retour au point de contrôle ; aucune survie historique supplémentaire n’est attribuée à cet indicateur.

Les cloisons soudées retiennent les poursuites et possèdent une intégrité. À partir du stade 2, les poursuivants peuvent éroder la soudure jusqu’à rupture. Sans pression ennemie, elle ne s’use pas toute seule. Les liens sont bidirectionnels. Certaines tâches de scénario ouvrent ou ferment réellement le lien. L’interaction E permet le déverrouillage prévu par le jeu ; les formes et durées de cette opération restent simplifiées. Newt ne peut pas utiliser B pour souder.

Chaque protagoniste conserve ses munitions, trousses, fusées et réserve de lampe entre ses chapitres. Les premières prises de contrôle donnent sa dotation propre. Le début d’un nouveau chapitre rétablit au moins 70 % de santé : il s’agit d’une assistance de progression, pas d’une guérison canonique. Les balises de repli sont communes à cette reconstitution, limitées aux douze dernières et visibles au sol ainsi que sur le plan. Le détecteur des Marines mesure uniquement les créatures vivantes de la pièce courante, pas des contacts à travers tout le graphe.

## Composition et garde-fous

Les 36 lieux restent reliés par 45 connexions bidirectionnelles. Il y a 23 étiquettes de profil architectural, plusieurs utilisant la même famille de rendu : ce ne sont pas 23 moteurs graphiques différents ni 36 illustrations uniques. Le nombre 411 compte des placements de props, pas des dessins uniques. Les 108 ajouts de crise sont des placements conditionnels séparés : papiers, flèches de repli, lampes endommagées et traces de brûlure. Les 18 cachettes sont des objets interactifs, comptés séparément.

Les pièces habitées ont un traitement domestique ; l’infirmerie et les laboratoires des travées vitrées ; les galeries des réseaux de tuyaux ; les hangars des structures de manutention ; la ruche une résine posée sur des appuis industriels. Le haut du cadre est occupé par l’architecture plutôt que par une bande vide. Les vitrages d’observation sont du décor, pas de fausses portes jouables. Les hauteurs et dimensions sont des intentions de blocage originales, non des mesures issues du livre.

Le sol et ses interactions partagent le repère du moteur. Les acteurs sont triés par profondeur. Les couvertures collisionnables demeurent les deux îlots préexistants dans les grandes salles ; leur nature graphique est adaptée au lieu. Les petits accessoires et les décors muraux sont non collisionnables. Certaines correspondances de silhouette et d’emprise demandent encore un travail d’assets final ; cette passe ne certifie pas une collision parfaite pixel par pixel.

Le renderer conserve ses parallaxes de montagnes, structures et premier plan. Les facteurs détaillés dans les métadonnées d’architecture constituent des intentions de production : ils ne sont pas tous des paramètres indépendants reliés au renderer. Les plafonds, vitrages et supports sont générés par les profils de pièce. Les ascenseurs, escaliers et véhicules restent des transitions ou postes d’interaction ; aucune cabine continue ni conduite de véhicule n’est ajoutée.

Le HUD reste au-dessus de la bande principale de marche. Le plan, l’équipement, le carnet et les tableaux suspendent la simulation. Le champ de jeu n’est pas remplacé par une page de boutons. Les raccourcis sont doublés par les menus lorsque possible ; les contrôles tactiles sont éprouvés par émulation, pas sur un téléphone physique. La manette matérielle n’est pas qualifiée.

## Coordonnées

`x` est une unité de simulation horizontale ; `z` est une profondeur normalisée, convertie en distance par le modèle. La distance du détecteur emploie une échelle de jeu. Les champs `dimensionsM`, étages et variantes sont des choix de level design, pas un relevé officiel de Hadley’s Hope. Une transition de point de vue entre chapitres n’est pas une téléportation libre du personnage.
'''
lines=['# ALIEN — Fleuve de la Douleur','',f'## Codex de level design · {version}','', 'Hadley’s Hope — Les réseaux se brisent','',limitations,'',principles,'## Campagne : tâches réellement définies','']
for c in D['chapters']:
 lines += [f"### {c['index']+1:02d} — {c['title']}",'',f"**{D['characters'][c['character']]['name']} · {c['timeLabel']} · {rooms[c['start']]['name']}**",'',c['synopsis'],'','| Étape | Lieu | Interaction | Condition nouvelle |','|---|---|---|---|']
 for i,t in enumerate(c['objectives']):
  o=next(o for o in rooms[t['room']]['objects'] if o['id']==t['id']);special='Tableau à trois commandes' if t['id'] in D['boards'] else 'Santé, tension et arrivée physique' if o['kind']=='escort' else 'Lien de cloison modifié' if t['id'] in D['doorTasks'] else 'Interaction physique héritée'
  lines.append(f"| {i+1} | {rooms[t['room']]['name']} | {o['label']} · `{o['kind']}` | {special} |")
 lines += ['',f"Dialogue original : **{c['dialogue']['speaker']}** — « {c['dialogue']['text']} »",'']
lines += ['## Tableaux et collecteurs','']
for id,b in D['boards'].items():
 lines += [f"### {b['title']} · `{id}`",'',f"{rooms[b['room']]['name']} · Circuit `{b['circuit']}` · Capacité {b['capacity']}.",'',b['hint'],'','| Commande | Charge | Réglage attendu | État initial |','|---|---:|---|---|']
 for i,c in enumerate(b['channels']):lines.append(f"| {c[0]} | {c[1]} | {'Actif / ouvert' if c[2] else 'Coupé / fermé'} | {'Actif / ouvert' if b['initial'][i] else 'Coupé / fermé'} |")
 lines += ['']
lines += ['## Registre pièce par pièce','']
for r in D['rooms']:
 a=r['architecture'];lines += [f"### {r['id']} — {r['name']}",'',f"**{r['building']} · niveau {r['floor']} · largeur {r['width']} u · profondeur {r['minZ']}–{r['maxZ']}**",'',f"Repère : {r['landmark']}. Profil `{a['style']}` / `{a['variant']}` ; circuit `{a['circuit']}` ; {a['wallModules']} modules muraux déclarés.",'','#### Accès physiques','', '| Destination | Genre | Position x / z | Condition |','|---|---|---|---|']
 for p in r['portals']:lines.append(f"| {rooms[p['to']]['name']} | {p['kind']} | {p['x']} / {p['z']} | {'Enfant' if p['childOnly'] else p['requires'] or 'Libre'} |")
 lines += ['','#### Décors placés','', '| Élément / ID | Position x / z | Couche | Collision | Usage |','|---|---|---|---|---|']
 for p in r['props']:lines.append(f"| `{p['kind']}` / `{p['id']}` | {p['x']} / {p['z']} | {p['layer']} | {'Oui' if p['collidable'] else 'Non'} | {p['purpose']} |")
 lines += ['','#### Objets et cachettes','', '| Interaction | Position x / z | Chapitre | Type |','|---|---|---|---|']
 for o in r['objects']:lines.append(f"| {o['label']} | {o['x']} / {o['z']} | {o['chapter']+1 if 'chapter' in o else 'Optionnel'} | `{o['kind']}` |")
 if r['phaseDressing']:
  lines += ['','#### Changements visuels de crise','', '| Ajout | Position x / z | Dès le stade |','|---|---|---|']
  for p in r['phaseDressing']:lines.append(f"| `{p['kind']}` | {p['x']} / {p['z']} | {p['fromPhase']} |")
 hazards=[h for h in D['hazards'] if h['room']==r['id']]
 for h in hazards:lines += ['',f"Danger `{h['id']}` à {h['x']} / {h['z']} : actif {h['activeFor']} s sur {h['period']} s ; dommage nominal {h['damage']} avec coefficient de difficulté. Neutralisation : `{h['disableFlag']}`."]
 lines += ['',f"**Contrôle de production :** préserver les {len(r['portals'])} retours de porte et les zones d’interaction. Un changement de dessin ne doit pas déplacer uniquement le seuil visuel. Ne pas placer un nouvel obstacle sur les objectifs ou fermer toutes les allées. Les décors de crise restent identifiables comme appartenant à cette pièce.",'']
(R/'docs/CODEX_LEVEL_DESIGN.md').write_text('\n'.join(lines),encoding='utf-8')
# Read completed evidence; refuse to publish a success report from an incomplete run.
files=['CORE_TEST_RESULTS.json','COLONY_TEST_RESULTS.json','INSTALLER_TEST_RESULTS.json','BROWSER_TEST_RESULTS.json','BROWSER_V02_TEST_RESULTS.json']
evidence={f:json.loads((R/'docs'/f).read_text()) for f in files};traversal=json.loads((R/'docs/TRAVERSAL_RESULTS.json').read_text())
assert all(v['passed'] for v in evidence.values()) and all(x['passed'] for x in traversal),'QA failed: do not build a success report.'
core=evidence[files[0]]['cases'];colony=evidence[files[1]]['cases'];inst=evidence[files[2]]['cases'];browser=sum(len(evidence[f]['cases']) for f in files[3:])
qa=f'''# Recette de livraison — {version}

Tests exécutés sur le runtime autonome et projets de test de l’installateur. Ce ne sont pas des tests du moteur Tantalus natif, ni des essais humains.

| Périmètre | Résultat | Preuve |
|---|---:|---|
| Modèle hérité | {core}/{core} groupes | CORE_TEST_RESULTS.json |
| Systèmes 0.2 et migration | {colony}/{colony} groupes | COLONY_TEST_RESULTS.json |
| Campagne | {len(traversal)}/{len(traversal)} parcours | TRAVERSAL_RESULTS.json |
| Installation / upgrade / rollback | {inst}/{inst} cas | INSTALLER_TEST_RESULTS.json |
| Chromium | {browser}/{browser} contrôles | BROWSER_TEST_RESULTS.json + BROWSER_V02_TEST_RESULTS.json |

Les six pilotes utilisent les déplacements, équipements, interactions, commandes de tableau et attentes du modèle. Pas de téléportation, mutation de santé, validation forcée d’objectif ou invulnérabilité. Chacun termine 49 objectifs et deux escortes. Leur durée optimisée est comprise entre {min(x['elapsedSeconds'] for x in traversal):.1f} et {max(x['elapsedSeconds'] for x in traversal):.1f} secondes de simulation : ce n’est PAS une estimation de durée pour un joueur.

Les tests système isolés emploient volontairement des fixtures et des mutations de position/état pour vérifier un cas précis ; ils ne doivent pas être confondus avec ces parcours. Le fichier tests/fixtures/real-v01-save.json est le véritable export de navigateur livré dans l’archive 0.1, pas un format ancien supposé. Il est chargé dans le modèle et par l’interface du navigateur.

Chromium exécute le contenu exact de JOUER.html via set_content. Une navigation locale HTTP a été essayée et bloquée (ERR_BLOCKED_BY_ADMINISTRATOR). Aucun contournement de cette politique n’a été utilisé. agent-browser est absent (commande essayée) ; Playwright et /usr/bin/chromium ont servi à la recette. L’enregistrement natif localStorage reste NON qualifié dans l’origine opaque. Le repli explicite, l’import/export et les erreurs d’import sont testés. Aucun essai Safari, Firefox, téléphone physique ou manette matérielle n’est revendiqué.

Les scènes tardives du rapport sont des sauvegardes de test validées et importées par l’interface. Ce sont des captures du jeu en exécution, pas des images d’intention ; ce n’est pas une vidéo d’une partie complète jouée manuellement.

{limitations}
'''
(R/'docs/QA_REPORT.md').write_text(qa)
readme=f'''# ALIEN — Fleuve de la Douleur · {version}

## Hadley’s Hope — Les réseaux se brisent

**Archive du DLC autonome et de ses sources. Ce n’est pas une archive du jeu Tantalus complet.**

{limitations}

## Jouer

Ouvrir `JOUER.html` dans un navigateur. Sous Windows, `LANCER_WINDOWS.bat` ouvre ce même fichier. L’archive doit d’abord être extraite. Le fichier autonome n’utilise aucun CDN, compte ou téléchargement d’asset.

Alternative locale avec Python : `python tools/serve.py`, puis l’adresse affichée par le serveur. Les fichiers modulaires sont dans `src/river-of-pain/index.html` ; le standalone est généré à partir des mêmes scripts.

## Contenu conservé et enrichi

16 chapitres courts, 36 lieux, 45 connexions, 49 objectifs, 24 notes originales et quatre points de vue. Cette passe ajoute 180 placements aux 231 existants, plus 108 décors conditionnels de crise, 18 cachettes, 6 tableaux et 2 jets de pression. Les 23 noms de profils architecturaux partagent certaines fonctions de rendu. Les quantités de placements ne sont pas des nombres de sprites uniques.

Les nouveautés : réseaux en secours et réarmement ; puzzles à trois commandes avec surcharge et consigne ; cachettes avec témoins ; lampe avec réserve ; détecteur local des Marines ; cloisons sous pression ennemie ; escortes avec santé, tension et ordres ; dotations conservées par protagoniste ; douze balises de repli maximum ; équipement et plan en pause. L’audio reste une ambiance et des effets synthétisés simples, pas une bande-son définitive.

## Commandes

| Action | Touche |
|---|---|
| Marcher / profondeur | Q D ou A D / Z S ou W S / flèches |
| Interagir / tirer | E / F |
| Se baisser / courir | C / Maj |
| Recharger / soins / fusée | R / H / X |
| Souder ou libérer la cloison | B, adulte équipé, près du passage |
| Équipement / plan / carnet / pause | I / Tab / J / Échap |
| Lampe / détecteur / cachette | L / T / G |
| Suivre-attendre / balise de repli | V / M |

Les actions du sac ont leurs boutons. Rassurer et soigner un compagnon se font depuis l’équipement, à proximité. Un tableau se règle avec ses trois commutateurs puis sa touche de validation ; il faut ensuite rester immobile pendant la manœuvre. Une cachette s’abandonne avec E ou une direction. Newt ne tire pas, ne lance pas de fusées et n’utilise ni le détecteur des Marines ni le poste à souder.

## Sauvegardes

Le namespace historique `atf.dlc.river-of-pain.v1.profile1` est conservé. Les exports 0.1 sans systèmes sont migrés en lecture. Les anciennes progressions sont conservées ; les détails qui n’existaient pas encore sont initialisés. Les dotations des protagonistes absents d’une ancienne sauvegarde ne peuvent pas être reconstituées rétroactivement.

Exporter un JSON depuis Pause avant de changer de version. L’import demande confirmation et refuse les fichiers étrangers ou invalides. Dans cet environnement de test, l’origine du navigateur empêche localStorage : sa persistance native n’est pas certifiée. La sauvegarde JSON et son codec ont été vérifiés, y compris avec un véritable export 0.1.

## Ajouter le lanceur à une copie de Tantalus

```sh
node tools/install.mjs "/chemin/vers/aliens-tantalus-frontier"
```

Pour une installation 0.1 existante et intacte :

```sh
node tools/install.mjs "/chemin/vers/aliens-tantalus-frontier" --upgrade
```

Le script vérifie les empreintes avant de toucher un fichier. Il refuse un index ou un module modifié, un lien symbolique, des fichiers ajoutés ou un journal incohérent. Aucun autre DLC, catalogue, package ou sauvegarde n’est remplacé. Le lanceur ouvre le runtime autonome ; il ne branche PAS ce DLC au GameEngine natif.

Retrait de l’installation gérée :

```sh
node tools/install.mjs "/chemin/vers/aliens-tantalus-frontier" --remove
```

Après upgrade, ce retrait restaure le shell d’avant le DLC, pas l’ancien runtime 0.1. Les sauvegardes de fichiers hôtes demeurent sous `.dlc-backups`. En cas de conflit de fichiers, ne pas supprimer les journaux au hasard : conserver les modifications et les rapprocher manuellement. Les tests d’installation utilisent des projets de test avec les ancrages DOM observés, pas le dépôt complet de Tantalus.

## Reproduire la recette

```sh
npm run build
npm test
python tests/browser.py
python tests/browser-v02.py
npm run docs
```

Node 20+ ; Python 3.10+ pour les scripts. Les tests de navigateur nécessitent Playwright et Chromium ; `CHROMIUM_PATH` permet de donner le chemin du binaire. Le jeu autonome n’exige aucune de ces dépendances de développement.

Résultats de cette livraison : {core} groupes hérités, {colony} groupes v02, six parcours, {inst} cas installateur et {browser} contrôles navigateur. Rapports JSON et périmètres dans `docs/`. `RAPPORT_ILLUSTRE.html` embarque ses captures ; `docs/CODEX_LEVEL_DESIGN.md` décrit toutes les pièces et leurs positions.

## Limites conservées

Pas de nouvelle fidélité 1:1 au livre. Pas de campagne plus longue promise sur la base du pilote automatique. Pas de véhicule pilotable ou d’ascenseur animé en continu. Pas de coopération réseau ni de raccord natif. Pas d’assets artistiques définitifs. Pas de publication GitHub ou Vercel. Aucune autorisation commerciale des ayants droit n’est fournie.
'''
(R/'README.md').write_text(readme)
# Bounded and explicitly labeled image selection; all are actual browser captures.
caprows=evidence['BROWSER_TEST_RESULTS.json']['captures']+evidence['BROWSER_V02_TEST_RESULTS.json']['captures'];cap={Path(c['file']).name:c for c in caprows}
selected=['09-repartiteur.png','04-infirmerie.png','10-logement.png','11-coupure.png','12-escorte.png','13-cachette.png','05-soubassements.png','14-equipement-portrait.png']
css='''*{box-sizing:border-box}body{margin:0;background:#07161c;color:#c2d0c7;font:16px/1.75 system-ui,sans-serif}main{max-width:1120px;margin:auto;padding:48px 30px 75px}header{padding:22px 0 38px;border-bottom:1px solid #355650}.eyebrow{font:11px monospace;letter-spacing:.18em;color:#9db6aa}h1{font-size:clamp(34px,5vw,60px);font-weight:450;letter-spacing:.04em;line-height:1.16;color:#e4e6cf}h2{font-size:27px;font-weight:450;color:#dce1c9;margin-top:48px}h3{font-size:17px;color:#d2dac0}.lead{font-size:23px;color:#b2c6b5}.tag{font:11px monospace;border:1px solid #657d66;padding:8px 12px;color:#cfcc99}.notice{border-left:3px solid #b2ad80;padding:19px 24px;background:#142a2d;font-size:14px}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:28px 0}.metric{padding:20px;background:#153033;border-top:1px solid #6b8b7f}.metric b{font:36px monospace;display:block;color:#dee3bd}.metric span{font:11px monospace;text-transform:uppercase;color:#aabdae}.cols{display:grid;grid-template-columns:1fr 1fr;gap:24px}.cols article{border-top:1px solid #486758;padding-top:15px}table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:13px 10px;text-align:left;border-bottom:1px solid #375148;vertical-align:top}th{font:11px monospace;color:#b1bda1}figure{margin:28px 0;background:#10282d;border:1px solid #3e5b54}figure img{width:100%;display:block}figcaption{padding:16px 20px;font-size:14px}figcaption small{display:block;font-size:11px;color:#93ab9e;margin-top:7px}.portrait{max-width:410px;margin:28px auto}code{overflow-wrap:anywhere;color:#d1c791}a{color:#d3c996}footer{margin-top:48px;border-top:1px solid #4a6359;padding-top:22px;font-size:12px;color:#94aaa0}@media(max-width:650px){main{padding:25px 16px}.metrics,.cols{grid-template-columns:1fr 1fr}.cols{grid-template-columns:1fr}td,th{padding:8px 4px}.notice{padding:15px}}'''
h=f'''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fleuve de la Douleur — Rapport 0.2</title><style>{css}</style></head><body><main><header><p class="eyebrow">ALIENS TANTALUS FRONTIER / ARCHIVES MIRE</p><h1>ALIEN<br>FLEUVE DE LA DOULEUR</h1><p class="lead">Hadley’s Hope — Les réseaux se brisent</p><span class="tag">{escape(version.upper())} · 29 SEPTEMBRE 2026 · LIVRAISON LOCALE</span></header><p class="notice"><strong>Une mise à niveau jouable de la 0.1.</strong> Le parcours reste constitué de 16 chapitres courts. Cette passe travaille les systèmes, l’identité des pièces et la continuité des sauvegardes ; ce n’est pas un DLC final ni une intégration native à Tantalus.</p><div class="metrics"><div class="metric"><b>36</b><span>Lieux reliés</span></div><div class="metric"><b>6</b><span>Tableaux fonctionnels</span></div><div class="metric"><b>18</b><span>Cachettes physiques</span></div><div class="metric"><b>+180</b><span>Placements de props</span></div></div><h2>Les changements jouables</h2><div class="cols"><article><h3>Des réseaux qui changent le parcours</h3><p>Quatre répartiteurs et deux collecteurs demandent des réglages précis. Les coupures modifient lumière et perception ; les collecteurs neutralisent deux jets de pression. Le temps suspendu dans l’interface reprend pour achever l’intervention.</p></article><article><h3>Survivre sans tout transformer en combat</h3><p>Cachettes, témoins, lampe à réserve, détecteur local et balises de repli complètent la marche. Newt ne reçoit pas l’arsenal des Marines. Les cloisons soudées peuvent céder sous une poursuite.</p></article><article><h3>Des compagnons à protéger</h3><p>Les deux escortes ont santé et tension. Attendre, suivre, rassurer et partager les trousses changent leur progression. Un compagnon perdu met fin à la tentative et renvoie au point de contrôle.</p></article><article><h3>Des pièces plus reconnaissables</h3><p>Logement, infirmerie, atelier et hangar utilisent des structures différenciées. Le registre compte 411 placements de props et 108 ajouts conditionnels de crise ; plusieurs emploient les mêmes dessins. Les visuels restent stylisés et provisoires.</p></article></div><h2>Captures de la version en exécution</h2><p>Chromium exécute le fichier autonome. Les scènes tardives sont initialisées par des sauvegardes de test importées dans le jeu. Aucune image générée d’intention ni photographie n’a été substituée au rendu.</p>'''
for i,n in enumerate(selected):
 c=cap[n];b64=base64.b64encode((R/c['file']).read_bytes()).decode();cl=' class="portrait"' if 'portrait' in n else '';setup='État de test importé par l’interface, puis commandes normales. Ce n’est pas une partie complète jouée manuellement.'
 if n=='14-equipement-portrait.png':setup+=' Émulation de viewport, pas un téléphone physique.'
 h+=f'<figure{cl}><img src="data:image/png;base64,{b64}" alt="{escape(c["description"])}"><figcaption><strong>{i+1:02d} / </strong>{escape(c["description"])}<small>{escape(setup)}</small></figcaption></figure>'
h+=f'''<h2>Recette réellement exécutée</h2><table><thead><tr><th>ÉTENDUE</th><th>RÉSULTAT</th><th>LIMITE</th></tr></thead><tbody><tr><td>Modèle hérité</td><td>{core}/{core} groupes</td><td>Pas une certification artistique.</td></tr><tr><td>Nouveaux systèmes</td><td>{colony}/{colony} groupes</td><td>Tests isolés avec fixtures explicites.</td></tr><tr><td>Parcours du modèle</td><td>6/6, deux vues × trois difficultés</td><td>49 objectifs, deux escortes. Pas d’essais humains ni de durée de jeu certifiée.</td></tr><tr><td>Installateur</td><td>{inst}/{inst} cas</td><td>Projets de test, pas build du moteur hôte complet.</td></tr><tr><td>Chromium</td><td>{browser}/{browser} contrôles</td><td>Aucune erreur JavaScript relevée. localStorage natif non qualifié.</td></tr></tbody></table><h2>Lancement et continuité</h2><p>Extraire l’archive puis ouvrir <code>JOUER.html</code>. Le jeu n’utilise pas de CDN. Le fichier autonome et les modules source exécutent le même code. Le JSON d’une sauvegarde 0.1 réelle a été migré et chargé par l’interface.</p><p>Installation neuve : <code>node tools/install.mjs DOSSIER_TANTALUS</code>. Installation 0.1 intacte : ajouter <code>--upgrade</code>. Le retrait <code>--remove</code> restaure le shell pré-DLC. Les index et modules modifiés déclenchent un refus, pas un écrasement silencieux.</p><p class="notice">{escape(limitations)} Le navigateur de test bloque HTTP local et ne fournit pas de stockage natif à son origine opaque. Import/export JSON vérifiés ; pas de qualification Safari, manette ou appareil mobile réel.</p><footer>Sources publiques et limites narratives reprises du dossier 0.1, sans nouvelle consultation du roman. Codex : <code>docs/CODEX_LEVEL_DESIGN.md</code>. Preuves détaillées : rapports JSON de <code>docs/</code>. Les captures PNG et le générateur de ce rapport sont inclus dans l’archive.</footer></main></body></html>'''
(R/'RAPPORT_ILLUSTRE.html').write_text(h,encoding='utf-8')
print(json.dumps({'version':version,'codexLines':len('\n'.join(lines).splitlines()),'reportCaptures':len(selected),'core':core,'colony':colony,'installer':inst,'browser':browser},ensure_ascii=False))
