# ALIEN — Fleuve de la Douleur · 0.2.0-candidate.1

## Hadley’s Hope — Les réseaux se brisent

**Archive du DLC autonome et de ses sources. Ce n’est pas une archive du jeu Tantalus complet.**

Cette version reste un moteur autonome avec lanceur additionnel. Le moteur natif de Tantalus, ses atlas, ses sauvegardes et l’écho Frontière 2204 ne sont pas modifiés. Aucun push GitHub, build du dépôt hôte complet ou déploiement Vercel n’a été effectué. Les décors et personnages sont dessinés par code ; ce ne sont pas des assets finaux ni une reproduction photoréaliste. Le roman intégral n’a pas été consulté. Plans, tâches, dialogues, règles et documents restent une condensation originale, non une adaptation 1:1 certifiée.

## Jouer

Ouvrir `JOUER.html` dans un navigateur. Sous Windows, `LANCER_WINDOWS.bat` ouvre ce même fichier. L’archive doit d’abord être extraite. Le fichier autonome n’utilise aucun CDN, compte ou téléchargement d’asset.

Alternative locale avec Python : `python tools/serve.py`, puis l’adresse affichée par le serveur. Les fichiers modulaires sont dans `src/river-of-pain/index.html` ; le standalone est généré à partir des mêmes scripts.

## Contenu conservé et enrichi

16 chapitres courts, 36 lieux, 45 connexions, 49 objectifs, 24 notes originales et quatre points de vue. Cette passe ajoute 180 placements aux 231 existants, plus 108 décors conditionnels de crise, 18 cachettes, 6 tableaux et 2 jets de pression. Les 23 noms de profils architecturaux partagent certaines fonctions de rendu. Les quantités de placements ne sont pas des nombres de sprites uniques.

Les nouveautés : réseaux en secours et réarmement ; puzzles à trois commandes avec surcharge et consigne ; cachettes avec témoins ; lampe avec réserve ; détecteur local des Marines ; cloisons sous pression ennemie ; escortes avec santé, tension et ordres ; dotations conservées par protagoniste ; douze balises de repli maximum ; équipement et plan en pause. L’audio reste une ambiance et des effets synthétisés simples, pas une bande-son définitive.

## Commandes

| Action | Touche |
|---|---|
| Marcher / profondeur | Q D ou A D / Z S ou W S / flèches |
| Interagir / tirer | E / F |
| Se baisser / courir | C / Maj |
| Recharger / soins / fusée | R / H / X |
| Souder ou libérer la cloison | B, adulte équipé, près du passage |
| Équipement / plan / carnet / pause | I / Tab / J / Échap |
| Lampe / détecteur / cachette | L / T / G |
| Suivre-attendre / balise de repli | V / M |

Les actions du sac ont leurs boutons. Rassurer et soigner un compagnon se font depuis l’équipement, à proximité. Un tableau se règle avec ses trois commutateurs puis sa touche de validation ; il faut ensuite rester immobile pendant la manœuvre. Une cachette s’abandonne avec E ou une direction. Newt ne tire pas, ne lance pas de fusées et n’utilise ni le détecteur des Marines ni le poste à souder.

## Sauvegardes

Le namespace historique `atf.dlc.river-of-pain.v1.profile1` est conservé. Les exports 0.1 sans systèmes sont migrés en lecture. Les anciennes progressions sont conservées ; les détails qui n’existaient pas encore sont initialisés. Les dotations des protagonistes absents d’une ancienne sauvegarde ne peuvent pas être reconstituées rétroactivement.

Exporter un JSON depuis Pause avant de changer de version. L’import demande confirmation et refuse les fichiers étrangers ou invalides. Dans cet environnement de test, l’origine du navigateur empêche localStorage : sa persistance native n’est pas certifiée. La sauvegarde JSON et son codec ont été vérifiés, y compris avec un véritable export 0.1.

## Ajouter le lanceur à une copie de Tantalus

```sh
node tools/install.mjs "/chemin/vers/aliens-tantalus-frontier"
```

Pour une installation 0.1 existante et intacte :

```sh
node tools/install.mjs "/chemin/vers/aliens-tantalus-frontier" --upgrade
```

Le script vérifie les empreintes avant de toucher un fichier. Il refuse un index ou un module modifié, un lien symbolique, des fichiers ajoutés ou un journal incohérent. Aucun autre DLC, catalogue, package ou sauvegarde n’est remplacé. Le lanceur ouvre le runtime autonome ; il ne branche PAS ce DLC au GameEngine natif.

Retrait de l’installation gérée :

```sh
node tools/install.mjs "/chemin/vers/aliens-tantalus-frontier" --remove
```

Après upgrade, ce retrait restaure le shell d’avant le DLC, pas l’ancien runtime 0.1. Les sauvegardes de fichiers hôtes demeurent sous `.dlc-backups`. En cas de conflit de fichiers, ne pas supprimer les journaux au hasard : conserver les modifications et les rapprocher manuellement. Les tests d’installation utilisent des projets de test avec les ancrages DOM observés, pas le dépôt complet de Tantalus.

## Reproduire la recette

```sh
npm run build
npm test
python tests/browser.py
python tests/browser-v02.py
npm run docs
```

Node 20+ ; Python 3.10+ pour les scripts. Les tests de navigateur nécessitent Playwright et Chromium ; `CHROMIUM_PATH` permet de donner le chemin du binaire. Le jeu autonome n’exige aucune de ces dépendances de développement.

Résultats de cette livraison : 90 groupes hérités, 75 groupes v02, six parcours, 22 cas installateur et 33 contrôles navigateur. Rapports JSON et périmètres dans `docs/`. `RAPPORT_ILLUSTRE.html` embarque ses captures ; `docs/CODEX_LEVEL_DESIGN.md` décrit toutes les pièces et leurs positions.

## Limites conservées

Pas de nouvelle fidélité 1:1 au livre. Pas de campagne plus longue promise sur la base du pilote automatique. Pas de véhicule pilotable ou d’ascenseur animé en continu. Pas de coopération réseau ni de raccord natif. Pas d’assets artistiques définitifs. Pas de publication GitHub ou Vercel. Aucune autorisation commerciale des ayants droit n’est fournie.
