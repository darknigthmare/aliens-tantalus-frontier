# Rapport QA — Alien 3 / Fiorina 161 V90

Date : 24 septembre 2026  
Base auditée : `496996f5ea557d970ec625aa346876f3eaed1c5f`  
Livraison : patch cumulatif V88 + V89 + V90

## Verdict

**PASS** sur les tests autonomes V88, V89, V90 et sur l'installation cumulative V88→V89→V90 avec désinstallation `--full`.

Le contrôle `npm run check` / `npm run build` du dépôt intégral n'est pas revendiqué dans ce rapport : cette session ne disposait pas d'un checkout complet téléchargeable du dépôt. Les ancres d'installation avaient en revanche été contrôlées contre le commit GitHub audité avant la construction du patch.

## QA V90 runtime

Commande :

```bash
node scripts/test-alien3-dlc-v90.mjs
```

Résultat : `ok: true`.

Topologie validée :

- 30 nœuds ;
- 44 connexions ;
- 4 routes principales ;
- 6 zones ;
- 30/30 nœuds physiquement connectés ;
- 4 manifolds incendiaires ;
- 6 fronts de feu ;
- 10 dossiers V90 ;
- 10 preuves V90 ;
- 3 protocoles de rejouabilité.

Parcours V90 validé :

- sélection Assembly Cut ;
- verrouillage du protocole après démarrage ;
- retrait du dossier royal prématuré après autopsie ;
- événement d'épargne V89 conservé ;
- Bishop ;
- registre des détenus V89 récupéré ;
- trois caches V88 ;
- allumeur refusé à 0/4 manifolds ;
- armement physique des 4/4 manifolds ;
- ignition et propagation des 6 segments ;
- accident du plan incendiaire ;
- retour obligatoire à l'EEV ;
- scan médical ;
- réactivation du dossier royal uniquement après le scan ;
- cuve à déchets Assembly ;
- sacrifice Junior ;
- libération Golic ;
- amorçage du plomb ;
- pressurisation de l'eau ;
- moule refusé avant préparation complète ;
- piège plomb ;
- choc thermique ;
- Patna / Compagnie ;
- Morse ;
- finale Assembly ;
- récompense finale V90.

État final V90 :

- preuves V90 : **10/10** ;
- dossiers V90 : **10/10 débloqués sur le parcours QA** ;
- preuves V89 : **10/10** dans le même parcours cumulatif ;
- manifolds : **4/4** ;
- propagation feu : **6/6** ;
- scan EEV : confirmé ;
- plomb : amorcé ;
- eau : pressurisée ;
- moule : prêt ;
- grade MIRE V90 : **S** ;
- événements observés : **194**.

Le test vérifie également la sauvegarde/reprise du schéma 90 ainsi que le protocole `mire-purist`, où les flares sont effectivement interdits.

## Régression V88

Commande :

```bash
node scripts/test-alien3-dlc-v88.mjs
```

Résultat : `ok: true`.

Contrats historiques conservés :

- 11 phases ;
- 11 chapitres ;
- 13 dossiers ;
- 20 nœuds ;
- 26 connexions ;
- 3 routes ;
- 6 zones ;
- phase finale atteinte ;
- 13 dossiers débloqués ;
- synchronisation MIRE 100 ;
- Runner neutralisé par la route environnementale ;
- route canonique validée.

## Régression V89

Commande :

```bash
node scripts/test-alien3-dlc-v89.mjs
```

Résultat : `ok: true`.

Contrats V89 conservés :

- Assembly Cut ;
- 4 routes ;
- 10/10 preuves ;
- grade MIRE S ;
- une embuscade Runner réellement déclenchée ;
- un flare physique réellement consommé ;
- un impact conventionnel réellement résisté ;
- événement d'épargne utilisé ;
- cuve Assembly et libération Golic validées ;
- 107 événements observés.

## Installation cumulative / restauration

Commande :

```bash
node scripts/test-alien3-installation-v90.mjs
```

Résultat : `ok: true`.

Le test part d'une fixture pré-DLC contenant les ancres du commit audité puis :

1. lance l'installateur V90 ;
2. vérifie l'installation automatique de V88 ;
3. vérifie l'installation automatique de V89 ;
4. vérifie V90 ;
5. lance le QA runtime V90 depuis la fixture installée ;
6. exécute `uninstall-alien3-dlc-v90.mjs --full` ;
7. compare les SHA-256 des cinq fichiers de base avant/après.

Résultat : **restauration bit-à-bit confirmée** pour :

- `src/special-operations-v67.js` ;
- `src/mission-levels-v52.js` ;
- `src/game-v52-level-runtime.js` ;
- `src/game-production-runtime.js` ;
- `src/app.js`.

Les répertoires de sauvegarde V88, V89 et V90 sont également supprimés après la désinstallation complète.

## Vérifications syntaxiques

`node --check` passe sur :

- `src/alien3-dlc-v90.js` ;
- `src/alien3-dlc-runtime-v90.js` ;
- `scripts/install-alien3-dlc-v90.mjs` ;
- `scripts/uninstall-alien3-dlc-v90.mjs` ;
- `scripts/test-alien3-dlc-v90.mjs` ;
- `scripts/test-alien3-installation-v90.mjs`.

## Points non revendiqués

- aucun push GitHub : la création de branche via l'intégration GitHub avait répondu 403 ;
- aucun déploiement Vercel ;
- aucun nouveau média audio/vidéo du film ;
- aucun test `npm run check` / `npm run build` sur le dépôt complet dans cette session ;
- aucun dialogue du scénario du film recopié : les textes narratifs sont originaux.

## Fichiers de preuve

- `qa-last-v90.json` — QA runtime V90 ;
- `qa-v88-regression-v90.json` — régression V88 ;
- `qa-v89-regression-v90.json` — régression V89 ;
- `qa-install-v90.json` — installation cumulative / restauration.
