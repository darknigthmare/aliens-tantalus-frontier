# Rapport QA — Alien 3 / Fiorina 161 V89

## Base contrôlée

- dépôt : `darknigthmare/aliens-tantalus-frontier`
- branche auditée : `main`
- commit de référence : `496996f5ea557d970ec625aa346876f3eaed1c5f`
- couche précédente : V88 Fiorina 161
- couche livrée : V89 cumulative

La connexion GitHub a permis la lecture du dépôt et la vérification des ancres d'intégration. La création d'une branche a échoué avec HTTP 403 (`Resource not accessible by integration`), donc aucune écriture distante n'a été effectuée.

## Résultat global

**PASS** pour le runtime V89, la régression V88, l'installation cumulative V88→V89 et la restauration complète.

## 1. Validation de contenu V89

`validateAlien3DlcV89()` : PASS.

| Contrat | Résultat |
|---|---:|
| Nœuds physiques | 24 |
| Connexions | 33 |
| Routes complètes | 4 |
| Zones | 6 |
| Montages | 2 |
| Dossiers MIRE V89 | 12 |
| Prisonniers suivis | 16 |
| Preuves V89 | 10 |

Les quatre routes ont des signatures distinctes, partent du spawn et rejoignent l'extraction. La quatrième route contient la salle d'assemblée, la cuve à déchets et l'écluse basse.

## 2. Parcours Assembly Cut automatisé

Commande :

```bash
node scripts/test-alien3-dlc-v89.mjs
```

Résultat : PASS.

Le test exécute en séquence :

1. sélection Assembly Cut ;
2. validation de l'EEV ;
3. autopsie ;
4. première phase Runner ;
5. attaque potentiellement létale puis épargne à 8 PV ;
6. mémoire de Bishop ;
7. registre des détenus ;
8. récupération des trois charges ;
9. lancer d'un flare physique ;
10. mise à feu des galeries ;
11. résistance du Runner aux dégâts conventionnels ;
12. consommation réelle du flare par le Runner ;
13. relocalisation d'embuscade hors caméra ;
14. blocage volontaire de la fonderie avant la cuve à déchets ;
15. sacrifice de Junior ;
16. capture du Runner ;
17. libération par Golic ;
18. décès d'Arthur et de Golic ;
19. retour du Runner ;
20. accès à la fonderie ;
21. piège au plomb ;
22. choc thermique ;
23. arrivée de la Compagnie ;
24. récupération du manifeste Patna ;
25. confrontation ;
26. déposition Morse ;
27. finale à plusieurs étapes ;
28. résolution Assembly sans émergence visible de l'embryon royal ;
29. sauvegarde ;
30. reconstruction d'un nouveau moteur et reprise du même état.

### Mesures de la passe principale

- preuves : **10/10** ;
- grade MIRE : **S** ;
- embuscades Runner confirmées : **1** ;
- flares consommés par le Runner : **1** ;
- impacts conventionnels résistés : **1** ;
- épargne déclenchée : **oui** ;
- Golic libère le Runner : **oui** ;
- Arthur enregistré mort : **oui** ;
- finale : **complete** ;
- variante : `assembly-no-emergence` ;
- événements runtime enregistrés : **107**.

## 3. Variante cinéma

Le test V89 exécute également la fin avec `cut = theatrical` et confirme :

- finale distincte ;
- `queenEmerges = true` ;
- aucune dépendance à la cuve à déchets pour cette branche.

La V88 complète est retestée séparément et reste PASS. Elle couvre le parcours historique initial avec 11 phases, 13 dossiers et les trois routes antérieures.

## 4. Régression V88

Commande :

```bash
node scripts/test-alien3-dlc-v88.mjs
```

Résultat : PASS.

Contrats conservés :

- 11 phases / 11 chapitres ;
- 13 dossiers MIRE V88 ;
- 20 nœuds ;
- 26 connexions ;
- 3 routes ;
- 6 zones ;
- Runner unique ;
- plomb fondu + choc thermique ;
- 13/13 dossiers déverrouillables ;
- récompense de Chronique persistante.

## 5. Installation cumulative / désinstallation

Commande :

```bash
node scripts/test-alien3-installation-v89.mjs
```

Résultat : PASS.

Le test crée une fixture reproduisant exactement les ancres vérifiées sur le commit audité, puis :

1. lance l'installateur V89 sans V88 ;
2. vérifie l'installation automatique de V88 ;
3. vérifie l'application de la couche V89 ;
4. lance le QA V89 depuis la fixture installée ;
5. lance le désinstalleur V89 avec `--full` ;
6. compare les SHA-256 des cinq fichiers de base avant/après.

Résultat : **restauration bit-à-bit des cinq fichiers**.

Fichiers de base vérifiés :

- `src/special-operations-v67.js`
- `src/mission-levels-v52.js`
- `src/game-v52-level-runtime.js`
- `src/game-production-runtime.js`
- `src/app.js`

## 6. Syntaxe

Tous les fichiers JavaScript/MJS du pack V88+V89 ont été passés dans `node --check` : **11/11 PASS**.

## 7. Sauvegarde / reprise

Le QA vérifie que :

- `specialOperation.alien3V89.schema === 89` ;
- le montage choisi est restauré ;
- l'état de la cuve et de Golic est restauré ;
- les preuves sont restaurées ;
- le Runner Director est restauré ;
- la finale complétée reste complétée après reprise ;
- V89 cohabite avec `alien3V88` au lieu de l'écraser.

## 8. Points non prétendus

Le shell de cette session ne dispose pas d'un checkout complet du dépôt et le téléchargement d'archive GitHub est bloqué dans l'environnement. `npm run check` et `npm run build` du **projet complet** n'ont donc pas été exécutés ici. Ce rapport ne les déclare pas comme passés.

En compensation, les cinq ancres de V88 et les quatre ancres de V89 ont été vérifiées contre le dépôt GitHub réel au commit de référence, puis les modules, le runtime et le cycle install/désinstall ont été testés localement.

## Fichiers de preuve

- `qa-last.json` : résultat runtime V89 ;
- `qa-v88-regression.json` : régression V88 ;
- `qa-install-v89.json` : intégration cumulative et restauration ;
- `PATCH_MANIFEST.json` : taille et SHA-256 des fichiers livrés.
