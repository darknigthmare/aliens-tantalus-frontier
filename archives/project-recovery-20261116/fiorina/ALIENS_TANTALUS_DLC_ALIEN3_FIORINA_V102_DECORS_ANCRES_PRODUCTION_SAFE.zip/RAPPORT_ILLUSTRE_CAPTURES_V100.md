# Alien 3 — Fiorina 161 V100 · Rapport illustré

Cette passe vérifie deux corrections de présentation demandées : **le décor commence au bord supérieur réel du champ de jeu** et **l’interface ne montre plus le vocabulaire de développement**.

## Ce qui est vérifié visuellement

- 9/9 profils de fond ancrés à `y=0` dans le runtime ;
- aucune bande vide volontaire au-dessus du décor ;
- chasse, secteurs, transitions et archives formulés pour le joueur ;
- suppression des versions, QA, runtime, graph, director, pont caméra, lane shift et autres identifiants internes de la présentation ;
- Archives de Fiorina : 90 dossiers / 7 terminaux, avec recherche, repères et dossiers liés ;
- conservation des 5 poursuites V99 et de la topologie 72 nœuds / 119 connexions / 4 routes / 6 zones.

## Captures

### Cour de la tempête

Le décor commence au bord supérieur du champ de jeu ; la chasse et les archives utilisent uniquement des libellés joueur.

![Cour de la tempête](qa_visual/screenshots-v100/01_storm_pursuit.png)

### Bloc carcéral

Passage de profondeur, anticipation du Runner et interface nettoyée dans le bloc.

![Bloc carcéral](qa_visual/screenshots-v100/02_cellblock_cutoff.png)

### Galeries techniques

Retour en passage étroit : le franchissement reste lisible sans exposer de terme de caméra ou de moteur.

![Galeries techniques](qa_visual/screenshots-v100/03_service_camera_bridge.png)

### Communications

La poursuite conserve sa pression tout en laissant l’interface parler comme le jeu, pas comme un outil de développement.

![Communications](qa_visual/screenshots-v100/04_communications_chase.png)

### Grande fonderie

Le pic de chasse V99 reste intact, mais toute sa présentation est réécrite pour le joueur.

![Grande fonderie](qa_visual/screenshots-v100/05_foundry_pressure.png)

### Archives — recherche Runner

Les Archives de Fiorina remplacent l’ancien vocabulaire de Codex technique ; catégories, recherche et dossiers liés restent fonctionnels.

![Archives — recherche Runner](qa_visual/screenshots-v100/06_codex_search.png)

### Archives — dossiers liés

Navigation entre dossiers avec intitulés naturels, repères et historique de consultation.

![Archives — dossiers liés](qa_visual/screenshots-v100/07_codex_links.png)

### Four / arrivée Patna

Décor top-aligné, franchissement naturel et dernière chasse présentée sans identifiant interne.

![Four / arrivée Patna](qa_visual/screenshots-v100/08_patna_shadow.png)

## Nature des captures

Les états proviennent de la chaîne runtime cumulative V88→V100. Le checkout GitHub complet et ses gros assets ne sont pas disponible localement dans cette session : le harness visuel substitue des **primitives industrielles déterministes** aux médias lourds. Les captures valident donc le **layout, l’état de jeu, l’ancrage du décor et l’interface V100**, et ne sont pas présentées comme des screenshots du build Vercel full-assets.

La génération est reproductible avec `qa_visual/render-captures-v100.py` et `qa_visual/capture-states-v100.json`.
