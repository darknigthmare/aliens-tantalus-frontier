# Rapport illustré — Alien 3: Fiorina 161 V98 Hybrid Director

**Nature des captures :** états produits par le runtime V88→V98, rasterisés par le harness QA procédural. Le checkout GitHub complet et ses gros assets n’étant pas disponible dans le navigateur local, ces captures valident le gameplay et les interfaces mais ne sont pas présentées comme le build Vercel full-assets.

## Résumé QA

- Secteurs hybrides : **9**
- Plans : **3**
- Codex dédié : **78/78**
- Nœuds connectés : **72/72**
- Grade : **S+++++++++**

## 01. Cour de la tempête · profondeur
Player arrière, Runner avant : démonstration de séparation de plans.
![Cour de la tempête · profondeur](qa_visual/screenshots/01_storm_depth.png)

## 02. Bloc carcéral · transition lissée
Transition arrière→avant à 54 %, avec télégraphe Runner vers l’avant.
![Bloc carcéral · transition lissée](qa_visual/screenshots/02_cellblock_shift.png)

## 03. Galeries techniques · 2D tension
Retour automatique en vue latérale stricte dans les conduits.
![Galeries techniques · 2D tension](qa_visual/screenshots/03_service_side.png)

## 04. Fonderie · chasse multi-plan
Joueur avant, Runner arrière, destination avant télégraphiée.
![Fonderie · chasse multi-plan](qa_visual/screenshots/04_foundry_hunt.png)

## 05. Codex Alien 3 V98
Interface dédiée : catégories, non-lus, favoris et 78 entrées séparées du MIRE.
![Codex Alien 3 V98](qa_visual/screenshots/05_codex_overlay.png)

## 06. Four / arrivée Patna · profondeur
Mise en scène ouverte de la confrontation avant retour final en 2D.
![Four / arrivée Patna · profondeur](qa_visual/screenshots/06_patna_depth.png)

## 07. Plateforme finale · 2D
Finale cadrée en vue latérale pour préserver précision et lisibilité.
![Plateforme finale · 2D](qa_visual/screenshots/07_final_side.png)
