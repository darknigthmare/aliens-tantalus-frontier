# Rapport d'intégration production — Alien 3 V94

## Base auditée

- Dépôt : `darknigthmare/aliens-tantalus-frontier`
- Commit de base : `496996f5ea557d970ec625aa346876f3eaed1c5f`
- Projet Vercel : `aliens-tantalus-frontier`
- Déploiement de production audité : `dpl_D6j6zYkz1ZRBVBfntRjAW6Lnwn5W`
- État : **READY**

Le journal de build Vercel de cette base confirme un clone du commit audité, l'exécution du script `node scripts/build.mjs` et une construction terminée correctement avec **3450 entrées catalogue**. Le script de build appelle lui-même `verifyPublicReleaseV86`, ce qui établit que la base utilisée par le patch est cohérente avec le contrat de distribution public.

## Pourquoi le ZIP QA n'est pas copié tel quel dans le dépôt

Le vérificateur public V86 refuse notamment les dossiers et noms privés/de production tels que `docs`, `tests`, rapports QA, captures et backups. Les installateurs de développement du DLC conservent volontairement ces éléments pour l'audit ; ils ne doivent donc pas être commités tels quels.

## Installateur production V94

Commande :

```bash
node scripts/install-alien3-dlc-v94-production.mjs /chemin/vers/aliens-tantalus-frontier
```

Il :

1. vérifie la base cible ;
2. applique V88 → V94 ;
3. retire les backups, rapports, docs et scripts QA/désinstallation qui seraient interdits par le contrat public ;
4. conserve uniquement **14 modules runtime** et les modifications des **5 fichiers de liaison** ;
5. exécute `npm run check` ;
6. exécute `npm run build` ;
7. restaure automatiquement l'état pré-DLC si une validation échoue.

## Tests de sécurité production

### Nettoyage

Résultat :

- productionSafe : **true** ;
- runtimeFiles : **14** ;
- forbiddenInjectedArtifacts : **0**.

### Rollback forcé

Un échec de validation/build a été provoqué volontairement afin de vérifier le chemin d'annulation :

- échec forcé détecté : **oui** ;
- cinq fichiers de base restaurés bit-à-bit : **oui** ;
- modules V88→V94 restant après rollback : **0**.

## GitHub

L'intégration GitHub de cette session est utilisable en lecture, mais les tentatives d'écriture ont toutes été refusées par GitHub avec `403 Resource not accessible by integration`, y compris :

- création d'une branche ;
- création d'un blob Git ;
- création d'un fichier via Contents sur la branche existante `codex/v86-public-release`.

Aucun push V94 n'a donc été simulé ou présenté comme réussi, et `main` n'a pas été modifiée.

## Conclusion

Le pack V94 est **préparé pour une intégration production transactionnelle**. Ses tests spécialisés, son nettoyage public et son rollback passent. La validation finale `npm run check` + `npm run build` sur la V94 elle-même doit être réalisée par l'installateur production dès qu'il est exécuté dans un checkout complet disposant des droits d'écriture ; en cas d'échec, le checkout est restauré automatiquement.
