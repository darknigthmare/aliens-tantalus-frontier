# Rapport QA — DLC Alien 3 / Fiorina 161 V88

## Base auditée

- Dépôt : `darknigthmare/aliens-tantalus-frontier`
- Base : `496996f5ea557d970ec625aa346876f3eaed1c5f`
- Les ancres de modification des cinq fichiers existants ont été relues sur GitHub et chacune était unique au moment de la préparation du patch.
- La création d'une branche distante a été refusée par l'intégration GitHub avec HTTP 403 ; ce livrable est donc un patch local réversible et n'est pas présenté comme déjà poussé sur `main`.

## QA runtime

Résultat : **PASS**.

- 11 phases / 11 chapitres.
- 13 entrées codex.
- 20 nœuds, 26 connexions, 6 zones et 3 routes distinctes.
- Les trois routes partent du spawn, arrivent à l'extraction et chaque segment correspond à une connexion physique déclarée.
- Un seul Runner hostile après configuration Fiorina.
- Dégâts balistiques conventionnels refusés sur le Runner.
- Plomb fondu obligatoire avant choc thermique.
- Tir remplacé par le flare.
- Solo forcé ; coop désactivée.
- Véhicule neutralisé.
- Pickup d'arme, caisse de munitions, cutter, terminaux génériques et nœuds d'objectif génériques retirés de l'archive.
- Fournitures médicales génériques conservées.
- Parcours automatique complet jusqu'à la fin.
- 13/13 dossiers MIRE déverrouillés sur la route testée.
- Sauvegarde puis restauration d'une nouvelle instance au chapitre final vérifiée.
- Récompenses finales et drapeaux `alien3Archive`, `canonRoute`, `runnerDefeated`, `mireSynchronization` vérifiés.

Le résultat machine détaillé est dans `qa-last.json`.

## QA installation / désinstallation

Résultat : **PASS** sur fixture d'intégration.

- Installation avec création des sauvegardes.
- Injection du registre Alien 3 et du moteur V88 vérifiée.
- Ajout des modules et scripts vérifié.
- Désinstallation exécutée.
- Les 5 fichiers modifiés ont été restaurés **bit-à-bit** : SHA-256 identiques avant/après.

## Vérifications syntaxiques

`node --check` : PASS sur :

- `src/alien3-dlc-v88.js`
- `src/alien3-dlc-runtime-v88.js`
- `scripts/install-alien3-dlc-v88.mjs`
- `scripts/test-alien3-dlc-v88.mjs`
- `scripts/uninstall-alien3-dlc-v88.mjs`

## Limite vérifiée explicitement

Le dépôt GitHub complet n'a pas pu être cloné depuis l'environnement d'exécution final, car l'accès réseau shell à GitHub est bloqué. Un `npm run check`/`npm run build` du dépôt entier n'est donc pas revendiqué ici. Le patch compense cela par : ancres vérifiées contre les vrais fichiers GitHub, tests runtime réels des deux nouveaux modules et test transactionnel de l'installateur/désinstallateur.
