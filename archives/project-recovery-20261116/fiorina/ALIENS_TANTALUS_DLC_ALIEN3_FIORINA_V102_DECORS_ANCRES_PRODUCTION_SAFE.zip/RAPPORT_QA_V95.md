# Rapport QA — Alien 3 Fiorina 161 V95 Living Hunt

## Résultat

**PASS** sur la couche V95 et sur la non-régression cumulative exécutée dans le pack de travail.

### Runtime V95

- validation de contenu : OK
- 72 nœuds
- 119 connexions
- 4 routes
- 6 zones
- 20 dossiers V95
- 20 preuves V95
- 4 patterns de chasse
- 10 stations V95
- 72/72 nœuds connectés
- 4/4 patterns observés dans le parcours de référence
- 4 évasions propres, 0 contact dans le run QA de référence
- une seule identité Runner observée : `enemy-006-runner`
- 13 esprits de détenus suivis dans le run QA
- 1 entraide automatique démontrée
- 0 rupture de panique dans le run de référence
- 1 transfert autonome au triage démontré
- pression logistique finale : 40
- score économie : 60
- Chase Lock : validé
- checksum MIRE final : validé
- 20/20 preuves et 20/20 dossiers débloqués
- archive parfaite V95 : validée
- grade théorique maximal : **S++++++**
- sauvegarde/reprise schéma 95 : validée
- wrapper de fin de mission : validé, récompenses V95 ajoutées à la chaîne héritée

### QA physique V95

- 72/72 nœuds connectés
- 119 connexions
- 36 connecteurs verticaux
- 177 surfaces de support simulées
- 10/10 stations V95 supportées
- 0 nœud orphelin
- extraction atteignable depuis le spawn

Une incohérence détectée pendant la passe a été corrigée : `f161-e107` reliait le poste d’observation haut aux communications par un `walk` malgré 160 unités de dénivelé. La liaison est maintenant une `ladder` explicite.

### Installation cumulative

Une fixture pré-DLC a reçu automatiquement **V88 → V95**. Les runtimes, templates, événements et notices V95 sont présents. Le test V95 et le QA physique sont exécutables après installation. `--full` restaure les cinq fichiers de base bit-à-bit.

### Production Safe

- 16 modules runtime conservés
- 0 artefact QA privé injecté dans la surface publique
- rollback forcé testé avec un `npm run check` volontairement en échec
- restauration bit-à-bit : OK
- résidu runtime après rollback : 0

### Non-régression

26 suites de régression ont été rejouées : runtimes V88→V95, topologies V91→V95, installations V89→V95 et Production Safe/rollback V93→V95. Résultat agrégé : **26/26 PASS**.

## Limite externe

Le vrai dépôt complet V95 n’a pas pu être modifié depuis cette session car l’intégration GitHub refuse les écritures avec `403 Resource not accessible by integration`. Le build complet V95 n’est donc pas revendiqué comme exécuté sur GitHub/Vercel. En revanche, l’installateur Production Safe exécute `npm run check` et `npm run build` sur un checkout complet et restaure automatiquement l’état pré-DLC en cas d’échec.
