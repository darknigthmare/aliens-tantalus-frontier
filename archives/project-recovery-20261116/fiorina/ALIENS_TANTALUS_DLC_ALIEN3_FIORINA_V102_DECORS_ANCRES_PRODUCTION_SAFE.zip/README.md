# Alien 3 — Fiorina 161 V102 · Décors ancrés

Ce paquet est un **correctif cumulatif V88–V102**, pas l’archive du jeu principal avec tous ses assets.

## Livré dans cette passe

30 ensembles fonctionnels, 284 composants, 51 formes de rendu, ancrages vérifiés sur les plateformes du plan, fonds différenciés et raccordés au haut de l’écran. Le HUD du canvas utilise trois panneaux discrets. Les 90 dossiers existants sont reformulés pour le joueur ; leurs identifiants et règles de découverte sont conservés. Le codex de conception est beaucoup plus détaillé et reste hors de l’interface du jeu.

## Consulter sans installer

- `RAPPORT_ILLUSTRE_V102.pdf` : rapport illustré, dix captures natives Chromium et portée des tests.
- `RAPPORT_ILLUSTRE_V102.html` : version autonome du rapport, images intégrées.
- `docs/ALIEN3_LEVEL_DESIGN_CODEX_V102.html` : codex de conception interactif, recherche et filtres.
- `docs/ALIEN3_LEVEL_DESIGN_CODEX_V102.md` : document source détaillé.
- `atelier/FIORINA_V102_APERCU_LOCAL.html` : banc jouable autonome, sans téléchargement d’assets.

Le banc charge les vrais modules de rendu V102 mais utilise un contrôleur simplifié, les mixins V101/V102 et des acteurs provisoires. Il ne rejoue pas la campagne complète et n’est pas le moteur de production. Les réglages de lieu servent à inspecter le décor, pas à prouver un parcours de mission.

## Installer sur une copie du projet

Décompresser ce patch **à côté** du projet, pas dedans. Les ancrages de code proviennent de la base `496996f5ea557d970ec625aa346876f3eaed1c5f` et de la V101 livrée. Le script refuse les modules historiques modifiés plutôt que de les écraser. Le dépôt complet, Node et npm sont nécessaires pour la validation de production.

```bash
node "CHEMIN_DU_PATCH/scripts/install-alien3-dlc-v102.mjs" "CHEMIN_DU_PROJET"
```

Le script travaille dans un dossier temporaire, applique l’héritage nécessaire, ajoute trois modules V102 et corrige la cible du registre de campagnes de 440 à 441. Il lance ensuite `npm run check` et `npm run build` **dans la copie de travail**. Les fichiers du projet ne sont remplacés qu’après réussite. Cette livraison n’a pas exécuté ces commandes sur le dépôt complet : les tests fournis utilisent des fixtures pour vérifier la sécurité de l’installation.

La copie publique conserve 31 modules runtime Alien 3. Sept fichiers de liaison/registre sont protégés, dont `src/content.js`. Les rapports, tests, scripts de capture et ce banc ne sont pas copiés dans la distribution du jeu. Un ancien `dist` est conservé dans la récupération externe avant son remplacement.

### Précontrôle sans écriture

```bash
node "CHEMIN_DU_PATCH/scripts/install-alien3-dlc-v102.mjs" "CHEMIN_DU_PROJET" --dry-run
```

Ce précontrôle vérifie la présence des fichiers et certains conflits ; il ne remplace pas l’installation en staging ni les tests du jeu.

### Installation explicitement sans check/build

```bash
node "CHEMIN_DU_PATCH/scripts/install-alien3-dlc-v102.mjs" "CHEMIN_DU_PROJET" --no-build
```

Cette option est réservée à l’inspection ou à une validation manuelle ultérieure. Elle ne valide pas la production.

### Restaurer

Le script imprime le chemin d’un `receipt.json` placé dans un dossier de récupération **extérieur au projet**. Garder ce dossier.

```bash
node "CHEMIN_DU_PATCH/scripts/install-alien3-dlc-v102.mjs" --restore "CHEMIN_DU_RECU/receipt.json"
```

La restauration vérifie les empreintes des fichiers et du `dist` avant d’agir. Elle refuse des modifications intervenues après installation. Les écritures sont atomiques fichier par fichier ; elles ne prétendent pas constituer une transaction insensible à une coupure électrique.

## Reproduire les contrôles

```bash
node scripts/test-alien3-dlc-v102.mjs
node scripts/test-alien3-installation-v102.mjs
python scripts/capture-alien3-v102.py
python scripts/run-alien3-regressions-v102.py
python scripts/build-alien3-reports-v102.py
```

La capture nécessite Python Playwright et Chromium. Les images sont obtenues dans le navigateur via les modules ES intégrés au HTML autonome, sans serveur ni redessin Python. Le script de rapport compose seulement la planche et la documentation à partir des captures.

## Limites importantes

Pas de build complet du dépôt, pas de publication GitHub ni de déploiement V102. Les suites historiques utilisent leurs bases isolées ; leur réussite ne prouve pas un parcours complet dans le jeu. La fidélité 1:1 au film et les sprites définitifs ne sont pas revendiqués. Les dimensions sont des unités de jeu. La topologie reste celle de V101 : 72 points, 119 connexions et quatre routes ; ce n’est pas un ajout de 72 nouvelles salles.
