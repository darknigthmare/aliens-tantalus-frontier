# Rapport QA — Alien 3 / Fiorina 161 V92

## Résultat

**PASS** sur les suites spécialisées V88, V89, V90, V91 et V92, le contrôle de topologie physique et l’installation/désinstallation cumulative.

## Runtime V92

- Validation définition : `true`
- Nœuds : **48**
- Connexions : **75**
- Routes : **4**
- Zones : **6**
- Dossiers V92 : **12/12**
- Preuves V92 : **12/12**
- Grade : **S+++**
- Volets utilisés : **2**
- Volets forcés par le Runner : **1**
- Purges vapeur : **1**
- Ordres détenus : **3**
- Feintes Runner : **1**
- Résistance flares : **0.41**
- Agressivité volets : **1.01**
- Tolérance vapeur : **0.24**
- Archive maîtresse parfaite : **true**
- Reprise sauvegarde V92 : **true**

Le test emploie deux flares physiques successifs et vérifie explicitement que le second leurre a une durée utile plus courte après adaptation. Il valide également un volet effectivement forcé par le Runner, une purge de vapeur qui casse son alerte, trois ordres de détenus, une feinte hors champ et la consolidation de l’archive maîtresse.

## Héritage cumulatif

Le run V92 maximal conserve et vérifie :

- V89 : **10/10 preuves**
- V90 : **10/10 preuves**
- V91 : **13/13 preuves**

Les suites autonomes `test-alien3-dlc-v88.mjs`, `v89`, `v90` et `v91` sont également rejouées et passent dans le pack V92.

## Topologie physique

- Nœuds connectés : **48/48**
- Connexions : **75**
- Routes complètes : **4**
- Connecteurs physiques : **18**
- Surfaces de contrôle : **124**
- Stations V92 supportées : **10/10**
- Nœuds orphelins : **0**
- Extraction accessible : **true**

## Installation / désinstallation

Le QA part d’une fixture pré-V88 compatible avec les ancres auditées. L’installateur V92 y installe automatiquement :

`V88 → V89 → V90 → V91 → V92`

Puis :

- vérifie les imports/template/runtime V92 ;
- lance le QA runtime V92 ;
- lance le QA physique V92 ;
- exécute `uninstall-alien3-dlc-v92.mjs --full` ;
- compare les SHA-256 des **5 fichiers de base** avec leurs octets initiaux.

Restauration bit-à-bit : **TRUE**.

## Ce que ce rapport ne prétend pas

Les QA spécialisés ne sont pas un substitut à `npm run check` et `npm run build` dans un checkout complet du dépôt avec tous les assets. Le pack fournit ces commandes dans le README, mais ce rapport ne les marque pas PASS tant qu’elles ne sont pas exécutées sur cette base complète.

La connexion GitHub utilisée précédemment autorise la lecture mais a refusé la création de branche avec HTTP 403 ; ce pack ne prétend donc pas avoir été poussé sur `main`.
