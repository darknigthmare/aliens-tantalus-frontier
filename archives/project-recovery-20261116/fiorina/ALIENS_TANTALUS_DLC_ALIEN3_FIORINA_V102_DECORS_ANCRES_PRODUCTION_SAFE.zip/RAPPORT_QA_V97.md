# Rapport QA — Alien 3 Fiorina 161 V97 Hybrid Archive

## Résultat

**PASS** — V97 est validée en QA spécialisé et en non-régression cumulative V88→V97.

## Vue hybride

- secteurs hybrides : 9/9 ;
- secteurs visités dans le run de référence : 9/9 ;
- transitions automatiques observées : 16 ;
- temps profondeur : 11.55 s ;
- temps 2D latéral : 11.05 s ;
- changements de plan : 3 ;
- esquives Runner inter-plan : 1 ;
- contacts Runner même-plan : 1.

La campagne utilise 5 secteurs en profondeur et 4 en 2D. Les trois plans arrière/médian/avant sont logiques et persistants. Le Runner testé reste le même acteur : le système ne génère pas une copie pour simuler la profondeur.

## Codex Alien 3 dédié

- entrées : 66 ;
- déverrouillées : 66/66 ;
- terminaux physiques : 5/5 ;
- pages explicitement consultées pendant le parcours automatisé : 6 ;
- progression sauvegardée et restaurée : True ;
- reprise : 66 entrées / 9 secteurs.

Le Codex DLC est séparé des 130 dossiers MIRE hérités V88→V96.

## Archive parfaite

- preuves V97 : 20/20 ;
- secteurs complets : True ;
- trois plans utilisés : True ;
- équilibre des deux modes : True ;
- Codex complet : True ;
- interaction Runner multi-plan validée : True ;
- Archive parfaite : True ;
- grade de référence : **S++++++++**.

`completionGrade = S` correspond au mock minimal d’empilement de récompenses : il ne rejoue volontairement pas l’intégralité des conditions parfaites des couches V88→V96 et ne doit pas être confondu avec le grade du parcours de référence.

## Topologie physique

- nœuds : 72 ; connectés : 72 ; orphelins : 0 ;
- connexions : 119 ; routes : 4 ;
- connecteurs verticaux : 36 ;
- surfaces : 177 ;
- secteurs profondeur : 5 ; secteurs 2D : 4 ;
- terminaux Codex supportés : True ;
- extraction atteignable : True.

## Installation cumulative

Installation V88→V97 : **PASS**. Versions installées : V88 → V89 → V90 → V91 → V92 → V93 → V94 → V95 → V96 → V97. Désinstallation `--full` : `fullUninstallBitPerfect = true` sur les six fichiers de base.

## Production Safe

- runtime files : 20 ;
- artefacts privés injectés restants : 0 ;
- rollback forcé : True ;
- restauration bit-perfect : True ;
- résidu runtime après rollback : 0.

## Non-régression

**36/36 suites PASS** : 10 runtimes V88→V97, 7 topologies V91→V97, 9 installations V89→V97, 5 contrôles Production Safe V93→V97 et 5 rollbacks V93→V97.

## Limite

Le vrai `npm run check` / `npm run build` du **checkout complet V97** n’a pas pu être exécuté dans cette session, car l’intégration GitHub est en lecture seule (HTTP 403 sur les écritures) et le conteneur n’a pas de clone réseau. L’installateur Production Safe est transactionnel et exécute ces deux commandes lorsqu’il est utilisé sur un checkout complet autorisé.
