import assert from 'node:assert/strict';
import { ALIEN3_CAMPAIGN_ID_V88 } from '../src/alien3-dlc-v88.js';
import { withAlien3DlcRuntimeV88 } from '../src/alien3-dlc-runtime-v88.js';
import { withAlien3DlcRuntimeV89 } from '../src/alien3-dlc-runtime-v89.js';
import { withAlien3DlcRuntimeV90 } from '../src/alien3-dlc-runtime-v90.js';
import {
  ALIEN3_CODEX_V91,
  ALIEN3_FIORINA_TEMPLATE_V91,
  ALIEN3_FOUNDRY_PISTONS_V91,
  ALIEN3_V91_EVIDENCE_IDS,
  validateAlien3DlcV91
} from '../src/alien3-dlc-v91.js';
import { withAlien3DlcRuntimeV91 } from '../src/alien3-dlc-runtime-v91.js';
import {
  ALIEN3_CODEX_V92, ALIEN3_FIORINA_TEMPLATE_V92, ALIEN3_SHUTTERS_V92, ALIEN3_STEAM_VALVES_V92,
  ALIEN3_V92_EVIDENCE_IDS, validateAlien3DlcV92
} from '../src/alien3-dlc-v92.js';
import { withAlien3DlcRuntimeV92 } from '../src/alien3-dlc-runtime-v92.js';

class MockBase {
  constructor() {
    this.events = [];
    this.images = new Map();
    this.enemies = [];
    this.doors = [];
    this.platforms = [
      { id: 'ground', x: 0, y: 510, w: 6200 },
      { id: 'deep', x: 2800, y: 630, w: 1900 },
      { id: 'high', x: 1000, y: 330, w: 5000 }
    ];
    this.player = { id: 'player', x: 180, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, actionClock: 0, fireClock: 0, vx: 0, vy: 0, facing: 1, crouching: false };
    this.coop = { id: 'coop', x: 120, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, vx: 0, vy: 0 };
    this.vehicle = { active: true, occupied: true, driver: this.player, passengers: [this.coop], x: 3200 };
    this.weaponPickup = { taken: false, x: 900 };
    this.toolPickup = { taken: false, x: 1200 };
    this.supplies = [{ type: 'ammo', amount: 24 }, { type: 'medkit', amount: 1 }];
    this.objectiveNodes = [{ id: 'generic-node' }];
    this.archiveTerminal = { recovered: false, x: 1500 };
    this.powerNode = { active: false, x: 1800 };
    this.objective = { x: 6000, y: 420, w: 68, h: 90, complete: false };
    this.missionLevelRuntime = { anchors: { extraction: { x: 6040, y: 510 } } };
    this.missionLevelVisualState = { activeZoneId: 'f161-coast' };
    this.mission = { state: 'active', objectives: { power: false, route: false, boss: false, archive: false, extract: false }, rewards: {}, retries: 0, elapsed: 100, casualties: 0 };
    this.inventory = { salvage: 0, intel: 0 };
    this.audio = { ui() {}, alarm() {}, hit() {} };
    this.camera = { x: 0, y: 0 };
    this.animationTime = 0;
    this.onEvent = (event) => this.events.push(event);
  }
  start(options = {}) { this.campaign = options.campaign; this.strategicBriefing = options.strategicBriefing; return { base: true }; }
  createEnemy(profile, index, x, groundY, options = {}) {
    return { ...profile, id: profile.id || `enemy-${index}`, x, y: groundY - 90, w: 90, h: 90, health: profile.health || 100, maxHealth: profile.health || 100, speed: profile.speed || 1, damage: profile.damage || 10, alive: true, facing: -1, alert: false, staggerClock: 0, hurtClock: 0, ...options };
  }
  initializeEnemyMissionNavigation() {}
  interact() { return false; }
  fire() { return false; }
  reload() { return true; }
  toggleVehicle() { return true; }
  useEquipment() { return true; }
  activateTracker() { return false; }
  applyEnemyDamage(enemy, amount) { enemy.health = Math.max(0, enemy.health - amount); if (enemy.health <= 0) enemy.alive = false; return amount; }
  updateEnemy() {}
  drawEnemy() {}
  defeatEnemy(enemy) { enemy.alive = false; enemy.health = 0; return true; }
  damagePlayer(actor, amount) { actor.health = Math.max(0, actor.health - amount); actor.damageTaken += amount; if (actor.health <= 0) actor.alive = false; return amount; }
  update(delta = 0.016) { this.animationTime += delta; return true; }
  missingObjectiveRequirement() { return ''; }
  missingExtractionRequirement() { return ''; }
  completeMission() { this.mission.state = 'complete'; this.mission.rewards = { credits: 100, salvage: 2, intel: 1 }; this.onEvent({ type: 'mission-complete', kills: 0, rewards: this.mission.rewards }); return true; }
  restartFromCheckpoint() { this.mission.state = 'active'; return true; }
  phaseLabel() { return 'BASE'; }
  objectiveProgressText() { return 'BASE'; }
  getInteractionPrompt() { return ''; }
  drawWorld() {}
  drawHud() {}
  captureResumeState() { return { schema: 1, player: { x: this.player.x, y: this.player.y } }; }
  applyResumeState() { return { applied: true, restored: 1 }; }
  getGameplayReport() { return { base: true }; }
  getSnapshot() { return { base: true }; }
  locked(requirement) { this.events.push({ type: 'locked', requirement }); return false; }
}

const V88 = withAlien3DlcRuntimeV88(MockBase);
const V89 = withAlien3DlcRuntimeV89(V88);
const V90 = withAlien3DlcRuntimeV90(V89);
const V91 = withAlien3DlcRuntimeV91(V90);
const Engine = withAlien3DlcRuntimeV92(V91);

const validationV91 = validateAlien3DlcV91();
assert.equal(validationV91.ok, true, validationV91.failures.join('; '));
const validation = validateAlien3DlcV92();
assert.equal(validation.ok, true, validation.failures.join('; '));
assert.equal(validation.counts.nodes, 48);
assert.equal(validation.counts.edges, 75);
assert.equal(ALIEN3_FIORINA_TEMPLATE_V92.routes.length, 4);
assert.equal(ALIEN3_CODEX_V92.length, 12);
assert.equal(ALIEN3_V92_EVIDENCE_IDS.length, 12);
assert.equal(ALIEN3_SHUTTERS_V92.length, 3);
assert.equal(ALIEN3_STEAM_VALVES_V92.length, 3);

const makeEngine = () => {
  const engine = new Engine();
  engine.start({
    campaign: { id: ALIEN3_CAMPAIGN_ID_V88 },
    strategicBriefing: { flags: { 'alien3-v90-challenge': 'archive' } },
    enemyCatalog: [{ id: 'enemy-006-runner', name: 'Runner Fiorina', biology: 'xenomorph', caste: 'runner', health: 720, damage: 29, speed: 1.9 }]
  });
  return engine;
};
const moveTo = (engine, version, stationId) => {
  const station = engine[`alien3StationV${version}`](stationId);
  assert.ok(station, stationId);
  engine.player.x = station.x;
  engine.player.y = station.y;
  return station;
};
const advance = (engine, seconds, step = 0.1) => {
  let remaining = seconds;
  while (remaining > 0) { const delta = Math.min(step, remaining); engine.update(delta); remaining -= delta; }
};

const engine = makeEngine();
assert.equal(engine.alien3V91.evidenceRecovered.length, 0);
assert.equal(engine.alien3V91.foundryChase.sequenceIndex, 0);

// Assembly Cut selected at the wreck before the archive locks.
moveTo(engine, 89, 'f161-cut-assembly-terminal');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V89.cut, 'assembly');
moveTo(engine, 90, 'f161-mire-challenge-terminal');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V90.evidenceRecovered.includes('mire-challenge'), true);
moveTo(engine, 88, 'f161-eev-recorder');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'infirmary');
moveTo(engine, 92, 'f161-master-archive-console');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V92.evidenceRecovered.includes('master-archive'), true);

// V91 makes the funeral a physical optional beat before the autopsy.
moveTo(engine, 91, 'f161-funeral-marker');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V91.evidenceRecovered.includes('funeral-rite'), true);
moveTo(engine, 88, 'f161-autopsy');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'first-blood');

// Materialize the early casualty trail without inventing extra enemies.
for (const id of ['f161-clemens-marker', 'f161-andrews-marker', 'f161-murphy-fan-marker']) {
  moveTo(engine, 91, id);
  assert.equal(engine.interact(engine.player), true, id);
}
engine.player.health = 10;
engine.damagePlayer(engine.player, 20, { source: 'Runner Fiorina' });
assert.equal(engine.player.health, 8);
assert.equal(engine.alien3V89.evidenceRecovered.includes('queen-sparing'), true);
// V92 emergency control systems are physical and adaptive.
moveTo(engine, 92, 'f161-shutter-cell');
assert.equal(engine.interact(engine.player), true);
assert.ok(engine.alien3V92.shutters['f161-shutter-cell'].closedClock > 0);
engine.alien3RunnerV88.x = 2710; engine.alien3RunnerV88.y = 420;
for (let i = 0; i < 70; i += 1) engine.updateEnemy(engine.alien3RunnerV88, 0.06);
assert.ok(engine.alien3V92.shutters['f161-shutter-cell'].breaches >= 1);
moveTo(engine, 92, 'f161-steam-service');
assert.equal(engine.interact(engine.player), true);
assert.ok(engine.alien3V92.steam['f161-steam-service'].activeClock > 0);
engine.alien3RunnerV88.x = 3180; engine.alien3RunnerV88.y = 240; engine.alien3RunnerV88.alert = true;
engine.updateEnemy(engine.alien3RunnerV88, 0.05);
assert.equal(engine.alien3RunnerV88.alert, false);
// A predictive off-screen interception unlocks the V91 heatmap evidence.
engine.alien3RunnerV88.x = 5600;
engine.alien3RunnerV88.y = 420;
engine.alien3V91.hunter.heat = 100;
engine.alien3V91.hunter.lastNoiseX = 900;
engine.camera.x = 0;
engine.updateAlien3HunterV91(0.2);
assert.ok(engine.alien3V91.hunter.predictions >= 1);
assert.equal(engine.alien3V91.evidenceRecovered.includes('runner-heatmap'), true);

// Repeated flares stay physical, but their useful life shrinks as the Runner learns the trick.
engine.alien3V90.challengeId = 'archive';
engine.alien3V88.flares = Math.max(engine.alien3V88.flares, 3);
engine.alien3V88.flareCooldown = 0;
const flaresBeforeV92 = engine.alien3V89.flares.length;
assert.equal(engine.fire(engine.player), true);
const firstV92Flare = engine.alien3V89.flares.at(-1);
assert.ok(firstV92Flare && engine.alien3V89.flares.length > flaresBeforeV92);
advance(engine, 1.25);
assert.equal(engine.fire(engine.player), true);
const secondV92Flare = engine.alien3V89.flares.at(-1);
assert.ok(engine.alien3V92.adaptation.flareResistance > 0.3);
assert.ok(secondV92Flare.maxLife < firstV92Flare.maxLife, 'flare adaptation must shorten later lure lifetime');

engine.player.x = 2800;
engine.update(0.1);
assert.equal(engine.alien3V88.phase, 'bishop');
moveTo(engine, 91, 'f161-tunnel-expedition-marker');
assert.equal(engine.interact(engine.player), true);
moveTo(engine, 88, 'f161-bishop-memory');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'trap-prep');
moveTo(engine, 89, 'f161-prison-register');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V89.evidenceRecovered.includes('prison-roster'), true);
// Preserve V90's complete physical fire plan.
for (const id of ['f161-cache-infirmary', 'f161-cache-cellblock', 'f161-cache-service']) {
  moveTo(engine, 88, id); assert.equal(engine.interact(engine.player), true, id);
}
for (const id of ['f161-fuel-a', 'f161-fuel-b', 'f161-fuel-c', 'f161-fuel-d']) {
  moveTo(engine, 90, id); assert.equal(engine.interact(engine.player), true, id);
}
moveTo(engine, 88, 'f161-fire-igniter');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'fire-maze');
advance(engine, 2.4);
assert.ok(engine.alien3V90.prisonerPlan.panic >= 40);
moveTo(engine, 91, 'f161-dillon-rally');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V91.prisonerAI.rallyCount, 1);
const woundedMorse = engine.alien3PrisonersV89.find((entry) => entry.id === 'morse');
woundedMorse.status = 'wounded';
engine.alien3V89.prisoners.morse = 'wounded';
moveTo(engine, 92, 'f161-command-rescue');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V92.prisonerCommands.woundedEvacuated.includes('morse'), true);
assert.equal(woundedMorse.status, 'wounded');
advance(engine, 1.0);
assert.equal(engine.alien3V90.firePlan.accidentResolved, true);
moveTo(engine, 90, 'f161-eev-medical-scanner');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V90.diagnosis.scanComplete, true);

// Assembly containment now waits for the Company message instead of an autonomous timer.
const waste = moveTo(engine, 89, 'f161-waste-tank-control');
engine.alien3RunnerV88.x = waste.x + 25;
engine.alien3RunnerV88.y = waste.y;
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V89.assembly.wasteTankTrapped, true);
advance(engine, 6);
assert.equal(engine.alien3V89.assembly.golicReleased, false);
assert.equal(engine.getInteractionPrompt(engine.player), 'RETOURNER AUX COMMUNICATIONS · CONTACTER LA COMPAGNIE');
moveTo(engine, 91, 'f161-company-message-console');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V91.companyDirective.messageSent, true);
advance(engine, 4.8);
assert.equal(engine.alien3V89.assembly.golicReleased, true);
assert.equal(engine.alien3V91.evidenceRecovered.includes('golic-escape-chain'), true);
moveTo(engine, 92, 'f161-command-lure');
assert.equal(engine.interact(engine.player), true);
assert.ok(engine.alien3V92.prisonerCommands.lureClock > 0);
moveTo(engine, 92, 'f161-command-seal');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V92.prisonerCommands.sealOrders, 1);
engine.alien3V91.hunter.heat = 32;
engine.alien3V92.adaptation.feintCooldown = 0;
engine.alien3RunnerV88.x = 5600; engine.alien3RunnerV88.y = 420; engine.camera.x = 0;
engine.updateAlien3FeintsV92(0.2);
assert.ok(engine.alien3V92.adaptation.feints >= 1);

engine.player.x = 4440;
engine.update(0.1);
assert.equal(engine.alien3V88.phase, 'leadworks');
moveTo(engine, 90, 'f161-lead-vat-primer'); assert.equal(engine.interact(engine.player), true);
moveTo(engine, 90, 'f161-water-header-control'); assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V90.leadworks.moldReady, true);

// The mold cannot be used until the three pistons have been cycled in order.
const mold = moveTo(engine, 88, 'f161-mold-control');
engine.alien3RunnerV88.x = mold.x + 20; engine.alien3RunnerV88.y = mold.y;
assert.equal(engine.interact(engine.player), false);
assert.match(engine.events.at(-1).requirement, /CORRIDOR DE RABATTEMENT/);
moveTo(engine, 91, 'f161-piston-b');
assert.equal(engine.interact(engine.player), false);
assert.equal(engine.alien3V91.foundryChase.wrongOrder, 1);
for (const id of ['f161-piston-a', 'f161-piston-b', 'f161-piston-c']) {
  moveTo(engine, 91, id);
  assert.equal(engine.interact(engine.player), true, id);
}
assert.equal(engine.alien3V91.foundryChase.ready, true);
assert.equal(engine.alien3V91.evidenceRecovered.includes('piston-maze'), true);

moveTo(engine, 88, 'f161-mold-control');
engine.alien3RunnerV88.x = engine.player.x + 25; engine.alien3RunnerV88.y = engine.player.y;
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'molten-lead');
moveTo(engine, 88, 'f161-sprinkler-control');
assert.equal(engine.interact(engine.player), true);
advance(engine, 1.4);
assert.equal(engine.alien3V88.phase, 'company');

// Company arrival now has a visible recovery cage and distinguishes Bishop II.
for (const id of ['f161-patna-cage', 'f161-bishop-two-marker']) {
  moveTo(engine, 91, id); assert.equal(engine.interact(engine.player), true, id);
}
moveTo(engine, 89, 'f161-patna-manifest'); assert.equal(engine.interact(engine.player), true);
moveTo(engine, 88, 'f161-company-contact'); assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'finale');
moveTo(engine, 91, 'f161-morse-custody-marker'); assert.equal(engine.interact(engine.player), true);
moveTo(engine, 89, 'f161-morse-witness-log'); assert.equal(engine.interact(engine.player), true);
engine.updateAlien3MasterArchiveV92();
assert.equal(engine.alien3V92.evidenceRecovered.includes('company-biosecurity'), true);
assert.equal(engine.alien3V92.evidenceRecovered.includes('final-telemetry'), true);
moveTo(engine, 88, 'f161-final-ledge'); assert.equal(engine.interact(engine.player), true);
advance(engine, 3.5);

assert.equal(engine.mission.state, 'complete');
assert.equal(engine.mission.rewards.alien3V91, true);
assert.equal(engine.mission.rewards.alien3V92, true);
assert.ok(['S+++', 'S++', 'S+', 'S', 'A', 'B', 'C', 'D'].includes(engine.mission.rewards.mireGradeV92));
assert.equal(engine.alien3V91.evidenceRecovered.length, ALIEN3_V91_EVIDENCE_IDS.length);
assert.equal(engine.alien3V91.codexUnlocked.length, ALIEN3_CODEX_V91.length);
assert.equal(engine.alien3V92.evidenceRecovered.length, ALIEN3_V92_EVIDENCE_IDS.length);
assert.equal(engine.alien3V92.codexUnlocked.length, ALIEN3_CODEX_V92.length);
assert.equal(engine.alien3V92.masterArchive.perfect, true);
assert.equal(engine.mission.rewards.companyChainV91.messageSent, true);
assert.equal(engine.mission.rewards.companyChainV91.cageInspected, true);
assert.equal(engine.mission.rewards.companyChainV91.bishopTwoConfirmed, true);
assert.equal(engine.mission.rewards.companyChainV91.aaronLastStand, true);
assert.equal(engine.mission.rewards.companyChainV91.morseCustody, true);

const saved = engine.captureResumeState();
assert.equal(saved.specialOperation.alien3V91.schema, 91);
assert.equal(saved.specialOperation.alien3V92.schema, 92);
const resumed = makeEngine();
const restored = resumed.applyResumeState(saved);
assert.equal(restored.applied, true);
assert.equal(resumed.alien3V91.foundryChase.ready, true);
assert.equal(resumed.alien3V91.companyDirective.messageSent, true);
assert.equal(resumed.alien3V91.evidenceRecovered.length, ALIEN3_V91_EVIDENCE_IDS.length);
assert.equal(resumed.alien3V92.evidenceRecovered.length, ALIEN3_V92_EVIDENCE_IDS.length);
assert.equal(resumed.alien3V92.masterArchive.perfect, true);

// The theatrical reconstruction does not require the Assembly-only message chain.
const theatrical = makeEngine();
assert.equal(theatrical.alien3V89.cut, 'theatrical');
assert.equal(theatrical.alien3V91.companyDirective.messageSent, false);
assert.equal(theatrical.alien3V91StationVisible(theatrical.alien3StationV91('f161-company-message-console')), false);

console.log(JSON.stringify({
  ok: true,
  validation,
  evidenceRecovered: engine.alien3V92.evidenceRecovered.length,
  codexUnlocked: engine.alien3V92.codexUnlocked.length,
  grade: engine.mission.rewards.mireGradeV92,
  adaptation: engine.mission.rewards.directorCutV92,
  tacticalSystems: engine.mission.rewards.tacticalSystemsV92,
  masterArchive: engine.mission.rewards.archiveMasterV92,
  achievements: engine.mission.rewards.v92Achievements,
  inherited: {
    v89: engine.alien3V89.evidenceRecovered.length,
    v90: engine.alien3V90.evidenceRecovered.length,
    v91: engine.alien3V91.evidenceRecovered.length
  },
  resume: { restored: restored.alien3DlcRestoredV92, evidence: resumed.alien3V92.evidenceRecovered.length }
}, null, 2));
