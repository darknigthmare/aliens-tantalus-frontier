#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(process.argv[2] || process.cwd());
const full = process.argv.includes('--full');
const backupDir = path.join(root, '.alien3-dlc-v89-backup');
const files = [
  'src/special-operations-v67.js',
  'src/mission-levels-v52.js',
  'src/game-production-runtime.js',
  'src/app.js'
];
const additions = [
  'src/alien3-dlc-v89.js',
  'src/alien3-dlc-runtime-v89.js',
  'scripts/test-alien3-dlc-v89.mjs',
  'scripts/uninstall-alien3-dlc-v89.mjs',
  'docs/ALIEN3_DLC_V89.md',
  'ALIEN3_DLC_V89_INSTALL_REPORT.json'
];
if (!fs.existsSync(backupDir)) {
  console.error('Sauvegarde .alien3-dlc-v89-backup introuvable. Désinstallation automatique impossible.');
  process.exitCode = 1;
} else {
  for (const relative of files) {
    const source = path.join(backupDir, relative);
    const target = path.join(root, relative);
    if (!fs.existsSync(source)) throw new Error(`Sauvegarde V89 manquante: ${relative}`);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(source, target);
  }
  for (const relative of additions) fs.rmSync(path.join(root, relative), { force: true });
  fs.rmSync(backupDir, { recursive: true, force: true });
  console.log('Alien 3 V89 retiré : état V88 restauré.');
  if (full) {
    const v88Uninstaller = path.join(root, 'scripts', 'uninstall-alien3-dlc-v88.mjs');
    if (fs.existsSync(v88Uninstaller)) {
      const result = spawnSync(process.execPath, [v88Uninstaller, root], { stdio: 'inherit' });
      if (result.status !== 0) process.exitCode = result.status || 1;
      else console.log('Option --full : base antérieure à V88 restaurée.');
    }
  }
}
