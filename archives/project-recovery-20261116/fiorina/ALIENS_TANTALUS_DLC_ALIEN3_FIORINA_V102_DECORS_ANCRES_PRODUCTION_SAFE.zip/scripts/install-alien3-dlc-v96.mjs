#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(process.argv[2] || process.cwd());
const patchRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXPECTED_BASE = '496996f5ea557d970ec625aa346876f3eaed1c5f';
const BACKUP_DIR = path.join(root, '.alien3-dlc-v96-backup');
const DRY_RUN = process.argv.includes('--dry-run');
const FORCE = process.argv.includes('--force');
const rel = (...parts) => path.join(...parts);
const targets = [
  rel('src','special-operations-v67.js'), rel('src','mission-levels-v52.js'), rel('src','game-production-runtime.js'),
  rel('src','app.js'), rel('src','audio-assets-v77.js')
];
const additions = [
  rel('src','alien3-dlc-v96.js'), rel('src','alien3-dlc-runtime-v96.js'), rel('scripts','test-alien3-dlc-v96.mjs'),
  rel('scripts','test-alien3-physical-v96.mjs'), rel('scripts','uninstall-alien3-dlc-v96.mjs'), rel('docs','ALIEN3_DLC_V96.md')
];

function sha256(value){ return crypto.createHash('sha256').update(value).digest('hex'); }
function read(relative){ const file=path.join(root,relative); if(!fs.existsSync(file)) throw new Error(`Fichier requis absent: ${relative}`); return fs.readFileSync(file,'utf8'); }
function replaceOnce(source,needle,replacement,label){ const first=source.indexOf(needle); if(first<0) throw new Error(`Ancre introuvable (${label}). Le projet n'est pas dans l'état V95 attendu.`); if(source.indexOf(needle,first+needle.length)>=0) throw new Error(`Ancre ambiguë (${label}). Installation arrêtée.`); return source.slice(0,first)+replacement+source.slice(first+needle.length); }
function insertAfter(source,needle,addition,label){ return replaceOnce(source,needle,needle+addition,label); }
function gitHead(){ const head=path.join(root,'.git','HEAD'); if(!fs.existsSync(head)) return null; const value=fs.readFileSync(head,'utf8').trim(); if(!value.startsWith('ref: ')) return value; const ref=path.join(root,'.git',value.slice(5)); return fs.existsSync(ref)?fs.readFileSync(ref,'utf8').trim():null; }
function ensureV95(){
  const installed=fs.existsSync(path.join(root,'src','alien3-dlc-v95.js'))&&fs.existsSync(path.join(root,'src','alien3-dlc-runtime-v95.js'));
  if(installed) return {alreadyInstalled:true,installedNow:false};
  if(DRY_RUN) return {alreadyInstalled:false,installedNow:false,wouldInstall:true};
  const installer=path.join(patchRoot,'scripts','install-alien3-dlc-v95.mjs');
  if(!fs.existsSync(installer)) throw new Error('Base V95 absente du pack V96.');
  const args=[installer,root]; if(FORCE) args.push('--force');
  const result=spawnSync(process.execPath,args,{stdio:'inherit'}); if(result.status!==0) throw new Error('Installation automatique de la base V95 impossible.');
  return {alreadyInstalled:false,installedNow:true};
}

function patchSpecialOperations(source){
  source=replaceOnce(source,
    "promiseSummary: 'Reconstruction MIRE V95 Living Hunt de Fiorina 161 : quatre cycles de chasse persistants pour un Runner unique, autonomie stress/fatigue/courage des détenus, entraide et triage, refuges limités, économie des outils, Chase Lock et checksum final.',",
    "promiseSummary: 'Reconstruction MIRE V96 Atmosphere de Fiorina 161 : six microclimats, huit cues audio optionnels avec fallback sûr, captions directionnelles du Runner, puissance/visibilité/vapeur, feedback climatique des détenus et diagnostic acoustique final.',",
    'résumé V96');
  source=replaceOnce(source,
    "'mire-master-archive', 'mire-codex-112', 'replay-challenges', 'isolated-archive-loadout']",
    "'mire-master-archive', 'zone-atmosphere-simulation', 'optional-dlc-audio-slots', 'directional-threat-captions', 'environment-power-tradeoffs', 'prisoner-climate-feedback', 'audio-fallback-safety', 'acoustic-diagnostic-gate', 'mire-codex-130', 'replay-challenges', 'isolated-archive-loadout']",
    'mécaniques V96');
  return source;
}

function patchMissionLevels(source){
  source=replaceOnce(source,"import { ALIEN3_FIORINA_PALETTE_V95, ALIEN3_FIORINA_TEMPLATE_V95 } from './alien3-dlc-v95.js';\n","import { ALIEN3_FIORINA_PALETTE_V96, ALIEN3_FIORINA_TEMPLATE_V96 } from './alien3-dlc-v96.js';\n",'import template V96');
  source=replaceOnce(source,'[ALIEN3_FIORINA_TEMPLATE_V95.id]: ALIEN3_FIORINA_PALETTE_V95,','[ALIEN3_FIORINA_TEMPLATE_V96.id]: ALIEN3_FIORINA_PALETTE_V96,','palette V96');
  source=replaceOnce(source,'[ALIEN3_FIORINA_TEMPLATE_V95.id]: ALIEN3_FIORINA_TEMPLATE_V95,','[ALIEN3_FIORINA_TEMPLATE_V96.id]: ALIEN3_FIORINA_TEMPLATE_V96,','template V96');
  return source;
}

function patchProductionRuntime(source){
  source=insertAfter(source,"import { withAlien3DlcRuntimeV95 } from './alien3-dlc-runtime-v95.js';\n","import { withAlien3DlcRuntimeV96 } from './alien3-dlc-runtime-v96.js';\n",'import runtime V96');
  source=replaceOnce(source,'const V95ProductionEngine = withAlien3DlcRuntimeV95(V94ProductionEngine);\n','const V95ProductionEngine = withAlien3DlcRuntimeV95(V94ProductionEngine);\nconst V96ProductionEngine = withAlien3DlcRuntimeV96(V95ProductionEngine);\n','chaîne moteur V96');
  source=replaceOnce(source,'export class GameEngine extends V95ProductionEngine {','export class GameEngine extends V96ProductionEngine {','moteur final V96');
  return source;
}

function patchApp(source){
  source=replaceOnce(source,
    "    ? 'Chronique MIRE V95 Living Hunt solo · 4 routes / 112 dossiers · quatre cycles de chasse · détenus autonomes · entraide/triage · refuges limités · Chase Lock · checksum final.'",
    "    ? 'Chronique MIRE V96 Atmosphere solo · 4 routes / 130 dossiers · 6 microclimats · audio optionnel/fallback · captions Runner · puissance/visibilité/vapeur · diagnostic acoustique.'",
    'notice opération V96');
  const helperAnchor=`const isAlien3V95RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v95-');\nconst alien3V95EventLabel = (event) => {\n  const detail = event.title || event.action || event.evidenceId || event.patternId || event.prisonerId || event.type.replace('alien3-v95-', '');\n  return \`MIRE 161 V95 · \${String(detail || 'LIVING HUNT').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  const helper=`const isAlien3V96RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v96-');\nconst alien3V96EventLabel = (event) => {\n  const detail = event.caption || event.title || event.action || event.evidenceId || event.cueId || event.zoneId || event.type.replace('alien3-v96-', '');\n  return \`MIRE 161 V96 · \${String(detail || 'ATMOSPHERE').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  source=insertAfter(source,helperAnchor,helper,'helpers événements V96');
  const handleAnchor=`  if (isAlien3V95RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V95EventLabel(event);\n  }\n`;
  source=insertAfter(source,handleAnchor,`  if (isAlien3V96RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V96EventLabel(event);\n  }\n`,'journal événements V96');
  const persistenceAnchor=`  const alien3V94PersistenceDue = isAlien3V94RuntimeEvent(event);\n  const alien3V95PersistenceDue = isAlien3V95RuntimeEvent(event);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue || alien3V90PersistenceDue || alien3V91PersistenceDue || alien3V92PersistenceDue || alien3V93PersistenceDue || alien3V94PersistenceDue || alien3V95PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  const replacement=`  const alien3V94PersistenceDue = isAlien3V94RuntimeEvent(event);\n  const alien3V95PersistenceDue = isAlien3V95RuntimeEvent(event);\n  const alien3V96PersistenceDue = isAlien3V96RuntimeEvent(event);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue || alien3V90PersistenceDue || alien3V91PersistenceDue || alien3V92PersistenceDue || alien3V93PersistenceDue || alien3V94PersistenceDue || alien3V95PersistenceDue || alien3V96PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  return replaceOnce(source,persistenceAnchor,replacement,'persistance événements V96');
}

function patchAudioAssets(source){
  return replaceOnce(source,
    "export const AUDIO_SLOTS_V77 = Object.freeze({ sfx: Object.freeze(['shot', 'tracker', 'hit', 'ui', 'alarm']), music: Object.freeze(['menu', 'hub', 'mission']) });",
    "export const AUDIO_SLOTS_V77 = Object.freeze({ sfx: Object.freeze(['shot', 'tracker', 'hit', 'ui', 'alarm', 'alien3-wind', 'alien3-runner', 'alien3-steam', 'alien3-mire', 'alien3-foundry', 'alien3-prison', 'alien3-company', 'alien3-heartbeat']), music: Object.freeze(['menu', 'hub', 'mission']) });",
    'slots audio V96');
}

function run(){
  if(fs.existsSync(path.join(root,'src','alien3-dlc-v96.js'))&&!FORCE) throw new Error('Le DLC Alien 3 V96 semble déjà installé.');
  const v95=ensureV95();
  if(DRY_RUN&&v95.wouldInstall){ console.log(JSON.stringify({schema:96,dryRun:true,prerequisite:'V95 (and V94…V88) would be installed first',expectedBaseCommit:EXPECTED_BASE},null,2)); return; }
  for(const relative of targets) read(relative);
  for(const relative of additions) if(!fs.existsSync(path.join(patchRoot,relative))) throw new Error(`Fichier du patch absent: ${relative}`);
  const head=gitHead(); if(head&&head!==EXPECTED_BASE&&!FORCE) console.warn(`[WARN] HEAD ${head} diffère de la base auditée ${EXPECTED_BASE}; V96 vérifie les ancres V95 avant écriture.`);
  const originals=Object.fromEntries(targets.map((relative)=>[relative,read(relative)]));
  const patched={
    [rel('src','special-operations-v67.js')]:patchSpecialOperations(originals[rel('src','special-operations-v67.js')]),
    [rel('src','mission-levels-v52.js')]:patchMissionLevels(originals[rel('src','mission-levels-v52.js')]),
    [rel('src','game-production-runtime.js')]:patchProductionRuntime(originals[rel('src','game-production-runtime.js')]),
    [rel('src','app.js')]:patchApp(originals[rel('src','app.js')]),
    [rel('src','audio-assets-v77.js')]:patchAudioAssets(originals[rel('src','audio-assets-v77.js')])
  };
  const report={schema:96,name:'Alien 3 — Fiorina 161 DLC V96 Atmosphere',expectedBaseCommit:EXPECTED_BASE,detectedHead:head,v95InstalledByThisRun:v95.installedNow,dryRun:DRY_RUN,
    modified:Object.entries(patched).map(([relative,content])=>({file:relative,beforeSha256:sha256(originals[relative]),afterSha256:sha256(content),beforeBytes:Buffer.byteLength(originals[relative]),afterBytes:Buffer.byteLength(content)})),
    added:additions.map((relative)=>({file:relative,sha256:sha256(fs.readFileSync(path.join(patchRoot,relative)))}))};
  if(DRY_RUN){console.log(JSON.stringify(report,null,2));return;}
  fs.mkdirSync(BACKUP_DIR,{recursive:true});
  try{
    for(const [relative,content] of Object.entries(originals)){const backup=path.join(BACKUP_DIR,relative);fs.mkdirSync(path.dirname(backup),{recursive:true});fs.writeFileSync(backup,content);}
    for(const [relative,content] of Object.entries(patched)) fs.writeFileSync(path.join(root,relative),content);
    for(const relative of additions){const target=path.join(root,relative);fs.mkdirSync(path.dirname(target),{recursive:true});fs.copyFileSync(path.join(patchRoot,relative),target);}
    fs.writeFileSync(path.join(root,'ALIEN3_DLC_V96_INSTALL_REPORT.json'),JSON.stringify(report,null,2));
  }catch(error){for(const [relative,content] of Object.entries(originals)){try{fs.writeFileSync(path.join(root,relative),content);}catch{}}for(const relative of additions){try{fs.rmSync(path.join(root,relative),{force:true});}catch{}}throw error;}
  console.log('Alien 3 — Fiorina 161 V96 Atmosphere installé.');
  console.log('V96 est cumulatif : V88 à V95 restent les couches de base.');
  console.log('Lancez : node scripts/test-alien3-dlc-v96.mjs && node scripts/test-alien3-physical-v96.mjs && npm run check && npm run build');
}
try{run();}catch(error){console.error('[ALIEN3 V96] Installation annulée:',error.message);process.exitCode=1;}
