import assert from 'node:assert/strict';
import {
  ALIEN3_DEPTH_OCCLUDERS_V98,
  ALIEN3_DLC_CODEX_TERMINALS_V98,
  ALIEN3_DLC_CODEX_V98,
  ALIEN3_FIORINA_TEMPLATE_V98,
  ALIEN3_HYBRID_DIRECTOR_PROFILES_V98,
  validateAlien3DlcV98
} from '../src/alien3-dlc-v98.js';
import { ALIEN3_HYBRID_SECTORS_V97 } from '../src/alien3-dlc-v97.js';

const validation=validateAlien3DlcV98();assert.equal(validation.ok,true,validation.failures.join('; '));
const nodes=ALIEN3_FIORINA_TEMPLATE_V98.nodes;const edges=ALIEN3_FIORINA_TEMPLATE_V98.edges;const routes=ALIEN3_FIORINA_TEMPLATE_V98.routes;
const nodeMap=new Map(nodes.map((entry)=>[entry.id,entry]));
const platforms=nodes.map((entry)=>({id:`node-${entry.id}`,x:entry.x-entry.width/2,y:entry.y,w:entry.width,nodeId:entry.id}));const connectors=[];
for(const edge of edges){
  const from=nodeMap.get(edge.from),to=nodeMap.get(edge.to);assert.ok(from&&to,`${edge.id} missing endpoint`);
  if(['walk','slope','airlock','gate'].includes(edge.kind)){
    const span=Math.hypot(to.x-from.x,to.y-from.y);const steps=Math.max(1,Math.ceil(span/210),Math.ceil(Math.abs(to.y-from.y)/10));const stepWidth=edge.kind==='slope'?Math.min(240,Math.abs(to.x-from.x)/steps+8):240;
    for(let step=1;step<steps;step+=1){const p=step/steps;platforms.push({id:`${edge.id}-step-${step}`,x:from.x+(to.x-from.x)*p-stepWidth/2,y:from.y+(to.y-from.y)*p,w:stepWidth,edgeId:edge.id});}
    if(edge.kind==='walk')assert.ok(Math.abs(from.y-to.y)<=72,`${edge.id} hides inaccessible verticality`);
  }
  if(edge.kind==='ladder'||edge.kind==='lift'){
    const connectorX=Number.isFinite(edge.connectorOffsetFromTo)?to.x+edge.connectorOffsetFromTo:(from.x+to.x)/2;const padding=34;
    for(const endpoint of [from,to]){if(Math.abs(endpoint.x-connectorX)<=endpoint.width/2-24)continue;platforms.push({id:`${edge.id}-${endpoint.id}-approach`,x:Math.min(endpoint.x,connectorX)-padding,y:endpoint.y,w:Math.abs(endpoint.x-connectorX)+padding*2,edgeId:edge.id});}
    connectors.push({id:edge.id,x:connectorX,top:Math.min(from.y,to.y),bottom:Math.max(from.y,to.y)});assert.ok(Math.abs(from.y-to.y)>=48,`${edge.id} meaningless vertical span`);
  }
}
const supports=(x,y,tolerance=58)=>platforms.some((platform)=>Math.abs(Number(platform.y)-y)<=tolerance&&x>=Number(platform.x)-tolerance&&x<=Number(platform.x)+Number(platform.w)+tolerance);
for(const connector of connectors){assert.ok(supports(connector.x,connector.top,30),`${connector.id} top unsupported`);assert.ok(supports(connector.x,connector.bottom,30),`${connector.id} bottom unsupported`);}
for(const terminal of ALIEN3_DLC_CODEX_TERMINALS_V98){const footY=terminal.y+terminal.h;const centerX=terminal.x+terminal.w/2;assert.ok(supports(centerX,footY,58),`${terminal.id} has no physical support`);assert.ok(terminal.lane>=0&&terminal.lane<=2,`${terminal.id} invalid lane`);}
for(const occluder of ALIEN3_DEPTH_OCCLUDERS_V98){assert.ok(occluder.x0>=0&&occluder.x1<=ALIEN3_FIORINA_TEMPLATE_V98.dimensions.width&&occluder.x1>occluder.x0,`${occluder.id} invalid span`);assert.ok(occluder.lane>=0&&occluder.lane<=2,`${occluder.id} invalid lane`);const mid=(occluder.x0+occluder.x1)/2;assert.ok(ALIEN3_HYBRID_SECTORS_V97.some((sector)=>sector.mode==='depth'&&mid>=sector.x0&&mid<sector.x1),`${occluder.id} placed outside a depth sector`);}
const degree=new Map(nodes.map((node)=>[node.id,0]));const adjacency=new Map(nodes.map((node)=>[node.id,[]]));for(const edge of edges){degree.set(edge.from,degree.get(edge.from)+1);degree.set(edge.to,degree.get(edge.to)+1);adjacency.get(edge.from).push(edge.to);if(!edge.oneWay)adjacency.get(edge.to).push(edge.from);}for(const node of nodes)assert.ok(degree.get(node.id)>0,`${node.id} orphan`);
const spawnId=nodes.find((node)=>node.anchor==='spawn')?.id;const extractionId=nodes.find((node)=>node.anchor==='extraction')?.id;assert.ok(spawnId&&extractionId,'spawn/extraction anchors required');const reached=new Set([spawnId]),queue=[spawnId];while(queue.length){const current=queue.shift();for(const next of adjacency.get(current)||[]){if(reached.has(next))continue;reached.add(next);queue.push(next);}}
assert.equal(reached.size,nodes.length,`physical graph disconnected: ${reached.size}/${nodes.length}`);assert.ok(reached.has(extractionId),'extraction not reachable');
for(const route of routes){assert.equal(route.nodeIds[0],spawnId,`${route.id} does not start at spawn`);assert.equal(route.nodeIds.at(-1),extractionId,`${route.id} does not end at extraction`);for(let i=1;i<route.nodeIds.length;i+=1){const from=route.nodeIds[i-1],to=route.nodeIds[i];assert.ok(edges.some((edge)=>(edge.from===from&&edge.to===to)||(!edge.oneWay&&edge.from===to&&edge.to===from)),`${route.id} broken at ${from}>${to}`);}}
const sectors=[...ALIEN3_HYBRID_SECTORS_V97].sort((a,b)=>a.x0-b.x0);assert.equal(sectors[0].x0,0);assert.equal(sectors.at(-1).x1,ALIEN3_FIORINA_TEMPLATE_V98.dimensions.width);for(let i=1;i<sectors.length;i+=1)assert.equal(sectors[i-1].x1,sectors[i].x0,`hybrid boundary mismatch ${sectors[i-1].id}/${sectors[i].id}`);
assert.equal(ALIEN3_HYBRID_DIRECTOR_PROFILES_V98.length,sectors.length);for(const sector of sectors){const profile=ALIEN3_HYBRID_DIRECTOR_PROFILES_V98.find((entry)=>entry.sectorId===sector.id);assert.ok(profile,`profile missing ${sector.id}`);assert.equal(profile.mode,sector.mode,`profile mode mismatch ${sector.id}`);}
assert.equal(new Set(ALIEN3_DLC_CODEX_V98.map((e)=>e.id)).size,ALIEN3_DLC_CODEX_V98.length);
console.log(JSON.stringify({ok:true,nodes:nodes.length,edges:edges.length,routes:routes.length,connectedNodes:reached.size,connectors:connectors.length,platforms:platforms.length,hybridSectors:sectors.length,directorProfiles:ALIEN3_HYBRID_DIRECTOR_PROFILES_V98.length,depthOccluders:ALIEN3_DEPTH_OCCLUDERS_V98.length,codexTerminals:ALIEN3_DLC_CODEX_TERMINALS_V98.length,allCodexTerminalsSupported:true,dedicatedCodex:ALIEN3_DLC_CODEX_V98.length,orphanNodes:0,extractionReachable:true},null,2));
