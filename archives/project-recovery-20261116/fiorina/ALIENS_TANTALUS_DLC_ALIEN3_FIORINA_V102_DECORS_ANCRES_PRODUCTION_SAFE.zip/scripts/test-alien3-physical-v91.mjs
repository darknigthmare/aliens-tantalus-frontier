import assert from 'node:assert/strict';
import { ALIEN3_FIORINA_TEMPLATE_V91, ALIEN3_V91_STATIONS } from '../src/alien3-dlc-v91.js';

const nodes = ALIEN3_FIORINA_TEMPLATE_V91.nodes;
const edges = ALIEN3_FIORINA_TEMPLATE_V91.edges;
const nodeMap = new Map(nodes.map((entry) => [entry.id, entry]));
const platforms = nodes.map((entry) => ({ id: `node-${entry.id}`, x: entry.x - entry.width / 2, y: entry.y, w: entry.width, nodeId: entry.id }));
const connectors = [];
for (const edge of edges) {
  const from = nodeMap.get(edge.from); const to = nodeMap.get(edge.to);
  assert.ok(from && to, edge.id);
  if (['walk', 'slope', 'airlock', 'gate'].includes(edge.kind)) {
    const distance = Math.hypot(to.x - from.x, to.y - from.y);
    const steps = Math.max(1, Math.ceil(distance / 210), Math.ceil(Math.abs(to.y - from.y) / 10));
    const stepWidth = edge.kind === 'slope' ? Math.min(240, Math.abs(to.x - from.x) / steps + 8) : 240;
    for (let step = 1; step < steps; step += 1) {
      const progress = step / steps;
      platforms.push({ id: `${edge.id}-step-${step}`, x: from.x + (to.x - from.x) * progress - stepWidth / 2, y: from.y + (to.y - from.y) * progress, w: stepWidth, edgeId: edge.id });
    }
    if (edge.kind === 'walk') assert.ok(Math.abs(from.y - to.y) <= 72, `${edge.id} hides inaccessible verticality`);
  }
  if (edge.kind === 'ladder' || edge.kind === 'lift') {
    const connectorX = (from.x + to.x) / 2;
    const padding = 34;
    for (const endpoint of [from, to]) {
      if (Math.abs(endpoint.x - connectorX) <= endpoint.width / 2 - 24) continue;
      platforms.push({ x: Math.min(endpoint.x, connectorX) - padding, y: endpoint.y, w: Math.abs(endpoint.x - connectorX) + padding * 2, edgeId: edge.id });
    }
    connectors.push({ id: edge.id, x: connectorX, top: Math.min(from.y, to.y), bottom: Math.max(from.y, to.y) });
    assert.ok(Math.abs(from.y - to.y) >= 48, `${edge.id} meaningless vertical span`);
  }
}
const supports = (x, y, tolerance = 28) => platforms.some((platform) => Math.abs(Number(platform.y) - y) <= tolerance && x >= Number(platform.x) - tolerance && x <= Number(platform.x) + Number(platform.w) + tolerance);
for (const connector of connectors) {
  assert.ok(supports(connector.x, connector.top), `${connector.id} top unsupported`);
  assert.ok(supports(connector.x, connector.bottom), `${connector.id} bottom unsupported`);
}
for (const station of ALIEN3_V91_STATIONS) {
  const footY = station.y + station.h;
  const centerX = station.x + station.w / 2;
  assert.ok(supports(centerX, footY, 54), `${station.id} has no physical support`);
}
const degree = new Map(nodes.map((node) => [node.id, 0]));
for (const edge of edges) { degree.set(edge.from, degree.get(edge.from) + 1); degree.set(edge.to, degree.get(edge.to) + 1); }
for (const node of nodes) assert.ok(degree.get(node.id) > 0, `${node.id} orphan`);
assert.equal(new Set(ALIEN3_V91_STATIONS.map((entry) => entry.id)).size, ALIEN3_V91_STATIONS.length);
console.log(JSON.stringify({ ok: true, nodes: nodes.length, edges: edges.length, connectors: connectors.length, platforms: platforms.length, stations: ALIEN3_V91_STATIONS.length, allStationsSupported: true, orphanNodes: 0 }, null, 2));
