#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(process.argv[2] || process.cwd());
const patchRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXPECTED_BASE = '496996f5ea557d970ec625aa346876f3eaed1c5f';
const BACKUP_DIR = path.join(root, '.alien3-dlc-v93-backup');
const DRY_RUN = process.argv.includes('--dry-run');
const FORCE = process.argv.includes('--force');
const rel = (...parts) => path.join(...parts);

const targets = [
  rel('src', 'special-operations-v67.js'),
  rel('src', 'mission-levels-v52.js'),
  rel('src', 'game-production-runtime.js'),
  rel('src', 'app.js')
];
const additions = [
  rel('src', 'alien3-dlc-v93.js'),
  rel('src', 'alien3-dlc-runtime-v93.js'),
  rel('scripts', 'test-alien3-dlc-v93.mjs'),
  rel('scripts', 'test-alien3-physical-v93.mjs'),
  rel('scripts', 'uninstall-alien3-dlc-v93.mjs'),
  rel('docs', 'ALIEN3_DLC_V93.md')
];

function sha256(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function read(relative) {
  const file = path.join(root, relative);
  if (!fs.existsSync(file)) throw new Error(`Fichier requis absent: ${relative}`);
  return fs.readFileSync(file, 'utf8');
}
function replaceOnce(source, needle, replacement, label) {
  const first = source.indexOf(needle);
  if (first < 0) throw new Error(`Ancre introuvable (${label}). Le projet n'est pas dans l'état V92 attendu.`);
  if (source.indexOf(needle, first + needle.length) >= 0) throw new Error(`Ancre ambiguë (${label}). Installation arrêtée.`);
  return source.slice(0, first) + replacement + source.slice(first + needle.length);
}
function insertAfter(source, needle, addition, label) { return replaceOnce(source, needle, needle + addition, label); }
function gitHead() {
  const head = path.join(root, '.git', 'HEAD');
  if (!fs.existsSync(head)) return null;
  const value = fs.readFileSync(head, 'utf8').trim();
  if (!value.startsWith('ref: ')) return value;
  const ref = path.join(root, '.git', value.slice(5));
  return fs.existsSync(ref) ? fs.readFileSync(ref, 'utf8').trim() : null;
}
function ensureV92() {
  const installed = fs.existsSync(path.join(root, 'src', 'alien3-dlc-v92.js'))
    && fs.existsSync(path.join(root, 'src', 'alien3-dlc-runtime-v92.js'));
  if (installed) return { alreadyInstalled: true, installedNow: false };
  if (DRY_RUN) return { alreadyInstalled: false, installedNow: false, wouldInstall: true };
  const installer = path.join(patchRoot, 'scripts', 'install-alien3-dlc-v92.mjs');
  if (!fs.existsSync(installer)) throw new Error('Base V92 absente du pack V93.');
  const args = [installer, root];
  if (FORCE) args.push('--force');
  const result = spawnSync(process.execPath, args, { stdio: 'inherit' });
  if (result.status !== 0) throw new Error('Installation automatique de la base V92 impossible.');
  return { alreadyInstalled: false, installedNow: true };
}

function patchSpecialOperations(source) {
  source = replaceOnce(
    source,
    "promiseSummary: 'Reconstruction MIRE V92 de Fiorina 161 : Runner adaptatif aux habitudes, volets d’urgence destructibles, purges de vapeur, ordres physiques aux détenus, archive maîtresse, checkpoints narratifs et fonderie intégrale cumulative.',",
    "promiseSummary: 'Reconstruction MIRE V93 de Fiorina 161 : Living Cast complet, beats historiques jouables sans couper les contrôles, routines individuelles des détenus, perchoirs adaptatifs du Runner, pourparlers Patna et chaîne Aaron/Morse intégrée.',",
    'résumé V93'
  );
  source = replaceOnce(
    source,
    "requiredMechanics: ['single-runner-predator', 'predictive-runner-heatmap', 'adaptive-tool-memory', 'no-firearms', 'persistent-flare-lures', 'emergency-shutters', 'steam-noise-masking', 'prisoner-tactical-orders', 'fiorina-prison-metroidvania', 'four-route-topology', 'living-historical-beats', 'physical-quinitricetyline-plan', 'fire-propagation', 'post-fire-eev-scan', 'theatrical-assembly-cuts', 'waste-tank-containment', 'company-directive-before-golic-release', 'named-prisoner-tasking', 'three-piston-foundry-chase', 'causal-lead-water-prep', 'molten-lead-trap', 'thermal-shock-finale', 'patna-cage-and-company-sequence', 'bishop-two-aaron-morse-finale', 'mire-master-archive', 'mire-codex-60', 'replay-challenges', 'isolated-archive-loadout']",
    "requiredMechanics: ['single-runner-predator', 'predictive-runner-heatmap', 'adaptive-tool-memory', 'runner-perch-hunting', 'player-habit-learning', 'no-firearms', 'persistent-flare-lures', 'emergency-shutters', 'steam-noise-masking', 'prisoner-tactical-orders', 'individual-prisoner-routines', 'avoidable-exposure-risk', 'fiorina-prison-metroidvania', 'four-route-topology', 'living-historical-beats', 'seamless-cinematic-beats', 'physical-quinitricetyline-plan', 'fire-propagation', 'post-fire-eev-scan', 'theatrical-assembly-cuts', 'waste-tank-containment', 'company-directive-before-golic-release', 'named-prisoner-tasking', 'three-piston-foundry-chase', 'causal-lead-water-prep', 'molten-lead-trap', 'thermal-shock-finale', 'patna-parley-and-cage', 'bishop-two-aaron-morse-finale', 'mire-master-archive', 'mire-codex-74', 'replay-challenges', 'isolated-archive-loadout']",
    'mécaniques V93'
  );
  return source;
}

function patchMissionLevels(source) {
  source = replaceOnce(
    source,
    "import { ALIEN3_FIORINA_PALETTE_V92, ALIEN3_FIORINA_TEMPLATE_V92 } from './alien3-dlc-v92.js';\n",
    "import { ALIEN3_FIORINA_PALETTE_V93, ALIEN3_FIORINA_TEMPLATE_V93 } from './alien3-dlc-v93.js';\n",
    'import template V93'
  );
  source = replaceOnce(source, '[ALIEN3_FIORINA_TEMPLATE_V92.id]: ALIEN3_FIORINA_PALETTE_V92,', '[ALIEN3_FIORINA_TEMPLATE_V93.id]: ALIEN3_FIORINA_PALETTE_V93,', 'palette V93');
  source = replaceOnce(source, '[ALIEN3_FIORINA_TEMPLATE_V92.id]: ALIEN3_FIORINA_TEMPLATE_V92,', '[ALIEN3_FIORINA_TEMPLATE_V93.id]: ALIEN3_FIORINA_TEMPLATE_V93,', 'template V93');
  return source;
}

function patchProductionRuntime(source) {
  source = insertAfter(
    source,
    "import { withAlien3DlcRuntimeV92 } from './alien3-dlc-runtime-v92.js';\n",
    "import { withAlien3DlcRuntimeV93 } from './alien3-dlc-runtime-v93.js';\n",
    'import runtime V93'
  );
  source = replaceOnce(
    source,
    'const V92ProductionEngine = withAlien3DlcRuntimeV92(V91ProductionEngine);\n',
    'const V92ProductionEngine = withAlien3DlcRuntimeV92(V91ProductionEngine);\nconst V93ProductionEngine = withAlien3DlcRuntimeV93(V92ProductionEngine);\n',
    'chaîne moteur V93'
  );
  source = replaceOnce(source, 'export class GameEngine extends V92ProductionEngine {', 'export class GameEngine extends V93ProductionEngine {', 'moteur final V93');
  return source;
}

function patchApp(source) {
  source = replaceOnce(
    source,
    "    ? 'Chronique MIRE V92 solo · 4 routes / 60 dossiers · Runner adaptatif aux habitudes · volets d’urgence · vapeur tactique · ordres aux détenus · archive maîtresse · fonderie cumulative.'",
    "    ? 'Chronique MIRE V93 solo · 4 routes / 74 dossiers · Living Cast · beats historiques jouables · routines détenus · perchoirs du Runner · pourparlers Patna · finale Aaron/Morse.'",
    'notice opération V93'
  );
  const helperAnchor = `const isAlien3V92RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v92-');\nconst alien3V92EventLabel = (event) => {\n  const detail = event.title || event.action || event.evidenceId || event.shutterId || event.valveId || event.prisonerId || event.phase || event.type.replace('alien3-v92-', '');\n  return \`MIRE 161 V92 · \${String(detail || 'ARCHIVE MAÎTRESSE').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  const helper = `const isAlien3V93RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v93-');\nconst alien3V93EventLabel = (event) => {\n  const detail = event.title || event.action || event.evidenceId || event.beatId || event.perchId || event.prisonerId || event.type.replace('alien3-v93-', '');\n  return \`MIRE 161 V93 · \${String(detail || 'LIVING CAST').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  source = insertAfter(source, helperAnchor, helper, 'helpers événements V93');

  const handleAnchor = `  if (isAlien3V92RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V92EventLabel(event);\n  }\n`;
  source = insertAfter(source, handleAnchor, `  if (isAlien3V93RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V93EventLabel(event);\n  }\n`, 'journal événements V93');

  const persistenceAnchor = `  const alien3V92PersistenceDue = isAlien3V92RuntimeEvent(event)\n    && event.type !== 'alien3-v92-checkpoint';\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue || alien3V90PersistenceDue || alien3V91PersistenceDue || alien3V92PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  const persistenceReplacement = `  const alien3V92PersistenceDue = isAlien3V92RuntimeEvent(event)\n    && event.type !== 'alien3-v92-checkpoint';\n  const alien3V93PersistenceDue = isAlien3V93RuntimeEvent(event);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue || alien3V90PersistenceDue || alien3V91PersistenceDue || alien3V92PersistenceDue || alien3V93PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  source = replaceOnce(source, persistenceAnchor, persistenceReplacement, 'persistance événements V93');
  return source;
}

function run() {
  if (fs.existsSync(path.join(root, 'src', 'alien3-dlc-v93.js')) && !FORCE) throw new Error('Le DLC Alien 3 V93 semble déjà installé.');
  const v92 = ensureV92();
  if (DRY_RUN && v92.wouldInstall) {
    console.log(JSON.stringify({ schema: 93, dryRun: true, prerequisite: 'V92 (and V91/V90/V89/V88) would be installed first', expectedBaseCommit: EXPECTED_BASE }, null, 2));
    return;
  }
  for (const relative of targets) read(relative);
  for (const relative of additions) if (!fs.existsSync(path.join(patchRoot, relative))) throw new Error(`Fichier du patch absent: ${relative}`);
  const head = gitHead();
  if (head && head !== EXPECTED_BASE && !FORCE) console.warn(`[WARN] HEAD ${head} diffère de la base auditée ${EXPECTED_BASE}; V93 vérifie les ancres V92 avant écriture.`);

  const originals = Object.fromEntries(targets.map((relative) => [relative, read(relative)]));
  const patched = {
    [rel('src', 'special-operations-v67.js')]: patchSpecialOperations(originals[rel('src', 'special-operations-v67.js')]),
    [rel('src', 'mission-levels-v52.js')]: patchMissionLevels(originals[rel('src', 'mission-levels-v52.js')]),
    [rel('src', 'game-production-runtime.js')]: patchProductionRuntime(originals[rel('src', 'game-production-runtime.js')]),
    [rel('src', 'app.js')]: patchApp(originals[rel('src', 'app.js')])
  };
  const report = {
    schema: 93,
    name: 'Alien 3 — Fiorina 161 DLC V93',
    expectedBaseCommit: EXPECTED_BASE,
    detectedHead: head,
    v92InstalledByThisRun: v92.installedNow,
    dryRun: DRY_RUN,
    modified: Object.entries(patched).map(([relative, content]) => ({
      file: relative,
      beforeSha256: sha256(originals[relative]),
      afterSha256: sha256(content),
      beforeBytes: Buffer.byteLength(originals[relative]),
      afterBytes: Buffer.byteLength(content)
    })),
    added: additions.map((relative) => ({ file: relative, sha256: sha256(fs.readFileSync(path.join(patchRoot, relative))) }))
  };
  if (DRY_RUN) { console.log(JSON.stringify(report, null, 2)); return; }

  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  try {
    for (const [relative, content] of Object.entries(originals)) {
      const backup = path.join(BACKUP_DIR, relative);
      fs.mkdirSync(path.dirname(backup), { recursive: true });
      fs.writeFileSync(backup, content);
    }
    for (const [relative, content] of Object.entries(patched)) fs.writeFileSync(path.join(root, relative), content);
    for (const relative of additions) {
      const target = path.join(root, relative);
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.copyFileSync(path.join(patchRoot, relative), target);
    }
    fs.writeFileSync(path.join(root, 'ALIEN3_DLC_V93_INSTALL_REPORT.json'), JSON.stringify(report, null, 2));
  } catch (error) {
    for (const [relative, content] of Object.entries(originals)) { try { fs.writeFileSync(path.join(root, relative), content); } catch {} }
    for (const relative of additions) { try { fs.rmSync(path.join(root, relative), { force: true }); } catch {} }
    throw error;
  }
  console.log('Alien 3 — Fiorina 161 V93 installé.');
  console.log('V93 est cumulatif : V88 à V92 sont conservés comme couches de base.');
  console.log('Lancez : node scripts/test-alien3-dlc-v93.mjs && node scripts/test-alien3-physical-v93.mjs && npm run check && npm run build');
}

try { run(); }
catch (error) { console.error('[ALIEN3 V93] Installation annulée:', error.message); process.exitCode = 1; }
