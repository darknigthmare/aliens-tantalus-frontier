#!/usr/bin/env node
/** Stage first, validate, then commit only the allowlisted files. Backups are outside
 * the public distribution. Existing runtime, dist, audio manifest and docs survive failure. */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
export const VERSION=102;
export const BASE_FILES=['src/special-operations-v67.js','src/mission-levels-v52.js','src/game-v52-level-runtime.js','src/game-production-runtime.js','src/app.js','src/audio-assets-v77.js','src/content.js'];
export const RUNTIME_FILES=[...Array.from({length:14},(_,i)=>88+i).flatMap(v=>[`src/alien3-dlc-v${v}.js`,`src/alien3-dlc-runtime-v${v}.js`]),'src/alien3-dlc-v102.js','src/alien3-dlc-runtime-v102.js','src/alien3-art-v102.js'];
const PATCH_ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const exists=p=>fs.existsSync(p);
const once=(s,a,b)=>{if(s.split(a).length!==2)throw Error(`Ancre absente ou ambiguë : ${a.slice(0,70)}`);return s.replace(a,b);};
function listFiles(root){let out=[];function walk(dir,prefix=''){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){if(!prefix&&['.git','node_modules','.vercel','dist'].includes(entry.name))continue;const rel=prefix+entry.name;if(entry.isSymbolicLink())throw Error(`Lien symbolique refusé : ${rel}`);if(entry.isDirectory())walk(path.join(dir,entry.name),rel+'/');else out.push(rel);}}walk(root);return out;}
function treeDigest(dir){if(!exists(dir))return null;const records=[];function walk(d,p=''){for(const e of fs.readdirSync(d,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){if(e.isSymbolicLink())throw Error('Lien symbolique refusé dans dist.');const rel=p+e.name;if(e.isDirectory())walk(path.join(d,e.name),rel+'/');else records.push([rel,hash(fs.readFileSync(path.join(d,e.name)))]);}}walk(dir);return hash(JSON.stringify(records));}
function run(script,args,cwd){const r=spawnSync(process.execPath,[script,...args],{cwd,encoding:'utf8',maxBuffer:20*1024*1024});if(r.status!==0)throw Error((r.stderr||r.stdout||String(r.error)).slice(-5000));return r.stdout;}
function removeInjected(stage,originals){for(let v=88;v<=101;v++){for(const rel of [`ALIEN3_DLC_V${v}_INSTALL_REPORT.json`,`docs/ALIEN3_DLC_V${v}.md`,`scripts/test-alien3-dlc-v${v}.mjs`,`scripts/test-alien3-physical-v${v}.mjs`,`scripts/uninstall-alien3-dlc-v${v}.mjs`,...(v===101?['docs/ALIEN3_LEVEL_DESIGN_CODEX_V101.md']:[])]){if(!originals.has(rel))fs.rmSync(path.join(stage,rel),{force:true});}
 const b=`.alien3-dlc-v${v}-backup`;if(![...originals].some(x=>x.startsWith(b+'/')))fs.rmSync(path.join(stage,b),{force:true,recursive:true});}
 const d=path.join(stage,'docs');if(exists(d)&&fs.readdirSync(d).length===0)fs.rmdirSync(d);
}
function writeAtomic(file,bytes){fs.mkdirSync(path.dirname(file),{recursive:true});const tmp=file+'.a3-v102-'+crypto.randomBytes(8).toString('hex')+'.tmp';try{fs.writeFileSync(tmp,bytes,{flag:'wx'});fs.renameSync(tmp,file);}finally{fs.rmSync(tmp,{force:true});}}
export function install(root,{noBuild=false,dryRun=false}={}){
 root=path.resolve(root);if(root===PATCH_ROOT||root.startsWith(PATCH_ROOT+path.sep))throw Error('Le projet cible doit être distinct du dossier du patch.');
 if(fs.lstatSync(root).isSymbolicLink())throw Error('Racine symbolique refusée.');
 if(exists(path.join(root,'dist'))&&fs.lstatSync(path.join(root,'dist')).isSymbolicLink())throw Error('dist symbolique refusé.');
 const originals=new Set(listFiles(root));for(const rel of BASE_FILES)if(!originals.has(rel))throw Error(`Fichier de base absent : ${rel}`);
 if(originals.has('src/alien3-dlc-v102.js'))throw Error('V102 déjà présente. Restaurer ou vérifier la version existante.');
 const actual=fs.readFileSync(path.join(root,'src/game-production-runtime.js'),'utf8');
 if(originals.has('src/alien3-dlc-v101.js')){
  if(!actual.includes('export class GameEngine extends V101ProductionEngine {'))throw Error('V101 présente mais liaison du moteur différente : aucune écriture.');
  for(const rel of RUNTIME_FILES.filter(f=>!/v102/.test(f))){if(!originals.has(rel)||hash(fs.readFileSync(path.join(root,rel)))!==hash(fs.readFileSync(path.join(PATCH_ROOT,rel))))throw Error(`Module local modifié : ${rel}. Fusion manuelle nécessaire.`);}
 }
 if(dryRun)return {ok:true,dryRun:true,target:root,baseFiles:BASE_FILES,runtimeModules:RUNTIME_FILES.length,checks:noBuild?[]:['npm run check','npm run build'],writes:0};
 const stage=fs.mkdtempSync(path.join(os.tmpdir(),'alien3-v102-stage-'));let recovery=null,committed=[];
 try{
  fs.cpSync(root,stage,{recursive:true,filter:source=>{const rel=path.relative(root,source);return !rel||!['.git','node_modules','.vercel','dist'].includes(rel.split(path.sep)[0]);}});
  if(!exists(path.join(stage,'src/alien3-dlc-v101.js')))run(path.join(PATCH_ROOT,'scripts/install-alien3-dlc-v101.mjs'),[stage],stage);
  let engine=fs.readFileSync(path.join(stage,'src/game-production-runtime.js'),'utf8');
  engine=once(engine,"import { withAlien3DlcRuntimeV101 } from './alien3-dlc-runtime-v101.js';","import { withAlien3DlcRuntimeV101 } from './alien3-dlc-runtime-v101.js';\nimport { withAlien3DlcRuntimeV102 } from './alien3-dlc-runtime-v102.js';");
  engine=once(engine,'const V101ProductionEngine = withAlien3DlcRuntimeV101(V100ProductionEngine);','const V101ProductionEngine = withAlien3DlcRuntimeV101(V100ProductionEngine);\nconst V102ProductionEngine = withAlien3DlcRuntimeV102(V101ProductionEngine);');
  engine=once(engine,'export class GameEngine extends V101ProductionEngine {','export class GameEngine extends V102ProductionEngine {');fs.writeFileSync(path.join(stage,'src/game-production-runtime.js'),engine);
  let content=fs.readFileSync(path.join(stage,'src/content.js'),'utf8');
  if(content.includes('campaigns: 440'))content=once(content,'campaigns: 440','campaigns: 441');else if(!content.includes('campaigns: 441'))throw Error('Contrat de campagnes non reconnu ; aucune écriture.');
  fs.writeFileSync(path.join(stage,'src/content.js'),content);
  for(const rel of RUNTIME_FILES.filter(f=>/v102/.test(f)))fs.copyFileSync(path.join(PATCH_ROOT,rel),path.join(stage,rel));
  removeInjected(stage,originals);
  const checks=[];
  if(!noBuild){
   if(!exists(path.join(stage,'package.json')))throw Error('package.json absent pour la validation complète.');
   for(const task of ['check','build']){const r=spawnSync(process.platform==='win32'?'npm.cmd':'npm',['run',task],{cwd:stage,encoding:'utf8',maxBuffer:30*1024*1024});if(r.status!==0)throw Error(`npm run ${task} : ${r.stderr||r.stdout||r.error}`);checks.push(`npm run ${task}`);}
  }
  const candidates=[...BASE_FILES,...RUNTIME_FILES];const audio='assets/audio/manifest.json';if(exists(path.join(stage,audio)))candidates.push(audio);
  const changes=candidates.filter(rel=>exists(path.join(stage,rel))&&(!exists(path.join(root,rel))||hash(fs.readFileSync(path.join(root,rel)))!==hash(fs.readFileSync(path.join(stage,rel)))));
  recovery=fs.mkdtempSync(path.join(path.dirname(root),'.alien3-v102-recovery-'));
  const receipt={schema:102,root,checksRun:checks,createdAt:new Date().toISOString(),files:[],distChanged:!noBuild&&exists(path.join(stage,'dist')),distBefore:treeDigest(path.join(root,'dist')),distAfter:!noBuild?treeDigest(path.join(stage,'dist')):null};
  for(const rel of changes){const before=exists(path.join(root,rel))?fs.readFileSync(path.join(root,rel)):null;if(before){const b=path.join(recovery,'files',rel);fs.mkdirSync(path.dirname(b),{recursive:true});fs.writeFileSync(b,before);}receipt.files.push({path:rel,existed:!!before,before:before?hash(before):null,after:hash(fs.readFileSync(path.join(stage,rel)))});}
  // Persist recovery bytes BEFORE the first write.
  fs.writeFileSync(path.join(recovery,'receipt.json'),JSON.stringify(receipt,null,2));
  try{
   for(const rel of changes){writeAtomic(path.join(root,rel),fs.readFileSync(path.join(stage,rel)));committed.push(rel);}
   if(receipt.distChanged){if(exists(path.join(root,'dist')))fs.renameSync(path.join(root,'dist'),path.join(recovery,'dist-before'));fs.cpSync(path.join(stage,'dist'),path.join(root,'dist'),{recursive:true});}
  }catch(error){
   for(const rel of committed){const entry=receipt.files.find(e=>e.path===rel);if(entry.existed)writeAtomic(path.join(root,rel),fs.readFileSync(path.join(recovery,'files',rel)));else fs.rmSync(path.join(root,rel),{force:true});}
   if(receipt.distChanged){fs.rmSync(path.join(root,'dist'),{recursive:true,force:true});if(exists(path.join(recovery,'dist-before')))fs.renameSync(path.join(recovery,'dist-before'),path.join(root,'dist'));}
   throw error;
  }
  return {ok:true,schema:102,checksRun:checks,fullBuildValidated:!noBuild,runtimeModules:RUNTIME_FILES.length,campaignTarget:441,changedFiles:changes.length,recoveryReceipt:path.join(recovery,'receipt.json'),preservesPreviousRuntimeOnFailure:true};
 }finally{fs.rmSync(stage,{recursive:true,force:true});}
}
export function restore(receiptPath){
 const recovery=path.dirname(path.resolve(receiptPath));const r=JSON.parse(fs.readFileSync(receiptPath,'utf8'));
 if(r.schema!==102||!path.isAbsolute(r.root)||!Array.isArray(r.files))throw Error('Reçu de restauration invalide.');
 if(fs.lstatSync(r.root).isSymbolicLink()||fs.lstatSync(recovery).isSymbolicLink())throw Error('Racine symbolique refusée.');
 listFiles(r.root);listFiles(recovery);
 const allowed=new Set([...BASE_FILES,...RUNTIME_FILES,'assets/audio/manifest.json']);
 for(const f of r.files){if(!allowed.has(f.path)||!exists(path.join(r.root,f.path))||hash(fs.readFileSync(path.join(r.root,f.path)))!==f.after)throw Error(`Modification post-installation ou chemin refusé : ${f.path}`);if(f.existed&&hash(fs.readFileSync(path.join(recovery,'files',f.path)))!==f.before)throw Error('Sauvegarde de récupération altérée.');}
 // Guard both sources and built output against post-install user edits.
 if(r.distChanged){if(treeDigest(path.join(r.root,'dist'))!==r.distAfter)throw Error('dist modifié après installation ; restauration refusée.');if(treeDigest(path.join(recovery,'dist-before'))!==r.distBefore)throw Error('Ancien dist de récupération altéré.');}
 for(const f of r.files){if(f.existed)writeAtomic(path.join(r.root,f.path),fs.readFileSync(path.join(recovery,'files',f.path)));else fs.rmSync(path.join(r.root,f.path),{force:true});}
 if(r.distChanged){fs.rmSync(path.join(r.root,'dist'),{recursive:true,force:true});if(r.distBefore!==null)fs.renameSync(path.join(recovery,'dist-before'),path.join(r.root,'dist'));}
 return {ok:true,restoredFiles:r.files.length,distRestored:r.distChanged,root:r.root};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{const args=process.argv.slice(2);const out=args[0]==='--restore'?restore(args[1]):install(args[0]||process.cwd(),{noBuild:args.includes('--no-build'),dryRun:args.includes('--dry-run')});console.log(JSON.stringify(out,null,2));}
 catch(e){console.error('Installation annulée : '+e.message);process.exitCode=1;}
}
