import assert from 'node:assert/strict';
import { ALIEN3_CAMPAIGN_ID_V88 } from '../src/alien3-dlc-v88.js';
import { withAlien3DlcRuntimeV88 } from '../src/alien3-dlc-runtime-v88.js';
import { withAlien3DlcRuntimeV89 } from '../src/alien3-dlc-runtime-v89.js';
import { withAlien3DlcRuntimeV90 } from '../src/alien3-dlc-runtime-v90.js';
import { withAlien3DlcRuntimeV91 } from '../src/alien3-dlc-runtime-v91.js';
import { withAlien3DlcRuntimeV92 } from '../src/alien3-dlc-runtime-v92.js';
import { withAlien3DlcRuntimeV93 } from '../src/alien3-dlc-runtime-v93.js';
import { withAlien3DlcRuntimeV94 } from '../src/alien3-dlc-runtime-v94.js';
import {
  ALIEN3_CODEX_V95,
  ALIEN3_FIORINA_TEMPLATE_V95,
  ALIEN3_HUNT_PATTERNS_V95,
  ALIEN3_V95_EVIDENCE_IDS,
  ALIEN3_V95_STATIONS,
  alien3V95Grade,
  validateAlien3DlcV95
} from '../src/alien3-dlc-v95.js';
import { withAlien3DlcRuntimeV95 } from '../src/alien3-dlc-runtime-v95.js';

class MockBase {
  constructor() {
    this.events = [];
    this.images = new Map();
    this.enemies = [];
    this.doors = [];
    this.platforms = [
      { id: 'ground', x: 0, y: 510, w: 6200 },
      { id: 'deep', x: 0, y: 630, w: 6200 },
      { id: 'high', x: 0, y: 330, w: 6200 },
      { id: 'perch', x: 0, y: 190, w: 6200 }
    ];
    this.player = { id: 'player', x: 180, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, actionClock: 0, fireClock: 0, vx: 0, vy: 0, facing: 1, crouching: false };
    this.coop = { id: 'coop', x: 120, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, vx: 0, vy: 0 };
    this.vehicle = { active: true, occupied: false, driver: null, passengers: [], x: 3200 };
    this.weaponPickup = { taken: false, x: 900 };
    this.toolPickup = { taken: false, x: 1200 };
    this.supplies = [];
    this.objectiveNodes = [];
    this.archiveTerminal = { recovered: false, x: 1500 };
    this.powerNode = { active: false, x: 1800 };
    this.objective = { x: 6000, y: 420, w: 68, h: 90, complete: false };
    this.missionLevelRuntime = { anchors: { extraction: { x: 6040, y: 510 } } };
    this.missionLevelVisualState = { activeZoneId: 'f161-coast' };
    this.mission = { state: 'active', objectives: { power: false, route: false, boss: false, archive: false, extract: false }, rewards: {}, retries: 0, elapsed: 0, casualties: 0 };
    this.inventory = { salvage: 0, intel: 0 };
    this.audio = { ui() {}, alarm() {}, hit() {} };
    this.camera = { x: 0, y: 0 };
    this.animationTime = 0;
    this.onEvent = (event) => this.events.push(event);
  }
  start(options = {}) { this.campaign = options.campaign; this.strategicBriefing = options.strategicBriefing; return { base: true }; }
  createEnemy(profile, index, x, groundY, options = {}) {
    return { ...profile, id: profile.id || `enemy-${index}`, x, y: groundY - 90, w: 90, h: 90, health: profile.health || 100, maxHealth: profile.health || 100, speed: profile.speed || 1, damage: profile.damage || 10, alive: true, facing: -1, alert: false, staggerClock: 0, hurtClock: 0, ...options };
  }
  initializeEnemyMissionNavigation() {}
  interact() { return false; }
  fire() { return false; }
  reload() { return true; }
  toggleVehicle() { return true; }
  useEquipment() { return true; }
  activateTracker() { return false; }
  applyEnemyDamage(enemy, amount) { enemy.health = Math.max(0, enemy.health - amount); if (enemy.health <= 0) enemy.alive = false; return amount; }
  updateEnemy() {}
  drawEnemy() {}
  defeatEnemy(enemy) { enemy.alive = false; enemy.health = 0; return true; }
  damagePlayer(actor, amount) { actor.health = Math.max(0, actor.health - amount); actor.damageTaken += amount; if (actor.health <= 0) actor.alive = false; return amount; }
  update(delta = 0.016) { this.animationTime += delta; return true; }
  missingObjectiveRequirement() { return ''; }
  missingExtractionRequirement() { return ''; }
  completeMission() { this.mission.state = 'complete'; this.mission.rewards = { credits: 100 }; this.onEvent({ type: 'mission-complete', rewards: this.mission.rewards }); return true; }
  restartFromCheckpoint() { this.mission.state = 'active'; return true; }
  phaseLabel() { return 'BASE'; }
  objectiveProgressText() { return 'BASE'; }
  getInteractionPrompt() { return ''; }
  drawWorld() {}
  drawHud() {}
  captureResumeState() { return { schema: 1, player: { x: this.player.x, y: this.player.y } }; }
  applyResumeState() { return { applied: true, restored: 1 }; }
  getGameplayReport() { return { base: true }; }
  getSnapshot() { return { base: true }; }
  locked(requirement) { this.events.push({ type: 'locked', requirement }); return false; }
}

const V88 = withAlien3DlcRuntimeV88(MockBase);
const V89 = withAlien3DlcRuntimeV89(V88);
const V90 = withAlien3DlcRuntimeV90(V89);
const V91 = withAlien3DlcRuntimeV91(V90);
const V92 = withAlien3DlcRuntimeV92(V91);
const V93 = withAlien3DlcRuntimeV93(V92);
const V94 = withAlien3DlcRuntimeV94(V93);
const Engine = withAlien3DlcRuntimeV95(V94);

const validation = validateAlien3DlcV95();
assert.equal(validation.ok, true, validation.failures.join('; '));
assert.equal(validation.counts.nodes, 72);
assert.equal(validation.counts.edges, 119);
assert.equal(ALIEN3_FIORINA_TEMPLATE_V95.routes.length, 4);
assert.equal(ALIEN3_CODEX_V95.length, 20);
assert.equal(ALIEN3_V95_EVIDENCE_IDS.length, 20);
assert.equal(ALIEN3_HUNT_PATTERNS_V95.length, 4);
assert.equal(ALIEN3_V95_STATIONS.length, 10);

const engine = new Engine();
engine.start({
  campaign: { id: ALIEN3_CAMPAIGN_ID_V88 },
  strategicBriefing: { flags: { 'alien3-v90-challenge': 'archive' } },
  enemyCatalog: [{ id: 'enemy-006-runner', name: 'Runner Fiorina', biology: 'xenomorph', caste: 'runner', health: 720, damage: 29, speed: 1.9 }]
});
assert.equal(engine.alien3V95.evidenceRecovered.includes('living-hunt-ready'), true);
assert.deepEqual(engine.alien3V95.telemetry.uniqueRunnerIds, ['enemy-006-runner']);

const moveToStation = (id) => {
  const station = engine.alien3StationV95(id);
  assert.ok(station, id);
  engine.player.x = station.x;
  engine.player.y = station.y;
  return station;
};

// Prisoner autonomy is explicit and deterministic.
engine.alien3V88.phase = 'trap-prep';
moveToStation('f161-autonomy-board-v95');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V95.autonomy.boardRead, true);
const active = engine.alien3PrisonersV89.filter((entry) => entry.status === 'active');
assert.ok(active.length >= 3);
const helper = active[0]; const target = active[1]; const wounded = active[2];
helper.x = 3200; target.x = 3210;
engine.alien3V95.autonomy.minds[helper.id].stress = 20;
engine.alien3V95.autonomy.minds[helper.id].state = 'steady';
engine.alien3V95.autonomy.minds[target.id].stress = 72;
engine.alien3V95.autonomy.minds[target.id].state = 'shaken';
engine.alien3RunnerV88.x = 6000; engine.alien3RunnerV88.y = 420;
engine.updateAlien3PrisonerAutonomyV95(0.1);
assert.ok(engine.alien3V95.autonomy.buddyAssists >= 1);
assert.equal(engine.alien3V95.evidenceRecovered.includes('buddy-assist'), true);
assert.equal(engine.alien3V95.evidenceRecovered.includes('panic-threshold'), true);
assert.equal(engine.alien3V95.autonomy.breakdowns, 0);

// Extend triage and verify a wounded prisoner transfers himself.
wounded.status = 'wounded'; wounded.x = 3575;
engine.alien3V95.autonomy.minds[wounded.id].state = 'wounded';
moveToStation('f161-triage-overflow-console-v95');
assert.equal(engine.interact(engine.player), true);
engine.updateAlien3PrisonerAutonomyV95(0.5);
assert.equal(engine.alien3V95.autonomy.minds[wounded.id].transferred, true);
assert.ok(engine.alien3V95.autonomy.safeTransfers >= 1);

// Shelters are useful but have a resource cost.
for (const id of ['f161-shelter-cell-console-v95', 'f161-shelter-service-console-v95']) {
  moveToStation(id);
  assert.equal(engine.interact(engine.player), true, id);
}
assert.equal(engine.alien3V95.autonomy.shelters.cell, true);
assert.equal(engine.alien3V95.autonomy.shelters.service, true);

// Four controlled hunt patterns, all using the exact same Runner actor.
engine.alien3V88.runner.active = true;
engine.alien3RunnerV88.alive = true;
for (let i = 0; i < 4; i += 1) {
  engine.alien3V95.hunt.cooldown = 0;
  engine.player.x = 180;
  assert.equal(engine.triggerAlien3HuntCycleV95({ force: true }), true);
  const runnerObject = engine.alien3RunnerV88;
  engine.alien3V95.hunt.minRange = 900;
  assert.equal(engine.resolveAlien3HuntCycleV95(), true);
  assert.equal(engine.alien3RunnerV88, runnerObject);
}
assert.equal(engine.alien3V95.hunt.encounters, 4);
assert.equal(engine.alien3V95.hunt.observed.length, 4);
assert.equal(engine.alien3V95.hunt.cleanEvades, 4);
assert.equal(engine.alien3V95.hunt.validated, true);
assert.equal(engine.alien3V95.telemetry.uniqueRunnerIds.length, 1);
assert.equal(engine.alien3V95.evidenceRecovered.includes('hunt-telemetry'), true);

// Resource tools and the adaptive chase lock.
engine.alien3V88.phase = 'leadworks';
moveToStation('f161-bait-switch-console-v95');
assert.equal(engine.interact(engine.player), true);
moveToStation('f161-pressure-alcove-console-v95');
assert.equal(engine.interact(engine.player), true);
assert.equal(Math.round(engine.alien3V95.resources.economyScore), 60);
engine.alien3V94.chase.improvised = true;
moveToStation('f161-chase-observer-console-v95');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V95.finalChase.lockArmed, true);

// Final checksum is an additional physical gate after V94 transmission.
engine.alien3V88.phase = 'finale';
engine.alien3V94.fidelity.finalTransmission = true;
moveToStation('f161-archive-checksum-console-v95');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V95.finalChase.checksumFinal, true);
assert.equal(engine.alien3V95.evidenceRecovered.includes('zero-breaks'), true);

// Perfect V94 inheritance closes the V95 perfect archive.
engine.alien3V94.perfectArchive.perfect = true;
engine.updateAlien3PerfectV95();
assert.equal(engine.alien3V95.perfectArchive.perfect, true);
assert.equal(engine.alien3V95.evidenceRecovered.length, ALIEN3_V95_EVIDENCE_IDS.length);
assert.equal(engine.alien3V95.codexUnlocked.length, ALIEN3_CODEX_V95.length);

const grade = alien3V95Grade({
  gradeV94: 'S+++++',
  evidence: ALIEN3_V95_EVIDENCE_IDS.length,
  huntPatterns: 4,
  cleanEvades: 4,
  zeroBreaks: true,
  economy: 60,
  checksum: true,
  perfect: true
});
assert.equal(grade, 'S++++++');

// Save/resume preserves hunt order, autonomy and checksum state.
const saved = engine.captureResumeState();
assert.equal(saved.specialOperation.alien3V95.schema, 95);
const resumed = new Engine();
resumed.start({
  campaign: { id: ALIEN3_CAMPAIGN_ID_V88 }, strategicBriefing: { flags: {} },
  enemyCatalog: [{ id: 'enemy-006-runner', name: 'Runner Fiorina', biology: 'xenomorph', caste: 'runner', health: 720, damage: 29, speed: 1.9 }]
});
const restored = resumed.applyResumeState(saved);
assert.equal(restored.applied, true);
assert.equal(restored.alien3DlcRestoredV95, true);
assert.equal(resumed.alien3V95.hunt.observed.length, 4);
assert.equal(resumed.alien3V95.autonomy.buddyAssists, engine.alien3V95.autonomy.buddyAssists);
assert.equal(resumed.alien3V95.finalChase.checksumFinal, true);
assert.equal(resumed.alien3V95.perfectArchive.perfect, true);

// Completion wrapper propagates V95 rewards on top of the inherited stack.
engine.missingExtractionRequirement = () => '';
engine.mission.state = 'active';
engine.alien3V88.complete = false;
assert.equal(engine.completeMission(engine.player), true);
assert.equal(engine.mission.rewards.alien3V95, true);
assert.equal(typeof engine.mission.rewards.mireGradeV95, 'string');
assert.equal(engine.mission.rewards.livingHuntV95.uniqueRunnerIds.length, 1);
assert.equal(engine.mission.rewards.prisonerAutonomyV95.zeroBreaks, true);

console.log(JSON.stringify({
  ok: true,
  validation,
  hunt: {
    order: engine.alien3V95.hunt.order,
    encounters: engine.alien3V95.hunt.encounters,
    patterns: engine.alien3V95.hunt.observed,
    cleanEvades: engine.alien3V95.hunt.cleanEvades,
    contacts: engine.alien3V95.hunt.contacts,
    uniqueRunnerIds: engine.alien3V95.telemetry.uniqueRunnerIds
  },
  autonomy: {
    minds: Object.keys(engine.alien3V95.autonomy.minds).length,
    buddyAssists: engine.alien3V95.autonomy.buddyAssists,
    breakdowns: engine.alien3V95.autonomy.breakdowns,
    safeTransfers: engine.alien3V95.autonomy.safeTransfers,
    zeroBreaks: engine.alien3V95.autonomy.zeroBreaks
  },
  resources: engine.alien3V95.resources,
  finalChase: engine.alien3V95.finalChase,
  evidenceRecovered: engine.alien3V95.evidenceRecovered.length,
  codexUnlocked: engine.alien3V95.codexUnlocked.length,
  perfectArchive: engine.alien3V95.perfectArchive,
  grade,
  completionGrade: engine.mission.rewards.mireGradeV95,
  completionRewards: { credits: engine.mission.rewards.credits, alien3V95: engine.mission.rewards.alien3V95 },
  resume: { restored: restored.alien3DlcRestoredV95, checksum: resumed.alien3V95.finalChase.checksumFinal }
}, null, 2));
