import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const patchRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const fixture = fs.mkdtempSync(path.join(os.tmpdir(), 'alien3-v96-install-'));
const sha = (buffer) => crypto.createHash('sha256').update(buffer).digest('hex');
const write = (relative, content) => {
  const target = path.join(fixture, relative);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, content);
};
const read = (relative) => fs.readFileSync(path.join(fixture, relative));

write('src/special-operations-v67.js', `const VALID_STATUSES = new Set(['effective', 'partial', 'missing']);\nexport const SPECIAL_OPERATIONS_V67 = Object.freeze([\n  freezeOperation({\n    id: 'cargo-brutal',\n    promisedTitle: 'CARGO BRUTAL'\n  })\n]);\nexport function validateSpecialOperationsV67(operations = SPECIAL_OPERATIONS_V67) {\n  const failures = [];\n  if (operations.length !== 19) failures.push(\`operations: \${operations.length} != 19\`);\n  return { failures };\n}\n`);
write('src/mission-levels-v52.js', `import { buildCetoHabitatsV75, cetoHabitatHazardsV75 } from './enemy-ceto-v75.js';\nexport const MISSION_TEMPLATE_IDS_V52 = Object.freeze([\n  'ship-interior-vertical',\n  'colony-multiroute',\n  'planet-exterior'\n]);\nconst TEMPLATE_PALETTES = Object.freeze({\n  base: true\n});\nconst SHIP_TEMPLATE = { id: 'ship-interior-vertical' };\nexport const MISSION_LEVEL_TEMPLATES_V52 = Object.freeze({\n  [SHIP_TEMPLATE.id]: SHIP_TEMPLATE,\n});\n`);
write('src/game-v52-level-runtime.js', `export const MISSION_LEVEL_LAYER_FILES_V52 = Object.freeze({\n  base: true\n});\n`);
write('src/game-production-runtime.js', `import { withPlaceablesRuntimeV86 } from './placeables-runtime-v86.js';\nconst V70ProductionEngine = class {};\nconst V86ProductionEngine = withPlaceablesRuntimeV86(V70ProductionEngine);\nexport class GameEngine extends V86ProductionEngine { }\n`);

const app = [
  "<span>${escapeHtml(world?.name || 'Frontier')}</span><span>${escapeHtml(campaign.objective)}</span>",
  "<footer><span>${campaign ? escapeHtml(world?.name || 'Frontier') : hubSurface ? 'USS TANTALUS · HUB PHYSIQUE' : 'REGISTRE DES OPÉRATIONS'}</span>",
  "<h3>${escapeHtml(campaign.name)}</h3><p>${escapeHtml(campaign.objective)} · ${escapeHtml(world.name)}</p>${specialNotice}",
  "  const specialNoticeCopy = specialOperation?.id === 'cargo-brutal'\n",
  "  const worldState = saveSystem.data.galaxy.worldState[world.id];\n  const before = absoluteHours(saveSystem.data.clock);",
  `  const crew = operationLoadout.crew;\n  const weapon = operationLoadout.weapon || WEAPONS[0];\n  const equipment = operationLoadout.equipment;\n  const specialOperation = getSpecialOperationByCampaignIdV67(campaign.id);\n  const vehicle = specialOperation?.issuedVehicleId\n    ? VEHICLES.find((entry) => entry.id === specialOperation.issuedVehicleId) || operationLoadout.vehicle\n    : operationLoadout.vehicle;\n  const costume = operationLoadout.costume;`,
  "    world: { ...world, ...worldState },\n    levelSeeds: LEVEL_SEEDS,",
  "  byId('mission-log').textContent = `MU/TH/UR · ${campaign.objective.toUpperCase()} · ${world.name} · ${missionLevel.templateLabel.toUpperCase()} · RISQUE ${deployment.operation.risk}%`;",
  "    campaign, world, worldState, levelSeed, missionLevel,\n    weapon, equipment, crew, vehicle, costume, deployment, operationLoadout\n  });",
  `const alienSurvivalEventLabelV70 = (event) => {\n  const detail = event.message || event.reason || event.circuitId || event.feedId\n    || event.doorId || event.stationId || event.type.replace('alien-survival-', '');\n  const remaining = Number(event.remainingSeconds ?? event.remaining);\n  const countdown = Number.isFinite(remaining) ? \` · T−\${Math.max(0, Math.ceil(remaining))} S\` : '';\n  return \`SURVIE · \${String(detail || 'SYSTÈMES ACTUALISÉS').toUpperCase()}\${countdown}\`;\n};\n`,
  `  if (isAlienSurvivalRuntimeEventV70(event)) {\n    alienSurvivalDockV70?.refresh();\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alienSurvivalEventLabelV70(event);\n  }\n`,
  `  const survivalPersistenceDue = ALIEN_SURVIVAL_PERSISTENT_EVENTS_V70.has(event.type)\n    && (event.type !== 'alien-survival-self-destruct-tick'\n      || Math.max(0, Math.ceil(Number(event.remainingSeconds ?? event.remaining) || 0)) % 5 === 0);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue) && saveSystem.data.strategy.currentOperation) {`
].join('\n/* fixture boundary */\n');
write('src/app.js', app);

write('src/audio-assets-v77.js', `export const AUDIO_SLOTS_V77 = Object.freeze({ sfx: Object.freeze(['shot', 'tracker', 'hit', 'ui', 'alarm']), music: Object.freeze(['menu', 'hub', 'mission']) });\n`);

const baseFiles = [
  'src/special-operations-v67.js',
  'src/mission-levels-v52.js',
  'src/game-v52-level-runtime.js',
  'src/game-production-runtime.js',
  'src/app.js',
  'src/audio-assets-v77.js'
];
const before = Object.fromEntries(baseFiles.map((relative) => [relative, sha(read(relative))]));

const installer = path.join(patchRoot, 'scripts', 'install-alien3-dlc-v96.mjs');
let result = spawnSync(process.execPath, [installer, fixture], { encoding: 'utf8' });
assert.equal(result.status, 0, result.stderr || result.stdout);

for (const version of ['v88','v89','v90','v91','v92','v93','v94','v95','v96']) {
  assert.equal(fs.existsSync(path.join(fixture, 'src', `alien3-dlc-${version}.js`)), true, `${version} definition missing`);
  assert.equal(fs.existsSync(path.join(fixture, 'src', `alien3-dlc-runtime-${version}.js`)), true, `${version} runtime missing`);
  assert.equal(fs.existsSync(path.join(fixture, `.alien3-dlc-${version}-backup`)), true, `${version} backup missing`);
}
const specialAfter = fs.readFileSync(path.join(fixture, 'src', 'special-operations-v67.js'), 'utf8');
assert.match(specialAfter, /runner-sensory-trace/);
assert.match(specialAfter, /eev-bishop-forensic-chain/);
assert.match(specialAfter, /physical-battery-duty/);
assert.match(specialAfter, /theatrical-assembly-workprint-profiles/);
assert.match(specialAfter, /improvised-final-reroutes/);
assert.match(specialAfter, /zone-atmosphere-simulation/);
assert.match(specialAfter, /optional-dlc-audio-slots/);
assert.match(specialAfter, /directional-threat-captions/);
assert.match(specialAfter, /mire-codex-130/);
assert.match(fs.readFileSync(path.join(fixture, 'src', 'mission-levels-v52.js'), 'utf8'), /ALIEN3_FIORINA_TEMPLATE_V96/);
assert.match(fs.readFileSync(path.join(fixture, 'src', 'game-production-runtime.js'), 'utf8'), /V96ProductionEngine/);
assert.match(fs.readFileSync(path.join(fixture, 'src', 'app.js'), 'utf8'), /130 dossiers/);

result = spawnSync(process.execPath, [path.join(fixture, 'scripts', 'test-alien3-dlc-v96.mjs')], { cwd: fixture, encoding: 'utf8' });
assert.equal(result.status, 0, result.stderr || result.stdout);
const runtimeQa = JSON.parse(result.stdout);
assert.equal(runtimeQa.ok, true);
assert.equal(runtimeQa.validation.counts.nodes, 72);
assert.equal(runtimeQa.validation.counts.edges, 119);
assert.equal(runtimeQa.validation.counts.routes, 4);
assert.equal(runtimeQa.evidenceRecovered, 18);
assert.equal(runtimeQa.codexUnlocked, 18);
assert.equal(runtimeQa.atmosphere.zonesVisited, 6);
assert.equal(runtimeQa.acoustics.uniqueCues, 8);
assert.equal(runtimeQa.acoustics.diagnostic, true);
assert.equal(runtimeQa.perfectArchive.perfect, true);
assert.ok(runtimeQa.acoustics.fallbackAttempts >= 8);
assert.equal(runtimeQa.resume.restored, true);
assert.equal(runtimeQa.perfectArchive.perfect, true);
assert.equal(runtimeQa.grade, 'S+++++++');
assert.equal(runtimeQa.resume.restored, true);

result = spawnSync(process.execPath, [path.join(fixture, 'scripts', 'test-alien3-physical-v96.mjs')], { cwd: fixture, encoding: 'utf8' });
assert.equal(result.status, 0, result.stderr || result.stdout);
const physicalQa = JSON.parse(result.stdout);
assert.equal(physicalQa.ok, true);
assert.equal(physicalQa.allStationsSupported, true);
assert.equal(physicalQa.orphanNodes, 0);
assert.equal(physicalQa.connectedNodes, 72);

const uninstaller = path.join(fixture, 'scripts', 'uninstall-alien3-dlc-v96.mjs');
result = spawnSync(process.execPath, [uninstaller, fixture, '--full'], { encoding: 'utf8' });
assert.equal(result.status, 0, result.stderr || result.stdout);
for (const relative of baseFiles) assert.equal(sha(read(relative)), before[relative], `${relative} not restored bit-for-bit`);
for (const version of ['v88','v89','v90','v91','v92','v93','v94','v95','v96']) {
  assert.equal(fs.existsSync(path.join(fixture, 'src', `alien3-dlc-${version}.js`)), false, `${version} definition not removed`);
  assert.equal(fs.existsSync(path.join(fixture, `.alien3-dlc-${version}-backup`)), false, `${version} backup not removed`);
}

console.log(JSON.stringify({
  ok: true,
  fixture,
  cumulativeInstall: true,
  versions: ['V88','V89','V90','V91','V92','V93','V94','V95','V96'],
  runtimeQa: {
    routes: runtimeQa.validation.counts.routes,
    nodes: runtimeQa.validation.counts.nodes,
    edges: runtimeQa.validation.counts.edges,
    evidenceV96: `${runtimeQa.evidenceRecovered}/18`,
    codexV96: `${runtimeQa.codexUnlocked}/18`,
    zonesVisited: runtimeQa.atmosphere.zonesVisited,
    audioCues: runtimeQa.acoustics.uniqueCues,
    diagnostic: runtimeQa.acoustics.diagnostic,
    gradeV96: runtimeQa.grade,
    perfectArchive: runtimeQa.perfectArchive.perfect
  },
  physicalQa: {
    connectedNodes: physicalQa.connectedNodes,
    connectors: physicalQa.connectors,
    stations: physicalQa.stations
  },
  fullUninstallBitPerfect: true,
  restoredFiles: baseFiles
}, null, 2));
fs.rmSync(fixture, { recursive: true, force: true });
