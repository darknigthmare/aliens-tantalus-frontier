import assert from 'node:assert/strict';
import { ALIEN3_CAMPAIGN_ID_V88 } from '../src/alien3-dlc-v88.js';
import { withAlien3DlcRuntimeV88 } from '../src/alien3-dlc-runtime-v88.js';
import { withAlien3DlcRuntimeV89 } from '../src/alien3-dlc-runtime-v89.js';
import { withAlien3DlcRuntimeV90 } from '../src/alien3-dlc-runtime-v90.js';
import { withAlien3DlcRuntimeV91 } from '../src/alien3-dlc-runtime-v91.js';
import { withAlien3DlcRuntimeV92 } from '../src/alien3-dlc-runtime-v92.js';
import { withAlien3DlcRuntimeV93 } from '../src/alien3-dlc-runtime-v93.js';
import { withAlien3DlcRuntimeV94 } from '../src/alien3-dlc-runtime-v94.js';
import { withAlien3DlcRuntimeV95 } from '../src/alien3-dlc-runtime-v95.js';
import { withAlien3DlcRuntimeV96 } from '../src/alien3-dlc-runtime-v96.js';
import {
  ALIEN3_DEPTH_LANES_V97, ALIEN3_DLC_CODEX_TERMINALS_V97, ALIEN3_DLC_CODEX_V97,
  ALIEN3_FIORINA_TEMPLATE_V97, ALIEN3_HYBRID_SECTORS_V97, ALIEN3_V97_EVIDENCE_IDS,
  alien3V97Grade, validateAlien3DlcV97
} from '../src/alien3-dlc-v97.js';
import { withAlien3DlcRuntimeV97 } from '../src/alien3-dlc-runtime-v97.js';

class MockBase {
  constructor() {
    this.events=[]; this.images=new Map(); this.enemies=[]; this.doors=[]; this.keys=new Set(); this.running=true; this.paused=false;
    this.platforms=[{id:'ground',x:0,y:510,w:6200},{id:'deep',x:0,y:630,w:6200},{id:'high',x:0,y:330,w:6200},{id:'perch',x:0,y:190,w:6200}];
    this.player={id:'player',x:180,y:420,w:44,h:90,alive:true,health:100,armor:0,kills:0,damageTaken:0,actionClock:0,fireClock:0,vx:0,vy:0,facing:1,crouching:false,grounded:true};
    this.coop={id:'coop',x:120,y:420,w:44,h:90,alive:true,health:100,armor:0,kills:0,damageTaken:0,vx:0,vy:0};
    this.vehicle={active:true,occupied:false,driver:null,passengers:[],x:3200}; this.weaponPickup={taken:false,x:900}; this.toolPickup={taken:false,x:1200}; this.supplies=[]; this.objectiveNodes=[];
    this.archiveTerminal={recovered:false,x:1500}; this.powerNode={active:false,x:1800}; this.objective={x:6000,y:420,w:68,h:90,complete:false};
    this.missionLevelRuntime={anchors:{extraction:{x:6040,y:510}}}; this.missionLevelVisualState={activeZoneId:'f161-coast'};
    this.mission={state:'active',objectives:{power:false,route:false,boss:false,archive:false,extract:false},rewards:{},retries:0,elapsed:0,casualties:0}; this.inventory={salvage:0,intel:0};
    this.audio={tones:0,effects:[],ui(){},alarm(){},hit(){},tone(){this.tones+=1;return true;},playEffect(id,fallback){this.effects.push(id);fallback?.();return false;}};
    this.camera={x:0,y:0}; this.animationTime=0; this.onEvent=(event)=>this.events.push(event);
  }
  start(options={}){this.campaign=options.campaign;this.strategicBriefing=options.strategicBriefing;return{base:true};}
  createEnemy(profile,index,x,groundY,options={}){return{...profile,id:profile.id||`enemy-${index}`,x,y:groundY-90,w:90,h:90,health:profile.health||100,maxHealth:profile.health||100,speed:profile.speed||1,damage:profile.damage||10,alive:true,facing:-1,alert:false,staggerClock:0,hurtClock:0,...options};}
  initializeEnemyMissionNavigation(){} interact(){return false;} fire(){return false;} reload(){return true;} toggleVehicle(){return true;} useEquipment(){return true;} activateTracker(){return false;}
  applyEnemyDamage(enemy,amount){enemy.health=Math.max(0,enemy.health-amount);if(enemy.health<=0)enemy.alive=false;return amount;} updateEnemy(){} drawEnemy(){} drawActor(){} defeatEnemy(enemy){enemy.alive=false;enemy.health=0;return true;}
  updatePlayer(){} damagePlayer(actor,amount){actor.health=Math.max(0,actor.health-amount);actor.damageTaken+=amount;if(actor.health<=0)actor.alive=false;return amount;}
  update(delta=0.016){this.animationTime+=delta;return true;} missingObjectiveRequirement(){return '';} missingExtractionRequirement(){return '';}
  completeMission(){this.mission.state='complete';this.mission.rewards={credits:100};this.onEvent({type:'mission-complete',rewards:this.mission.rewards});return true;}
  restartFromCheckpoint(){this.mission.state='active';return true;} phaseLabel(){return'BASE';} objectiveProgressText(){return'BASE';} getInteractionPrompt(){return'';}
  drawBackdrop(){} drawWorld(){} drawHud(){} captureResumeState(){return{schema:1,player:{x:this.player.x,y:this.player.y}};} applyResumeState(){return{applied:true,restored:1};}
  getGameplayReport(){return{base:true};} getSnapshot(){return{base:true};} locked(requirement){this.events.push({type:'locked',requirement});return false;}
}

const V88=withAlien3DlcRuntimeV88(MockBase); const V89=withAlien3DlcRuntimeV89(V88); const V90=withAlien3DlcRuntimeV90(V89); const V91=withAlien3DlcRuntimeV91(V90);
const V92=withAlien3DlcRuntimeV92(V91); const V93=withAlien3DlcRuntimeV93(V92); const V94=withAlien3DlcRuntimeV94(V93); const V95=withAlien3DlcRuntimeV95(V94);
const V96=withAlien3DlcRuntimeV96(V95); const Engine=withAlien3DlcRuntimeV97(V96);

const validation=validateAlien3DlcV97(); assert.equal(validation.ok,true,validation.failures.join('; '));
assert.equal(ALIEN3_FIORINA_TEMPLATE_V97.nodes.length,72); assert.equal(ALIEN3_FIORINA_TEMPLATE_V97.edges.length,119); assert.equal(ALIEN3_FIORINA_TEMPLATE_V97.routes.length,4);
assert.equal(ALIEN3_HYBRID_SECTORS_V97.length,9); assert.equal(ALIEN3_DEPTH_LANES_V97.length,3); assert.equal(ALIEN3_DLC_CODEX_TERMINALS_V97.length,5); assert.equal(ALIEN3_DLC_CODEX_V97.length,66); assert.equal(ALIEN3_V97_EVIDENCE_IDS.length,20);

const engine=new Engine();
engine.start({campaign:{id:ALIEN3_CAMPAIGN_ID_V88},strategicBriefing:{flags:{'alien3-v90-challenge':'archive'}},enemyCatalog:[{id:'enemy-006-runner',name:'Runner Fiorina',biology:'xenomorph',caste:'runner',health:720,damage:29,speed:1.9}]});
assert.equal(engine.alien3V97.hybrid.mode,'depth'); assert.equal(engine.alien3V97.evidenceRecovered.includes('hybrid-runtime-ready'),true); assert.equal(engine.alien3V97.dlcCodex.unlocked.length,6);

// Traverse the full authored level and verify automatic depth <-> side transitions without new routes.
for(const sector of ALIEN3_HYBRID_SECTORS_V97){ engine.player.x=sector.x0+Math.min(90,(sector.x1-sector.x0)/2); engine.player.y=420; engine.syncAlien3HybridSectorV97(0.25); assert.equal(engine.alien3V97.hybrid.mode,sector.mode,sector.id); }
assert.equal(engine.alien3V97.hybrid.visitedSectors.length,9); assert.ok(engine.alien3V97.hybrid.transitions>=8); assert.equal(engine.alien3V97.evidenceRecovered.includes('all-hybrid-sectors'),true); assert.equal(engine.alien3V97.evidenceRecovered.includes('automatic-view-transition'),true);

// Exercise all three physical depth planes.
engine.player.x=1900; engine.syncAlien3HybridSectorV97(0.1); assert.equal(engine.alien3V97.hybrid.mode,'depth');
assert.equal(engine.shiftAlien3DepthLaneV97(-1),true); assert.equal(engine.alien3V97.hybrid.playerLane,0);
assert.equal(engine.shiftAlien3DepthLaneV97(1),true); assert.equal(engine.alien3V97.hybrid.playerLane,1);
assert.equal(engine.shiftAlien3DepthLaneV97(1),true); assert.equal(engine.alien3V97.hybrid.playerLane,2);
assert.equal(engine.alien3V97.evidenceRecovered.includes('lane-rear-used'),true); assert.equal(engine.alien3V97.evidenceRecovered.includes('lane-mid-used'),true); assert.equal(engine.alien3V97.evidenceRecovered.includes('lane-front-used'),true);

// A Runner contact on a different depth plane is a real lane evade; same lane can still hurt.
engine.alien3RunnerV88.alive=true; engine.alien3V88.runner.active=true; engine.alien3RunnerV88.x=engine.player.x+120; engine.alien3RunnerV88.y=420;
engine.alien3V97.hybrid.playerLane=2; engine.alien3V97.hybrid.runnerLane=0; const hp=engine.player.health;
assert.equal(engine.damagePlayer(engine.player,20,{source:'Runner Fiorina'}),0); assert.equal(engine.player.health,hp); assert.equal(engine.alien3V97.evidenceRecovered.includes('runner-lane-evasion'),true);
engine.alien3V97.hybrid.runnerLane=2; assert.ok(engine.damagePlayer(engine.player,5,{source:'Runner Fiorina'})>0); assert.equal(engine.alien3V97.evidenceRecovered.includes('runner-lane-contact'),true);

// Five physical codex terminals unlock the dedicated DLC codex independently from MIRE.
for(const terminal of ALIEN3_DLC_CODEX_TERMINALS_V97){
  engine.player.x=terminal.x; engine.player.y=terminal.y; engine.syncAlien3HybridSectorV97(0.05); engine.alien3V97.hybrid.playerLane=terminal.lane;
  assert.equal(engine.interact(engine.player),true,terminal.id);
}
assert.equal(engine.alien3V97.dlcCodex.terminalsRead.length,5); assert.equal(engine.alien3V97.dlcCodex.unlocked.length,66); assert.equal(engine.alien3V97.dlcCodex.complete,true);
assert.equal(engine.alien3V97.evidenceRecovered.includes('codex-complete'),true); assert.ok(engine.alien3V97.dlcCodex.currentId); assert.equal(engine.cycleAlien3DlcCodexV97(1),true);

// Balance both presentation modes so neither becomes a cosmetic one-off.
engine.player.x=1900; for(let i=0;i<40;i++) engine.syncAlien3HybridSectorV97(0.25);
engine.player.x=900; for(let i=0;i<40;i++) engine.syncAlien3HybridSectorV97(0.25);
assert.ok(engine.alien3V97.hybrid.depthSeconds>=8); assert.ok(engine.alien3V97.hybrid.sideSeconds>=8); assert.equal(engine.alien3V97.evidenceRecovered.includes('balanced-hybrid-time'),true);

engine.alien3V96.perfectArchive.perfect=true; engine.updateAlien3PerfectV97();
assert.equal(engine.alien3V97.perfectArchive.perfect,true); assert.equal(engine.alien3V97.evidenceRecovered.length,20);
const grade=alien3V97Grade({gradeV96:'S+++++++',evidence:20,sectors:9,lanes:3,codex:66,transitions:8,laneEvades:3,balanced:true,perfect:true}); assert.equal(grade,'S++++++++');

const saved=engine.captureResumeState(); assert.equal(saved.specialOperation.alien3V97.schema,97);
const resumed=new Engine(); resumed.start({campaign:{id:ALIEN3_CAMPAIGN_ID_V88},strategicBriefing:{flags:{}},enemyCatalog:[{id:'enemy-006-runner',name:'Runner Fiorina',biology:'xenomorph',caste:'runner',health:720,damage:29,speed:1.9}]});
const restored=resumed.applyResumeState(saved); assert.equal(restored.alien3DlcRestoredV97,true); assert.equal(resumed.alien3V97.dlcCodex.unlocked.length,66); assert.equal(resumed.alien3V97.perfectArchive.perfect,true); assert.equal(resumed.alien3V97.hybrid.visitedSectors.length,9);

engine.missingExtractionRequirement=()=>''; engine.mission.state='active'; engine.alien3V88.complete=false; assert.equal(engine.completeMission(engine.player),true);
assert.equal(engine.mission.rewards.alien3V97,true); assert.equal(engine.mission.rewards.dedicatedCodexV97.unlocked.length,66); assert.equal(typeof engine.mission.rewards.mireGradeV97,'string');

console.log(JSON.stringify({
  ok:true, validation,
  hybrid:{sectorsVisited:engine.alien3V97.hybrid.visitedSectors.length,transitions:engine.alien3V97.hybrid.transitions,depthSeconds:Number(engine.alien3V97.hybrid.depthSeconds.toFixed(2)),sideSeconds:Number(engine.alien3V97.hybrid.sideSeconds.toFixed(2)),laneChanges:engine.alien3V97.hybrid.laneChanges,laneEvades:engine.alien3V97.hybrid.laneEvades,laneContacts:engine.alien3V97.hybrid.laneContacts},
  dedicatedCodex:{total:ALIEN3_DLC_CODEX_V97.length,unlocked:engine.alien3V97.dlcCodex.unlocked.length,viewed:engine.alien3V97.dlcCodex.viewed.length,terminals:engine.alien3V97.dlcCodex.terminalsRead.length},
  evidenceRecovered:engine.alien3V97.evidenceRecovered.length,perfectArchive:engine.alien3V97.perfectArchive,grade,completionGrade:engine.mission.rewards.mireGradeV97,
  resume:{restored:restored.alien3DlcRestoredV97,codex:resumed.alien3V97.dlcCodex.unlocked.length,sectors:resumed.alien3V97.hybrid.visitedSectors.length}
},null,2));
