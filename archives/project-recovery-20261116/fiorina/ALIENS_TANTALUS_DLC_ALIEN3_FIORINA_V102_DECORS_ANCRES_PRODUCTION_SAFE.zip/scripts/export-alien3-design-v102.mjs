import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import * as a from '../src/alien3-dlc-v102.js';import {ALIEN3_HYBRID_SECTORS_V97} from '../src/alien3-dlc-v97.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out={schema:102,units:'Game units. Not film set measurements.',scene:a.compileAlien3DecorV102(),topology:a.ALIEN3_FIORINA_TEMPLATE_V102,sectors:ALIEN3_HYBRID_SECTORS_V97,briefs:a.ALIEN3_SECTOR_BRIEFS_V102,rules:a.ALIEN3_RULES_V102,recipes:a.ALIEN3_ASSEMBLY_RECIPES_V102,hud:a.ALIEN3_HUD_RECTS_V102};
fs.mkdirSync(path.join(root,'qa-v102'),{recursive:true});fs.writeFileSync(path.join(root,'qa-v102/design-source.json'),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({assemblies:out.scene.groups.length,props:out.scene.props.length,nodes:out.topology.nodes.length}));
