#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = path.resolve(process.argv[2] || process.cwd());
const full = process.argv.includes('--full');
const backupDir = path.join(root, '.alien3-dlc-v94-backup');
const files = [
  'src/special-operations-v67.js',
  'src/mission-levels-v52.js',
  'src/game-production-runtime.js',
  'src/app.js'
];
const additions = [
  'src/alien3-dlc-v94.js',
  'src/alien3-dlc-runtime-v94.js',
  'scripts/test-alien3-dlc-v94.mjs',
  'scripts/test-alien3-physical-v94.mjs',
  'scripts/uninstall-alien3-dlc-v94.mjs',
  'docs/ALIEN3_DLC_V94.md'
];

if (!fs.existsSync(backupDir)) throw new Error('Backup V94 introuvable.');
for (const relative of files) {
  const backup = path.join(backupDir, relative);
  if (!fs.existsSync(backup)) throw new Error(`Backup absent: ${relative}`);
  fs.mkdirSync(path.dirname(path.join(root, relative)), { recursive: true });
  fs.copyFileSync(backup, path.join(root, relative));
}
for (const relative of additions) fs.rmSync(path.join(root, relative), { force: true });
fs.rmSync(path.join(root, 'ALIEN3_DLC_V94_INSTALL_REPORT.json'), { force: true });
fs.rmSync(backupDir, { recursive: true, force: true });

if (full) {
  const prior = path.join(root, 'scripts', 'uninstall-alien3-dlc-v93.mjs');
  if (!fs.existsSync(prior)) throw new Error('Désinstallateur V93 absent après restauration V94.');
  const result = spawnSync(process.execPath, [prior, root, '--full'], { stdio: 'inherit' });
  if (result.status !== 0) throw new Error('Désinstallation complète V93→V88 impossible.');
} else {
  console.log('V94 retirée. La base V93 est restaurée.');
}
