#!/usr/bin/env python3
"""Verify the pristine delivered package. Intentional edits invalidate its manifest."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1]
m=json.loads((ROOT/'PATCH_MANIFEST.json').read_text());expected={x['path']:x for x in m['files']}
actual={p.relative_to(ROOT).as_posix():p for p in ROOT.rglob('*') if p.is_file() and p.name!='PATCH_MANIFEST.json'}
errors=[]
for name,x in expected.items():
 p=actual.get(name)
 if p is None:errors.append('missing:'+name);continue
 raw=p.read_bytes()
 if len(raw)!=x['bytes'] or hashlib.sha256(raw).hexdigest()!=x['sha256']:errors.append('mismatch:'+name)
for name in actual.keys()-expected.keys():errors.append('unexpected:'+name)
result={'ok':not errors,'files':len(expected),'actual':len(actual),'errors':errors};print(json.dumps(result,indent=2));sys.exit(0 if result['ok'] else 1)
