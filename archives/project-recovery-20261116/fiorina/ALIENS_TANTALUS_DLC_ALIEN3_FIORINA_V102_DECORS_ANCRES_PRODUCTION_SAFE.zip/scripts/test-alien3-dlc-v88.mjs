import assert from 'node:assert/strict';
import {
  ALIEN3_CAMPAIGN_ID_V88,
  ALIEN3_CODEX_V88,
  ALIEN3_FIORINA_TEMPLATE_V88,
  validateAlien3DlcV88
} from '../src/alien3-dlc-v88.js';
import { withAlien3DlcRuntimeV88 } from '../src/alien3-dlc-runtime-v88.js';

class MockBase {
  constructor() {
    this.events = [];
    this.images = new Map();
    this.enemies = [];
    this.doors = [];
    this.player = { id: 'player', x: 180, y: 420, w: 44, h: 90, alive: true, kills: 0, actionClock: 0, fireClock: 0, vx: 0, vy: 0 };
    this.coop = { id: 'coop', x: 120, y: 420, w: 44, h: 90, alive: true, kills: 0, vx: 0, vy: 0 };
    this.vehicle = { active: true, occupied: true, driver: this.player, passengers: [this.coop], x: 3200 };
    this.weaponPickup = { taken: false, x: 900 };
    this.toolPickup = { taken: false, x: 1200 };
    this.supplies = [{ type: 'ammo', amount: 24 }, { type: 'medkit', amount: 1 }];
    this.objectiveNodes = [{ id: 'generic-node' }];
    this.archiveTerminal = { recovered: false, x: 1500 };
    this.powerNode = { active: false, x: 1800 };
    this.objective = { x: 6000, y: 420, w: 68, h: 90, complete: false };
    this.missionLevelRuntime = { anchors: { extraction: { x: 6040, y: 510 } } };
    this.mission = { state: 'active', objectives: { power: false, route: false, boss: false, archive: false, extract: false }, rewards: {}, retries: 0, elapsed: 100, casualties: 0 };
    this.inventory = { salvage: 0, intel: 0 };
    this.audio = { ui() {}, alarm() {}, hit() {} };
    this.onEvent = (event) => this.events.push(event);
  }
  start(options = {}) { this.campaign = options.campaign; return { base: true }; }
  createEnemy(profile, index, x, groundY, options = {}) {
    const enemy = {
      ...profile,
      id: profile.id || `enemy-${index}`,
      x, y: groundY - 90, w: 90, h: 90, health: profile.health || 100,
      maxHealth: profile.health || 100, speed: profile.speed || 1, damage: profile.damage || 10,
      alive: true, facing: -1, ...options
    };
    return enemy;
  }
  initializeEnemyMissionNavigation() {}
  interact() { return false; }
  fire() { return false; }
  reload() { return true; }
  toggleVehicle() { return true; }
  useEquipment() { return true; }
  activateTracker() { return true; }
  applyEnemyDamage(enemy, amount) {
    enemy.health = Math.max(0, enemy.health - amount);
    if (enemy.health <= 0) enemy.alive = false;
    return amount;
  }
  updateEnemy() {}
  drawEnemy() {}
  defeatEnemy(enemy) { enemy.alive = false; enemy.health = 0; return true; }
  damagePlayer() { return true; }
  update() { return true; }
  missingObjectiveRequirement() { return ''; }
  missingExtractionRequirement() { return ''; }
  completeMission() { this.mission.state = 'complete'; this.mission.rewards = { credits: 100, salvage: 2, intel: 1 }; this.onEvent({ type: 'mission-complete', kills: 0, rewards: this.mission.rewards }); return true; }
  restartFromCheckpoint() { this.mission.state = 'active'; return true; }
  phaseLabel() { return 'BASE'; }
  objectiveProgressText() { return 'BASE'; }
  getInteractionPrompt() { return ''; }
  drawWorld() {}
  drawHud() {}
  captureResumeState() { return { schema: 1, player: { x: this.player.x, y: this.player.y } }; }
  applyResumeState() { return { applied: true, restored: 1 }; }
  getGameplayReport() { return { base: true }; }
  getSnapshot() { return { base: true }; }
  locked(requirement) { this.events.push({ type: 'locked', requirement }); return false; }
}

const Engine = withAlien3DlcRuntimeV88(MockBase);
const report = validateAlien3DlcV88();
assert.equal(report.ok, true, report.failures.join('; '));
assert.equal(ALIEN3_FIORINA_TEMPLATE_V88.routes.length, 3);
assert.equal(ALIEN3_CODEX_V88.length, 13);

const engine = new Engine();
engine.start({
  campaign: { id: ALIEN3_CAMPAIGN_ID_V88 },
  enemyCatalog: [{ id: 'enemy-006-runner', name: 'Runner', biology: 'xenomorph', caste: 'runner', health: 720, damage: 29, speed: 1.9 }]
});
assert.equal(engine.alien3V88.phase, 'wreckage');
assert.equal(engine.enemies.length, 1);
assert.equal(engine.alien3RunnerV88.caste, 'runner');
assert.equal(engine.coopEnabled, false);
assert.equal(engine.coop.alive, false);
assert.equal(engine.vehicle.active, false);
assert.equal(engine.vehicle.driver, null);
assert.equal(engine.weaponPickup.taken, true);
assert.equal(engine.toolPickup.taken, true);
assert.equal(engine.supplies.some((entry) => entry.type === 'ammo'), false);
assert.equal(engine.supplies.some((entry) => entry.type === 'medkit'), true);
assert.equal(engine.objectiveNodes.length, 0);
assert.equal(engine.archiveTerminal.x, -4000);
assert.equal(engine.powerNode.x, -4000);

const moveTo = (stationId) => {
  const station = engine.alien3StationV88(stationId);
  assert.ok(station, stationId);
  engine.player.x = station.x;
  engine.player.y = station.y;
  return station;
};

moveTo('f161-eev-recorder');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'infirmary');

moveTo('f161-autopsy');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'first-blood');
assert.equal(engine.alien3V88.runner.active, true);

const hpBefore = engine.alien3RunnerV88.health;
assert.equal(engine.applyEnemyDamage(engine.alien3RunnerV88, 999, { kind: 'rifle' }), 0);
assert.equal(engine.alien3RunnerV88.health, hpBefore);

engine.player.x = 2800;
engine.update(0.1);
assert.equal(engine.alien3V88.phase, 'bishop');

moveTo('f161-bishop-memory');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'trap-prep');

for (const id of ['f161-cache-infirmary', 'f161-cache-cellblock', 'f161-cache-service']) {
  moveTo(id);
  assert.equal(engine.interact(engine.player), true, id);
}
assert.equal(engine.alien3V88.fireMazeArmed, true);
assert.equal(engine.alien3V88.flares, 6);

const flaresBefore = engine.alien3V88.flares;
assert.equal(engine.fire(engine.player), true);
assert.equal(engine.alien3V88.flares, flaresBefore - 1);

moveTo('f161-fire-igniter');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'fire-maze');

engine.player.x = 4400;
engine.update(0.1);
assert.equal(engine.alien3V88.phase, 'leadworks');

const mold = moveTo('f161-mold-control');
engine.alien3RunnerV88.x = mold.x + 40;
engine.alien3RunnerV88.y = mold.y;
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'molten-lead');
assert.equal(engine.alien3V88.moltenLeadApplied, true);
assert.equal(engine.alien3RunnerV88.alive, true);

moveTo('f161-sprinkler-control');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'thermal-shock');
assert.equal(engine.alien3V88.runnerDefeated, true);

engine.update(1);
engine.update(0.3);
assert.equal(engine.alien3V88.phase, 'company');

moveTo('f161-company-contact');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'finale');
assert.equal(engine.alien3V88.companyRefused, true);

assert.equal(engine.activateTracker(engine.player), true);
assert.ok(engine.alien3V88.currentCodexId);

const saved = engine.captureResumeState();
assert.equal(saved.specialOperation.alien3V88.schema, 88);
assert.ok(saved.specialOperation.alien3RunnerV88);

const resumed = new Engine();
resumed.start({
  campaign: { id: ALIEN3_CAMPAIGN_ID_V88 },
  enemyCatalog: [{ id: 'enemy-006-runner', name: 'Runner', biology: 'xenomorph', caste: 'runner', health: 720, damage: 29, speed: 1.9 }]
});
const resumeResult = resumed.applyResumeState(saved);
assert.equal(resumeResult.applied, true);
assert.equal(resumed.alien3V88.phase, 'finale');
assert.equal(resumed.alien3V88.companyRefused, true);
assert.equal(resumed.alien3V88.runnerDefeated, true);
assert.equal(resumed.alien3V88.codexUnlocked.length, engine.alien3V88.codexUnlocked.length);

moveTo('f161-final-ledge');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.mission.state, 'complete');
assert.equal(engine.alien3V88.complete, true);
assert.equal(engine.mission.rewards.alien3Archive, true);
assert.equal(engine.mission.rewards.canonRoute, true);
assert.ok(engine.mission.rewards.codexUnlocked.length >= 10);

const completion = engine.events.findLast((event) => event.type === 'mission-complete');
assert.ok(completion);
assert.equal(completion.rewards.alien3Archive, true);

console.log(JSON.stringify({
  ok: true,
  validation: report,
  finalPhase: engine.alien3V88.phase,
  events: engine.events.length,
  codexUnlocked: engine.alien3V88.codexUnlocked.length,
  rewards: engine.mission.rewards
}, null, 2));
