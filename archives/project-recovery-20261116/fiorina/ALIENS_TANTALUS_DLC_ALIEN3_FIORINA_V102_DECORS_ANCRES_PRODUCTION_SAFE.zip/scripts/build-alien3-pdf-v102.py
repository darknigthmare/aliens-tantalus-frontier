#!/usr/bin/env python3
from pathlib import Path
import json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4,landscape
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.lib.styles import ParagraphStyle
R=Path(__file__).resolve().parents[1];browser=json.loads((R/'qa-v102/browser.json').read_text());u=json.loads((R/'qa-v102/unit.json').read_text());i=json.loads((R/'qa-v102/installation.json').read_text());reg=json.loads((R/'qa-v102/regressions.json').read_text())
fonts=Path('/usr/share/fonts/truetype/dejavu');pdfmetrics.registerFont(TTFont('D',str(fonts/'DejaVuSans.ttf')));pdfmetrics.registerFont(TTFont('DB',str(fonts/'DejaVuSans-Bold.ttf')))
W,H=landscape(A4);c=canvas.Canvas(str(R/'RAPPORT_ILLUSTRE_V102.pdf'),pagesize=(W,H));c.setTitle('Alien 3 — Fiorina 161 V102 | Décors ancrés');c.setAuthor('Aliens: Tantalus Frontier — documentation locale')
style=ParagraphStyle('body',fontName='D',fontSize=11,leading=16,textColor=HexColor('#293b30'))
small=ParagraphStyle('small',parent=style,fontSize=9,leading=12)
def para(text,x,y,width,st=style):
 p=Paragraph(text,st);_,h=p.wrap(width,600);p.drawOn(c,x,y-h);return y-h

def page(n,title,sub=''):
 c.setFillColor(HexColor('#edf1e9'));c.rect(0,0,W,H,fill=1,stroke=0)
 c.setFillColor(HexColor('#1b3126'));c.rect(0,H-86,W,86,fill=1,stroke=0)
 c.setFillColor(HexColor('#dce3cb'));c.setFont('DB',21);c.drawString(40,H-41,title)
 c.setFont('D',9);c.setFillColor(HexColor('#aaba9d'));c.drawString(40,H-63,sub)
 c.setFillColor(HexColor('#65725d'));c.setFont('D',8);c.drawString(40,17,'V102 · Banc local dans Chromium · acteurs provisoires · pas le build complet du jeu')
 c.drawRightString(W-40,17,f'{n:02d} / 12')
page(1,'Fiorina 161 — Décors ancrés','ALIEN 3 · V102 · Rapport de production locale et captures')
y=H-120
y=para('Cette passe remplace le décor dispersé par des ensembles rattachés aux points réels du niveau. Les meubles restent sur leurs appuis quand le joueur saute ; les fonctions d’une pièce deviennent plus reconnaissables.',40,y,W-80)
y-=28
for x,number,label in [(40,'30','ensembles nommés'),(238,'284','composants ancrés'),(436,'51','formes distinctes'),(634,'10','captures Chromium')]:
 c.setFillColor(HexColor('#d6dfca'));c.rect(x,y-70,168,70,fill=1,stroke=0);c.setFillColor(HexColor('#294b34'));c.setFont('DB',28);c.drawString(x+14,y-31,number);c.setFont('D',10);c.drawString(x+14,y-53,label)
y-=102
y=para('<b>À lire avec les images.</b> Les captures montrent les modules de rendu livrés, exécutés dans un banc jouable local avec un contrôleur simplifié. Le moteur principal, ses assets lourds et le déroulement complet de la campagne ne sont pas chargés.',40,y,W-80)
y-=20
y=para('<b>Contrôles.</b> '+str(u['cases'])+' cas V102 ciblés, '+str(i['cases'])+' scénarios d’installation, '+str(browser['tests'])+' contrôles navigateur et '+str(reg['passed'])+'/'+str(reg['total'])+' scripts historiques isolés. Aucun de ces totaux n’est présenté comme une validation du jeu complet.',40,y,W-80)
y-=20
para('<b>Codex de conception.</b> Neuf secteurs, trente assemblages détaillés, les soixante-douze points et les 119 connexions du graphe sont documentés séparément des archives du joueur. Les 90 textes affichés dans ces archives ont été reformulés sans modifier leurs identifiants.',40,y,W-80)
c.showPage()
titles=['Côte et épave EEV','Infirmerie et morgue','Détention et espaces communs','Galeries de service','Supervision industrielle','Grande fonderie','Pistons et moule','Four principal','Arrivée de la Compagnie','Archives de Fiorina']
captions=['Coque EEV, prise d’air et matériel de secours. Les ensembles suivent les supports du graphe, pas la hauteur du personnage.',
'Brancards avec roues, armoires, lavage, écrans et éclairage. Chaque baie reçoit un vocabulaire de soin distinct.',
'Cellules et couchettes derrière le passage, espaces communs à l’étage. Les baies peintes ne sont pas des portes de gameplay ajoutées.',
'Ventilateur, gaines, pompe et établi. Les équipements sont regroupés par fonction ; la pluie côtière n’envahit pas les intérieurs.',
'Postes et réserve restent liés aux coordonnées des nœuds existants. Le découpage de caméra ne déplace pas les fonctions du lieu.',
'Creuset conique, palan, portique et poche de transfert. Les commandes et collisions héritées restent sous la responsabilité du moteur existant.',
'Tiges, joints et appuis différencient les vérins. Le moule est bas et laisse la zone de circulation visible.',
'Bouche du four, équipements annexes et conduites de service. Les lumières sont associées à une source dessinée.',
'Huit composants de récupération sont visibles seulement après l’arrivée de la Compagnie. L’état opposé a été contrôlé dans le navigateur.',
'Recherche et navigation sur les textes affichés. Les 90 entrées sont conservées ; dessiner une page ne modifie pas la sauvegarde du banc.']
for n,(shot,title,caption) in enumerate(zip(browser['screenshots'],titles,captions),2):
 page(n,title,'Capture native du canvas · 1280 × 720 · état de visualisation préparé dans le banc')
 iw=W-80;ih=iw*720/1280;c.drawImage(str(R/shot['file']),40,72,iw,ih,mask='auto')
 para(caption,40,61,W-80,small);c.showPage()
page(12,'Bilan des contrôles','Ce qui est vérifié, ce qui reste à valider dans le projet complet')
rows=[['Contrôle','Résultat','Portée'],['Contrats V102',f"{u['cases']} cas passés",'Ancrages, supports, coordonnées, variantes, HUD, sauvegarde, recherche.'],['Installation',f"{i['cases']} scénarios",'Fixtures : staging, échecs check/build, reprise et protection des éditions locales.'],['Chromium',f"{browser['tests']} contrôles",'Clavier, saut, profondeur du banc, archives, opacité haute et redimensionnement.'],['Héritage',f"{reg['passed']}/{reg['total']} scripts",'Suites isolées conservées ; pas un parcours complet du jeu.'],['Production complète','Non exécutée','Pas de check/build sur le dépôt complet, pas de push ni de déploiement V102.']]
rows=[[Paragraph(str(x),small) for x in row] for row in rows];tab=Table(rows,colWidths=[148,133,W-361]);tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#d6dfca')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9),('LINEBELOW',(0,0),(-1,-1),.4,HexColor('#bbc8b0'))]));tw,th=tab.wrap(W-80,400);tab.drawOn(c,40,H-110-th)
y=H-135-th
para('La V102 conserve le graphe hérité : <b>72 points, 119 connexions et quatre routes</b>. Ce ne sont pas 72 nouvelles salles. La fidélité 1:1 au film, les sprites définitifs, les collisions de production et l’empilement avec tous les anciens interactifs restent à examiner dans le jeu complet.',40,y,W-80)
y-=78
para('Les journaux, empreintes des sources et états de capture sont dans <b>qa-v102/</b>. Le codex de conception existe en HTML autonome et en Markdown. Le correctif cumulatif et le banc sont fournis séparément du jeu principal.',40,y,W-80,small)
c.showPage();c.save();print(R/'RAPPORT_ILLUSTRE_V102.pdf')
