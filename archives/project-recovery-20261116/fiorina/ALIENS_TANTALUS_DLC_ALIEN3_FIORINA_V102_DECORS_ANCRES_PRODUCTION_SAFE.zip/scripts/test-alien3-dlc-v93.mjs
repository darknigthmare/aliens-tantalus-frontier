import assert from 'node:assert/strict';
import { ALIEN3_CAMPAIGN_ID_V88 } from '../src/alien3-dlc-v88.js';
import { withAlien3DlcRuntimeV88 } from '../src/alien3-dlc-runtime-v88.js';
import { withAlien3DlcRuntimeV89 } from '../src/alien3-dlc-runtime-v89.js';
import { withAlien3DlcRuntimeV90 } from '../src/alien3-dlc-runtime-v90.js';
import { withAlien3DlcRuntimeV91 } from '../src/alien3-dlc-runtime-v91.js';
import { withAlien3DlcRuntimeV92 } from '../src/alien3-dlc-runtime-v92.js';
import {
  ALIEN3_CODEX_V93,
  ALIEN3_FIORINA_TEMPLATE_V93,
  ALIEN3_HISTORICAL_BEATS_V93,
  ALIEN3_PRISONER_ROUTINE_ROLES_V93,
  ALIEN3_RUNNER_PERCHES_V93,
  ALIEN3_V93_EVIDENCE_IDS,
  alien3V93Grade,
  validateAlien3DlcV93
} from '../src/alien3-dlc-v93.js';
import { withAlien3DlcRuntimeV93 } from '../src/alien3-dlc-runtime-v93.js';
import { ALIEN3_V89_EVIDENCE_IDS } from '../src/alien3-dlc-v89.js';
import { ALIEN3_V90_EVIDENCE_IDS } from '../src/alien3-dlc-v90.js';
import { ALIEN3_V91_EVIDENCE_IDS } from '../src/alien3-dlc-v91.js';
import { ALIEN3_V92_EVIDENCE_IDS } from '../src/alien3-dlc-v92.js';

class MockBase {
  constructor() {
    this.events = [];
    this.images = new Map();
    this.enemies = [];
    this.doors = [];
    this.platforms = [
      { id: 'ground', x: 0, y: 510, w: 6200 },
      { id: 'deep', x: 2800, y: 630, w: 1900 },
      { id: 'high', x: 900, y: 330, w: 5300 },
      { id: 'perch', x: 1600, y: 190, w: 3600 }
    ];
    this.player = { id: 'player', x: 180, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, actionClock: 0, fireClock: 0, vx: 0, vy: 0, facing: 1, crouching: false };
    this.coop = { id: 'coop', x: 120, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, vx: 0, vy: 0 };
    this.vehicle = { active: true, occupied: false, driver: null, passengers: [], x: 3200 };
    this.weaponPickup = { taken: false, x: 900 };
    this.toolPickup = { taken: false, x: 1200 };
    this.supplies = [];
    this.objectiveNodes = [];
    this.archiveTerminal = { recovered: false, x: 1500 };
    this.powerNode = { active: false, x: 1800 };
    this.objective = { x: 6000, y: 420, w: 68, h: 90, complete: false };
    this.missionLevelRuntime = { anchors: { extraction: { x: 6040, y: 510 } } };
    this.missionLevelVisualState = { activeZoneId: 'f161-coast' };
    this.mission = { state: 'active', objectives: { power: false, route: false, boss: false, archive: false, extract: false }, rewards: {}, retries: 0, elapsed: 0, casualties: 0 };
    this.inventory = { salvage: 0, intel: 0 };
    this.audio = { ui() {}, alarm() {}, hit() {} };
    this.camera = { x: 0, y: 0 };
    this.animationTime = 0;
    this.onEvent = (event) => this.events.push(event);
  }
  start(options = {}) { this.campaign = options.campaign; this.strategicBriefing = options.strategicBriefing; return { base: true }; }
  createEnemy(profile, index, x, groundY, options = {}) {
    return { ...profile, id: profile.id || `enemy-${index}`, x, y: groundY - 90, w: 90, h: 90, health: profile.health || 100, maxHealth: profile.health || 100, speed: profile.speed || 1, damage: profile.damage || 10, alive: true, facing: -1, alert: false, staggerClock: 0, hurtClock: 0, ...options };
  }
  initializeEnemyMissionNavigation() {}
  interact() { return false; }
  fire() { return false; }
  reload() { return true; }
  toggleVehicle() { return true; }
  useEquipment() { return true; }
  activateTracker() { return false; }
  applyEnemyDamage(enemy, amount) { enemy.health = Math.max(0, enemy.health - amount); if (enemy.health <= 0) enemy.alive = false; return amount; }
  updateEnemy() {}
  drawEnemy() {}
  defeatEnemy(enemy) { enemy.alive = false; enemy.health = 0; return true; }
  damagePlayer(actor, amount) { actor.health = Math.max(0, actor.health - amount); actor.damageTaken += amount; if (actor.health <= 0) actor.alive = false; return amount; }
  update(delta = 0.016) { this.animationTime += delta; return true; }
  missingObjectiveRequirement() { return ''; }
  missingExtractionRequirement() { return ''; }
  completeMission() { this.mission.state = 'complete'; this.mission.rewards = { credits: 100 }; this.onEvent({ type: 'mission-complete', rewards: this.mission.rewards }); return true; }
  restartFromCheckpoint() { this.mission.state = 'active'; return true; }
  phaseLabel() { return 'BASE'; }
  objectiveProgressText() { return 'BASE'; }
  getInteractionPrompt() { return ''; }
  drawWorld() {}
  drawHud() {}
  captureResumeState() { return { schema: 1, player: { x: this.player.x, y: this.player.y } }; }
  applyResumeState() { return { applied: true, restored: 1 }; }
  getGameplayReport() { return { base: true }; }
  getSnapshot() { return { base: true }; }
  locked(requirement) { this.events.push({ type: 'locked', requirement }); return false; }
}

const V88 = withAlien3DlcRuntimeV88(MockBase);
const V89 = withAlien3DlcRuntimeV89(V88);
const V90 = withAlien3DlcRuntimeV90(V89);
const V91 = withAlien3DlcRuntimeV91(V90);
const V92 = withAlien3DlcRuntimeV92(V91);
const Engine = withAlien3DlcRuntimeV93(V92);

const validation = validateAlien3DlcV93();
assert.equal(validation.ok, true, validation.failures.join('; '));
assert.equal(validation.counts.nodes, 54);
assert.equal(validation.counts.edges, 87);
assert.equal(ALIEN3_FIORINA_TEMPLATE_V93.routes.length, 4);
assert.equal(ALIEN3_CODEX_V93.length, 14);
assert.equal(ALIEN3_V93_EVIDENCE_IDS.length, 14);
assert.equal(ALIEN3_HISTORICAL_BEATS_V93.length, 4);
assert.equal(ALIEN3_RUNNER_PERCHES_V93.length, 3);
assert.equal(ALIEN3_PRISONER_ROUTINE_ROLES_V93.length, 4);

const engine = new Engine();
engine.start({
  campaign: { id: ALIEN3_CAMPAIGN_ID_V88 },
  strategicBriefing: { flags: { 'alien3-v90-challenge': 'archive' } },
  enemyCatalog: [{ id: 'enemy-006-runner', name: 'Runner Fiorina', biology: 'xenomorph', caste: 'runner', health: 720, damage: 29, speed: 1.9 }]
});
const moveToStation = (id) => {
  const station = engine.alien3StationV93(id);
  assert.ok(station, id);
  engine.player.x = station.x;
  engine.player.y = station.y;
  return station;
};
const visitBeat = (beatId) => {
  const beat = ALIEN3_HISTORICAL_BEATS_V93.find((entry) => entry.id === beatId);
  assert.ok(beat, beatId);
  engine.player.x = beat.x - engine.player.w / 2;
  engine.player.y = beat.y - engine.player.h / 2;
  engine.updateAlien3HistoricalBeatsV93();
  assert.equal(engine.alien3V93.historical.triggered[beatId], true, beatId);
};

// Historical beats remain playable and do not pause the engine.
engine.alien3V88.phase = 'first-blood';
for (const id of ['murphy', 'tunnels', 'clemens', 'andrews']) visitBeat(id);
assert.equal(engine.alien3V93.historical.count, 4);
assert.equal(engine.alien3V93.evidenceRecovered.includes('seamless-cinematics'), true);
assert.ok(engine.alien3V93.cinematic.cardsShown >= 4);
assert.equal(engine.mission.state, 'active');

// Prisoners receive four physical jobs and can approach danger without an automatic casualty.
engine.alien3V88.phase = 'trap-prep';
moveToStation('f161-routine-board-v93');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V93.routines.boardRead, true);
assert.equal(engine.alien3V93.routines.activeRoles, 4);
assert.equal(Object.keys(engine.alien3V93.routines.assignments).length > 0, true);
const exposed = engine.alien3PrisonersV89.find((entry) => entry.status === 'active');
assert.ok(exposed);
engine.alien3RunnerV88.x = exposed.x + 10;
engine.alien3RunnerV88.y = exposed.y;
for (let i = 0; i < 5; i += 1) engine.updateAlien3PrisonerRoutinesV93(0.2);
assert.equal(engine.alien3V93.evidenceRecovered.includes('prisoner-risk'), true);
assert.equal(engine.alien3V93.routines.avoidableCasualties, 0);
engine.alien3RunnerV88.x = 5600;
engine.updateAlien3PrisonerRoutinesV93(0.5);

// The one Runner learns a sprint-heavy player style, perches offscreen and drops back to ground.
engine.alien3V88.phase = 'bishop';
engine.alien3V88.runner.active = true;
engine.alien3RunnerV88.alive = true;
engine.alien3RunnerV88.x = 5600;
engine.alien3RunnerV88.y = 420;
engine.alien3V91.hunter.heat = 42;
engine.alien3V93.runnerMind.perchCooldown = 0;
engine.player.x = 1800;
engine.player.vx = 240;
engine.camera.x = 0;
for (let i = 0; i < 18; i += 1) engine.updateAlien3RunnerMindV93(0.2);
assert.ok(engine.alien3V93.telemetry.runnerPerches >= 1);
assert.equal(engine.alien3V93.evidenceRecovered.includes('runner-perches'), true);
assert.equal(engine.alien3V93.evidenceRecovered.includes('runner-learning'), true);
for (let i = 0; i < 20; i += 1) engine.updateAlien3RunnerMindV93(0.2);
assert.ok(engine.alien3V93.runnerMind.drops >= 1);
assert.equal(engine.alien3V93.runnerMind.perchId, null);

// Patna finale is split into parley, Aaron, Morse and witness confirmation.
engine.alien3V88.phase = 'company';
moveToStation('f161-company-parley-v93');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V93.company.parleyResolved, true);
assert.equal(engine.alien3V93.company.cageDeployed, true);
engine.alien3V88.phase = 'finale';
for (const id of ['f161-aaron-charge-v93', 'f161-morse-wound-v93', 'f161-witness-terminal-v93']) {
  moveToStation(id);
  assert.equal(engine.interact(engine.player), true, id);
}
assert.equal(engine.alien3V93.company.aaronCharge, true);
assert.equal(engine.alien3V93.company.morseWound, true);
assert.equal(engine.alien3V93.company.witnessConfirmed, true);
assert.equal(engine.alien3V89.company.morseWounded, true);
assert.equal(engine.alien3V91.company.morseCustody, true);

// Complete inherited evidence to validate the V93 perfect-archive contract.
engine.alien3V89.evidenceRecovered = [...ALIEN3_V89_EVIDENCE_IDS];
engine.alien3V90.evidenceRecovered = [...ALIEN3_V90_EVIDENCE_IDS];
engine.alien3V91.evidenceRecovered = [...ALIEN3_V91_EVIDENCE_IDS];
engine.alien3V92.evidenceRecovered = [...ALIEN3_V92_EVIDENCE_IDS];
for (const id of ALIEN3_V93_EVIDENCE_IDS.filter((id) => id !== 'perfect-archive-run')) engine.recoverAlien3EvidenceV93(id, { silent: true });
engine.alien3V88.runnerDefeated = true;
engine.alien3V88.phase = 'finale';
engine.updateAlien3ArchivePerfectV93();
assert.equal(engine.alien3V93.archivePerfect.perfect, true);
assert.equal(engine.alien3V93.evidenceRecovered.length, ALIEN3_V93_EVIDENCE_IDS.length);
assert.equal(engine.alien3V93.codexUnlocked.length, ALIEN3_CODEX_V93.length);

const grade = alien3V93Grade({ gradeV92: 'S+++', evidence: ALIEN3_V93_EVIDENCE_IDS.length, historical: 4, avoidableCasualties: 0, perfect: true });
assert.equal(grade, 'S++++');

const saved = engine.captureResumeState();
assert.equal(saved.specialOperation.alien3V93.schema, 93);
const resumed = new Engine();
resumed.start({ campaign: { id: ALIEN3_CAMPAIGN_ID_V88 }, strategicBriefing: { flags: {} }, enemyCatalog: [{ id: 'enemy-006-runner', name: 'Runner Fiorina', biology: 'xenomorph', caste: 'runner', health: 720, damage: 29, speed: 1.9 }] });
const restored = resumed.applyResumeState(saved);
assert.equal(restored.applied, true);
assert.equal(restored.alien3DlcRestoredV93, true);
assert.equal(resumed.alien3V93.evidenceRecovered.length, ALIEN3_V93_EVIDENCE_IDS.length);
assert.equal(resumed.alien3V93.archivePerfect.perfect, true);
assert.equal(resumed.alien3V93.company.witnessConfirmed, true);

console.log(JSON.stringify({
  ok: true,
  validation,
  historicalBeats: engine.alien3V93.historical.count,
  evidenceRecovered: engine.alien3V93.evidenceRecovered.length,
  codexUnlocked: engine.alien3V93.codexUnlocked.length,
  routineRoles: engine.alien3V93.routines.activeRoles,
  avoidableCasualties: engine.alien3V93.routines.avoidableCasualties,
  runnerMind: {
    learnedStyle: engine.alien3V93.runnerMind.learnedStyle,
    perches: engine.alien3V93.telemetry.runnerPerches,
    drops: engine.alien3V93.runnerMind.drops,
    predictionStrength: engine.alien3V93.runnerMind.predictionStrength
  },
  company: engine.alien3V93.company,
  perfectArchive: engine.alien3V93.archivePerfect,
  grade,
  resume: { restored: restored.alien3DlcRestoredV93, evidence: resumed.alien3V93.evidenceRecovered.length }
}, null, 2));
