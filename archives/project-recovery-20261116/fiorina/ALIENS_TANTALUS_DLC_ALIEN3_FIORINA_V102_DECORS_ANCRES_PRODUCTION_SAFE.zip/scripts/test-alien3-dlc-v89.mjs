import assert from 'node:assert/strict';
import { ALIEN3_CAMPAIGN_ID_V88 } from '../src/alien3-dlc-v88.js';
import { withAlien3DlcRuntimeV88 } from '../src/alien3-dlc-runtime-v88.js';
import {
  ALIEN3_CODEX_V89,
  ALIEN3_FIORINA_TEMPLATE_V89,
  ALIEN3_V89_EVIDENCE_IDS,
  validateAlien3DlcV89
} from '../src/alien3-dlc-v89.js';
import { withAlien3DlcRuntimeV89 } from '../src/alien3-dlc-runtime-v89.js';

class MockBase {
  constructor() {
    this.events = [];
    this.images = new Map();
    this.enemies = [];
    this.doors = [];
    this.platforms = [
      { id: 'ground', x: 0, y: 510, w: 6200 },
      { id: 'deep', x: 2800, y: 630, w: 1900 },
      { id: 'high', x: 1000, y: 330, w: 5000 }
    ];
    this.player = { id: 'player', x: 180, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, actionClock: 0, fireClock: 0, vx: 0, vy: 0, facing: 1 };
    this.coop = { id: 'coop', x: 120, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, vx: 0, vy: 0 };
    this.vehicle = { active: true, occupied: true, driver: this.player, passengers: [this.coop], x: 3200 };
    this.weaponPickup = { taken: false, x: 900 };
    this.toolPickup = { taken: false, x: 1200 };
    this.supplies = [{ type: 'ammo', amount: 24 }, { type: 'medkit', amount: 1 }];
    this.objectiveNodes = [{ id: 'generic-node' }];
    this.archiveTerminal = { recovered: false, x: 1500 };
    this.powerNode = { active: false, x: 1800 };
    this.objective = { x: 6000, y: 420, w: 68, h: 90, complete: false };
    this.missionLevelRuntime = { anchors: { extraction: { x: 6040, y: 510 } } };
    this.mission = { state: 'active', objectives: { power: false, route: false, boss: false, archive: false, extract: false }, rewards: {}, retries: 0, elapsed: 100, casualties: 0 };
    this.inventory = { salvage: 0, intel: 0 };
    this.audio = { ui() {}, alarm() {}, hit() {} };
    this.camera = { x: 0, y: 0 };
    this.animationTime = 0;
    this.onEvent = (event) => this.events.push(event);
  }
  start(options = {}) { this.campaign = options.campaign; return { base: true }; }
  createEnemy(profile, index, x, groundY, options = {}) {
    return {
      ...profile, id: profile.id || `enemy-${index}`, x, y: groundY - 90, w: 90, h: 90,
      health: profile.health || 100, maxHealth: profile.health || 100, speed: profile.speed || 1,
      damage: profile.damage || 10, alive: true, facing: -1, alert: false, staggerClock: 0, hurtClock: 0, ...options
    };
  }
  initializeEnemyMissionNavigation() {}
  interact() { return false; }
  fire() { return false; }
  reload() { return true; }
  toggleVehicle() { return true; }
  useEquipment() { return true; }
  activateTracker() { return false; }
  applyEnemyDamage(enemy, amount) { enemy.health = Math.max(0, enemy.health - amount); if (enemy.health <= 0) enemy.alive = false; return amount; }
  updateEnemy() {}
  drawEnemy() {}
  defeatEnemy(enemy) { enemy.alive = false; enemy.health = 0; return true; }
  damagePlayer(actor, amount) { actor.health = Math.max(0, actor.health - amount); actor.damageTaken += amount; if (actor.health <= 0) actor.alive = false; return amount; }
  update(delta = 0.016) { this.animationTime += delta; return true; }
  missingObjectiveRequirement() { return ''; }
  missingExtractionRequirement() { return ''; }
  completeMission() { this.mission.state = 'complete'; this.mission.rewards = { credits: 100, salvage: 2, intel: 1 }; this.onEvent({ type: 'mission-complete', kills: 0, rewards: this.mission.rewards }); return true; }
  restartFromCheckpoint() { this.mission.state = 'active'; return true; }
  phaseLabel() { return 'BASE'; }
  objectiveProgressText() { return 'BASE'; }
  getInteractionPrompt() { return ''; }
  drawWorld() {}
  drawHud() {}
  captureResumeState() { return { schema: 1, player: { x: this.player.x, y: this.player.y } }; }
  applyResumeState() { return { applied: true, restored: 1 }; }
  getGameplayReport() { return { base: true }; }
  getSnapshot() { return { base: true }; }
  locked(requirement) { this.events.push({ type: 'locked', requirement }); return false; }
}

const V88 = withAlien3DlcRuntimeV88(MockBase);
const Engine = withAlien3DlcRuntimeV89(V88);
const validation = validateAlien3DlcV89();
assert.equal(validation.ok, true, validation.failures.join('; '));
assert.equal(ALIEN3_FIORINA_TEMPLATE_V89.routes.length, 4);
assert.equal(ALIEN3_CODEX_V89.length, 12);
assert.equal(ALIEN3_FIORINA_TEMPLATE_V89.nodes.some((node) => node.id === 'f161-waste-tank'), true);

const makeEngine = () => {
  const engine = new Engine();
  engine.start({
    campaign: { id: ALIEN3_CAMPAIGN_ID_V88 },
    enemyCatalog: [{ id: 'enemy-006-runner', name: 'Runner', biology: 'xenomorph', caste: 'runner', health: 720, damage: 29, speed: 1.9 }]
  });
  return engine;
};

const moveToV88 = (engine, stationId) => {
  const station = engine.alien3StationV88(stationId);
  assert.ok(station, stationId);
  engine.player.x = station.x;
  engine.player.y = station.y;
  return station;
};
const moveToV89 = (engine, stationId) => {
  const station = engine.alien3StationV89(stationId);
  assert.ok(station, stationId);
  engine.player.x = station.x;
  engine.player.y = station.y;
  return station;
};
const advance = (engine, seconds, step = 0.1) => {
  let remaining = seconds;
  while (remaining > 0) {
    const delta = Math.min(step, remaining);
    engine.update(delta);
    remaining -= delta;
  }
};

const engine = makeEngine();
assert.equal(engine.alien3V89.cut, 'theatrical');
assert.equal(engine.alien3V89.evidenceRecovered.includes('runner-director'), true);

moveToV89(engine, 'f161-cut-assembly-terminal');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V89.cut, 'assembly');
assert.equal(engine.alien3V89.codexUnlocked.includes('f161-host-babe'), true);

moveToV88(engine, 'f161-eev-recorder');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V89.cutLocked, true);
assert.equal(engine.alien3V88.phase, 'infirmary');

moveToV88(engine, 'f161-autopsy');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'first-blood');

// The first potentially lethal Runner strike is converted into the canon sparing beat.
engine.player.health = 15;
assert.ok(engine.damagePlayer(engine.player, 40, { source: engine.alien3RunnerV88.name }) >= 0);
assert.equal(engine.player.alive, true);
assert.equal(engine.player.health, 8);
assert.equal(engine.alien3V89.director.sparingUsed, true);
assert.equal(engine.alien3V89.codexUnlocked.includes('f161-queen-sparing'), true);
advance(engine, 2.6);

engine.player.x = 2800;
engine.update(0.1);
assert.equal(engine.alien3V88.phase, 'bishop');

moveToV88(engine, 'f161-bishop-memory');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'trap-prep');

moveToV89(engine, 'f161-prison-register');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V89.evidenceRecovered.includes('prison-roster'), true);

for (const id of ['f161-cache-infirmary', 'f161-cache-cellblock', 'f161-cache-service']) {
  moveToV88(engine, id);
  assert.equal(engine.interact(engine.player), true, id);
}
const flaresBefore = engine.alien3V88.flares;
assert.equal(engine.fire(engine.player), true);
assert.equal(engine.alien3V88.flares, flaresBefore - 1);
assert.equal(engine.alien3V89.flares.length, 1);
assert.equal(engine.alien3V89.director.mode, 'lure');

moveToV88(engine, 'f161-fire-igniter');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'fire-maze');

// Conventional damage remains ineffective and is tracked by the V89 director.
const runnerHealthBeforeConventionalHit = engine.alien3RunnerV88.health;
engine.applyEnemyDamage(engine.alien3RunnerV88, 250, { kind: 'pulse-rifle' });
assert.equal(engine.alien3RunnerV88.health, runnerHealthBeforeConventionalHit);
assert.equal(engine.alien3V89.director.conventionalHitsResisted, 1);

// A physical flare must actually lure the now-active Runner and be consumed at close range.
const lureFlare = engine.alien3V89.flares[0];
engine.alien3RunnerV88.x = lureFlare.x + 18;
engine.alien3RunnerV88.y = lureFlare.y - engine.alien3RunnerV88.h / 2;
engine.updateEnemy(engine.alien3RunnerV88, 0.03);
assert.equal(engine.alien3V89.director.flaresConsumed, 1);
assert.equal(lureFlare.consumed, true);

// High tension can relocate the unique Runner to an authored off-camera ambush anchor.
engine.player.x = 3000;
engine.player.y = 420;
engine.camera.x = 2500;
engine.alien3RunnerV88.x = 120;
engine.alien3RunnerV88.y = 420;
engine.alien3V89.director.mode = 'ambush';
engine.alien3V89.director.tension = 90;
engine.alien3V89.director.relocationCooldown = 0;
engine.updateAlien3DirectorV89(0.1);
assert.equal(engine.alien3V89.director.ambushes, 1);
assert.ok(engine.alien3V89.director.lastAnchorId);

// Assembly route must pass through the authored waste tank before leadworks.
engine.player.x = 4400;
engine.update(0.1);
assert.equal(engine.alien3V88.phase, 'fire-maze');
const waste = moveToV89(engine, 'f161-waste-tank-control');
engine.alien3RunnerV88.x = waste.x + 30;
engine.alien3RunnerV88.y = waste.y;
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V89.assembly.wasteTankTrapped, true);
assert.equal(engine.alien3V89.prisoners.junior, 'deceased');
assert.equal(engine.alien3V88.runner.active, false);
advance(engine, 4.8);
assert.equal(engine.alien3V89.assembly.golicReleased, true);
assert.equal(engine.alien3V89.prisoners.golic, 'deceased');
assert.equal(engine.alien3V89.prisoners.arthur, 'deceased');
assert.equal(engine.alien3V88.runner.active, true);

engine.player.x = 4400;
engine.update(0.1);
assert.equal(engine.alien3V88.phase, 'leadworks');

const mold = moveToV88(engine, 'f161-mold-control');
engine.alien3RunnerV88.x = mold.x + 40;
engine.alien3RunnerV88.y = mold.y;
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'molten-lead');
moveToV88(engine, 'f161-sprinkler-control');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.runnerDefeated, true);
advance(engine, 1.4);
assert.equal(engine.alien3V88.phase, 'company');
assert.equal(engine.alien3V89.company.visible, true);

moveToV89(engine, 'f161-patna-manifest');
assert.equal(engine.interact(engine.player), true);
moveToV88(engine, 'f161-company-contact');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'finale');

moveToV89(engine, 'f161-morse-witness-log');
assert.equal(engine.interact(engine.player), true);
moveToV88(engine, 'f161-final-ledge');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.mission.state, 'active');
assert.equal(engine.alien3V89.finale.started, true);
advance(engine, 3.5);
assert.equal(engine.mission.state, 'complete');
assert.equal(engine.alien3V89.finale.completed, true);
assert.equal(engine.alien3V89.finale.queenEmerges, false);
assert.equal(engine.mission.rewards.alien3V89, true);
assert.equal(engine.mission.rewards.archiveCut, 'assembly');
assert.equal(engine.mission.rewards.finaleVariant, 'assembly-no-emergence');
assert.ok(['S', 'A', 'B', 'C', 'D'].includes(engine.mission.rewards.mireGrade));

const saved = engine.captureResumeState();
assert.equal(saved.specialOperation.alien3V89.schema, 89);
assert.equal(saved.specialOperation.alien3V89.cut, 'assembly');
const resumed = makeEngine();
const resumeResult = resumed.applyResumeState(saved);
assert.equal(resumeResult.applied, true);
assert.equal(resumed.alien3V89.cut, 'assembly');
assert.equal(resumed.alien3V89.assembly.golicReleased, true);
assert.equal(resumed.alien3V89.finale.completed, true);

// The theatrical branch keeps the alternate ending presentation distinct.
const theatrical = makeEngine();
theatrical.alien3V88.phase = 'finale';
theatrical.alien3V88.companyRefused = true;
theatrical.alien3V89.cut = 'theatrical';
moveToV89(theatrical, 'f161-morse-witness-log');
assert.equal(theatrical.interact(theatrical.player), true);
moveToV88(theatrical, 'f161-final-ledge');
assert.equal(theatrical.interact(theatrical.player), true);
advance(theatrical, 2.5);
assert.equal(theatrical.alien3V89.finale.queenEmerges, true);

console.log(JSON.stringify({
  ok: true,
  validation,
  cut: engine.alien3V89.cut,
  evidenceRecovered: engine.alien3V89.evidenceRecovered.length,
  evidenceTotal: ALIEN3_V89_EVIDENCE_IDS.length,
  codexV89Unlocked: engine.alien3V89.codexUnlocked.length,
  director: engine.alien3V89.director,
  assembly: engine.alien3V89.assembly,
  finale: engine.alien3V89.finale,
  rewards: engine.mission.rewards,
  eventCount: engine.events.length
}, null, 2));
