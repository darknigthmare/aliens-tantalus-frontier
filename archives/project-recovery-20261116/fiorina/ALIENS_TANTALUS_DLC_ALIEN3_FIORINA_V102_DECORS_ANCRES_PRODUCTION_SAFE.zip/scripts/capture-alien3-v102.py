#!/usr/bin/env python3
"""Capture the local playable rendering bench in Chromium. No game art is redrawn.
Requires Python playwright and Chromium. The self-contained bundle loads ES modules
through Blob URLs, so this test does not require network access or a local server.
This is NOT an end-to-end run of the complete production game.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys, shutil
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'qa-v102'; SHOTS=OUT/'captures'; SHOTS.mkdir(parents=True, exist_ok=True)
subprocess.run([sys.executable,str(ROOT/'scripts/build-alien3-preview-v102.py')],check=True)
html=(ROOT/'atelier/FIORINA_V102_APERCU_LOCAL.html').read_text()
names=['01_cote_eev','02_infirmerie_morgue','03_detention','04_galeries','05_supervision','06_fonderie','07_pistons_moule','08_four','09_compagnie']
checks=[]; shots=[]; errors=[]
def record(name,value,details=None):
    if not value: raise AssertionError(name+': '+str(details))
    checks.append({'name':name,'ok':True, **({'details':details} if details is not None else {})})
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=shutil.which('chromium') or shutil.which('chromium-browser'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    version=browser.version
    page=browser.new_page(viewport={'width':1280,'height':720},device_scale_factor=1)
    page.on('pageerror',lambda e:errors.append(str(e)))
    requests=[];page.on('request',lambda req:requests.append(req.url))
    page.set_content('<script>window.__BENCH_QUERY__="capture=1&freeze=1&room=0"</script>'+html,wait_until='load')
    page.wait_for_function('!!window.fiorinaBench')
    record('Actual shared V102 module loaded',page.evaluate('fiorinaBench.engine.isAlien3MissionV102()'))
    for i,name in enumerate(names):
        page.evaluate('(i)=>{fiorinaBench.setLocation(i);fiorinaBench.engine.paused=false;fiorinaBench.render();}',i)
        page.locator('canvas').screenshot(path=str(SHOTS/(name+'.png')))
        state=page.evaluate('({player:fiorinaBench.engine.player,camera:fiorinaBench.engine.camera,propsDrawn:fiorinaBench.engine.alien3RenderStatsV102.props,flags:fiorinaBench.engine.getAlien3VisualFlagsV102()})')
        shots.append({'file':'qa-v102/captures/'+name+'.png','room':i,'state':state})
    # Mutations are user inputs or test setup. Rendering itself must not grant progress.
    pure=page.evaluate('''()=>{const e=fiorinaBench.engine;const before=JSON.stringify(e.captureResumeState());for(let i=0;i<10;i++)fiorinaBench.render();return before===JSON.stringify(e.captureResumeState());}''')
    record('Ten rendering passes leave the save unchanged',pure)
    before=page.evaluate('fiorinaBench.engine.player.x')
    page.keyboard.down('ArrowRight')
    page.evaluate('()=>{for(let i=0;i<20;i++)fiorinaBench.tick(1/60)}')
    page.keyboard.up('ArrowRight')
    after=page.evaluate('fiorinaBench.engine.player.x')
    record('Right key moves right in the local controller',after>before,{'delta':round(after-before,3)})
    page.keyboard.down('ArrowLeft');page.evaluate('()=>{for(let i=0;i<20;i++)fiorinaBench.tick(1/60)}');page.keyboard.up('ArrowLeft')
    record('Left key moves left',page.evaluate('fiorinaBench.engine.player.x')<after)
    page.evaluate('()=>{fiorinaBench.setLocation(5);fiorinaBench.tick(1/60)}')
    jump_before=page.evaluate('({y:fiorinaBench.engine.player.y,geometry:JSON.stringify(fiorinaBench.engine.alien3DecorSceneV102)})')
    page.keyboard.down('Space');page.evaluate('fiorinaBench.tick(1/60)');page.keyboard.up('Space');page.evaluate('()=>{for(let i=0;i<8;i++)fiorinaBench.tick(1/60)}')
    jump_after=page.evaluate('({y:fiorinaBench.engine.player.y,geometry:JSON.stringify(fiorinaBench.engine.alien3DecorSceneV102)})')
    record('Jump changes player altitude',jump_after['y']<jump_before['y'])
    record('Jump never displaces scenery',jump_after['geometry']==jump_before['geometry'])
    page.evaluate('()=>{fiorinaBench.setLocation(0);fiorinaBench.tick(1/60)}')
    page.keyboard.down('ArrowUp');page.evaluate('()=>{for(let i=0;i<4;i++)fiorinaBench.tick(1/60)}');page.keyboard.up('ArrowUp')
    record('Depth control changes plane away from a ladder',page.evaluate('fiorinaBench.engine.player.depth')==0)
    page.keyboard.press('Escape');x=page.evaluate('fiorinaBench.engine.player.x')
    page.keyboard.down('ArrowRight');page.evaluate('fiorinaBench.tick(.2)');page.keyboard.up('ArrowRight')
    record('Pause freezes movement',page.evaluate('fiorinaBench.engine.player.x')==x)
    page.keyboard.press('Escape')
    page.keyboard.press('KeyC');record('C opens the actual V102 archive panel',page.evaluate('fiorinaBench.engine.alien3V98.codexUi.open'))
    old=page.evaluate('fiorinaBench.engine.alien3V99.codexGraph.currentId');page.keyboard.press('Period')
    record('Archive navigation changes the selected entry',page.evaluate('fiorinaBench.engine.alien3V99.codexGraph.currentId')!=old)
    page.keyboard.press('Slash');page.locator('#archive-search').fill('Runner');page.keyboard.press('Enter')
    record('Archive search returns matching entries',page.evaluate('fiorinaBench.engine.alien3CodexVisibleEntriesV99().length')>0)
    page.locator('canvas').screenshot(path=str(SHOTS/'10_archives.png'));shots.append({'file':'qa-v102/captures/10_archives.png','room':'archive','state':{'query':'Runner'}})
    pure=page.evaluate('''()=>{const e=fiorinaBench.engine;const before=JSON.stringify(e.captureResumeState());for(let i=0;i<10;i++)fiorinaBench.render();return before===JSON.stringify(e.captureResumeState());}''')
    record('Archive drawing does not mark pages read or alter saves',pure)
    page.keyboard.press('KeyC');record('C closes the archive',not page.evaluate('fiorinaBench.engine.alien3V98.codexUi.open'))
    coverage=page.evaluate('''()=>{const e=fiorinaBench.engine,c=document.querySelector('canvas').getContext('2d'),rows=[];for(const x of [0,2100,4920])for(const y of [0,55,110]){e.camera={x,y};c.clearRect(0,0,1280,720);e.drawBackdrop(c);const a=c.getImageData(0,0,1280,1).data;let ok=true;for(let i=3;i<a.length;i+=4)if(a[i]!==255)ok=false;rows.push({x,y,opaque:ok});}return rows;}''')
    record('Background covers the first pixel row for 9 camera positions',all(x['opaque'] for x in coverage),coverage)
    continuity=page.evaluate('''()=>{const e=fiorinaBench.engine,c=document.querySelector('canvas').getContext('2d'),arr=[];for(const x of [207.9,208.1]){e.camera={x,y:0};c.clearRect(0,0,1280,720);e.drawBackdrop(c);arr.push(c.getImageData(0,0,1280,720).data);}let diff=0;for(let i=0;i<arr[0].length;i+=4)for(let k=0;k<3;k++)diff+=Math.abs(arr[0][i+k]-arr[1][i+k]);return diff/(1280*720*3);}''')
    record('Background transition has no abrupt whole-screen replacement',continuity<6,{'meanChannelDifference':continuity})
    company=page.evaluate('''()=>{const e=fiorinaBench.engine;fiorinaBench.setLocation(8);e.alien3V88.phase='leadworks';e.alien3V89.company.visible=false;fiorinaBench.render();const before=e.alien3RenderStatsV102.props;e.alien3V89.company.visible=true;fiorinaBench.render();return {before,after:e.alien3RenderStatsV102.props};}''')
    record('Company kit is actually culled until arrival',company['after']-company['before']==8,company)
    page.set_viewport_size({'width':844,'height':390});page.evaluate('fiorinaBench.render()')
    box=page.locator('canvas').bounding_box();record('Canvas scales inside mobile landscape viewport',box['width']<=844 and box['height']<=390,box)
    record('No browser JavaScript errors',not errors,errors)
    record('No external network request',not [u for u in requests if u.startswith(('https:','http:'))])
    browser.close()
for shot in shots:
    raw=(ROOT/shot['file']).read_bytes();shot.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),width=1280,height=720)
source_hashes={f'src/{name}':hashlib.sha256((ROOT/'src'/name).read_bytes()).hexdigest() for name in ['alien3-dlc-v102.js','alien3-dlc-runtime-v102.js','alien3-art-v102.js']}
result={'ok':True,'scope':'Local playable rendering bench, V101/V102 mixins, simplified controller, placeholder actors. NOT complete production game.', 'captureMethod':'Chromium page.set_content, actual shared ES modules loaded via Blob URLs; native canvas screenshots', 'browser':version,'capturedAt':datetime.now(timezone.utc).isoformat(),'tests':len(checks),'results':checks,'screenshots':shots,'sourceHashes':source_hashes,'productionBuildTested':False}
(OUT/'browser.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'ok':True,'tests':len(checks),'screenshots':len(shots),'browser':version}))
