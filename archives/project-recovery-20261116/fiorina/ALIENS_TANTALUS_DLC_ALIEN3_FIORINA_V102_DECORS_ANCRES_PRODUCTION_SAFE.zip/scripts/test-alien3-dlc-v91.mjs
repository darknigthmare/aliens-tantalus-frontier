import assert from 'node:assert/strict';
import { ALIEN3_CAMPAIGN_ID_V88 } from '../src/alien3-dlc-v88.js';
import { withAlien3DlcRuntimeV88 } from '../src/alien3-dlc-runtime-v88.js';
import { withAlien3DlcRuntimeV89 } from '../src/alien3-dlc-runtime-v89.js';
import { withAlien3DlcRuntimeV90 } from '../src/alien3-dlc-runtime-v90.js';
import {
  ALIEN3_CODEX_V91,
  ALIEN3_FIORINA_TEMPLATE_V91,
  ALIEN3_FOUNDRY_PISTONS_V91,
  ALIEN3_V91_EVIDENCE_IDS,
  validateAlien3DlcV91
} from '../src/alien3-dlc-v91.js';
import { withAlien3DlcRuntimeV91 } from '../src/alien3-dlc-runtime-v91.js';

class MockBase {
  constructor() {
    this.events = [];
    this.images = new Map();
    this.enemies = [];
    this.doors = [];
    this.platforms = [
      { id: 'ground', x: 0, y: 510, w: 6200 },
      { id: 'deep', x: 2800, y: 630, w: 1900 },
      { id: 'high', x: 1000, y: 330, w: 5000 }
    ];
    this.player = { id: 'player', x: 180, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, actionClock: 0, fireClock: 0, vx: 0, vy: 0, facing: 1, crouching: false };
    this.coop = { id: 'coop', x: 120, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, vx: 0, vy: 0 };
    this.vehicle = { active: true, occupied: true, driver: this.player, passengers: [this.coop], x: 3200 };
    this.weaponPickup = { taken: false, x: 900 };
    this.toolPickup = { taken: false, x: 1200 };
    this.supplies = [{ type: 'ammo', amount: 24 }, { type: 'medkit', amount: 1 }];
    this.objectiveNodes = [{ id: 'generic-node' }];
    this.archiveTerminal = { recovered: false, x: 1500 };
    this.powerNode = { active: false, x: 1800 };
    this.objective = { x: 6000, y: 420, w: 68, h: 90, complete: false };
    this.missionLevelRuntime = { anchors: { extraction: { x: 6040, y: 510 } } };
    this.missionLevelVisualState = { activeZoneId: 'f161-coast' };
    this.mission = { state: 'active', objectives: { power: false, route: false, boss: false, archive: false, extract: false }, rewards: {}, retries: 0, elapsed: 100, casualties: 0 };
    this.inventory = { salvage: 0, intel: 0 };
    this.audio = { ui() {}, alarm() {}, hit() {} };
    this.camera = { x: 0, y: 0 };
    this.animationTime = 0;
    this.onEvent = (event) => this.events.push(event);
  }
  start(options = {}) { this.campaign = options.campaign; this.strategicBriefing = options.strategicBriefing; return { base: true }; }
  createEnemy(profile, index, x, groundY, options = {}) {
    return { ...profile, id: profile.id || `enemy-${index}`, x, y: groundY - 90, w: 90, h: 90, health: profile.health || 100, maxHealth: profile.health || 100, speed: profile.speed || 1, damage: profile.damage || 10, alive: true, facing: -1, alert: false, staggerClock: 0, hurtClock: 0, ...options };
  }
  initializeEnemyMissionNavigation() {}
  interact() { return false; }
  fire() { return false; }
  reload() { return true; }
  toggleVehicle() { return true; }
  useEquipment() { return true; }
  activateTracker() { return false; }
  applyEnemyDamage(enemy, amount) { enemy.health = Math.max(0, enemy.health - amount); if (enemy.health <= 0) enemy.alive = false; return amount; }
  updateEnemy() {}
  drawEnemy() {}
  defeatEnemy(enemy) { enemy.alive = false; enemy.health = 0; return true; }
  damagePlayer(actor, amount) { actor.health = Math.max(0, actor.health - amount); actor.damageTaken += amount; if (actor.health <= 0) actor.alive = false; return amount; }
  update(delta = 0.016) { this.animationTime += delta; return true; }
  missingObjectiveRequirement() { return ''; }
  missingExtractionRequirement() { return ''; }
  completeMission() { this.mission.state = 'complete'; this.mission.rewards = { credits: 100, salvage: 2, intel: 1 }; this.onEvent({ type: 'mission-complete', kills: 0, rewards: this.mission.rewards }); return true; }
  restartFromCheckpoint() { this.mission.state = 'active'; return true; }
  phaseLabel() { return 'BASE'; }
  objectiveProgressText() { return 'BASE'; }
  getInteractionPrompt() { return ''; }
  drawWorld() {}
  drawHud() {}
  captureResumeState() { return { schema: 1, player: { x: this.player.x, y: this.player.y } }; }
  applyResumeState() { return { applied: true, restored: 1 }; }
  getGameplayReport() { return { base: true }; }
  getSnapshot() { return { base: true }; }
  locked(requirement) { this.events.push({ type: 'locked', requirement }); return false; }
}

const V88 = withAlien3DlcRuntimeV88(MockBase);
const V89 = withAlien3DlcRuntimeV89(V88);
const V90 = withAlien3DlcRuntimeV90(V89);
const Engine = withAlien3DlcRuntimeV91(V90);

const validation = validateAlien3DlcV91();
assert.equal(validation.ok, true, validation.failures.join('; '));
assert.equal(validation.counts.nodes, 40);
assert.equal(validation.counts.edges, 60);
assert.equal(ALIEN3_FIORINA_TEMPLATE_V91.routes.length, 4);
assert.equal(ALIEN3_CODEX_V91.length, 13);
assert.equal(ALIEN3_V91_EVIDENCE_IDS.length, 13);
assert.equal(ALIEN3_FOUNDRY_PISTONS_V91.length, 3);

const makeEngine = () => {
  const engine = new Engine();
  engine.start({
    campaign: { id: ALIEN3_CAMPAIGN_ID_V88 },
    strategicBriefing: { flags: { 'alien3-v90-challenge': 'archive' } },
    enemyCatalog: [{ id: 'enemy-006-runner', name: 'Runner Fiorina', biology: 'xenomorph', caste: 'runner', health: 720, damage: 29, speed: 1.9 }]
  });
  return engine;
};
const moveTo = (engine, version, stationId) => {
  const station = engine[`alien3StationV${version}`](stationId);
  assert.ok(station, stationId);
  engine.player.x = station.x;
  engine.player.y = station.y;
  return station;
};
const advance = (engine, seconds, step = 0.1) => {
  let remaining = seconds;
  while (remaining > 0) { const delta = Math.min(step, remaining); engine.update(delta); remaining -= delta; }
};

const engine = makeEngine();
assert.equal(engine.alien3V91.evidenceRecovered.length, 0);
assert.equal(engine.alien3V91.foundryChase.sequenceIndex, 0);

// Assembly Cut selected at the wreck before the archive locks.
moveTo(engine, 89, 'f161-cut-assembly-terminal');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V89.cut, 'assembly');
moveTo(engine, 88, 'f161-eev-recorder');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'infirmary');

// V91 makes the funeral a physical optional beat before the autopsy.
moveTo(engine, 91, 'f161-funeral-marker');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V91.evidenceRecovered.includes('funeral-rite'), true);
moveTo(engine, 88, 'f161-autopsy');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'first-blood');

// Materialize the early casualty trail without inventing extra enemies.
for (const id of ['f161-clemens-marker', 'f161-andrews-marker', 'f161-murphy-fan-marker']) {
  moveTo(engine, 91, id);
  assert.equal(engine.interact(engine.player), true, id);
}
// A predictive off-screen interception unlocks the V91 heatmap evidence.
engine.alien3RunnerV88.x = 5600;
engine.alien3RunnerV88.y = 420;
engine.alien3V91.hunter.heat = 100;
engine.alien3V91.hunter.lastNoiseX = 900;
engine.camera.x = 0;
engine.updateAlien3HunterV91(0.2);
assert.ok(engine.alien3V91.hunter.predictions >= 1);
assert.equal(engine.alien3V91.evidenceRecovered.includes('runner-heatmap'), true);

engine.player.x = 2800;
engine.update(0.1);
assert.equal(engine.alien3V88.phase, 'bishop');
moveTo(engine, 91, 'f161-tunnel-expedition-marker');
assert.equal(engine.interact(engine.player), true);
moveTo(engine, 88, 'f161-bishop-memory');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'trap-prep');

// Preserve V90's complete physical fire plan.
for (const id of ['f161-cache-infirmary', 'f161-cache-cellblock', 'f161-cache-service']) {
  moveTo(engine, 88, id); assert.equal(engine.interact(engine.player), true, id);
}
for (const id of ['f161-fuel-a', 'f161-fuel-b', 'f161-fuel-c', 'f161-fuel-d']) {
  moveTo(engine, 90, id); assert.equal(engine.interact(engine.player), true, id);
}
moveTo(engine, 88, 'f161-fire-igniter');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'fire-maze');
advance(engine, 2.4);
assert.ok(engine.alien3V90.prisonerPlan.panic >= 40);
moveTo(engine, 91, 'f161-dillon-rally');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V91.prisonerAI.rallyCount, 1);
advance(engine, 1.0);
assert.equal(engine.alien3V90.firePlan.accidentResolved, true);
moveTo(engine, 90, 'f161-eev-medical-scanner');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V90.diagnosis.scanComplete, true);

// Assembly containment now waits for the Company message instead of an autonomous timer.
const waste = moveTo(engine, 89, 'f161-waste-tank-control');
engine.alien3RunnerV88.x = waste.x + 25;
engine.alien3RunnerV88.y = waste.y;
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V89.assembly.wasteTankTrapped, true);
advance(engine, 6);
assert.equal(engine.alien3V89.assembly.golicReleased, false);
assert.equal(engine.getInteractionPrompt(engine.player), 'RETOURNER AUX COMMUNICATIONS · CONTACTER LA COMPAGNIE');
moveTo(engine, 91, 'f161-company-message-console');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V91.companyDirective.messageSent, true);
advance(engine, 4.8);
assert.equal(engine.alien3V89.assembly.golicReleased, true);
assert.equal(engine.alien3V91.evidenceRecovered.includes('golic-escape-chain'), true);

engine.player.x = 4440;
engine.update(0.1);
assert.equal(engine.alien3V88.phase, 'leadworks');
moveTo(engine, 90, 'f161-lead-vat-primer'); assert.equal(engine.interact(engine.player), true);
moveTo(engine, 90, 'f161-water-header-control'); assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V90.leadworks.moldReady, true);

// The mold cannot be used until the three pistons have been cycled in order.
const mold = moveTo(engine, 88, 'f161-mold-control');
engine.alien3RunnerV88.x = mold.x + 20; engine.alien3RunnerV88.y = mold.y;
assert.equal(engine.interact(engine.player), false);
assert.match(engine.events.at(-1).requirement, /CORRIDOR DE RABATTEMENT/);
moveTo(engine, 91, 'f161-piston-b');
assert.equal(engine.interact(engine.player), false);
assert.equal(engine.alien3V91.foundryChase.wrongOrder, 1);
for (const id of ['f161-piston-a', 'f161-piston-b', 'f161-piston-c']) {
  moveTo(engine, 91, id);
  assert.equal(engine.interact(engine.player), true, id);
}
assert.equal(engine.alien3V91.foundryChase.ready, true);
assert.equal(engine.alien3V91.evidenceRecovered.includes('piston-maze'), true);

moveTo(engine, 88, 'f161-mold-control');
engine.alien3RunnerV88.x = engine.player.x + 25; engine.alien3RunnerV88.y = engine.player.y;
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'molten-lead');
moveTo(engine, 88, 'f161-sprinkler-control');
assert.equal(engine.interact(engine.player), true);
advance(engine, 1.4);
assert.equal(engine.alien3V88.phase, 'company');

// Company arrival now has a visible recovery cage and distinguishes Bishop II.
for (const id of ['f161-patna-cage', 'f161-bishop-two-marker']) {
  moveTo(engine, 91, id); assert.equal(engine.interact(engine.player), true, id);
}
moveTo(engine, 89, 'f161-patna-manifest'); assert.equal(engine.interact(engine.player), true);
moveTo(engine, 88, 'f161-company-contact'); assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'finale');
moveTo(engine, 91, 'f161-morse-custody-marker'); assert.equal(engine.interact(engine.player), true);
moveTo(engine, 89, 'f161-morse-witness-log'); assert.equal(engine.interact(engine.player), true);
moveTo(engine, 88, 'f161-final-ledge'); assert.equal(engine.interact(engine.player), true);
advance(engine, 3.5);

assert.equal(engine.mission.state, 'complete');
assert.equal(engine.mission.rewards.alien3V91, true);
assert.ok(['S++', 'S+', 'S', 'A', 'B', 'C', 'D'].includes(engine.mission.rewards.mireGradeV91));
assert.equal(engine.alien3V91.evidenceRecovered.length, ALIEN3_V91_EVIDENCE_IDS.length);
assert.equal(engine.alien3V91.codexUnlocked.length, ALIEN3_CODEX_V91.length);
assert.equal(engine.mission.rewards.companyChainV91.messageSent, true);
assert.equal(engine.mission.rewards.companyChainV91.cageInspected, true);
assert.equal(engine.mission.rewards.companyChainV91.bishopTwoConfirmed, true);
assert.equal(engine.mission.rewards.companyChainV91.aaronLastStand, true);
assert.equal(engine.mission.rewards.companyChainV91.morseCustody, true);

const saved = engine.captureResumeState();
assert.equal(saved.specialOperation.alien3V91.schema, 91);
const resumed = makeEngine();
const restored = resumed.applyResumeState(saved);
assert.equal(restored.applied, true);
assert.equal(resumed.alien3V91.foundryChase.ready, true);
assert.equal(resumed.alien3V91.companyDirective.messageSent, true);
assert.equal(resumed.alien3V91.evidenceRecovered.length, ALIEN3_V91_EVIDENCE_IDS.length);

// The theatrical reconstruction does not require the Assembly-only message chain.
const theatrical = makeEngine();
assert.equal(theatrical.alien3V89.cut, 'theatrical');
assert.equal(theatrical.alien3V91.companyDirective.messageSent, false);
assert.equal(theatrical.alien3V91StationVisible(theatrical.alien3StationV91('f161-company-message-console')), false);

console.log(JSON.stringify({
  ok: true,
  validation,
  evidenceRecovered: engine.alien3V91.evidenceRecovered.length,
  codexUnlocked: engine.alien3V91.codexUnlocked.length,
  grade: engine.mission.rewards.mireGradeV91,
  hunter: engine.mission.rewards.hunterDirectorV91,
  foundryChase: engine.mission.rewards.foundryChase,
  company: engine.mission.rewards.companyChainV91,
  achievements: engine.mission.rewards.v91Achievements,
  resume: { restored: restored.alien3DlcRestoredV91, evidence: resumed.alien3V91.evidenceRecovered.length }
}, null, 2));
