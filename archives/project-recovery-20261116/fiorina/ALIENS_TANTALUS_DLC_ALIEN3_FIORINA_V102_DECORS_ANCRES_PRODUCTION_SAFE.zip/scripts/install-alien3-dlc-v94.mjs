#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(process.argv[2] || process.cwd());
const patchRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXPECTED_BASE = '496996f5ea557d970ec625aa346876f3eaed1c5f';
const BACKUP_DIR = path.join(root, '.alien3-dlc-v94-backup');
const DRY_RUN = process.argv.includes('--dry-run');
const FORCE = process.argv.includes('--force');
const rel = (...parts) => path.join(...parts);

const targets = [
  rel('src', 'special-operations-v67.js'),
  rel('src', 'mission-levels-v52.js'),
  rel('src', 'game-production-runtime.js'),
  rel('src', 'app.js')
];
const additions = [
  rel('src', 'alien3-dlc-v94.js'),
  rel('src', 'alien3-dlc-runtime-v94.js'),
  rel('scripts', 'test-alien3-dlc-v94.mjs'),
  rel('scripts', 'test-alien3-physical-v94.mjs'),
  rel('scripts', 'uninstall-alien3-dlc-v94.mjs'),
  rel('docs', 'ALIEN3_DLC_V94.md')
];

function sha256(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function read(relative) {
  const file = path.join(root, relative);
  if (!fs.existsSync(file)) throw new Error(`Fichier requis absent: ${relative}`);
  return fs.readFileSync(file, 'utf8');
}
function replaceOnce(source, needle, replacement, label) {
  const first = source.indexOf(needle);
  if (first < 0) throw new Error(`Ancre introuvable (${label}). Le projet n'est pas dans l'état V93 attendu.`);
  if (source.indexOf(needle, first + needle.length) >= 0) throw new Error(`Ancre ambiguë (${label}). Installation arrêtée.`);
  return source.slice(0, first) + replacement + source.slice(first + needle.length);
}
function insertAfter(source, needle, addition, label) { return replaceOnce(source, needle, needle + addition, label); }
function gitHead() {
  const head = path.join(root, '.git', 'HEAD');
  if (!fs.existsSync(head)) return null;
  const value = fs.readFileSync(head, 'utf8').trim();
  if (!value.startsWith('ref: ')) return value;
  const ref = path.join(root, '.git', value.slice(5));
  return fs.existsSync(ref) ? fs.readFileSync(ref, 'utf8').trim() : null;
}
function ensureV93() {
  const installed = fs.existsSync(path.join(root, 'src', 'alien3-dlc-v93.js'))
    && fs.existsSync(path.join(root, 'src', 'alien3-dlc-runtime-v93.js'));
  if (installed) return { alreadyInstalled: true, installedNow: false };
  if (DRY_RUN) return { alreadyInstalled: false, installedNow: false, wouldInstall: true };
  const installer = path.join(patchRoot, 'scripts', 'install-alien3-dlc-v93.mjs');
  if (!fs.existsSync(installer)) throw new Error('Base V93 absente du pack V94.');
  const args = [installer, root];
  if (FORCE) args.push('--force');
  const result = spawnSync(process.execPath, args, { stdio: 'inherit' });
  if (result.status !== 0) throw new Error('Installation automatique de la base V93 impossible.');
  return { alreadyInstalled: false, installedNow: true };
}

function patchSpecialOperations(source) {
  source = replaceOnce(
    source,
    "promiseSummary: 'Reconstruction MIRE V93 de Fiorina 161 : Living Cast complet, beats historiques jouables sans couper les contrôles, routines individuelles des détenus, perchoirs adaptatifs du Runner, pourparlers Patna et chaîne Aaron/Morse intégrée.',",
    "promiseSummary: 'Reconstruction MIRE V94 Fidelity de Fiorina 161 : profils Cinéma / Assembly / Workprint isolés, chaîne forensique EEV↔Bishop, foi carcérale, Battery Duty, cache Golic, trace sensorielle du Runner, bait-and-chase improvisé et transmission finale.',",
    'résumé V94'
  );
  source = replaceOnce(
    source,
    "requiredMechanics: ['single-runner-predator', 'predictive-runner-heatmap', 'adaptive-tool-memory', 'runner-perch-hunting', 'player-habit-learning', 'no-firearms', 'persistent-flare-lures', 'emergency-shutters', 'steam-noise-masking', 'prisoner-tactical-orders', 'individual-prisoner-routines', 'avoidable-exposure-risk', 'fiorina-prison-metroidvania', 'four-route-topology', 'living-historical-beats', 'seamless-cinematic-beats', 'physical-quinitricetyline-plan', 'fire-propagation', 'post-fire-eev-scan', 'theatrical-assembly-cuts', 'waste-tank-containment', 'company-directive-before-golic-release', 'named-prisoner-tasking', 'three-piston-foundry-chase', 'causal-lead-water-prep', 'molten-lead-trap', 'thermal-shock-finale', 'patna-parley-and-cage', 'bishop-two-aaron-morse-finale', 'mire-master-archive', 'mire-codex-74', 'replay-challenges', 'isolated-archive-loadout']",
    "requiredMechanics: ['single-runner-predator', 'predictive-runner-heatmap', 'adaptive-tool-memory', 'runner-perch-hunting', 'player-habit-learning', 'runner-sensory-trace', 'no-firearms', 'persistent-flare-lures', 'emergency-shutters', 'steam-noise-masking', 'prisoner-tactical-orders', 'individual-prisoner-routines', 'avoidable-exposure-risk', 'prison-faith-cohesion', 'fiorina-prison-metroidvania', 'four-route-topology', 'living-historical-beats', 'seamless-cinematic-beats', 'eev-bishop-forensic-chain', 'physical-battery-duty', 'physical-quinitricetyline-plan', 'fire-propagation', 'post-fire-eev-scan', 'theatrical-assembly-workprint-profiles', 'waste-tank-containment', 'workprint-golic-cache', 'company-directive-before-golic-release', 'named-prisoner-tasking', 'three-piston-foundry-chase', 'improvised-final-reroutes', 'causal-lead-water-prep', 'molten-lead-trap', 'thermal-shock-finale', 'patna-parley-and-cage', 'bishop-two-aaron-morse-finale', 'final-mire-transmission', 'mire-master-archive', 'mire-codex-92', 'replay-challenges', 'isolated-archive-loadout']",
    'mécaniques V94'
  );
  return source;
}

function patchMissionLevels(source) {
  source = replaceOnce(
    source,
    "import { ALIEN3_FIORINA_PALETTE_V93, ALIEN3_FIORINA_TEMPLATE_V93 } from './alien3-dlc-v93.js';\n",
    "import { ALIEN3_FIORINA_PALETTE_V94, ALIEN3_FIORINA_TEMPLATE_V94 } from './alien3-dlc-v94.js';\n",
    'import template V94'
  );
  source = replaceOnce(source, '[ALIEN3_FIORINA_TEMPLATE_V93.id]: ALIEN3_FIORINA_PALETTE_V93,', '[ALIEN3_FIORINA_TEMPLATE_V94.id]: ALIEN3_FIORINA_PALETTE_V94,', 'palette V94');
  source = replaceOnce(source, '[ALIEN3_FIORINA_TEMPLATE_V93.id]: ALIEN3_FIORINA_TEMPLATE_V93,', '[ALIEN3_FIORINA_TEMPLATE_V94.id]: ALIEN3_FIORINA_TEMPLATE_V94,', 'template V94');
  return source;
}

function patchProductionRuntime(source) {
  source = insertAfter(
    source,
    "import { withAlien3DlcRuntimeV93 } from './alien3-dlc-runtime-v93.js';\n",
    "import { withAlien3DlcRuntimeV94 } from './alien3-dlc-runtime-v94.js';\n",
    'import runtime V94'
  );
  source = replaceOnce(
    source,
    'const V93ProductionEngine = withAlien3DlcRuntimeV93(V92ProductionEngine);\n',
    'const V93ProductionEngine = withAlien3DlcRuntimeV93(V92ProductionEngine);\nconst V94ProductionEngine = withAlien3DlcRuntimeV94(V93ProductionEngine);\n',
    'chaîne moteur V94'
  );
  source = replaceOnce(source, 'export class GameEngine extends V93ProductionEngine {', 'export class GameEngine extends V94ProductionEngine {', 'moteur final V94');
  return source;
}

function patchApp(source) {
  source = replaceOnce(
    source,
    "    ? 'Chronique MIRE V93 solo · 4 routes / 74 dossiers · Living Cast · beats historiques jouables · routines détenus · perchoirs du Runner · pourparlers Patna · finale Aaron/Morse.'",
    "    ? 'Chronique MIRE V94 Fidelity solo · 4 routes / 92 dossiers · Cinéma / Assembly / Workprint · chaîne EEV↔Bishop · Battery Duty · foi carcérale · bait-and-chase improvisé · transmission finale.'",
    'notice opération V94'
  );
  const helperAnchor = `const isAlien3V93RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v93-');\nconst alien3V93EventLabel = (event) => {\n  const detail = event.title || event.action || event.evidenceId || event.beatId || event.perchId || event.prisonerId || event.type.replace('alien3-v93-', '');\n  return \`MIRE 161 V93 · \${String(detail || 'LIVING CAST').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  const helper = `const isAlien3V94RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v94-');\nconst alien3V94EventLabel = (event) => {\n  const detail = event.title || event.action || event.evidenceId || event.profileId || event.sector || event.cellId || event.type.replace('alien3-v94-', '');\n  return \`MIRE 161 V94 · \${String(detail || 'FIDELITY').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  source = insertAfter(source, helperAnchor, helper, 'helpers événements V94');

  const handleAnchor = `  if (isAlien3V93RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V93EventLabel(event);\n  }\n`;
  source = insertAfter(source, handleAnchor, `  if (isAlien3V94RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V94EventLabel(event);\n  }\n`, 'journal événements V94');

  const persistenceAnchor = `  const alien3V93PersistenceDue = isAlien3V93RuntimeEvent(event);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue || alien3V90PersistenceDue || alien3V91PersistenceDue || alien3V92PersistenceDue || alien3V93PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  const persistenceReplacement = `  const alien3V93PersistenceDue = isAlien3V93RuntimeEvent(event);\n  const alien3V94PersistenceDue = isAlien3V94RuntimeEvent(event);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue || alien3V90PersistenceDue || alien3V91PersistenceDue || alien3V92PersistenceDue || alien3V93PersistenceDue || alien3V94PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  source = replaceOnce(source, persistenceAnchor, persistenceReplacement, 'persistance événements V94');
  return source;
}

function run() {
  if (fs.existsSync(path.join(root, 'src', 'alien3-dlc-v94.js')) && !FORCE) throw new Error('Le DLC Alien 3 V94 semble déjà installé.');
  const v93 = ensureV93();
  if (DRY_RUN && v93.wouldInstall) {
    console.log(JSON.stringify({ schema: 94, dryRun: true, prerequisite: 'V93 (and V92/V91/V90/V89/V88) would be installed first', expectedBaseCommit: EXPECTED_BASE }, null, 2));
    return;
  }
  for (const relative of targets) read(relative);
  for (const relative of additions) if (!fs.existsSync(path.join(patchRoot, relative))) throw new Error(`Fichier du patch absent: ${relative}`);
  const head = gitHead();
  if (head && head !== EXPECTED_BASE && !FORCE) console.warn(`[WARN] HEAD ${head} diffère de la base auditée ${EXPECTED_BASE}; V94 vérifie les ancres V93 avant écriture.`);

  const originals = Object.fromEntries(targets.map((relative) => [relative, read(relative)]));
  const patched = {
    [rel('src', 'special-operations-v67.js')]: patchSpecialOperations(originals[rel('src', 'special-operations-v67.js')]),
    [rel('src', 'mission-levels-v52.js')]: patchMissionLevels(originals[rel('src', 'mission-levels-v52.js')]),
    [rel('src', 'game-production-runtime.js')]: patchProductionRuntime(originals[rel('src', 'game-production-runtime.js')]),
    [rel('src', 'app.js')]: patchApp(originals[rel('src', 'app.js')])
  };
  const report = {
    schema: 94,
    name: 'Alien 3 — Fiorina 161 DLC V94 Fidelity',
    expectedBaseCommit: EXPECTED_BASE,
    detectedHead: head,
    v93InstalledByThisRun: v93.installedNow,
    dryRun: DRY_RUN,
    modified: Object.entries(patched).map(([relative, content]) => ({
      file: relative,
      beforeSha256: sha256(originals[relative]),
      afterSha256: sha256(content),
      beforeBytes: Buffer.byteLength(originals[relative]),
      afterBytes: Buffer.byteLength(content)
    })),
    added: additions.map((relative) => ({ file: relative, sha256: sha256(fs.readFileSync(path.join(patchRoot, relative))) }))
  };
  if (DRY_RUN) { console.log(JSON.stringify(report, null, 2)); return; }

  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  try {
    for (const [relative, content] of Object.entries(originals)) {
      const backup = path.join(BACKUP_DIR, relative);
      fs.mkdirSync(path.dirname(backup), { recursive: true });
      fs.writeFileSync(backup, content);
    }
    for (const [relative, content] of Object.entries(patched)) fs.writeFileSync(path.join(root, relative), content);
    for (const relative of additions) {
      const target = path.join(root, relative);
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.copyFileSync(path.join(patchRoot, relative), target);
    }
    fs.writeFileSync(path.join(root, 'ALIEN3_DLC_V94_INSTALL_REPORT.json'), JSON.stringify(report, null, 2));
  } catch (error) {
    for (const [relative, content] of Object.entries(originals)) { try { fs.writeFileSync(path.join(root, relative), content); } catch {} }
    for (const relative of additions) { try { fs.rmSync(path.join(root, relative), { force: true }); } catch {} }
    throw error;
  }
  console.log('Alien 3 — Fiorina 161 V94 Fidelity installé.');
  console.log('V94 est cumulatif : V88 à V93 restent les couches de base.');
  console.log('Lancez : node scripts/test-alien3-dlc-v94.mjs && node scripts/test-alien3-physical-v94.mjs && npm run check && npm run build');
}

try { run(); }
catch (error) { console.error('[ALIEN3 V94] Installation annulée:', error.message); process.exitCode = 1; }
