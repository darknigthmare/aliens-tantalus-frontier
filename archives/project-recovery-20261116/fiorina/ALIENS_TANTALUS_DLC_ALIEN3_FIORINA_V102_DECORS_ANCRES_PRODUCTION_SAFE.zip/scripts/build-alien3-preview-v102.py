from pathlib import Path
import json,re
root=Path(__file__).resolve().parents[1]
sources={}
def collect(path):
 if path in sources:return
 src=(root/path).read_text();sources[path]=src
 for rel in re.findall(r"(?:from\s*|import\s*)['\"]([^'\"]+)['\"]",src):
  if rel.startswith('.'):
   target=(root/path).parent.joinpath(rel).resolve().relative_to(root).as_posix();collect(target)
collect('atelier/app.js')
boot='''<script>window.__BENCH_QUERY__=window.__BENCH_QUERY__||'';</script><script type="module">
const sources=__SOURCES__;const cache=new Map();
function norm(path){let out=[];for(const x of path.split('/')){if(x==='..')out.pop();else if(x!=='.'&&x)out.push(x);}return out.join('/');}
function moduleUrl(id){if(cache.has(id))return cache.get(id);const base=id.slice(0,id.lastIndexOf('/')+1);let src=sources[id];if(src===undefined)throw Error('Missing '+id);src=src.replace(/(from\\s*|import\\s*)['"]([^'"]+)['"]/g,(all,p,rel)=>rel.startsWith('.')?p+JSON.stringify(moduleUrl(norm(base+rel))):all);const url=URL.createObjectURL(new Blob([src],{type:'text/javascript'}));cache.set(id,url);return url;}
await import(moduleUrl('atelier/app.js'));
</script>'''.replace('__SOURCES__',json.dumps(sources,ensure_ascii=False).replace('</script','<\\/script'))
html=(root/'atelier/index.html').read_text();html=html.replace('<script type="module" src="./app.js"></script>',boot)
(root/'atelier/FIORINA_V102_APERCU_LOCAL.html').write_text(html)
print('Embedded modules',len(sources),'bytes',len(html.encode()))
