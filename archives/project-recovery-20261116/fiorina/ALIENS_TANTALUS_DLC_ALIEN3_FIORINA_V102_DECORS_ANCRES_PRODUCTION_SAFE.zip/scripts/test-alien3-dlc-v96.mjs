import assert from 'node:assert/strict';
import { ALIEN3_CAMPAIGN_ID_V88 } from '../src/alien3-dlc-v88.js';
import { withAlien3DlcRuntimeV88 } from '../src/alien3-dlc-runtime-v88.js';
import { withAlien3DlcRuntimeV89 } from '../src/alien3-dlc-runtime-v89.js';
import { withAlien3DlcRuntimeV90 } from '../src/alien3-dlc-runtime-v90.js';
import { withAlien3DlcRuntimeV91 } from '../src/alien3-dlc-runtime-v91.js';
import { withAlien3DlcRuntimeV92 } from '../src/alien3-dlc-runtime-v92.js';
import { withAlien3DlcRuntimeV93 } from '../src/alien3-dlc-runtime-v93.js';
import { withAlien3DlcRuntimeV94 } from '../src/alien3-dlc-runtime-v94.js';
import { withAlien3DlcRuntimeV95 } from '../src/alien3-dlc-runtime-v95.js';
import {
  ALIEN3_AUDIO_CUES_V96, ALIEN3_CODEX_V96, ALIEN3_ENVIRONMENT_ZONES_V96, ALIEN3_FIORINA_TEMPLATE_V96,
  ALIEN3_V96_EVIDENCE_IDS, ALIEN3_V96_STATIONS, alien3V96Grade, validateAlien3DlcV96
} from '../src/alien3-dlc-v96.js';
import { withAlien3DlcRuntimeV96 } from '../src/alien3-dlc-runtime-v96.js';

class MockBase {
  constructor() {
    this.events = []; this.images = new Map(); this.enemies = []; this.doors = [];
    this.platforms = [
      { id:'ground',x:0,y:510,w:6200 }, { id:'deep',x:0,y:630,w:6200 },
      { id:'high',x:0,y:330,w:6200 }, { id:'perch',x:0,y:190,w:6200 }
    ];
    this.player = { id:'player',x:180,y:420,w:44,h:90,alive:true,health:100,armor:0,kills:0,damageTaken:0,actionClock:0,fireClock:0,vx:0,vy:0,facing:1,crouching:false };
    this.coop = { id:'coop',x:120,y:420,w:44,h:90,alive:true,health:100,armor:0,kills:0,damageTaken:0,vx:0,vy:0 };
    this.vehicle = { active:true,occupied:false,driver:null,passengers:[],x:3200 };
    this.weaponPickup = { taken:false,x:900 }; this.toolPickup = { taken:false,x:1200 }; this.supplies=[]; this.objectiveNodes=[];
    this.archiveTerminal = { recovered:false,x:1500 }; this.powerNode = { active:false,x:1800 };
    this.objective = { x:6000,y:420,w:68,h:90,complete:false };
    this.missionLevelRuntime = { anchors:{ extraction:{x:6040,y:510} } }; this.missionLevelVisualState={activeZoneId:'f161-coast'};
    this.mission = { state:'active',objectives:{power:false,route:false,boss:false,archive:false,extract:false},rewards:{},retries:0,elapsed:0,casualties:0 };
    this.inventory={salvage:0,intel:0};
    this.audio = {
      tones:0, effects:[], ui(){}, alarm(){}, hit(){}, tone(){ this.tones += 1; return true; },
      playEffect(id, fallback){ this.effects.push(id); fallback?.(); return false; }
    };
    this.camera={x:0,y:0}; this.animationTime=0; this.onEvent=(event)=>this.events.push(event);
  }
  start(options={}){ this.campaign=options.campaign; this.strategicBriefing=options.strategicBriefing; return {base:true}; }
  createEnemy(profile,index,x,groundY,options={}){ return {...profile,id:profile.id||`enemy-${index}`,x,y:groundY-90,w:90,h:90,health:profile.health||100,maxHealth:profile.health||100,speed:profile.speed||1,damage:profile.damage||10,alive:true,facing:-1,alert:false,staggerClock:0,hurtClock:0,...options}; }
  initializeEnemyMissionNavigation(){} interact(){return false;} fire(){return false;} reload(){return true;} toggleVehicle(){return true;} useEquipment(){return true;} activateTracker(){return false;}
  applyEnemyDamage(enemy,amount){ enemy.health=Math.max(0,enemy.health-amount); if(enemy.health<=0) enemy.alive=false; return amount; }
  updateEnemy(){} drawEnemy(){} defeatEnemy(enemy){enemy.alive=false;enemy.health=0;return true;}
  damagePlayer(actor,amount){actor.health=Math.max(0,actor.health-amount);actor.damageTaken+=amount;if(actor.health<=0)actor.alive=false;return amount;}
  update(delta=0.016){this.animationTime+=delta;return true;} missingObjectiveRequirement(){return '';} missingExtractionRequirement(){return '';}
  completeMission(){this.mission.state='complete';this.mission.rewards={credits:100};this.onEvent({type:'mission-complete',rewards:this.mission.rewards});return true;}
  restartFromCheckpoint(){this.mission.state='active';return true;} phaseLabel(){return 'BASE';} objectiveProgressText(){return 'BASE';} getInteractionPrompt(){return '';}
  drawWorld(){} drawHud(){} captureResumeState(){return {schema:1,player:{x:this.player.x,y:this.player.y}};} applyResumeState(){return {applied:true,restored:1};}
  getGameplayReport(){return {base:true};} getSnapshot(){return {base:true};} locked(requirement){this.events.push({type:'locked',requirement});return false;}
}

const V88=withAlien3DlcRuntimeV88(MockBase); const V89=withAlien3DlcRuntimeV89(V88); const V90=withAlien3DlcRuntimeV90(V89);
const V91=withAlien3DlcRuntimeV91(V90); const V92=withAlien3DlcRuntimeV92(V91); const V93=withAlien3DlcRuntimeV93(V92);
const V94=withAlien3DlcRuntimeV94(V93); const V95=withAlien3DlcRuntimeV95(V94); const Engine=withAlien3DlcRuntimeV96(V95);

const validation=validateAlien3DlcV96();
assert.equal(validation.ok,true,validation.failures.join('; '));
assert.equal(validation.counts.nodes,72); assert.equal(validation.counts.edges,119); assert.equal(validation.counts.routes,4);
assert.equal(ALIEN3_FIORINA_TEMPLATE_V96.routes.length,4); assert.equal(ALIEN3_ENVIRONMENT_ZONES_V96.length,6);
assert.equal(ALIEN3_AUDIO_CUES_V96.length,8); assert.equal(ALIEN3_V96_STATIONS.length,8); assert.equal(ALIEN3_CODEX_V96.length,18); assert.equal(ALIEN3_V96_EVIDENCE_IDS.length,18);

const engine=new Engine();
engine.start({campaign:{id:ALIEN3_CAMPAIGN_ID_V88},strategicBriefing:{flags:{'alien3-v90-challenge':'archive'}},enemyCatalog:[{id:'enemy-006-runner',name:'Runner Fiorina',biology:'xenomorph',caste:'runner',health:720,damage:29,speed:1.9}]});
assert.equal(engine.alien3V96.evidenceRecovered.includes('atmosphere-ready'),true);
assert.equal(engine.alien3V96.environment.currentZoneId,'f161-coast');

const moveToStation=(id)=>{const station=engine.alien3StationV96(id);assert.ok(station,id);engine.player.x=station.x;engine.player.y=station.y;return station;};

// Storm exposure is real but recoverable and remains below critical in the reference run.
engine.player.x=120; engine.player.y=420;
for(let i=0;i<72;i++) engine.syncAlien3EnvironmentV96(0.25);
assert.ok(engine.alien3V96.environment.wetness>=25); assert.equal(engine.alien3V96.evidenceRecovered.includes('cold-wet-exposure'),true);
assert.ok(engine.alien3V96.environment.exposurePeak<90);
moveToStation('f161-weather-console-v96'); assert.equal(engine.interact(engine.player),true); assert.equal(engine.alien3V96.environment.weatherRead,true);

// Visit all six existing zones; V96 deliberately adds no fifth route or extra topology.
for(const zone of ALIEN3_FIORINA_TEMPLATE_V96.zones){ engine.player.x=zone.x+Math.min(120,zone.w/2); engine.player.y=420; engine.syncAlien3EnvironmentV96(0.2); }
assert.equal(engine.alien3V96.environment.zoneVisits.length,6); assert.equal(engine.alien3V96.evidenceRecovered.includes('six-zones-visited'),true);

// Power / PA / steam / extractor utilities are physical, one-shot interactions on certified surfaces.
for(const id of ['f161-infirmary-breaker-v96','f161-cellblock-pa-v96','f161-service-breaker-v96','f161-steam-baffle-v96','f161-foundry-breaker-v96','f161-furnace-extractor-v96']){
  moveToStation(id); assert.equal(engine.interact(engine.player),true,id);
}
assert.deepEqual(engine.alien3V96.environment.breakers,{infirmary:true,service:true,leadworks:true});
assert.equal(engine.alien3V96.environment.prisonPa,true); assert.equal(engine.alien3V96.environment.steamBaffle,true); assert.equal(engine.alien3V96.environment.furnaceExtractor,true);
assert.equal(engine.alien3V96.evidenceRecovered.includes('visibility-tradeoff'),true);

// Climate stabilization feeds back into V95 prisoner minds.
engine.ensureAlien3PrisonerMindsV95();
for(const mind of Object.values(engine.alien3V95.autonomy.minds)) mind.stress=35;
engine.player.x=1120; engine.player.y=420;
for(let i=0;i<28;i++) engine.syncAlien3EnvironmentV96(0.25);
assert.equal(engine.alien3V96.evidenceRecovered.includes('prisoner-climate-stable'),true);

// Directional acoustic captions reveal only band + bearing, never exact coordinates.
engine.alien3RunnerV88.alive=true; engine.alien3V88.runner.active=true;
engine.player.x=3500; engine.player.y=420;
engine.alien3RunnerV88.x=3260; engine.alien3RunnerV88.y=420; engine.alien3V96.acoustics.runnerCueCooldown=0; engine.updateAlien3ThreatAudioV96(0.1);
assert.equal(engine.alien3V96.evidenceRecovered.includes('runner-bearing-left'),true);
engine.alien3RunnerV88.x=3780; engine.alien3V96.acoustics.runnerCueCooldown=0; engine.updateAlien3ThreatAudioV96(0.1);
assert.equal(engine.alien3V96.evidenceRecovered.includes('runner-bearing-right'),true);
assert.equal(engine.alien3V96.evidenceRecovered.includes('runner-acoustic-near'),true);

// Exercise every optional cue. The mock intentionally has no real media so fallbacks must remain safe.
for(const cue of ALIEN3_AUDIO_CUES_V96) engine.playAlien3CueV96(cue.id,{force:true});
assert.equal(engine.alien3V96.acoustics.uniqueCues.length,8); assert.equal(engine.alien3V96.acoustics.fallbackSafe,true);
assert.ok(engine.alien3V96.telemetry.fallbackAttempts>=8); assert.equal(engine.alien3V96.evidenceRecovered.includes('audio-fallback-safe'),true);

// The diagnostic is a final accessibility / soundscape gate rather than a hard audio-file requirement.
moveToStation('f161-acoustic-diagnostic-v96'); assert.equal(engine.interact(engine.player),true); assert.equal(engine.alien3V96.acoustics.diagnostic,true);
assert.equal(engine.alien3V96.evidenceRecovered.includes('acoustic-diagnostic'),true);

// Inherit a perfect V95 reference run and close every V96 criterion.
engine.alien3V95.perfectArchive.perfect=true;
engine.alien3V96.environment.exposurePeak=Math.min(engine.alien3V96.environment.exposurePeak,69);
engine.alien3V96.environment.thermalPeak=Math.min(engine.alien3V96.environment.thermalPeak,40);
engine.updateAlien3PerfectV96();
assert.equal(engine.alien3V96.perfectArchive.perfect,true);
assert.equal(engine.alien3V96.evidenceRecovered.length,ALIEN3_V96_EVIDENCE_IDS.length);
assert.equal(engine.alien3V96.codexUnlocked.length,ALIEN3_CODEX_V96.length);

const grade=alien3V96Grade({gradeV95:'S++++++',evidence:18,zones:6,cues:8,utilities:6,exposurePeak:69,thermalPeak:40,diagnostic:true,perfect:true});
assert.equal(grade,'S+++++++');

const saved=engine.captureResumeState(); assert.equal(saved.specialOperation.alien3V96.schema,96);
const resumed=new Engine();
resumed.start({campaign:{id:ALIEN3_CAMPAIGN_ID_V88},strategicBriefing:{flags:{}},enemyCatalog:[{id:'enemy-006-runner',name:'Runner Fiorina',biology:'xenomorph',caste:'runner',health:720,damage:29,speed:1.9}]});
const restored=resumed.applyResumeState(saved); assert.equal(restored.alien3DlcRestoredV96,true); assert.equal(resumed.alien3V96.acoustics.diagnostic,true); assert.equal(resumed.alien3V96.perfectArchive.perfect,true);
assert.equal(resumed.alien3V96.environment.zoneVisits.length,6);

engine.missingExtractionRequirement=()=>''; engine.mission.state='active'; engine.alien3V88.complete=false;
assert.equal(engine.completeMission(engine.player),true); assert.equal(engine.mission.rewards.alien3V96,true); assert.equal(typeof engine.mission.rewards.mireGradeV96,'string');
assert.equal(engine.mission.rewards.atmosphereV96.zonesVisited.length,6); assert.equal(engine.mission.rewards.acousticsV96.cues.length,8); assert.equal(engine.mission.rewards.acousticsV96.diagnostic,true);

console.log(JSON.stringify({
  ok:true, validation,
  atmosphere:{zonesVisited:engine.alien3V96.environment.zoneVisits.length,exposurePeak:Number(engine.alien3V96.environment.exposurePeak.toFixed(2)),thermalPeak:Number(engine.alien3V96.environment.thermalPeak.toFixed(2)),visibilityMin:Number(engine.alien3V96.environment.visibilityMin.toFixed(2)),breakers:engine.alien3V96.environment.breakers,steamBaffle:engine.alien3V96.environment.steamBaffle,furnaceExtractor:engine.alien3V96.environment.furnaceExtractor},
  acoustics:{uniqueCues:engine.alien3V96.acoustics.uniqueCues.length,fallbackAttempts:engine.alien3V96.telemetry.fallbackAttempts,captions:engine.alien3V96.acoustics.captions,left:engine.alien3V96.telemetry.leftCaptions,right:engine.alien3V96.telemetry.rightCaptions,diagnostic:engine.alien3V96.acoustics.diagnostic},
  evidenceRecovered:engine.alien3V96.evidenceRecovered.length,codexUnlocked:engine.alien3V96.codexUnlocked.length,perfectArchive:engine.alien3V96.perfectArchive,grade,completionGrade:engine.mission.rewards.mireGradeV96,
  resume:{restored:restored.alien3DlcRestoredV96,zones:resumed.alien3V96.environment.zoneVisits.length,diagnostic:resumed.alien3V96.acoustics.diagnostic}
},null,2));
