#!/usr/bin/env python3
from pathlib import Path
import concurrent.futures, subprocess, json, time
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'qa-v102/regressions';OUT.mkdir(parents=True,exist_ok=True)
scripts=[p for p in sorted((ROOT/'scripts').glob('test-*.mjs')) if not p.name.endswith('-v102.mjs')]
def run(p):
 t=time.monotonic()
 try:
  r=subprocess.run(['node',str(p)],cwd=ROOT,text=True,capture_output=True,timeout=90)
  (OUT/(p.stem+'.log')).write_text(r.stdout+'\nSTDERR\n'+r.stderr)
  return {'script':p.name,'ok':r.returncode==0,'returnCode':r.returncode,'seconds':round(time.monotonic()-t,2),'log':'qa-v102/regressions/'+p.stem+'.log'}
 except subprocess.TimeoutExpired:
  return {'script':p.name,'ok':False,'timeout':True}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,scripts))
report={'scope':'Inherited isolated suites on their supplied test bases/fixtures. NOT full production E2E.','total':len(results),'passed':sum(r['ok'] for r in results),'failed':sum(not r['ok'] for r in results),'results':results}
(ROOT/'qa-v102/regressions.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='results'}))
for x in results:
 if not x['ok']: print(x)
