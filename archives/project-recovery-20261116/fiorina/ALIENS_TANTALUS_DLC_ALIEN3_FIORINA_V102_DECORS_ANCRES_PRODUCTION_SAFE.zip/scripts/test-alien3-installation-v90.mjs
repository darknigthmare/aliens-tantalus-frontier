import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const patchRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const fixture = fs.mkdtempSync(path.join(os.tmpdir(), 'alien3-v90-install-'));
const sha = (buffer) => crypto.createHash('sha256').update(buffer).digest('hex');
const write = (relative, content) => {
  const target = path.join(fixture, relative);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, content);
};
const read = (relative) => fs.readFileSync(path.join(fixture, relative));

write('src/special-operations-v67.js', `const VALID_STATUSES = new Set(['effective', 'partial', 'missing']);\nexport const SPECIAL_OPERATIONS_V67 = Object.freeze([\n  freezeOperation({\n    id: 'cargo-brutal',\n    promisedTitle: 'CARGO BRUTAL'\n  })\n]);\nexport function validateSpecialOperationsV67(operations = SPECIAL_OPERATIONS_V67) {\n  const failures = [];\n  if (operations.length !== 19) failures.push(\`operations: \${operations.length} != 19\`);\n  return { failures };\n}\n`);
write('src/mission-levels-v52.js', `import { buildCetoHabitatsV75, cetoHabitatHazardsV75 } from './enemy-ceto-v75.js';\nexport const MISSION_TEMPLATE_IDS_V52 = Object.freeze([\n  'ship-interior-vertical',\n  'colony-multiroute',\n  'planet-exterior'\n]);\nconst TEMPLATE_PALETTES = Object.freeze({\n  base: true\n});\nconst SHIP_TEMPLATE = { id: 'ship-interior-vertical' };\nexport const MISSION_LEVEL_TEMPLATES_V52 = Object.freeze({\n  [SHIP_TEMPLATE.id]: SHIP_TEMPLATE,\n});\n`);
write('src/game-v52-level-runtime.js', `export const MISSION_LEVEL_LAYER_FILES_V52 = Object.freeze({\n  base: true\n});\n`);
write('src/game-production-runtime.js', `import { withPlaceablesRuntimeV86 } from './placeables-runtime-v86.js';\nconst V70ProductionEngine = class {};\nconst V86ProductionEngine = withPlaceablesRuntimeV86(V70ProductionEngine);\nexport class GameEngine extends V86ProductionEngine { }\n`);

const app = [
  "<span>${escapeHtml(world?.name || 'Frontier')}</span><span>${escapeHtml(campaign.objective)}</span>",
  "<footer><span>${campaign ? escapeHtml(world?.name || 'Frontier') : hubSurface ? 'USS TANTALUS · HUB PHYSIQUE' : 'REGISTRE DES OPÉRATIONS'}</span>",
  "<h3>${escapeHtml(campaign.name)}</h3><p>${escapeHtml(campaign.objective)} · ${escapeHtml(world.name)}</p>${specialNotice}",
  "  const specialNoticeCopy = specialOperation?.id === 'cargo-brutal'\n",
  "  const worldState = saveSystem.data.galaxy.worldState[world.id];\n  const before = absoluteHours(saveSystem.data.clock);",
  `  const crew = operationLoadout.crew;\n  const weapon = operationLoadout.weapon || WEAPONS[0];\n  const equipment = operationLoadout.equipment;\n  const specialOperation = getSpecialOperationByCampaignIdV67(campaign.id);\n  const vehicle = specialOperation?.issuedVehicleId\n    ? VEHICLES.find((entry) => entry.id === specialOperation.issuedVehicleId) || operationLoadout.vehicle\n    : operationLoadout.vehicle;\n  const costume = operationLoadout.costume;`,
  "    world: { ...world, ...worldState },\n    levelSeeds: LEVEL_SEEDS,",
  "  byId('mission-log').textContent = `MU/TH/UR · ${campaign.objective.toUpperCase()} · ${world.name} · ${missionLevel.templateLabel.toUpperCase()} · RISQUE ${deployment.operation.risk}%`;",
  "    campaign, world, worldState, levelSeed, missionLevel,\n    weapon, equipment, crew, vehicle, costume, deployment, operationLoadout\n  });",
  `const alienSurvivalEventLabelV70 = (event) => {\n  const detail = event.message || event.reason || event.circuitId || event.feedId\n    || event.doorId || event.stationId || event.type.replace('alien-survival-', '');\n  const remaining = Number(event.remainingSeconds ?? event.remaining);\n  const countdown = Number.isFinite(remaining) ? \` · T−\${Math.max(0, Math.ceil(remaining))} S\` : '';\n  return \`SURVIE · \${String(detail || 'SYSTÈMES ACTUALISÉS').toUpperCase()}\${countdown}\`;\n};\n`,
  `  if (isAlienSurvivalRuntimeEventV70(event)) {\n    alienSurvivalDockV70?.refresh();\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alienSurvivalEventLabelV70(event);\n  }\n`,
  `  const survivalPersistenceDue = ALIEN_SURVIVAL_PERSISTENT_EVENTS_V70.has(event.type)\n    && (event.type !== 'alien-survival-self-destruct-tick'\n      || Math.max(0, Math.ceil(Number(event.remainingSeconds ?? event.remaining) || 0)) % 5 === 0);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue) && saveSystem.data.strategy.currentOperation) {`
].join('\n/* fixture boundary */\n');
write('src/app.js', app);

const baseFiles = [
  'src/special-operations-v67.js',
  'src/mission-levels-v52.js',
  'src/game-v52-level-runtime.js',
  'src/game-production-runtime.js',
  'src/app.js'
];
const before = Object.fromEntries(baseFiles.map((relative) => [relative, sha(read(relative))]));

const installer = path.join(patchRoot, 'scripts', 'install-alien3-dlc-v90.mjs');
let result = spawnSync(process.execPath, [installer, fixture], { encoding: 'utf8' });
assert.equal(result.status, 0, result.stderr || result.stdout);
assert.equal(fs.existsSync(path.join(fixture, 'src', 'alien3-dlc-v88.js')), true);
assert.equal(fs.existsSync(path.join(fixture, 'src', 'alien3-dlc-v89.js')), true);
assert.equal(fs.existsSync(path.join(fixture, 'src', 'alien3-dlc-v90.js')), true);
assert.equal(fs.existsSync(path.join(fixture, '.alien3-dlc-v88-backup')), true);
assert.equal(fs.existsSync(path.join(fixture, '.alien3-dlc-v89-backup')), true);
assert.equal(fs.existsSync(path.join(fixture, '.alien3-dlc-v90-backup')), true);
const specialAfter = fs.readFileSync(path.join(fixture, 'src', 'special-operations-v67.js'), 'utf8');
assert.match(specialAfter, /physical-quinitricetyline-plan/);
assert.match(fs.readFileSync(path.join(fixture, 'src', 'mission-levels-v52.js'), 'utf8'), /ALIEN3_FIORINA_TEMPLATE_V90/);
assert.match(fs.readFileSync(path.join(fixture, 'src', 'game-production-runtime.js'), 'utf8'), /V90ProductionEngine/);
assert.match(fs.readFileSync(path.join(fixture, 'src', 'app.js'), 'utf8'), /35 dossiers MIRE/);

result = spawnSync(process.execPath, [path.join(fixture, 'scripts', 'test-alien3-dlc-v90.mjs')], { cwd: fixture, encoding: 'utf8' });
assert.equal(result.status, 0, result.stderr || result.stdout);
const runtimeQa = JSON.parse(result.stdout);
assert.equal(runtimeQa.ok, true);
assert.equal(runtimeQa.validation.counts.nodes, 30);
assert.equal(runtimeQa.validation.counts.edges, 44);
assert.equal(runtimeQa.validation.counts.routes, 4);
assert.equal(runtimeQa.validation.counts.manifolds, 4);
assert.equal(runtimeQa.evidenceRecovered, runtimeQa.evidenceTotal);
assert.equal(runtimeQa.firePlan.prepared, true);
assert.equal(runtimeQa.firePlan.accidentResolved, true);
assert.equal(runtimeQa.diagnosis.scanComplete, true);
assert.equal(runtimeQa.leadworks.moldReady, true);

const uninstaller = path.join(fixture, 'scripts', 'uninstall-alien3-dlc-v90.mjs');
result = spawnSync(process.execPath, [uninstaller, fixture, '--full'], { encoding: 'utf8' });
assert.equal(result.status, 0, result.stderr || result.stdout);
for (const relative of baseFiles) assert.equal(sha(read(relative)), before[relative], `${relative} not restored bit-for-bit`);
assert.equal(fs.existsSync(path.join(fixture, 'src', 'alien3-dlc-v88.js')), false);
assert.equal(fs.existsSync(path.join(fixture, 'src', 'alien3-dlc-v89.js')), false);
assert.equal(fs.existsSync(path.join(fixture, 'src', 'alien3-dlc-v90.js')), false);
assert.equal(fs.existsSync(path.join(fixture, '.alien3-dlc-v88-backup')), false);
assert.equal(fs.existsSync(path.join(fixture, '.alien3-dlc-v89-backup')), false);
assert.equal(fs.existsSync(path.join(fixture, '.alien3-dlc-v90-backup')), false);

const summary = {
  ok: true,
  fixture,
  cumulativeInstall: true,
  v88AutoInstalled: true,
  v89AutoInstalled: true,
  v90Installed: true,
  runtimeQa: {
    challenge: runtimeQa.challenge,
    routes: runtimeQa.validation.counts.routes,
    nodes: runtimeQa.validation.counts.nodes,
    manifolds: runtimeQa.validation.counts.manifolds,
    evidenceV90: `${runtimeQa.evidenceRecovered}/${runtimeQa.evidenceTotal}`,
    scanComplete: runtimeQa.diagnosis.scanComplete,
    foundryReady: runtimeQa.leadworks.moldReady,
    mireGradeV90: runtimeQa.rewards.mireGradeV90
  },
  fullUninstallBitPerfect: true,
  restoredFiles: baseFiles
};
console.log(JSON.stringify(summary, null, 2));
fs.rmSync(fixture, { recursive: true, force: true });
