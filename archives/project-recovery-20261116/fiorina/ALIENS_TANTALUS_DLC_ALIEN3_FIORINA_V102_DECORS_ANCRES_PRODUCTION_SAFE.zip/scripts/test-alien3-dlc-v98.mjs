import assert from 'node:assert/strict';
import { ALIEN3_CAMPAIGN_ID_V88 } from '../src/alien3-dlc-v88.js';
import { withAlien3DlcRuntimeV88 } from '../src/alien3-dlc-runtime-v88.js';
import { withAlien3DlcRuntimeV89 } from '../src/alien3-dlc-runtime-v89.js';
import { withAlien3DlcRuntimeV90 } from '../src/alien3-dlc-runtime-v90.js';
import { withAlien3DlcRuntimeV91 } from '../src/alien3-dlc-runtime-v91.js';
import { withAlien3DlcRuntimeV92 } from '../src/alien3-dlc-runtime-v92.js';
import { withAlien3DlcRuntimeV93 } from '../src/alien3-dlc-runtime-v93.js';
import { withAlien3DlcRuntimeV94 } from '../src/alien3-dlc-runtime-v94.js';
import { withAlien3DlcRuntimeV95 } from '../src/alien3-dlc-runtime-v95.js';
import { withAlien3DlcRuntimeV96 } from '../src/alien3-dlc-runtime-v96.js';
import { withAlien3DlcRuntimeV97 } from '../src/alien3-dlc-runtime-v97.js';
import {
  ALIEN3_DEPTH_OCCLUDERS_V98, ALIEN3_DLC_CODEX_TERMINALS_V98, ALIEN3_DLC_CODEX_V98,
  ALIEN3_FIORINA_TEMPLATE_V98, ALIEN3_HYBRID_DIRECTOR_PROFILES_V98, ALIEN3_V98_EVIDENCE_IDS,
  alien3V98Grade, validateAlien3DlcV98
} from '../src/alien3-dlc-v98.js';
import { withAlien3DlcRuntimeV98 } from '../src/alien3-dlc-runtime-v98.js';
import { ALIEN3_HYBRID_SECTORS_V97 } from '../src/alien3-dlc-v97.js';

class MockBase {
  constructor() {
    this.events=[]; this.images=new Map(); this.enemies=[]; this.doors=[]; this.keys=new Set(); this.running=true; this.paused=false;
    this.platforms=[{id:'ground',x:0,y:510,w:6200},{id:'deep',x:0,y:630,w:6200},{id:'high',x:0,y:330,w:6200},{id:'perch',x:0,y:190,w:6200}];
    this.player={id:'player',x:180,y:420,w:44,h:90,alive:true,health:100,armor:0,kills:0,damageTaken:0,actionClock:0,fireClock:0,vx:0,vy:0,facing:1,crouching:false,grounded:true};
    this.coop={id:'coop',x:120,y:420,w:44,h:90,alive:true,health:100,armor:0,kills:0,damageTaken:0,vx:0,vy:0};
    this.vehicle={active:true,occupied:false,driver:null,passengers:[],x:3200}; this.weaponPickup={taken:false,x:900}; this.toolPickup={taken:false,x:1200}; this.supplies=[]; this.objectiveNodes=[];
    this.archiveTerminal={recovered:false,x:1500}; this.powerNode={active:false,x:1800}; this.objective={x:6000,y:420,w:68,h:90,complete:false};
    this.missionLevelRuntime={anchors:{extraction:{x:6040,y:510}}}; this.missionLevelVisualState={activeZoneId:'f161-coast'};
    this.mission={state:'active',objectives:{power:false,route:false,boss:false,archive:false,extract:false},rewards:{},retries:0,elapsed:0,casualties:0}; this.inventory={salvage:0,intel:0};
    this.audio={tones:0,effects:[],ui(){},alarm(){},hit(){},tone(){this.tones+=1;return true;},playEffect(id,fallback){this.effects.push(id);fallback?.();return false;}};
    this.camera={x:0,y:0}; this.animationTime=0; this.onEvent=(event)=>this.events.push(event);
  }
  start(options={}){this.campaign=options.campaign;this.strategicBriefing=options.strategicBriefing;return{base:true};}
  createEnemy(profile,index,x,groundY,options={}){return{...profile,id:profile.id||`enemy-${index}`,x,y:groundY-90,w:90,h:90,health:profile.health||100,maxHealth:profile.health||100,speed:profile.speed||1,damage:profile.damage||10,alive:true,facing:-1,alert:false,staggerClock:0,hurtClock:0,...options};}
  initializeEnemyMissionNavigation(){} interact(){return false;} fire(){return false;} reload(){return true;} toggleVehicle(){return true;} useEquipment(){return true;} activateTracker(){return false;}
  applyEnemyDamage(enemy,amount){enemy.health=Math.max(0,enemy.health-amount);if(enemy.health<=0)enemy.alive=false;return amount;} updateEnemy(){} drawEnemy(){} drawActor(){} defeatEnemy(enemy){enemy.alive=false;enemy.health=0;return true;}
  updatePlayer(){} damagePlayer(actor,amount){actor.health=Math.max(0,actor.health-amount);actor.damageTaken+=amount;if(actor.health<=0)actor.alive=false;return amount;}
  update(delta=0.016){this.animationTime+=delta;return true;} missingObjectiveRequirement(){return '';} missingExtractionRequirement(){return '';}
  completeMission(){this.mission.state='complete';this.mission.rewards={credits:100};this.onEvent({type:'mission-complete',rewards:this.mission.rewards});return true;}
  restartFromCheckpoint(){this.mission.state='active';return true;} phaseLabel(){return'BASE';} objectiveProgressText(){return'BASE';} getInteractionPrompt(){return'';}
  drawBackdrop(){} drawWorld(){} drawHud(){} captureResumeState(){return{schema:1,player:{x:this.player.x,y:this.player.y}};} applyResumeState(){return{applied:true,restored:1};}
  getGameplayReport(){return{base:true};} getSnapshot(){return{base:true};} locked(requirement){this.events.push({type:'locked',requirement});return false;}
}

const V88=withAlien3DlcRuntimeV88(MockBase); const V89=withAlien3DlcRuntimeV89(V88); const V90=withAlien3DlcRuntimeV90(V89); const V91=withAlien3DlcRuntimeV91(V90);
const V92=withAlien3DlcRuntimeV92(V91); const V93=withAlien3DlcRuntimeV93(V92); const V94=withAlien3DlcRuntimeV94(V93); const V95=withAlien3DlcRuntimeV95(V94);
const V96=withAlien3DlcRuntimeV96(V95); const V97=withAlien3DlcRuntimeV97(V96); const Engine=withAlien3DlcRuntimeV98(V97);

const validation=validateAlien3DlcV98(); assert.equal(validation.ok,true,validation.failures.join('; '));
assert.equal(ALIEN3_FIORINA_TEMPLATE_V98.nodes.length,72); assert.equal(ALIEN3_FIORINA_TEMPLATE_V98.edges.length,119); assert.equal(ALIEN3_FIORINA_TEMPLATE_V98.routes.length,4);
assert.equal(ALIEN3_HYBRID_DIRECTOR_PROFILES_V98.length,9); assert.equal(ALIEN3_DEPTH_OCCLUDERS_V98.length,7); assert.equal(ALIEN3_DLC_CODEX_V98.length,78); assert.equal(ALIEN3_DLC_CODEX_TERMINALS_V98.length,6); assert.equal(ALIEN3_V98_EVIDENCE_IDS.length,16);

const runnerProfile={id:'enemy-006-runner',name:'Runner Fiorina',biology:'xenomorph',caste:'runner',health:720,damage:29,speed:1.9};
const engine=new Engine();
engine.start({campaign:{id:ALIEN3_CAMPAIGN_ID_V88},strategicBriefing:{flags:{'alien3-v90-challenge':'archive'}},enemyCatalog:[runnerProfile]});
assert.equal(engine.alien3V98.evidenceRecovered.includes('hybrid-director-ready'),true);

// Traverse all nine contracts; the graph remains unchanged while presentation changes.
for(const sector of ALIEN3_HYBRID_SECTORS_V97){
  engine.player.x=sector.x0+Math.min(90,(sector.x1-sector.x0)/2); engine.player.y=420;
  engine.syncAlien3HybridSectorV97(0.05); engine.syncAlien3DirectorProfileV98();
}
assert.equal(engine.alien3V98.director.profilesVisited.length,9); assert.equal(engine.alien3V98.evidenceRecovered.includes('all-camera-contracts'),true);

// Smooth lane changes must not teleport the canonical lane before the blend completes.
engine.player.x=1900; engine.syncAlien3HybridSectorV97(0.05); engine.syncAlien3DirectorProfileV98(); engine.alien3V97.hybrid.playerLane=1;
assert.equal(engine.shiftAlien3DepthLaneV97(-1),true); assert.equal(engine.alien3V97.hybrid.playerLane,1); assert.equal(engine.alien3V98.director.laneShiftActive,true);
engine.advanceAlien3LaneShiftV98(0.12); assert.equal(engine.alien3V97.hybrid.playerLane,1); assert.ok(engine.alien3V98.director.laneBlend>0&&engine.alien3V98.director.laneBlend<1);
engine.advanceAlien3LaneShiftV98(0.20); assert.equal(engine.alien3V97.hybrid.playerLane,0); assert.equal(engine.alien3V98.director.laneShiftActive,false);
// Two more smooth shifts cover all planes and satisfy the mastery rule.
assert.equal(engine.shiftAlien3DepthLaneV97(1),true); engine.advanceAlien3LaneShiftV98(0.30); assert.equal(engine.alien3V97.hybrid.playerLane,1);
assert.equal(engine.shiftAlien3DepthLaneV97(1),true); engine.advanceAlien3LaneShiftV98(0.30); assert.equal(engine.alien3V97.hybrid.playerLane,2);
assert.ok(engine.alien3V98.telemetry.smoothLaneShifts>=3); assert.equal(engine.alien3V98.evidenceRecovered.includes('smooth-lane-shift'),true);

// Use front/rear occluders.
engine.alien3V97.hybrid.playerLane=0; engine.player.x=350; engine.syncAlien3HybridSectorV97(0.01); engine.updateAlien3DepthCoverV98(0.5);
assert.equal(engine.alien3V98.evidenceRecovered.includes('depth-cover-rear'),true);
engine.player.x=2450; engine.alien3V97.hybrid.playerLane=2; engine.syncAlien3HybridSectorV97(0.01); engine.updateAlien3DepthCoverV98(0.5);
assert.equal(engine.alien3V98.evidenceRecovered.includes('depth-cover-front'),true);

// Runner lane change is telegraphed, not instantaneous.
engine.player.x=1950; engine.alien3V97.hybrid.playerLane=0; engine.alien3V97.hybrid.runnerLane=1; engine.alien3V97.hybrid.runnerLaneClock=0;
engine.alien3RunnerV88.x=engine.player.x+120; engine.alien3RunnerV88.alive=true; engine.alien3V88.runnerDefeated=false;
engine.updateAlien3RunnerDepthV97(0.05);
assert.equal(engine.alien3V97.hybrid.runnerLane,1); assert.ok(engine.alien3V98.director.runnerTelegraphClock>0); assert.equal(engine.alien3V98.director.runnerTelegraphTo,0);
for(let i=0;i<20 && engine.alien3V98.director.runnerTelegraphClock>0;i++) engine.updateAlien3RunnerDepthV97(0.05);
assert.equal(engine.alien3V97.hybrid.runnerLane,0); assert.equal(engine.alien3V98.evidenceRecovered.includes('runner-depth-telegraph'),true);
// Create a genuine lane evade after a telegraphed transition.
engine.alien3V97.hybrid.runnerLane=2; const hp=engine.player.health; assert.equal(engine.damagePlayer(engine.player,12,{source:'Runner Fiorina'}),0); assert.equal(engine.player.health,hp);
engine.update(0.02); assert.equal(engine.alien3V98.evidenceRecovered.includes('runner-transition-survived'),true);

// Unlock the original 66 entries from five terminals and the V98 extension from terminal six.
for(const terminal of ALIEN3_DLC_CODEX_TERMINALS_V98){
  engine.player.x=terminal.x; engine.player.y=terminal.y; engine.syncAlien3HybridSectorV97(0.01); engine.alien3V97.hybrid.playerLane=terminal.lane;
  assert.equal(engine.interact(engine.player),true,terminal.id);
}
assert.equal(engine.alien3CodexUnlockedV98().length,78); assert.equal(engine.alien3V98.codexUi.terminalsRead.length,6); assert.equal(engine.alien3V98.evidenceRecovered.includes('codex-78-complete'),true);
assert.equal(engine.alien3V97.dlcCodex.unlocked.length,66,'V98 must not corrupt V97 exact-66 perfect contract');

// Persistent dedicated UI: category, page, bookmark and full reading state.
engine.openAlien3CodexUiV98(); assert.equal(engine.alien3V98.codexUi.open,true); assert.equal(engine.alien3V98.evidenceRecovered.includes('codex-ui-opened'),true);
assert.equal(engine.cycleAlien3CodexCategoryV98(1),true); assert.equal(engine.alien3V98.evidenceRecovered.includes('codex-category-used'),true);
assert.equal(engine.toggleAlien3CodexBookmarkV98(),true); assert.equal(engine.alien3V98.evidenceRecovered.includes('codex-bookmark-used'),true);
for(const id of engine.alien3CodexUnlockedV98()) engine.markAlien3CodexViewedV98(id);
assert.equal(engine.alien3CodexViewedV98().length,78); assert.equal(engine.alien3V98.evidenceRecovered.includes('codex-reading-complete'),true);

// Balance both presentation contracts without altering topology.
engine.alien3V98.director.depthFrames=130; engine.alien3V98.director.sideFrames=130;
engine.recoverAlien3EvidenceV98('depth-composition-balanced',{silent:true}); engine.recoverAlien3EvidenceV98('side-composition-balanced',{silent:true});
engine.alien3V97.perfectArchive.perfect=true; engine.updateAlien3PerfectV98();
assert.equal(engine.alien3V98.perfectArchive.perfect,true); assert.equal(engine.alien3V98.evidenceRecovered.length,16);
const grade=alien3V98Grade({gradeV97:'S++++++++',evidence:16,profiles:9,codex:78,read:78,smoothShifts:3,coverUses:2,uiActions:3,perfect:true}); assert.equal(grade,'S+++++++++');

const saved=engine.captureResumeState(); assert.equal(saved.specialOperation.alien3V98.schema,98);
const resumed=new Engine(); resumed.start({campaign:{id:ALIEN3_CAMPAIGN_ID_V88},strategicBriefing:{flags:{}},enemyCatalog:[runnerProfile]});
const restored=resumed.applyResumeState(saved); assert.equal(restored.alien3DlcRestoredV98,true); assert.equal(resumed.alien3V98.perfectArchive.perfect,true); assert.equal(resumed.alien3CodexUnlockedV98().length,78); assert.equal(resumed.alien3CodexViewedV98().length,78);

engine.missingExtractionRequirement=()=>''; engine.mission.state='active'; engine.alien3V88.complete=false; assert.equal(engine.completeMission(engine.player),true);
assert.equal(engine.mission.rewards.alien3V98,true); assert.equal(engine.mission.rewards.dedicatedCodexV98.unlocked.length,78); assert.equal(typeof engine.mission.rewards.mireGradeV98,'string');

console.log(JSON.stringify({
  ok:true, validation,
  director:{profiles:engine.alien3V98.director.profilesVisited.length,smoothLaneShifts:engine.alien3V98.telemetry.smoothLaneShifts,runnerTelegraphs:engine.alien3V98.telemetry.runnerTelegraphs,occludersUsed:engine.alien3V98.director.occludersUsed.length},
  dedicatedCodex:{total:ALIEN3_DLC_CODEX_V98.length,unlocked:engine.alien3CodexUnlockedV98().length,viewed:engine.alien3CodexViewedV98().length,terminals:engine.alien3V98.codexUi.terminalsRead.length,bookmarks:engine.alien3V98.codexUi.bookmarks.length},
  evidenceRecovered:engine.alien3V98.evidenceRecovered.length,perfectArchive:engine.alien3V98.perfectArchive,grade,completionGrade:engine.mission.rewards.mireGradeV98,
  resume:{restored:restored.alien3DlcRestoredV98,codex:resumed.alien3CodexUnlockedV98().length,viewed:resumed.alien3CodexViewedV98().length}
},null,2));
