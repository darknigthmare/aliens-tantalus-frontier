#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(process.argv[2] || process.cwd());
const backupRoot = path.join(root, '.alien3-dlc-v88-backup');
const restored = [
  'src/special-operations-v67.js',
  'src/mission-levels-v52.js',
  'src/game-v52-level-runtime.js',
  'src/game-production-runtime.js',
  'src/app.js'
];
const added = [
  'src/alien3-dlc-v88.js',
  'src/alien3-dlc-runtime-v88.js',
  'scripts/test-alien3-dlc-v88.mjs',
  'scripts/uninstall-alien3-dlc-v88.mjs',
  'docs/ALIEN3_DLC_V88.md',
  'ALIEN3_DLC_V88_INSTALL_REPORT.json'
];

if (!fs.existsSync(backupRoot)) {
  console.error('Sauvegarde .alien3-dlc-v88-backup introuvable. Désinstallation automatique impossible.');
  process.exitCode = 1;
} else {
  for (const relative of restored) {
    const source = path.join(backupRoot, relative);
    const target = path.join(root, relative);
    if (!fs.existsSync(source)) throw new Error(`Sauvegarde manquante: ${relative}`);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(source, target);
  }
  for (const relative of added) fs.rmSync(path.join(root, relative), { force: true });
  fs.rmSync(backupRoot, { recursive: true, force: true });
  console.log('Alien 3 — Fiorina 161 V88 désinstallé et fichiers d’origine restaurés.');
}
