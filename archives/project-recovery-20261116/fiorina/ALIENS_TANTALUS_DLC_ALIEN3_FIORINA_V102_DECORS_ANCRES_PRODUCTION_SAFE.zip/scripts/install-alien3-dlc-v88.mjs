#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = path.resolve(process.argv[2] || process.cwd());
const patchRoot = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const EXPECTED_BASE = '496996f5ea557d970ec625aa346876f3eaed1c5f';
const BACKUP_DIR = path.join(root, '.alien3-dlc-v88-backup');
const DRY_RUN = process.argv.includes('--dry-run');
const FORCE = process.argv.includes('--force');

const rel = (...parts) => path.join(...parts);
const targets = [
  rel('src', 'special-operations-v67.js'),
  rel('src', 'mission-levels-v52.js'),
  rel('src', 'game-v52-level-runtime.js'),
  rel('src', 'game-production-runtime.js'),
  rel('src', 'app.js')
];
const additions = [
  rel('src', 'alien3-dlc-v88.js'),
  rel('src', 'alien3-dlc-runtime-v88.js'),
  rel('scripts', 'test-alien3-dlc-v88.mjs'),
  rel('scripts', 'uninstall-alien3-dlc-v88.mjs'),
  rel('docs', 'ALIEN3_DLC_V88.md')
];

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function read(relative) {
  const file = path.join(root, relative);
  if (!fs.existsSync(file)) throw new Error(`Fichier requis absent: ${relative}`);
  return fs.readFileSync(file, 'utf8');
}

function replaceOnce(source, needle, replacement, label) {
  const first = source.indexOf(needle);
  if (first < 0) throw new Error(`Ancre introuvable (${label}). Le dépôt n'est pas la base attendue.`);
  if (source.indexOf(needle, first + needle.length) >= 0) throw new Error(`Ancre ambiguë (${label}). Installation arrêtée.`);
  return source.slice(0, first) + replacement + source.slice(first + needle.length);
}

function insertAfter(source, needle, addition, label) {
  return replaceOnce(source, needle, needle + addition, label);
}

function ensureNotInstalled() {
  if (fs.existsSync(path.join(root, 'src', 'alien3-dlc-v88.js')) && !FORCE) {
    throw new Error('Le DLC Alien 3 V88 semble déjà installé. Utilisez --force uniquement après vérification manuelle.');
  }
}

function gitHead() {
  const head = path.join(root, '.git', 'HEAD');
  if (!fs.existsSync(head)) return null;
  const value = fs.readFileSync(head, 'utf8').trim();
  if (!value.startsWith('ref: ')) return value;
  const ref = path.join(root, '.git', value.slice(5));
  return fs.existsSync(ref) ? fs.readFileSync(ref, 'utf8').trim() : null;
}

function patchSpecialOperations(source) {
  const entry = `  freezeOperation({\n    id: 'alien3-fiorina-161',\n    promisedTitle: 'MIRE ARCHIVE 003 : FIORINA 161', kind: 'mission', implementationStatus: 'effective', playable: true, productionOrder: 20,\n    campaignId: 'special-alien3-fiorina-161', archiveSolo: true, disableVehicle: true,\n    campaign: Object.freeze({\n      pairId: null, mode: 'SURVIVAL', worldId: 'world-05-lethe', objective: 'survive Fiorina 161 and destroy the Runner',\n      year: 2179, canon: 'MIRE archive reconstruction', routes: 3, templateId: 'fiorina-161-prison', minimumCrew: 1,\n      archiveWorld: Object.freeze({ name: 'Fiorina 161', atmosphere: 'breathable', danger: 9, biomes: Object.freeze(['storm-coast', 'penal-complex', 'leadworks', 'industrial-furnace']), archiveReconstruction: true })\n    }),\n    promiseSummary: 'Reconstruction jouable de Fiorina 161 : EEV, infirmerie, prison, Bishop, Runner unique, galeries incendiaires, fonderie au plomb, choc thermique et finale corporative.',\n    requiredMechanics: ['single-runner-predator', 'no-firearms', 'flare-distraction', 'fiorina-prison-metroidvania', 'molten-lead-trap', 'thermal-shock-finale', 'mire-codex', 'isolated-archive-loadout']\n  }),\n`;
  source = replaceOnce(
    source,
    "  freezeOperation({\n    id: 'cargo-brutal',",
    entry + "  freezeOperation({\n    id: 'cargo-brutal',",
    'registre Alien 3 avant Cargo Brutal'
  );
  source = replaceOnce(source, "operations.length !== 19", "operations.length !== 20", 'compteur opérations');
  source = replaceOnce(source, "operations: ${operations.length} != 19", "operations: ${operations.length} != 20", 'message compteur opérations');
  return source;
}

function patchMissionLevels(source) {
  source = insertAfter(
    source,
    "import { buildCetoHabitatsV75, cetoHabitatHazardsV75 } from './enemy-ceto-v75.js';\n",
    "import { ALIEN3_FIORINA_PALETTE_V88, ALIEN3_FIORINA_TEMPLATE_V88 } from './alien3-dlc-v88.js';\n",
    'import template Fiorina'
  );
  source = replaceOnce(
    source,
    "  'colony-multiroute',\n  'planet-exterior'\n]);",
    "  'colony-multiroute',\n  'planet-exterior',\n  'fiorina-161-prison'\n]);",
    'liste template ids'
  );
  source = replaceOnce(
    source,
    "const TEMPLATE_PALETTES = Object.freeze({\n",
    "const TEMPLATE_PALETTES = Object.freeze({\n  [ALIEN3_FIORINA_TEMPLATE_V88.id]: ALIEN3_FIORINA_PALETTE_V88,\n",
    'palette Fiorina'
  );
  source = replaceOnce(
    source,
    "export const MISSION_LEVEL_TEMPLATES_V52 = Object.freeze({\n  [SHIP_TEMPLATE.id]: SHIP_TEMPLATE,",
    "export const MISSION_LEVEL_TEMPLATES_V52 = Object.freeze({\n  [ALIEN3_FIORINA_TEMPLATE_V88.id]: ALIEN3_FIORINA_TEMPLATE_V88,\n  [SHIP_TEMPLATE.id]: SHIP_TEMPLATE,",
    'registre template Fiorina'
  );
  return source;
}

function patchLevelRuntime(source) {
  const marker = "export const MISSION_LEVEL_LAYER_FILES_V52 = Object.freeze({\n";
  const addition = `  'fiorina-161-prison': Object.freeze({\n    far: '/assets/openai/metroidvania/planet-exterior-far.png',\n    mid: '/assets/openai/metroidvania/colony-multiroute-mid.png',\n    foreground: '/assets/openai/metroidvania/tantalus-mission-foreground.png'\n  }),\n`;
  return replaceOnce(source, marker, marker + addition, 'couches visuelles Fiorina');
}

function patchProductionRuntime(source) {
  source = insertAfter(
    source,
    "import { withPlaceablesRuntimeV86 } from './placeables-runtime-v86.js';\n",
    "import { withAlien3DlcRuntimeV88 } from './alien3-dlc-runtime-v88.js';\n",
    'import runtime Alien 3'
  );
  source = replaceOnce(
    source,
    "const V86ProductionEngine = withPlaceablesRuntimeV86(V70ProductionEngine);\n",
    "const V86ProductionEngine = withPlaceablesRuntimeV86(V70ProductionEngine);\nconst V88ProductionEngine = withAlien3DlcRuntimeV88(V86ProductionEngine);\n",
    'chaîne runtime V88'
  );
  source = replaceOnce(source, "export class GameEngine extends V86ProductionEngine {", "export class GameEngine extends V88ProductionEngine {", 'moteur final V88');
  return source;
}

function patchApp(source) {
  source = replaceOnce(
    source,
    "<span>${escapeHtml(world?.name || 'Frontier')}</span><span>${escapeHtml(campaign.objective)}</span>",
    "<span>${escapeHtml(campaign.archiveWorld?.name || world?.name || 'Frontier')}</span><span>${escapeHtml(campaign.objective)}</span>",
    'carte campagne localisation archive'
  );
  source = replaceOnce(
    source,
    "<footer><span>${campaign ? escapeHtml(world?.name || 'Frontier') : hubSurface ? 'USS TANTALUS · HUB PHYSIQUE' : 'REGISTRE DES OPÉRATIONS'}</span>",
    "<footer><span>${campaign ? escapeHtml(campaign.archiveWorld?.name || world?.name || 'Frontier') : hubSurface ? 'USS TANTALUS · HUB PHYSIQUE' : 'REGISTRE DES OPÉRATIONS'}</span>",
    'registre spécial localisation archive'
  );
  source = replaceOnce(
    source,
    "<h3>${escapeHtml(campaign.name)}</h3><p>${escapeHtml(campaign.objective)} · ${escapeHtml(world.name)}</p>${specialNotice}",
    "<h3>${escapeHtml(campaign.name)}</h3><p>${escapeHtml(campaign.objective)} · ${escapeHtml(campaign.archiveWorld?.name || world.name)}</p>${specialNotice}",
    'plan opération localisation archive'
  );
  source = replaceOnce(
    source,
    "  const specialNoticeCopy = specialOperation?.id === 'cargo-brutal'\n",
    "  const specialNoticeCopy = specialOperation?.id === 'alien3-fiorina-161'\n    ? 'Chronique MIRE solo · aucun véhicule ni arsenal militaire · tir converti en flare · Runner unique · plomb fondu puis choc thermique · 13 entrées de codex.'\n    : specialOperation?.id === 'cargo-brutal'\n",
    'notice Alien 3'
  );
  source = replaceOnce(
    source,
    "  const worldState = saveSystem.data.galaxy.worldState[world.id];\n  const before = absoluteHours(saveSystem.data.clock);",
    "  const worldState = saveSystem.data.galaxy.worldState[world.id];\n  const missionWorld = campaign.archiveWorld ? { ...world, ...clone(campaign.archiveWorld), id: world.id } : world;\n  const before = absoluteHours(saveSystem.data.clock);",
    'monde virtuel archive'
  );
  const loadoutOld = `  const crew = operationLoadout.crew;\n  const weapon = operationLoadout.weapon || WEAPONS[0];\n  const equipment = operationLoadout.equipment;\n  const specialOperation = getSpecialOperationByCampaignIdV67(campaign.id);\n  const vehicle = specialOperation?.issuedVehicleId\n    ? VEHICLES.find((entry) => entry.id === specialOperation.issuedVehicleId) || operationLoadout.vehicle\n    : operationLoadout.vehicle;\n  const costume = operationLoadout.costume;`;
  const loadoutNew = `  const specialOperation = getSpecialOperationByCampaignIdV67(campaign.id);\n  const archiveSolo = specialOperation?.archiveSolo === true;\n  const crew = archiveSolo ? [] : operationLoadout.crew;\n  const weapon = operationLoadout.weapon || WEAPONS[0];\n  const equipment = operationLoadout.equipment;\n  const vehicle = archiveSolo || specialOperation?.disableVehicle\n    ? null\n    : specialOperation?.issuedVehicleId\n      ? VEHICLES.find((entry) => entry.id === specialOperation.issuedVehicleId) || operationLoadout.vehicle\n      : operationLoadout.vehicle;\n  const costume = archiveSolo ? null : operationLoadout.costume;`;
  source = replaceOnce(source, loadoutOld, loadoutNew, 'loadout archive solo');
  source = replaceOnce(
    source,
    "    world: { ...world, ...worldState },\n    levelSeeds: LEVEL_SEEDS,",
    "    world: { ...missionWorld, ...worldState },\n    levelSeeds: LEVEL_SEEDS,",
    'builder monde archive'
  );
  source = replaceOnce(
    source,
    "  byId('mission-log').textContent = `MU/TH/UR · ${campaign.objective.toUpperCase()} · ${world.name} · ${missionLevel.templateLabel.toUpperCase()} · RISQUE ${deployment.operation.risk}%`;",
    "  byId('mission-log').textContent = `MU/TH/UR · ${campaign.objective.toUpperCase()} · ${missionWorld.name} · ${missionLevel.templateLabel.toUpperCase()} · RISQUE ${deployment.operation.risk}%`;",
    'log mission archive'
  );
  source = replaceOnce(
    source,
    "    campaign, world, worldState, levelSeed, missionLevel,\n    weapon, equipment, crew, vehicle, costume, deployment, operationLoadout\n  });",
    "    campaign, world: missionWorld, worldState, levelSeed, missionLevel,\n    weapon, equipment, crew, vehicle, costume, deployment, operationLoadout\n  });",
    'contexte mission archive'
  );
  return source;
}

function run() {
  ensureNotInstalled();
  for (const relative of targets) read(relative);
  for (const relative of additions) {
    const source = path.join(patchRoot, relative);
    if (!fs.existsSync(source)) throw new Error(`Fichier du patch absent: ${relative}`);
  }

  const head = gitHead();
  if (head && head !== EXPECTED_BASE && !FORCE) {
    console.warn(`[WARN] HEAD ${head} diffère de la base auditée ${EXPECTED_BASE}. Les ancres doivent toutes correspondre ou l'installation s'arrêtera.`);
  }

  const originals = Object.fromEntries(targets.map((relative) => [relative, read(relative)]));
  const patched = {
    [rel('src', 'special-operations-v67.js')]: patchSpecialOperations(originals[rel('src', 'special-operations-v67.js')]),
    [rel('src', 'mission-levels-v52.js')]: patchMissionLevels(originals[rel('src', 'mission-levels-v52.js')]),
    [rel('src', 'game-v52-level-runtime.js')]: patchLevelRuntime(originals[rel('src', 'game-v52-level-runtime.js')]),
    [rel('src', 'game-production-runtime.js')]: patchProductionRuntime(originals[rel('src', 'game-production-runtime.js')]),
    [rel('src', 'app.js')]: patchApp(originals[rel('src', 'app.js')])
  };

  const report = {
    schema: 88,
    name: 'Alien 3 — Fiorina 161 DLC',
    expectedBaseCommit: EXPECTED_BASE,
    detectedHead: head,
    dryRun: DRY_RUN,
    modified: Object.entries(patched).map(([relative, content]) => ({
      file: relative,
      beforeSha256: sha256(originals[relative]),
      afterSha256: sha256(content),
      beforeBytes: Buffer.byteLength(originals[relative]),
      afterBytes: Buffer.byteLength(content)
    })),
    added: additions.map((relative) => ({ file: relative, sha256: sha256(fs.readFileSync(path.join(patchRoot, relative))) }))
  };

  if (DRY_RUN) {
    console.log(JSON.stringify(report, null, 2));
    return;
  }

  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  try {
    for (const [relative, content] of Object.entries(originals)) {
      const backup = path.join(BACKUP_DIR, relative);
      fs.mkdirSync(path.dirname(backup), { recursive: true });
      fs.writeFileSync(backup, content);
    }
    for (const [relative, content] of Object.entries(patched)) fs.writeFileSync(path.join(root, relative), content);
    for (const relative of additions) {
      const target = path.join(root, relative);
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.copyFileSync(path.join(patchRoot, relative), target);
    }
    fs.writeFileSync(path.join(root, 'ALIEN3_DLC_V88_INSTALL_REPORT.json'), JSON.stringify(report, null, 2));
  } catch (error) {
    for (const [relative, content] of Object.entries(originals)) {
      try { fs.writeFileSync(path.join(root, relative), content); } catch { /* best effort rollback */ }
    }
    for (const relative of additions) {
      try { fs.rmSync(path.join(root, relative), { force: true }); } catch { /* best effort rollback */ }
    }
    throw error;
  }

  console.log('Alien 3 — Fiorina 161 V88 installé.');
  console.log('Sauvegarde des fichiers modifiés :', BACKUP_DIR);
  console.log('Lancez ensuite : npm run check && npm run build');
}

try { run(); }
catch (error) {
  console.error('[ALIEN3 V88] Installation annulée:', error.message);
  process.exitCode = 1;
}
