#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root=path.resolve(process.argv[2]||process.cwd());
const patchRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const EXPECTED_BASE='496996f5ea557d970ec625aa346876f3eaed1c5f';
const BACKUP_DIR=path.join(root,'.alien3-dlc-v99-backup');
const DRY_RUN=process.argv.includes('--dry-run'); const FORCE=process.argv.includes('--force');
const rel=(...parts)=>path.join(...parts);
const targets=[rel('src','special-operations-v67.js'),rel('src','mission-levels-v52.js'),rel('src','game-production-runtime.js'),rel('src','app.js')];
const additions=[rel('src','alien3-dlc-v99.js'),rel('src','alien3-dlc-runtime-v99.js'),rel('scripts','test-alien3-dlc-v99.mjs'),rel('scripts','test-alien3-physical-v99.mjs'),rel('scripts','uninstall-alien3-dlc-v99.mjs'),rel('docs','ALIEN3_DLC_V99.md')];
const sha256=(value)=>crypto.createHash('sha256').update(value).digest('hex');
const read=(relative)=>{const file=path.join(root,relative);if(!fs.existsSync(file))throw new Error(`Fichier requis absent: ${relative}`);return fs.readFileSync(file,'utf8');};
function replaceOnce(source,needle,replacement,label){const first=source.indexOf(needle);if(first<0)throw new Error(`Ancre introuvable (${label}). Le projet n'est pas dans l'état V98 attendu.`);if(source.indexOf(needle,first+needle.length)>=0)throw new Error(`Ancre ambiguë (${label}). Installation arrêtée.`);return source.slice(0,first)+replacement+source.slice(first+needle.length);}
function insertAfter(source,needle,addition,label){return replaceOnce(source,needle,needle+addition,label);}
function gitHead(){const head=path.join(root,'.git','HEAD');if(!fs.existsSync(head))return null;const value=fs.readFileSync(head,'utf8').trim();if(!value.startsWith('ref: '))return value;const ref=path.join(root,'.git',value.slice(5));return fs.existsSync(ref)?fs.readFileSync(ref,'utf8').trim():null;}
function ensureV98(){
  const installed=fs.existsSync(path.join(root,'src','alien3-dlc-v98.js'))&&fs.existsSync(path.join(root,'src','alien3-dlc-runtime-v98.js'));
  if(installed)return{alreadyInstalled:true,installedNow:false};
  if(DRY_RUN)return{alreadyInstalled:false,installedNow:false,wouldInstall:true};
  const installer=path.join(patchRoot,'scripts','install-alien3-dlc-v98.mjs');if(!fs.existsSync(installer))throw new Error('Base V98 absente du pack V99.');
  const args=[installer,root];if(FORCE)args.push('--force');const result=spawnSync(process.execPath,args,{stdio:'inherit'});if(result.status!==0)throw new Error('Installation automatique de la base V98 impossible.');return{alreadyInstalled:false,installedNow:true};
}
function patchSpecialOperations(source){
  source=replaceOnce(source,
    "promiseSummary: 'Reconstruction MIRE V98 Hybrid Director de Fiorina 161 : transitions de profondeur lissées, télégraphe multi-plan du Runner, neuf contrats caméra, occultants physiques et Codex Alien 3 dédié de 78 entrées.',",
    "promiseSummary: 'Reconstruction MIRE V99 Adaptive Pursuit de Fiorina 161 : cinq poursuites adaptatives, ponts caméra, pression de chasse et Codex Alien 3 dédié de 90 entrées avec recherche et liens croisés.',",'résumé V99');
  source=replaceOnce(source,
    "'mire-master-archive', 'zone-atmosphere-simulation', 'optional-dlc-audio-slots', 'directional-threat-captions', 'environment-power-tradeoffs', 'prisoner-climate-feedback', 'audio-fallback-safety', 'acoustic-diagnostic-gate', 'mire-codex-130', 'hybrid-depth-view-9-sectors', 'three-depth-lanes', 'automatic-side-tension-transitions', 'runner-depth-lane-chase', 'hybrid-director-9-camera-contracts', 'smooth-depth-lane-blend', 'runner-depth-telegraph', 'depth-occluders', 'dedicated-alien3-codex-78', 'persistent-codex-ui', 'replay-challenges', 'isolated-archive-loadout']",
    "'mire-master-archive', 'zone-atmosphere-simulation', 'optional-dlc-audio-slots', 'directional-threat-captions', 'environment-power-tradeoffs', 'prisoner-climate-feedback', 'audio-fallback-safety', 'acoustic-diagnostic-gate', 'mire-codex-130', 'hybrid-depth-view-9-sectors', 'three-depth-lanes', 'automatic-side-tension-transitions', 'runner-depth-lane-chase', 'hybrid-director-9-camera-contracts', 'smooth-depth-lane-blend', 'runner-depth-telegraph', 'depth-occluders', 'adaptive-pursuit-5-chases', 'camera-bridges', 'pursuit-pressure', 'dedicated-alien3-codex-90', 'codex-search-links-history', 'persistent-codex-ui', 'replay-challenges', 'isolated-archive-loadout']",'mécaniques V99');
  return source;
}
function patchMissionLevels(source){
  source=replaceOnce(source,"import { ALIEN3_FIORINA_PALETTE_V98, ALIEN3_FIORINA_TEMPLATE_V98 } from './alien3-dlc-v98.js';\n","import { ALIEN3_FIORINA_PALETTE_V99, ALIEN3_FIORINA_TEMPLATE_V99 } from './alien3-dlc-v99.js';\n",'import template V99');
  source=replaceOnce(source,'[ALIEN3_FIORINA_TEMPLATE_V98.id]: ALIEN3_FIORINA_PALETTE_V98,','[ALIEN3_FIORINA_TEMPLATE_V99.id]: ALIEN3_FIORINA_PALETTE_V99,','palette V99');
  source=replaceOnce(source,'[ALIEN3_FIORINA_TEMPLATE_V98.id]: ALIEN3_FIORINA_TEMPLATE_V98,','[ALIEN3_FIORINA_TEMPLATE_V99.id]: ALIEN3_FIORINA_TEMPLATE_V99,','template V99');return source;
}
function patchProductionRuntime(source){
  source=insertAfter(source,"import { withAlien3DlcRuntimeV98 } from './alien3-dlc-runtime-v98.js';\n","import { withAlien3DlcRuntimeV99 } from './alien3-dlc-runtime-v99.js';\n",'import runtime V99');
  source=replaceOnce(source,'const V98ProductionEngine = withAlien3DlcRuntimeV98(V97ProductionEngine);\n','const V98ProductionEngine = withAlien3DlcRuntimeV98(V97ProductionEngine);\nconst V99ProductionEngine = withAlien3DlcRuntimeV99(V98ProductionEngine);\n','chaîne moteur V99');
  source=replaceOnce(source,'export class GameEngine extends V98ProductionEngine {','export class GameEngine extends V99ProductionEngine {','moteur final V99');return source;
}
function patchApp(source){
  source=replaceOnce(source,
    "    ? 'Chronique MIRE V98 Hybrid Director solo · 4 routes / 130 dossiers MIRE + Codex DLC 78 · 9 contrats caméra · transitions de plan lissées · Runner télégraphié · occultants profondeur.'",
    "    ? 'Chronique MIRE V99 Adaptive Pursuit solo · 4 routes / Codex DLC 90 · 5 poursuites adaptatives · ponts caméra · recherche et liens croisés.'",'notice opération V99');
  const helperAnchor=`const isAlien3V98RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v98-');\nconst alien3V98EventLabel = (event) => {\n  const detail = event.title || event.action || event.evidenceId || event.codexId || event.profileId || event.type.replace('alien3-v98-', '');\n  return \`ALIEN 3 V98 · \${String(detail || 'HYBRID DIRECTOR').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  const helper=`const isAlien3V99RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v99-');\nconst alien3V99EventLabel = (event) => {\n  const detail = event.title || event.action || event.evidenceId || event.codexId || event.chaseId || event.type.replace('alien3-v99-', '');\n  return \`ALIEN 3 V99 · \${String(detail || 'ADAPTIVE PURSUIT').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  source=insertAfter(source,helperAnchor,helper,'helpers événements V99');
  const handleAnchor=`  if (isAlien3V98RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V98EventLabel(event);\n  }\n`;
  source=insertAfter(source,handleAnchor,`  if (isAlien3V99RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V99EventLabel(event);\n  }\n`,'journal événements V99');
  const persistenceAnchor=`  const alien3V97PersistenceDue = isAlien3V97RuntimeEvent(event);\n  const alien3V98PersistenceDue = isAlien3V98RuntimeEvent(event);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue || alien3V90PersistenceDue || alien3V91PersistenceDue || alien3V92PersistenceDue || alien3V93PersistenceDue || alien3V94PersistenceDue || alien3V95PersistenceDue || alien3V96PersistenceDue || alien3V97PersistenceDue || alien3V98PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  const replacement=`  const alien3V97PersistenceDue = isAlien3V97RuntimeEvent(event);\n  const alien3V98PersistenceDue = isAlien3V98RuntimeEvent(event);\n  const alien3V99PersistenceDue = isAlien3V99RuntimeEvent(event);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue || alien3V90PersistenceDue || alien3V91PersistenceDue || alien3V92PersistenceDue || alien3V93PersistenceDue || alien3V94PersistenceDue || alien3V95PersistenceDue || alien3V96PersistenceDue || alien3V97PersistenceDue || alien3V98PersistenceDue || alien3V99PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  return replaceOnce(source,persistenceAnchor,replacement,'persistance événements V99');
}
function run(){
  if(fs.existsSync(path.join(root,'src','alien3-dlc-v99.js'))&&!FORCE)throw new Error('Le DLC Alien 3 V99 semble déjà installé.');
  const v98=ensureV98();if(DRY_RUN&&v98.wouldInstall){console.log(JSON.stringify({schema:99,dryRun:true,prerequisite:'V98 (and V97…V88) would be installed first',expectedBaseCommit:EXPECTED_BASE},null,2));return;}
  for(const relative of targets)read(relative);for(const relative of additions)if(!fs.existsSync(path.join(patchRoot,relative)))throw new Error(`Fichier du patch absent: ${relative}`);
  const head=gitHead();if(head&&head!==EXPECTED_BASE&&!FORCE)console.warn(`[WARN] HEAD ${head} diffère de la base auditée ${EXPECTED_BASE}; V99 vérifie les ancres V98 avant écriture.`);
  const originals=Object.fromEntries(targets.map((relative)=>[relative,read(relative)]));
  const patched={
    [rel('src','special-operations-v67.js')]:patchSpecialOperations(originals[rel('src','special-operations-v67.js')]),
    [rel('src','mission-levels-v52.js')]:patchMissionLevels(originals[rel('src','mission-levels-v52.js')]),
    [rel('src','game-production-runtime.js')]:patchProductionRuntime(originals[rel('src','game-production-runtime.js')]),
    [rel('src','app.js')]:patchApp(originals[rel('src','app.js')])
  };
  const report={schema:99,name:'Alien 3 — Fiorina 161 DLC V99 Hybrid Director',expectedBaseCommit:EXPECTED_BASE,detectedHead:head,v98InstalledByThisRun:v98.installedNow,dryRun:DRY_RUN,
    modified:Object.entries(patched).map(([relative,content])=>({file:relative,beforeSha256:sha256(originals[relative]),afterSha256:sha256(content),beforeBytes:Buffer.byteLength(originals[relative]),afterBytes:Buffer.byteLength(content)})),
    added:additions.map((relative)=>({file:relative,sha256:sha256(fs.readFileSync(path.join(patchRoot,relative)))}))};
  if(DRY_RUN){console.log(JSON.stringify(report,null,2));return;}
  fs.mkdirSync(BACKUP_DIR,{recursive:true});
  try{
    for(const [relative,content] of Object.entries(originals)){const backup=path.join(BACKUP_DIR,relative);fs.mkdirSync(path.dirname(backup),{recursive:true});fs.writeFileSync(backup,content);}
    for(const [relative,content] of Object.entries(patched))fs.writeFileSync(path.join(root,relative),content);
    for(const relative of additions){const target=path.join(root,relative);fs.mkdirSync(path.dirname(target),{recursive:true});fs.copyFileSync(path.join(patchRoot,relative),target);}
    fs.writeFileSync(path.join(root,'ALIEN3_DLC_V99_INSTALL_REPORT.json'),JSON.stringify(report,null,2));
  }catch(error){for(const [relative,content] of Object.entries(originals)){try{fs.writeFileSync(path.join(root,relative),content);}catch{}}for(const relative of additions){try{fs.rmSync(path.join(root,relative),{force:true});}catch{}}throw error;}
  console.log('Alien 3 — Fiorina 161 V99 Hybrid Director installé.');
  console.log('V99 est cumulatif : V88 à V98 restent les couches de base.');
  console.log('Lancez : node scripts/test-alien3-dlc-v99.mjs && node scripts/test-alien3-physical-v99.mjs && npm run check && npm run build');
}
try{run();}catch(error){console.error('[ALIEN3 V99] Installation annulée:',error.message);process.exitCode=1;}
