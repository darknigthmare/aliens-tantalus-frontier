#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(process.argv[2] || process.cwd());
const patchRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXPECTED_BASE = '496996f5ea557d970ec625aa346876f3eaed1c5f';
const BACKUP_DIR = path.join(root, '.alien3-dlc-v90-backup');
const DRY_RUN = process.argv.includes('--dry-run');
const FORCE = process.argv.includes('--force');
const rel = (...parts) => path.join(...parts);

const targets = [
  rel('src', 'special-operations-v67.js'),
  rel('src', 'mission-levels-v52.js'),
  rel('src', 'game-production-runtime.js'),
  rel('src', 'app.js')
];
const additions = [
  rel('src', 'alien3-dlc-v90.js'),
  rel('src', 'alien3-dlc-runtime-v90.js'),
  rel('scripts', 'test-alien3-dlc-v90.mjs'),
  rel('scripts', 'uninstall-alien3-dlc-v90.mjs'),
  rel('docs', 'ALIEN3_DLC_V90.md')
];

function sha256(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function read(relative) {
  const file = path.join(root, relative);
  if (!fs.existsSync(file)) throw new Error(`Fichier requis absent: ${relative}`);
  return fs.readFileSync(file, 'utf8');
}
function replaceOnce(source, needle, replacement, label) {
  const first = source.indexOf(needle);
  if (first < 0) throw new Error(`Ancre introuvable (${label}). Le projet n'est pas dans l'état V89 attendu.`);
  if (source.indexOf(needle, first + needle.length) >= 0) throw new Error(`Ancre ambiguë (${label}). Installation arrêtée.`);
  return source.slice(0, first) + replacement + source.slice(first + needle.length);
}
function insertAfter(source, needle, addition, label) { return replaceOnce(source, needle, needle + addition, label); }

function gitHead() {
  const head = path.join(root, '.git', 'HEAD');
  if (!fs.existsSync(head)) return null;
  const value = fs.readFileSync(head, 'utf8').trim();
  if (!value.startsWith('ref: ')) return value;
  const ref = path.join(root, '.git', value.slice(5));
  return fs.existsSync(ref) ? fs.readFileSync(ref, 'utf8').trim() : null;
}

function ensureV89() {
  const installed = fs.existsSync(path.join(root, 'src', 'alien3-dlc-v89.js'))
    && fs.existsSync(path.join(root, 'src', 'alien3-dlc-runtime-v89.js'));
  if (installed) return { alreadyInstalled: true, installedNow: false };
  if (DRY_RUN) return { alreadyInstalled: false, installedNow: false, wouldInstall: true };
  const installer = path.join(patchRoot, 'scripts', 'install-alien3-dlc-v89.mjs');
  if (!fs.existsSync(installer)) throw new Error('Base V89 absente du pack V90.');
  const args = [installer, root];
  if (FORCE) args.push('--force');
  const result = spawnSync(process.execPath, args, { stdio: 'inherit' });
  if (result.status !== 0) throw new Error('Installation automatique de la base V89 impossible.');
  return { alreadyInstalled: false, installedNow: true };
}

function patchSpecialOperations(source) {
  source = replaceOnce(
    source,
    "promiseSummary: 'Reconstruction étendue de Fiorina 161 : montages cinéma/Assembly, Runner dirigé, registre des prisonniers, cuve à déchets, Golic/Junior, fonderie au plomb, choc thermique, Patna et finale différenciée.',",
    "promiseSummary: 'Reconstruction MIRE V90 de Fiorina 161 : montages cinéma/Assembly, Runner adaptatif au bruit, plan au quinitricetyline physiquement préparé, retour EEV pour diagnostic royal, détenus affectés aux sections, fonderie plomb/eau causale, Patna et finale différenciée.',",
    'résumé V90'
  );
  source = replaceOnce(
    source,
    "requiredMechanics: ['single-runner-predator', 'runner-director', 'no-firearms', 'persistent-flare-lures', 'fiorina-prison-metroidvania', 'four-route-topology', 'theatrical-assembly-cuts', 'waste-tank-containment', 'named-prisoner-roster', 'molten-lead-trap', 'thermal-shock-finale', 'patna-company-sequence', 'mire-codex', 'isolated-archive-loadout']",
    "requiredMechanics: ['single-runner-predator', 'adaptive-noise-director', 'no-firearms', 'persistent-flare-lures', 'fiorina-prison-metroidvania', 'four-route-topology', 'physical-quinitricetyline-plan', 'fire-propagation', 'post-fire-eev-scan', 'theatrical-assembly-cuts', 'waste-tank-containment', 'named-prisoner-tasking', 'causal-lead-water-prep', 'molten-lead-trap', 'thermal-shock-finale', 'patna-company-sequence', 'mire-codex-35', 'replay-challenges', 'isolated-archive-loadout']",
    'mécaniques V90'
  );
  return source;
}

function patchMissionLevels(source) {
  source = replaceOnce(
    source,
    "import { ALIEN3_FIORINA_PALETTE_V89, ALIEN3_FIORINA_TEMPLATE_V89 } from './alien3-dlc-v89.js';\n",
    "import { ALIEN3_FIORINA_PALETTE_V90, ALIEN3_FIORINA_TEMPLATE_V90 } from './alien3-dlc-v90.js';\n",
    'import template V90'
  );
  source = replaceOnce(source, '[ALIEN3_FIORINA_TEMPLATE_V89.id]: ALIEN3_FIORINA_PALETTE_V89,', '[ALIEN3_FIORINA_TEMPLATE_V90.id]: ALIEN3_FIORINA_PALETTE_V90,', 'palette V90');
  source = replaceOnce(source, '[ALIEN3_FIORINA_TEMPLATE_V89.id]: ALIEN3_FIORINA_TEMPLATE_V89,', '[ALIEN3_FIORINA_TEMPLATE_V90.id]: ALIEN3_FIORINA_TEMPLATE_V90,', 'template V90');
  return source;
}

function patchProductionRuntime(source) {
  source = insertAfter(
    source,
    "import { withAlien3DlcRuntimeV89 } from './alien3-dlc-runtime-v89.js';\n",
    "import { withAlien3DlcRuntimeV90 } from './alien3-dlc-runtime-v90.js';\n",
    'import runtime V90'
  );
  source = replaceOnce(
    source,
    'const V89ProductionEngine = withAlien3DlcRuntimeV89(V88ProductionEngine);\n',
    'const V89ProductionEngine = withAlien3DlcRuntimeV89(V88ProductionEngine);\nconst V90ProductionEngine = withAlien3DlcRuntimeV90(V89ProductionEngine);\n',
    'chaîne moteur V90'
  );
  source = replaceOnce(source, 'export class GameEngine extends V89ProductionEngine {', 'export class GameEngine extends V90ProductionEngine {', 'moteur final V90');
  return source;
}

function patchApp(source) {
  source = replaceOnce(
    source,
    "    ? 'Chronique MIRE V89 solo · 4 routes · montage cinéma ou Assembly · Runner dirigé · flares persistants · cuve à déchets · plomb/choc thermique · Patna · 25 dossiers MIRE.'",
    "    ? 'Chronique MIRE V90 solo · 4 routes · feu au quinitricetyline préparé physiquement · retour EEV pour diagnostic · Runner adaptatif au bruit · prisonniers affectés · plomb/eau causaux · cinéma/Assembly · 35 dossiers MIRE.'",
    'notice opération V90'
  );
  const helperAnchor = `const isAlien3V89RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v89-');\nconst alien3V89EventLabel = (event) => {\n  const detail = event.stage || event.state || event.evidenceId || event.characterId || event.cut || event.action || event.type.replace('alien3-v89-', '');\n  return \`MIRE 161 · \${String(detail || 'ARCHIVE ACTUALISÉE').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  const helper = `const isAlien3V90RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v90-');\nconst alien3V90EventLabel = (event) => {\n  const detail = event.title || event.action || event.evidenceId || event.challengeId || event.manifoldId || event.type.replace('alien3-v90-', '');\n  return \`MIRE 161 V90 · \${String(detail || 'RECONSTRUCTION ACTUALISÉE').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  source = insertAfter(source, helperAnchor, helper, 'helpers événements V90');

  const handleAnchor = `  if (isAlien3V89RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V89EventLabel(event);\n  }\n`;
  source = insertAfter(source, handleAnchor, `  if (isAlien3V90RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V90EventLabel(event);\n  }\n`, 'journal événements V90');

  const persistenceAnchor = `  const alien3V89PersistenceDue = isAlien3V89RuntimeEvent(event)\n    && event.type !== 'alien3-v89-runner-director';\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  const persistenceReplacement = `  const alien3V89PersistenceDue = isAlien3V89RuntimeEvent(event)\n    && event.type !== 'alien3-v89-runner-director';\n  const alien3V90PersistenceDue = isAlien3V90RuntimeEvent(event)\n    && !['alien3-v90-sensory', 'alien3-v90-presentation'].includes(event.type);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue || alien3V90PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  source = replaceOnce(source, persistenceAnchor, persistenceReplacement, 'persistance événements V90');
  return source;
}

function run() {
  if (fs.existsSync(path.join(root, 'src', 'alien3-dlc-v90.js')) && !FORCE) throw new Error('Le DLC Alien 3 V90 semble déjà installé.');
  const v89 = ensureV89();
  if (DRY_RUN && v89.wouldInstall) {
    console.log(JSON.stringify({ schema: 90, dryRun: true, prerequisite: 'V89 (and V88) would be installed first', expectedBaseCommit: EXPECTED_BASE }, null, 2));
    return;
  }
  for (const relative of targets) read(relative);
  for (const relative of additions) if (!fs.existsSync(path.join(patchRoot, relative))) throw new Error(`Fichier du patch absent: ${relative}`);
  const head = gitHead();
  if (head && head !== EXPECTED_BASE && !FORCE) console.warn(`[WARN] HEAD ${head} diffère de la base auditée ${EXPECTED_BASE}; V90 vérifie les ancres V89 avant écriture.`);

  const originals = Object.fromEntries(targets.map((relative) => [relative, read(relative)]));
  const patched = {
    [rel('src', 'special-operations-v67.js')]: patchSpecialOperations(originals[rel('src', 'special-operations-v67.js')]),
    [rel('src', 'mission-levels-v52.js')]: patchMissionLevels(originals[rel('src', 'mission-levels-v52.js')]),
    [rel('src', 'game-production-runtime.js')]: patchProductionRuntime(originals[rel('src', 'game-production-runtime.js')]),
    [rel('src', 'app.js')]: patchApp(originals[rel('src', 'app.js')])
  };
  const report = {
    schema: 90,
    name: 'Alien 3 — Fiorina 161 DLC V90',
    expectedBaseCommit: EXPECTED_BASE,
    detectedHead: head,
    v89InstalledByThisRun: v89.installedNow,
    dryRun: DRY_RUN,
    modified: Object.entries(patched).map(([relative, content]) => ({
      file: relative,
      beforeSha256: sha256(originals[relative]),
      afterSha256: sha256(content),
      beforeBytes: Buffer.byteLength(originals[relative]),
      afterBytes: Buffer.byteLength(content)
    })),
    added: additions.map((relative) => ({ file: relative, sha256: sha256(fs.readFileSync(path.join(patchRoot, relative))) }))
  };
  if (DRY_RUN) { console.log(JSON.stringify(report, null, 2)); return; }

  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  try {
    for (const [relative, content] of Object.entries(originals)) {
      const backup = path.join(BACKUP_DIR, relative);
      fs.mkdirSync(path.dirname(backup), { recursive: true });
      fs.writeFileSync(backup, content);
    }
    for (const [relative, content] of Object.entries(patched)) fs.writeFileSync(path.join(root, relative), content);
    for (const relative of additions) {
      const target = path.join(root, relative);
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.copyFileSync(path.join(patchRoot, relative), target);
    }
    fs.writeFileSync(path.join(root, 'ALIEN3_DLC_V90_INSTALL_REPORT.json'), JSON.stringify(report, null, 2));
  } catch (error) {
    for (const [relative, content] of Object.entries(originals)) { try { fs.writeFileSync(path.join(root, relative), content); } catch {} }
    for (const relative of additions) { try { fs.rmSync(path.join(root, relative), { force: true }); } catch {} }
    throw error;
  }
  console.log('Alien 3 — Fiorina 161 V90 installé.');
  console.log('V90 est cumulatif : V88 et V89 sont conservés comme couches de base.');
  console.log('Lancez : node scripts/test-alien3-dlc-v90.mjs && npm run check && npm run build');
}

try { run(); }
catch (error) { console.error('[ALIEN3 V90] Installation annulée:', error.message); process.exitCode = 1; }
