import assert from 'node:assert/strict';
import { ALIEN3_LEVEL_DESIGN_LAYOUTS_V101, ALIEN3_LEVEL_DESIGN_SECTORS_V101, auditAlien3LevelDesignV101 } from '../src/alien3-dlc-v101.js';
import { ALIEN3_FIORINA_TEMPLATE_V101 } from '../src/alien3-dlc-v101.js';
const audit=auditAlien3LevelDesignV101();assert.equal(audit.ok,true,audit.failures.join('; '));assert.equal(ALIEN3_FIORINA_TEMPLATE_V101.nodes.length,72);assert.equal(ALIEN3_FIORINA_TEMPLATE_V101.edges.length,119);assert.equal(ALIEN3_FIORINA_TEMPLATE_V101.routes.length,4);
for(const spec of ALIEN3_LEVEL_DESIGN_SECTORS_V101){const list=ALIEN3_LEVEL_DESIGN_LAYOUTS_V101[spec.id];assert.ok(list.length>=spec.targetMin&&list.length<=spec.targetMax,spec.id);assert.equal(list.some(p=>spec.forbidden.includes(p.family)),false,`${spec.id}: forbidden`);assert.ok(new Set(list.map(p=>p.family)).size>=5,`${spec.id}: diversity`);assert.ok(list.some(p=>p.layer==='far'),`${spec.id}: far`);assert.ok(list.some(p=>p.layer==='mid'),`${spec.id}: mid`);}
console.log(JSON.stringify({ok:true,nodes:72,edges:119,routes:4,sectors:9,totalProps:audit.totalProps,archetypes:audit.archetypes,rules:audit.rules,sectorAudit:audit.sectors},null,2));
