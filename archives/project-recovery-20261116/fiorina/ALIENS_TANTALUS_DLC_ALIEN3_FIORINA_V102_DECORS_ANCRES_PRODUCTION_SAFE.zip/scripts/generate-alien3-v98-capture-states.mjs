import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ALIEN3_CAMPAIGN_ID_V88 } from '../src/alien3-dlc-v88.js';
import { withAlien3DlcRuntimeV88 } from '../src/alien3-dlc-runtime-v88.js';
import { withAlien3DlcRuntimeV89 } from '../src/alien3-dlc-runtime-v89.js';
import { withAlien3DlcRuntimeV90 } from '../src/alien3-dlc-runtime-v90.js';
import { withAlien3DlcRuntimeV91 } from '../src/alien3-dlc-runtime-v91.js';
import { withAlien3DlcRuntimeV92 } from '../src/alien3-dlc-runtime-v92.js';
import { withAlien3DlcRuntimeV93 } from '../src/alien3-dlc-runtime-v93.js';
import { withAlien3DlcRuntimeV94 } from '../src/alien3-dlc-runtime-v94.js';
import { withAlien3DlcRuntimeV95 } from '../src/alien3-dlc-runtime-v95.js';
import { withAlien3DlcRuntimeV96 } from '../src/alien3-dlc-runtime-v96.js';
import { withAlien3DlcRuntimeV97 } from '../src/alien3-dlc-runtime-v97.js';
import { withAlien3DlcRuntimeV98 } from '../src/alien3-dlc-runtime-v98.js';
import { ALIEN3_DLC_CODEX_TERMINALS_V98 } from '../src/alien3-dlc-v98.js';

class MockBase {
  constructor(){this.events=[];this.images=new Map();this.enemies=[];this.doors=[];this.keys=new Set();this.running=true;this.paused=false;this.platforms=[{id:'ground',x:0,y:510,w:6200},{id:'deep',x:0,y:630,w:6200},{id:'high',x:0,y:330,w:6200},{id:'perch',x:0,y:190,w:6200}];this.player={id:'player',x:180,y:420,w:44,h:90,alive:true,health:88,maxHealth:100,armor:0,kills:0,damageTaken:0,actionClock:0,fireClock:0,vx:0,vy:0,facing:1,crouching:false,grounded:true};this.coop={id:'coop',x:120,y:420,w:44,h:90,alive:false,health:0,armor:0,kills:0,damageTaken:0,vx:0,vy:0};this.vehicle={active:false,occupied:false,driver:null,passengers:[],x:-9999};this.weaponPickup={taken:true,x:-9999};this.toolPickup={taken:true,x:-9999};this.supplies=[];this.objectiveNodes=[];this.archiveTerminal={recovered:false,x:-9999};this.powerNode={active:false,x:-9999};this.objective={x:6000,y:420,w:68,h:90,complete:false};this.missionLevelRuntime={anchors:{extraction:{x:6040,y:510}}};this.missionLevelVisualState={activeZoneId:'f161-coast'};this.mission={state:'active',objectives:{power:true,route:true,boss:false,archive:true,extract:false},rewards:{},retries:0,elapsed:0,casualties:0};this.inventory={salvage:0,intel:0};this.audio={ui(){},alarm(){},hit(){},tone(){return true;},playEffect(id,fallback){fallback?.();return false;}};this.camera={x:0,y:0};this.animationTime=8.3;this.onEvent=(event)=>this.events.push(event);}
  start(options={}){this.campaign=options.campaign;this.strategicBriefing=options.strategicBriefing;return{base:true};}
  createEnemy(profile,index,x,groundY,options={}){return{...profile,id:profile.id||`enemy-${index}`,x,y:groundY-90,w:108,h:82,health:profile.health||100,maxHealth:profile.health||100,speed:profile.speed||1,damage:profile.damage||10,alive:true,facing:-1,alert:true,staggerClock:0,hurtClock:0,...options};}
  initializeEnemyMissionNavigation(){}interact(){return false;}fire(){return false;}reload(){return true;}toggleVehicle(){return true;}useEquipment(){return true;}activateTracker(){return false;}applyEnemyDamage(e,a){e.health=Math.max(0,e.health-a);return a;}updateEnemy(){}drawEnemy(){}drawActor(){}defeatEnemy(e){e.alive=false;return true;}updatePlayer(){}damagePlayer(a,n){a.health=Math.max(0,a.health-n);a.damageTaken+=n;return n;}update(d=.016){this.animationTime+=d;return true;}missingObjectiveRequirement(){return'';}missingExtractionRequirement(){return'';}completeMission(){return true;}restartFromCheckpoint(){return true;}phaseLabel(){return'ARCHIVE';}objectiveProgressText(){return'FIORINA 161';}getInteractionPrompt(){return'';}drawBackdrop(){}drawWorld(){}drawHud(){}captureResumeState(){return{schema:1}}applyResumeState(){return{applied:true,restored:1}}getGameplayReport(){return{base:true}}getSnapshot(){return{base:true}}locked(){return false;}
}
const V88=withAlien3DlcRuntimeV88(MockBase),V89=withAlien3DlcRuntimeV89(V88),V90=withAlien3DlcRuntimeV90(V89),V91=withAlien3DlcRuntimeV91(V90),V92=withAlien3DlcRuntimeV92(V91),V93=withAlien3DlcRuntimeV93(V92),V94=withAlien3DlcRuntimeV94(V93),V95=withAlien3DlcRuntimeV95(V94),V96=withAlien3DlcRuntimeV96(V95),V97=withAlien3DlcRuntimeV97(V96),Engine=withAlien3DlcRuntimeV98(V97);
const runnerProfile={id:'enemy-006-runner',name:'Runner Fiorina',biology:'xenomorph',caste:'runner',health:720,damage:29,speed:1.9};
const make=()=>{const e=new Engine();e.start({campaign:{id:ALIEN3_CAMPAIGN_ID_V88},strategicBriefing:{flags:{'alien3-v90-challenge':'archive'}},enemyCatalog:[runnerProfile]});return e;};
function setPos(e,x,runnerX,lane=1,runnerLane=1){e.player.x=x;e.player.y=420;e.alien3RunnerV88.x=runnerX;e.alien3RunnerV88.y=420;e.alien3RunnerV88.alive=true;e.syncAlien3HybridSectorV97(.05);e.alien3V97.hybrid.playerLane=lane;e.alien3V97.hybrid.runnerLane=runnerLane;e.syncAlien3DirectorProfileV98();}
function snapshot(e,id,title,notes){return{id,title,notes,player:{x:e.player.x,y:e.player.y,health:e.player.health,lane:e.alien3V97.hybrid.playerLane},runner:{x:e.alien3RunnerV88.x,y:e.alien3RunnerV88.y,alive:e.alien3RunnerV88.alive,lane:e.alien3V97.hybrid.runnerLane},sector:e.currentAlien3HybridSectorV97(),v97:e.alien3V97,v98:e.alien3V98,events:e.events.slice(-12)};}
const scenes=[];
{
 const e=make();setPos(e,430,780,0,2);scenes.push(snapshot(e,'01_storm_depth','Cour de la tempête · profondeur','Player arrière, Runner avant : démonstration de séparation de plans.'));
}
{
 const e=make();setPos(e,2200,2550,0,1);e.alien3V98.director.laneShiftActive=true;e.alien3V98.director.laneFrom=0;e.alien3V98.director.laneTo=2;e.alien3V98.director.laneBlend=.54;e.alien3V98.director.runnerTelegraphFrom=1;e.alien3V98.director.runnerTelegraphTo=2;e.alien3V98.director.runnerTelegraphClock=.42;scenes.push(snapshot(e,'02_cellblock_shift','Bloc carcéral · transition lissée','Transition arrière→avant à 54 %, avec télégraphe Runner vers l’avant.'));
}
{
 const e=make();setPos(e,3200,3525,1,1);scenes.push(snapshot(e,'03_service_side','Galeries techniques · 2D tension','Retour automatique en vue latérale stricte dans les conduits.'));
}
{
 const e=make();setPos(e,4380,4725,2,0);e.alien3V98.director.runnerTelegraphFrom=0;e.alien3V98.director.runnerTelegraphTo=2;e.alien3V98.director.runnerTelegraphClock=.58;scenes.push(snapshot(e,'04_foundry_hunt','Fonderie · chasse multi-plan','Joueur avant, Runner arrière, destination avant télégraphiée.'));
}
{
 const e=make();setPos(e,3840,4100,2,1);for(const t of ALIEN3_DLC_CODEX_TERMINALS_V98)e.readAlien3CodexTerminalV97(t);for(const id of e.alien3CodexUnlockedV98().slice(0,52))e.markAlien3CodexViewedV98(id);e.alien3V98.codexUi.open=true;e.alien3V98.codexUi.selectedCategory='PRÉSENTATION';e.alien3V98.codexUi.currentId='a3c-v98-director';e.alien3V98.codexUi.bookmarks=['a3c-v98-director','a3c-overview-hybrid','a3c-xeno-runner'];scenes.push(snapshot(e,'05_codex_overlay','Codex Alien 3 V98','Interface dédiée : catégories, non-lus, favoris et 78 entrées séparées du MIRE.'));
}
{
 const e=make();setPos(e,5420,5700,1,1);e.alien3RunnerV88.alive=false;scenes.push(snapshot(e,'06_patna_depth','Four / arrivée Patna · profondeur','Mise en scène ouverte de la confrontation avant retour final en 2D.'));
}
{
 const e=make();setPos(e,5920,6100,1,1);e.alien3RunnerV88.alive=false;scenes.push(snapshot(e,'07_final_side','Plateforme finale · 2D','Finale cadrée en vue latérale pour préserver précision et lisibilité.'));
}
const out=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..','qa_visual','capture-states-v98.json');fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify({schema:98,generatedAt:new Date().toISOString(),source:'runtime mixins V88→V98',scenes},null,2));console.log(out);
