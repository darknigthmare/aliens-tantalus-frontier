#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(process.argv[2] || process.cwd());
const patchRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DRY_RUN = process.argv.includes('--dry-run');
const NO_BUILD = process.argv.includes('--no-build');
const FORCE = process.argv.includes('--force');
const versions = ['v88', 'v89', 'v90', 'v91', 'v92', 'v93', 'v94', 'v95', 'v96'];
const baseFiles = [
  'src/special-operations-v67.js',
  'src/mission-levels-v52.js',
  'src/game-v52-level-runtime.js',
  'src/game-production-runtime.js',
  'src/app.js',
  'src/audio-assets-v77.js'
];
const runtimeFiles = versions.flatMap((version) => [
  `src/alien3-dlc-${version}.js`,
  `src/alien3-dlc-runtime-${version}.js`
]);

const sha256 = (buffer) => crypto.createHash('sha256').update(buffer).digest('hex');
const exists = (relative) => fs.existsSync(path.join(root, relative));
const read = (relative) => fs.readFileSync(path.join(root, relative));
const remove = (relative, options = {}) => fs.rmSync(path.join(root, relative), { force: true, ...options });

function cleanupInjectedPrivateArtifacts() {
  for (const version of versions) {
    remove(`.alien3-dlc-${version}-backup`, { recursive: true });
    remove(`ALIEN3_DLC_${version.toUpperCase()}_INSTALL_REPORT.json`);
    remove(`docs/ALIEN3_DLC_${version.toUpperCase()}.md`);
    remove(`scripts/test-alien3-dlc-${version}.mjs`);
    remove(`scripts/test-alien3-physical-${version}.mjs`);
    remove(`scripts/uninstall-alien3-dlc-${version}.mjs`);
  }
  const docsDir = path.join(root, 'docs');
  if (fs.existsSync(docsDir) && fs.readdirSync(docsDir).length === 0) fs.rmdirSync(docsDir);
}

function assertProductionSurface() {
  const failures = [];
  for (const relative of runtimeFiles) if (!exists(relative)) failures.push(`runtime absent: ${relative}`);
  for (const version of versions) {
    for (const relative of [
      `.alien3-dlc-${version}-backup`,
      `ALIEN3_DLC_${version.toUpperCase()}_INSTALL_REPORT.json`,
      `docs/ALIEN3_DLC_${version.toUpperCase()}.md`,
      `scripts/test-alien3-dlc-${version}.mjs`,
      `scripts/test-alien3-physical-${version}.mjs`,
      `scripts/uninstall-alien3-dlc-${version}.mjs`
    ]) if (exists(relative)) failures.push(`artefact privé restant: ${relative}`);
  }
  return failures;
}

function runCommand(command, args) {
  const result = spawnSync(command, args, { cwd: root, encoding: 'utf8', stdio: 'pipe' });
  if (result.stdout) process.stdout.write(result.stdout);
  if (result.stderr) process.stderr.write(result.stderr);
  return result;
}

function restoreSnapshot(snapshot, audioManifest, audioManifestExisted) {
  for (const [relative, bytes] of Object.entries(snapshot)) {
    const target = path.join(root, relative);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, bytes);
  }
  for (const relative of runtimeFiles) remove(relative);
  cleanupInjectedPrivateArtifacts();
  const manifest = path.join(root, 'assets/audio/manifest.json');
  if (audioManifestExisted) {
    fs.mkdirSync(path.dirname(manifest), { recursive: true });
    fs.writeFileSync(manifest, audioManifest);
  } else {
    fs.rmSync(manifest, { force: true });
  }
  fs.rmSync(path.join(root, 'dist'), { recursive: true, force: true });
}

function main() {
  for (const relative of baseFiles) if (!exists(relative)) throw new Error(`Fichier de base absent: ${relative}`);
  if (!exists('package.json') && !NO_BUILD && !DRY_RUN) throw new Error('package.json absent : impossible de lancer les contrôles production.');

  const snapshot = Object.fromEntries(baseFiles.map((relative) => [relative, read(relative)]));
  const manifestPath = 'assets/audio/manifest.json';
  const audioManifestExisted = exists(manifestPath);
  const audioManifest = audioManifestExisted ? read(manifestPath) : null;
  const before = Object.fromEntries(Object.entries(snapshot).map(([relative, bytes]) => [relative, sha256(bytes)]));

  if (DRY_RUN) {
    console.log(JSON.stringify({
      schema: 96,
      productionSafe: true,
      dryRun: true,
      root,
      cumulativeVersions: versions.map((version) => version.toUpperCase()),
      baseFiles,
      runtimeFiles,
      checks: NO_BUILD ? [] : ['npm run check', 'npm run build']
    }, null, 2));
    return;
  }

  const installer = path.join(patchRoot, 'scripts', 'install-alien3-dlc-v96.mjs');
  const args = [installer, root];
  if (FORCE) args.push('--force');
  const install = spawnSync(process.execPath, args, { cwd: root, encoding: 'utf8', stdio: 'pipe' });
  if (install.stdout) process.stdout.write(install.stdout);
  if (install.stderr) process.stderr.write(install.stderr);
  if (install.status !== 0) throw new Error('Installation cumulative V96 refusée avant la phase production.');

  try {
    cleanupInjectedPrivateArtifacts();
    const surfaceFailures = assertProductionSurface();
    if (surfaceFailures.length) throw new Error(surfaceFailures.join('; '));

    if (!NO_BUILD) {
      const check = runCommand(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['run', 'check']);
      if (check.status !== 0) throw new Error(`npm run check a échoué (code ${check.status}).`);
      const build = runCommand(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['run', 'build']);
      if (build.status !== 0) throw new Error(`npm run build a échoué (code ${build.status}).`);
    }

    const after = Object.fromEntries(baseFiles.map((relative) => [relative, sha256(read(relative))]));
    console.log(JSON.stringify({
      ok: true,
      schema: 96,
      productionSafe: true,
      cumulativeVersions: versions.map((version) => version.toUpperCase()),
      checksRun: NO_BUILD ? [] : ['npm run check', 'npm run build'],
      baseFiles: baseFiles.map((relative) => ({ file: relative, beforeSha256: before[relative], afterSha256: after[relative] })),
      runtimeFiles: runtimeFiles.map((relative) => ({ file: relative, sha256: sha256(read(relative)) })),
      privateArtifactsRemaining: 0
    }, null, 2));
  } catch (error) {
    restoreSnapshot(snapshot, audioManifest, audioManifestExisted);
    throw new Error(`${error.message} Restauration pré-DLC effectuée.`);
  }
}

try { main(); }
catch (error) {
  console.error('[ALIEN3 V96 PRODUCTION] Échec:', error.message);
  process.exitCode = 1;
}
