import assert from 'node:assert/strict';
import { ALIEN3_CAMPAIGN_ID_V88 } from '../src/alien3-dlc-v88.js';
import { withAlien3DlcRuntimeV88 } from '../src/alien3-dlc-runtime-v88.js';
import { withAlien3DlcRuntimeV89 } from '../src/alien3-dlc-runtime-v89.js';
import { withAlien3DlcRuntimeV90 } from '../src/alien3-dlc-runtime-v90.js';
import { withAlien3DlcRuntimeV91 } from '../src/alien3-dlc-runtime-v91.js';
import { withAlien3DlcRuntimeV92 } from '../src/alien3-dlc-runtime-v92.js';
import { withAlien3DlcRuntimeV93 } from '../src/alien3-dlc-runtime-v93.js';
import {
  ALIEN3_CODEX_V94,
  ALIEN3_FIDELITY_BEATS_V94,
  ALIEN3_FIORINA_TEMPLATE_V94,
  ALIEN3_RECONSTRUCTION_PROFILES_V94,
  ALIEN3_V94_EVIDENCE_IDS,
  ALIEN3_V94_STATIONS,
  alien3V94Grade,
  validateAlien3DlcV94
} from '../src/alien3-dlc-v94.js';
import { withAlien3DlcRuntimeV94 } from '../src/alien3-dlc-runtime-v94.js';

class MockBase {
  constructor() {
    this.events = [];
    this.images = new Map();
    this.enemies = [];
    this.doors = [];
    this.platforms = [
      { id: 'ground', x: 0, y: 510, w: 6200 },
      { id: 'deep', x: 0, y: 630, w: 6200 },
      { id: 'high', x: 0, y: 330, w: 6200 },
      { id: 'perch', x: 0, y: 190, w: 6200 }
    ];
    this.player = { id: 'player', x: 180, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, actionClock: 0, fireClock: 0, vx: 0, vy: 0, facing: 1, crouching: false };
    this.coop = { id: 'coop', x: 120, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, vx: 0, vy: 0 };
    this.vehicle = { active: true, occupied: false, driver: null, passengers: [], x: 3200 };
    this.weaponPickup = { taken: false, x: 900 };
    this.toolPickup = { taken: false, x: 1200 };
    this.supplies = [];
    this.objectiveNodes = [];
    this.archiveTerminal = { recovered: false, x: 1500 };
    this.powerNode = { active: false, x: 1800 };
    this.objective = { x: 6000, y: 420, w: 68, h: 90, complete: false };
    this.missionLevelRuntime = { anchors: { extraction: { x: 6040, y: 510 } } };
    this.missionLevelVisualState = { activeZoneId: 'f161-coast' };
    this.mission = { state: 'active', objectives: { power: false, route: false, boss: false, archive: false, extract: false }, rewards: {}, retries: 0, elapsed: 0, casualties: 0 };
    this.inventory = { salvage: 0, intel: 0 };
    this.audio = { ui() {}, alarm() {}, hit() {} };
    this.camera = { x: 0, y: 0 };
    this.animationTime = 0;
    this.onEvent = (event) => this.events.push(event);
  }
  start(options = {}) { this.campaign = options.campaign; this.strategicBriefing = options.strategicBriefing; return { base: true }; }
  createEnemy(profile, index, x, groundY, options = {}) {
    return { ...profile, id: profile.id || `enemy-${index}`, x, y: groundY - 90, w: 90, h: 90, health: profile.health || 100, maxHealth: profile.health || 100, speed: profile.speed || 1, damage: profile.damage || 10, alive: true, facing: -1, alert: false, staggerClock: 0, hurtClock: 0, ...options };
  }
  initializeEnemyMissionNavigation() {}
  interact() { return false; }
  fire() { return false; }
  reload() { return true; }
  toggleVehicle() { return true; }
  useEquipment() { return true; }
  activateTracker() { return false; }
  applyEnemyDamage(enemy, amount) { enemy.health = Math.max(0, enemy.health - amount); if (enemy.health <= 0) enemy.alive = false; return amount; }
  updateEnemy() {}
  drawEnemy() {}
  defeatEnemy(enemy) { enemy.alive = false; enemy.health = 0; return true; }
  damagePlayer(actor, amount) { actor.health = Math.max(0, actor.health - amount); actor.damageTaken += amount; if (actor.health <= 0) actor.alive = false; return amount; }
  update(delta = 0.016) { this.animationTime += delta; return true; }
  missingObjectiveRequirement() { return ''; }
  missingExtractionRequirement() { return ''; }
  completeMission() { this.mission.state = 'complete'; this.mission.rewards = { credits: 100 }; this.onEvent({ type: 'mission-complete', rewards: this.mission.rewards }); return true; }
  restartFromCheckpoint() { this.mission.state = 'active'; return true; }
  phaseLabel() { return 'BASE'; }
  objectiveProgressText() { return 'BASE'; }
  getInteractionPrompt() { return ''; }
  drawWorld() {}
  drawHud() {}
  captureResumeState() { return { schema: 1, player: { x: this.player.x, y: this.player.y } }; }
  applyResumeState() { return { applied: true, restored: 1 }; }
  getGameplayReport() { return { base: true }; }
  getSnapshot() { return { base: true }; }
  locked(requirement) { this.events.push({ type: 'locked', requirement }); return false; }
}

const V88 = withAlien3DlcRuntimeV88(MockBase);
const V89 = withAlien3DlcRuntimeV89(V88);
const V90 = withAlien3DlcRuntimeV90(V89);
const V91 = withAlien3DlcRuntimeV91(V90);
const V92 = withAlien3DlcRuntimeV92(V91);
const V93 = withAlien3DlcRuntimeV93(V92);
const Engine = withAlien3DlcRuntimeV94(V93);

const validation = validateAlien3DlcV94();
assert.equal(validation.ok, true, validation.failures.join('; '));
assert.equal(validation.counts.nodes, 62);
assert.equal(validation.counts.edges, 102);
assert.equal(ALIEN3_FIORINA_TEMPLATE_V94.routes.length, 4);
assert.equal(ALIEN3_CODEX_V94.length, 18);
assert.equal(ALIEN3_V94_EVIDENCE_IDS.length, 18);
assert.equal(ALIEN3_FIDELITY_BEATS_V94.length, 6);
assert.equal(ALIEN3_V94_STATIONS.length, 11);
assert.equal(ALIEN3_RECONSTRUCTION_PROFILES_V94.length, 3);

const engine = new Engine();
engine.start({
  campaign: { id: ALIEN3_CAMPAIGN_ID_V88 },
  strategicBriefing: { flags: { 'alien3-v90-challenge': 'archive' } },
  enemyCatalog: [{ id: 'enemy-006-runner', name: 'Runner Fiorina', biology: 'xenomorph', caste: 'runner', health: 720, damage: 29, speed: 1.9 }]
});

const moveToStation = (id) => {
  const station = engine.alien3StationV94(id);
  assert.ok(station, id);
  engine.player.x = station.x;
  engine.player.y = station.y;
  return station;
};

// Profile Workprint proxies the Assembly cut before the EEV archive locks.
moveToStation('f161-profile-workprint-v94');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V94.profile.id, 'workprint');
assert.equal(engine.alien3V89.cut, 'assembly');
assert.equal(engine.alien3V94.evidenceRecovered.includes('profile-selected'), true);

// Non-graphic wreckage confrontation keeps the mission active and resolves by movement.
engine.alien3V88.phase = 'infirmary';
engine.player.x = 810; engine.player.y = 540;
engine.updateAlien3WreckageConfrontationV94(0.1);
assert.equal(engine.alien3V94.fidelity.wreckageStarted, true);
engine.player.x = 1060;
engine.updateAlien3WreckageConfrontationV94(0.1);
assert.equal(engine.alien3V94.fidelity.wreckageResolved, true);
assert.equal(engine.mission.state, 'active');

// Flight recorder -> Bishop cross-check is causal.
engine.alien3V88.crashRecorderRead = true;
moveToStation('f161-flight-analysis-console-v94');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V94.fidelity.flightRecorderAnalyzed, true);
engine.alien3V88.bishopRecovered = true;
engine.updateAlien3ForensicsV94();
assert.equal(engine.alien3V94.fidelity.forensicsComplete, true);
assert.equal(engine.alien3V94.evidenceRecovered.includes('flight-recorder-chain'), true);

// Faith raises social cohesion but does not rewrite historical deaths.
engine.alien3V88.phase = 'bishop';
moveToStation('f161-faith-record-v94');
const faithBefore = engine.alien3V94.social.faith;
assert.equal(engine.interact(engine.player), true);
assert.ok(engine.alien3V94.social.faith > faithBefore);
assert.equal(engine.alien3V94.evidenceRecovered.includes('prison-faith'), true);

// Battery Duty blocks the igniter on Workprint until both cells are connected.
engine.alien3V88.phase = 'trap-prep';
engine.alien3V88.fireMazeArmed = true;
const igniter = engine.alien3StationsV88.find((entry) => entry.kind === 'igniter');
assert.ok(igniter);
engine.player.x = igniter.x; engine.player.y = igniter.y;
assert.equal(engine.interact(engine.player), false);
assert.ok(engine.events.some((event) => event.type === 'locked' && /BATTERY DUTY/.test(event.requirement || '')));

for (const id of ['f161-battery-cell-a-v94', 'f161-battery-cell-b-v94', 'f161-battery-junction-v94']) {
  moveToStation(id);
  assert.equal(engine.interact(engine.player), true, id);
}
assert.equal(engine.alien3V94.batteryDuty.complete, true);
assert.equal(engine.alien3V94.evidenceRecovered.includes('battery-duty'), true);

// Workprint Golic cache.
moveToStation('f161-golic-cache-console-v94');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V94.fidelity.golicCacheFound, true);

// Runner red trace is a non-blocking overlay and last-stand evidence can be earned.
engine.alien3V88.phase = 'leadworks';
engine.alien3V88.runner.active = true;
engine.alien3RunnerV88.alive = true;
engine.player.x = 4700; engine.player.y = 420;
engine.alien3RunnerV88.x = 4780; engine.alien3RunnerV88.y = 420;
engine.updateAlien3RunnerPovV94(0.1);
assert.ok(engine.alien3V94.chase.runnerPovPulses >= 1);
assert.equal(engine.alien3V94.evidenceRecovered.includes('runner-pov'), true);
assert.equal(engine.alien3V94.evidenceRecovered.includes('ripley-last-stand'), true);

// Three reroutes make the final chase genuinely improvised.
for (let i = 0; i < 3; i += 1) {
  moveToStation('f161-chase-reroute-console-v94');
  assert.equal(engine.interact(engine.player), true);
}
assert.equal(engine.alien3V94.chase.reroutes, 3);
assert.equal(engine.alien3V94.chase.improvised, true);

// Workprint-specific archival beats arrive from the inherited causal chain.
engine.alien3V91.companyDirective.messageSent = true;
engine.alien3V89.assembly.golicReleased = true;
engine.alien3V88.runnerDefeated = true;
engine.alien3V93.company.parleyResolved = true;
engine.alien3V88.phase = 'finale';
engine.alien3V93.company.witnessConfirmed = true;
engine.updateAlien3WorkprintV94();
for (const id of ['workprint-company-message', 'workprint-golic-release', 'manual-sprinklers', 'company-camera-block', 'finale-order']) {
  assert.equal(engine.alien3V94.evidenceRecovered.includes(id), true, id);
}

// Final transmission is a physical extra step before the legacy finale.
moveToStation('f161-final-transmission-console-v94');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V94.fidelity.finalTransmission, true);

// Inherited perfect archive + V94 conditions unlock S+++++.
engine.alien3V93.archivePerfect.perfect = true;
engine.alien3V94.social.trustRipley = Math.max(65, engine.alien3V94.social.trustRipley);
engine.updateAlien3SocialV94(0.1);
engine.updateAlien3PerfectV94();
assert.equal(engine.alien3V94.perfectArchive.perfect, true);
assert.equal(engine.alien3V94.evidenceRecovered.length, ALIEN3_V94_EVIDENCE_IDS.length);
assert.equal(engine.alien3V94.codexUnlocked.length, ALIEN3_CODEX_V94.length);
assert.equal(engine.alien3V94.fidelity.beatCount, ALIEN3_FIDELITY_BEATS_V94.length);

const grade = alien3V94Grade({
  gradeV93: 'S++++',
  evidence: ALIEN3_V94_EVIDENCE_IDS.length,
  fidelityBeats: ALIEN3_FIDELITY_BEATS_V94.length,
  batteryComplete: true,
  forensicsComplete: true,
  social: 80,
  perfect: true
});
assert.equal(grade, 'S+++++');

// Resume state preserves Fidelity / Workprint state.
const saved = engine.captureResumeState();
assert.equal(saved.specialOperation.alien3V94.schema, 94);
const resumed = new Engine();
resumed.start({
  campaign: { id: ALIEN3_CAMPAIGN_ID_V88 },
  strategicBriefing: { flags: {} },
  enemyCatalog: [{ id: 'enemy-006-runner', name: 'Runner Fiorina', biology: 'xenomorph', caste: 'runner', health: 720, damage: 29, speed: 1.9 }]
});
const restored = resumed.applyResumeState(saved);
assert.equal(restored.applied, true);
assert.equal(restored.alien3DlcRestoredV94, true);
assert.equal(resumed.alien3V94.profile.id, 'workprint');
assert.equal(resumed.alien3V94.evidenceRecovered.length, ALIEN3_V94_EVIDENCE_IDS.length);
assert.equal(resumed.alien3V94.perfectArchive.perfect, true);
assert.equal(resumed.alien3V94.chase.reroutes, 3);

console.log(JSON.stringify({
  ok: true,
  validation,
  profile: engine.alien3V94.profile,
  evidenceRecovered: engine.alien3V94.evidenceRecovered.length,
  codexUnlocked: engine.alien3V94.codexUnlocked.length,
  fidelityBeats: engine.alien3V94.fidelity.beatCount,
  forensicsComplete: engine.alien3V94.fidelity.forensicsComplete,
  batteryDuty: engine.alien3V94.batteryDuty,
  social: engine.alien3V94.social,
  chase: {
    reroutes: engine.alien3V94.chase.reroutes,
    runnerPovPulses: engine.alien3V94.chase.runnerPovPulses,
    improvised: engine.alien3V94.chase.improvised
  },
  workprintBeats: engine.alien3V94.telemetry.workprintBeats,
  perfectArchive: engine.alien3V94.perfectArchive,
  grade,
  resume: {
    restored: restored.alien3DlcRestoredV94,
    profile: resumed.alien3V94.profile.id,
    evidence: resumed.alien3V94.evidenceRecovered.length
  }
}, null, 2));
