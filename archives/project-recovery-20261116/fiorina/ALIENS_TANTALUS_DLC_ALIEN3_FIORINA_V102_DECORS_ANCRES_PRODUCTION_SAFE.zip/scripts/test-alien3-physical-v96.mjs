import assert from 'node:assert/strict';
import {
  ALIEN3_FIORINA_TEMPLATE_V96,
  ALIEN3_V96_STATIONS,
  validateAlien3DlcV96
} from '../src/alien3-dlc-v96.js';

const validation = validateAlien3DlcV96();
assert.equal(validation.ok, true, validation.failures.join('; '));

const nodes = ALIEN3_FIORINA_TEMPLATE_V96.nodes;
const edges = ALIEN3_FIORINA_TEMPLATE_V96.edges;
const routes = ALIEN3_FIORINA_TEMPLATE_V96.routes;
const nodeMap = new Map(nodes.map((entry) => [entry.id, entry]));
const platforms = nodes.map((entry) => ({ id: `node-${entry.id}`, x: entry.x - entry.width / 2, y: entry.y, w: entry.width, nodeId: entry.id }));
const connectors = [];

for (const edge of edges) {
  const from = nodeMap.get(edge.from);
  const to = nodeMap.get(edge.to);
  assert.ok(from && to, `${edge.id} missing endpoint`);
  if (['walk', 'slope', 'airlock', 'gate'].includes(edge.kind)) {
    const span = Math.hypot(to.x - from.x, to.y - from.y);
    const steps = Math.max(1, Math.ceil(span / 210), Math.ceil(Math.abs(to.y - from.y) / 10));
    const stepWidth = edge.kind === 'slope' ? Math.min(240, Math.abs(to.x - from.x) / steps + 8) : 240;
    for (let step = 1; step < steps; step += 1) {
      const progress = step / steps;
      platforms.push({ id: `${edge.id}-step-${step}`, x: from.x + (to.x - from.x) * progress - stepWidth / 2, y: from.y + (to.y - from.y) * progress, w: stepWidth, edgeId: edge.id });
    }
    if (edge.kind === 'walk') assert.ok(Math.abs(from.y - to.y) <= 72, `${edge.id} hides inaccessible verticality`);
  }
  if (edge.kind === 'ladder' || edge.kind === 'lift') {
    const connectorX = Number.isFinite(edge.connectorOffsetFromTo) ? to.x + edge.connectorOffsetFromTo : (from.x + to.x) / 2;
    const padding = 34;
    for (const endpoint of [from, to]) {
      if (Math.abs(endpoint.x - connectorX) <= endpoint.width / 2 - 24) continue;
      platforms.push({ id: `${edge.id}-${endpoint.id}-approach`, x: Math.min(endpoint.x, connectorX) - padding, y: endpoint.y, w: Math.abs(endpoint.x - connectorX) + padding * 2, edgeId: edge.id });
    }
    connectors.push({ id: edge.id, x: connectorX, top: Math.min(from.y, to.y), bottom: Math.max(from.y, to.y) });
    assert.ok(Math.abs(from.y - to.y) >= 48, `${edge.id} meaningless vertical span`);
  }
}

const supports = (x, y, tolerance = 58) => platforms.some((platform) => (
  Math.abs(Number(platform.y) - y) <= tolerance
  && x >= Number(platform.x) - tolerance
  && x <= Number(platform.x) + Number(platform.w) + tolerance
));

for (const connector of connectors) {
  assert.ok(supports(connector.x, connector.top, 30), `${connector.id} top unsupported`);
  assert.ok(supports(connector.x, connector.bottom, 30), `${connector.id} bottom unsupported`);
}
for (const station of ALIEN3_V96_STATIONS) {
  const footY = station.y + station.h;
  const centerX = station.x + station.w / 2;
  assert.ok(supports(centerX, footY, 58), `${station.id} has no physical support`);
}

const degree = new Map(nodes.map((node) => [node.id, 0]));
const adjacency = new Map(nodes.map((node) => [node.id, []]));
for (const edge of edges) {
  degree.set(edge.from, degree.get(edge.from) + 1);
  degree.set(edge.to, degree.get(edge.to) + 1);
  adjacency.get(edge.from).push(edge.to);
  if (!edge.oneWay) adjacency.get(edge.to).push(edge.from);
}
for (const node of nodes) assert.ok(degree.get(node.id) > 0, `${node.id} orphan`);

const spawnId = nodes.find((node) => node.anchor === 'spawn')?.id;
const extractionId = nodes.find((node) => node.anchor === 'extraction')?.id;
assert.ok(spawnId && extractionId, 'spawn/extraction anchors required');
const reached = new Set([spawnId]);
const queue = [spawnId];
while (queue.length) {
  const current = queue.shift();
  for (const next of adjacency.get(current) || []) {
    if (reached.has(next)) continue;
    reached.add(next);
    queue.push(next);
  }
}
assert.equal(reached.size, nodes.length, `physical graph disconnected: ${reached.size}/${nodes.length}`);
assert.ok(reached.has(extractionId), 'extraction not reachable');

for (const route of routes) {
  assert.equal(route.nodeIds[0], spawnId, `${route.id} does not start at spawn`);
  assert.equal(route.nodeIds.at(-1), extractionId, `${route.id} does not end at extraction`);
  for (let index = 1; index < route.nodeIds.length; index += 1) {
    const from = route.nodeIds[index - 1];
    const to = route.nodeIds[index];
    assert.ok(edges.some((edge) => (edge.from === from && edge.to === to) || (!edge.oneWay && edge.from === to && edge.to === from)), `${route.id} broken at ${from}>${to}`);
  }
}

assert.equal(new Set(ALIEN3_V96_STATIONS.map((entry) => entry.id)).size, ALIEN3_V96_STATIONS.length, 'duplicate station ids');

console.log(JSON.stringify({
  ok: true,
  nodes: nodes.length,
  edges: edges.length,
  routes: routes.length,
  connectedNodes: reached.size,
  connectors: connectors.length,
  platforms: platforms.length,
  stations: ALIEN3_V96_STATIONS.length,
  allStationsSupported: true,
  orphanNodes: 0,
  extractionReachable: true
}, null, 2));
