import assert from 'node:assert/strict';
import { ALIEN3_CAMPAIGN_ID_V88 } from '../src/alien3-dlc-v88.js';
import { withAlien3DlcRuntimeV88 } from '../src/alien3-dlc-runtime-v88.js';
import { withAlien3DlcRuntimeV89 } from '../src/alien3-dlc-runtime-v89.js';
import {
  ALIEN3_CODEX_V90,
  ALIEN3_FIRE_MANIFOLDS_V90,
  ALIEN3_FIORINA_TEMPLATE_V90,
  ALIEN3_V90_EVIDENCE_IDS,
  validateAlien3DlcV90
} from '../src/alien3-dlc-v90.js';
import { withAlien3DlcRuntimeV90 } from '../src/alien3-dlc-runtime-v90.js';

class MockBase {
  constructor() {
    this.events = [];
    this.images = new Map();
    this.enemies = [];
    this.doors = [];
    this.platforms = [
      { id: 'ground', x: 0, y: 510, w: 6200 },
      { id: 'deep', x: 2800, y: 630, w: 1900 },
      { id: 'high', x: 1000, y: 330, w: 5000 }
    ];
    this.player = { id: 'player', x: 180, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, actionClock: 0, fireClock: 0, vx: 0, vy: 0, facing: 1, crouching: false };
    this.coop = { id: 'coop', x: 120, y: 420, w: 44, h: 90, alive: true, health: 100, armor: 0, kills: 0, damageTaken: 0, vx: 0, vy: 0 };
    this.vehicle = { active: true, occupied: true, driver: this.player, passengers: [this.coop], x: 3200 };
    this.weaponPickup = { taken: false, x: 900 };
    this.toolPickup = { taken: false, x: 1200 };
    this.supplies = [{ type: 'ammo', amount: 24 }, { type: 'medkit', amount: 1 }];
    this.objectiveNodes = [{ id: 'generic-node' }];
    this.archiveTerminal = { recovered: false, x: 1500 };
    this.powerNode = { active: false, x: 1800 };
    this.objective = { x: 6000, y: 420, w: 68, h: 90, complete: false };
    this.missionLevelRuntime = { anchors: { extraction: { x: 6040, y: 510 } } };
    this.missionLevelVisualState = { activeZoneId: 'f161-coast' };
    this.mission = { state: 'active', objectives: { power: false, route: false, boss: false, archive: false, extract: false }, rewards: {}, retries: 0, elapsed: 100, casualties: 0 };
    this.inventory = { salvage: 0, intel: 0 };
    this.audio = { ui() {}, alarm() {}, hit() {} };
    this.camera = { x: 0, y: 0 };
    this.animationTime = 0;
    this.onEvent = (event) => this.events.push(event);
  }
  start(options = {}) { this.campaign = options.campaign; this.strategicBriefing = options.strategicBriefing; return { base: true }; }
  createEnemy(profile, index, x, groundY, options = {}) {
    return {
      ...profile, id: profile.id || `enemy-${index}`, x, y: groundY - 90, w: 90, h: 90,
      health: profile.health || 100, maxHealth: profile.health || 100, speed: profile.speed || 1,
      damage: profile.damage || 10, alive: true, facing: -1, alert: false, staggerClock: 0, hurtClock: 0, ...options
    };
  }
  initializeEnemyMissionNavigation() {}
  interact() { return false; }
  fire() { return false; }
  reload() { return true; }
  toggleVehicle() { return true; }
  useEquipment() { return true; }
  activateTracker() { return false; }
  applyEnemyDamage(enemy, amount) { enemy.health = Math.max(0, enemy.health - amount); if (enemy.health <= 0) enemy.alive = false; return amount; }
  updateEnemy() {}
  drawEnemy() {}
  defeatEnemy(enemy) { enemy.alive = false; enemy.health = 0; return true; }
  damagePlayer(actor, amount) { actor.health = Math.max(0, actor.health - amount); actor.damageTaken += amount; if (actor.health <= 0) actor.alive = false; return amount; }
  update(delta = 0.016) { this.animationTime += delta; return true; }
  missingObjectiveRequirement() { return ''; }
  missingExtractionRequirement() { return ''; }
  completeMission() { this.mission.state = 'complete'; this.mission.rewards = { credits: 100, salvage: 2, intel: 1 }; this.onEvent({ type: 'mission-complete', kills: 0, rewards: this.mission.rewards }); return true; }
  restartFromCheckpoint() { this.mission.state = 'active'; return true; }
  phaseLabel() { return 'BASE'; }
  objectiveProgressText() { return 'BASE'; }
  getInteractionPrompt() { return ''; }
  drawWorld() {}
  drawHud() {}
  captureResumeState() { return { schema: 1, player: { x: this.player.x, y: this.player.y } }; }
  applyResumeState() { return { applied: true, restored: 1 }; }
  getGameplayReport() { return { base: true }; }
  getSnapshot() { return { base: true }; }
  locked(requirement) { this.events.push({ type: 'locked', requirement }); return false; }
}

const V88 = withAlien3DlcRuntimeV88(MockBase);
const V89 = withAlien3DlcRuntimeV89(V88);
const Engine = withAlien3DlcRuntimeV90(V89);

const validation = validateAlien3DlcV90();
assert.equal(validation.ok, true, validation.failures.join('; '));
assert.equal(ALIEN3_FIORINA_TEMPLATE_V90.routes.length, 4);
assert.equal(validation.counts.nodes, 30);
assert.equal(validation.counts.edges, 44);
assert.equal(ALIEN3_CODEX_V90.length, 10);
assert.equal(ALIEN3_FIRE_MANIFOLDS_V90.length, 4);

const makeEngine = (challengeId = 'archive') => {
  const engine = new Engine();
  engine.start({
    campaign: { id: ALIEN3_CAMPAIGN_ID_V88 },
    strategicBriefing: { flags: { 'alien3-v90-challenge': challengeId } },
    enemyCatalog: [{ id: 'enemy-006-runner', name: 'Runner', biology: 'xenomorph', caste: 'runner', health: 720, damage: 29, speed: 1.9 }]
  });
  return engine;
};
const moveToV88 = (engine, stationId) => {
  const station = engine.alien3StationV88(stationId);
  assert.ok(station, stationId);
  engine.player.x = station.x;
  engine.player.y = station.y;
  return station;
};
const moveToV89 = (engine, stationId) => {
  const station = engine.alien3StationV89(stationId);
  assert.ok(station, stationId);
  engine.player.x = station.x;
  engine.player.y = station.y;
  return station;
};
const moveToV90 = (engine, stationId) => {
  const station = engine.alien3StationV90(stationId);
  assert.ok(station, stationId);
  engine.player.x = station.x;
  engine.player.y = station.y;
  return station;
};
const advance = (engine, seconds, step = 0.1) => {
  let remaining = seconds;
  while (remaining > 0) {
    const delta = Math.min(step, remaining);
    engine.update(delta);
    remaining -= delta;
  }
};

const engine = makeEngine();
assert.equal(engine.alien3V90.challengeId, 'archive');
assert.equal(engine.alien3V90.presentation.cardKind, 'chapter');

// Challenge terminal is optional and can cycle back to the standard archive before lock.
moveToV90(engine, 'f161-mire-challenge-terminal');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V90.challengeId, 'mire-purist');
assert.equal(engine.fire(engine.player), false);
assert.match(engine.events.at(-1).requirement, /FLARES DÉSACTIVÉS/);
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V90.challengeId, 'fury-nightmare');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V90.challengeId, 'archive');
assert.equal(engine.alien3V90.evidenceRecovered.includes('mire-challenge'), true);

// Assembly remains selectable and locks when the reconstruction starts.
moveToV89(engine, 'f161-cut-assembly-terminal');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V89.cut, 'assembly');
moveToV88(engine, 'f161-eev-recorder');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'infirmary');
assert.equal(engine.alien3V90.challengeLocked, true);

// Autopsy advances the story but V90 deliberately defers the queen diagnosis.
moveToV88(engine, 'f161-autopsy');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'first-blood');
assert.equal(engine.alien3V88.codexUnlocked.includes('queen-embryo'), false);
assert.equal(engine.alien3V90.diagnosis.queenCodexDeferred, true);

// Preserve the V89 sparing beat, but it only becomes explainable after the later scan.
engine.player.health = 15;
engine.damagePlayer(engine.player, 40, { source: engine.alien3RunnerV88.name });
assert.equal(engine.player.alive, true);
assert.equal(engine.player.health, 8);
assert.equal(engine.alien3V89.director.sparingUsed, true);
advance(engine, 2.6);
engine.player.x = 2800;
engine.update(0.1);
assert.equal(engine.alien3V88.phase, 'bishop');
moveToV88(engine, 'f161-bishop-memory');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'trap-prep');
moveToV89(engine, 'f161-prison-register');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V89.evidenceRecovered.includes('prison-roster'), true);

// The old three caches are no longer enough: four physical fuel manifolds must also be armed.
for (const id of ['f161-cache-infirmary', 'f161-cache-cellblock', 'f161-cache-service']) {
  moveToV88(engine, id);
  assert.equal(engine.interact(engine.player), true, id);
}
moveToV88(engine, 'f161-fire-igniter');
assert.equal(engine.interact(engine.player), false);
assert.equal(engine.alien3V88.phase, 'trap-prep');
assert.match(engine.events.at(-1).requirement, /MANIFOLDS QUINITRICETYLINE 0\/4/);

for (const id of ['f161-fuel-a', 'f161-fuel-b', 'f161-fuel-c', 'f161-fuel-d']) {
  moveToV90(engine, id);
  assert.equal(engine.interact(engine.player), true, id);
}
assert.equal(engine.alien3V90.firePlan.prepared, true);
assert.equal(engine.alien3V90.stats.manifoldsArmed, 4);
assert.equal(engine.alien3V90.codexUnlocked.includes('f161-quinitricetyline'), true);

// Ignition now propagates physically and ends in an authored accident instead of an instant phase skip.
moveToV88(engine, 'f161-fire-igniter');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'fire-maze');
assert.equal(engine.alien3V90.firePlan.ignited, true);
engine.player.x = 2500;
engine.player.y = 420;
advance(engine, 3.4);
assert.equal(engine.alien3V90.firePlan.accidentResolved, true);
assert.equal(engine.alien3V90.firePlan.activeSegments.length, 6);
assert.equal(engine.alien3V90.diagnosis.scanAvailable, true);
assert.equal(engine.alien3V90.evidenceRecovered.includes('fire-accident'), true);

// Reaching the foundry early is refused until Ripley has returned to the EEV medical scanner.
engine.player.x = 4440;
engine.update(0.1);
assert.equal(engine.alien3V88.phase, 'fire-maze');
assert.equal(engine.getInteractionPrompt(engine.player), 'RETOURNER À L’EEV · SCANNER MÉDICAL');
moveToV90(engine, 'f161-eev-medical-scanner');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V90.diagnosis.scanComplete, true);
assert.equal(engine.alien3V88.codexUnlocked.includes('queen-embryo'), true);
assert.equal(engine.alien3V90.evidenceRecovered.includes('royal-host-signal'), true);

// Assembly Cut still requires the waste-tank capture/release before leadworks.
const waste = moveToV89(engine, 'f161-waste-tank-control');
engine.alien3RunnerV88.x = waste.x + 25;
engine.alien3RunnerV88.y = waste.y;
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V89.assembly.wasteTankTrapped, true);
advance(engine, 4.8);
assert.equal(engine.alien3V89.assembly.golicReleased, true);
engine.player.x = 4440;
engine.update(0.1);
assert.equal(engine.alien3V88.phase, 'leadworks');

// V90 sensory layer learns repeated zone traversal and rewards quiet crouched movement while the Runner is still active.
engine.missionLevelVisualState.activeZoneId = 'f161-furnace';
engine.player.crouching = true;
engine.player.vx = 20;
advance(engine, 1.0);
engine.missionLevelVisualState.activeZoneId = 'f161-leadworks'; advance(engine, 0.2);
engine.missionLevelVisualState.activeZoneId = 'f161-furnace'; advance(engine, 0.2);
engine.missionLevelVisualState.activeZoneId = 'f161-leadworks'; advance(engine, 0.2);
engine.missionLevelVisualState.activeZoneId = 'f161-furnace'; advance(engine, 0.2);
assert.ok(engine.alien3V90.sensory.routeMemory['f161-furnace'] >= 3);
assert.ok(engine.alien3V90.stats.routeRepetitions >= 1);
assert.ok(engine.alien3V90.stats.stealthSeconds > 0);
engine.player.crouching = false;
engine.player.vx = 0;

// Foundry setup is causal: mold interaction is blocked until lead and water are both prepared.
const mold = moveToV88(engine, 'f161-mold-control');
engine.alien3RunnerV88.x = mold.x + 40;
engine.alien3RunnerV88.y = mold.y;
assert.equal(engine.interact(engine.player), false);
assert.match(engine.events.at(-1).requirement, /PRÉPARER LA CUVE DE PLOMB/);
moveToV90(engine, 'f161-lead-vat-primer');
assert.equal(engine.interact(engine.player), true);
moveToV90(engine, 'f161-water-header-control');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V90.leadworks.moldReady, true);
assert.equal(engine.alien3V90.leadworks.dillonCommitted, true);
assert.equal(engine.alien3V90.leadworks.morseAtLeadControl, true);

moveToV88(engine, 'f161-mold-control');
engine.alien3RunnerV88.x = engine.player.x + 30;
engine.alien3RunnerV88.y = engine.player.y;
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'molten-lead');
moveToV88(engine, 'f161-sprinkler-control');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.runnerDefeated, true);
advance(engine, 1.4);
assert.equal(engine.alien3V88.phase, 'company');

// Finish through the existing V89 multi-stage company/finale path.
moveToV89(engine, 'f161-patna-manifest');
assert.equal(engine.interact(engine.player), true);
moveToV88(engine, 'f161-company-contact');
assert.equal(engine.interact(engine.player), true);
assert.equal(engine.alien3V88.phase, 'finale');
moveToV89(engine, 'f161-morse-witness-log');
assert.equal(engine.interact(engine.player), true);
moveToV88(engine, 'f161-final-ledge');
assert.equal(engine.interact(engine.player), true);
advance(engine, 3.5);
assert.equal(engine.mission.state, 'complete');
assert.equal(engine.mission.rewards.alien3V90, true);
assert.ok(['S+', 'S', 'A', 'B', 'C', 'D'].includes(engine.mission.rewards.mireGradeV90));
assert.equal(engine.mission.rewards.medicalScanConfirmed, true);
assert.equal(engine.mission.rewards.leadworksPrepared, true);
assert.equal(engine.alien3V90.evidenceRecovered.length, ALIEN3_V90_EVIDENCE_IDS.length);
assert.equal(engine.alien3V90.codexUnlocked.length, ALIEN3_CODEX_V90.length);

// Save/resume preserves the new fire, diagnosis, sensory and foundry state.
const saved = engine.captureResumeState();
assert.equal(saved.specialOperation.alien3V90.schema, 90);
const resumed = makeEngine();
const resumeResult = resumed.applyResumeState(saved);
assert.equal(resumeResult.applied, true);
assert.equal(resumed.alien3V90.firePlan.accidentResolved, true);
assert.equal(resumed.alien3V90.diagnosis.scanComplete, true);
assert.equal(resumed.alien3V90.leadworks.moldReady, true);
assert.equal(resumed.alien3V90.evidenceRecovered.length, ALIEN3_V90_EVIDENCE_IDS.length);

// Purist challenge remains a separate optional replay rule and does not alter the archive chronology.
const purist = makeEngine('mire-purist');
purist.alien3V88.flares = 4;
assert.equal(purist.fire(purist.player), false);
assert.equal(purist.alien3V88.flares, 4);
assert.equal(purist.alien3V90.challengeId, 'mire-purist');

console.log(JSON.stringify({
  ok: true,
  validation,
  challenge: engine.alien3V90.challengeId,
  evidenceRecovered: engine.alien3V90.evidenceRecovered.length,
  evidenceTotal: ALIEN3_V90_EVIDENCE_IDS.length,
  codexUnlocked: engine.alien3V90.codexUnlocked.length,
  firePlan: engine.alien3V90.firePlan,
  diagnosis: engine.alien3V90.diagnosis,
  leadworks: engine.alien3V90.leadworks,
  sensory: engine.alien3V90.sensory,
  prisonerPlan: engine.alien3V90.prisonerPlan,
  rewards: engine.mission.rewards,
  eventCount: engine.events.length
}, null, 2));
