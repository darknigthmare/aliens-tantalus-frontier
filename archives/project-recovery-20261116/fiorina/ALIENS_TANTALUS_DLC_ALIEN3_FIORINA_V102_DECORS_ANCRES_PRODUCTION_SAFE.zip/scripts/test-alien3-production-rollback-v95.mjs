import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const patchRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const fixture = fs.mkdtempSync(path.join(os.tmpdir(), 'alien3-v95-install-'));
const sha = (buffer) => crypto.createHash('sha256').update(buffer).digest('hex');
const write = (relative, content) => {
  const target = path.join(fixture, relative);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, content);
};
const read = (relative) => fs.readFileSync(path.join(fixture, relative));

write('src/special-operations-v67.js', `const VALID_STATUSES = new Set(['effective', 'partial', 'missing']);\nexport const SPECIAL_OPERATIONS_V67 = Object.freeze([\n  freezeOperation({\n    id: 'cargo-brutal',\n    promisedTitle: 'CARGO BRUTAL'\n  })\n]);\nexport function validateSpecialOperationsV67(operations = SPECIAL_OPERATIONS_V67) {\n  const failures = [];\n  if (operations.length !== 19) failures.push(\`operations: \${operations.length} != 19\`);\n  return { failures };\n}\n`);
write('src/mission-levels-v52.js', `import { buildCetoHabitatsV75, cetoHabitatHazardsV75 } from './enemy-ceto-v75.js';\nexport const MISSION_TEMPLATE_IDS_V52 = Object.freeze([\n  'ship-interior-vertical',\n  'colony-multiroute',\n  'planet-exterior'\n]);\nconst TEMPLATE_PALETTES = Object.freeze({\n  base: true\n});\nconst SHIP_TEMPLATE = { id: 'ship-interior-vertical' };\nexport const MISSION_LEVEL_TEMPLATES_V52 = Object.freeze({\n  [SHIP_TEMPLATE.id]: SHIP_TEMPLATE,\n});\n`);
write('src/game-v52-level-runtime.js', `export const MISSION_LEVEL_LAYER_FILES_V52 = Object.freeze({\n  base: true\n});\n`);
write('src/game-production-runtime.js', `import { withPlaceablesRuntimeV86 } from './placeables-runtime-v86.js';\nconst V70ProductionEngine = class {};\nconst V86ProductionEngine = withPlaceablesRuntimeV86(V70ProductionEngine);\nexport class GameEngine extends V86ProductionEngine { }\n`);

const app = [
  "<span>${escapeHtml(world?.name || 'Frontier')}</span><span>${escapeHtml(campaign.objective)}</span>",
  "<footer><span>${campaign ? escapeHtml(world?.name || 'Frontier') : hubSurface ? 'USS TANTALUS · HUB PHYSIQUE' : 'REGISTRE DES OPÉRATIONS'}</span>",
  "<h3>${escapeHtml(campaign.name)}</h3><p>${escapeHtml(campaign.objective)} · ${escapeHtml(world.name)}</p>${specialNotice}",
  "  const specialNoticeCopy = specialOperation?.id === 'cargo-brutal'\n",
  "  const worldState = saveSystem.data.galaxy.worldState[world.id];\n  const before = absoluteHours(saveSystem.data.clock);",
  `  const crew = operationLoadout.crew;\n  const weapon = operationLoadout.weapon || WEAPONS[0];\n  const equipment = operationLoadout.equipment;\n  const specialOperation = getSpecialOperationByCampaignIdV67(campaign.id);\n  const vehicle = specialOperation?.issuedVehicleId\n    ? VEHICLES.find((entry) => entry.id === specialOperation.issuedVehicleId) || operationLoadout.vehicle\n    : operationLoadout.vehicle;\n  const costume = operationLoadout.costume;`,
  "    world: { ...world, ...worldState },\n    levelSeeds: LEVEL_SEEDS,",
  "  byId('mission-log').textContent = `MU/TH/UR · ${campaign.objective.toUpperCase()} · ${world.name} · ${missionLevel.templateLabel.toUpperCase()} · RISQUE ${deployment.operation.risk}%`;",
  "    campaign, world, worldState, levelSeed, missionLevel,\n    weapon, equipment, crew, vehicle, costume, deployment, operationLoadout\n  });",
  `const alienSurvivalEventLabelV70 = (event) => {\n  const detail = event.message || event.reason || event.circuitId || event.feedId\n    || event.doorId || event.stationId || event.type.replace('alien-survival-', '');\n  const remaining = Number(event.remainingSeconds ?? event.remaining);\n  const countdown = Number.isFinite(remaining) ? \` · T−\${Math.max(0, Math.ceil(remaining))} S\` : '';\n  return \`SURVIE · \${String(detail || 'SYSTÈMES ACTUALISÉS').toUpperCase()}\${countdown}\`;\n};\n`,
  `  if (isAlienSurvivalRuntimeEventV70(event)) {\n    alienSurvivalDockV70?.refresh();\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alienSurvivalEventLabelV70(event);\n  }\n`,
  `  const survivalPersistenceDue = ALIEN_SURVIVAL_PERSISTENT_EVENTS_V70.has(event.type)\n    && (event.type !== 'alien-survival-self-destruct-tick'\n      || Math.max(0, Math.ceil(Number(event.remainingSeconds ?? event.remaining) || 0)) % 5 === 0);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue) && saveSystem.data.strategy.currentOperation) {`
].join('\n/* fixture boundary */\n');
write('src/app.js', app);

const baseFiles = [
  'src/special-operations-v67.js',
  'src/mission-levels-v52.js',
  'src/game-v52-level-runtime.js',
  'src/game-production-runtime.js',
  'src/app.js'
];
const before = Object.fromEntries(baseFiles.map((relative) => [relative, sha(read(relative))]));

const exists = (relative) => fs.existsSync(path.join(fixture, relative));
write('package.json', JSON.stringify({ type:'module', scripts:{ check:"node -e \"process.exit(7)\"", build:"node -e \"process.exit(0)\"" } }, null, 2));
const productionInstaller = path.join(patchRoot, 'scripts', 'install-alien3-dlc-v95-production.mjs');
const run = spawnSync(process.execPath, [productionInstaller, fixture], { encoding: 'utf8' });
assert.notEqual(run.status, 0, 'build failure fixture unexpectedly passed');
assert.match(run.stderr, /Restauration pré-DLC effectuée/);
for (const relative of baseFiles) assert.equal(sha(read(relative)), before[relative], `${relative} rollback mismatch`);
for (const version of ['v88','v89','v90','v91','v92','v93','v94','v95']) {
  assert.equal(exists(`src/alien3-dlc-${version}.js`), false);
  assert.equal(exists(`src/alien3-dlc-runtime-${version}.js`), false);
  assert.equal(exists(`.alien3-dlc-${version}-backup`), false);
  assert.equal(exists(`ALIEN3_DLC_${version.toUpperCase()}_INSTALL_REPORT.json`), false);
}
assert.equal(exists('dist'), false);
console.log(JSON.stringify({ ok:true, forcedBuildFailure:true, rollbackBitPerfect:true, runtimeResidue:0 }, null, 2));
fs.rmSync(fixture, { recursive: true, force: true });
