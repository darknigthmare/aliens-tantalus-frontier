#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(process.argv[2] || process.cwd());
const patchRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXPECTED_BASE = '496996f5ea557d970ec625aa346876f3eaed1c5f';
const BACKUP_DIR = path.join(root, '.alien3-dlc-v91-backup');
const DRY_RUN = process.argv.includes('--dry-run');
const FORCE = process.argv.includes('--force');
const rel = (...parts) => path.join(...parts);

const targets = [
  rel('src', 'special-operations-v67.js'),
  rel('src', 'mission-levels-v52.js'),
  rel('src', 'game-production-runtime.js'),
  rel('src', 'app.js')
];
const additions = [
  rel('src', 'alien3-dlc-v91.js'),
  rel('src', 'alien3-dlc-runtime-v91.js'),
  rel('scripts', 'test-alien3-dlc-v91.mjs'),
  rel('scripts', 'test-alien3-physical-v91.mjs'),
  rel('scripts', 'uninstall-alien3-dlc-v91.mjs'),
  rel('docs', 'ALIEN3_DLC_V91.md')
];

function sha256(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function read(relative) {
  const file = path.join(root, relative);
  if (!fs.existsSync(file)) throw new Error(`Fichier requis absent: ${relative}`);
  return fs.readFileSync(file, 'utf8');
}
function replaceOnce(source, needle, replacement, label) {
  const first = source.indexOf(needle);
  if (first < 0) throw new Error(`Ancre introuvable (${label}). Le projet n'est pas dans l'état V90 attendu.`);
  if (source.indexOf(needle, first + needle.length) >= 0) throw new Error(`Ancre ambiguë (${label}). Installation arrêtée.`);
  return source.slice(0, first) + replacement + source.slice(first + needle.length);
}
function insertAfter(source, needle, addition, label) { return replaceOnce(source, needle, needle + addition, label); }
function gitHead() {
  const head = path.join(root, '.git', 'HEAD');
  if (!fs.existsSync(head)) return null;
  const value = fs.readFileSync(head, 'utf8').trim();
  if (!value.startsWith('ref: ')) return value;
  const ref = path.join(root, '.git', value.slice(5));
  return fs.existsSync(ref) ? fs.readFileSync(ref, 'utf8').trim() : null;
}
function ensureV90() {
  const installed = fs.existsSync(path.join(root, 'src', 'alien3-dlc-v90.js'))
    && fs.existsSync(path.join(root, 'src', 'alien3-dlc-runtime-v90.js'));
  if (installed) return { alreadyInstalled: true, installedNow: false };
  if (DRY_RUN) return { alreadyInstalled: false, installedNow: false, wouldInstall: true };
  const installer = path.join(patchRoot, 'scripts', 'install-alien3-dlc-v90.mjs');
  if (!fs.existsSync(installer)) throw new Error('Base V90 absente du pack V91.');
  const args = [installer, root];
  if (FORCE) args.push('--force');
  const result = spawnSync(process.execPath, args, { stdio: 'inherit' });
  if (result.status !== 0) throw new Error('Installation automatique de la base V90 impossible.');
  return { alreadyInstalled: false, installedNow: true };
}

function patchSpecialOperations(source) {
  source = replaceOnce(
    source,
    "promiseSummary: 'Reconstruction MIRE V90 de Fiorina 161 : montages cinéma/Assembly, Runner adaptatif au bruit, plan au quinitricetyline physiquement préparé, retour EEV pour diagnostic royal, détenus affectés aux sections, fonderie plomb/eau causale, Patna et finale différenciée.',",
    "promiseSummary: 'Reconstruction MIRE V91 de Fiorina 161 : archive vivante des pertes de la prison, chaîne Assembly confinement→directive Compagnie→Golic, Runner prédictif, trois pistons de rabattement, cage Patna, Bishop II/Aaron/Morse et fonderie intégrale.',",
    'résumé V91'
  );
  source = replaceOnce(
    source,
    "requiredMechanics: ['single-runner-predator', 'adaptive-noise-director', 'no-firearms', 'persistent-flare-lures', 'fiorina-prison-metroidvania', 'four-route-topology', 'physical-quinitricetyline-plan', 'fire-propagation', 'post-fire-eev-scan', 'theatrical-assembly-cuts', 'waste-tank-containment', 'named-prisoner-tasking', 'causal-lead-water-prep', 'molten-lead-trap', 'thermal-shock-finale', 'patna-company-sequence', 'mire-codex-35', 'replay-challenges', 'isolated-archive-loadout']",
    "requiredMechanics: ['single-runner-predator', 'predictive-runner-heatmap', 'no-firearms', 'persistent-flare-lures', 'fiorina-prison-metroidvania', 'four-route-topology', 'living-historical-beats', 'physical-quinitricetyline-plan', 'fire-propagation', 'post-fire-eev-scan', 'theatrical-assembly-cuts', 'waste-tank-containment', 'company-directive-before-golic-release', 'named-prisoner-tasking', 'three-piston-foundry-chase', 'causal-lead-water-prep', 'molten-lead-trap', 'thermal-shock-finale', 'patna-cage-and-company-sequence', 'bishop-two-aaron-morse-finale', 'mire-codex-48', 'replay-challenges', 'isolated-archive-loadout']",
    'mécaniques V91'
  );
  return source;
}

function patchMissionLevels(source) {
  source = replaceOnce(
    source,
    "import { ALIEN3_FIORINA_PALETTE_V90, ALIEN3_FIORINA_TEMPLATE_V90 } from './alien3-dlc-v90.js';\n",
    "import { ALIEN3_FIORINA_PALETTE_V91, ALIEN3_FIORINA_TEMPLATE_V91 } from './alien3-dlc-v91.js';\n",
    'import template V91'
  );
  source = replaceOnce(source, '[ALIEN3_FIORINA_TEMPLATE_V90.id]: ALIEN3_FIORINA_PALETTE_V90,', '[ALIEN3_FIORINA_TEMPLATE_V91.id]: ALIEN3_FIORINA_PALETTE_V91,', 'palette V91');
  source = replaceOnce(source, '[ALIEN3_FIORINA_TEMPLATE_V90.id]: ALIEN3_FIORINA_TEMPLATE_V90,', '[ALIEN3_FIORINA_TEMPLATE_V91.id]: ALIEN3_FIORINA_TEMPLATE_V91,', 'template V91');
  return source;
}

function patchProductionRuntime(source) {
  source = insertAfter(
    source,
    "import { withAlien3DlcRuntimeV90 } from './alien3-dlc-runtime-v90.js';\n",
    "import { withAlien3DlcRuntimeV91 } from './alien3-dlc-runtime-v91.js';\n",
    'import runtime V91'
  );
  source = replaceOnce(
    source,
    'const V90ProductionEngine = withAlien3DlcRuntimeV90(V89ProductionEngine);\n',
    'const V90ProductionEngine = withAlien3DlcRuntimeV90(V89ProductionEngine);\nconst V91ProductionEngine = withAlien3DlcRuntimeV91(V90ProductionEngine);\n',
    'chaîne moteur V91'
  );
  source = replaceOnce(source, 'export class GameEngine extends V90ProductionEngine {', 'export class GameEngine extends V91ProductionEngine {', 'moteur final V91');
  return source;
}

function patchApp(source) {
  source = replaceOnce(
    source,
    "    ? 'Chronique MIRE V90 solo · 4 routes · feu au quinitricetyline préparé physiquement · retour EEV pour diagnostic · Runner adaptatif au bruit · prisonniers affectés · plomb/eau causaux · cinéma/Assembly · 35 dossiers MIRE.'",
    "    ? 'Chronique MIRE V91 solo · 4 routes densifiées · 48 dossiers · pertes historiques physiques · Runner prédictif · chaîne Assembly causale · 3 pistons de rabattement · cage Patna · Bishop II/Aaron/Morse.'",
    'notice opération V91'
  );
  const helperAnchor = `const isAlien3V90RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v90-');\nconst alien3V90EventLabel = (event) => {\n  const detail = event.title || event.action || event.evidenceId || event.challengeId || event.manifoldId || event.type.replace('alien3-v90-', '');\n  return \`MIRE 161 V90 · \${String(detail || 'RECONSTRUCTION ACTUALISÉE').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  const helper = `const isAlien3V91RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v91-');\nconst alien3V91EventLabel = (event) => {\n  const detail = event.title || event.action || event.evidenceId || event.pistonId || event.anchorId || event.type.replace('alien3-v91-', '');\n  return \`MIRE 161 V91 · \${String(detail || 'ARCHIVE VIVANTE').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  source = insertAfter(source, helperAnchor, helper, 'helpers événements V91');

  const handleAnchor = `  if (isAlien3V90RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V90EventLabel(event);\n  }\n`;
  source = insertAfter(source, handleAnchor, `  if (isAlien3V91RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V91EventLabel(event);\n  }\n`, 'journal événements V91');

  const persistenceAnchor = `  const alien3V90PersistenceDue = isAlien3V90RuntimeEvent(event)\n    && !['alien3-v90-sensory', 'alien3-v90-presentation'].includes(event.type);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue || alien3V90PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  const persistenceReplacement = `  const alien3V90PersistenceDue = isAlien3V90RuntimeEvent(event)\n    && !['alien3-v90-sensory', 'alien3-v90-presentation'].includes(event.type);\n  const alien3V91PersistenceDue = isAlien3V91RuntimeEvent(event)\n    && event.type !== 'alien3-v91-hunter';\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue || alien3V90PersistenceDue || alien3V91PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  source = replaceOnce(source, persistenceAnchor, persistenceReplacement, 'persistance événements V91');
  return source;
}

function run() {
  if (fs.existsSync(path.join(root, 'src', 'alien3-dlc-v91.js')) && !FORCE) throw new Error('Le DLC Alien 3 V91 semble déjà installé.');
  const v90 = ensureV90();
  if (DRY_RUN && v90.wouldInstall) {
    console.log(JSON.stringify({ schema: 91, dryRun: true, prerequisite: 'V90 (and V89/V88) would be installed first', expectedBaseCommit: EXPECTED_BASE }, null, 2));
    return;
  }
  for (const relative of targets) read(relative);
  for (const relative of additions) if (!fs.existsSync(path.join(patchRoot, relative))) throw new Error(`Fichier du patch absent: ${relative}`);
  const head = gitHead();
  if (head && head !== EXPECTED_BASE && !FORCE) console.warn(`[WARN] HEAD ${head} diffère de la base auditée ${EXPECTED_BASE}; V91 vérifie les ancres V90 avant écriture.`);

  const originals = Object.fromEntries(targets.map((relative) => [relative, read(relative)]));
  const patched = {
    [rel('src', 'special-operations-v67.js')]: patchSpecialOperations(originals[rel('src', 'special-operations-v67.js')]),
    [rel('src', 'mission-levels-v52.js')]: patchMissionLevels(originals[rel('src', 'mission-levels-v52.js')]),
    [rel('src', 'game-production-runtime.js')]: patchProductionRuntime(originals[rel('src', 'game-production-runtime.js')]),
    [rel('src', 'app.js')]: patchApp(originals[rel('src', 'app.js')])
  };
  const report = {
    schema: 91,
    name: 'Alien 3 — Fiorina 161 DLC V91',
    expectedBaseCommit: EXPECTED_BASE,
    detectedHead: head,
    v90InstalledByThisRun: v90.installedNow,
    dryRun: DRY_RUN,
    modified: Object.entries(patched).map(([relative, content]) => ({ file: relative, beforeSha256: sha256(originals[relative]), afterSha256: sha256(content), beforeBytes: Buffer.byteLength(originals[relative]), afterBytes: Buffer.byteLength(content) })),
    added: additions.map((relative) => ({ file: relative, sha256: sha256(fs.readFileSync(path.join(patchRoot, relative))) }))
  };
  if (DRY_RUN) { console.log(JSON.stringify(report, null, 2)); return; }

  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  try {
    for (const [relative, content] of Object.entries(originals)) {
      const backup = path.join(BACKUP_DIR, relative);
      fs.mkdirSync(path.dirname(backup), { recursive: true });
      fs.writeFileSync(backup, content);
    }
    for (const [relative, content] of Object.entries(patched)) fs.writeFileSync(path.join(root, relative), content);
    for (const relative of additions) {
      const target = path.join(root, relative);
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.copyFileSync(path.join(patchRoot, relative), target);
    }
    fs.writeFileSync(path.join(root, 'ALIEN3_DLC_V91_INSTALL_REPORT.json'), JSON.stringify(report, null, 2));
  } catch (error) {
    for (const [relative, content] of Object.entries(originals)) { try { fs.writeFileSync(path.join(root, relative), content); } catch {} }
    for (const relative of additions) { try { fs.rmSync(path.join(root, relative), { force: true }); } catch {} }
    throw error;
  }
  console.log('Alien 3 — Fiorina 161 V91 installé.');
  console.log('V91 est cumulatif : V88, V89 et V90 sont conservés comme couches de base.');
  console.log('Lancez : node scripts/test-alien3-dlc-v91.mjs && npm run check && npm run build');
}

try { run(); }
catch (error) { console.error('[ALIEN3 V91] Installation annulée:', error.message); process.exitCode = 1; }
