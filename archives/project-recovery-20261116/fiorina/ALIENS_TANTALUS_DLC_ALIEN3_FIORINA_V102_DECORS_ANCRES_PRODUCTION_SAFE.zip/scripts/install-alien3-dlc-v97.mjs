#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root=path.resolve(process.argv[2]||process.cwd());
const patchRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const EXPECTED_BASE='496996f5ea557d970ec625aa346876f3eaed1c5f';
const BACKUP_DIR=path.join(root,'.alien3-dlc-v97-backup');
const DRY_RUN=process.argv.includes('--dry-run'); const FORCE=process.argv.includes('--force');
const rel=(...parts)=>path.join(...parts);
const targets=[rel('src','special-operations-v67.js'),rel('src','mission-levels-v52.js'),rel('src','game-production-runtime.js'),rel('src','app.js')];
const additions=[rel('src','alien3-dlc-v97.js'),rel('src','alien3-dlc-runtime-v97.js'),rel('scripts','test-alien3-dlc-v97.mjs'),rel('scripts','test-alien3-physical-v97.mjs'),rel('scripts','uninstall-alien3-dlc-v97.mjs'),rel('docs','ALIEN3_DLC_V97.md')];
const sha256=(value)=>crypto.createHash('sha256').update(value).digest('hex');
const read=(relative)=>{const file=path.join(root,relative);if(!fs.existsSync(file))throw new Error(`Fichier requis absent: ${relative}`);return fs.readFileSync(file,'utf8');};
function replaceOnce(source,needle,replacement,label){const first=source.indexOf(needle);if(first<0)throw new Error(`Ancre introuvable (${label}). Le projet n'est pas dans l'état V96 attendu.`);if(source.indexOf(needle,first+needle.length)>=0)throw new Error(`Ancre ambiguë (${label}). Installation arrêtée.`);return source.slice(0,first)+replacement+source.slice(first+needle.length);}
function insertAfter(source,needle,addition,label){return replaceOnce(source,needle,needle+addition,label);}
function gitHead(){const head=path.join(root,'.git','HEAD');if(!fs.existsSync(head))return null;const value=fs.readFileSync(head,'utf8').trim();if(!value.startsWith('ref: '))return value;const ref=path.join(root,'.git',value.slice(5));return fs.existsSync(ref)?fs.readFileSync(ref,'utf8').trim():null;}
function ensureV96(){
  const installed=fs.existsSync(path.join(root,'src','alien3-dlc-v96.js'))&&fs.existsSync(path.join(root,'src','alien3-dlc-runtime-v96.js'));
  if(installed)return{alreadyInstalled:true,installedNow:false};
  if(DRY_RUN)return{alreadyInstalled:false,installedNow:false,wouldInstall:true};
  const installer=path.join(patchRoot,'scripts','install-alien3-dlc-v96.mjs');if(!fs.existsSync(installer))throw new Error('Base V96 absente du pack V97.');
  const args=[installer,root];if(FORCE)args.push('--force');const result=spawnSync(process.execPath,args,{stdio:'inherit'});if(result.status!==0)throw new Error('Installation automatique de la base V96 impossible.');return{alreadyInstalled:false,installedNow:true};
}
function patchSpecialOperations(source){
  source=replaceOnce(source,
    "promiseSummary: 'Reconstruction MIRE V96 Atmosphere de Fiorina 161 : six microclimats, huit cues audio optionnels avec fallback sûr, captions directionnelles du Runner, puissance/visibilité/vapeur, feedback climatique des détenus et diagnostic acoustique final.',",
    "promiseSummary: 'Reconstruction MIRE V97 Hybrid Archive de Fiorina 161 : neuf secteurs alternant vue profondeur 2.5D et 2D tension, trois plans jouables, Runner mono-acteur multi-plan et Codex Alien 3 dédié de 66 entrées.',",'résumé V97');
  source=replaceOnce(source,
    "'mire-master-archive', 'zone-atmosphere-simulation', 'optional-dlc-audio-slots', 'directional-threat-captions', 'environment-power-tradeoffs', 'prisoner-climate-feedback', 'audio-fallback-safety', 'acoustic-diagnostic-gate', 'mire-codex-130', 'replay-challenges', 'isolated-archive-loadout']",
    "'mire-master-archive', 'zone-atmosphere-simulation', 'optional-dlc-audio-slots', 'directional-threat-captions', 'environment-power-tradeoffs', 'prisoner-climate-feedback', 'audio-fallback-safety', 'acoustic-diagnostic-gate', 'mire-codex-130', 'hybrid-depth-view-9-sectors', 'three-depth-lanes', 'automatic-side-tension-transitions', 'runner-depth-lane-chase', 'dedicated-alien3-codex-66', 'replay-challenges', 'isolated-archive-loadout']",'mécaniques V97');
  return source;
}
function patchMissionLevels(source){
  source=replaceOnce(source,"import { ALIEN3_FIORINA_PALETTE_V96, ALIEN3_FIORINA_TEMPLATE_V96 } from './alien3-dlc-v96.js';\n","import { ALIEN3_FIORINA_PALETTE_V97, ALIEN3_FIORINA_TEMPLATE_V97 } from './alien3-dlc-v97.js';\n",'import template V97');
  source=replaceOnce(source,'[ALIEN3_FIORINA_TEMPLATE_V96.id]: ALIEN3_FIORINA_PALETTE_V96,','[ALIEN3_FIORINA_TEMPLATE_V97.id]: ALIEN3_FIORINA_PALETTE_V97,','palette V97');
  source=replaceOnce(source,'[ALIEN3_FIORINA_TEMPLATE_V96.id]: ALIEN3_FIORINA_TEMPLATE_V96,','[ALIEN3_FIORINA_TEMPLATE_V97.id]: ALIEN3_FIORINA_TEMPLATE_V97,','template V97');return source;
}
function patchProductionRuntime(source){
  source=insertAfter(source,"import { withAlien3DlcRuntimeV96 } from './alien3-dlc-runtime-v96.js';\n","import { withAlien3DlcRuntimeV97 } from './alien3-dlc-runtime-v97.js';\n",'import runtime V97');
  source=replaceOnce(source,'const V96ProductionEngine = withAlien3DlcRuntimeV96(V95ProductionEngine);\n','const V96ProductionEngine = withAlien3DlcRuntimeV96(V95ProductionEngine);\nconst V97ProductionEngine = withAlien3DlcRuntimeV97(V96ProductionEngine);\n','chaîne moteur V97');
  source=replaceOnce(source,'export class GameEngine extends V96ProductionEngine {','export class GameEngine extends V97ProductionEngine {','moteur final V97');return source;
}
function patchApp(source){
  source=replaceOnce(source,
    "    ? 'Chronique MIRE V96 Atmosphere solo · 4 routes / 130 dossiers · 6 microclimats · audio optionnel/fallback · captions Runner · puissance/visibilité/vapeur · diagnostic acoustique.'",
    "    ? 'Chronique MIRE V97 Hybrid Archive solo · 4 routes / 130 dossiers MIRE + Codex DLC 66 · 9 secteurs hybride profondeur/2D · 3 plans · Runner multi-plan · transitions automatiques.'",'notice opération V97');
  const helperAnchor=`const isAlien3V96RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v96-');\nconst alien3V96EventLabel = (event) => {\n  const detail = event.caption || event.title || event.action || event.evidenceId || event.cueId || event.zoneId || event.type.replace('alien3-v96-', '');\n  return \`MIRE 161 V96 · \${String(detail || 'ATMOSPHERE').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  const helper=`const isAlien3V97RuntimeEvent = (event) => typeof event?.type === 'string' && event.type.startsWith('alien3-v97-');\nconst alien3V97EventLabel = (event) => {\n  const detail = event.title || event.action || event.evidenceId || event.codexId || event.sectorId || event.type.replace('alien3-v97-', '');\n  return \`ALIEN 3 V97 · \${String(detail || 'HYBRID ARCHIVE').replaceAll('-', ' ').toUpperCase()}\`;\n};\n`;
  source=insertAfter(source,helperAnchor,helper,'helpers événements V97');
  const handleAnchor=`  if (isAlien3V96RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V96EventLabel(event);\n  }\n`;
  source=insertAfter(source,handleAnchor,`  if (isAlien3V97RuntimeEvent(event)) {\n    recordOperationFlag(saveSystem.data, event.type);\n    log.textContent = alien3V97EventLabel(event);\n  }\n`,'journal événements V97');
  const persistenceAnchor=`  const alien3V95PersistenceDue = isAlien3V95RuntimeEvent(event);\n  const alien3V96PersistenceDue = isAlien3V96RuntimeEvent(event);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue || alien3V90PersistenceDue || alien3V91PersistenceDue || alien3V92PersistenceDue || alien3V93PersistenceDue || alien3V94PersistenceDue || alien3V95PersistenceDue || alien3V96PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  const replacement=`  const alien3V95PersistenceDue = isAlien3V95RuntimeEvent(event);\n  const alien3V96PersistenceDue = isAlien3V96RuntimeEvent(event);\n  const alien3V97PersistenceDue = isAlien3V97RuntimeEvent(event);\n  if ((persistentEvents.has(event.type) || ALPHA_BRAVO_PERSISTENT_EVENTS_V69.has(event.type) || survivalPersistenceDue || alien3V89PersistenceDue || alien3V90PersistenceDue || alien3V91PersistenceDue || alien3V92PersistenceDue || alien3V93PersistenceDue || alien3V94PersistenceDue || alien3V95PersistenceDue || alien3V96PersistenceDue || alien3V97PersistenceDue) && saveSystem.data.strategy.currentOperation) {`;
  return replaceOnce(source,persistenceAnchor,replacement,'persistance événements V97');
}
function run(){
  if(fs.existsSync(path.join(root,'src','alien3-dlc-v97.js'))&&!FORCE)throw new Error('Le DLC Alien 3 V97 semble déjà installé.');
  const v96=ensureV96();if(DRY_RUN&&v96.wouldInstall){console.log(JSON.stringify({schema:97,dryRun:true,prerequisite:'V96 (and V95…V88) would be installed first',expectedBaseCommit:EXPECTED_BASE},null,2));return;}
  for(const relative of targets)read(relative);for(const relative of additions)if(!fs.existsSync(path.join(patchRoot,relative)))throw new Error(`Fichier du patch absent: ${relative}`);
  const head=gitHead();if(head&&head!==EXPECTED_BASE&&!FORCE)console.warn(`[WARN] HEAD ${head} diffère de la base auditée ${EXPECTED_BASE}; V97 vérifie les ancres V96 avant écriture.`);
  const originals=Object.fromEntries(targets.map((relative)=>[relative,read(relative)]));
  const patched={
    [rel('src','special-operations-v67.js')]:patchSpecialOperations(originals[rel('src','special-operations-v67.js')]),
    [rel('src','mission-levels-v52.js')]:patchMissionLevels(originals[rel('src','mission-levels-v52.js')]),
    [rel('src','game-production-runtime.js')]:patchProductionRuntime(originals[rel('src','game-production-runtime.js')]),
    [rel('src','app.js')]:patchApp(originals[rel('src','app.js')])
  };
  const report={schema:97,name:'Alien 3 — Fiorina 161 DLC V97 Hybrid Archive',expectedBaseCommit:EXPECTED_BASE,detectedHead:head,v96InstalledByThisRun:v96.installedNow,dryRun:DRY_RUN,
    modified:Object.entries(patched).map(([relative,content])=>({file:relative,beforeSha256:sha256(originals[relative]),afterSha256:sha256(content),beforeBytes:Buffer.byteLength(originals[relative]),afterBytes:Buffer.byteLength(content)})),
    added:additions.map((relative)=>({file:relative,sha256:sha256(fs.readFileSync(path.join(patchRoot,relative)))}))};
  if(DRY_RUN){console.log(JSON.stringify(report,null,2));return;}
  fs.mkdirSync(BACKUP_DIR,{recursive:true});
  try{
    for(const [relative,content] of Object.entries(originals)){const backup=path.join(BACKUP_DIR,relative);fs.mkdirSync(path.dirname(backup),{recursive:true});fs.writeFileSync(backup,content);}
    for(const [relative,content] of Object.entries(patched))fs.writeFileSync(path.join(root,relative),content);
    for(const relative of additions){const target=path.join(root,relative);fs.mkdirSync(path.dirname(target),{recursive:true});fs.copyFileSync(path.join(patchRoot,relative),target);}
    fs.writeFileSync(path.join(root,'ALIEN3_DLC_V97_INSTALL_REPORT.json'),JSON.stringify(report,null,2));
  }catch(error){for(const [relative,content] of Object.entries(originals)){try{fs.writeFileSync(path.join(root,relative),content);}catch{}}for(const relative of additions){try{fs.rmSync(path.join(root,relative),{force:true});}catch{}}throw error;}
  console.log('Alien 3 — Fiorina 161 V97 Hybrid Archive installé.');
  console.log('V97 est cumulatif : V88 à V96 restent les couches de base.');
  console.log('Lancez : node scripts/test-alien3-dlc-v97.mjs && node scripts/test-alien3-physical-v97.mjs && npm run check && npm run build');
}
try{run();}catch(error){console.error('[ALIEN3 V97] Installation annulée:',error.message);process.exitCode=1;}
