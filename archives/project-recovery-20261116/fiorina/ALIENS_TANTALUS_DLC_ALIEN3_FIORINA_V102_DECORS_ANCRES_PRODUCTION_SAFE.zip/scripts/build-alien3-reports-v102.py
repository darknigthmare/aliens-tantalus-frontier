#!/usr/bin/env python3
"""Build design documentation and reports from the exact shipped V102 data and captures."""
from pathlib import Path
from datetime import datetime,timezone
import json,html,hashlib,base64,subprocess,sys
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parents[1]
subprocess.run(['node',str(R/'scripts/export-alien3-design-v102.mjs')],check=True)
d=json.loads((R/'qa-v102/design-source.json').read_text()); scene=d['scene']; t=d['topology'];
unit=json.loads((R/'qa-v102/unit.json').read_text()); installation=json.loads((R/'qa-v102/installation.json').read_text()); browser=json.loads((R/'qa-v102/browser.json').read_text()); regression=json.loads((R/'qa-v102/regressions.json').read_text())
E=html.escape;num=lambda x:f'{x:.2f}'.rstrip('0').rstrip('.')
labels={'pipe':'Conduite','support':'Appui','duct':'Gaine','junction':'Boîtier','fan':'Ventilateur','valve':'Vanne','gauge':'Manomètre','cable':'Faisceau','grille':'Grille','drain':'Caniveau','stencil':'Signalétique','lamp':'Luminaire','eev':'Coque EEV','cabinet':'Armoire','gurney':'Brancard','monitor':'Écran','console':'Pupitre','sink':'Évier','basin':'Lavabo','bottle':'Flacon','tray':'Plateau','cell':'Cellule','bunk':'Couchette','blanket':'Couverture','cup':'Gobelet','bowl':'Écuelle','table':'Table','bench':'Banc / établi','altar':'Autel','rack':'Rayonnage','candle':'Bougie','book':'Livre','pump':'Pompe','tank':'Réservoir','toolboard':'Panneau d’outils','case':'Mallette','barrel':'Fût','spool':'Bobine','stool':'Tabouret','crucible':'Creuset','gantry':'Portique','hoist':'Palan','ladle':'Poche de transfert','slag':'Bac à laitier','piston':'Vérin','mold':'Moule','furnace':'Four','recovery':'Cage de récupération','lampstand':'Projecteur sur pied','clamp':'Bride','winch':'Treuil'}
mount={'floor':'sol de la baie','wall':'fond de la baie','ceiling':'structure haute'}
node_by={n['id']:n for n in t['nodes']}
# This is a production design document, separate from the in-game archive.
lines=['# ALIEN 3 — FIORINA 161','## Codex de level design V102 · Ancrages et ateliers','',
'### Statut de cette édition',
'Ce document décrit les données réellement livrées dans la V102 : 30 assemblages nommés, 284 composants, 51 formes de rendu et les 72 points du graphe hérité. Un point de graphe n’est pas présenté comme une salle entièrement reconstruite. Le dessin demeure une interprétation provisoire, pas un relevé 1:1 des décors du film.',
'Le codex de conception est un document hors jeu. Il ne remplace pas les 90 entrées des archives du joueur et n’ajoute aucun score de collecte. Les versions antérieures restent dans le pack pour la reprise du travail ; les règles V102 prennent le pas sur le placement dispersé et les objectifs de quantité de la V101.',
'', '## 1. Choix de conception',
'Un lieu est identifié par son activité avant de recevoir des objets. L’EEV a une coque, des ruptures et un matériel de secours ; une baie de soin possède un brancard, de l’eau, du rangement et de la lumière ; le creuset est associé à un palan et à une poche de transfert. Des groupes lisibles remplacent une répartition uniforme de petits objets.',
'La densité n’est pas une condition de victoire. Les 284 composants ne sont pas 284 accessoires uniques : ce sont les pièces de 30 ensembles, dessinées à partir de 51 formes. Les murs, poutres et éléments lointains ne sont pas ajoutés au total pour gonfler le catalogue.',
'Le découpage caméra hybride reste hérité : neuf secteurs, cinq avec profondeur et quatre latéraux. Cette édition ne convertit pas encore tout le graphe en véritables pièces cloisonnées avec changement de plan à chaque porte. La continuité d’une pièce, son étage et ses voisins doivent rester prioritaires lors de cette future conversion.',
'', '## 2. Coordonnées, échelle et appuis',
'Le monde mesure 6200 × 720 unités de jeu. X augmente vers la droite et Y vers le bas. Le pied d’un personnage se situe à y + h. Les dimensions ci-dessous sont des unités de jeu ; elles ne mesurent ni les acteurs ni les plateaux du film.',
'Le support d’un assemblage est le point nommé du graphe, puis sa plateforme node-platform-<identifiant> dans le plan compilé. Quand un vrai plan compilé est fourni, l’audit vérifie la présence de cette surface, sa hauteur et la largeur réellement disponible. Dans le banc local, ces supports sont dérivés des plateformes des points du template : ce périmètre est signalé dans les données.',
'La largeur d’une baie est bornée par la largeur du support moins 24 unités, par le plus proche voisin au même étage moins 24 unités et par la largeur native de la recette. Le dessin ne doit donc pas devenir plus grand pour remplir un écran. Les écarts du compilateur de niveau sont appliqués aux ancrages, pas ignorés.',
'Formules : largeur = maxX(recette) × échelle ; origineX = nœud.x − largeur/2 ; composant.x = origineX + localX × échelle ; composant.y = nœud.y + localY × échelle. Pour un composant posé au sol, composant.y + composant.h = support.y, avec une tolérance numérique de 0,01 unité.',
'Le joueur, sa hauteur de saut, la caméra et la profondeur ne figurent jamais dans ces coordonnées de placement. Ils ne peuvent donc pas déplacer un brancard, une pompe ou un creuset. La caméra intervient uniquement au moment de projeter le monde à l’écran.',
'', '## 3. Séparation décor / gameplay',
'Tous les nouveaux ensembles sont dans une alcôve arrière : renderPlane = rear-recess, collision = none. Ils ne constituent pas une nouvelle couverture et ne changent pas le trajet du Runner. Le sol jouable, les verrous, les dommages, les postes interactifs et la poursuite restent ceux du runtime existant.',
'Une cellule peinte dans une baie n’est pas une porte ajoutée au graphe. Un cadran dessiné n’est pas un bouton. Le joueur reçoit une invite uniquement des véritables interactions existantes. Pour transformer un futur accessoire en objet utilisable, il faudra ajouter un contrat de collision, d’accès, d’état et de sauvegarde explicite ; la forme seule ne suffit pas.',
'Le matériel de récupération de la Compagnie est conditionnel. Les huit composants de cet ensemble sont masqués jusqu’au drapeau d’arrivée ou à une phase de conclusion compatible. Sa présence n’est jamais déduite de la seule position horizontale du joueur.',
'', '## 4. Couches, éclairage et transitions',
'Couche 0 : remplissage opaque de tout le champ depuis y = 0. Couche 1 : maçonnerie et masses lointaines à déplacement lent. Couche 2 : réseaux de plafond. Couche 3 : baies ancrées, machines et mobilier. Couche 4 : plateformes, interactions et acteurs hérités. Couche 5 : quelques conduites de premier plan qui s’effacent devant les silhouettes. Couche 6 : interface compacte.',
'Les maçonneries suivent 0,14 du déplacement horizontal et 0,08 du déplacement vertical. Les réseaux de plafond utilisent des coefficients distincts 0,28 et 0,18. Les machines et meubles suivent exactement le monde ; ils ne glissent pas sur leur support pour produire une parallaxe.',
'Le vocabulaire du fond dépend du lieu : ouvertures et intempéries côtières, niches médicales sobres, barreaux pour la détention, conduites dans les galeries, cuves et transferts dans la fonderie. Les changements de vocabulaire sont fondus sur une bande de 192 unités autour de la transition, sans remplacer brutalement tout l’écran.',
'Chaque lueur locale de la nouvelle couche est associée à un luminaire, une bougie ou un contenant chaud. Ce sont des halos 2D, pas une simulation d’éclairage physique. Le sel, l’usure, les joints, les rivets et les nervures sont des détails de formes ; ils ne doivent pas brouiller la silhouette principale.',
'Les premiers plans descendent depuis le haut mais ne forment pas une barre opaque sur le joueur. L’opacité tombe au maximum à 0,065 près d’un acteur. Les dimensions de dégagement utilisées par le test sont explicites dans foregroundOpacityV102.',
'Les effets animés de la nouvelle couche utilisent un temps de rendu nul avec le réglage de mouvement réduit. La qualité basse supprime une partie des traces de surface, pas les appuis ni les silhouettes utiles.',
'', '## 5. Interface du joueur',
'Le HUD dessiné dans le canvas est limité à trois panneaux ordinaires : lieu, état et action courante. Leur aire cumulée représente 5,70 % de 1280 × 720. Ce chiffre ne mesure pas les panneaux de l’application principale autour du canvas, non vérifiés dans le banc.',
'Les 90 entrées existantes reçoivent une nouvelle formulation destinée au joueur, sans ajouter de dossiers ni changer leurs identifiants. La recherche utilise les titres et textes affichés et respecte les conditions de découverte. Les archives occupent davantage d’espace uniquement à la demande. Le rendu d’une page ne doit pas marquer un dossier comme lu, délivrer une preuve ou modifier un score. Seule une action explicite ou le système de progression propriétaire peut faire évoluer ces états.',
'Les codes de version, identifiants de nœud, noms de tests et compteurs de développement appartiennent à ce document ou aux rapports, jamais au HUD ordinaire. Les touches indiquées doivent correspondre à des actions réellement disponibles.',
'', '## 6. Grille de contrôle et portée des preuves',
'Les contrôles automatisés garantissent des propriétés précises des données ou du code. Ils ne certifient ni la fidélité au film, ni la qualité artistique finale, ni l’absence de tous les problèmes du jeu complet. Les lignes « examen visuel » restent des validations humaines à faire écran par écran.',
'| Règle | Contrat | Contrôle |','|---|---|---|']
kindlabel={'automated':'test automatisé ciblé','browser':'contrôle dans Chromium','visual':'examen visuel, pas certification automatique','disclosure':'limite de périmètre'}
for q in d['rules']: lines.append(f"| {q['id']} | {q['text']} | {kindlabel[q['validation']]} |")
lines+=['','## 7. Fiches des neuf secteurs','']
for i,(b,s) in enumerate(zip(d['briefs'],d['sectors'])):
 groups=[g for g in scene['groups'] if g['sectorId']==s['id']]; props=[p for p in scene['props'] if p['sectorId']==s['id']]
 lines +=[f"### 7.{i+1}. {b['label']}",f"**Secteur :** `{s['id']}` · X {s['x0']} à {s['x1']} · vue {'avec profondeur' if s['mode']=='depth' else 'latérale'}. **Contenu :** {len(groups)} assemblages / {len(props)} composants.",'',f"**Composition :** {b['composition']}",f"**Logique des réseaux :** {b['networks']} Cette phrase décrit l’intention visuelle ; elle n’ajoute pas une simulation de fluides.",f"**Exclusions et pièges :** {b['exclusions']}",'', '**Assemblages rattachés à la position réelle :**']
 for g in groups:lines.append(f"- {g['label']} — `{g['nodeId']}` ; support Y {g['y']} ; X {num(g['x'])}–{num(g['x']+g['w'])} ; hauteur décorative {num(g['h'])}.")
 lines+=['','**Contrôle avant validation de ce secteur :** vérifier les extrémités du support dans le plan compilé ; contrôler la silhouette du personnage en marche et en saut ; vérifier que la baie ne suggère pas une couverture ; comparer l’état avant et après événement ; vérifier la sortie dans les deux sens de circulation. La vue du banc est une coupe multi-étages, pas une preuve de géométrie complète d’une pièce du film.','']
lines+=['## 8. Inventaire détaillé des trente assemblages','Les coordonnées suivantes sont celles du template livré. Un vrai plan compilé peut décaler les nœuds ; les coordonnées des accessoires suivent alors ces décalages automatiquement.','']
for i,g in enumerate(scene['groups']):
 n=node_by[g['nodeId']];ps=[p for p in scene['props'] if p['assemblyId']==g['id']]
 lines +=[f"### 8.{i+1}. {g['label']}",f"**Identité :** `{g['id']}` · recette `{g['recipe']}` · zone `{g['zoneId']}`.",f"**Point d’appui :** `{g['nodeId']}` à ({n['x']}, {n['y']}) ; largeur nominale {n['width']}.",f"**Baie :** X {num(g['x'])} à {num(g['x']+g['w'])} ; pied Y {g['y']} ; échelle {num(g['scale'])}. **Support :** `{g['supportId']}`.",f"**Présence :** {'uniquement après arrivée de la Compagnie' if g['condition']=='company' else 'permanente dans cette couche'}. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.",'', '| Composant | X | Y | Largeur | Hauteur | Pose |','|---|---:|---:|---:|---:|---|']
 for p in ps:lines.append(f"| {labels[p['kind']]} `{p['id'].split('/')[-1]}` | {num(p['x'])} | {num(p['y'])} | {num(p['w'])} | {num(p['h'])} | {mount[p['mount']]} |")
 lines+=['','**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.','']
lines+=['## 9. Répertoire des points du graphe','Les 72 fiches ci-dessous documentent des points de circulation ou d’action hérités. Elles ne comptabilisent pas 72 nouvelles salles. Toutes les connexions de cette section sont conservées, non créées par la décoration.','']
for i,n in enumerate(t['nodes']):
 edges=[e for e in t['edges'] if n['id'] in (e['from'],e['to'])]; gs=[g for g in scene['groups'] if g['nodeId']==n['id']]
 lines +=[f"### 9.{i+1}. {n['id']}",f"**Zone :** `{n['zoneId']}` · coordonnées ({n['x']}, {n['y']}) · largeur {n['width']} · ancre de jeu : {n.get('anchor') or 'aucune'}.", '**Décor V102 :** '+('; '.join(g['label'] for g in gs) if gs else 'pas d’assemblage supplémentaire ; passage ou respiration conservé.')]
 for e in edges:
  other=e['to'] if e['from']==n['id'] else e['from'];o=node_by[other]
  lines.append(f"- `{other}` : `{e['kind']}` · ΔX {o['x']-n['x']} · ΔY {o['y']-n['y']} · connexion `{e['id']}`.")
 lines.append('')
lines+=['## 10. Registre des 119 connexions','| Connexion | Origine | Destination | Type |','|---|---|---|---|']
for e in t['edges']:lines.append(f"| `{e['id']}` | `{e['from']}` | `{e['to']}` | {e['kind']} |")
lines +=['','## 11. Rendu, sauvegarde et intégration',
'Le renderer partagé est src/alien3-art-v102.js. Le module de données définit les recettes et les ancrages ; le mixin V102 remplace uniquement la couche décorative dispersée V101 et le HUD du canvas. Les interactions et acteurs historiques continuent d’être rendus par leurs propriétaires.',
'La décoration est reconstruite au chargement depuis les nœuds du plan. Elle n’est pas recopiée intégralement dans la sauvegarde. Seuls les secteurs visités et les réglages V102 utiles sont sérialisés ; les statistiques de dessin sont éphémères. Dix appels de rendu et dix appels de rendu des archives ont été contrôlés dans Chromium sans modification du snapshot du banc.',
'L’installateur V102 travaille d’abord dans une copie temporaire. Il valide les ancrages de code, applique l’héritage nécessaire, pose trois nouveaux modules puis corrige le contrat du registre de campagnes de 440 à 441. Il lance npm run check puis npm run build dans cette copie, sauf demande explicite --no-build. Un échec de ces commandes ne touche donc pas les fichiers du projet cible.',
'La publication locale ne porte que sur sept fichiers de liaison/registre, les 31 modules runtime nécessaires et, si généré, le manifeste audio. Les rapports, captures et le banc restent hors de la distribution du jeu. Une sauvegarde externe est écrite avant le remplacement des fichiers. La restauration refuse des sources ou un dist modifiés après installation.',
'Il s’agit d’écritures atomiques fichier par fichier, pas d’une transaction de système de fichiers résistante à toute coupure électrique. Le reçu et les copies externes sont à conserver. Aucun push GitHub ni déploiement Vercel n’a été effectué dans cette édition.',
'', '## 12. Vérifications réalisées et limites restantes',
 f"V102 : {unit['cases']} cas de données/runtime isolés, {installation['cases']} scénarios d’installation sur fixtures et {browser['tests']} contrôles dans Chromium. Héritage : {regression['passed']}/{regression['total']} scripts isolés repassent. Le détail et la portée de chaque contrôle sont fournis dans qa-v102.",
'Les dix images sont des captures natives de canvas dans Chromium. Le banc exécute les modules de rendu livrés et les mixins V101/V102 avec un contrôleur simplifié. Il ne charge pas le moteur principal, les assets massifs du dépôt ni toute la campagne. Les acteurs sont dessinés provisoirement ; leur fidélité 1:1 et leurs animations définitives ne sont pas revendiquées.',
'Le vrai npm run check / npm run build de la totalité du dépôt avec le DLC n’a pas été exécuté. Les essais positifs/négatifs de l’installateur utilisent des projets synthétiques et servent à vérifier la sécurité des écritures, pas à prouver le build de production.',
'À examiner dans le jeu complet : empilement des anciens postes interactifs avec les nouveaux ensembles, lisibilité des silhouettes définitives, débouchés de toutes les échelles, vrais volumes de couverture, raccords entre pièces, accessibilité tactile, comportement de la caméra de production et fidélité visuelle scène par scène. Ces points ne sont pas effacés par un total de tests verts.','']
md='\n'.join(lines);(R/'docs/ALIEN3_LEVEL_DESIGN_CODEX_V102.md').write_text(md)
# Interactive, self-contained design browser. No external dependencies.
style="""*{box-sizing:border-box}body{margin:0;background:#edf0e9;color:#22352a;font:15px/1.65 system-ui,sans-serif}header{background:#182b23;color:#dce5cc;padding:38px max(24px,5vw)}header h1{margin:0;font-weight:500;font-size:32px}header p{max-width:1040px}main{max-width:1400px;margin:auto;padding:30px}nav{position:sticky;top:0;background:#dfe7d9eF;padding:12px;display:flex;gap:12px;z-index:2;flex-wrap:wrap}input,select{font:inherit;padding:11px;border:1px solid #839279;border-radius:4px}input{flex:1;min-width:230px}article{background:white;border:1px solid #c8d2c0;padding:22px;margin:18px 0;border-radius:5px}h2{font-size:22px;font-weight:600}small,.muted{color:#68745d}table{width:100%;border-collapse:collapse;font-size:13px}td,th{text-align:left;padding:7px;border-bottom:1px solid #e1e6dc}code{font-size:12px;overflow-wrap:anywhere}details{margin:12px 0}summary{cursor:pointer;font-weight:600}p{margin:10px 0}svg{width:100%;background:#182b23}a{color:#526942}pre{white-space:pre-wrap;font:13px/1.6 monospace;max-height:65vh;overflow:auto}.stats{font-size:16px;color:#b9cfa8}@media(max-width:760px){main{padding:14px}header h1{font-size:25px}table{font-size:11px}td,th{padding:4px}}
"""
articles=[]
for b,s in zip(d['briefs'],d['sectors']):
 groups=[g for g in scene['groups'] if g['sectorId']==s['id']]
 articles.append(f"<article data-type='sector' data-search='{E(b['label']+' '+s['id'])}'><h2>{E(b['label'])}</h2><p>{E(b['composition'])}</p><p><b>Réseaux :</b> {E(b['networks'])}</p><p><b>À éviter :</b> {E(b['exclusions'])}</p><p class='muted'>X {s['x0']}–{s['x1']} · {len(groups)} ensembles · {'profondeur' if s['mode']=='depth' else 'latéral'}</p></article>")
for g in scene['groups']:
 ps=[p for p in scene['props'] if p['assemblyId']==g['id']]
 rows=''.join(f"<tr><td>{E(labels[p['kind']])}</td><td>{num(p['x'])}, {num(p['y'])}</td><td>{num(p['w'])} × {num(p['h'])}</td><td>{mount[p['mount']]}</td></tr>" for p in ps)
 articles.append(f"<article data-type='assembly' data-search='{E(g['label']+' '+g['id']+' '+g['nodeId']+' '+g['recipe'])}'><h2>{E(g['label'])}</h2><p><code>{g['nodeId']}</code> · appui Y {g['y']} · échelle {num(g['scale'])} · {len(ps)} composants</p><p>Fond d’alcôve ; aucune collision nouvelle. Présence : {'arrivée de la Compagnie' if g['condition']=='company' else 'permanente'}.</p><details><summary>Dimensions et pose de chaque composant</summary><table><tr><th>Forme</th><th>X, Y</th><th>L × H</th><th>Pose</th></tr>{rows}</table></details></article>")
for n in t['nodes']:
 es=[e for e in t['edges'] if n['id'] in (e['from'],e['to'])]
 links=''.join(f"<p><code>{e['to'] if e['from']==n['id'] else e['from']}</code> — {e['kind']}</p>" for e in es)
 articles.append(f"<article data-type='node' data-search='{E(n['id']+' '+n['zoneId'])}'><h2>{n['id']}</h2><p>({n['x']}, {n['y']}) · largeur {n['width']} · {n['zoneId']} · {len(es)} connexions</p><details><summary>Voisins et moyens de passage</summary>{links}</details></article>")
for q in d['rules']:articles.append(f"<article data-type='rule' data-search='{E(q['id']+' '+q['text'])}'><h2>{q['id']}</h2><p>{q['text']}</p><p class='muted'>{kindlabel[q['validation']]}</p></article>")
html_doc=f"""<!doctype html><html lang='fr'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Fiorina 161 — Codex de level design V102</title><style>{style}</style><header><h1>Fiorina 161 — Codex de level design</h1><p>V102 · Appuis, mobilier, réseaux et composition. Document de conception hors jeu. Les dimensions sont des unités de jeu, pas des mesures des plateaux du film.</p><p class='stats'>30 ensembles · 284 composants · 51 formes · 72 points de circulation · 119 connexions</p></header><main><nav><input id='q' aria-label='Rechercher dans le codex' placeholder='Chercher une pièce, une machine ou un nœud…'><select id='type' aria-label='Type de fiche'><option value=''>Toutes les fiches</option><option value='sector'>Secteurs</option><option value='assembly'>Assemblages</option><option value='node'>Points du graphe</option><option value='rule'>Règles</option></select><span id='count'></span></nav><details><summary>Lire le document complet ({len(lines)} lignes)</summary><pre>{E(md)}</pre></details><section>{''.join(articles)}</section></main><script>const q=document.querySelector('#q'),type=document.querySelector('#type'),cards=[...document.querySelectorAll('article')];function filter(){{const needle=q.value.toLocaleLowerCase('fr');let n=0;for(const c of cards){{c.hidden=!!((type.value&&c.dataset.type!==type.value)||(needle&&!c.dataset.search.toLocaleLowerCase('fr').includes(needle)));if(!c.hidden)n++;}}document.querySelector('#count').textContent=n+' fiches';}}q.oninput=filter;type.onchange=filter;filter();</script></html>"""
(R/'docs/ALIEN3_LEVEL_DESIGN_CODEX_V102.html').write_text(html_doc)
# Contact sheet composed only from original browser captures.
font_path=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf');font=ImageFont.truetype(str(font_path),20) if font_path.exists() else ImageFont.load_default()
shots=browser['screenshots'];sheet=Image.new('RGB',(1600,2470),'#101813');draw=ImageDraw.Draw(sheet);draw.text((24,20),'FIORINA 161 — V102 | Captures du banc jouable Chromium',font=font,fill='#d5dcc6')
for i,shot in enumerate(shots):
 x=(i%2)*800;y=78+(i//2)*478;img=Image.open(R/shot['file']).convert('RGB').resize((784,441));sheet.paste(img,(x+8,y));title=d['briefs'][i]['label'] if i<9 else 'Archives · recherche Runner';draw.text((x+16,y+450),title,font=font,fill='#b7c7a6')
sheet.save(R/'qa-v102/PLANCHE_CAPTURES_V102.jpg',quality=94)
# Illustrated report: exact browser PNGs embedded for offline reading.
captions=[
('Côte et EEV','La coque de l’EEV possède une silhouette propre. La prise d’air et le matériel de secours sont rattachés à leurs points de support. Le fond couvre le haut du champ.'),
('Infirmerie et morgue','Brancards, roues, armoires, écrans, lavage et luminaires distinguent les alcôves médicales. Les lits ne montent plus lorsque le joueur saute.'),
('Détention et espaces communs','Cellules, couchettes et réfectoire occupent leurs niveaux respectifs. Les baies arrière ne constituent pas de nouvelles portes utilisables.'),
('Galeries de service','Ventilateur, gaines, pompes et atelier possèdent des formes différenciées. La pluie extérieure n’est pas réutilisée comme effet intérieur.'),
('Supervision industrielle','Produits d’entretien et pupitre restent aux points réels du graphe. Les limites de caméra ne déplacent pas les fonctions de la prison.'),
('Fonderie','Creuset conique, portique, palan et transfert remplacent les blocs génériques. Les commandes historiques restent séparées du set dressing.'),
('Pistons et moule','Les vérins montrent tiges et semelles. Le moule reste bas, derrière la circulation, sans nouveau collider caché.'),
('Four principal','La bouche du four, les conduites et les baies de service différencient la zone chaude. Les halos restent associés à une source.'),
('Arrivée de la Compagnie','La cage et le matériel de récupération apparaissent conditionnellement. Le Runner du banc est masqué dans ce préréglage terminal.'),
('Archives de Fiorina','Le panneau est rendu dans le navigateur, avec recherche et navigation testées. Dessiner une page ne modifie pas la sauvegarde du banc.')]
figures=[]
for shot,(title,caption) in zip(shots,captions):
 encoded=base64.b64encode((R/shot['file']).read_bytes()).decode()
 figures.append(f"<article><h2>{E(title)}</h2><img style='width:100%;display:block' src='data:image/png;base64,{encoded}' alt='{E(title)}'><p>{E(caption)}</p><small>Capture native du banc local · 1280 × 720 · acteurs provisoires, pas le build complet.</small></article>")
summary_html=f"""<article><h2>Ce qui a réellement été livré</h2><p>30 assemblages ancrés, 284 composants, 51 formes et une couche de rendu commune au correctif et au banc. Le fond est rempli depuis y = 0 ; le HUD du canvas passe à trois panneaux couvrant 5,70 % du champ normal.</p><p>Le codex comprend neuf fiches de secteur, trente fiches d’assemblage avec dimensions, soixante-douze fiches de points et le registre des 119 connexions. Les nombres décrivent des objets de données, pas autant de nouvelles pièces jouables.</p></article><article><h2>Vérifications et périmètre</h2><table><tr><th>Contrôle</th><th>Résultat</th><th>Périmètre</th></tr><tr><td>V102 données / runtime</td><td>{unit['cases']} cas passés</td><td>Contrats isolés et mutations adverses</td></tr><tr><td>Installation / restauration</td><td>{installation['cases']} scénarios passés</td><td>Fixtures ; échecs de check/build, protection des éditions locales</td></tr><tr><td>Chromium</td><td>{browser['tests']} contrôles passés</td><td>Banc jouable, clavier, archives, redimensionnement, ancrages</td></tr><tr><td>Héritage</td><td>{regression['passed']}/{regression['total']} scripts passés</td><td>Suites historiques isolées</td></tr><tr><td>Jeu complet / déploiement</td><td>Non exécuté</td><td>Pas de build E2E, push ou déploiement V102</td></tr></table></article><article><h2>Origine des images</h2><p>Ces images proviennent de Chromium {E(browser['browser'])}, par capture native du canvas. Les modules ES livrés ont été exécutés dans le navigateur, sans redessiner leur sortie en Python. La planche est seulement un assemblage des PNG.</p><p><b>Le banc emploie un contrôleur simplifié, les mixins V101/V102 et des acteurs provisoires.</b> Il ne contient pas le moteur principal, ses gros assets ni une partie complète de la campagne. Les captures ne prouvent pas la fidélité 1:1 au film, la qualité des sprites définitifs ou la validation de toute la progression.</p><p>Date UTC : {E(browser['capturedAt'])}. Les positions de capture et les empreintes des sources sont dans qa-v102/browser.json.</p></article>"""
report=f"<!doctype html><html lang='fr'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Alien 3 · Rapport illustré V102</title><style>{style}</style><header><h1>Alien 3 — Décors ancrés</h1><p>V102 · Rapport illustré de la passe de production locale.</p><p class='stats'>10 captures Chromium · arrière-plans différenciés · ensembles fonctionnels · HUD compact</p></header><main>{summary_html}{''.join(figures)}</main></html>"
(R/'RAPPORT_ILLUSTRE_V102.html').write_text(report)
qa=f"""# Rapport QA V102 — Ancrages et ateliers

## Résultats exécutés
- Données et contrats du nouveau runtime : **{unit['cases']} cas passés**.
- Installation : **{installation['cases']} scénarios passés sur fixtures synthétiques**.
- Navigateur : **{browser['tests']} contrôles passés**, {len(shots)} captures 1280×720.
- Héritage : **{regression['passed']}/{regression['total']} scripts isolés passés**.

## Corrections constatées
- Décor lié à la hauteur du joueur dans V101 : supprimé pour la nouvelle couche.
- Vérification des appuis : nom, hauteur, largeur et présence de la plateforme compilée lorsqu’elle est fournie.
- Flottement de petits objets posés au sol : coordonnées corrigées ; tolérance ramenée à 0,01 unité.
- Fond : couverture opaque de la première rangée contrôlée pour neuf positions de caméra.
- Changement brutal de vocabulaire architectural : fondu de 192 unités, continuité testée.
- Redimensionnement du banc initialement figé à 1280×720 : corrigé et retesté en 844×390.
- Les 90 textes des archives sont reformulés ; la recherche indexe les textes affichés et ne révèle pas les pages verrouillées.
- Le rendu des archives ne modifie pas la sauvegarde.
- Matériel Compagnie : huit composants réellement masqués avant arrivée.
- Registre : le contrat source attendait 440 campagnes ; le patch ajoute une campagne. L’installateur V102 met la cible à 441, sans renuméroter le registre général.
- Échec de validation : l’installation se fait d’abord dans une copie ; le dossier cible reste inchangé.

## Mesures
- 30 assemblages / 284 composants / 51 formes / 30 supports.
- Topologie V101 inchangée : 72 points / 119 connexions / 4 routes.
- Couverture des panneaux HUD ordinaires : {unit['hudCoverage']*100:.2f} % du canvas.
- L’installateur gère 31 modules runtime et sept fichiers de base, dont content.js.

## Limites
Le navigateur a exécuté un banc local V101/V102 avec contrôleur simplifié. Il ne s’agit pas du moteur principal, ni d’un parcours complet du DLC. Aucun build complet du dépôt, push GitHub ou déploiement V102 n’a été effectué. Les succès/échecs npm de l’installation ont été simulés dans des fixtures pour tester les écritures ; ils ne prouvent pas le build du jeu.
La qualité artistique finale, la fidélité scène par scène, les véritables collisions en profondeur et l’assemblage avec tous les anciens interactifs restent à examiner dans la production complète.

## Preuves livrées
- qa-v102/unit.json
- qa-v102/installation.json
- qa-v102/browser.json
- qa-v102/regressions.json et journaux individuels
- qa-v102/design-source.json
- qa-v102/captures/
- scripts/test-alien3-dlc-v102.mjs
- scripts/test-alien3-installation-v102.mjs
- scripts/capture-alien3-v102.py
"""
(R/'RAPPORT_QA_V102.md').write_text(qa)
(R/'qa-v102/documentation.json').write_text(json.dumps({'codexLines':len(lines),'codexWords':len(md.split()),'interactiveFiches':len(articles),'sectorFiches':9,'assemblyFiches':30,'nodeFiches':72,'connectionRecords':119,'ruleFiches':18,'screenshots':len(shots)},indent=2)+'\n')
print(json.dumps({'codexLines':len(lines),'codexWords':len(md.split()),'interactiveFiches':len(articles),'reportBytes':len(report.encode())}))
