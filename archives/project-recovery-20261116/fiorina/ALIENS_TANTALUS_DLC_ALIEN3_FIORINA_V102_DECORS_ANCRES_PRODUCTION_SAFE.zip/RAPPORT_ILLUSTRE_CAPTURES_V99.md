# Rapport illustré — Alien 3: Fiorina 161 V99 Adaptive Pursuit

**Nature des captures :** captures QA runtime reproductibles 1280×720. Les états proviennent de la chaîne V88→V99 exécutée par le harness de capture. Le checkout GitHub complet et ses gros assets n’étant pas disponible dans le navigateur local, le rasteriseur remplace les assets artistiques lourds par des primitives industrielles déterministes. Ces images valident les états, poursuites, transitions caméra et interfaces V99 ; elles ne sont pas présentées comme captures du build Vercel full-assets.

## Résumé QA

- Poursuites adaptatives : **5/5**
- Coupures Runner : **5/5**
- Pression maximale observée : **93,6928 / 100**
- Ponts caméra : **9/9**
- Codex Alien 3 dédié : **90/90 débloquées et lues**
- Terminaux Codex : **7/7**
- Topologie : **72/72 nœuds · 119 connexions · 4 routes · 0 orphelin**
- Grade du run parfait : **S++++++++++**

## 01. Cour de la tempête · première chasse
Poursuite adaptative dans la cour : Runner sur un autre plan, pression dynamique et coupure annoncée.
![01. Cour de la tempête · première chasse](qa_visual/screenshots/01_storm_pursuit.png)

## 02. Bloc carcéral · coupure inter-plan
Transition de plan à 57 %, télégraphe Runner et montée de pression à 70/100.
![02. Bloc carcéral · coupure inter-plan](qa_visual/screenshots/02_cellblock_cutoff.png)

## 03. Galeries techniques · pont caméra
Transition cinématique non bloquante du volume profondeur vers la lecture 2D de tension.
![03. Galeries techniques · pont caméra](qa_visual/screenshots/03_service_camera_bridge.png)

## 04. Communications · poursuite de retour
Le Runner exploite le retour vers les communications sans créer de nouvel acteur ni de nouvelle route.
![04. Communications · poursuite de retour](qa_visual/screenshots/04_communications_chase.png)

## 05. Fonderie · pression maximale
Poursuite de fonderie à environ 94/100 : plans, occultants et coupure se combinent avec le Hunter Director.
![05. Fonderie · pression maximale](qa_visual/screenshots/05_foundry_pressure.png)

## 06. Codex Alien 3 · recherche
Codex dédié 90 entrées : recherche “Runner”, catégories et liens croisés sans mélanger les dossiers MIRE.
![06. Codex Alien 3 · recherche](qa_visual/screenshots/06_codex_search.png)

## 07. Codex Alien 3 · graphe de liens
Navigation par liens croisés et historique entre fiches liées au Runner, aux poursuites et à la profondeur.
![07. Codex Alien 3 · graphe de liens](qa_visual/screenshots/07_codex_links.png)

## 08. Patna · dernière chasse hybride
Dernier segment de chasse dans le secteur Patna avant le retour vers la finale latérale.
![08. Patna · dernière chasse hybride](qa_visual/screenshots/08_patna_shadow.png)

## Limite de capture

Les captures utilisent le même état logique/runtime V99 testé, mais pas le jeu de gros assets du checkout GitHub complet. Le rapport sépare volontairement validation gameplay/UI et fidélité visuelle full-assets.
