# Alien 3 — Fiorina 161 V93 — Rapport d’intégration production

## État de la base réelle

Dépôt audité : `darknigthmare/aliens-tantalus-frontier`  
Commit : `496996f5ea557d970ec625aa346876f3eaed1c5f`  
Projet Vercel : `aliens-tantalus-frontier`

Le déploiement production Vercel correspondant à ce commit est `READY`. Les logs de build réels indiquent :

- clone de `main` au commit `496996f` ;
- installation des dépendances ;
- exécution de `npm run build` ;
- `node scripts/build.mjs` ;
- résultat : `Built ALIENS: TANTALUS FRONTIER 86.0.0 with 3450 catalog entries.` ;
- build Vercel terminé sans erreur.

Le script `build.mjs` appelle `verifyPublicReleaseV86(root)` avant de produire `dist`, donc le contrat de distribution publique est exécuté pendant ce build réel.

## Blocage de publication depuis cette session

Trois voies d’écriture GitHub ont été testées et refusées par l’intégration avec HTTP 403 `Resource not accessible by integration` :

1. création d’une branche ;
2. création d’un blob Git isolé ;
3. création d’un fichier via l’API Contents sur la branche existante `codex/v86-public-release`.

Le conteneur local ne dispose pas non plus de résolution DNS sortante vers GitHub, donc un `git clone` direct n’est pas disponible dans cette session.

Aucune modification n’a été faite à `main`.

## Problème découvert avant intégration

Le pack QA V93 contient volontairement des docs, scripts de tests, désinstalleurs, rapports et backups locaux. Le vérificateur public V86 du projet refuse ces surfaces dans la racine d’une distribution publique :

- `docs/` est un segment privé ;
- les nouveaux scripts Alien 3 ne sont pas dans la whitelist `SCRIPT_FILES` ;
- les backups `.alien3-*` et rapports d’installation ne doivent pas être publiés.

Le ZIP QA ne doit donc pas être copié tel quel dans le dépôt.

## Correctif V93 production-safe

Nouveau script : `scripts/install-alien3-dlc-v93-production.mjs`.

Il :

1. prend un snapshot mémoire des cinq fichiers de liaison ;
2. installe cumulativement V88→V93 ;
3. retire tous les artefacts privés injectés ;
4. conserve seulement les douze modules runtime Alien 3 et les cinq fichiers de liaison modifiés ;
5. exécute `npm run check` puis `npm run build` par défaut ;
6. si un contrôle échoue, restaure les cinq fichiers bit-à-bit, supprime les douze modules, restaure `assets/audio/manifest.json` et retire `dist/`.

## QA de l’installateur production

### Surface publique

`test-alien3-production-clean-v93.mjs` : PASS

- 12/12 modules runtime conservés ;
- 0 backup `.alien3-*` ;
- 0 rapport d’installation injecté ;
- 0 doc Alien 3 injectée dans le checkout ;
- 0 script QA / désinstallation injecté dans le checkout ;
- liaisons V93 présentes dans `special-operations-v67.js`, `mission-levels-v52.js`, `game-production-runtime.js` et `app.js`.

### Rollback sur échec de build

`test-alien3-production-rollback-v93.mjs` : PASS

Un `npm run check` volontairement configuré pour échouer a été utilisé. Résultat :

- échec correctement détecté ;
- cinq fichiers de base restaurés bit-à-bit ;
- 0 module runtime Alien 3 résiduel ;
- 0 backup / rapport résiduel ;
- `dist/` supprimé.

## Limite restante

La V93 elle-même n’a pas pu être envoyée sur GitHub/Vercel depuis cette session, car la connexion GitHub est en lecture seule malgré les métadonnées de permission du dépôt. La validation finale `npm run check && npm run build` de V93 doit donc être exécutée par l’installateur production sur un checkout complet où l’écriture Git est disponible.
