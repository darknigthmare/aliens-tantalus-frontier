# Rapport QA — Alien 3 : Fiorina 161 V93

## Verdict

**PASS** — La couche V93 « Living Cast » et toutes les générations cumulatives V88→V92 passent leurs suites de non-régression. L'installation cumulative V88→V93 et la désinstallation `--full` restaurent les cinq fichiers de base vérifiés bit-à-bit.

## Runtime V93

- Validation : **True** ; échecs : **0**.
- Topologie : **54 nœuds**, **87 connexions**, **4 routes**, **6 zones**.
- Archives V93 : **14/14 preuves**, **14/14 dossiers**.
- Beats historiques : **4/4**.
- Routines : **4/4 rôles actifs** ; blessures évitables : **0**.
- Runner : style appris **sprint**, **1** passage en perchoir, **1** retour au sol, force de prédiction **35.7**.
- Finale Patna : pourparlers, cage, Aaron, Morse et témoin final tous validés.
- Archive parfaite : **True** ; grade final **S++++**.
- Sauvegarde/reprise : **True**, 14/14 preuves restaurées.

## QA physique

- Résultat : **True**.
- **54/54 nœuds connectés** ; nœuds orphelins : **0**.
- **87 connexions**, **26 connecteurs**, **136 surfaces**.
- Stations : **5**, toutes supportées : **True**.
- Perchoirs : **3**, tous supportés : **True**.
- Extraction atteignable : **True**.

## Installation cumulative

- Résultat : **True**.
- Installation cumulative : **True**.
- Chaîne installée : **V88 → V89 → V90 → V91 → V92 → V93**.
- QA runtime après installation : 54 nœuds, 87 connexions, 14/14 preuves, 14/14 dossiers, grade S++++.
- Archive parfaite après installation : **True**.
- Désinstallation complète bit-à-bit : **True**.
- Fichiers restaurés : **5/5**.

## Non-régression cumulative

| Couche | Résultat | Contrôle principal |
|---|---:|---|
| V88 | PASS | 11 phases, 13 dossiers |
| V89 | PASS | 10/10 preuves, Runner Director, Assembly Cut |
| V90 | PASS | 10/10 preuves, 4 manifolds, scan EEV, fonderie |
| V91 | PASS | 13/13 preuves, 3 pistons, Compagnie/Golic |
| V92 | PASS | 12/12 preuves, adaptation, shutters/vapeur/ordres |
| V93 | PASS | 14/14 preuves, Living Cast, perchoirs, finale Patna |

## Limites explicites

Ce rapport ne revendique pas `npm run check` ni `npm run build` sur le dépôt complet avec l'ensemble de ses assets lourds : le pack est validé par ses suites spécialisées et par l'installateur cumulatif. Le push GitHub n'est pas effectué, la création de branche par l'intégration ayant renvoyé un 403 lors de la tentative précédente.
