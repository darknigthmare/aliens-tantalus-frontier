# Rapport QA — Alien 3 : Fiorina 161 V94 Fidelity / Workprint

## Verdict

**PASS** — la couche V94 est validée sur les suites spécialisées du pack et ne casse pas les couches V88 à V93.

## Runtime V94

- Graphe : **62 nœuds / 102 connexions / 4 routes / 6 zones**.
- Continuité physique : **62/62 nœuds connectés**.
- Profils MIRE : **3** — Cinéma 1992, Assembly Cut, Workprint.
- Profil du run de référence : **Workprint**, adossé à la base Assembly.
- Dossiers V94 : **18/18**.
- Preuves V94 : **18/18**.
- Beats Fidelity : **6/6**.
- Chaîne forensique EEV ↔ Bishop : **complète**.
- Battery Duty : cellules **A + B**, jonction alimentée, **2/2 tests**, contrainte validée.
- Foi / cohésion : foi **66**, confiance Ripley **65**, discipline **64**.
- Dernier bait-and-chase : **3/3 reroutages**.
- Runner POV : **1 activation physique observée**.
- Archive parfaite V94 : **validée**.
- Grade maximal obtenu : **S+++++**.
- Sauvegarde/reprise schéma 94 : **PASS**, profil Workprint et **18 preuves** restaurés.

## Topologie physique V94

- Nœuds : **62**.
- Connexions : **102**.
- Routes : **4**.
- Connecteurs : **32**.
- Surfaces jouables analysées : **160**.
- Stations V94 : **11/11 supportées** par une surface jouable.
- Nœuds orphelins : **0**.
- Extraction atteignable : **oui**.

## Installation cumulative

Le test part d'une fixture pré-DLC et installe automatiquement :

**V88 → V89 → V90 → V91 → V92 → V93 → V94**.

Après installation :

- runtime V94 : **PASS** ;
- topologie V94 : **PASS** ;
- preuves : **18/18** ;
- dossiers : **18/18** ;
- profil : **Workprint** ;
- archive parfaite : **oui** ;
- grade : **S+++++**.

La désinstallation `--full` restaure bit-à-bit les cinq fichiers de base :

1. `src/special-operations-v67.js`
2. `src/mission-levels-v52.js`
3. `src/game-v52-level-runtime.js`
4. `src/game-production-runtime.js`
5. `src/app.js`

Résultat : **PASS**.

## Surface production

L'installateur production conserve uniquement les **14 modules runtime V88→V94** et les modifications des cinq fichiers de liaison.

- Artefacts interdits injectés : **0**.
- Surface production : **PASS**.
- Test d'échec volontaire de validation/build : **PASS**.
- Restauration bit-à-bit après échec : **PASS**.
- Résidu runtime après rollback : **0**.

## Non-régression V88 → V94

Toutes les générations passent ensemble :

- **V88 PASS** — 11 phases, 11 chapitres, 13 dossiers, 20 nœuds, 3 routes.
- **V89 PASS** — 24 nœuds, 4 routes, 2 montages, 16 détenus, 10 preuves.
- **V90 PASS** — 30 nœuds, 4 manifolds, 6 fronts de feu, 10 preuves.
- **V91 PASS** — 40 nœuds, 3 pistons, 13 preuves, grade S.
- **V92 PASS** — 48 nœuds, shutters/vapeur/ordres, 12 preuves, grade S+++.
- **V93 PASS** — 54 nœuds, perchoirs/routines/Living Cast, 14 preuves, grade S++++.
- **V94 PASS** — 62 nœuds, 3 profils Fidelity, Battery Duty, forensics, 18 preuves, grade S+++++.

## Limite explicitement non revendiquée

Le **build V94 sur un checkout GitHub complet** n'est pas marqué comme exécuté dans cette session : la connexion GitHub refuse toute écriture (403) et le conteneur local n'a pas de résolution DNS pour cloner le dépôt complet. Le build Vercel du commit de base audité est, lui, connu comme READY. L'installateur production V94 est conçu pour exécuter `npm run check` puis `npm run build` sur un vrai checkout et revenir automatiquement à l'état pré-DLC si l'une des deux commandes échoue.
