# Rapport QA — Alien 3 Fiorina 161 V101

## Objet
V101 densifie les fonds et le set dressing sans modifier la topologie certifiée V100. Le Codex de Level Design devient exécutable par le runtime.

## Résultats
- Validation V101 : PASS.
- Topologie héritée : 72 nœuds, 119 arêtes, 4 routes, 6 zones.
- Codex Level Design : 32 règles.
- Catalogue : 48 archétypes de props.
- Placement déterministe : 359 props sur 9 secteurs.
- Diversité par secteur : 5 à 7 familles.
- Répétition maximale observée : 13,5 %.
- Runtime V101 : couches far / mid / front effectivement dessinées.
- Sauvegarde/reprise schéma 101 : PASS.
- Production Safe : 28 modules runtime, 0 artefact QA public.
- Rollback forcé : bit-perfect, 0 résidu.
- Régression exécutée : 43/43 PASS.

## Densité par secteur
- Cour de la tempête : 40 props.
- EEV / infirmerie : 37.
- Bloc carcéral : 47.
- Galeries techniques : 45.
- Communications : 34.
- Grande fonderie : 46.
- Pistons / moule : 37.
- Four / Patna : 45.
- Plateforme finale : 28.

## Note visuelle
Les captures illustrées utilisent le harness QA local. Les placements, familles et règles sont ceux du runtime V101 ; les assets lourds du checkout GitHub complet étant indisponibles localement, les props sont représentés par des primitives industrielles déterministes. Le rapport ne prétend pas montrer le rendu full-assets Vercel.
