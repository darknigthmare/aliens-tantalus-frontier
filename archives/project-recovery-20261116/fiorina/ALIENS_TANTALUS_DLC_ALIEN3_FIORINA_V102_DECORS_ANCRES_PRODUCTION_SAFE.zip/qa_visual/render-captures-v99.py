import json, os, math
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path('/mnt/data/ALIEN3_DLC_v99_PATCH')
STATE_FILE = ROOT / 'qa_visual' / 'capture-states-v99.json'
OUT = ROOT / 'qa_visual' / 'screenshots'
OUT.mkdir(parents=True, exist_ok=True)
data = json.loads(STATE_FILE.read_text(encoding='utf-8'))

HTML = r'''<!doctype html><html><head><meta charset="utf-8"><style>
html,body{margin:0;width:1280px;height:720px;overflow:hidden;background:#050708;font-family:Arial,Helvetica,sans-serif}
canvas{display:block;width:1280px;height:720px}</style></head><body><canvas id="c" width="1280" height="720"></canvas>
<script>
const S=__SCENE__;
const c=document.getElementById('c'),x=c.getContext('2d');
const W=1280,H=720;
const mode=S.sector.mode;
const profile=S.v98.director.currentProfileId; const V=S.v99;
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function rr(px,py,w,h,r,fill,stroke){x.beginPath();x.roundRect(px,py,w,h,r); if(fill){x.fillStyle=fill;x.fill()} if(stroke){x.strokeStyle=stroke;x.stroke()}}
function txt(t,px,py,size=18,color='#d8e1d7',weight=500,align='left'){x.font=`${weight} ${size}px Arial`;x.textAlign=align;x.fillStyle=color;x.fillText(t,px,py)}
function line(ax,ay,bx,by,color,w=2,alpha=1){x.globalAlpha=alpha;x.beginPath();x.moveTo(ax,ay);x.lineTo(bx,by);x.strokeStyle=color;x.lineWidth=w;x.stroke();x.globalAlpha=1}
function laneVisual(lane){return [{scale:.80,y:-58,alpha:.68,label:'ARRIÈRE'},{scale:.95,y:0,alpha:.86,label:'MÉDIAN'},{scale:1.10,y:60,alpha:1,label:'AVANT'}][lane]||{scale:1,y:0,alpha:1,label:'—'}}
function localX(worldX){const mid=(S.player.x+S.runner.x)/2; return 640+(worldX-mid)*1.15}
function sky(){
 const g=x.createLinearGradient(0,0,0,H); let stops;
 if(profile.includes('storm')) stops=[['#0a1114','#172226'],['#111a1e','#06090a']];
 else if(profile.includes('foundry')||profile.includes('mold')||profile.includes('patna')||profile.includes('final')) stops=[['#17110d','#2a1b12'],['#100b08','#030405']];
 else stops=[['#081011','#111a18'],['#0b1110','#040606']];
 g.addColorStop(0,stops[0][0]);g.addColorStop(.62,stops[0][1]);g.addColorStop(1,stops[1][1]);x.fillStyle=g;x.fillRect(0,0,W,H);
}
function environment(){
 const ground=525;
 // deep background
 x.fillStyle='#0b0f0f'; for(let i=0;i<14;i++){let px=i*110-30; x.fillRect(px,160+(i%3)*18,70,ground-160);}
 if(profile.includes('storm')){
   x.fillStyle='#11191d'; for(let i=0;i<8;i++){let px=i*180-40; x.fillRect(px,330,120,210); x.fillRect(px+30,280,20,50)}
   for(let i=0;i<70;i++){let px=(i*83)%1320, py=80+(i*47)%500; line(px,py,px-26,py+60,'#75909b',1,.18)}
   line(0,525,W,525,'#65737a',3,.35);
 } else if(profile.includes('prison')){
   x.fillStyle='#101717'; for(let i=0;i<12;i++){let px=40+i*104; rr(px,260,72,250,3,'#0a0e0e','#27302e'); line(px+18,270,px+18,500,'#38433f',2,.5);line(px+52,270,px+52,500,'#38433f',2,.5)}
   line(0,525,W,525,'#63695d',4,.45);
 } else if(profile.includes('service')){
   for(let i=0;i<8;i++){let py=180+i*42; line(0,py,W,py,'#25322f',8,.7)}
   for(let i=0;i<16;i++){let px=i*90; line(px,120,px,520,'#1a2421',5,.8)}
   rr(300,330,220,140,8,'#111816','#39453f'); rr(820,310,160,160,8,'#111816','#39453f');
   line(0,525,W,525,'#505951',4,.6);
 } else if(profile.includes('communications')){
   for(let i=0;i<6;i++){rr(90+i*198,250,130,250,4,'#0d1414','#394540'); for(let j=0;j<6;j++) rr(106+i*198,274+j*32,98,14,2,j%2?'#172a24':'#1b2421')}
   line(0,525,W,525,'#59645b',4,.55);
 } else if(profile.includes('foundry')||profile.includes('mold')){
   x.fillStyle='#1a1410'; for(let i=0;i<7;i++){let px=i*200-30; x.fillRect(px,250,150,275); line(px+20,210,px+20,510,'#45372c',10,.8)}
   x.fillStyle='rgba(216,104,38,.22)';x.fillRect(0,490,W,60); for(let i=0;i<14;i++){let px=i*96; line(px,520,px+30,455,'#d66a2a',2,.35)}
   rr(515,395,250,100,16,'#130d09','#82512c');
 } else if(profile.includes('patna')){
   x.fillStyle='#18120f'; for(let i=0;i<9;i++){let px=i*150; x.fillRect(px,340,90,185)}
   rr(930,205,230,285,12,'#b2b7ae','#e6e9df'); rr(980,250,130,210,8,'#1c2625','#75837c');
   x.fillStyle='rgba(211,88,38,.25)';x.fillRect(0,500,W,45);
 } else {
   x.fillStyle='#171410'; for(let i=0;i<10;i++){let px=i*135;x.fillRect(px,300,90,225)}
   rr(470,250,340,260,8,'#15100d','#5f4937'); line(0,525,W,525,'#6a5849',4,.5);
 }
 // foreground framing
 x.fillStyle='rgba(0,0,0,.30)';x.fillRect(0,0,36,H);x.fillRect(W-36,0,36,H);
}
function lanes(){
 if(mode!=='depth') return;
 [0,1,2].forEach((l)=>{const v=laneVisual(l), base=446+v.y; line(70,base,1210,base,l===S.player.lane?'#91c7a6':'#52625b',l===S.player.lane?3:1,l===S.player.lane?.62:.28); txt(v.label,88,base-9,13,l===S.player.lane?'#b9dec6':'#6f8078',600)});
}
function drawPlayer(){
 let lane=S.player.lane;
 let visual=laneVisual(lane);
 if(S.v98.director.laneShiftActive){let b=clamp(S.v98.director.laneBlend,0,1);let f=laneVisual(S.v98.director.laneFrom),t=laneVisual(S.v98.director.laneTo);visual={scale:f.scale+(t.scale-f.scale)*b,y:f.y+(t.y-f.y)*b,alpha:.95,label:'SHIFT'};}
 let px=localX(S.player.x), py=442+visual.y, sc=visual.scale;
 x.save();x.translate(px,py);x.scale(sc,sc);x.globalAlpha=visual.alpha;
 // legs
 line(-10,25,-16,66,'#aeb8aa',10,1);line(10,25,17,66,'#aeb8aa',10,1);
 // body
 rr(-20,-42,40,70,8,'#7e8e79','#c0cab9'); rr(-14,-74,28,32,14,'#b8aa92','#d7cbb7');
 // arm + flare/light
 line(16,-25,38,-5,'#9ca88f',8,1); x.fillStyle='#c7d66f';x.fillRect(34,-8,12,5);
 x.restore();
 rr(px-42,py+72,84,22,6,'rgba(8,12,11,.78)','rgba(150,196,164,.35)');txt(`RIPLEY · P${lane+1}`,px,py+88,12,'#d7e7db',700,'center');
}
function drawRunner(){
 if(!S.runner.alive){txt('RUNNER NEUTRALISÉ',localX(S.runner.x),470,13,'#b48262',700,'center');return;}
 const v=laneVisual(S.runner.lane),px=localX(S.runner.x),py=446+v.y,sc=v.scale*1.02;
 x.save();x.translate(px,py);x.scale(sc,sc);x.globalAlpha=v.alpha;
 // quadruped silhouette
 x.fillStyle='#101313';x.strokeStyle='#56625d';x.lineWidth=2;
 x.beginPath();x.ellipse(0,-18,58,24,0,0,Math.PI*2);x.fill();x.stroke();
 x.beginPath();x.ellipse(52,-30,27,18,-.12,0,Math.PI*2);x.fill();x.stroke();
 // dome
 x.beginPath();x.ellipse(65,-39,26,11,-.12,Math.PI,Math.PI*2);x.strokeStyle='#75817c';x.stroke();
 line(-46,-8,-70,34,'#222827',8,1);line(-12,0,-28,39,'#222827',8,1);line(28,-1,17,40,'#222827',8,1);line(51,-12,66,29,'#222827',8,1);
 // tail
 x.beginPath();x.moveTo(-54,-24);x.bezierCurveTo(-95,-40,-105,-70,-132,-66);x.strokeStyle='#1e2422';x.lineWidth=8;x.stroke();
 x.restore();
 if(S.v98.director.runnerTelegraphClock>0){const tv=laneVisual(S.v98.director.runnerTelegraphTo);const ty=446+tv.y; x.save();x.setLineDash([8,7]);x.strokeStyle='rgba(212,115,74,.85)';x.lineWidth=2;x.beginPath();x.ellipse(px,ty-18,76,42,0,0,Math.PI*2);x.stroke();x.setLineDash([]);txt(`TRAVERSÉE → P${S.v98.director.runnerTelegraphTo+1}`,px,ty-68,13,'#e1a178',700,'center');x.restore();}
 rr(px-46,py+64,92,22,6,'rgba(8,12,11,.82)','rgba(120,145,134,.38)');txt(`RUNNER · P${S.runner.lane+1}`,px,py+80,12,'#cdd6cf',700,'center');
}
function occluders(){
 if(mode!=='depth') return;
 const lane=S.player.lane; const y=laneVisual(lane).y;
 if(profile.includes('prison')||profile.includes('foundry')||profile.includes('patna')){
   x.globalAlpha=.55;rr(330,395+y,130,115,4,'#161d1b','#53615a');rr(860,405-y*.3,100,105,4,'#151b19','#4d5953');x.globalAlpha=1;
 }
}
function hud(){
 rr(34,28,430,76,10,'rgba(4,8,8,.86)','rgba(99,135,117,.45)');
 txt('MIRE // FIORINA 161',56,57,14,'#91b99f',700);txt(S.sector.label,56,83,24,'#e0e5dd',800);
 rr(504,30,250,34,8,mode==='depth'?'rgba(50,91,78,.82)':'rgba(89,74,53,.82)','rgba(178,205,190,.32)');txt(mode==='depth'?'VUE PROFONDEUR 2.5D':'VUE 2D LATÉRALE',629,53,14,'#e6ece7',700,'center');
 rr(34,118,258,50,8,'rgba(4,8,8,.78)','rgba(90,120,106,.28)');txt('RIPLEY',49,141,12,'#829c8c',700);txt(`${Math.round(S.player.health)} HP`,276,143,14,'#d9e7dc',800,'right');x.fillStyle='#1d2823';x.fillRect(49,151,226,6);x.fillStyle='#8eb69a';x.fillRect(49,151,226*clamp(S.player.health/100,0,1),6);
 const chase=V.pursuit.activeId||'VEILLE';
 rr(36,581,502,108,10,'rgba(4,7,7,.90)','rgba(125,113,75,.46)');txt('ADAPTIVE PURSUIT V99',55,607,14,'#d7c88f',800);txt(`${chase.replaceAll('-',' ').toUpperCase()}`,55,631,13,'#e1e5dc',650);
 txt(`PRESSION ${Math.round(V.pursuit.pressure)} / 100 · CHASSES ${V.pursuit.cleared.length}/5 · COUPURES ${V.pursuit.runnerCutoffs}`,55,654,12,'#b5beb3',600);
 x.fillStyle='#24251f';x.fillRect(55,667,420,8);let pg=clamp(V.pursuit.pressure/100,0,1);let grd=x.createLinearGradient(55,0,475,0);grd.addColorStop(0,'#6f8e75');grd.addColorStop(.6,'#c08c52');grd.addColorStop(1,'#b6503d');x.fillStyle=grd;x.fillRect(55,667,420*pg,8);
 rr(756,581,488,108,10,'rgba(4,7,7,.90)','rgba(100,136,119,.4)');txt('CODEX ALIEN 3 · V99 GRAPH',776,607,14,'#9bc4a7',800);let u=(S.v97.dlcCodex.unlocked?.length||0)+(S.v98.codexUi.extensionUnlocked?.length||0)+(V.codexGraph.extensionUnlocked?.length||0);let vw=(S.v97.dlcCodex.viewed?.length||0)+(S.v98.codexUi.extensionViewed?.length||0)+(V.codexGraph.extensionViewed?.length||0);txt(`${u}/90 DÉBLOQUÉES · ${vw}/90 LUES · FILTRE ${V.codexGraph.filter}`,776,633,12,'#dde5df',600);txt(`RECHERCHE “${V.codexGraph.query||'—'}” · HIST ${V.codexGraph.history.length} · LIENS ${V.codexGraph.linkUses}`,776,654,12,'#aebdb3',600);txt(`PONTS CAM ${V.cameraBridge.visited.length}/9${V.cameraBridge.activeId?` · ${Math.round(V.cameraBridge.blend*100)}%`:''}`,776,675,12,'#778e80',600);
 txt('CAPTURE QA RUNTIME V99 · RENDU PROCÉDURAL REPRODUCTIBLE',1240,24,11,'rgba(193,205,197,.62)',600,'right');
}
function codexOverlay(){
 if(!S.v98.codexUi.open) return;
 x.fillStyle='rgba(1,4,4,.79)';x.fillRect(0,0,W,H);rr(72,52,1136,612,16,'rgba(7,13,12,.985)','#687e72');
 txt('ALIEN 3 // CODEX DÉDIÉ V99',102,91,25,'#e2e9e4',800);txt('90 ENTRÉES · RECHERCHE · LIENS CROISÉS',1175,90,13,'#94b49f',700,'right');
 const cats=['TOUS','ARCHIVE','GAMEPLAY','LIEUX','PERSONNAGES','XÉNOBIOLOGIE','ÉVÉNEMENTS','SYSTÈMES','PRÉSENTATION'];let cy=126;for(const cat of cats){const sel=cat===S.v98.codexUi.selectedCategory;rr(103,cy,185,31,5,sel?'#294537':'#111b18',sel?'#87b599':'#2e3e37');txt(cat,119,cy+21,11,sel?'#e2eee6':'#8fa298',sel?800:600);cy+=37;}
 txt(`FILTRE · ${V.codexGraph.filter}`,112,486,11,'#9eb6a7',700);txt('RECHERCHE',112,517,11,'#778e80',700);rr(104,528,184,35,5,'#0c1412','#394b42');txt(V.codexGraph.query||'—',117,551,13,'#d1dbd4',650);
 rr(309,126,322,495,8,'#0c1211','#2d3b35');const names=V.codexGraph.query?['Runner Fiorina','Télégraphe inter-plan','Adaptive Pursuit','Coupure de fonderie','Pression de chasse','Hunter Director','Occultants de profondeur']:['Adaptive Pursuit','Brèche de la Tempête','Coupe du Bloc','Retour Communications','Coupure Fonderie','Ombre Patna','Pont de caméra','Pression de chasse','Recherche Codex','Liens croisés'];let ey=158;names.forEach((n,i)=>{const sel=i===0; if(sel)rr(321,ey-20,298,32,5,'#22352d','#5d7a6b');txt(`${i===0?'▶':'·'} ${n}`,334,ey+1,12,sel?'#e3ebe6':'#9aa9a1',sel?800:600);ey+=42;});
 rr(653,126,526,495,8,'#0b1110','#34453d');txt(V.codexGraph.query?'RUNNER FIORINA':'ADAPTIVE PURSUIT',684,166,22,'#e6ece8',800);txt(V.codexGraph.query?'XÉNOBIOLOGIE':'GAMEPLAY',684,191,12,'#86a894',700);
 const body=V.codexGraph.query?['Le Runner reste un acteur unique dans l’archive.','La recherche filtre uniquement les entrées déjà débloquées.','','V99 lie cette fiche aux poursuites, aux plans de profondeur','et au télégraphe inter-plan sans révéler sa position exacte.']:['Cinq poursuites exploitent les routes existantes de Fiorina.','Le Runner coupe, comprime ou feinte selon le plan du joueur','et la pression accumulée, sans dupliquer la créature.','','Les ponts caméra lissent les changements de secteur et le','Codex permet désormais recherche, filtres et liens croisés.'];let by=233;for(const l of body){txt(l,684,by,14,l?'#c4d0c8':'#6e8177',500);by+=27}
 txt('LIENS CROISÉS',684,420,12,'#8fb39d',800);['Télégraphe inter-plan','Runner Fiorina','Chasse de fonderie'].forEach((l,i)=>txt(`${i===0?'▶':'·'} ${l}`,699,448+i*24,13,i===0?'#ddcb92':'#91a49a',650));
 txt('/ RECHERCHE · K FILTRE · L LIEN · H RETOUR · B FAVORI · C FERMER',684,590,11,'#71887b',600);txt(`TERMINAUX ${V.codexGraph.terminalsRead.length}/7 · HISTORIQUE ${V.codexGraph.history.length}`,684,611,11,'#71887b',600);
}
function shiftOverlay(){if(!S.v98.director.laneShiftActive)return;const p=Math.round(S.v98.director.laneBlend*100);rr(506,185,268,52,9,'rgba(13,21,19,.9)','#799984');txt(`TRANSITION DE PLAN · ${p}%`,640,217,17,'#d7e6dc',800,'center');}
function bridgeOverlay(){if(!V.cameraBridge.activeId)return;rr(492,246,296,58,9,'rgba(12,20,18,.92)','#7d9988');txt(`PONT CAMÉRA · ${Math.round(V.cameraBridge.blend*100)}%`,640,279,17,'#dbe7df',800,'center');}
sky();environment();lanes();occluders();drawPlayer();drawRunner();shiftOverlay();bridgeOverlay();hud();codexOverlay();
</script></body></html>'''

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox','--disable-gpu'])
    for scene in data['scenes']:
        page=browser.new_page(viewport={"width":1280,"height":720}, device_scale_factor=1)
        errors=[]
        page.on('pageerror', lambda exc: errors.append(str(exc)))
        html=HTML.replace('__SCENE__', json.dumps(scene, ensure_ascii=False))
        page.set_content(html, wait_until='domcontentloaded')
        page.wait_for_timeout(80)
        if errors:
            raise RuntimeError(f"{scene['id']} JS error: {errors}")
        out=OUT/(scene['id']+'.png')
        page.screenshot(path=str(out), full_page=False)
        print(out)
        page.close()
    browser.close()
