import { ALIEN3_CAMPAIGN_ID_V88 } from '../src/alien3-dlc-v88.js';
import { withAlien3DlcRuntimeV88 } from '../src/alien3-dlc-runtime-v88.js';
import { withAlien3DlcRuntimeV89 } from '../src/alien3-dlc-runtime-v89.js';
import { withAlien3DlcRuntimeV90 } from '../src/alien3-dlc-runtime-v90.js';
import { withAlien3DlcRuntimeV91 } from '../src/alien3-dlc-runtime-v91.js';
import { withAlien3DlcRuntimeV92 } from '../src/alien3-dlc-runtime-v92.js';
import { withAlien3DlcRuntimeV93 } from '../src/alien3-dlc-runtime-v93.js';
import { withAlien3DlcRuntimeV94 } from '../src/alien3-dlc-runtime-v94.js';
import { withAlien3DlcRuntimeV95 } from '../src/alien3-dlc-runtime-v95.js';
import { withAlien3DlcRuntimeV96 } from '../src/alien3-dlc-runtime-v96.js';
import { withAlien3DlcRuntimeV97 } from '../src/alien3-dlc-runtime-v97.js';
import { withAlien3DlcRuntimeV98 } from '../src/alien3-dlc-runtime-v98.js';
import { ALIEN3_DLC_CODEX_TERMINALS_V98, ALIEN3_DLC_CODEX_V98, ALIEN3_DLC_CODEX_EXTENSION_V98 } from '../src/alien3-dlc-v98.js';

const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

class CaptureBase{
  constructor(){
    this.canvas=canvas;this.ctx=ctx;this.events=[];this.images=new Map();this.enemies=[];this.doors=[];this.keys=new Set();this.running=true;this.paused=false;
    this.platforms=[{id:'ground',x:0,y:510,w:6200},{id:'deep',x:0,y:630,w:6200},{id:'high',x:0,y:330,w:6200},{id:'perch',x:0,y:190,w:6200}];
    this.player={id:'player',x:180,y:420,w:44,h:90,alive:true,health:88,maxHealth:100,armor:0,kills:0,damageTaken:0,actionClock:0,fireClock:0,vx:0,vy:0,facing:1,crouching:false,grounded:true,color:'#b8b69a'};
    this.coop={id:'coop',x:120,y:420,w:44,h:90,alive:false,health:0,armor:0,kills:0,damageTaken:0,vx:0,vy:0};
    this.vehicle={active:false,occupied:false,driver:null,passengers:[],x:-9999};this.weaponPickup={taken:true,x:-9999};this.toolPickup={taken:true,x:-9999};this.supplies=[];this.objectiveNodes=[];
    this.archiveTerminal={recovered:false,x:-9999};this.powerNode={active:false,x:-9999};this.objective={x:6000,y:420,w:68,h:90,complete:false};
    this.missionLevelRuntime={anchors:{extraction:{x:6040,y:510}}};this.missionLevelVisualState={activeZoneId:'f161-coast'};
    this.mission={state:'active',objectives:{power:true,route:true,boss:false,archive:true,extract:false},rewards:{},retries:0,elapsed:0,casualties:0};this.inventory={salvage:0,intel:0};
    this.audio={ui(){},alarm(){},hit(){},tone(){return true;},playEffect(id,fallback){fallback?.();return false;}};this.camera={x:0,y:0};this.animationTime=8.3;this.onEvent=(event)=>this.events.push(event);
  }
  start(options={}){this.campaign=options.campaign;this.strategicBriefing=options.strategicBriefing;return{base:true};}
  createEnemy(profile,index,x,groundY,options={}){return{...profile,id:profile.id||`enemy-${index}`,x,y:groundY-90,w:108,h:82,health:profile.health||100,maxHealth:profile.health||100,speed:profile.speed||1,damage:profile.damage||10,alive:true,facing:-1,alert:true,staggerClock:0,hurtClock:0,...options};}
  initializeEnemyMissionNavigation(){}interact(){return false;}fire(){return false;}reload(){return true;}toggleVehicle(){return true;}useEquipment(){return true;}activateTracker(){return false;}
  applyEnemyDamage(enemy,amount){enemy.health=Math.max(0,enemy.health-amount);if(enemy.health<=0)enemy.alive=false;return amount;}updateEnemy(){}defeatEnemy(enemy){enemy.alive=false;enemy.health=0;return true;}
  updatePlayer(){}damagePlayer(actor,amount){actor.health=Math.max(0,actor.health-amount);actor.damageTaken+=amount;return amount;}update(delta=0.016){this.animationTime+=delta;return true;}
  missingObjectiveRequirement(){return'';}missingExtractionRequirement(){return'';}completeMission(){return true;}restartFromCheckpoint(){return true;}phaseLabel(){return'ARCHIVE';}objectiveProgressText(){return'FIORINA 161';}getInteractionPrompt(){return'';}
  captureResumeState(){return{schema:1,player:{x:this.player.x,y:this.player.y}};}applyResumeState(){return{applied:true,restored:1};}getGameplayReport(){return{base:true};}getSnapshot(){return{base:true};}locked(){return false;}
  drawBackdrop(ctx){
    const sector=this.alien3V97?.hybrid?.currentSectorId||'hybrid-storm-yard';
    const g=ctx.createLinearGradient(0,0,0,720);g.addColorStop(0,sector.includes('foundry')||sector.includes('furnace')?'#100807':'#030708');g.addColorStop(.62,sector.includes('cellblock')?'#0d100d':'#07100e');g.addColorStop(1,'#171610');ctx.fillStyle=g;ctx.fillRect(0,0,1280,720);
    ctx.save();ctx.globalAlpha=.28;ctx.strokeStyle='#53605a';ctx.lineWidth=2;
    for(let x=-50;x<1350;x+=130){ctx.beginPath();ctx.moveTo(x,100);ctx.lineTo(x+80,510);ctx.stroke();}
    ctx.globalAlpha=.18;ctx.fillStyle='#8d8a67';for(let x=30;x<1280;x+=210)ctx.fillRect(x,170+(x%3)*44,120,6);ctx.restore();
    if(sector.includes('storm')){ctx.save();ctx.strokeStyle='rgba(154,171,168,.28)';for(let i=0;i<85;i++){const x=(i*173)%1320,y=(i*83)%520;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-18,y+34);ctx.stroke();}ctx.restore();}
    if(sector.includes('foundry')||sector.includes('furnace')){const glow=ctx.createRadialGradient(880,520,20,880,520,420);glow.addColorStop(0,'rgba(196,83,37,.32)');glow.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=glow;ctx.fillRect(380,160,900,560);}
  }
  drawActor(ctx,a){
    const x=a.x,y=a.y;ctx.save();ctx.fillStyle='#c1bd9e';ctx.fillRect(x+15,y+16,14,32);ctx.fillStyle='#867b63';ctx.fillRect(x+8,y+47,28,34);ctx.fillStyle='#d6c9aa';ctx.beginPath();ctx.arc(x+22,y+9,9,0,Math.PI*2);ctx.fill();ctx.fillStyle='#262a24';ctx.fillRect(x+7,y+80,11,12);ctx.fillRect(x+27,y+80,11,12);ctx.strokeStyle='#8f997f';ctx.strokeRect(x+7,y+47,30,34);ctx.restore();
  }
  drawEnemy(ctx,e){
    if(!e?.alive)return;const x=e.x,y=e.y;ctx.save();ctx.fillStyle='#171a15';ctx.strokeStyle='#9b8a65';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x+50,y+44,46,22,-.18,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.beginPath();ctx.ellipse(x+90,y+34,27,15,-.18,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.lineWidth=5;for(const [ax,ay,bx,by] of [[28,58,8,82],[52,60,42,88],[72,57,72,87],[90,52,108,77]]){ctx.beginPath();ctx.moveTo(x+ax,y+ay);ctx.lineTo(x+bx,y+by);ctx.stroke();}ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x+15,y+45);ctx.bezierCurveTo(x-18,y+18,x-32,y+72,x-62,y+54);ctx.stroke();ctx.fillStyle='#b49a62';ctx.fillRect(x+107,y+32,8,3);ctx.restore();
  }
  drawWorld(ctx){
    const sx=this.camera.x;ctx.save();ctx.fillStyle='#20221c';ctx.fillRect(sx,510,1280,210);ctx.fillStyle='#4f4b3b';for(let x=Math.floor(sx/110)*110;x<sx+1400;x+=110)ctx.fillRect(x,507,82,4);
    const sector=this.alien3V97?.hybrid?.currentSectorId||'';
    if(sector.includes('cellblock')){for(let x=sx+120;x<sx+1180;x+=220){ctx.strokeStyle='#3e483e';ctx.strokeRect(x,250,120,250);ctx.fillStyle='#111611';ctx.fillRect(x+12,275,96,160);}}
    if(sector.includes('service')){ctx.fillStyle='#252a25';ctx.fillRect(sx,170,1280,46);ctx.fillRect(sx,470,1280,40);ctx.strokeStyle='#605847';for(let x=sx+40;x<sx+1260;x+=90){ctx.beginPath();ctx.moveTo(x,215);ctx.lineTo(x+20,470);ctx.stroke();}}
    if(sector.includes('foundry')){ctx.fillStyle='#28231c';ctx.fillRect(sx+120,240,170,270);ctx.fillRect(sx+920,190,140,320);ctx.fillStyle='#7d3d24';ctx.fillRect(sx+560,480,260,26);ctx.strokeStyle='#8c6b48';for(let x=sx+80;x<sx+1200;x+=160){ctx.beginPath();ctx.moveTo(x,510);ctx.lineTo(x+45,340);ctx.stroke();}}
    if(sector.includes('furnace')){ctx.fillStyle='#272019';ctx.beginPath();ctx.arc(sx+880,430,150,Math.PI,0);ctx.fill();ctx.fillStyle='#8a3f25';ctx.fillRect(sx+760,430,240,80);ctx.fillStyle='#303632';for(let i=0;i<4;i++)ctx.fillRect(sx+180+i*95,390,36,120);}
    ctx.restore();
    if(this.player?.alive)this.drawActor(ctx,this.player);if(this.alien3RunnerV88?.alive)this.drawEnemy(ctx,this.alien3RunnerV88);
  }
  drawHud(ctx){ctx.save();ctx.fillStyle='rgba(2,4,4,.88)';ctx.fillRect(18,18,310,72);ctx.strokeStyle='#5f695e';ctx.strokeRect(18.5,18.5,309,71);ctx.fillStyle='#d8d3ab';ctx.font='bold 12px monospace';ctx.fillText('MIRE // FIORINA 161',30,40);ctx.fillStyle='#9daa9a';ctx.font='10px monospace';ctx.fillText(`RIPLEY  PV ${Math.round(this.player.health)}/100`,30,59);ctx.fillText('OBJECTIF · SURVIVRE / RECONSTRUIRE',30,77);ctx.restore();}
}
const V88=withAlien3DlcRuntimeV88(CaptureBase),V89=withAlien3DlcRuntimeV89(V88),V90=withAlien3DlcRuntimeV90(V89),V91=withAlien3DlcRuntimeV91(V90),V92=withAlien3DlcRuntimeV92(V91),V93=withAlien3DlcRuntimeV93(V92),V94=withAlien3DlcRuntimeV94(V93),V95=withAlien3DlcRuntimeV95(V94),V96=withAlien3DlcRuntimeV96(V95),V97=withAlien3DlcRuntimeV97(V96),Engine=withAlien3DlcRuntimeV98(V97);
const runner={id:'enemy-006-runner',name:'Runner Fiorina',biology:'xenomorph',caste:'runner',health:720,damage:29,speed:1.9};
const engine=new Engine();engine.start({campaign:{id:ALIEN3_CAMPAIGN_ID_V88},strategicBriefing:{flags:{'alien3-v90-challenge':'archive'}},enemyCatalog:[runner]});

function unlockAllCodex(){
  for(const terminal of ALIEN3_DLC_CODEX_TERMINALS_V98)engine.readAlien3CodexTerminalV97(terminal);
  for(const id of engine.alien3CodexUnlockedV98())engine.markAlien3CodexViewedV98(id);
}
function scene(name){
  engine.alien3V98.codexUi.open=false;engine.alien3V98.director.runnerTelegraphClock=0;engine.alien3V98.director.laneShiftActive=false;engine.player.health=88;engine.alien3RunnerV88.alive=true;engine.alien3V88.runnerDefeated=false;
  if(name==='storm-depth'){engine.player.x=430;engine.player.y=420;engine.alien3RunnerV88.x=780;engine.alien3RunnerV88.y=420;engine.syncAlien3HybridSectorV97(.05);engine.alien3V97.hybrid.playerLane=0;engine.alien3V97.hybrid.runnerLane=2;}
  else if(name==='cellblock-shift'){engine.player.x=2200;engine.player.y=420;engine.alien3RunnerV88.x=2550;engine.alien3RunnerV88.y=420;engine.syncAlien3HybridSectorV97(.05);engine.alien3V97.hybrid.playerLane=0;engine.alien3V97.hybrid.runnerLane=1;engine.alien3V98.director.laneShiftActive=true;engine.alien3V98.director.laneFrom=0;engine.alien3V98.director.laneTo=2;engine.alien3V98.director.laneBlend=.54;engine.alien3V98.director.runnerTelegraphFrom=1;engine.alien3V98.director.runnerTelegraphTo=2;engine.alien3V98.director.runnerTelegraphClock=.42;}
  else if(name==='service-side'){engine.player.x=3200;engine.player.y=420;engine.alien3RunnerV88.x=3525;engine.alien3RunnerV88.y=420;engine.syncAlien3HybridSectorV97(.05);engine.alien3V97.hybrid.playerLane=1;engine.alien3V97.hybrid.runnerLane=1;}
  else if(name==='foundry-hunt'){engine.player.x=4380;engine.player.y=420;engine.alien3RunnerV88.x=4725;engine.alien3RunnerV88.y=420;engine.syncAlien3HybridSectorV97(.05);engine.alien3V97.hybrid.playerLane=2;engine.alien3V97.hybrid.runnerLane=0;engine.alien3V98.director.runnerTelegraphFrom=0;engine.alien3V98.director.runnerTelegraphTo=2;engine.alien3V98.director.runnerTelegraphClock=.58;}
  else if(name==='codex'){engine.player.x=3840;engine.player.y=420;engine.syncAlien3HybridSectorV97(.05);unlockAllCodex();engine.alien3V98.codexUi.open=true;engine.alien3V98.codexUi.selectedCategory='PRÉSENTATION';engine.alien3V98.codexUi.currentId='a3c-v98-director';engine.alien3V98.codexUi.bookmarks=['a3c-v98-director','a3c-overview-hybrid','a3c-xeno-runner'];}
  else if(name==='patna-depth'){engine.player.x=5420;engine.player.y=420;engine.alien3RunnerV88.alive=false;engine.syncAlien3HybridSectorV97(.05);engine.alien3V97.hybrid.playerLane=1;}
  else {engine.player.x=5920;engine.player.y=420;engine.alien3RunnerV88.alive=false;engine.syncAlien3HybridSectorV97(.05);engine.alien3V97.hybrid.playerLane=1;}
  engine.syncAlien3DirectorProfileV98();engine.camera.x=clamp(engine.player.x-470,0,6200-1280);engine.camera.y=0;
}
function draw(){ctx.clearRect(0,0,1280,720);engine.drawBackdrop(ctx);ctx.save();ctx.translate(-engine.camera.x,0);engine.drawWorld(ctx);ctx.restore();engine.drawHud(ctx);const sector=engine.currentAlien3HybridSectorV97();ctx.save();ctx.fillStyle='rgba(0,0,0,.72)';ctx.fillRect(20,678,700,26);ctx.fillStyle='#9fa991';ctx.font='10px monospace';ctx.fillText(`CAPTURE QA · ${sector.label} · ${sector.mode==='depth'?'PROFONDEUR 2.5D':'2D LATÉRALE'} · PROFIL ${engine.alien3V98.director.currentProfileId}`,30,696);ctx.restore();}
const name=new URLSearchParams(location.search).get('scene')||'storm-depth';scene(name);draw();window.__ALIEN3_V98_CAPTURE_READY__=true;window.__ALIEN3_V98_SCENE__=name;window.__ALIEN3_V98_SNAPSHOT__=engine.getSnapshot();
