import json, os, math
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path('/mnt/data/ALIEN3_DLC_v98_PATCH')
STATE_FILE = ROOT / 'qa_visual' / 'capture-states-v98.json'
OUT = ROOT / 'qa_visual' / 'screenshots'
OUT.mkdir(parents=True, exist_ok=True)
data = json.loads(STATE_FILE.read_text(encoding='utf-8'))

HTML = r'''<!doctype html><html><head><meta charset="utf-8"><style>
html,body{margin:0;width:1280px;height:720px;overflow:hidden;background:#050708;font-family:Arial,Helvetica,sans-serif}
canvas{display:block;width:1280px;height:720px}</style></head><body><canvas id="c" width="1280" height="720"></canvas>
<script>
const S=__SCENE__;
const c=document.getElementById('c'),x=c.getContext('2d');
const W=1280,H=720;
const mode=S.sector.mode;
const profile=S.v98.director.currentProfileId;
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function rr(px,py,w,h,r,fill,stroke){x.beginPath();x.roundRect(px,py,w,h,r); if(fill){x.fillStyle=fill;x.fill()} if(stroke){x.strokeStyle=stroke;x.stroke()}}
function txt(t,px,py,size=18,color='#d8e1d7',weight=500,align='left'){x.font=`${weight} ${size}px Arial`;x.textAlign=align;x.fillStyle=color;x.fillText(t,px,py)}
function line(ax,ay,bx,by,color,w=2,alpha=1){x.globalAlpha=alpha;x.beginPath();x.moveTo(ax,ay);x.lineTo(bx,by);x.strokeStyle=color;x.lineWidth=w;x.stroke();x.globalAlpha=1}
function laneVisual(lane){return [{scale:.80,y:-58,alpha:.68,label:'ARRIÈRE'},{scale:.95,y:0,alpha:.86,label:'MÉDIAN'},{scale:1.10,y:60,alpha:1,label:'AVANT'}][lane]||{scale:1,y:0,alpha:1,label:'—'}}
function localX(worldX){const mid=(S.player.x+S.runner.x)/2; return 640+(worldX-mid)*1.15}
function sky(){
 const g=x.createLinearGradient(0,0,0,H); let stops;
 if(profile.includes('storm')) stops=[['#0a1114','#172226'],['#111a1e','#06090a']];
 else if(profile.includes('foundry')||profile.includes('mold')||profile.includes('patna')||profile.includes('final')) stops=[['#17110d','#2a1b12'],['#100b08','#030405']];
 else stops=[['#081011','#111a18'],['#0b1110','#040606']];
 g.addColorStop(0,stops[0][0]);g.addColorStop(.62,stops[0][1]);g.addColorStop(1,stops[1][1]);x.fillStyle=g;x.fillRect(0,0,W,H);
}
function environment(){
 const ground=525;
 // deep background
 x.fillStyle='#0b0f0f'; for(let i=0;i<14;i++){let px=i*110-30; x.fillRect(px,160+(i%3)*18,70,ground-160);}
 if(profile.includes('storm')){
   x.fillStyle='#11191d'; for(let i=0;i<8;i++){let px=i*180-40; x.fillRect(px,330,120,210); x.fillRect(px+30,280,20,50)}
   for(let i=0;i<70;i++){let px=(i*83)%1320, py=80+(i*47)%500; line(px,py,px-26,py+60,'#75909b',1,.18)}
   line(0,525,W,525,'#65737a',3,.35);
 } else if(profile.includes('prison')){
   x.fillStyle='#101717'; for(let i=0;i<12;i++){let px=40+i*104; rr(px,260,72,250,3,'#0a0e0e','#27302e'); line(px+18,270,px+18,500,'#38433f',2,.5);line(px+52,270,px+52,500,'#38433f',2,.5)}
   line(0,525,W,525,'#63695d',4,.45);
 } else if(profile.includes('service')){
   for(let i=0;i<8;i++){let py=180+i*42; line(0,py,W,py,'#25322f',8,.7)}
   for(let i=0;i<16;i++){let px=i*90; line(px,120,px,520,'#1a2421',5,.8)}
   rr(300,330,220,140,8,'#111816','#39453f'); rr(820,310,160,160,8,'#111816','#39453f');
   line(0,525,W,525,'#505951',4,.6);
 } else if(profile.includes('communications')){
   for(let i=0;i<6;i++){rr(90+i*198,250,130,250,4,'#0d1414','#394540'); for(let j=0;j<6;j++) rr(106+i*198,274+j*32,98,14,2,j%2?'#172a24':'#1b2421')}
   line(0,525,W,525,'#59645b',4,.55);
 } else if(profile.includes('foundry')||profile.includes('mold')){
   x.fillStyle='#1a1410'; for(let i=0;i<7;i++){let px=i*200-30; x.fillRect(px,250,150,275); line(px+20,210,px+20,510,'#45372c',10,.8)}
   x.fillStyle='rgba(216,104,38,.22)';x.fillRect(0,490,W,60); for(let i=0;i<14;i++){let px=i*96; line(px,520,px+30,455,'#d66a2a',2,.35)}
   rr(515,395,250,100,16,'#130d09','#82512c');
 } else if(profile.includes('patna')){
   x.fillStyle='#18120f'; for(let i=0;i<9;i++){let px=i*150; x.fillRect(px,340,90,185)}
   rr(930,205,230,285,12,'#b2b7ae','#e6e9df'); rr(980,250,130,210,8,'#1c2625','#75837c');
   x.fillStyle='rgba(211,88,38,.25)';x.fillRect(0,500,W,45);
 } else {
   x.fillStyle='#171410'; for(let i=0;i<10;i++){let px=i*135;x.fillRect(px,300,90,225)}
   rr(470,250,340,260,8,'#15100d','#5f4937'); line(0,525,W,525,'#6a5849',4,.5);
 }
 // foreground framing
 x.fillStyle='rgba(0,0,0,.30)';x.fillRect(0,0,36,H);x.fillRect(W-36,0,36,H);
}
function lanes(){
 if(mode!=='depth') return;
 [0,1,2].forEach((l)=>{const v=laneVisual(l), base=446+v.y; line(70,base,1210,base,l===S.player.lane?'#91c7a6':'#52625b',l===S.player.lane?3:1,l===S.player.lane?.62:.28); txt(v.label,88,base-9,13,l===S.player.lane?'#b9dec6':'#6f8078',600)});
}
function drawPlayer(){
 let lane=S.player.lane;
 let visual=laneVisual(lane);
 if(S.v98.director.laneShiftActive){let b=clamp(S.v98.director.laneBlend,0,1);let f=laneVisual(S.v98.director.laneFrom),t=laneVisual(S.v98.director.laneTo);visual={scale:f.scale+(t.scale-f.scale)*b,y:f.y+(t.y-f.y)*b,alpha:.95,label:'SHIFT'};}
 let px=localX(S.player.x), py=442+visual.y, sc=visual.scale;
 x.save();x.translate(px,py);x.scale(sc,sc);x.globalAlpha=visual.alpha;
 // legs
 line(-10,25,-16,66,'#aeb8aa',10,1);line(10,25,17,66,'#aeb8aa',10,1);
 // body
 rr(-20,-42,40,70,8,'#7e8e79','#c0cab9'); rr(-14,-74,28,32,14,'#b8aa92','#d7cbb7');
 // arm + flare/light
 line(16,-25,38,-5,'#9ca88f',8,1); x.fillStyle='#c7d66f';x.fillRect(34,-8,12,5);
 x.restore();
 rr(px-42,py+72,84,22,6,'rgba(8,12,11,.78)','rgba(150,196,164,.35)');txt(`RIPLEY · P${lane+1}`,px,py+88,12,'#d7e7db',700,'center');
}
function drawRunner(){
 if(!S.runner.alive){txt('RUNNER NEUTRALISÉ',localX(S.runner.x),470,13,'#b48262',700,'center');return;}
 const v=laneVisual(S.runner.lane),px=localX(S.runner.x),py=446+v.y,sc=v.scale*1.02;
 x.save();x.translate(px,py);x.scale(sc,sc);x.globalAlpha=v.alpha;
 // quadruped silhouette
 x.fillStyle='#101313';x.strokeStyle='#56625d';x.lineWidth=2;
 x.beginPath();x.ellipse(0,-18,58,24,0,0,Math.PI*2);x.fill();x.stroke();
 x.beginPath();x.ellipse(52,-30,27,18,-.12,0,Math.PI*2);x.fill();x.stroke();
 // dome
 x.beginPath();x.ellipse(65,-39,26,11,-.12,Math.PI,Math.PI*2);x.strokeStyle='#75817c';x.stroke();
 line(-46,-8,-70,34,'#222827',8,1);line(-12,0,-28,39,'#222827',8,1);line(28,-1,17,40,'#222827',8,1);line(51,-12,66,29,'#222827',8,1);
 // tail
 x.beginPath();x.moveTo(-54,-24);x.bezierCurveTo(-95,-40,-105,-70,-132,-66);x.strokeStyle='#1e2422';x.lineWidth=8;x.stroke();
 x.restore();
 if(S.v98.director.runnerTelegraphClock>0){const tv=laneVisual(S.v98.director.runnerTelegraphTo);const ty=446+tv.y; x.save();x.setLineDash([8,7]);x.strokeStyle='rgba(212,115,74,.85)';x.lineWidth=2;x.beginPath();x.ellipse(px,ty-18,76,42,0,0,Math.PI*2);x.stroke();x.setLineDash([]);txt(`TRAVERSÉE → P${S.v98.director.runnerTelegraphTo+1}`,px,ty-68,13,'#e1a178',700,'center');x.restore();}
 rr(px-46,py+64,92,22,6,'rgba(8,12,11,.82)','rgba(120,145,134,.38)');txt(`RUNNER · P${S.runner.lane+1}`,px,py+80,12,'#cdd6cf',700,'center');
}
function occluders(){
 if(mode!=='depth') return;
 const lane=S.player.lane; const y=laneVisual(lane).y;
 if(profile.includes('prison')||profile.includes('foundry')||profile.includes('patna')){
   x.globalAlpha=.55;rr(330,395+y,130,115,4,'#161d1b','#53615a');rr(860,405-y*.3,100,105,4,'#151b19','#4d5953');x.globalAlpha=1;
 }
}
function hud(){
 // top-left title
 rr(34,28,430,76,10,'rgba(4,8,8,.86)','rgba(99,135,117,.45)');
 txt('MIRE // FIORINA 161',56,57,14,'#91b99f',700);txt(S.sector.label,56,83,24,'#e0e5dd',800);
 rr(504,30,214,34,8,mode==='depth'?'rgba(50,91,78,.82)':'rgba(89,74,53,.82)','rgba(178,205,190,.32)');txt(mode==='depth'?'VUE PROFONDEUR 2.5D':'VUE 2D LATÉRALE',611,53,14,'#e6ece7',700,'center');
 // health
 rr(34,118,258,50,8,'rgba(4,8,8,.78)','rgba(90,120,106,.28)');txt('RIPLEY',49,141,12,'#829c8c',700);txt(`${Math.round(S.player.health)} HP`,276,143,14,'#d9e7dc',800,'right');x.fillStyle='#1d2823';x.fillRect(49,151,226,6);x.fillStyle='#8eb69a';x.fillRect(49,151,226*clamp(S.player.health/100,0,1),6);
 // bottom director
 rr(36,593,420,96,10,'rgba(4,7,7,.88)','rgba(100,136,119,.4)');txt('HYBRID DIRECTOR V98',55,619,14,'#9bc4a7',800);txt(`PROFIL · ${profile.toUpperCase()}`,55,643,13,'#dde5df',600);txt(`PLAN JOUEUR P${S.player.lane+1} · RUNNER P${S.runner.lane+1}`,55,665,13,'#aebdb3',600);txt(`SECTEUR ${mode==='depth'?'MULTI-PLAN':'TENSION LATÉRALE'}`,55,684,12,'#778e80',600);
 rr(824,594,420,94,10,'rgba(4,7,7,.88)','rgba(100,136,119,.4)');txt('CODEX ALIEN 3',843,620,14,'#9bc4a7',800);let ui=S.v98.codexUi;let unlocked=(S.v97.dlcCodex.unlocked?.length||0)+(ui.extensionUnlocked?.length||0);let viewed=(S.v97.dlcCodex.viewed?.length||0)+(ui.extensionViewed?.length||0);txt(`${unlocked}/78 DÉBLOQUÉES · ${viewed}/78 LUES`,843,647,13,'#dde5df',600);let terminals=[...new Set([...(S.v97.dlcCodex.terminalsRead||[]),...(ui.terminalsRead||[])])].length;txt(`TERMINAUX ${terminals}/6 · FAVORIS ${ui.bookmarks?.length||0}`,843,670,12,'#9caea3',600);
 // runtime transparency label
 txt('CAPTURE QA RUNTIME V98 · RENDU PROCÉDURAL REPRODUCTIBLE',1240,24,11,'rgba(193,205,197,.62)',600,'right');
}
function codexOverlay(){
 if(!S.v98.codexUi.open) return;
 x.fillStyle='rgba(1,4,4,.76)';x.fillRect(0,0,W,H);
 rr(95,64,1090,590,16,'rgba(8,14,13,.97)','#62796d');
 txt('ALIEN 3 // CODEX DÉDIÉ V98',126,105,25,'#dfe8e1',800);
 txt('ARCHIVE FIORINA 161 · 78 ENTRÉES',1154,104,13,'#8eb19a',700,'right');
 const cats=['TOUS','ARCHIVE','GAMEPLAY','LIEUX','PERSONNAGES','XÉNOBIOLOGIE','ÉVÉNEMENTS','SYSTÈMES','PRÉSENTATION'];
 let cy=139;for(const cat of cats){const sel=cat===S.v98.codexUi.selectedCategory;rr(126,cy,195,34,6,sel?'#294537':'#111b18',sel?'#87b599':'#2e3e37');txt(cat,143,cy+23,12,sel?'#e2eee6':'#8fa298',sel?800:600);cy+=42;}
 // entries column
 rr(343,139,320,461,8,'#0c1211','#2d3b35');
 const entries=['Hybrid Director','Transition de plan lissée','Télégraphe du Runner','Occultants de profondeur','Contrats caméra','Lisibilité latérale','Interface Codex','Entrées non lues','Favoris','Bloc carcéral','Fonderie','Arrivée Patna'];
 let ey=166; entries.forEach((e,i)=>{const sel=i===0; if(sel)rr(357,ey-20,290,32,5,'#22352d','#5d7a6b');txt(`${i<9?'0':''}${i+1} · ${e}`,371,ey+1,12,sel?'#e3ebe6':'#9aa9a1',sel?800:600);if(i<3){x.fillStyle='#91c8a5';x.beginPath();x.arc(636,ey-4,3,0,Math.PI*2);x.fill()}ey+=35;});
 // detail
 rr(685,139,468,461,8,'#0b1110','#34453d');txt('HYBRID DIRECTOR',714,180,22,'#e6ece8',800);txt('PRÉSENTATION',714,205,12,'#86a894',700);
 const body=['Le réalisateur hybride associe chaque secteur de Fiorina','à un contrat caméra cohérent avec son espace : profondeur','pour les arènes et chasses larges, vraie 2D latérale pour','les couloirs étroits, conduits et phases de tension.','','Les changements de plan sont interpolés et le Runner','télégraphie sa traversée avant de changer de profondeur.','','Cette entrée appartient au Codex Alien 3 dédié et reste','indépendante des dossiers MIRE historiques.'];
 let by=245;for(const l of body){txt(l,714,by,14,l?'#c4d0c8':'#6e8177',500);by+=26}
 txt('B · FAVORI',714,570,12,'#8fb39d',700);txt('C · FERMER  ·  [ ] CATÉGORIE  ·  , . PAGE',1130,570,11,'#71887b',600,'right');
}
function shiftOverlay(){if(!S.v98.director.laneShiftActive)return;const p=Math.round(S.v98.director.laneBlend*100);rr(506,185,268,52,9,'rgba(13,21,19,.9)','#799984');txt(`TRANSITION DE PLAN · ${p}%`,640,217,17,'#d7e6dc',800,'center');}
sky();environment();lanes();occluders();drawPlayer();drawRunner();shiftOverlay();hud();codexOverlay();
</script></body></html>'''

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox','--disable-gpu'])
    for scene in data['scenes']:
        page=browser.new_page(viewport={"width":1280,"height":720}, device_scale_factor=1)
        errors=[]
        page.on('pageerror', lambda exc: errors.append(str(exc)))
        html=HTML.replace('__SCENE__', json.dumps(scene, ensure_ascii=False))
        page.set_content(html, wait_until='domcontentloaded')
        page.wait_for_timeout(80)
        if errors:
            raise RuntimeError(f"{scene['id']} JS error: {errors}")
        out=OUT/(scene['id']+'.png')
        page.screenshot(path=str(out), full_page=False)
        print(out)
        page.close()
    browser.close()
