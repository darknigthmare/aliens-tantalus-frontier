# Rapport QA V102 — Ancrages et ateliers

## Résultats exécutés
- Données et contrats du nouveau runtime : **23 cas passés**.
- Installation : **11 scénarios passés sur fixtures synthétiques**.
- Navigateur : **19 contrôles passés**, 10 captures 1280×720.
- Héritage : **55/55 scripts isolés passés**.

## Corrections constatées
- Décor lié à la hauteur du joueur dans V101 : supprimé pour la nouvelle couche.
- Vérification des appuis : nom, hauteur, largeur et présence de la plateforme compilée lorsqu’elle est fournie.
- Flottement de petits objets posés au sol : coordonnées corrigées ; tolérance ramenée à 0,01 unité.
- Fond : couverture opaque de la première rangée contrôlée pour neuf positions de caméra.
- Changement brutal de vocabulaire architectural : fondu de 192 unités, continuité testée.
- Redimensionnement du banc initialement figé à 1280×720 : corrigé et retesté en 844×390.
- Les 90 textes des archives sont reformulés ; la recherche indexe les textes affichés et ne révèle pas les pages verrouillées.
- Le rendu des archives ne modifie pas la sauvegarde.
- Matériel Compagnie : huit composants réellement masqués avant arrivée.
- Registre : le contrat source attendait 440 campagnes ; le patch ajoute une campagne. L’installateur V102 met la cible à 441, sans renuméroter le registre général.
- Échec de validation : l’installation se fait d’abord dans une copie ; le dossier cible reste inchangé.

## Mesures
- 30 assemblages / 284 composants / 51 formes / 30 supports.
- Topologie V101 inchangée : 72 points / 119 connexions / 4 routes.
- Couverture des panneaux HUD ordinaires : 5.70 % du canvas.
- L’installateur gère 31 modules runtime et sept fichiers de base, dont content.js.

## Limites
Le navigateur a exécuté un banc local V101/V102 avec contrôleur simplifié. Il ne s’agit pas du moteur principal, ni d’un parcours complet du DLC. Aucun build complet du dépôt, push GitHub ou déploiement V102 n’a été effectué. Les succès/échecs npm de l’installation ont été simulés dans des fixtures pour tester les écritures ; ils ne prouvent pas le build du jeu.
La qualité artistique finale, la fidélité scène par scène, les véritables collisions en profondeur et l’assemblage avec tous les anciens interactifs restent à examiner dans la production complète.

## Preuves livrées
- qa-v102/unit.json
- qa-v102/installation.json
- qa-v102/browser.json
- qa-v102/regressions.json et journaux individuels
- qa-v102/design-source.json
- qa-v102/captures/
- scripts/test-alien3-dlc-v102.mjs
- scripts/test-alien3-installation-v102.mjs
- scripts/capture-alien3-v102.py
