# ALIEN 3 — FIORINA 161
## Codex de level design V102 · Ancrages et ateliers

### Statut de cette édition
Ce document décrit les données réellement livrées dans la V102 : 30 assemblages nommés, 284 composants, 51 formes de rendu et les 72 points du graphe hérité. Un point de graphe n’est pas présenté comme une salle entièrement reconstruite. Le dessin demeure une interprétation provisoire, pas un relevé 1:1 des décors du film.
Le codex de conception est un document hors jeu. Il ne remplace pas les 90 entrées des archives du joueur et n’ajoute aucun score de collecte. Les versions antérieures restent dans le pack pour la reprise du travail ; les règles V102 prennent le pas sur le placement dispersé et les objectifs de quantité de la V101.

## 1. Choix de conception
Un lieu est identifié par son activité avant de recevoir des objets. L’EEV a une coque, des ruptures et un matériel de secours ; une baie de soin possède un brancard, de l’eau, du rangement et de la lumière ; le creuset est associé à un palan et à une poche de transfert. Des groupes lisibles remplacent une répartition uniforme de petits objets.
La densité n’est pas une condition de victoire. Les 284 composants ne sont pas 284 accessoires uniques : ce sont les pièces de 30 ensembles, dessinées à partir de 51 formes. Les murs, poutres et éléments lointains ne sont pas ajoutés au total pour gonfler le catalogue.
Le découpage caméra hybride reste hérité : neuf secteurs, cinq avec profondeur et quatre latéraux. Cette édition ne convertit pas encore tout le graphe en véritables pièces cloisonnées avec changement de plan à chaque porte. La continuité d’une pièce, son étage et ses voisins doivent rester prioritaires lors de cette future conversion.

## 2. Coordonnées, échelle et appuis
Le monde mesure 6200 × 720 unités de jeu. X augmente vers la droite et Y vers le bas. Le pied d’un personnage se situe à y + h. Les dimensions ci-dessous sont des unités de jeu ; elles ne mesurent ni les acteurs ni les plateaux du film.
Le support d’un assemblage est le point nommé du graphe, puis sa plateforme node-platform-<identifiant> dans le plan compilé. Quand un vrai plan compilé est fourni, l’audit vérifie la présence de cette surface, sa hauteur et la largeur réellement disponible. Dans le banc local, ces supports sont dérivés des plateformes des points du template : ce périmètre est signalé dans les données.
La largeur d’une baie est bornée par la largeur du support moins 24 unités, par le plus proche voisin au même étage moins 24 unités et par la largeur native de la recette. Le dessin ne doit donc pas devenir plus grand pour remplir un écran. Les écarts du compilateur de niveau sont appliqués aux ancrages, pas ignorés.
Formules : largeur = maxX(recette) × échelle ; origineX = nœud.x − largeur/2 ; composant.x = origineX + localX × échelle ; composant.y = nœud.y + localY × échelle. Pour un composant posé au sol, composant.y + composant.h = support.y, avec une tolérance numérique de 0,01 unité.
Le joueur, sa hauteur de saut, la caméra et la profondeur ne figurent jamais dans ces coordonnées de placement. Ils ne peuvent donc pas déplacer un brancard, une pompe ou un creuset. La caméra intervient uniquement au moment de projeter le monde à l’écran.

## 3. Séparation décor / gameplay
Tous les nouveaux ensembles sont dans une alcôve arrière : renderPlane = rear-recess, collision = none. Ils ne constituent pas une nouvelle couverture et ne changent pas le trajet du Runner. Le sol jouable, les verrous, les dommages, les postes interactifs et la poursuite restent ceux du runtime existant.
Une cellule peinte dans une baie n’est pas une porte ajoutée au graphe. Un cadran dessiné n’est pas un bouton. Le joueur reçoit une invite uniquement des véritables interactions existantes. Pour transformer un futur accessoire en objet utilisable, il faudra ajouter un contrat de collision, d’accès, d’état et de sauvegarde explicite ; la forme seule ne suffit pas.
Le matériel de récupération de la Compagnie est conditionnel. Les huit composants de cet ensemble sont masqués jusqu’au drapeau d’arrivée ou à une phase de conclusion compatible. Sa présence n’est jamais déduite de la seule position horizontale du joueur.

## 4. Couches, éclairage et transitions
Couche 0 : remplissage opaque de tout le champ depuis y = 0. Couche 1 : maçonnerie et masses lointaines à déplacement lent. Couche 2 : réseaux de plafond. Couche 3 : baies ancrées, machines et mobilier. Couche 4 : plateformes, interactions et acteurs hérités. Couche 5 : quelques conduites de premier plan qui s’effacent devant les silhouettes. Couche 6 : interface compacte.
Les maçonneries suivent 0,14 du déplacement horizontal et 0,08 du déplacement vertical. Les réseaux de plafond utilisent des coefficients distincts 0,28 et 0,18. Les machines et meubles suivent exactement le monde ; ils ne glissent pas sur leur support pour produire une parallaxe.
Le vocabulaire du fond dépend du lieu : ouvertures et intempéries côtières, niches médicales sobres, barreaux pour la détention, conduites dans les galeries, cuves et transferts dans la fonderie. Les changements de vocabulaire sont fondus sur une bande de 192 unités autour de la transition, sans remplacer brutalement tout l’écran.
Chaque lueur locale de la nouvelle couche est associée à un luminaire, une bougie ou un contenant chaud. Ce sont des halos 2D, pas une simulation d’éclairage physique. Le sel, l’usure, les joints, les rivets et les nervures sont des détails de formes ; ils ne doivent pas brouiller la silhouette principale.
Les premiers plans descendent depuis le haut mais ne forment pas une barre opaque sur le joueur. L’opacité tombe au maximum à 0,065 près d’un acteur. Les dimensions de dégagement utilisées par le test sont explicites dans foregroundOpacityV102.
Les effets animés de la nouvelle couche utilisent un temps de rendu nul avec le réglage de mouvement réduit. La qualité basse supprime une partie des traces de surface, pas les appuis ni les silhouettes utiles.

## 5. Interface du joueur
Le HUD dessiné dans le canvas est limité à trois panneaux ordinaires : lieu, état et action courante. Leur aire cumulée représente 5,70 % de 1280 × 720. Ce chiffre ne mesure pas les panneaux de l’application principale autour du canvas, non vérifiés dans le banc.
Les 90 entrées existantes reçoivent une nouvelle formulation destinée au joueur, sans ajouter de dossiers ni changer leurs identifiants. La recherche utilise les titres et textes affichés et respecte les conditions de découverte. Les archives occupent davantage d’espace uniquement à la demande. Le rendu d’une page ne doit pas marquer un dossier comme lu, délivrer une preuve ou modifier un score. Seule une action explicite ou le système de progression propriétaire peut faire évoluer ces états.
Les codes de version, identifiants de nœud, noms de tests et compteurs de développement appartiennent à ce document ou aux rapports, jamais au HUD ordinaire. Les touches indiquées doivent correspondre à des actions réellement disponibles.

## 6. Grille de contrôle et portée des preuves
Les contrôles automatisés garantissent des propriétés précises des données ou du code. Ils ne certifient ni la fidélité au film, ni la qualité artistique finale, ni l’absence de tous les problèmes du jeu complet. Les lignes « examen visuel » restent des validations humaines à faire écran par écran.
| Règle | Contrat | Contrôle |
|---|---|---|
| A3-ANCHOR | Tout décor a un support nommé ; coordonnées indépendantes du joueur. | test automatisé ciblé |
| A3-FINITE | Positions et dimensions finies et positives. | test automatisé ciblé |
| A3-ID | Identifiants uniques, parents existants. | test automatisé ciblé |
| A3-FOOT | Les meubles reposent sur le plan de pose ; pas sur la caméra. | test automatisé ciblé |
| A3-BOUND | Les éléments restent dans la baie de leur assemblage. | test automatisé ciblé |
| A3-NO_FAKE_COVER | Décor d’arrière-plan non collidable et explicitement sans couverture. | test automatisé ciblé |
| A3-CONDITION | Le matériel de récupération dépend de l’arrivée de la Compagnie. | test automatisé ciblé |
| A3-ROUTE | Aucun nœud, verrou ou ordre de mission ajouté pour justifier le décor. | test automatisé ciblé |
| A3-DRAW_PURE | Le rendu ne change ni progression ni sauvegarde. | test automatisé ciblé |
| A3-TOP | Fond opaque depuis le premier pixel du champ, quelle que soit la caméra. | contrôle dans Chromium |
| A3-HUD | Les panneaux ordinaires couvrent moins de 9 % de l’écran. | test automatisé ciblé |
| A3-READ | Les premiers plans s’effacent à proximité des silhouettes. | test automatisé ciblé |
| A3-PARALLAX | Les machines proches suivent le monde ; seule l’architecture distante dérive. | contrôle dans Chromium |
| A3-LUX | Une lumière forte a une source dessinée. | examen visuel, pas certification automatique |
| A3-RHYTHM | Alcôves équipées puis respirations, sans tapis uniforme de petits objets. | examen visuel, pas certification automatique |
| A3-IDENTITY | Une forme identifiable remplace chaque bloc générique. | examen visuel, pas certification automatique |
| A3-FILM | Plans et dimensions de jeu : adaptation, pas relevé certifié des plateaux. | limite de périmètre |
| A3-ROOMS | La pièce, son étage et ses voisins priment sur les limites de caméra. | limite de périmètre |

## 7. Fiches des neuf secteurs

### 7.1. Côte et épave
**Secteur :** `hybrid-storm-yard` · X 0 à 720 · vue avec profondeur. **Contenu :** 2 assemblages / 18 composants.

**Composition :** Maçonnerie sombre, sel, tôles arrachées. La coque de l’EEV reste le repère, pas un rectangle générique.
**Logique des réseaux :** Air : prise → filtre → gaine. Eau : ruissellement → caniveau. Cette phrase décrit l’intention visuelle ; elle n’ajoute pas une simulation de fluides.
**Exclusions et pièges :** Pas de mobilier médical dispersé sur la côte. Pluie extérieure seulement.

**Assemblages rattachés à la position réelle :**
- Prise d’air côtière — `f161-spawn` ; support Y 510 ; X 87.5–272.5 ; hauteur décorative 146.
- Épave et matériel de secours — `f161-eev` ; support Y 510 ; X 485.5–754.5 ; hauteur décorative 158.

**Contrôle avant validation de ce secteur :** vérifier les extrémités du support dans le plan compilé ; contrôler la silhouette du personnage en marche et en saut ; vérifier que la baie ne suggère pas une couverture ; comparer l’état avant et après événement ; vérifier la sortie dans les deux sens de circulation. La vue du banc est une coupe multi-étages, pas une preuve de géométrie complète d’une pièce du film.

### 7.2. Infirmerie et morgue
**Secteur :** `hybrid-eev-infirmary` · X 720 à 1700 · vue latérale. **Contenu :** 3 assemblages / 32 composants.

**Composition :** Alcôves de soin différenciées par brancard, lavabo, armoires et luminaire.
**Logique des réseaux :** Eau de lavage → évier → évacuation ; écran → câble → boîtier. Cette phrase décrit l’intention visuelle ; elle n’ajoute pas une simulation de fluides.
**Exclusions et pièges :** Ne pas représenter une morgue comme une autre soute. Pas de lampe sans support.

**Assemblages rattachés à la position réelle :**
- Poste de soin — `f161-infirmary` ; support Y 510 ; X 1002–1238 ; hauteur décorative 131.44.
- Chambre médicale — `f161-clemens-bed` ; support Y 510 ; X 1302–1458 ; hauteur décorative 86.89.
- Baie mortuaire — `f161-morgue-high` ; support Y 350 ; X 1382–1618 ; hauteur décorative 111.27.

**Contrôle avant validation de ce secteur :** vérifier les extrémités du support dans le plan compilé ; contrôler la silhouette du personnage en marche et en saut ; vérifier que la baie ne suggère pas une couverture ; comparer l’état avant et après événement ; vérifier la sortie dans les deux sens de circulation. La vue du banc est une coupe multi-étages, pas une preuve de géométrie complète d’une pièce du film.

### 7.3. Détention et espaces communs
**Secteur :** `hybrid-cellblock` · X 1700 à 2840 · vue avec profondeur. **Contenu :** 5 assemblages / 48 composants.

**Composition :** Cellules derrière le passage ; réfectoire à l’étage ; communication ancrée à son vrai nœud.
**Logique des réseaux :** Cellules → coursive ; tables → circulation centrale ; câbles → poste haut. Cette phrase décrit l’intention visuelle ; elle n’ajoute pas une simulation de fluides.
**Exclusions et pièges :** Aucun nouveau passage dans les grilles peintes. Ne pas déplacer les communications vers une autre abscisse.

**Assemblages rattachés à la position réelle :**
- Cellules ouest — `f161-cell-a` ; support Y 510 ; X 1767–2033 ; hauteur décorative 154.
- Cellules est — `f161-cell-b` ; support Y 510 ; X 2487–2753 ; hauteur décorative 154.
- Réfectoire — `f161-mess-high` ; support Y 350 ; X 2198–2442 ; hauteur décorative 137.
- Lieu de recueillement — `f161-faith-dais-v94` ; support Y 190 ; X 2067–2293 ; hauteur décorative 133.89.
- Poste de communication — `f161-comms-high` ; support Y 350 ; X 2642–2798 ; hauteur décorative 96.24.

**Contrôle avant validation de ce secteur :** vérifier les extrémités du support dans le plan compilé ; contrôler la silhouette du personnage en marche et en saut ; vérifier que la baie ne suggère pas une couverture ; comparer l’état avant et après événement ; vérifier la sortie dans les deux sens de circulation. La vue du banc est une coupe multi-étages, pas une preuve de géométrie complète d’une pièce du film.

### 7.4. Galeries de service
**Secteur :** `hybrid-service-tunnels` · X 2840 à 3520 · vue latérale. **Contenu :** 5 assemblages / 48 composants.

**Composition :** Conduites regroupées, ventilateur distinct, maintenance et pompage séparés.
**Logique des réseaux :** Gaine → ventilateur ; pompe → vanne → collecteur. Cette phrase décrit l’intention visuelle ; elle n’ajoute pas une simulation de fluides.
**Exclusions et pièges :** Ne pas confondre pluie extérieure et vapeur intérieure. Chaque échelle conserve son débouché.

**Assemblages rattachés à la position réelle :**
- Ventilateur de maintenance — `f161-fan-shaft` ; support Y 330 ; X 2887–2993 ; hauteur décorative 61.39.
- Pompage des galeries — `f161-service-low` ; support Y 510 ; X 2957.5–3182.5 ; hauteur décorative 150.
- Entretien des réseaux — `f161-service-high` ; support Y 330 ; X 3017–3123 ; hauteur décorative 64.58.
- Alcôve des galeries — `f161-tunnel-shrine` ; support Y 630 ; X 3327–3513 ; hauteur décorative 110.19.
- Recharge des batteries — `f161-battery-locker-v94` ; support Y 330 ; X 3387–3613 ; hauteur décorative 137.69.

**Contrôle avant validation de ce secteur :** vérifier les extrémités du support dans le plan compilé ; contrôler la silhouette du personnage en marche et en saut ; vérifier que la baie ne suggère pas une couverture ; comparer l’état avant et après événement ; vérifier la sortie dans les deux sens de circulation. La vue du banc est une coupe multi-étages, pas une preuve de géométrie complète d’une pièce du film.

### 7.5. Supervision industrielle
**Secteur :** `hybrid-assembly-communications` · X 3520 à 4020 · vue avec profondeur. **Contenu :** 2 assemblages / 20 composants.

**Composition :** Poste de commande et produits de maintenance, en continuité avec les galeries.
**Logique des réseaux :** Réserve → poste de travail ; faisceau câblé → supervision. Cette phrase décrit l’intention visuelle ; elle n’ajoute pas une simulation de fluides.
**Exclusions et pièges :** Le découpage caméra hérité ne constitue pas à lui seul une pièce du film.

**Assemblages rattachés à la position réelle :**
- Réserve de produits — `f161-chemical-store` ; support Y 510 ; X 3577–3763 ; hauteur décorative 106.08.
- Supervision de la fonderie — `f161-command-post-node` ; support Y 510 ; X 3882–4038 ; hauteur décorative 96.24.

**Contrôle avant validation de ce secteur :** vérifier les extrémités du support dans le plan compilé ; contrôler la silhouette du personnage en marche et en saut ; vérifier que la baie ne suggère pas une couverture ; comparer l’état avant et après événement ; vérifier la sortie dans les deux sens de circulation. La vue du banc est une coupe multi-étages, pas une preuve de géométrie complète d’une pièce du film.

### 7.6. Fonderie
**Secteur :** `hybrid-foundry-hall` · X 4020 à 4700 · vue avec profondeur. **Contenu :** 4 assemblages / 40 composants.

**Composition :** Creuset conique avec collerette, portique, palan, poche de transfert et bac à laitier.
**Logique des réseaux :** Alimentation → creuset → transfert → moule ; eau sur sa propre conduite. Cette phrase décrit l’intention visuelle ; elle n’ajoute pas une simulation de fluides.
**Exclusions et pièges :** Pas de tuyau d’eau dessiné comme une arrivée de métal. Feu seulement dans son contenant.

**Assemblages rattachés à la position réelle :**
- Collecte des effluents — `f161-waste-tank` ; support Y 630 ; X 3957.5–4182.5 ; hauteur décorative 150.
- Creuset et transfert — `f161-leadworks` ; support Y 510 ; X 4122–4278 ; hauteur décorative 118.09.
- Alimentation du creuset — `f161-lead-primer` ; support Y 510 ; X 4302–4458 ; hauteur décorative 104.
- Collecteur d’eau supérieur — `f161-sprinkler` ; support Y 330 ; X 4447.5–4672.5 ; hauteur décorative 150.

**Contrôle avant validation de ce secteur :** vérifier les extrémités du support dans le plan compilé ; contrôler la silhouette du personnage en marche et en saut ; vérifier que la baie ne suggère pas une couverture ; comparer l’état avant et après événement ; vérifier la sortie dans les deux sens de circulation. La vue du banc est une coupe multi-étages, pas une preuve de géométrie complète d’une pièce du film.

### 7.7. Pistons et moule
**Secteur :** `hybrid-piston-mold` · X 4700 à 5180 · vue latérale. **Contenu :** 3 assemblages / 28 composants.

**Composition :** Tiges, joints et semelles lisibles ; moule bas pour laisser voir le piège.
**Logique des réseaux :** Collecteur → vérin → guidage ; réseau d’eau au-dessus, évacuation au-dessous. Cette phrase décrit l’intention visuelle ; elle n’ajoute pas une simulation de fluides.
**Exclusions et pièges :** Ne pas peindre un faux bouton utilisable. Les vraies commandes appartiennent au runtime existant.

**Assemblages rattachés à la position réelle :**
- Pistons supérieurs — `f161-piston-b-node` ; support Y 330 ; X 4742–4898 ; hauteur décorative 97.05.
- Moule de coulée — `f161-mold` ; support Y 510 ; X 4783.5–5056.5 ; hauteur décorative 143.
- Retour hydraulique — `f161-pressure-alcove-v95` ; support Y 630 ; X 4682–4878 ; hauteur décorative 130.67.

**Contrôle avant validation de ce secteur :** vérifier les extrémités du support dans le plan compilé ; contrôler la silhouette du personnage en marche et en saut ; vérifier que la baie ne suggère pas une couverture ; comparer l’état avant et après événement ; vérifier la sortie dans les deux sens de circulation. La vue du banc est une coupe multi-étages, pas une preuve de géométrie complète d’une pièce du film.

### 7.8. Four et approche
**Secteur :** `hybrid-furnace-patna` · X 5180 à 5750 · vue avec profondeur. **Contenu :** 3 assemblages / 24 composants.

**Composition :** Bouche circulaire, briques réfractaires, conduites de récupération et caillebotis.
**Logique des réseaux :** Énergie → four ; fumées → extraction ; commandes → passerelle. Cette phrase décrit l’intention visuelle ; elle n’ajoute pas une simulation de fluides.
**Exclusions et pièges :** Le matériel Patna reste absent avant l’arrivée de la Compagnie.

**Assemblages rattachés à la position réelle :**
- Four principal — `f161-furnace` ; support Y 510 ; X 5402–5558 ; hauteur décorative 110.29.
- Commande de passerelle — `f161-furnace-high` ; support Y 330 ; X 5232.5–5467.5 ; hauteur décorative 154.
- Approche de la Compagnie — `f161-parley-v93` ; support Y 510 ; X 5582–5738 ; hauteur décorative 102.23.

**Contrôle avant validation de ce secteur :** vérifier les extrémités du support dans le plan compilé ; contrôler la silhouette du personnage en marche et en saut ; vérifier que la baie ne suggère pas une couverture ; comparer l’état avant et après événement ; vérifier la sortie dans les deux sens de circulation. La vue du banc est une coupe multi-étages, pas une preuve de géométrie complète d’une pièce du film.

### 7.9. Plateforme terminale
**Secteur :** `hybrid-final-platform` · X 5750 à 6200 · vue latérale. **Contenu :** 3 assemblages / 26 composants.

**Composition :** La silhouette et le vide priment ; appareils regroupés aux appuis.
**Logique des réseaux :** Treuil → câble → plateforme ; émetteur fixé sur sa baie. Cette phrase décrit l’intention visuelle ; elle n’ajoute pas une simulation de fluides.
**Exclusions et pièges :** Aucune pluie de caisses ni gros panneau permanent devant la scène finale.

**Assemblages rattachés à la position réelle :**
- Matériel de récupération — `f161-patna-cage-node` ; support Y 510 ; X 5887–5973 ; hauteur décorative 42.85.
- Plateforme terminale — `f161-extraction` ; support Y 510 ; X 5997–6083 ; hauteur décorative 56.36.
- Émetteur de service — `f161-final-transmission-v94` ; support Y 330 ; X 6017–6183 ; hauteur décorative 102.41.

**Contrôle avant validation de ce secteur :** vérifier les extrémités du support dans le plan compilé ; contrôler la silhouette du personnage en marche et en saut ; vérifier que la baie ne suggère pas une couverture ; comparer l’état avant et après événement ; vérifier la sortie dans les deux sens de circulation. La vue du banc est une coupe multi-étages, pas une preuve de géométrie complète d’une pièce du film.

## 8. Inventaire détaillé des trente assemblages
Les coordonnées suivantes sont celles du template livré. Un vrai plan compilé peut décaler les nœuds ; les coordonnées des accessoires suivent alors ces décalages automatiquement.

### 8.1. Prise d’air côtière
**Identité :** `coast-intake` · recette `intake` · zone `f161-coast`.
**Point d’appui :** `f161-spawn` à (180, 510) ; largeur nominale 260.
**Baie :** X 87.5 à 272.5 ; pied Y 510 ; échelle 1. **Support :** `node-platform-f161-spawn`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Ventilateur `0` | 87.5 | 398 | 84 | 84 | fond de la baie |
| Gaine `1` | 167.5 | 414 | 105 | 48 | fond de la baie |
| Boîtier `2` | 230.5 | 470 | 38 | 38 | fond de la baie |
| Manomètre `3` | 194.5 | 467 | 22 | 22 | fond de la baie |
| Conduite `4` | 175.5 | 480 | 42 | 10 | fond de la baie |
| Caniveau `5` | 94.5 | 503 | 100 | 7 | sol de la baie |
| Luminaire `6` | 127.5 | 364 | 40 | 13 | structure haute |
| Faisceau `7` | 244.5 | 409 | 7 | 52 | fond de la baie |
| Appui `8` | 92.5 | 490 | 6 | 20 | sol de la baie |
| Signalétique `9` | 188.5 | 370 | 77 | 19 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.2. Épave et matériel de secours
**Identité :** `coast-wreck` · recette `eev` · zone `f161-coast`.
**Point d’appui :** `f161-eev` à (620, 510) ; largeur nominale 300.
**Baie :** X 485.5 à 754.5 ; pied Y 510 ; échelle 1. **Support :** `node-platform-f161-eev`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Coque EEV `0` | 485.5 | 396 | 236 | 114 | sol de la baie |
| Faisceau `1` | 496.5 | 471 | 80 | 12 | fond de la baie |
| Mallette `2` | 664.5 | 476 | 43 | 34 | sol de la baie |
| Caniveau `3` | 498.5 | 504 | 139 | 6 | sol de la baie |
| Luminaire `4` | 565.5 | 352 | 41 | 13 | structure haute |
| Boîtier `5` | 728.5 | 461 | 26 | 44 | fond de la baie |
| Conduite `6` | 726.5 | 405 | 10 | 45 | fond de la baie |
| Signalétique `7` | 660.5 | 367 | 72 | 20 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.3. Poste de soin
**Identité :** `medical-care` · recette `clinic` · zone `f161-infirmary`.
**Point d’appui :** `f161-infirmary` à (1120, 510) ; largeur nominale 300.
**Baie :** X 1002 à 1238 ; pied Y 510 ; échelle 1. **Support :** `node-platform-f161-infirmary`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Armoire `0` | 1002 | 411.42 | 44.81 | 98.58 | sol de la baie |
| Brancard `1` | 1067.72 | 466.19 | 105.55 | 43.81 | sol de la baie |
| Écran `2` | 1110.54 | 408.43 | 51.78 | 38.84 | fond de la baie |
| Évier `3` | 1186.22 | 452.24 | 51.78 | 57.76 | sol de la baie |
| Flacon `4` | 1010.96 | 425.36 | 5.97 | 13.94 | fond de la baie |
| Flacon `5` | 1023.91 | 425.36 | 5.97 | 13.94 | fond de la baie |
| Flacon `6` | 1194.19 | 435.32 | 5.97 | 14.94 | fond de la baie |
| Luminaire `7` | 1074.69 | 378.56 | 97.59 | 11.95 | structure haute |
| Faisceau `8` | 1159.33 | 446.27 | 7.97 | 54.77 | fond de la baie |
| Conduite `9` | 1231.03 | 419.38 | 6.97 | 21.91 | fond de la baie |
| Plateau `10` | 1085.65 | 454.24 | 46.8 | 8.96 | fond de la baie |
| Signalétique `11` | 1004.99 | 381.54 | 54.77 | 16.93 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.4. Chambre médicale
**Identité :** `clemens-room` · recette `clinic` · zone `f161-infirmary`.
**Point d’appui :** `f161-clemens-bed` à (1380, 510) ; largeur nominale 180.
**Baie :** X 1302 à 1458 ; pied Y 510 ; échelle 0.66. **Support :** `node-platform-f161-clemens-bed`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Armoire `0` | 1302 | 444.84 | 29.62 | 65.16 | sol de la baie |
| Brancard `1` | 1345.44 | 481.04 | 69.77 | 28.96 | sol de la baie |
| Écran `2` | 1373.75 | 442.86 | 34.23 | 25.67 | fond de la baie |
| Évier `3` | 1423.77 | 471.82 | 34.23 | 38.18 | sol de la baie |
| Flacon `4` | 1307.92 | 454.05 | 3.95 | 9.22 | fond de la baie |
| Flacon `5` | 1316.48 | 454.05 | 3.95 | 9.22 | fond de la baie |
| Flacon `6` | 1429.04 | 460.63 | 3.95 | 9.87 | fond de la baie |
| Luminaire `7` | 1350.05 | 423.11 | 64.51 | 7.9 | structure haute |
| Faisceau `8` | 1406 | 467.87 | 5.27 | 36.2 | fond de la baie |
| Conduite `9` | 1453.39 | 450.1 | 4.61 | 14.48 | fond de la baie |
| Plateau `10` | 1357.29 | 473.14 | 30.94 | 5.92 | fond de la baie |
| Signalétique `11` | 1303.97 | 425.09 | 36.2 | 11.19 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.5. Baie mortuaire
**Identité :** `morgue-bay` · recette `morgue` · zone `f161-infirmary`.
**Point d’appui :** `f161-morgue-high` à (1500, 350) ; largeur nominale 260.
**Baie :** X 1382 à 1618 ; pied Y 350 ; échelle 0.9. **Support :** `node-platform-f161-morgue-high`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Armoire `0` | 1382 | 271.03 | 52.05 | 78.97 | sol de la baie |
| Brancard `1` | 1458.27 | 312.31 | 98.71 | 37.69 | sol de la baie |
| Évier `2` | 1576.72 | 296.16 | 41.28 | 53.84 | sol de la baie |
| Luminaire `3` | 1463.66 | 238.73 | 77.17 | 10.77 | structure haute |
| Caniveau `4` | 1461.86 | 345.51 | 96.91 | 4.49 | sol de la baie |
| Plateau `5` | 1504.04 | 298.85 | 37.69 | 8.97 | fond de la baie |
| Boîtier `6` | 1588.39 | 256.68 | 22.43 | 21.54 | fond de la baie |
| Signalétique `7` | 1384.69 | 239.63 | 52.05 | 14.36 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.6. Cellules ouest
**Identité :** `cell-a` · recette `cell` · zone `f161-cellblock`.
**Point d’appui :** `f161-cell-a` à (1900, 510) ; largeur nominale 300.
**Baie :** X 1767 à 2033 ; pied Y 510 ; échelle 1. **Support :** `node-platform-f161-cell-a`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Cellule `0` | 1767 | 378 | 73 | 132 | sol de la baie |
| Couchette `1` | 1861 | 407 | 111 | 103 | sol de la baie |
| Lavabo `2` | 1990 | 462 | 35 | 48 | sol de la baie |
| Luminaire `3` | 1784 | 356 | 37 | 11 | structure haute |
| Couverture `4` | 1880 | 471 | 42 | 8 | fond de la baie |
| Gobelet `5` | 1965 | 499 | 8 | 11 | sol de la baie |
| Signalétique `6` | 1874 | 368 | 73 | 19 | fond de la baie |
| Conduite `7` | 2027 | 401 | 6 | 89 | fond de la baie |
| Faisceau `8` | 1779 | 368 | 234 | 5 | fond de la baie |
| Caniveau `9` | 1988 | 505 | 36 | 5 | sol de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.7. Cellules est
**Identité :** `cell-b` · recette `cell` · zone `f161-cellblock`.
**Point d’appui :** `f161-cell-b` à (2620, 510) ; largeur nominale 300.
**Baie :** X 2487 à 2753 ; pied Y 510 ; échelle 1. **Support :** `node-platform-f161-cell-b`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Cellule `0` | 2487 | 378 | 73 | 132 | sol de la baie |
| Couchette `1` | 2581 | 407 | 111 | 103 | sol de la baie |
| Lavabo `2` | 2710 | 462 | 35 | 48 | sol de la baie |
| Luminaire `3` | 2504 | 356 | 37 | 11 | structure haute |
| Couverture `4` | 2600 | 471 | 42 | 8 | fond de la baie |
| Gobelet `5` | 2685 | 499 | 8 | 11 | sol de la baie |
| Signalétique `6` | 2594 | 368 | 73 | 19 | fond de la baie |
| Conduite `7` | 2747 | 401 | 6 | 89 | fond de la baie |
| Faisceau `8` | 2499 | 368 | 234 | 5 | fond de la baie |
| Caniveau `9` | 2708 | 505 | 36 | 5 | sol de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.8. Réfectoire
**Identité :** `mess` · recette `refectory` · zone `f161-cellblock`.
**Point d’appui :** `f161-mess-high` à (2320, 350) ; largeur nominale 280.
**Baie :** X 2198 à 2442 ; pied Y 350 ; échelle 1. **Support :** `node-platform-f161-mess-high`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Table `0` | 2212 | 305 | 156 | 45 | sol de la baie |
| Banc / établi `1` | 2202 | 326 | 65 | 24 | sol de la baie |
| Banc / établi `2` | 2312 | 326 | 65 | 24 | sol de la baie |
| Gobelet `3` | 2244 | 296 | 8 | 10 | fond de la baie |
| Gobelet `4` | 2290 | 296 | 8 | 10 | fond de la baie |
| Écuelle `5` | 2324 | 299 | 21 | 7 | fond de la baie |
| Rayonnage `6` | 2388 | 241 | 53 | 109 | sol de la baie |
| Luminaire `7` | 2246 | 215 | 78 | 12 | structure haute |
| Signalétique `8` | 2389 | 213 | 53 | 17 | fond de la baie |
| Faisceau `9` | 2391 | 227 | 42 | 5 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.9. Lieu de recueillement
**Identité :** `faith` · recette `chapel` · zone `f161-cellblock`.
**Point d’appui :** `f161-faith-dais-v94` à (2180, 190) ; largeur nominale 250.
**Baie :** X 2067 à 2293 ; pied Y 190 ; échelle 0.95. **Support :** `node-platform-f161-faith-dais-v94`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Autel `0` | 2106.88 | 134.92 | 113.95 | 55.08 | sol de la baie |
| Banc / établi `1` | 2067 | 166.26 | 54.13 | 23.74 | sol de la baie |
| Banc / établi `2` | 2238.87 | 166.26 | 54.13 | 23.74 | sol de la baie |
| Bougie `3` | 2138.22 | 111.18 | 5.7 | 23.74 | fond de la baie |
| Bougie `4` | 2198.99 | 114.98 | 5.7 | 19.94 | fond de la baie |
| Livre `5` | 2168.61 | 125.43 | 22.79 | 7.6 | fond de la baie |
| Luminaire `6` | 2155.31 | 56.11 | 22.79 | 10.45 | structure haute |
| Signalétique `7` | 2108.78 | 76.05 | 112.05 | 20.89 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.10. Poste de communication
**Identité :** `actual-comms` · recette `comms` · zone `f161-cellblock`.
**Point d’appui :** `f161-comms-high` à (2720, 350) ; largeur nominale 180.
**Baie :** X 2642 à 2798 ; pied Y 350 ; échelle 0.63. **Support :** `node-platform-f161-comms-high`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Pupitre `0` | 2644.52 | 302.19 | 84.29 | 47.81 | sol de la baie |
| Rayonnage `1` | 2756.48 | 266.34 | 41.52 | 83.66 | sol de la baie |
| Écran `2` | 2652.06 | 272.63 | 32.71 | 23.9 | fond de la baie |
| Écran `3` | 2691.69 | 272.63 | 32.71 | 23.9 | fond de la baie |
| Bobine `4` | 2736.98 | 331.76 | 18.24 | 18.24 | sol de la baie |
| Boîtier `5` | 2733.21 | 281.44 | 16.98 | 18.24 | fond de la baie |
| Faisceau `6` | 2721.26 | 297.79 | 39.63 | 5.03 | fond de la baie |
| Luminaire `7` | 2652.69 | 255.65 | 28.31 | 6.29 | structure haute |
| Signalétique `8` | 2757.11 | 253.76 | 40.89 | 9.44 | fond de la baie |
| Tabouret `9` | 2683.52 | 329.87 | 15.1 | 20.13 | sol de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.11. Ventilateur de maintenance
**Identité :** `murphy-fan` · recette `fan` · zone `f161-service`.
**Point d’appui :** `f161-fan-shaft` à (2940, 330) ; largeur nominale 170.
**Baie :** X 2887 à 2993 ; pied Y 330 ; échelle 0.41. **Support :** `node-platform-f161-fan-shaft`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Ventilateur `0` | 2890.27 | 277.61 | 47.47 | 47.47 | fond de la baie |
| Gaine `1` | 2937.75 | 292.76 | 52.8 | 23.33 | fond de la baie |
| Boîtier `2` | 2969.26 | 275.16 | 13.92 | 12.69 | fond de la baie |
| Manomètre `3` | 2951.66 | 279.66 | 8.59 | 8.59 | fond de la baie |
| Vanne `4` | 2943.48 | 318.95 | 11.05 | 11.05 | fond de la baie |
| Conduite `5` | 2891.09 | 324.68 | 101.91 | 3.68 | fond de la baie |
| Caniveau `6` | 2894.37 | 327.95 | 38.47 | 2.05 | sol de la baie |
| Luminaire `7` | 2899.69 | 268.61 | 18.42 | 4.09 | structure haute |
| Grille `8` | 2967.63 | 319.77 | 21.69 | 8.59 | fond de la baie |
| Faisceau `9` | 2983.18 | 274.75 | 2.86 | 15.55 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.12. Pompage des galeries
**Identité :** `service-pump` · recette `pump` · zone `f161-service`.
**Point d’appui :** `f161-service-low` à (3070, 510) ; largeur nominale 300.
**Baie :** X 2957.5 à 3182.5 ; pied Y 510 ; échelle 1. **Support :** `node-platform-f161-service-low`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Pompe `0` | 2985.5 | 430 | 83 | 80 | sol de la baie |
| Réservoir `1` | 3122.5 | 384 | 60 | 126 | sol de la baie |
| Vanne `2` | 3086.5 | 471 | 27 | 27 | fond de la baie |
| Manomètre `3` | 3003.5 | 402 | 24 | 24 | fond de la baie |
| Conduite `4` | 3056.5 | 481 | 84 | 10 | fond de la baie |
| Conduite `5` | 3135.5 | 384 | 8 | 19 | fond de la baie |
| Boîtier `6` | 2966.5 | 448 | 23 | 25 | fond de la baie |
| Caniveau `7` | 2960.5 | 505 | 116 | 5 | sol de la baie |
| Luminaire `8` | 3056.5 | 360 | 37 | 10 | structure haute |
| Signalétique `9` | 2978.5 | 371 | 72 | 18 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.13. Entretien des réseaux
**Identité :** `service-shop` · recette `workshop` · zone `f161-service`.
**Point d’appui :** `f161-service-high` à (3070, 330) ; largeur nominale 280.
**Baie :** X 3017 à 3123 ; pied Y 330 ; échelle 0.45. **Support :** `node-platform-f161-service-high`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Banc / établi `0` | 3018.78 | 306.84 | 57.9 | 23.16 | sol de la baie |
| Rayonnage `1` | 3097.17 | 276.11 | 25.83 | 53.89 | sol de la baie |
| Panneau d’outils `2` | 3024.57 | 280.56 | 47.66 | 22.71 | fond de la baie |
| Mallette `3` | 3082.47 | 314.86 | 15.14 | 15.14 | sol de la baie |
| Luminaire `4` | 3029.92 | 268.09 | 35.18 | 4.9 | structure haute |
| Boîtier `5` | 3082.92 | 282.79 | 12.03 | 14.7 | fond de la baie |
| Bobine `6` | 3101.18 | 309.51 | 13.36 | 13.36 | fond de la baie |
| Conduite `7` | 3021.45 | 272.99 | 96.2 | 2.67 | fond de la baie |
| Signalétique `8` | 3082.03 | 265.42 | 35.63 | 7.57 | fond de la baie |
| Plateau `9` | 3045.5 | 301.05 | 14.25 | 4.45 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.14. Alcôve des galeries
**Identité :** `deep-shrine` · recette `chapel` · zone `f161-service`.
**Point d’appui :** `f161-tunnel-shrine` à (3420, 630) ; largeur nominale 210.
**Baie :** X 3327 à 3513 ; pied Y 630 ; échelle 0.78. **Support :** `node-platform-f161-tunnel-shrine`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Autel `0` | 3359.82 | 584.67 | 93.78 | 45.33 | sol de la baie |
| Banc / établi `1` | 3327 | 610.46 | 44.55 | 19.54 | sol de la baie |
| Banc / établi `2` | 3468.45 | 610.46 | 44.55 | 19.54 | sol de la baie |
| Bougie `3` | 3385.61 | 565.13 | 4.69 | 19.54 | fond de la baie |
| Bougie `4` | 3435.63 | 568.26 | 4.69 | 16.41 | fond de la baie |
| Livre `5` | 3410.62 | 576.86 | 18.76 | 6.25 | fond de la baie |
| Luminaire `6` | 3399.68 | 519.81 | 18.76 | 8.6 | structure haute |
| Signalétique `7` | 3361.39 | 536.22 | 92.22 | 17.19 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.15. Recharge des batteries
**Identité :** `battery-store` · recette `workshop` · zone `f161-service`.
**Point d’appui :** `f161-battery-locker-v94` à (3500, 330) ; largeur nominale 250.
**Baie :** X 3387 à 3613 ; pied Y 330 ; échelle 0.95. **Support :** `node-platform-f161-battery-locker-v94`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Banc / établi `0` | 3390.8 | 280.62 | 123.45 | 49.38 | sol de la baie |
| Rayonnage `1` | 3557.92 | 215.1 | 55.08 | 114.9 | sol de la baie |
| Panneau d’outils `2` | 3403.14 | 224.6 | 101.61 | 48.43 | fond de la baie |
| Mallette `3` | 3526.59 | 297.71 | 32.29 | 32.29 | sol de la baie |
| Luminaire `4` | 3414.54 | 198.01 | 75.02 | 10.45 | structure haute |
| Boîtier `5` | 3527.54 | 229.34 | 25.64 | 31.34 | fond de la baie |
| Bobine `6` | 3566.47 | 286.32 | 28.49 | 28.49 | fond de la baie |
| Conduite `7` | 3396.5 | 208.45 | 205.11 | 5.7 | fond de la baie |
| Signalétique `8` | 3525.64 | 192.31 | 75.97 | 16.14 | fond de la baie |
| Plateau `9` | 3447.77 | 268.28 | 30.39 | 9.5 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.16. Réserve de produits
**Identité :** `chemical-store` · recette `store` · zone `f161-service`.
**Point d’appui :** `f161-chemical-store` à (3670, 510) ; largeur nominale 210.
**Baie :** X 3577 à 3763 ; pied Y 510 ; échelle 0.71. **Support :** `node-platform-f161-chemical-store`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Rayonnage `0` | 3577 | 423.01 | 53.04 | 86.99 | sol de la baie |
| Fût `1` | 3650.55 | 460.49 | 27.58 | 49.51 | sol de la baie |
| Fût `2` | 3687.33 | 460.49 | 27.58 | 49.51 | sol de la baie |
| Mallette `3` | 3727.64 | 485.95 | 30.41 | 24.05 | sol de la baie |
| Luminaire `4` | 3644.89 | 403.92 | 31.12 | 7.07 | structure haute |
| Grille `5` | 3657.62 | 421.6 | 57.29 | 22.63 | fond de la baie |
| Vanne `6` | 3747.44 | 445.64 | 15.56 | 15.56 | fond de la baie |
| Conduite `7` | 3627.21 | 437.86 | 30.41 | 4.95 | fond de la baie |
| Signalétique `8` | 3583.37 | 405.33 | 47.38 | 11.32 | fond de la baie |
| Caniveau `9` | 3644.89 | 506.46 | 79.21 | 3.54 | sol de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.17. Supervision de la fonderie
**Identité :** `command` · recette `comms` · zone `f161-leadworks`.
**Point d’appui :** `f161-command-post-node` à (3960, 510) ; largeur nominale 180.
**Baie :** X 3882 à 4038 ; pied Y 510 ; échelle 0.63. **Support :** `node-platform-f161-command-post-node`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Pupitre `0` | 3884.52 | 462.19 | 84.29 | 47.81 | sol de la baie |
| Rayonnage `1` | 3996.48 | 426.34 | 41.52 | 83.66 | sol de la baie |
| Écran `2` | 3892.06 | 432.63 | 32.71 | 23.9 | fond de la baie |
| Écran `3` | 3931.69 | 432.63 | 32.71 | 23.9 | fond de la baie |
| Bobine `4` | 3976.98 | 491.76 | 18.24 | 18.24 | sol de la baie |
| Boîtier `5` | 3973.21 | 441.44 | 16.98 | 18.24 | fond de la baie |
| Faisceau `6` | 3961.26 | 457.79 | 39.63 | 5.03 | fond de la baie |
| Luminaire `7` | 3892.69 | 415.65 | 28.31 | 6.29 | structure haute |
| Signalétique `8` | 3997.11 | 413.76 | 40.89 | 9.44 | fond de la baie |
| Tabouret `9` | 3923.52 | 489.87 | 15.1 | 20.13 | sol de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.18. Collecte des effluents
**Identité :** `waste` · recette `pump` · zone `f161-leadworks`.
**Point d’appui :** `f161-waste-tank` à (4070, 630) ; largeur nominale 310.
**Baie :** X 3957.5 à 4182.5 ; pied Y 630 ; échelle 1. **Support :** `node-platform-f161-waste-tank`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Pompe `0` | 3985.5 | 550 | 83 | 80 | sol de la baie |
| Réservoir `1` | 4122.5 | 504 | 60 | 126 | sol de la baie |
| Vanne `2` | 4086.5 | 591 | 27 | 27 | fond de la baie |
| Manomètre `3` | 4003.5 | 522 | 24 | 24 | fond de la baie |
| Conduite `4` | 4056.5 | 601 | 84 | 10 | fond de la baie |
| Conduite `5` | 4135.5 | 504 | 8 | 19 | fond de la baie |
| Boîtier `6` | 3966.5 | 568 | 23 | 25 | fond de la baie |
| Caniveau `7` | 3960.5 | 625 | 116 | 5 | sol de la baie |
| Luminaire `8` | 4056.5 | 480 | 37 | 10 | structure haute |
| Signalétique `9` | 3978.5 | 491 | 72 | 18 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.19. Creuset et transfert
**Identité :** `leadworks` · recette `smelter` · zone `f161-leadworks`.
**Point d’appui :** `f161-leadworks` à (4200, 510) ; largeur nominale 340.
**Baie :** X 4122 à 4278 ; pied Y 510 ; échelle 0.62. **Support :** `node-platform-f161-leadworks`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Creuset `0` | 4151.83 | 424.85 | 72.1 | 85.15 | sol de la baie |
| Portique `1` | 4127.59 | 406.21 | 133.63 | 103.79 | sol de la baie |
| Palan `2` | 4174.83 | 414.29 | 29.83 | 40.4 | structure haute |
| Poche de transfert `3` | 4242.57 | 441.63 | 35.43 | 68.37 | sol de la baie |
| Manomètre `4` | 4128.22 | 475.2 | 14.29 | 14.29 | fond de la baie |
| Conduite `5` | 4127.59 | 489.49 | 26.1 | 6.22 | fond de la baie |
| Bac à laitier `6` | 4240.09 | 490.11 | 25.48 | 19.89 | sol de la baie |
| Luminaire `7` | 4241.95 | 391.91 | 19.89 | 7.46 | structure haute |
| Signalétique `8` | 4150.59 | 397.51 | 49.72 | 11.19 | fond de la baie |
| Grille `9` | 4194.1 | 505.65 | 26.1 | 4.35 | sol de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.20. Alimentation du creuset
**Identité :** `lead-primer` · recette `pump` · zone `f161-leadworks`.
**Point d’appui :** `f161-lead-primer` à (4380, 510) ; largeur nominale 190.
**Baie :** X 4302 à 4458 ; pied Y 510 ; échelle 0.69. **Support :** `node-platform-f161-lead-primer`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Pompe `0` | 4321.41 | 454.53 | 57.55 | 55.47 | sol de la baie |
| Réservoir `1` | 4416.4 | 422.64 | 41.6 | 87.36 | sol de la baie |
| Vanne `2` | 4391.44 | 482.96 | 18.72 | 18.72 | fond de la baie |
| Manomètre `3` | 4333.89 | 435.12 | 16.64 | 16.64 | fond de la baie |
| Conduite `4` | 4370.64 | 489.89 | 58.24 | 6.93 | fond de la baie |
| Conduite `5` | 4425.41 | 422.64 | 5.55 | 13.17 | fond de la baie |
| Boîtier `6` | 4308.24 | 467.01 | 15.95 | 17.33 | fond de la baie |
| Caniveau `7` | 4304.08 | 506.53 | 80.43 | 3.47 | sol de la baie |
| Luminaire `8` | 4370.64 | 406 | 25.65 | 6.93 | structure haute |
| Signalétique `9` | 4316.56 | 413.63 | 49.92 | 12.48 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.21. Collecteur d’eau supérieur
**Identité :** `water-header` · recette `pump` · zone `f161-leadworks`.
**Point d’appui :** `f161-sprinkler` à (4560, 330) ; largeur nominale 280.
**Baie :** X 4447.5 à 4672.5 ; pied Y 330 ; échelle 1. **Support :** `node-platform-f161-sprinkler`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Pompe `0` | 4475.5 | 250 | 83 | 80 | sol de la baie |
| Réservoir `1` | 4612.5 | 204 | 60 | 126 | sol de la baie |
| Vanne `2` | 4576.5 | 291 | 27 | 27 | fond de la baie |
| Manomètre `3` | 4493.5 | 222 | 24 | 24 | fond de la baie |
| Conduite `4` | 4546.5 | 301 | 84 | 10 | fond de la baie |
| Conduite `5` | 4625.5 | 204 | 8 | 19 | fond de la baie |
| Boîtier `6` | 4456.5 | 268 | 23 | 25 | fond de la baie |
| Caniveau `7` | 4450.5 | 325 | 116 | 5 | sol de la baie |
| Luminaire `8` | 4546.5 | 180 | 37 | 10 | structure haute |
| Signalétique `9` | 4468.5 | 191 | 72 | 18 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.22. Pistons supérieurs
**Identité :** `piston-upper` · recette `pistons` · zone `f161-leadworks`.
**Point d’appui :** `f161-piston-b-node` à (4820, 330) ; largeur nominale 180.
**Baie :** X 4742 à 4898 ; pied Y 330 ; échelle 0.6. **Support :** `node-platform-f161-piston-b-node`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Vérin `0` | 4750.34 | 258.55 | 34.53 | 71.45 | sol de la baie |
| Vérin `1` | 4806.9 | 258.55 | 34.53 | 71.45 | sol de la baie |
| Vérin `2` | 4863.47 | 258.55 | 34.53 | 71.45 | sol de la baie |
| Conduite `3` | 4747.36 | 247.83 | 149.45 | 6.55 | fond de la baie |
| Manomètre `4` | 4848.58 | 288.32 | 13.69 | 13.69 | fond de la baie |
| Vanne `5` | 4787.25 | 298.44 | 14.29 | 14.29 | fond de la baie |
| Boîtier `6` | 4789.63 | 265.69 | 13.69 | 16.67 | fond de la baie |
| Luminaire `7` | 4810.47 | 235.33 | 25.01 | 6.55 | structure haute |
| Signalétique `8` | 4749.15 | 232.95 | 44.66 | 10.72 | fond de la baie |
| Caniveau `9` | 4787.85 | 327.02 | 75.02 | 2.98 | sol de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.23. Moule de coulée
**Identité :** `mold` · recette `mold` · zone `f161-leadworks`.
**Point d’appui :** `f161-mold` à (4920, 510) ; largeur nominale 360.
**Baie :** X 4783.5 à 5056.5 ; pied Y 510 ; échelle 1. **Support :** `node-platform-f161-mold`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Moule `0` | 4787.5 | 468 | 231 | 42 | sol de la baie |
| Conduite `1` | 4807.5 | 414 | 195 | 9 | fond de la baie |
| Vanne `2` | 4997.5 | 414 | 26 | 26 | fond de la baie |
| Manomètre `3` | 4793.5 | 421 | 23 | 23 | fond de la baie |
| Luminaire `4` | 4840.5 | 367 | 105 | 12 | structure haute |
| Grille `5` | 4787.5 | 501 | 229 | 9 | sol de la baie |
| Signalétique `6` | 4861.5 | 391 | 91 | 20 | fond de la baie |
| Boîtier `7` | 5032.5 | 439 | 24 | 37 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.24. Retour hydraulique
**Identité :** `lower-pressure` · recette `pump` · zone `f161-leadworks`.
**Point d’appui :** `f161-pressure-alcove-v95` à (4780, 630) ; largeur nominale 220.
**Baie :** X 4682 à 4878 ; pied Y 630 ; échelle 0.87. **Support :** `node-platform-f161-pressure-alcove-v95`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Pompe `0` | 4706.39 | 560.31 | 72.3 | 69.69 | sol de la baie |
| Réservoir `1` | 4825.73 | 520.24 | 52.27 | 109.76 | sol de la baie |
| Vanne `2` | 4794.37 | 596.03 | 23.52 | 23.52 | fond de la baie |
| Manomètre `3` | 4722.07 | 535.92 | 20.91 | 20.91 | fond de la baie |
| Conduite `4` | 4768.24 | 604.74 | 73.17 | 8.71 | fond de la baie |
| Conduite `5` | 4837.06 | 520.24 | 6.97 | 16.55 | fond de la baie |
| Boîtier `6` | 4689.84 | 575.99 | 20.04 | 21.78 | fond de la baie |
| Caniveau `7` | 4684.61 | 625.64 | 101.05 | 4.36 | sol de la baie |
| Luminaire `8` | 4768.24 | 499.33 | 32.23 | 8.71 | structure haute |
| Signalétique `9` | 4700.29 | 508.92 | 62.72 | 15.68 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.25. Four principal
**Identité :** `main-furnace` · recette `furnace` · zone `f161-furnace`.
**Point d’appui :** `f161-furnace` à (5480, 510) ; largeur nominale 340.
**Baie :** X 5402 à 5558 ; pied Y 510 ; échelle 0.57. **Support :** `node-platform-f161-furnace`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Four `0` | 5414.57 | 406 | 101.71 | 104 | sol de la baie |
| Conduite `1` | 5524.86 | 437.43 | 8 | 65.71 | fond de la baie |
| Manomètre `2` | 5522.57 | 454 | 14.29 | 14.29 | fond de la baie |
| Bac à laitier `3` | 5538 | 490 | 20 | 20 | sol de la baie |
| Luminaire `4` | 5408.86 | 399.71 | 20.57 | 6.29 | structure haute |
| Signalétique `5` | 5526.57 | 418.57 | 27.43 | 10.86 | fond de la baie |
| Grille `6` | 5412.29 | 503.14 | 105.71 | 6.86 | sol de la baie |
| Boîtier `7` | 5539.71 | 459.14 | 13.14 | 20.57 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.26. Commande de passerelle
**Identité :** `furnace-gantry` · recette `landing` · zone `f161-furnace`.
**Point d’appui :** `f161-furnace-high` à (5350, 330) ; largeur nominale 280.
**Baie :** X 5232.5 à 5467.5 ; pied Y 330 ; échelle 1. **Support :** `node-platform-f161-furnace-high`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Treuil `0` | 5270.5 | 262 | 80 | 68 | sol de la baie |
| Boîtier `1` | 5381.5 | 231 | 36 | 51 | fond de la baie |
| Conduite `2` | 5255.5 | 214 | 210 | 9 | fond de la baie |
| Vanne `3` | 5441.5 | 215 | 26 | 26 | fond de la baie |
| Luminaire `4` | 5371.5 | 176 | 38 | 11 | structure haute |
| Grille `5` | 5256.5 | 322 | 139 | 8 | sol de la baie |
| Signalétique `6` | 5258.5 | 180 | 74 | 19 | fond de la baie |
| Appui `7` | 5355.5 | 306 | 12 | 24 | sol de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.27. Approche de la Compagnie
**Identité :** `parley` · recette `landing` · zone `f161-furnace`.
**Point d’appui :** `f161-parley-v93` à (5660, 510) ; largeur nominale 180.
**Baie :** X 5582 à 5738 ; pied Y 510 ; échelle 0.66. **Support :** `node-platform-f161-parley-v93`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Treuil `0` | 5607.23 | 464.86 | 53.11 | 45.14 | sol de la baie |
| Boîtier `1` | 5680.91 | 444.28 | 23.9 | 33.86 | fond de la baie |
| Conduite `2` | 5597.27 | 433 | 139.4 | 5.97 | fond de la baie |
| Vanne `3` | 5720.74 | 433.66 | 17.26 | 17.26 | fond de la baie |
| Luminaire `4` | 5674.27 | 407.77 | 25.23 | 7.3 | structure haute |
| Grille `5` | 5597.93 | 504.69 | 92.27 | 5.31 | sol de la baie |
| Signalétique `6` | 5599.26 | 410.43 | 49.12 | 12.61 | fond de la baie |
| Appui `7` | 5663.65 | 494.07 | 7.97 | 15.93 | sol de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.28. Matériel de récupération
**Identité :** `patna-kit` · recette `company` · zone `f161-furnace`.
**Point d’appui :** `f161-patna-cage-node` à (5930, 510) ; largeur nominale 160.
**Baie :** X 5887 à 5973 ; pied Y 510 ; échelle 0.31. **Support :** `node-platform-f161-patna-cage-node`.
**Présence :** uniquement après arrivée de la Compagnie. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Cage de récupération `0` | 5893.16 | 467.15 | 39.76 | 42.85 | sol de la baie |
| Mallette `1` | 5939.4 | 497.98 | 20.65 | 12.02 | sol de la baie |
| Projecteur sur pied `2` | 5964.68 | 467.15 | 8.32 | 42.85 | sol de la baie |
| Écran `3` | 5941.25 | 486.27 | 13.25 | 9.25 | fond de la baie |
| Faisceau `4` | 5930.15 | 505.99 | 14.8 | 2.47 | fond de la baie |
| Signalétique `5` | 5939.09 | 475.78 | 23.43 | 6.16 | fond de la baie |
| Mallette `6` | 5887.31 | 499.83 | 10.79 | 10.17 | sol de la baie |
| Bride `7` | 5908.89 | 485.65 | 8.01 | 8.32 | fond de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.29. Plateforme terminale
**Identité :** `final-landing` · recette `landing` · zone `f161-furnace`.
**Point d’appui :** `f161-extraction` à (6040, 510) ; largeur nominale 300.
**Baie :** X 5997 à 6083 ; pied Y 510 ; échelle 0.37. **Support :** `node-platform-f161-extraction`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Treuil `0` | 6010.91 | 485.11 | 29.28 | 24.89 | sol de la baie |
| Boîtier `1` | 6051.53 | 473.77 | 13.17 | 18.66 | fond de la baie |
| Conduite `2` | 6005.42 | 467.55 | 76.85 | 3.29 | fond de la baie |
| Vanne `3` | 6073.49 | 467.91 | 9.51 | 9.51 | fond de la baie |
| Luminaire `4` | 6047.87 | 453.64 | 13.91 | 4.03 | structure haute |
| Grille `5` | 6005.78 | 507.07 | 50.87 | 2.93 | sol de la baie |
| Signalétique `6` | 6006.51 | 455.11 | 27.08 | 6.95 | fond de la baie |
| Appui `7` | 6042.01 | 501.22 | 4.39 | 8.78 | sol de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

### 8.30. Émetteur de service
**Identité :** `final-transmitter` · recette `comms` · zone `f161-furnace`.
**Point d’appui :** `f161-final-transmission-v94` à (6100, 330) ; largeur nominale 190.
**Baie :** X 6017 à 6183 ; pied Y 330 ; échelle 0.67. **Support :** `node-platform-f161-final-transmission-v94`.
**Présence :** permanente dans cette couche. **Rendu :** fond d’alcôve, derrière les acteurs. **Collision :** aucune nouvelle collision.

| Composant | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| Pupitre `0` | 6019.68 | 279.13 | 89.69 | 50.87 | sol de la baie |
| Rayonnage `1` | 6138.82 | 240.98 | 44.18 | 89.02 | sol de la baie |
| Écran `2` | 6027.71 | 247.67 | 34.81 | 25.44 | fond de la baie |
| Écran `3` | 6069.88 | 247.67 | 34.81 | 25.44 | fond de la baie |
| Bobine `4` | 6118.07 | 310.59 | 19.41 | 19.41 | sol de la baie |
| Boîtier `5` | 6114.06 | 257.04 | 18.07 | 19.41 | fond de la baie |
| Faisceau `6` | 6101.34 | 274.44 | 42.17 | 5.35 | fond de la baie |
| Luminaire `7` | 6028.38 | 229.6 | 30.12 | 6.69 | structure haute |
| Signalétique `8` | 6139.49 | 227.59 | 43.51 | 10.04 | fond de la baie |
| Tabouret `9` | 6061.18 | 308.58 | 16.06 | 21.42 | sol de la baie |

**Lecture et entretien :** le meuble ou la machine principale doit rester identifiable avant les petits raccords. La baie sert de plan de fixation aux éléments muraux. Les composants posés au sol sont contrôlés à la hauteur du support ; les éléments muraux/hauts exigent encore un examen visuel de leur fixation. Aucun composant n’autorise à lui seul une action de jeu.

## 9. Répertoire des points du graphe
Les 72 fiches ci-dessous documentent des points de circulation ou d’action hérités. Elles ne comptabilisent pas 72 nouvelles salles. Toutes les connexions de cette section sont conservées, non créées par la décoration.

### 9.1. f161-spawn
**Zone :** `f161-coast` · coordonnées (180, 510) · largeur 260 · ancre de jeu : spawn.
**Décor V102 :** Prise d’air côtière
- `f161-eev` : `walk` · ΔX 440 · ΔY 0 · connexion `f161-e01`.

### 9.2. f161-eev
**Zone :** `f161-coast` · coordonnées (620, 510) · largeur 300 · ancre de jeu : archive.
**Décor V102 :** Épave et matériel de secours
- `f161-spawn` : `walk` · ΔX -440 · ΔY 0 · connexion `f161-e01`.
- `f161-infirmary` : `walk` · ΔX 500 · ΔY 0 · connexion `f161-e02`.
- `f161-flight-analysis-v94` : `ladder` · ΔX 160 · ΔY -180 · connexion `f161-e89`.
- `f161-wreckage-incident-v94` : `ladder` · ΔX 200 · ΔY 120 · connexion `f161-e91`.

### 9.3. f161-infirmary
**Zone :** `f161-infirmary` · coordonnées (1120, 510) · largeur 300 · ancre de jeu : aucune.
**Décor V102 :** Poste de soin
- `f161-eev` : `walk` · ΔX -500 · ΔY 0 · connexion `f161-e02`.
- `f161-cell-a` : `gate` · ΔX 780 · ΔY 0 · connexion `f161-e03`.
- `f161-morgue-high` : `ladder` · ΔX 380 · ΔY -160 · connexion `f161-e12`.
- `f161-service-deep` : `vent` · ΔX 1950 · ΔY 120 · connexion `f161-e19`.
- `f161-clemens-bed` : `walk` · ΔX 260 · ΔY 0 · connexion `f161-e46`.
- `f161-wreckage-incident-v94` : `ladder` · ΔX -300 · ΔY 120 · connexion `f161-e92`.

### 9.4. f161-morgue-high
**Zone :** `f161-infirmary` · coordonnées (1500, 350) · largeur 260 · ancre de jeu : aucune.
**Décor V102 :** Baie mortuaire
- `f161-infirmary` : `ladder` · ΔX -380 · ΔY 160 · connexion `f161-e12`.
- `f161-mess-high` : `walk` · ΔX 820 · ΔY 0 · connexion `f161-e13`.
- `f161-funeral-walk` : `ladder` · ΔX 80 · ΔY 160 · connexion `f161-e48`.
- `f161-master-archive-node` : `walk` · ΔX -240 · ΔY 0 · connexion `f161-e62`.
- `f161-flight-analysis-v94` : `walk` · ΔX -720 · ΔY -20 · connexion `f161-e90`.

### 9.5. f161-cell-a
**Zone :** `f161-cellblock` · coordonnées (1900, 510) · largeur 300 · ancre de jeu : aucune.
**Décor V102 :** Cellules ouest
- `f161-infirmary` : `gate` · ΔX -780 · ΔY 0 · connexion `f161-e03`.
- `f161-mess-high` : `ladder` · ΔX 420 · ΔY -160 · connexion `f161-e23`.
- `f161-assembly-hall` : `walk` · ΔX 400 · ΔY 0 · connexion `f161-e27`.
- `f161-shelter-cell-v95` : `ladder` · ΔX 150 · ΔY 120 · connexion `f161-e104`.

### 9.6. f161-mess-high
**Zone :** `f161-cellblock` · coordonnées (2320, 350) · largeur 280 · ancre de jeu : aucune.
**Décor V102 :** Réfectoire
- `f161-morgue-high` : `walk` · ΔX -820 · ΔY 0 · connexion `f161-e13`.
- `f161-service-high` : `walk` · ΔX 750 · ΔY -20 · connexion `f161-e14`.
- `f161-cell-a` : `ladder` · ΔX -420 · ΔY 160 · connexion `f161-e23`.
- `f161-assembly-hall` : `ladder` · ΔX -20 · ΔY 160 · connexion `f161-e29`.
- `f161-mess-ceiling` : `walk` · ΔX 150 · ΔY 0 · connexion `f161-e49`.
- `f161-faith-dais-v94` : `ladder` · ΔX -140 · ΔY -160 · connexion `f161-e93`.

### 9.7. f161-cell-b
**Zone :** `f161-cellblock` · coordonnées (2620, 510) · largeur 300 · ancre de jeu : aucune.
**Décor V102 :** Cellules est
- `f161-service-low` : `gate` · ΔX 450 · ΔY 0 · connexion `f161-e05`.
- `f161-assembly-hall` : `walk` · ΔX -320 · ΔY 0 · connexion `f161-e28`.
- `f161-shutter-cell-node` : `walk` · ΔX 120 · ΔY 0 · connexion `f161-e63`.

### 9.8. f161-service-low
**Zone :** `f161-service` · coordonnées (3070, 510) · largeur 300 · ancre de jeu : aucune.
**Décor V102 :** Pompage des galeries
- `f161-cell-b` : `gate` · ΔX -450 · ΔY 0 · connexion `f161-e05`.
- `f161-bishop` : `walk` · ΔX 430 · ΔY 0 · connexion `f161-e06`.
- `f161-service-high` : `ladder` · ΔX 0 · ΔY -180 · connexion `f161-e24`.
- `f161-service-deep` : `ladder` · ΔX 0 · ΔY 120 · connexion `f161-e25`.
- `f161-fuel-manifold-a` : `walk` · ΔX -110 · ΔY 0 · connexion `f161-e35`.
- `f161-rescue-post-node` : `walk` · ΔX 260 · ΔY 0 · connexion `f161-e67`.

### 9.9. f161-service-high
**Zone :** `f161-service` · coordonnées (3070, 330) · largeur 280 · ancre de jeu : aucune.
**Décor V102 :** Entretien des réseaux
- `f161-mess-high` : `walk` · ΔX -750 · ΔY 20 · connexion `f161-e14`.
- `f161-tunnel-high` : `walk` · ΔX 750 · ΔY 0 · connexion `f161-e15`.
- `f161-service-low` : `ladder` · ΔX 0 · ΔY 180 · connexion `f161-e24`.
- `f161-fan-shaft` : `walk` · ΔX -130 · ΔY 0 · connexion `f161-e51`.
- `f161-steam-service-node` : `walk` · ΔX 120 · ΔY 0 · connexion `f161-e65`.
- `f161-perch-service-v93` : `ladder` · ΔX 240 · ΔY -140 · connexion `f161-e80`.
- `f161-battery-locker-v94` : `walk` · ΔX 430 · ΔY 0 · connexion `f161-e95`.
- `f161-hunt-service-v95` : `walk` · ΔX 300 · ΔY 0 · connexion `f161-e110`.

### 9.10. f161-service-deep
**Zone :** `f161-service` · coordonnées (3070, 630) · largeur 280 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-infirmary` : `vent` · ΔX -1950 · ΔY -120 · connexion `f161-e19`.
- `f161-tunnel-low` : `walk` · ΔX 750 · ΔY 0 · connexion `f161-e20`.
- `f161-service-low` : `ladder` · ΔX 0 · ΔY -120 · connexion `f161-e25`.
- `f161-tunnel-shrine` : `walk` · ΔX 350 · ΔY 0 · connexion `f161-e52`.
- `f161-refuge-service-v95` : `walk` · ΔX -80 · ΔY 0 · connexion `f161-e108`.

### 9.11. f161-bishop
**Zone :** `f161-service` · coordonnées (3500, 510) · largeur 300 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-service-low` : `walk` · ΔX -430 · ΔY 0 · connexion `f161-e06`.
- `f161-leadworks` : `gate` · ΔX 700 · ΔY 0 · connexion `f161-e07`.
- `f161-fuel-manifold-b` : `walk` · ΔX -260 · ΔY 0 · connexion `f161-e37`.
- `f161-chemical-store` : `walk` · ΔX 170 · ΔY 0 · connexion `f161-e38`.
- `f161-tunnel-shrine` : `ladder` · ΔX -80 · ΔY 120 · connexion `f161-e53`.
- `f161-rescue-post-node` : `walk` · ΔX -170 · ΔY 0 · connexion `f161-e68`.
- `f161-shutter-service-node` : `walk` · ΔX 150 · ΔY 0 · connexion `f161-e69`.

### 9.12. f161-tunnel-high
**Zone :** `f161-leadworks` · coordonnées (3820, 330) · largeur 280 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-service-high` : `walk` · ΔX -750 · ΔY 0 · connexion `f161-e15`.
- `f161-sprinkler` : `walk` · ΔX 740 · ΔY 0 · connexion `f161-e16`.
- `f161-chemical-store` : `ladder` · ΔX -150 · ΔY 180 · connexion `f161-e39`.
- `f161-command-post-node` : `ladder` · ΔX 140 · ΔY 180 · connexion `f161-e71`.
- `f161-battery-locker-v94` : `walk` · ΔX -320 · ΔY 0 · connexion `f161-e96`.
- `f161-battery-junction-v94` : `walk` · ΔX 200 · ΔY 0 · connexion `f161-e99`.

### 9.13. f161-tunnel-low
**Zone :** `f161-leadworks` · coordonnées (3820, 630) · largeur 280 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-service-deep` : `walk` · ΔX -750 · ΔY 0 · connexion `f161-e20`.
- `f161-leadworks` : `ladder` · ΔX 380 · ΔY -120 · connexion `f161-e21`.
- `f161-waste-tank` : `walk` · ΔX 250 · ΔY 0 · connexion `f161-e30`.
- `f161-golic-cache-v94` : `walk` · ΔX -160 · ΔY 0 · connexion `f161-e98`.
- `f161-hunt-junction-v95` : `walk` · ΔX 80 · ΔY 0 · connexion `f161-e114`.

### 9.14. f161-leadworks
**Zone :** `f161-leadworks` · coordonnées (4200, 510) · largeur 340 · ancre de jeu : power.
**Décor V102 :** Creuset et transfert
- `f161-bishop` : `gate` · ΔX -700 · ΔY 0 · connexion `f161-e07`.
- `f161-mold` : `walk` · ΔX 720 · ΔY 0 · connexion `f161-e08`.
- `f161-tunnel-low` : `ladder` · ΔX -380 · ΔY 120 · connexion `f161-e21`.
- `f161-furnace` : `vent` · ΔX 1280 · ΔY 0 · connexion `f161-e22`.
- `f161-sprinkler` : `ladder` · ΔX 360 · ΔY -180 · connexion `f161-e26`.
- `f161-sluice-low` : `ladder` · ΔX 300 · ΔY 120 · connexion `f161-e32`.
- `f161-lead-primer` : `walk` · ΔX 180 · ΔY 0 · connexion `f161-e40`.
- `f161-piston-a-node` : `walk` · ΔX 280 · ΔY 0 · connexion `f161-e54`.
- `f161-command-post-node` : `walk` · ΔX -240 · ΔY 0 · connexion `f161-e72`.

### 9.15. f161-sprinkler
**Zone :** `f161-leadworks` · coordonnées (4560, 330) · largeur 280 · ancre de jeu : aucune.
**Décor V102 :** Collecteur d’eau supérieur
- `f161-tunnel-high` : `walk` · ΔX -740 · ΔY 0 · connexion `f161-e16`.
- `f161-furnace-high` : `walk` · ΔX 790 · ΔY 0 · connexion `f161-e17`.
- `f161-leadworks` : `ladder` · ΔX -360 · ΔY 180 · connexion `f161-e26`.
- `f161-water-header` : `walk` · ΔX 130 · ΔY 0 · connexion `f161-e42`.
- `f161-piston-b-node` : `walk` · ΔX 260 · ΔY 0 · connexion `f161-e56`.
- `f161-bait-switch-v95` : `walk` · ΔX -240 · ΔY 0 · connexion `f161-e117`.

### 9.16. f161-mold
**Zone :** `f161-leadworks` · coordonnées (4920, 510) · largeur 360 · ancre de jeu : objective-primary.
**Décor V102 :** Moule de coulée
- `f161-leadworks` : `walk` · ΔX -720 · ΔY 0 · connexion `f161-e08`.
- `f161-furnace` : `walk` · ΔX 560 · ΔY 0 · connexion `f161-e09`.
- `f161-lead-primer` : `walk` · ΔX -540 · ΔY 0 · connexion `f161-e41`.
- `f161-water-header` : `ladder` · ΔX -230 · ΔY -180 · connexion `f161-e43`.
- `f161-piston-a-node` : `walk` · ΔX -440 · ΔY 0 · connexion `f161-e55`.
- `f161-piston-b-node` : `ladder` · ΔX -100 · ΔY -180 · connexion `f161-e57`.
- `f161-piston-c-node` : `walk` · ΔX 220 · ΔY 0 · connexion `f161-e58`.
- `f161-shutter-foundry-node` : `walk` · ΔX 130 · ΔY 0 · connexion `f161-e75`.
- `f161-chase-reroute-v94` : `ladder` · ΔX 130 · ΔY 120 · connexion `f161-e101`.

### 9.17. f161-furnace-high
**Zone :** `f161-furnace` · coordonnées (5350, 330) · largeur 280 · ancre de jeu : aucune.
**Décor V102 :** Commande de passerelle
- `f161-sprinkler` : `walk` · ΔX -790 · ΔY 0 · connexion `f161-e17`.
- `f161-furnace` : `ladder` · ΔX 130 · ΔY 180 · connexion `f161-e18`.
- `f161-furnace-gantry` : `walk` · ΔX 390 · ΔY 0 · connexion `f161-e33`.
- `f161-furnace-overlook` : `walk` · ΔX 230 · ΔY 0 · connexion `f161-e44`.
- `f161-chase-observer-v95` : `walk` · ΔX -70 · ΔY 0 · connexion `f161-e119`.

### 9.18. f161-furnace
**Zone :** `f161-furnace` · coordonnées (5480, 510) · largeur 340 · ancre de jeu : boss.
**Décor V102 :** Four principal
- `f161-mold` : `walk` · ΔX -560 · ΔY 0 · connexion `f161-e09`.
- `f161-company` : `walk` · ΔX 320 · ΔY 0 · connexion `f161-e10`.
- `f161-furnace-high` : `ladder` · ΔX -130 · ΔY -180 · connexion `f161-e18`.
- `f161-leadworks` : `vent` · ΔX -1280 · ΔY 0 · connexion `f161-e22`.
- `f161-piston-c-node` : `walk` · ΔX -340 · ΔY 0 · connexion `f161-e59`.
- `f161-parley-v93` : `walk` · ΔX 180 · ΔY 0 · connexion `f161-e85`.
- `f161-chase-reroute-v94` : `ladder` · ΔX -430 · ΔY 120 · connexion `f161-e102`.

### 9.19. f161-company
**Zone :** `f161-furnace` · coordonnées (5800, 510) · largeur 300 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-furnace` : `walk` · ΔX -320 · ΔY 0 · connexion `f161-e10`.
- `f161-extraction` : `walk` · ΔX 240 · ΔY 0 · connexion `f161-e11`.
- `f161-furnace-gantry` : `ladder` · ΔX -60 · ΔY -180 · connexion `f161-e34`.
- `f161-furnace-overlook` : `ladder` · ΔX -220 · ΔY -180 · connexion `f161-e45`.
- `f161-patna-cage-node` : `walk` · ΔX 130 · ΔY 0 · connexion `f161-e60`.
- `f161-parley-v93` : `walk` · ΔX -140 · ΔY 0 · connexion `f161-e86`.
- `f161-witness-v93` : `ladder` · ΔX 230 · ΔY -180 · connexion `f161-e87`.

### 9.20. f161-extraction
**Zone :** `f161-furnace` · coordonnées (6040, 510) · largeur 300 · ancre de jeu : extraction.
**Décor V102 :** Plateforme terminale
- `f161-company` : `walk` · ΔX -240 · ΔY 0 · connexion `f161-e11`.
- `f161-patna-cage-node` : `walk` · ΔX -110 · ΔY 0 · connexion `f161-e61`.
- `f161-witness-v93` : `ladder` · ΔX -10 · ΔY -180 · connexion `f161-e88`.

### 9.21. f161-assembly-hall
**Zone :** `f161-cellblock` · coordonnées (2300, 510) · largeur 300 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-cell-a` : `walk` · ΔX -400 · ΔY 0 · connexion `f161-e27`.
- `f161-cell-b` : `walk` · ΔX 320 · ΔY 0 · connexion `f161-e28`.
- `f161-mess-high` : `ladder` · ΔX 20 · ΔY -160 · connexion `f161-e29`.
- `f161-shelter-cell-v95` : `ladder` · ΔX -250 · ΔY 120 · connexion `f161-e105`.

### 9.22. f161-waste-tank
**Zone :** `f161-leadworks` · coordonnées (4070, 630) · largeur 310 · ancre de jeu : aucune.
**Décor V102 :** Collecte des effluents
- `f161-tunnel-low` : `walk` · ΔX -250 · ΔY 0 · connexion `f161-e30`.
- `f161-sluice-low` : `walk` · ΔX 430 · ΔY 0 · connexion `f161-e31`.
- `f161-hunt-junction-v95` : `walk` · ΔX -170 · ΔY 0 · connexion `f161-e115`.

### 9.23. f161-sluice-low
**Zone :** `f161-leadworks` · coordonnées (4500, 630) · largeur 280 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-waste-tank` : `walk` · ΔX -430 · ΔY 0 · connexion `f161-e31`.
- `f161-leadworks` : `ladder` · ΔX -300 · ΔY -120 · connexion `f161-e32`.

### 9.24. f161-furnace-gantry
**Zone :** `f161-furnace` · coordonnées (5740, 330) · largeur 280 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-furnace-high` : `walk` · ΔX -390 · ΔY 0 · connexion `f161-e33`.
- `f161-company` : `ladder` · ΔX 60 · ΔY 180 · connexion `f161-e34`.

### 9.25. f161-fuel-manifold-a
**Zone :** `f161-service` · coordonnées (2960, 510) · largeur 180 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-service-low` : `walk` · ΔX 110 · ΔY 0 · connexion `f161-e35`.
- `f161-fuel-manifold-b` : `walk` · ΔX 280 · ΔY 0 · connexion `f161-e36`.

### 9.26. f161-fuel-manifold-b
**Zone :** `f161-service` · coordonnées (3240, 510) · largeur 180 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-fuel-manifold-a` : `walk` · ΔX -280 · ΔY 0 · connexion `f161-e36`.
- `f161-bishop` : `walk` · ΔX 260 · ΔY 0 · connexion `f161-e37`.

### 9.27. f161-chemical-store
**Zone :** `f161-service` · coordonnées (3670, 510) · largeur 210 · ancre de jeu : aucune.
**Décor V102 :** Réserve de produits
- `f161-bishop` : `walk` · ΔX -170 · ΔY 0 · connexion `f161-e38`.
- `f161-tunnel-high` : `ladder` · ΔX 150 · ΔY -180 · connexion `f161-e39`.
- `f161-shutter-service-node` : `walk` · ΔX -20 · ΔY 0 · connexion `f161-e70`.

### 9.28. f161-lead-primer
**Zone :** `f161-leadworks` · coordonnées (4380, 510) · largeur 190 · ancre de jeu : aucune.
**Décor V102 :** Alimentation du creuset
- `f161-leadworks` : `walk` · ΔX -180 · ΔY 0 · connexion `f161-e40`.
- `f161-mold` : `walk` · ΔX 540 · ΔY 0 · connexion `f161-e41`.

### 9.29. f161-water-header
**Zone :** `f161-leadworks` · coordonnées (4690, 330) · largeur 190 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-sprinkler` : `walk` · ΔX -130 · ΔY 0 · connexion `f161-e42`.
- `f161-mold` : `ladder` · ΔX 230 · ΔY 180 · connexion `f161-e43`.
- `f161-steam-lead-node` : `walk` · ΔX 20 · ΔY 0 · connexion `f161-e73`.
- `f161-battery-junction-v94` : `walk` · ΔX -670 · ΔY 0 · connexion `f161-e100`.

### 9.30. f161-furnace-overlook
**Zone :** `f161-furnace` · coordonnées (5580, 330) · largeur 220 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-furnace-high` : `walk` · ΔX -230 · ΔY 0 · connexion `f161-e44`.
- `f161-company` : `ladder` · ΔX 220 · ΔY 180 · connexion `f161-e45`.

### 9.31. f161-clemens-bed
**Zone :** `f161-infirmary` · coordonnées (1380, 510) · largeur 180 · ancre de jeu : aucune.
**Décor V102 :** Chambre médicale
- `f161-infirmary` : `walk` · ΔX -260 · ΔY 0 · connexion `f161-e46`.
- `f161-funeral-walk` : `walk` · ΔX 200 · ΔY 0 · connexion `f161-e47`.

### 9.32. f161-funeral-walk
**Zone :** `f161-infirmary` · coordonnées (1580, 510) · largeur 180 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-clemens-bed` : `walk` · ΔX -200 · ΔY 0 · connexion `f161-e47`.
- `f161-morgue-high` : `ladder` · ΔX -80 · ΔY -160 · connexion `f161-e48`.

### 9.33. f161-mess-ceiling
**Zone :** `f161-cellblock` · coordonnées (2470, 350) · largeur 190 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-mess-high` : `walk` · ΔX -150 · ΔY 0 · connexion `f161-e49`.
- `f161-comms-high` : `walk` · ΔX 250 · ΔY 0 · connexion `f161-e50`.
- `f161-perch-cell-v93` : `ladder` · ΔX 30 · ΔY -160 · connexion `f161-e77`.

### 9.34. f161-comms-high
**Zone :** `f161-cellblock` · coordonnées (2720, 350) · largeur 180 · ancre de jeu : aucune.
**Décor V102 :** Poste de communication
- `f161-mess-ceiling` : `walk` · ΔX -250 · ΔY 0 · connexion `f161-e50`.
- `f161-shutter-cell-node` : `ladder` · ΔX 20 · ΔY 160 · connexion `f161-e64`.
- `f161-perch-cell-v93` : `ladder` · ΔX -220 · ΔY -160 · connexion `f161-e78`.
- `f161-watch-cell-v95` : `ladder` · ΔX -60 · ΔY -160 · connexion `f161-e107`.

### 9.35. f161-fan-shaft
**Zone :** `f161-service` · coordonnées (2940, 330) · largeur 170 · ancre de jeu : aucune.
**Décor V102 :** Ventilateur de maintenance
- `f161-service-high` : `walk` · ΔX 130 · ΔY 0 · connexion `f161-e51`.
- `f161-steam-service-node` : `walk` · ΔX 250 · ΔY 0 · connexion `f161-e66`.

### 9.36. f161-tunnel-shrine
**Zone :** `f161-service` · coordonnées (3420, 630) · largeur 210 · ancre de jeu : aucune.
**Décor V102 :** Alcôve des galeries
- `f161-service-deep` : `walk` · ΔX -350 · ΔY 0 · connexion `f161-e52`.
- `f161-bishop` : `ladder` · ΔX 80 · ΔY -120 · connexion `f161-e53`.
- `f161-golic-cache-v94` : `walk` · ΔX 240 · ΔY 0 · connexion `f161-e97`.
- `f161-refuge-service-v95` : `walk` · ΔX -430 · ΔY 0 · connexion `f161-e109`.

### 9.37. f161-piston-a-node
**Zone :** `f161-leadworks` · coordonnées (4480, 510) · largeur 180 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-leadworks` : `walk` · ΔX -280 · ΔY 0 · connexion `f161-e54`.
- `f161-mold` : `walk` · ΔX 440 · ΔY 0 · connexion `f161-e55`.

### 9.38. f161-piston-b-node
**Zone :** `f161-leadworks` · coordonnées (4820, 330) · largeur 180 · ancre de jeu : aucune.
**Décor V102 :** Pistons supérieurs
- `f161-sprinkler` : `walk` · ΔX -260 · ΔY 0 · connexion `f161-e56`.
- `f161-mold` : `ladder` · ΔX 100 · ΔY 180 · connexion `f161-e57`.
- `f161-steam-lead-node` : `walk` · ΔX -110 · ΔY 0 · connexion `f161-e74`.
- `f161-perch-lead-v93` : `ladder` · ΔX -100 · ΔY -140 · connexion `f161-e84`.

### 9.39. f161-piston-c-node
**Zone :** `f161-leadworks` · coordonnées (5140, 510) · largeur 180 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-mold` : `walk` · ΔX -220 · ΔY 0 · connexion `f161-e58`.
- `f161-furnace` : `walk` · ΔX 340 · ΔY 0 · connexion `f161-e59`.
- `f161-shutter-foundry-node` : `walk` · ΔX -90 · ΔY 0 · connexion `f161-e76`.

### 9.40. f161-patna-cage-node
**Zone :** `f161-furnace` · coordonnées (5930, 510) · largeur 160 · ancre de jeu : aucune.
**Décor V102 :** Matériel de récupération
- `f161-company` : `walk` · ΔX -130 · ΔY 0 · connexion `f161-e60`.
- `f161-extraction` : `walk` · ΔX 110 · ΔY 0 · connexion `f161-e61`.

### 9.41. f161-master-archive-node
**Zone :** `f161-infirmary` · coordonnées (1260, 350) · largeur 170 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-morgue-high` : `walk` · ΔX 240 · ΔY 0 · connexion `f161-e62`.

### 9.42. f161-shutter-cell-node
**Zone :** `f161-cellblock` · coordonnées (2740, 510) · largeur 160 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-cell-b` : `walk` · ΔX -120 · ΔY 0 · connexion `f161-e63`.
- `f161-comms-high` : `ladder` · ΔX -20 · ΔY -160 · connexion `f161-e64`.

### 9.43. f161-steam-service-node
**Zone :** `f161-service` · coordonnées (3190, 330) · largeur 160 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-service-high` : `walk` · ΔX -120 · ΔY 0 · connexion `f161-e65`.
- `f161-fan-shaft` : `walk` · ΔX -250 · ΔY 0 · connexion `f161-e66`.
- `f161-perch-service-v93` : `ladder` · ΔX 120 · ΔY -140 · connexion `f161-e79`.

### 9.44. f161-rescue-post-node
**Zone :** `f161-service` · coordonnées (3330, 510) · largeur 170 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-service-low` : `walk` · ΔX -260 · ΔY 0 · connexion `f161-e67`.
- `f161-bishop` : `walk` · ΔX 170 · ΔY 0 · connexion `f161-e68`.
- `f161-triage-v93` : `walk` · ΔX 160 · ΔY 0 · connexion `f161-e81`.

### 9.45. f161-shutter-service-node
**Zone :** `f161-service` · coordonnées (3650, 510) · largeur 160 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-bishop` : `walk` · ΔX -150 · ΔY 0 · connexion `f161-e69`.
- `f161-chemical-store` : `walk` · ΔX 20 · ΔY 0 · connexion `f161-e70`.
- `f161-triage-v93` : `walk` · ΔX -160 · ΔY 0 · connexion `f161-e82`.
- `f161-triage-overflow-v95` : `walk` · ΔX -50 · ΔY 0 · connexion `f161-e113`.

### 9.46. f161-command-post-node
**Zone :** `f161-leadworks` · coordonnées (3960, 510) · largeur 180 · ancre de jeu : aucune.
**Décor V102 :** Supervision de la fonderie
- `f161-tunnel-high` : `ladder` · ΔX -140 · ΔY -180 · connexion `f161-e71`.
- `f161-leadworks` : `walk` · ΔX 240 · ΔY 0 · connexion `f161-e72`.

### 9.47. f161-steam-lead-node
**Zone :** `f161-leadworks` · coordonnées (4710, 330) · largeur 160 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-water-header` : `walk` · ΔX -20 · ΔY 0 · connexion `f161-e73`.
- `f161-piston-b-node` : `walk` · ΔX 110 · ΔY 0 · connexion `f161-e74`.
- `f161-perch-lead-v93` : `ladder` · ΔX 10 · ΔY -140 · connexion `f161-e83`.

### 9.48. f161-shutter-foundry-node
**Zone :** `f161-leadworks` · coordonnées (5050, 510) · largeur 160 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-mold` : `walk` · ΔX -130 · ΔY 0 · connexion `f161-e75`.
- `f161-piston-c-node` : `walk` · ΔX 90 · ΔY 0 · connexion `f161-e76`.

### 9.49. f161-perch-cell-v93
**Zone :** `f161-cellblock` · coordonnées (2500, 190) · largeur 170 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-mess-ceiling` : `ladder` · ΔX -30 · ΔY 160 · connexion `f161-e77`.
- `f161-comms-high` : `ladder` · ΔX 220 · ΔY 160 · connexion `f161-e78`.
- `f161-faith-dais-v94` : `walk` · ΔX -320 · ΔY 0 · connexion `f161-e94`.
- `f161-watch-cell-v95` : `walk` · ΔX 160 · ΔY 0 · connexion `f161-e106`.

### 9.50. f161-perch-service-v93
**Zone :** `f161-service` · coordonnées (3310, 190) · largeur 170 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-steam-service-node` : `ladder` · ΔX -120 · ΔY 140 · connexion `f161-e79`.
- `f161-service-high` : `ladder` · ΔX -240 · ΔY 140 · connexion `f161-e80`.

### 9.51. f161-triage-v93
**Zone :** `f161-service` · coordonnées (3490, 510) · largeur 190 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-rescue-post-node` : `walk` · ΔX -160 · ΔY 0 · connexion `f161-e81`.
- `f161-shutter-service-node` : `walk` · ΔX 160 · ΔY 0 · connexion `f161-e82`.
- `f161-triage-overflow-v95` : `walk` · ΔX 110 · ΔY 0 · connexion `f161-e112`.

### 9.52. f161-perch-lead-v93
**Zone :** `f161-leadworks` · coordonnées (4720, 190) · largeur 170 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-steam-lead-node` : `ladder` · ΔX -10 · ΔY 140 · connexion `f161-e83`.
- `f161-piston-b-node` : `ladder` · ΔX 100 · ΔY 140 · connexion `f161-e84`.

### 9.53. f161-parley-v93
**Zone :** `f161-furnace` · coordonnées (5660, 510) · largeur 180 · ancre de jeu : aucune.
**Décor V102 :** Approche de la Compagnie
- `f161-furnace` : `walk` · ΔX -180 · ΔY 0 · connexion `f161-e85`.
- `f161-company` : `walk` · ΔX 140 · ΔY 0 · connexion `f161-e86`.

### 9.54. f161-witness-v93
**Zone :** `f161-furnace` · coordonnées (6030, 330) · largeur 170 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-company` : `ladder` · ΔX -230 · ΔY 180 · connexion `f161-e87`.
- `f161-extraction` : `ladder` · ΔX 10 · ΔY 180 · connexion `f161-e88`.
- `f161-final-transmission-v94` : `walk` · ΔX 70 · ΔY 0 · connexion `f161-e103`.
- `f161-archive-checksum-v95` : `ladder` · ΔX -70 · ΔY -140 · connexion `f161-e120`.

### 9.55. f161-flight-analysis-v94
**Zone :** `f161-coast` · coordonnées (780, 330) · largeur 220 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-eev` : `ladder` · ΔX -160 · ΔY 180 · connexion `f161-e89`.
- `f161-morgue-high` : `walk` · ΔX 720 · ΔY 20 · connexion `f161-e90`.

### 9.56. f161-wreckage-incident-v94
**Zone :** `f161-coast` · coordonnées (820, 630) · largeur 220 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-eev` : `ladder` · ΔX -200 · ΔY -120 · connexion `f161-e91`.
- `f161-infirmary` : `ladder` · ΔX 300 · ΔY -120 · connexion `f161-e92`.

### 9.57. f161-faith-dais-v94
**Zone :** `f161-cellblock` · coordonnées (2180, 190) · largeur 250 · ancre de jeu : aucune.
**Décor V102 :** Lieu de recueillement
- `f161-mess-high` : `ladder` · ΔX 140 · ΔY 160 · connexion `f161-e93`.
- `f161-perch-cell-v93` : `walk` · ΔX 320 · ΔY 0 · connexion `f161-e94`.

### 9.58. f161-battery-locker-v94
**Zone :** `f161-service` · coordonnées (3500, 330) · largeur 250 · ancre de jeu : aucune.
**Décor V102 :** Recharge des batteries
- `f161-service-high` : `walk` · ΔX -430 · ΔY 0 · connexion `f161-e95`.
- `f161-tunnel-high` : `walk` · ΔX 320 · ΔY 0 · connexion `f161-e96`.
- `f161-hunt-service-v95` : `walk` · ΔX -130 · ΔY 0 · connexion `f161-e111`.

### 9.59. f161-golic-cache-v94
**Zone :** `f161-service` · coordonnées (3660, 630) · largeur 230 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-tunnel-shrine` : `walk` · ΔX -240 · ΔY 0 · connexion `f161-e97`.
- `f161-tunnel-low` : `walk` · ΔX 160 · ΔY 0 · connexion `f161-e98`.

### 9.60. f161-battery-junction-v94
**Zone :** `f161-leadworks` · coordonnées (4020, 330) · largeur 250 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-tunnel-high` : `walk` · ΔX -200 · ΔY 0 · connexion `f161-e99`.
- `f161-water-header` : `walk` · ΔX 670 · ΔY 0 · connexion `f161-e100`.
- `f161-bait-switch-v95` : `walk` · ΔX 300 · ΔY 0 · connexion `f161-e116`.

### 9.61. f161-chase-reroute-v94
**Zone :** `f161-leadworks` · coordonnées (5050, 630) · largeur 250 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-mold` : `ladder` · ΔX -130 · ΔY -120 · connexion `f161-e101`.
- `f161-furnace` : `ladder` · ΔX 430 · ΔY -120 · connexion `f161-e102`.
- `f161-pressure-alcove-v95` : `walk` · ΔX -270 · ΔY 0 · connexion `f161-e118`.

### 9.62. f161-final-transmission-v94
**Zone :** `f161-furnace` · coordonnées (6100, 330) · largeur 190 · ancre de jeu : aucune.
**Décor V102 :** Émetteur de service
- `f161-witness-v93` : `walk` · ΔX -70 · ΔY 0 · connexion `f161-e103`.

### 9.63. f161-shelter-cell-v95
**Zone :** `f161-cellblock` · coordonnées (2050, 630) · largeur 220 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-cell-a` : `ladder` · ΔX -150 · ΔY -120 · connexion `f161-e104`.
- `f161-assembly-hall` : `ladder` · ΔX 250 · ΔY -120 · connexion `f161-e105`.

### 9.64. f161-watch-cell-v95
**Zone :** `f161-cellblock` · coordonnées (2660, 190) · largeur 190 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-perch-cell-v93` : `walk` · ΔX -160 · ΔY 0 · connexion `f161-e106`.
- `f161-comms-high` : `ladder` · ΔX 60 · ΔY 160 · connexion `f161-e107`.

### 9.65. f161-refuge-service-v95
**Zone :** `f161-service` · coordonnées (2990, 630) · largeur 230 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-service-deep` : `walk` · ΔX 80 · ΔY 0 · connexion `f161-e108`.
- `f161-tunnel-shrine` : `walk` · ΔX 430 · ΔY 0 · connexion `f161-e109`.

### 9.66. f161-hunt-service-v95
**Zone :** `f161-service` · coordonnées (3370, 330) · largeur 210 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-service-high` : `walk` · ΔX -300 · ΔY 0 · connexion `f161-e110`.
- `f161-battery-locker-v94` : `walk` · ΔX 130 · ΔY 0 · connexion `f161-e111`.

### 9.67. f161-triage-overflow-v95
**Zone :** `f161-service` · coordonnées (3600, 510) · largeur 220 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-triage-v93` : `walk` · ΔX -110 · ΔY 0 · connexion `f161-e112`.
- `f161-shutter-service-node` : `walk` · ΔX 50 · ΔY 0 · connexion `f161-e113`.

### 9.68. f161-hunt-junction-v95
**Zone :** `f161-leadworks` · coordonnées (3900, 630) · largeur 210 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-tunnel-low` : `walk` · ΔX -80 · ΔY 0 · connexion `f161-e114`.
- `f161-waste-tank` : `walk` · ΔX 170 · ΔY 0 · connexion `f161-e115`.

### 9.69. f161-bait-switch-v95
**Zone :** `f161-leadworks` · coordonnées (4320, 330) · largeur 210 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-battery-junction-v94` : `walk` · ΔX -300 · ΔY 0 · connexion `f161-e116`.
- `f161-sprinkler` : `walk` · ΔX 240 · ΔY 0 · connexion `f161-e117`.

### 9.70. f161-pressure-alcove-v95
**Zone :** `f161-leadworks` · coordonnées (4780, 630) · largeur 220 · ancre de jeu : aucune.
**Décor V102 :** Retour hydraulique
- `f161-chase-reroute-v94` : `walk` · ΔX 270 · ΔY 0 · connexion `f161-e118`.

### 9.71. f161-chase-observer-v95
**Zone :** `f161-furnace` · coordonnées (5280, 330) · largeur 210 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-furnace-high` : `walk` · ΔX 70 · ΔY 0 · connexion `f161-e119`.

### 9.72. f161-archive-checksum-v95
**Zone :** `f161-furnace` · coordonnées (5960, 190) · largeur 190 · ancre de jeu : aucune.
**Décor V102 :** pas d’assemblage supplémentaire ; passage ou respiration conservé.
- `f161-witness-v93` : `ladder` · ΔX 70 · ΔY 140 · connexion `f161-e120`.

## 10. Registre des 119 connexions
| Connexion | Origine | Destination | Type |
|---|---|---|---|
| `f161-e01` | `f161-spawn` | `f161-eev` | walk |
| `f161-e02` | `f161-eev` | `f161-infirmary` | walk |
| `f161-e03` | `f161-infirmary` | `f161-cell-a` | gate |
| `f161-e05` | `f161-cell-b` | `f161-service-low` | gate |
| `f161-e06` | `f161-service-low` | `f161-bishop` | walk |
| `f161-e07` | `f161-bishop` | `f161-leadworks` | gate |
| `f161-e08` | `f161-leadworks` | `f161-mold` | walk |
| `f161-e09` | `f161-mold` | `f161-furnace` | walk |
| `f161-e10` | `f161-furnace` | `f161-company` | walk |
| `f161-e11` | `f161-company` | `f161-extraction` | walk |
| `f161-e12` | `f161-infirmary` | `f161-morgue-high` | ladder |
| `f161-e13` | `f161-morgue-high` | `f161-mess-high` | walk |
| `f161-e14` | `f161-mess-high` | `f161-service-high` | walk |
| `f161-e15` | `f161-service-high` | `f161-tunnel-high` | walk |
| `f161-e16` | `f161-tunnel-high` | `f161-sprinkler` | walk |
| `f161-e17` | `f161-sprinkler` | `f161-furnace-high` | walk |
| `f161-e18` | `f161-furnace-high` | `f161-furnace` | ladder |
| `f161-e19` | `f161-infirmary` | `f161-service-deep` | vent |
| `f161-e20` | `f161-service-deep` | `f161-tunnel-low` | walk |
| `f161-e21` | `f161-tunnel-low` | `f161-leadworks` | ladder |
| `f161-e22` | `f161-leadworks` | `f161-furnace` | vent |
| `f161-e23` | `f161-cell-a` | `f161-mess-high` | ladder |
| `f161-e24` | `f161-service-low` | `f161-service-high` | ladder |
| `f161-e25` | `f161-service-low` | `f161-service-deep` | ladder |
| `f161-e26` | `f161-leadworks` | `f161-sprinkler` | ladder |
| `f161-e27` | `f161-cell-a` | `f161-assembly-hall` | walk |
| `f161-e28` | `f161-assembly-hall` | `f161-cell-b` | walk |
| `f161-e29` | `f161-assembly-hall` | `f161-mess-high` | ladder |
| `f161-e30` | `f161-tunnel-low` | `f161-waste-tank` | walk |
| `f161-e31` | `f161-waste-tank` | `f161-sluice-low` | walk |
| `f161-e32` | `f161-sluice-low` | `f161-leadworks` | ladder |
| `f161-e33` | `f161-furnace-high` | `f161-furnace-gantry` | walk |
| `f161-e34` | `f161-furnace-gantry` | `f161-company` | ladder |
| `f161-e35` | `f161-service-low` | `f161-fuel-manifold-a` | walk |
| `f161-e36` | `f161-fuel-manifold-a` | `f161-fuel-manifold-b` | walk |
| `f161-e37` | `f161-fuel-manifold-b` | `f161-bishop` | walk |
| `f161-e38` | `f161-bishop` | `f161-chemical-store` | walk |
| `f161-e39` | `f161-chemical-store` | `f161-tunnel-high` | ladder |
| `f161-e40` | `f161-leadworks` | `f161-lead-primer` | walk |
| `f161-e41` | `f161-lead-primer` | `f161-mold` | walk |
| `f161-e42` | `f161-sprinkler` | `f161-water-header` | walk |
| `f161-e43` | `f161-water-header` | `f161-mold` | ladder |
| `f161-e44` | `f161-furnace-high` | `f161-furnace-overlook` | walk |
| `f161-e45` | `f161-furnace-overlook` | `f161-company` | ladder |
| `f161-e46` | `f161-infirmary` | `f161-clemens-bed` | walk |
| `f161-e47` | `f161-clemens-bed` | `f161-funeral-walk` | walk |
| `f161-e48` | `f161-funeral-walk` | `f161-morgue-high` | ladder |
| `f161-e49` | `f161-mess-high` | `f161-mess-ceiling` | walk |
| `f161-e50` | `f161-mess-ceiling` | `f161-comms-high` | walk |
| `f161-e51` | `f161-service-high` | `f161-fan-shaft` | walk |
| `f161-e52` | `f161-service-deep` | `f161-tunnel-shrine` | walk |
| `f161-e53` | `f161-tunnel-shrine` | `f161-bishop` | ladder |
| `f161-e54` | `f161-leadworks` | `f161-piston-a-node` | walk |
| `f161-e55` | `f161-piston-a-node` | `f161-mold` | walk |
| `f161-e56` | `f161-sprinkler` | `f161-piston-b-node` | walk |
| `f161-e57` | `f161-piston-b-node` | `f161-mold` | ladder |
| `f161-e58` | `f161-mold` | `f161-piston-c-node` | walk |
| `f161-e59` | `f161-piston-c-node` | `f161-furnace` | walk |
| `f161-e60` | `f161-company` | `f161-patna-cage-node` | walk |
| `f161-e61` | `f161-patna-cage-node` | `f161-extraction` | walk |
| `f161-e62` | `f161-morgue-high` | `f161-master-archive-node` | walk |
| `f161-e63` | `f161-cell-b` | `f161-shutter-cell-node` | walk |
| `f161-e64` | `f161-shutter-cell-node` | `f161-comms-high` | ladder |
| `f161-e65` | `f161-service-high` | `f161-steam-service-node` | walk |
| `f161-e66` | `f161-steam-service-node` | `f161-fan-shaft` | walk |
| `f161-e67` | `f161-service-low` | `f161-rescue-post-node` | walk |
| `f161-e68` | `f161-rescue-post-node` | `f161-bishop` | walk |
| `f161-e69` | `f161-bishop` | `f161-shutter-service-node` | walk |
| `f161-e70` | `f161-shutter-service-node` | `f161-chemical-store` | walk |
| `f161-e71` | `f161-tunnel-high` | `f161-command-post-node` | ladder |
| `f161-e72` | `f161-command-post-node` | `f161-leadworks` | walk |
| `f161-e73` | `f161-water-header` | `f161-steam-lead-node` | walk |
| `f161-e74` | `f161-steam-lead-node` | `f161-piston-b-node` | walk |
| `f161-e75` | `f161-mold` | `f161-shutter-foundry-node` | walk |
| `f161-e76` | `f161-shutter-foundry-node` | `f161-piston-c-node` | walk |
| `f161-e77` | `f161-mess-ceiling` | `f161-perch-cell-v93` | ladder |
| `f161-e78` | `f161-perch-cell-v93` | `f161-comms-high` | ladder |
| `f161-e79` | `f161-steam-service-node` | `f161-perch-service-v93` | ladder |
| `f161-e80` | `f161-perch-service-v93` | `f161-service-high` | ladder |
| `f161-e81` | `f161-rescue-post-node` | `f161-triage-v93` | walk |
| `f161-e82` | `f161-triage-v93` | `f161-shutter-service-node` | walk |
| `f161-e83` | `f161-steam-lead-node` | `f161-perch-lead-v93` | ladder |
| `f161-e84` | `f161-perch-lead-v93` | `f161-piston-b-node` | ladder |
| `f161-e85` | `f161-furnace` | `f161-parley-v93` | walk |
| `f161-e86` | `f161-parley-v93` | `f161-company` | walk |
| `f161-e87` | `f161-company` | `f161-witness-v93` | ladder |
| `f161-e88` | `f161-witness-v93` | `f161-extraction` | ladder |
| `f161-e89` | `f161-eev` | `f161-flight-analysis-v94` | ladder |
| `f161-e90` | `f161-flight-analysis-v94` | `f161-morgue-high` | walk |
| `f161-e91` | `f161-eev` | `f161-wreckage-incident-v94` | ladder |
| `f161-e92` | `f161-wreckage-incident-v94` | `f161-infirmary` | ladder |
| `f161-e93` | `f161-mess-high` | `f161-faith-dais-v94` | ladder |
| `f161-e94` | `f161-faith-dais-v94` | `f161-perch-cell-v93` | walk |
| `f161-e95` | `f161-service-high` | `f161-battery-locker-v94` | walk |
| `f161-e96` | `f161-battery-locker-v94` | `f161-tunnel-high` | walk |
| `f161-e97` | `f161-tunnel-shrine` | `f161-golic-cache-v94` | walk |
| `f161-e98` | `f161-golic-cache-v94` | `f161-tunnel-low` | walk |
| `f161-e99` | `f161-tunnel-high` | `f161-battery-junction-v94` | walk |
| `f161-e100` | `f161-battery-junction-v94` | `f161-water-header` | walk |
| `f161-e101` | `f161-mold` | `f161-chase-reroute-v94` | ladder |
| `f161-e102` | `f161-chase-reroute-v94` | `f161-furnace` | ladder |
| `f161-e103` | `f161-witness-v93` | `f161-final-transmission-v94` | walk |
| `f161-e104` | `f161-cell-a` | `f161-shelter-cell-v95` | ladder |
| `f161-e105` | `f161-shelter-cell-v95` | `f161-assembly-hall` | ladder |
| `f161-e106` | `f161-perch-cell-v93` | `f161-watch-cell-v95` | walk |
| `f161-e107` | `f161-watch-cell-v95` | `f161-comms-high` | ladder |
| `f161-e108` | `f161-service-deep` | `f161-refuge-service-v95` | walk |
| `f161-e109` | `f161-refuge-service-v95` | `f161-tunnel-shrine` | walk |
| `f161-e110` | `f161-service-high` | `f161-hunt-service-v95` | walk |
| `f161-e111` | `f161-hunt-service-v95` | `f161-battery-locker-v94` | walk |
| `f161-e112` | `f161-triage-v93` | `f161-triage-overflow-v95` | walk |
| `f161-e113` | `f161-triage-overflow-v95` | `f161-shutter-service-node` | walk |
| `f161-e114` | `f161-tunnel-low` | `f161-hunt-junction-v95` | walk |
| `f161-e115` | `f161-hunt-junction-v95` | `f161-waste-tank` | walk |
| `f161-e116` | `f161-battery-junction-v94` | `f161-bait-switch-v95` | walk |
| `f161-e117` | `f161-bait-switch-v95` | `f161-sprinkler` | walk |
| `f161-e118` | `f161-chase-reroute-v94` | `f161-pressure-alcove-v95` | walk |
| `f161-e119` | `f161-furnace-high` | `f161-chase-observer-v95` | walk |
| `f161-e120` | `f161-witness-v93` | `f161-archive-checksum-v95` | ladder |

## 11. Rendu, sauvegarde et intégration
Le renderer partagé est src/alien3-art-v102.js. Le module de données définit les recettes et les ancrages ; le mixin V102 remplace uniquement la couche décorative dispersée V101 et le HUD du canvas. Les interactions et acteurs historiques continuent d’être rendus par leurs propriétaires.
La décoration est reconstruite au chargement depuis les nœuds du plan. Elle n’est pas recopiée intégralement dans la sauvegarde. Seuls les secteurs visités et les réglages V102 utiles sont sérialisés ; les statistiques de dessin sont éphémères. Dix appels de rendu et dix appels de rendu des archives ont été contrôlés dans Chromium sans modification du snapshot du banc.
L’installateur V102 travaille d’abord dans une copie temporaire. Il valide les ancrages de code, applique l’héritage nécessaire, pose trois nouveaux modules puis corrige le contrat du registre de campagnes de 440 à 441. Il lance npm run check puis npm run build dans cette copie, sauf demande explicite --no-build. Un échec de ces commandes ne touche donc pas les fichiers du projet cible.
La publication locale ne porte que sur sept fichiers de liaison/registre, les 31 modules runtime nécessaires et, si généré, le manifeste audio. Les rapports, captures et le banc restent hors de la distribution du jeu. Une sauvegarde externe est écrite avant le remplacement des fichiers. La restauration refuse des sources ou un dist modifiés après installation.
Il s’agit d’écritures atomiques fichier par fichier, pas d’une transaction de système de fichiers résistante à toute coupure électrique. Le reçu et les copies externes sont à conserver. Aucun push GitHub ni déploiement Vercel n’a été effectué dans cette édition.

## 12. Vérifications réalisées et limites restantes
V102 : 23 cas de données/runtime isolés, 11 scénarios d’installation sur fixtures et 19 contrôles dans Chromium. Héritage : 55/55 scripts isolés repassent. Le détail et la portée de chaque contrôle sont fournis dans qa-v102.
Les dix images sont des captures natives de canvas dans Chromium. Le banc exécute les modules de rendu livrés et les mixins V101/V102 avec un contrôleur simplifié. Il ne charge pas le moteur principal, les assets massifs du dépôt ni toute la campagne. Les acteurs sont dessinés provisoirement ; leur fidélité 1:1 et leurs animations définitives ne sont pas revendiquées.
Le vrai npm run check / npm run build de la totalité du dépôt avec le DLC n’a pas été exécuté. Les essais positifs/négatifs de l’installateur utilisent des projets synthétiques et servent à vérifier la sécurité des écritures, pas à prouver le build de production.
À examiner dans le jeu complet : empilement des anciens postes interactifs avec les nouveaux ensembles, lisibilité des silhouettes définitives, débouchés de toutes les échelles, vrais volumes de couverture, raccords entre pièces, accessibilité tactile, comportement de la caméra de production et fidélité visuelle scène par scène. Ces points ne sont pas effacés par un total de tests verts.
