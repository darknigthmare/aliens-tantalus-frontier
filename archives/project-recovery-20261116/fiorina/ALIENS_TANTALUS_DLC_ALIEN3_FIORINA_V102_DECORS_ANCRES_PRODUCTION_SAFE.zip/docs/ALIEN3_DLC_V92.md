# Alien 3 — Fiorina 161 V92

## Positionnement

V92 est une couche cumulative au-dessus de V88, V89, V90 et V91. Elle conserve la reconstruction MIRE de Fiorina 161, ses deux montages jouables (cinéma / Assembly Cut), le Runner unique, le plan au quinitricetyline, le diagnostic EEV, la fonderie plomb/eau, la chaîne Compagnie/Golic et les trois pistons de rabattement.

La V92 vise surtout la rejouabilité systémique : le Runner apprend l'usage répété des outils tactiques et les détenus deviennent des ressources physiques de coordination, sans transformer l'archive en shooter militaire.

## Nouveautés V92

- 48 nœuds physiques, 75 connexions, 6 zones, 4 routes principales.
- 12 dossiers MIRE V92, soit 60 dossiers Alien 3 cumulés.
- 12 nouvelles preuves persistantes.
- 3 volets d'urgence physiques et destructibles.
- 3 purges de vapeur utilisables pour masquer le bruit / désorienter le Runner.
- 3 postes de commandement détenus : leurre, fermeture, évacuation des blessés.
- Archive maîtresse MIRE consolidant les preuves V89–V92 et les checkpoints de phase.
- Adaptation du Runner : résistance progressive aux flares, agressivité contre les volets, tolérance à la vapeur, mémoire de l'outil répété et feintes hors champ.
- Grade MIRE jusqu'à S+++.

## Contrats de fidélité

1. Un seul Runner existe à la fois. Les feintes et interceptions le repositionnent : elles ne créent jamais de seconde créature.
2. Les armes à feu restent exclues de l'archive. Les flares sont un outil de contrôle, pas une arme létale.
3. La mort du Runner reste réservée à la séquence plomb fondu puis choc thermique.
4. L'Assembly Cut conserve l'ordre causal : confinement dans la cuve → communication avec la Compagnie → directive de conservation → chaîne Golic → libération.
5. Aucun ordre aux détenus ne ressuscite un mort ou n'annule une perte historique déjà enregistrée.

## Adaptation du Runner

Le directeur V92 mémorise l'utilisation des outils de contrôle :

- **Flares** : leur efficacité utile diminue lorsque le joueur les exploite de façon répétitive.
- **Volets** : les fermetures répétées augmentent l'agressivité du Runner ; il peut finir par forcer un volet.
- **Vapeur** : les purges réduisent bruit et pression de route, mais leur durée utile diminue avec la tolérance.
- **Répétition** : l'utilisation successive du même outil augmente la mémoire tactique et favorise les feintes/interceptions.

L'objectif est de pousser le joueur à alterner ses solutions plutôt que d'appliquer une boucle sûre.

## Ordres aux détenus

- **Leurre** : déplace la pression du Runner vers une position commandée sans téléportation visible près du joueur.
- **Fermeture** : déclenche à distance le volet disponible le plus pertinent.
- **Évacuation** : déplace un détenu blessé vers le poste sûr tout en conservant son état blessé.

Les ordres alimentent un indice de coopération utilisé dans le score MIRE.

## Archive maîtresse

L'archive maîtresse consolide les preuves des couches précédentes. Le statut parfait exige les preuves V89, V90, V91 et les preuves V92 hors entrée « archive parfaite », ainsi que la résolution terminale du Runner / de la Compagnie. Le résultat final est persisté dans la sauvegarde spéciale V92.

## Installation

Depuis la racine du projet :

```bash
node /chemin/du/pack/scripts/install-alien3-dlc-v92.mjs /chemin/du/projet
```

L'installateur installe automatiquement V91 (et donc V90, V89, V88) si nécessaire.

Tests dédiés :

```bash
node scripts/test-alien3-dlc-v92.mjs
node scripts/test-alien3-physical-v92.mjs
```

Pour retirer uniquement V92 :

```bash
node scripts/uninstall-alien3-dlc-v92.mjs /chemin/du/projet
```

Pour revenir à l'état antérieur à V88 :

```bash
node scripts/uninstall-alien3-dlc-v92.mjs /chemin/du/projet --full
```

## Limites de validation

Le pack vérifie ses modules, sa topologie, son installation cumulative et sa restauration des fichiers cibles. Il ne remplace pas un `npm run check` / `npm run build` exécuté dans un checkout complet du dépôt avec tous les assets de production.
