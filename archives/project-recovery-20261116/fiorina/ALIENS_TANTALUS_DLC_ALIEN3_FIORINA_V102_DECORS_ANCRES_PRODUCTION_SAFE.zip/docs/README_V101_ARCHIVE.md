# Alien 3 — Fiorina 161 V101 — Dense Set Dressing

Pack cumulatif V88→V101. V101 conserve le gameplay hybride V97–V100 et ajoute une bible de level design exécutable : 32 règles, 48 archétypes et 359 placements décoratifs déterministes sur les 9 secteurs.

Le but est de remplacer les placeholders grossiers par une grammaire cohérente : structure, maintenance, détention, soin, stockage, fonderie, sécurité, environnement et récupération Patna. Chaque secteur possède densité cible, familles autorisées/interdites, landmarks et coefficients de parallaxe.

Fichiers clés :
- `src/alien3-dlc-v101.js`
- `src/alien3-dlc-runtime-v101.js`
- `docs/ALIEN3_LEVEL_DESIGN_CODEX_V101.md`
- `RAPPORT_QA_V101.md`
- `RAPPORT_ILLUSTRE_CAPTURES_V101.html`
