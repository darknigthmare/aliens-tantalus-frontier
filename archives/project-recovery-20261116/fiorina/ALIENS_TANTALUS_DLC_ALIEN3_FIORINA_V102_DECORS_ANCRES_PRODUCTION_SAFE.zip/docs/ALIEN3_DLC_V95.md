# Alien 3 — Fiorina 161 V95 · Living Hunt

V95 est une couche cumulative au-dessus des V88→V94. Elle ne crée ni nouvelle caste ni cinquième route : elle densifie la prison existante et réutilise le Runner unique.

## Living Hunt

Quatre patterns persistants structurent les interceptions : surplomb du bloc, coupure technique, retour par le drain et feinte de fonderie. L’ordre dépend du profil MIRE choisi mais est sauvegardé, auditable et rejouable. Chaque cycle enregistre la distance minimale, le contact éventuel et les évasions propres. Tous les cycles repositionnent le même acteur Runner ; aucun clone n’est créé.

## Autonomie des détenus

Après lecture du tableau d’organisation, chaque détenu actif reçoit un état mental persistant : stress, fatigue, courage, état courant et cooldown d’entraide. Un détenu stable peut soutenir automatiquement un compagnon secoué. Les blessés peuvent rejoindre le triage étendu sans ordre manuel. Une rupture de panique reste possible si le stress dépasse le seuil critique.

## Pression des ressources

Deux refuges, l’extension du triage, le leurre sectoriel et l’alcôve de pression ont un coût logistique mesuré. Le score d’économie récompense un usage raisonné des outils hérités des V92–V94.

## Chase Lock et checksum

Le dernier verrou de chasse exige les trois reroutages V94 et plusieurs cycles V95 réellement observés. Après la transmission finale V94, un checksum MIRE supplémentaire doit être validé avant la fermeture définitive de l’archive.

## Topologie

- 72 nœuds physiques
- 119 connexions
- 4 routes traversantes
- 6 zones
- 10 stations V95
- 4 patterns de chasse
- 20 dossiers et 20 preuves V95

## Sauvegarde

Le schéma V95 sauvegarde l’ordre des patterns, les rencontres, distances, évasions, états mentaux, entraides, transferts de triage, pression de ressources, Chase Lock, checksum et archive parfaite.

## Production

Utiliser `scripts/install-alien3-dlc-v95-production.mjs` dans un checkout complet. Le mode production nettoie les artefacts QA privés, lance `npm run check` puis `npm run build`, et restaure l’état pré-DLC si un contrôle échoue.
