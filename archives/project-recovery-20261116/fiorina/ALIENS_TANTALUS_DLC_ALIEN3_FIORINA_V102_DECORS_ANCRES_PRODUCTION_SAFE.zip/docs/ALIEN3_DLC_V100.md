# Alien 3 — Fiorina 161 V100 · Immersion Pass

V100 conserve toute la campagne V88→V99 et corrige deux points de présentation.

## Fond raccordé au bord supérieur
Les neuf secteurs hybrides utilisent un profil de fond top-aligné (`topEdgeY: 0`). Les couches lointaine et médiane compensent le défilement vertical afin que leur image commence au bord supérieur logique du canvas, puis une architecture de plafond/structure prolonge visuellement le décor dès `y=0`.

## Interface joueur
Les informations techniques des anciennes couches restent disponibles dans les rapports QA mais sont masquées/supprimées de la présentation joueur. Les panneaux affichent désormais des informations naturelles : **Chasse**, **Archives de Fiorina 161**, secteur courant, température, alimentation et visibilité. Les mentions de version, QA, runtime, graph, director, preuves internes et ponts caméra ne sont plus des libellés visibles.

## Archives
Le Codex 90 reste inchangé en contenu et progression. Son affichage applique une couche de texte joueur : catégories naturelles, titres nettoyés, corps débarrassés du jargon de production, recherche, repères et dossiers liés.

## Compatibilité
- topologie : 72 nœuds / 119 connexions / 4 routes / 6 zones ;
- Codex : 90 entrées / 7 terminaux ;
- poursuites : 5 ;
- V100 n'ajoute aucune nouvelle route ni aucun nouveau xénomorphe.
