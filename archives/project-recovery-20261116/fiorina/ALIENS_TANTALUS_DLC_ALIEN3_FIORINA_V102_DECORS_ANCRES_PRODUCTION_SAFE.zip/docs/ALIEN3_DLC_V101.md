# Alien 3 — Fiorina 161 V101 — Dense Set Dressing

V101 densifie les neuf secteurs sans modifier la topologie V100. Elle ajoute un Codex de Level Design exécutable : 32 règles, 48 archétypes et 359 placements déterministes. Le runtime dessine des couches lointaines, médianes et d'avant-plan selon la fonction de chaque zone.

Voir **ALIEN3_LEVEL_DESIGN_CODEX_V101.md** pour la bible détaillée.
