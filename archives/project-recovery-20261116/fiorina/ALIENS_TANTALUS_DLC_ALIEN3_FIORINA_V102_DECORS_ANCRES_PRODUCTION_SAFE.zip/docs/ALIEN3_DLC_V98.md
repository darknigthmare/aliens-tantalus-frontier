# Alien 3 — Fiorina 161 V98 · Hybrid Director

V98 prolonge V97 sans modifier le graphe certifié du niveau. La couche améliore la lisibilité et la mise en scène du mode hybride : transitions de plan interpolées, télégraphe du Runner avant changement de profondeur, contrats caméra par secteur, occultants physiques de profondeur et interface persistante du Codex Alien 3.

## Chiffres
- 72 nœuds / 119 connexions / 4 routes / 6 zones (inchangés).
- 9 secteurs hybrides et 9 profils de mise en scène.
- 3 plans de profondeur.
- 7 occultants de profondeur.
- 78 entrées du Codex Alien 3 dédié (66 V97 + 12 V98).
- 6 terminaux physiques.
- 16 preuves V98.

## Commandes Codex V98
- `C` : ouvrir / fermer le Codex Alien 3.
- `[` / `]` : catégorie précédente / suivante.
- `,` / `.` : page précédente / suivante.
- `B` : ajouter / retirer la page courante des favoris.

## Mode hybride V98
Les limites de secteurs continuent de commuter automatiquement entre profondeur et 2D latérale. En profondeur, un changement de plan dure 0,28 s au lieu de téléporter l'acteur. Le Runner annonce sa destination de plan avant de s'y déplacer. Les occultants n'ont d'effet que depuis leur plan réel.

## QA illustré
Le pack QA V98 contient `qa_visual/capture-v98.html`, un harness reproductible qui exécute les modules runtime V88→V98 sur canvas. Les captures produites par ce harness sont intégrées au rapport illustré. Elles représentent le runtime DLC réel et ses états hybrides/UI ; elles ne prétendent pas être un build Vercel complet avec tous les assets du dépôt tant que GitHub reste en lecture seule.

## Captures V98

Le générateur `scripts/generate-alien3-v98-capture-states.mjs` exécute les couches runtime V88→V98 et sérialise sept états de référence dans `qa_visual/capture-states-v98.json`. `qa_visual/render-captures-v98.py` transforme ensuite ces états en captures 1280×720 avec Chromium/Playwright via `page.set_content`, ce qui contourne l'interdiction locale de naviguer vers `localhost` ou `file://`.

Les sept scènes sont : tempête profondeur, transition lissée du bloc carcéral, galeries 2D, chasse multi-plan en fonderie, Codex plein écran, arrivée Patna en profondeur et plateforme finale 2D.

Le rapport `RAPPORT_ILLUSTRE_CAPTURES_V98.html` est autonome : les PNG sont intégrés en base64 et restent aussi disponibles séparément dans `qa_visual/screenshots/`.
