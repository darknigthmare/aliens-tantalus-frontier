# Alien 3 — Fiorina 161 V93 — Living Cast

V93 est une couche cumulative installée au-dessus de V88→V92. Elle ne remplace pas les systèmes précédents : elle densifie la même Chronique MIRE Fiorina 161.

## Objectif de la passe

Transformer les derniers éléments encore trop statiques en gameplay lisible sans inventer une autre campagne ni un second Runner : beats historiques jouables, routines individuelles des détenus, chasse verticale hors champ et confrontation Patna en plusieurs temps.

## Topologie V93

- 54 nœuds physiques.
- 87 connexions.
- 4 routes complètes conservées.
- 6 zones.
- 26 connecteurs verticaux testés.
- 136 surfaces physiques dans le QA de reconstruction.
- 5 stations V93.
- 3 perchoirs hauts dédiés au Runner.

Les six nouveaux nœuds sont des branches de la carte existante : perchoirs du bloc, des galeries et de la fonderie, baie de triage, zone de pourparlers Patna et poste témoin final.

## Living Cast

Le tableau des équipes affecte les détenus actifs à quatre fonctions :

1. leurre ;
2. fermeture ;
3. relais fonderie ;
4. triage.

Les acteurs se déplacent réellement vers leur poste. Un détenu blessé privilégie la baie de triage. Une exposition prolongée au Runner peut produire une blessure évitable ; cette perte est enregistrée séparément des morts historiques imposées par la reconstruction.

## Beats historiques non bloquants

Quatre séquences sont déclenchées spatialement sans geler les commandes :

- Murphy et le puits de ventilation ;
- Boggs / Rains / Golic dans les galeries ;
- Clemens à l’infirmerie ;
- Andrews dans le réfectoire.

Le cadrage V93 ajoute une carte de scène et un léger letterbox pendant environ deux secondes, mais le personnage reste contrôlable.

## Runner V93

Le Runner reste un individu unique. V93 ajoute trois perchoirs hors champ et une lecture des habitudes :

- temps passé accroupi ;
- vitesse élevée / sprint ;
- immobilité prolongée.

Le directeur déduit un style dominant — stealth, sprint, static ou mixed — et choisit un perchoir hors caméra. Après une courte attente, le même Runner retombe sur une surface physique et reprend sa chasse. Aucun clone ni seconde caste n’est créé.

## Patna et finale

La Compagnie dispose maintenant de quatre étapes physiques distinctes :

- pourparlers Patna ;
- déploiement explicite de la cage ;
- dernier refus d’Aaron ;
- blessure de Morse puis confirmation de son statut de témoin/custodie.

Ces étapes enrichissent la mise en scène sans remplacer les événements déjà portés par V89/V91.

## Archives

V93 ajoute 14 dossiers et 14 preuves. Le total cumulatif Alien 3 passe de 60 à 74 dossiers MIRE.

Le contrat « Archive parfaite — Living Cast » exige :

- héritage V89–V92 complet ;
- 4/4 beats historiques ;
- zéro blessure évitable liée aux routines ;
- chaîne Patna/Aaron/Morse complète ;
- Runner vaincu par la route de fonderie déjà validée ;
- 13 preuves V93 précédant la preuve finale.

Grade maximal : **S++++**.

## QA V93

Le QA V93 vérifie :

- 54 nœuds / 87 arêtes / 4 routes ;
- 14 dossiers / 14 preuves ;
- 4 beats historiques ;
- 4 rôles de détenus ;
- near-miss exposé sans blessure évitable dans le run de référence ;
- apprentissage « sprint » du Runner ;
- perchoir puis retour au sol ;
- parley Patna, Aaron, Morse et témoin ;
- archive parfaite ;
- sauvegarde/reprise schéma 93.

Le QA physique valide 54/54 nœuds connectés, tous les connecteurs, stations et perchoirs.

## Références de continuité

La passe a été recroisée avec la documentation des scènes restaurées et du Workprint/Assembly Cut publiée par Alien vs. Predator Galaxy, notamment les séquences Murphy, Boggs/Rains/Golic, Clemens, Andrews, message de la Compagnie, libération du Runner par Golic et finale alternative. Les dialogues du jeu restent reformulés : aucun script du film n’est reproduit.
