# Alien 3 — Fiorina 161 DLC V89

## Objet

V89 est une extension cumulative de la Chronique MIRE Alien 3 V88 pour **Aliens: Tantalus Frontier**. Elle conserve la campagne continue Fiorina 161 et ajoute une seconde couche de simulation, de rejouabilité et de fidélité : deux montages distincts, un Runner piloté par un directeur de tension, une quatrième route physique, un registre individuel des détenus et une finale différenciée.

Base auditée : `496996f5ea557d970ec625aa346876f3eaed1c5f`.

## Accès

L'opération reste enregistrée sous :

- opération : `alien3-fiorina-161`
- campagne : `special-alien3-fiorina-161`
- template : `fiorina-161-prison`
- année de reconstruction : 2179
- mode : SURVIVAL / Chronique MIRE solo

Le lancement utilise le système normal de planification des opérations. L'archive remplace le monde stratégique par la reconstruction Fiorina 161 sans ajouter une planète fictive à la carte persistante.

## Les deux reconstructions

Deux terminaux sont disponibles au début de l'archive, avant la validation de l'EEV. Le choix devient ensuite irréversible pour cette partie.

### Montage cinéma

- hôte canin Spike ;
- progression directe vers le plan incendiaire puis la fonderie ;
- finale avec émergence visible de l'embryon royal pendant la chute.

### Assembly Cut

- hôte bovin Babe ;
- route supplémentaire par la cuve à déchets ;
- sacrifice de Junior ;
- capture temporaire du Runner ;
- libération par Golic et mort d'Arthur/Golic ;
- finale sans émergence visible de l'embryon royal.

Les deux branches sont volontairement séparées. Le DLC ne mélange pas leurs événements contradictoires dans une seule chronologie.

## Structure jouable

Le graphe V89 contient :

- 24 nœuds physiques ;
- 33 connexions ;
- 6 zones ;
- 4 routes continues entre le point d'arrivée et la plateforme finale.

Routes :

1. bloc carcéral ;
2. passerelles supérieures ;
3. conduits / maintenance ;
4. route de confinement V89 par salle d'assemblée, cuve à déchets et écluse basse.

La quatrième route n'est pas un téléporteur ou un choix de menu : elle est reliée au même graphe de navigation que le reste du niveau.

## Runner Director V89

Le DLC n'ajoute pas plusieurs Aliens pour créer artificiellement de la pression. Un seul Runner est maintenu et passe entre plusieurs états :

- dormant ;
- shadow ;
- hunt ;
- ambush ;
- lure ;
- contained ;
- cooldown.

Le niveau de tension dépend notamment de la distance et du mouvement du joueur. En état d'embuscade, le Runner peut être repositionné vers un point d'embuscade authored hors caméra. Les six ancres sont dans le bloc, la salle d'assemblée, les services, la cuve, la fonderie et le moule.

Les flares sont désormais des objets physiques persistants avec durée de vie. Le Runner peut se diriger vers un flare, le consommer et générer une fenêtre de déplacement. Les tirs conventionnels restent inefficaces et sont comptabilisés par la télémétrie V89.

## Épargne de Ripley

Une attaque potentiellement létale du Runner pendant la première moitié de l'archive peut être interrompue une fois. Le joueur reste à 8 PV, le Runner recule et l'entrée MIRE correspondante est déverrouillée. Cette mécanique reproduit un événement de narration sans transformer le Runner en allié : sa chasse reprend ensuite.

## Registre des détenus

V89 suit individuellement 16 détenus nommés : Dillon, Morse, Golic, Junior, Murphy, Boggs, Rains, David, Kevin, Jude, Troy, William, Gregor, Arthur, Frank et Eric.

Le runtime conserve leur statut (`active`, `wounded`, `deceased`, `missing`) dans la sauvegarde. Les silhouettes encore actives se déplacent physiquement dans la prison aux phases tardives ; les décès déclenchés par les routes cinéma/Assembly mettent immédiatement à jour le registre.

## Assembly Cut — cuve à déchets

La branche Assembly verrouille le passage `fire-maze -> leadworks` tant que le confinement n'est pas résolu.

Séquence :

1. le joueur attire le Runner vers la cuve ;
2. Junior se sacrifie et le sas se ferme ;
3. le Runner est temporairement inactif ;
4. la chronologie continue pendant quelques secondes ;
5. Golic rompt le confinement ;
6. Arthur et Golic sont enregistrés comme morts ;
7. le Runner redevient actif ;
8. l'accès à la fonderie est libéré.

Cette séquence est sauvegardée et restaurée sans pouvoir dupliquer les événements.

## Compagnie / Patna

La phase Company dispose maintenant :

- d'une équipe de récupération visible ;
- d'un manifeste Patna ;
- de la confrontation enregistrée comme récupération corporative ;
- d'un suivi de Morse blessé et d'Aaron dans la séquence finale.

La Compagnie n'est pas transformée en vague de soldats génériques : elle reste un événement narratif de fin d'archive.

## Finale V89

L'interaction avec la plateforme finale lance une séquence à plusieurs étapes plutôt qu'une résolution instantanée :

1. plateforme ;
2. Morse touché ;
3. dernier geste d'Aaron ;
4. chute vers la fournaise ;
5. résolution de l'archive.

La présentation de l'embryon royal dépend du montage choisi.

## Dossiers MIRE V89

V89 ajoute 12 dossiers au corpus V88 de 13 entrées, soit **25 dossiers de Chronique Alien 3 disponibles dans la pile V88+V89** :

- montage cinéma ;
- Assembly Cut ;
- Spike ;
- Babe ;
- Junior ;
- Golic ;
- cuve à déchets ;
- registre des résidents ;
- Patna ;
- Morse ;
- épargne du Runner ;
- Runner Director.

Le tracker alterne le corpus V88 et l'extension V89 afin que les dossiers de base ne soient jamais masqués.

## Preuves V89

10 preuves persistantes sont suivies : choix du montage, variante d'hôte, registre, cuve, sacrifice Junior, libération Golic, épargne, Patna, Morse et Runner Director.

## Score MIRE

La note finale est calculée sur :

- synchronisation de la Chronique V88 ;
- pourcentage de preuves V89 ;
- dégâts subis.

Grades : S, A, B, C ou D. Un grade supérieur ajoute un bonus de crédits, sans remplacer les récompenses V88.

## Succès internes V89

Le runtime peut déverrouiller :

- `assembly-complete` ;
- `perfect-organism-recognition` ;
- `no-wasted-fire` ;
- `fury-survivor` ;
- `mire-archivist-161` ;
- `morse-witness`.

Ces identifiants sont dans le payload de récompense V89 afin d'être reliés plus tard à une interface de trophées si le projet le souhaite.

## Sauvegarde / reprise

`captureResumeState()` ajoute `specialOperation.alien3V89` avec schéma 89. Les données persistées couvrent notamment :

- montage choisi et verrouillage ;
- preuves et dossiers ;
- état Assembly ;
- Runner Director ;
- flares persistants ;
- statut de chaque détenu ;
- Compagnie ;
- finale ;
- statistiques et succès.

La couche V88 reste également présente : V89 est cumulative et ne remplace pas son état de progression.

## Installation

À la racine du projet :

```bash
node scripts/install-alien3-dlc-v89.mjs /chemin/vers/aliens-tantalus-frontier
```

Si V88 n'est pas présent, l'installateur V89 installe automatiquement la base V88 fournie dans le pack, puis applique V89.

Test :

```bash
node scripts/test-alien3-dlc-v89.mjs
npm run check
npm run build
```

## Désinstallation

Retour de V89 vers V88 :

```bash
node scripts/uninstall-alien3-dlc-v89.mjs /chemin/vers/aliens-tantalus-frontier
```

Retour complet vers l'état antérieur à V88 :

```bash
node scripts/uninstall-alien3-dlc-v89.mjs /chemin/vers/aliens-tantalus-frontier --full
```

Les quatre fichiers modifiés par la couche V89 sont restaurés depuis `.alien3-dlc-v89-backup`. L'option `--full` appelle ensuite le désinstalleur V88.

## Limites de cette livraison

Le pack est du code et du contenu de runtime. Il réutilise l'infrastructure graphique existante du projet et des dessins runtime pour les éléments V89. Aucun nouveau fichier audio sous licence n'est inclus. Les dialogues sont des formulations originales adaptées au jeu, pas des retranscriptions du scénario du film.
