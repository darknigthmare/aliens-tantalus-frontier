# Alien 3 — Fiorina 161 DLC V90

## Objet

V90 est la troisième couche cumulative de la Chronique MIRE **Alien 3 — Fiorina 161** pour **Aliens: Tantalus Frontier**. Elle inclut tout V88 et V89, puis transforme les deux séquences encore trop abstraites — le plan incendiaire et la fonderie — en objectifs physiques, causaux et sauvegardables.

Base auditée : `496996f5ea557d970ec625aa346876f3eaed1c5f`.

Identifiants conservés :

- opération : `alien3-fiorina-161` ;
- campagne : `special-alien3-fiorina-161` ;
- template : `fiorina-161-prison` ;
- reconstruction : 2179 ;
- mode : SURVIVAL / Chronique MIRE solo.

## Correction de continuité V90

V90 corrige l'ordre de la découverte médicale. L'autopsie ne débloque plus prématurément le dossier `queen-embryo`. La reconstruction doit désormais :

1. préparer le plan au quinitricetyline ;
2. déclencher l'incendie et survivre à sa propagation ;
3. constater l'échec du plan ;
4. revenir physiquement vers l'EEV ;
5. utiliser le scanner médical ;
6. confirmer seulement alors le signal royal ;
7. repartir vers la fonderie et préparer le piège final.

Les dialogues de cette adaptation sont des formulations originales. Aucun dialogue de scénario ou piste audio du film n'est reproduit.

## Topologie V90

Le graphe atteint :

- **30 nœuds physiques** ;
- **44 connexions** ;
- **6 zones** ;
- **4 routes principales réellement continues** ;
- 6 nouveaux nœuds de production reliés aux routes existantes.

Les nouvelles branches servent le gameplay : manifolds incendiaires, stockage chimique, amorçage du plomb, collecteur d'eau et surplomb du four. V90 n'invente pas une cinquième route simplement pour augmenter un compteur.

## Plan incendiaire physique

Le plan au quinitricetyline demande désormais quatre préparations séparées :

- manifold A — David ;
- manifold B — Kevin ;
- manifold C — Troy ;
- manifold D — Gregor.

Les trois caches V88 restent nécessaires, mais elles ne suffisent plus. L'allumeur central refuse la séquence tant que les quatre manifolds ne sont pas armés.

Après l'allumage, le feu ne saute pas instantanément à la phase suivante : six segments se propagent avec des délais différents. Le runtime génère des zones de feu physiques, des dégâts avec cooldown, de la panique et les pertes scénarisées de Frank et Eric. Lorsque l'accident est résolu, le retour vers l'EEV devient l'objectif principal.

## Retour EEV et diagnostic

Le scanner médical V90 n'est interactif qu'après l'échec du plan incendiaire. Il persiste :

- retour à l'EEV ;
- scan terminé ;
- dossier médical ;
- signal royal ;
- levée du report du dossier `queen-embryo`.

La transition vers la fonderie est bloquée tant que le diagnostic n'est pas effectué.

## Fonderie causale

Avant de pouvoir utiliser le moule, deux préparations physiques sont obligatoires :

1. amorcer la cuve de plomb ;
2. pressuriser le collecteur d'eau.

Le moule reste verrouillé si l'une manque. Le sprinkler final reste également inutilisable sans pression d'eau. Dillon et Morse sont associés à leurs postes de fin de plan, avec dossiers et preuves persistantes.

## Runner Sensorial Director V90

V90 ajoute une couche de perception par-dessus le Runner Director V89. Le Runner reste **un seul prédateur** : aucun doublon n'est créé pour simuler de la difficulté.

Le directeur suit :

- bruit courant ;
- pic de bruit ;
- actions bruyantes ;
- temps de silence ;
- zone actuelle ;
- mémoire des zones empruntées ;
- répétition d'une route ;
- pression due aux retours fréquents ;
- fenêtres de furtivité accroupie.

Marcher vite, utiliser des objets bruyants et répéter le même itinéraire augmentent la pression. Ralentir, s'accroupir et changer de route créent de vraies fenêtres de furtivité. Les multiplicateurs de vitesse/dégâts des défis sont appliqués depuis une base conservée afin d'éviter tout cumul au chargement.

## Détenus actifs

Le registre individuel V89 est conservé. V90 lui ajoute un plan d'action collectif :

- affectations par phase ;
- cible physique par tâche ;
- déplacement vers les postes ;
- moral ;
- panique ;
- tâches terminées ;
- pertes scénarisées.

Les détenus ne sont donc plus uniquement des silhouettes de décor aux phases de préparation.

## Présentation des chapitres

Chaque grande transition peut afficher une carte courte et non intrusive :

- épave / EEV ;
- infirmerie ;
- première chasse ;
- Bishop ;
- préparation incendiaire ;
- incendie ;
- retour EEV ;
- fonderie ;
- plomb ;
- choc thermique ;
- Compagnie / finale.

Ces cartes utilisent du texte original de l'adaptation et respectent `reducedMotion` dans le runtime général.

## Atmosphère procédurale

V90 ajoute sans nouveau média sous licence :

- pluie et ruissellement sur les zones côtières ;
- vapeur dans les services et la fonderie ;
- étincelles dans les zones métallurgiques ;
- propagation visuelle des six fronts de feu.

Les effets sont dessinés par le runtime et ne remplacent pas les couches artistiques V88/V89.

## Protocoles de rejouabilité

Trois protocoles existent avant le verrouillage de la reconstruction :

- `archive` : expérience standard ;
- `mire-purist` : flares interdits, Runner légèrement renforcé ;
- `fury-nightmare` : Runner plus rapide et plus dangereux.

Ce sont des variantes de rejouabilité du système MIRE. Elles ne modifient pas la chronologie historique de référence.

## Dossiers et preuves

V90 ajoute **10 dossiers MIRE** au corpus cumulatif :

- quinitricetyline ;
- affectations incendiaires ;
- accident incendiaire ;
- scan médical EEV ;
- signal d'hôte royal ;
- amorçage plomb ;
- collecteur d'eau ;
- dernier plan de Dillon ;
- poste de contrôle de Morse ;
- protocoles MIRE.

Corpus cumulatif : **13 V88 + 12 V89 + 10 V90 = 35 dossiers Alien 3 disponibles**.

V90 suit également 10 nouvelles preuves persistantes. Le parcours QA maximal récupère désormais aussi les 10 preuves V89.

## Grade et succès

Le score V90 peut produire : `S+`, `S`, `A`, `B`, `C`, `D`.

Succès internes possibles :

- `fiorina-fire-chief` ;
- `truth-in-the-eev` ;
- `foundry-ready` ;
- `through-the-flames` ;
- `silent-on-fury` ;
- `mire-archive-90` ;
- `mire-purist` ;
- `fury-nightmare`.

Ils sont intégrés au payload de récompense, prêts à être reliés plus tard à une interface de trophées.

## Sauvegarde / reprise

`captureResumeState()` ajoute `specialOperation.alien3V90` avec schéma 90. Sont persistés notamment :

- protocole de rejouabilité ;
- manifolds et propagation du feu ;
- accident ;
- diagnostic EEV ;
- préparation plomb/eau ;
- bruit et mémoire d'itinéraire ;
- moral/panique et tâches des détenus ;
- preuves, dossiers et succès ;
- présentation de chapitre.

Les états V88 et V89 restent également présents. V90 est cumulative, pas destructive.

## Installation cumulative

À la racine du projet :

```bash
node scripts/install-alien3-dlc-v90.mjs /chemin/vers/aliens-tantalus-frontier
```

Si V89 n'est pas présent, V90 lance l'installateur V89 fourni. Celui-ci installe lui-même V88 si nécessaire.

QA du DLC :

```bash
node scripts/test-alien3-dlc-v90.mjs
```

Sur un checkout complet du jeu, lancer ensuite les contrôles normaux du projet :

```bash
npm run check
npm run build
```

## Désinstallation

Retour de V90 vers V89 :

```bash
node scripts/uninstall-alien3-dlc-v90.mjs /chemin/vers/aliens-tantalus-frontier
```

Retour complet vers l'état antérieur à V88 :

```bash
node scripts/uninstall-alien3-dlc-v90.mjs /chemin/vers/aliens-tantalus-frontier --full
```

L'option `--full` chaîne les désinstallateurs V90, V89 puis V88.

## Limites de livraison

Le pack contient le code, les données, l'installateur et les tests. Il réutilise les assets graphiques du projet et les représentations runtime déjà intégrées. Aucun nouveau contenu audio ou extrait de film sous licence n'est inclus. Le push GitHub n'est pas effectué par le pack.
