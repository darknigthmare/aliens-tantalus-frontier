# Aliens: Tantalus Frontier — DLC Alien 3 / Fiorina 161 V88

## Positionnement

Cette extension ajoute une Chronique MIRE jouable consacrée à Fiorina 161. Elle est conçue comme une reconstruction interactive fidèle aux grands événements d’*Alien 3*, adaptée au gameplay 2D metroidvania de Tantalus Frontier. Les textes de mission et de codex sont des formulations originales du projet : aucun dialogue long du scénario du film n’est recopié.

Le DLC utilise l’identifiant de campagne `special-alien3-fiorina-161`, l’opération `alien3-fiorina-161` et le template physique `fiorina-161-prison`.

## Parcours complet

1. **Le Choc** — arrivée sur la côte de Fiorina 161, inspection des données de l’EEV.
2. **Les morts ne dorment pas** — infirmerie, morgue, indices biologiques et suspicion d’un embryon royal.
3. **Le Dragon** — premier assaut du Runner et fuite à travers le bloc carcéral.
4. **Un visage connu** — récupération des fragments de mémoire de Bishop.
5. **Pas de fusils** — récupération de trois charges incendiaires et constitution du stock de flares.
6. **Dans le noir** — déclenchement du plan incendiaire et traversée des galeries.
7. **L’Appât** — poursuite dans la fonderie et conduite du Runner vers le moule.
8. **Le Plomb** — déversement de plomb fondu lorsque le Runner se trouve réellement dans le piège.
9. **Choc thermique** — accès à la passerelle haute et activation de l’extinction pour neutraliser le Runner.
10. **La Compagnie** — arrivée de l’équipe de récupération et refus de remettre l’actif biologique.
11. **Dernière décision** — clôture de la reconstruction MIRE et extraction des données de l’archive.

## Level design

Le niveau Fiorina est un espace continu de 6200 unités, découpé en six zones : côte/EEV, infirmerie-morgue, bloc carcéral, galeries techniques, fonderie/leadworks et four principal. Vingt nœuds physiques, vingt-six connexions et trois routes complètes relient le spawn à la fin : axe carcéral au sol, route haute par morgue/passerelles et réseau de maintenance bas.

Les routes ne sont pas des choix de menu : elles utilisent les plateformes, échelles, conduits et portes du runtime V52. Les risques incluent obscurité, vapeur et feu industriel. Les couches visuelles existantes du projet sont réutilisées pour assurer une installation légère ; le runtime ajoute par-dessus les stations Fiorina, le piège, le plomb, les silhouettes de survivants et le HUD MIRE.

## Runner

Le DLC conserve un seul prédateur hostile. Tous les ennemis génériques créés par le bootstrap normal sont supprimés à l’entrée de l’archive. Le profil Runner déjà présent dans le catalogue est privilégié ; un profil de secours n’est utilisé que si le catalogue ne le fournit pas.

Le Runner est invulnérable aux dégâts conventionnels. Le tir n’utilise pas le fusil du loadout : il lance un flare, consomme une charge et peut provoquer une courte hésitation de la créature. La victoire exige l’ordre suivant : Runner dans le moule, plomb fondu, passage à la vanne haute, choc thermique. L’état du Runner — position, santé, orientation, vitesse et phase — est sauvegardé.

## Règles de l’archive

- Opération solo : l’escouade Echo-9 n’est pas injectée dans la simulation.
- Aucun véhicule.
- Pas de tir balistique ; le bouton de tir devient une action flare.
- Tourelles, mines, explosifs et drones offensifs sont bloqués par la Chronique.
- Le Runner ne peut pas être éliminé avec une arme amenée depuis la campagne principale.
- La campagne stratégique reste intacte ; l’archive utilise Fiorina 161 comme nom et biomes de mission sans ajouter artificiellement une vingt-et-unième planète au système stratégique.

## Codex MIRE

Treize entrées sont déverrouillées progressivement : Fiorina 161, EEV/Sulaco, infirmerie, embryon royal, Runner, Bishop endommagé, doctrine sans armes, plan incendiaire, leadworks, piège au plomb, choc thermique, équipe de récupération et enregistrement final. Pendant la mission, la commande normalement liée au tracker fait défiler les dossiers déverrouillés dans un panneau MIRE temporaire.

## Sauvegarde et reprise

Le bloc `specialOperation.alien3V88` conserve la phase, l’horloge, la synchronisation, les caches, les flares, le statut des pièges, les survivants et le codex. `specialOperation.alien3RunnerV88` conserve la créature. Chaque changement de chapitre émet également un `objective-action`, ce qui réutilise le chemin de persistance déjà établi dans l’application.

Le redémarrage après échec replace le joueur à une position correspondant au chapitre en cours. Il n’introduit pas de nouvel identifiant de checkpoint incompatible avec le filtre de reprise déjà présent dans `game-production-core.js`.

## Récompenses

La fin ajoute aux récompenses normales : 850 crédits, 35 salvage, 8 intel, le drapeau `alien3Archive`, le score `mireSynchronization`, le drapeau `canonRoute`, le nombre de survivants et la liste des entrées de codex obtenues.

## Installation

Depuis la racine du dépôt Tantalus Frontier :

```bash
node /chemin/vers/ALIEN3_DLC_v88_PATCH/scripts/install-alien3-dlc-v88.mjs . --dry-run
node /chemin/vers/ALIEN3_DLC_v88_PATCH/scripts/install-alien3-dlc-v88.mjs .
node scripts/test-alien3-dlc-v88.mjs
npm run check
npm run build
```

L’installateur vérifie des ancres uniques avant toute écriture, sauvegarde les cinq fichiers modifiés dans `.alien3-dlc-v88-backup`, copie les nouveaux modules et produit `ALIEN3_DLC_V88_INSTALL_REPORT.json`. En cas d’échec pendant l’écriture, les fichiers modifiés sont restaurés.

Pour retirer le DLC :

```bash
node scripts/uninstall-alien3-dlc-v88.mjs .
```

## Base auditée

Le patch a été préparé sur le commit GitHub `496996f5ea557d970ec625aa346876f3eaed1c5f`. Si la branche locale a évolué, l’installateur peut encore fonctionner si toutes les ancres restent uniques ; sinon il s’arrête avant de modifier le projet.
