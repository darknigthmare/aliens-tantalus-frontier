# Alien 3 — Fiorina 161 V94 — Fidelity / Workprint

V94 est une couche cumulative installée au-dessus de V88→V93. Elle ne crée ni une cinquième route ni un second Runner. Elle densifie la même Chronique MIRE avec des éléments encore absents ou trop abstraits dans les versions précédentes.

## Objectif

La passe V94 isole trois profils de reconstruction :

1. **Cinéma 1992** — hôte canin, finale cinéma.
2. **Assembly Cut** — hôte bovin, cuve à déchets et chaîne Golic.
3. **Workprint** — base Assembly + variantes archivées spécifiques, sans écraser les deux autres profils.

Le profil choisi est verrouillé dès que le journal EEV est lu afin d’empêcher une fusion opportuniste des continuités pendant la même partie.

## Topologie

- 62 nœuds physiques.
- 102 connexions.
- 4 routes complètes conservées.
- 6 zones.
- 32 connecteurs verticaux dans le QA physique.
- 160 surfaces reconstruites dans le QA.
- 11 stations V94.

Les huit nouveaux nœuds sont des branches : analyse EEV, incident de l’épave, estrade de foi, Battery Duty, cache Golic, jonction du piège, reroutage de fonderie et transmission finale.

## Fidelity systems

### Chaîne EEV ↔ Bishop

Le journal EEV peut être analysé dès sa récupération. La preuve n’est considérée complète qu’après recoupement avec les fragments de Bishop.

### Foi et cohésion

L’estrade de l’Assembly Hall permet d’observer la cohésion des détenus. La foi et la confiance de Ripley réduisent légèrement la panique systémique pendant l’incendie, sans annuler les pertes historiques imposées par l’archive.

### Confrontation de l’épave

Une séquence non graphique se déclenche près de l’épave. Le joueur garde ses commandes et doit rejoindre une zone sûre avant l’expiration d’un court délai. Dillon intervient dans tous les cas ; une résolution propre augmente davantage la confiance.

### Battery Duty

Pour Assembly et Workprint, deux cellules doivent être testées et raccordées avant d’autoriser la mise à feu du piège. Le montage cinéma ne reçoit pas cette contrainte obligatoire.

### Workprint

Le profil Workprint ajoute notamment :

- cache Golic ;
- variante du message de la Compagnie ;
- variante de la chaîne de libération de Golic ;
- trace sensorielle rouge non bloquante du Runner ;
- risque volontaire de Ripley pendant le dernier rabattage ;
- information sur l’interdiction des images de récupération ;
- ordre de montage final distinct ;
- activation manuelle du choc thermique dans l’archive.

Les dialogues sont reformulés ; aucun script du film n’est reproduit.

### Bait-and-chase

Trois reroutages de corridor doivent être commandés pendant la fonderie. Le même Runner est déplacé vers des surfaces physiques différentes à mesure que le joueur improvise le rabattage vers le moule.

### Transmission finale

La borne haute de la fonderie doit être atteinte après la chaîne Patna/Aaron/Morse afin de sceller la télémétrie MIRE avant la fermeture de l’archive.

## Archives

V94 ajoute :

- 18 dossiers ;
- 18 preuves ;
- 6 beats Fidelity ;
- grade maximal **S+++++**.

Total cumulatif Alien 3 : **92 dossiers MIRE**.

## QA

Le QA V94 vérifie :

- 62 nœuds / 102 arêtes / 4 routes ;
- 18 dossiers / 18 preuves ;
- sélection Workprint → base Assembly ;
- confrontation non graphique contrôlable ;
- chaîne EEV/Bishop ;
- Battery Duty bloquant réellement l’igniteur ;
- deux cellules + jonction ;
- cache Golic ;
- Runner POV ;
- trois reroutages ;
- variantes Workprint ;
- transmission finale ;
- archive parfaite ;
- sauvegarde/reprise schéma 94 ;
- grade S+++++.

Le QA physique valide 62/62 nœuds connectés, 32 connecteurs, 160 surfaces et 11/11 stations supportées.

## Références de continuité

La passe a été recroisée avec la comparaison Assembly/Theatrical/Workprint et les listes de scènes supprimées/restaurées publiées par Alien vs. Predator Galaxy. Les éléments utilisés ici incluent Battery Duty, Prison Faith, les variantes Golic, le message de la Compagnie et les différences de la poursuite/finale Workprint.
