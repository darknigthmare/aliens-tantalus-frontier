# ALIEN 3 — FIORINA 161 — V99 ADAPTIVE PURSUIT

V99 prolonge la V98 Hybrid Director sans modifier la topologie certifiée de Fiorina 161.

## Objectifs

- rendre les poursuites moins scriptées ;
- conserver un seul Runner physique ;
- lisser davantage la caméra lors des changements de secteurs ;
- transformer le Codex Alien 3 en base documentaire navigable ;
- préserver les contrats V88→V98 et leurs sauvegardes.

## Topologie conservée

- 72 nœuds ;
- 119 connexions ;
- 4 routes ;
- 6 zones ;
- 9 secteurs hybrides ;
- 3 plans de profondeur ;
- 36 connecteurs verticaux ;
- 177 surfaces de support.

## Adaptive Pursuit

Cinq poursuites physiques exploitent uniquement des secteurs déjà existants :

1. Brèche Tempête — cour extérieure ;
2. Coupe du Bloc — bloc carcéral ;
3. Retour Communications — assemblage / communications ;
4. Coupure Fonderie — grande fonderie ;
5. Ombre Patna — four / arrivée Patna.

Chaque poursuite possède un segment, une sortie claire, une pression cible, un plan de coupure privilégié et un contrat caméra. Le Runner n'est jamais dupliqué : V99 manipule uniquement le même acteur créé par V88.

La pression 0–100 est un indicateur de densité de chasse. Elle n'affiche pas les coordonnées du Runner.

## Ponts caméra

Les neuf contrats caméra V98 disposent maintenant d'un pont d'entrée. Lorsqu'un secteur change, la composition passe progressivement d'un contrat à l'autre au lieu de basculer instantanément.

## Codex Alien 3 V99

Le Codex dédié passe de 78 à 90 entrées et reste séparé des 130 dossiers MIRE.

Nouveautés :

- recherche dans titre / catégorie / corps ;
- filtres TOUS / NON LUS / FAVORIS ;
- liens croisés entre fiches ;
- historique de navigation ;
- septième terminal physique dans la fonderie ;
- favoris persistants ;
- 90 entrées sauvegardées indépendamment du MIRE.

Commandes dans l'interface :

- `C` : ouvrir / fermer ;
- `[` / `]` : catégorie ;
- `,` / `.` : page ;
- `B` : favori ;
- `/` : saisir une recherche ;
- `K` : filtre rapide ;
- `L` : suivre un lien ;
- `H` : revenir dans l'historique.

## Archive parfaite V99

Conditions principales : héritage parfait V98, cinq poursuites terminées, neuf ponts caméra visités, Codex 90/90 débloqué et lu, recherche + filtre + lien + historique utilisés, et les 18 preuves V99 récupérées.

Grade maximal : `S++++++++++`.

## Sauvegarde

Schéma V99 sauvegardé sous `specialOperation.alien3V99` : poursuites, pression, coupures, ponts caméra, requête de recherche, filtre, historique, liens, extension Codex, preuves, télémétrie, succès et Archive parfaite.
