# Alien 3 — Fiorina 161 DLC V91 — Archive vivante

Base auditée : `darknigthmare/aliens-tantalus-frontier` au commit `496996f5ea557d970ec625aa346876f3eaed1c5f`.

V91 est une couche cumulative : V88 (campagne Fiorina), V89 (cinéma/Assembly + Runner Director + prisonniers/Patna), V90 (quinitricetyline + retour EEV + fonderie plomb/eau + bruit) restent intactes et sont installées automatiquement si elles manquent.

## Objectif V91

La V90 avait déjà la progression et les systèmes principaux. V91 transforme les morceaux encore trop abstraits en événements physiques et remet plusieurs beats restaurés de l’Assembly Cut dans une chaîne causale jouable, sans reproduire le scénario ou les dialogues du film.

### Topologie

- 40 nœuds physiques, 60 connexions, 6 zones.
- Les 4 routes V89/V90 restent les seules routes de bout en bout : aucune cinquième route factice n’est ajoutée.
- 10 branches physiques supplémentaires : lit de Clemens, mémorial, plafond du réfectoire, communications, puits de ventilation, balise du tunnel, trois pistons de fonderie et cage Patna.

### Archive vivante

13 nouvelles preuves / 13 nouveaux dossiers MIRE V91 :

1. Rite funéraire 161.
2. Murphy / puits de ventilation.
3. Boggs, Rains et Golic / expédition des galeries.
4. Incident Clemens / infirmerie.
5. Incident Andrews / réfectoire.
6. Directive de la Compagnie.
7. Chaîne d’évasion/libération de Golic.
8. Piston maze de la fonderie.
9. Cage Patna.
10. Bishop II.
11. Dernier refus d’Aaron.
12. Custodie de Morse.
13. Carte de pression du Runner.

Cumul : 13 V88 + 12 V89 + 10 V90 + 13 V91 = **48 dossiers Alien 3** dans les couches du DLC.

### Assembly Cut causal

En Assembly Cut, le Runner piégé dans la cuve à déchets ne se libère plus sur un simple délai. Il reste réellement contenu tant que le joueur n’a pas regagné la console de communication et envoyé l’état du spécimen. La réponse de la Compagnie interdit sa destruction ; seulement après ce beat la chaîne Golic peut reprendre et le Runtime V89 déclenche sa libération.

Le montage cinéma reste indépendant et ne dépend jamais de cette station.

### Runner Director V91

Le V91 complète les systèmes V89/V90 par une carte de pression :

- chaleur dérivée du bruit V90 et des routes répétées ;
- mémoire de zone ;
- passages d’ombre sans attaque ;
- interceptions prédictives hors caméra ;
- dernière position bruyante ;
- cooldown d’interception ;
- aucun clonage du Runner : le même acteur physique est repositionné seulement lorsqu’il est hors champ et à grande distance.

### Fonderie : corridor de rabattement

Après préparation du plomb et du collecteur d’eau V90, le moule reste verrouillé tant que trois pistons n’ont pas été cyclés dans l’ordre :

1. Piston A — dérivation.
2. Piston B — sas haut.
3. Piston C — entonnoir.

Chaque action produit du bruit, réveille la pression du Runner et déplace son objectif de chasse vers l’étape suivante. Une mauvaise commande est refusée et comptée dans le score V91. Le troisième piston autorise seulement le rabattement ; la condition V88 qui exige que le Runner soit réellement à portée du moule reste active.

### Compagnie et finale

- Cage de confinement Patna visible et inspectable.
- Bishop II distingué du Bishop synthétique endommagé.
- Beat Aaron enregistré dans la séquence finale.
- Morse conserve son statut de témoin survivant/blessé puis de détenu de la Compagnie.
- Les variations cinéma/Assembly V89 restent inchangées pour le sacrifice final.

### Score et succès V91

Le grade V91 prolonge le grade V90 jusqu’à `S++` et tient compte des 13 preuves, de la discipline des pistons et de la capacité à lire le directeur du Runner. Succès internes : archive complète, pistons sans erreur, interception prédictive vécue, chaîne Assembly causale, Compagnie entièrement documentée et maintien de la ligne.

## Installation

Depuis la racine du projet :

```bash
node /chemin/vers/ALIEN3_DLC_v91_PATCH/scripts/install-alien3-dlc-v91.mjs .
node scripts/test-alien3-dlc-v91.mjs
node scripts/test-alien3-physical-v91.mjs
npm run check
npm run build
```

L’installateur V91 installe automatiquement V90, donc V89 puis V88, si nécessaire.

Désinstallation de V91 uniquement :

```bash
node scripts/uninstall-alien3-dlc-v91.mjs .
```

Retour complet à l’état pré-V88 :

```bash
node scripts/uninstall-alien3-dlc-v91.mjs . --full
```

## Limites de validation

Le pack inclut ses QA autonomes et un test d’installation/désinstallation bit-à-bit. Le `npm run check` et le `npm run build` du dépôt complet doivent être exécutés dans un checkout complet du projet ; le pack ne prétend pas avoir téléchargé les ~1,7 Go du dépôt et de ses assets dans l’environnement de génération.
