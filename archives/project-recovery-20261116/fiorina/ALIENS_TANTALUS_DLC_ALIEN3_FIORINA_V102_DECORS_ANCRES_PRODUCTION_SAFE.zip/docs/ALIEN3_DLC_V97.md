# Alien 3 — Fiorina 161 V97 · Hybrid Archive

V97 réadapte l’intégralité du DLC Alien 3 V88→V96 au principe de vue hybride déjà retenu pour le DLC Alien : profondeur 2.5D dans les espaces larges, vraie vue 2D latérale dans les couloirs, conduits et séquences qui exigent un cadrage précis.

## Principe

La topologie certifiée reste inchangée : 72 nœuds, 119 arêtes, 4 routes, 6 zones. V97 superpose 9 contrats de mise en scène sur le même monde de 6200 unités. Il n’existe donc aucune route factice ajoutée uniquement pour la perspective.

### Secteurs hybrides

1. 0–720 — Cour de la tempête — profondeur.
2. 720–1700 — EEV / infirmerie — 2D latérale.
3. 1700–2840 — Bloc carcéral — profondeur.
4. 2840–3520 — Galeries techniques — 2D latérale.
5. 3520–4020 — Assemblage / communications — profondeur.
6. 4020–4700 — Fonderie large — profondeur.
7. 4700–5180 — Pistons / moule — 2D latérale.
8. 5180–5750 — Four / arrivée Patna — profondeur.
9. 5750–6200 — Plateforme finale — 2D latérale.

Le changement est automatique lorsque le joueur franchit la limite physique correspondante. Le mode ne peut donc pas être forcé dans une zone où il nuirait au level design.

## Trois plans de profondeur

En mode profondeur :

- arrière : échelle 0,82 ; furtivité renforcée ; pression Runner réduite ;
- médian : plan neutre ;
- avant : échelle 1,08 ; exposition supérieure ; pression Runner accrue.

Commandes : W/S ou flèches haut/bas changent de plan. Dans ces secteurs, ces touches sont retirées du système d’échelle/crouch avant l’appel au moteur latéral afin d’éviter les doubles commandes. La marche gauche/droite, le saut et les autres systèmes restent ceux du jeu principal.

En mode 2D tension, le joueur et le Runner sont automatiquement recentrés sur le plan médian et le moteur retrouve ses contrôles latéraux normaux, notamment échelles et accroupissement.

## Runner multi-plan, mono-acteur

V97 ne crée jamais de second Runner. L’acteur `enemy-006-runner` reçoit seulement un plan de profondeur persistant. Il peut changer de plan selon la distance et la chaleur du Hunter Director.

Une attaque de contact en mode profondeur ne touche le joueur que si les deux acteurs sont sur le même plan. Une attaque qui passe sur un autre plan devient une esquive de profondeur enregistrée. En 2D latérale, les règles de contact V88→V96 restent intégralement actives.

## Rendu

Le moteur conserve ses sprites 2D. V97 applique selon le plan :

- changement d’échelle autour de la ligne de sol ;
- décalage vertical de rendu ;
- grille de sol perspective ;
- parallaxe supplémentaire ;
- indicateur HUD du plan ;
- annonce courte lors du passage profondeur ↔ 2D.

Le gameplay physique X/Y d’origine n’est pas réécrit : la profondeur est une troisième coordonnée logique dédiée au DLC. Cela évite de casser plateformes, portes, échelles, pièges et sauvegardes héritées.

## Codex Alien 3 dédié

V97 ajoute un Codex autonome de 66 entrées, séparé des 130 dossiers MIRE V88→V96.

Catégories : Archive, Gameplay, Lieux, Personnages, Xénobiologie, Événements et Systèmes.

Le contenu couvre notamment : Fiorina 161, EEV, infirmerie, morgue, bloc carcéral, galeries, cuve à déchets, communications, fonderie, moule, four, Patna, Ripley, Dillon, Clemens, Andrews, Aaron, Morse, Golic, Junior, Murphy, Boggs, Rains, Bishop, Bishop II, Runner, hôtes Cinéma/Assembly, embryon royal, perchoirs, plan incendiaire, capture Assembly, libération Golic, plomb, choc thermique, quinitricetyline, pistons, volets, vapeur, flares, audio optionnel, sauvegarde et mode hybride.

### Terminaux

Cinq terminaux physiques débloquent le Codex par chapitres :

- EEV — Arrivée ;
- Bloc carcéral — Fiorina ;
- Service — Chasse ;
- Fonderie — Fonderie ;
- Patna — Finale.

Le dernier terminal permet d’atteindre 66/66 entrées si les précédents ont été consultés.

`C` ouvre/passe à la page suivante. `Shift+C` revient à la page précédente. `Shift+Q` peut également ouvrir/cycler le Codex via le tracker sans remplacer l’usage normal de Q.

L’overlay n’interrompt pas artificiellement la simulation : il reste un outil MIRE de terrain.

## Sauvegarde V97

Le schéma 97 conserve : secteur hybride, mode courant, plan joueur, plan Runner, temps passé dans chaque type de vue, transitions, esquives/contact de profondeur, secteurs visités, progression du Codex, pages lues, terminaux consultés, preuves, télémétrie et état Archive parfaite.

## Archive parfaite

La perfection V97 exige : perfection V96 héritée, 9/9 secteurs, usage des trois plans, temps significatif dans les deux modes, 66/66 entrées du Codex, les cinq terminaux et interaction effective avec le Runner sur le système de profondeur.

Grade maximal : `S++++++++`.

## Production Safe

Le pack V97 est cumulatif V88→V97. L’installateur Production Safe ne conserve dans une distribution publique que les modules runtime nécessaires et les modifications des fichiers de liaison. Les rapports, backups, tests et docs d’installation sont retirés avant `npm run check` et `npm run build`. En cas d’échec, le rollback restaure la base pré-DLC.
