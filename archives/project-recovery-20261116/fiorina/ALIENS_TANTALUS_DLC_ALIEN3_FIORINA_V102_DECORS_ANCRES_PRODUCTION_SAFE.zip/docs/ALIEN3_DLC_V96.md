# Alien 3 — Fiorina 161 V96 · Atmosphere / Optional Audio

V96 est cumulative au-dessus de V88→V95. Elle ne crée ni cinquième route ni nouvelle caste : elle approfondit les 72 nœuds / 119 connexions déjà certifiés avec une couche d’atmosphère, audio optionnel, accessibilité et climat.

## Atmosphère

Six microclimats sont suivis : côte/EEV, infirmerie, bloc carcéral, galeries techniques, fonderie et four/Patna. Le runtime conserve température, humidité, exposition au froid, contrainte thermique, visibilité, puissance et masque vapeur. Trois disjoncteurs, la sono du bloc, un déflecteur vapeur et l’extracteur du four créent des compromis entre lisibilité, cohésion des détenus, bruit et Hunter Director.

## Audio optionnel

V96 étend `AUDIO_SLOTS_V77.sfx` avec huit emplacements :

- `assets/audio/sfx/alien3-wind.*`
- `assets/audio/sfx/alien3-runner.*`
- `assets/audio/sfx/alien3-steam.*`
- `assets/audio/sfx/alien3-mire.*`
- `assets/audio/sfx/alien3-foundry.*`
- `assets/audio/sfx/alien3-prison.*`
- `assets/audio/sfx/alien3-company.*`
- `assets/audio/sfx/alien3-heartbeat.*`

Extensions acceptées par le scanner existant : MP3, WAV, OGG, M4A et WebM. Aucun média n’est obligatoire. Si un slot est absent, le runtime utilise une synthèse légère ou le silence ; la progression ne dépend jamais d’un fichier audio.

## Accessibilité acoustique

Le Runner produit une bande de menace `lointain / proche / critique` et une direction `GAUCHE / DROITE / CENTRE` sans exposer ses coordonnées exactes. Les captions sont visibles dans le HUD et persistées par événements V96.

## Progression V96

- 18 dossiers MIRE V96 ; total cumulatif visé : 130.
- 18 preuves V96.
- 8 stations physiques sur les surfaces V95.
- 8 cues audio optionnels.
- diagnostic acoustique final ; il exige au moins 6 cues et les deux directions gauche/droite mais jamais un fichier audio réel.
- grade V96 maximal : `S+++++++`.

## Production Safe

L’installateur production V96 installe V88→V96, conserve uniquement les 18 modules runtime et les modifications publiques, puis lance `npm run check` et `npm run build`. En cas d’échec, six fichiers de base sont restaurés bit-à-bit et les modules runtime sont supprimés.
