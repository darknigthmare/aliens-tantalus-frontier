# ALIEN 3 — Fiorina 161 — Codex de Level Design V101

Règles de production exécutables pour densifier les fonds, remplacer les placeholders et garantir une cohérence fonctionnelle entre décor, gameplay, lore et lisibilité.

## Objectifs de production

- Remplacer les placeholders visuels par une grammaire de décor cohérente avec Fiorina 161.
- Garantir qu'aucun prop n'existe seulement pour « remplir ».
- Conserver la lisibilité du joueur, du Runner, des routes et des interactions malgré une forte densité.
- Maintenir quatre routes et la topologie validée ; la densification ne crée pas de faux passages.
- Ancrer tous les fonds au bord supérieur du champ de jeu.
- Utiliser la profondeur et le parallaxe sans transformer les décors en obstacles trompeurs.

## Échelle de référence

- **playerHeight** : 1,80 m environ
- **door** : 2,1–2,4 m
- **railing** : 1,0–1,15 m
- **catwalkClearance** : 2,2 m minimum
- **maintenanceGap** : 0,9–1,2 m
- **largeMachine** : doit montrer support + alimentation + accès

## Composition d'écran

- Bandes : 0–18 % plafond / silhouette haute ; 18–45 % fond structurel ; 45–72 % architecture médiane ; 72–88 % plan jouable ; 88–100 % avant-plan ponctuel.
- Rythme : dense / respiration / landmark / respiration / dense.
- Zone de lecture : au moins 15 % de l’écran sans gros prop autour du joueur pendant une poursuite.

## Règles exécutables (32)

### LD-001 — Silhouette avant détail
**Section :** lecture.  
Chaque écran doit être compréhensible en aplats : sol, plafond, obstacle principal et destination restent lisibles avant l’ajout du petit décor.

### LD-002 — Point de fuite utile
**Section :** lecture.  
Toute grande salle possède au moins un axe visuel qui guide vers la progression ou un landmark cohérent, jamais vers un mur sans fonction.

### LD-003 — Pas de chemin décoratif mensonger
**Section :** lecture.  
Aucun alignement lumineux, câble, rambarde ou série de props ne doit suggérer une route inaccessible sauf si le blocage est clairement matérialisé.

### LD-004 — Silence visuel
**Section :** lecture.  
Une zone de repos visuel de 15 à 25 % de l’écran doit séparer deux masses décoratives denses pour préserver les silhouettes et les menaces.

### LD-005 — Échelle humaine constante
**Section :** échelle.  
Portes, lits, passerelles, casiers et machines utilisent Ripley comme référence ; aucun prop ne change arbitrairement d’échelle entre secteurs.

### LD-006 — Machines crédibles
**Section :** échelle.  
Une machine plus haute qu’un étage doit disposer de supports, conduites ou accès de maintenance justifiant sa présence.

### LD-007 — Charge transmise
**Section :** structure.  
Poutres, passerelles et plateformes doivent visuellement reposer sur des appuis ou disparaître dans une masse structurelle crédible.

### LD-008 — Aucune porte flottante
**Section :** structure.  
Toute porte est intégrée dans un mur, cadre, sas, cage ou volume architectural ; jamais posée seule dans le vide.

### LD-009 — Verticalité justifiée
**Section :** structure.  
Échelles et passerelles desservent une destination identifiable : maintenance, cellules, conduits, commandes ou fonderie.

### LD-010 — Prop = fonction
**Section :** fonction.  
Chaque prop visible appartient à une fonction : structure, circulation, énergie, ventilation, détention, soin, stockage, fusion, sécurité ou récupération.

### LD-011 — Familles regroupées
**Section :** fonction.  
Les props techniques apparaissent en grappes fonctionnelles : vanne près des conduites, tableau près des câbles, treuil près d’une charge.

### LD-012 — Pas de remplissage aléatoire
**Section :** fonction.  
Les petits objets ne sont ajoutés que s’ils expliquent l’usage du lieu ou soutiennent une composition, jamais pour remplir un trou.

### LD-013 — Trois couches minimum
**Section :** densité.  
Chaque secteur combine au moins trois couches : fond structurel, set dressing jouable, avant-plan léger.

### LD-014 — Sept familles minimum
**Section :** densité.  
Un secteur important doit montrer au moins sept familles de décor différentes sans casser sa fonction dominante.

### LD-015 — Répétition plafonnée
**Section :** densité.  
Un même archétype ne dépasse pas 18 % des props d’un secteur sauf motif structurel explicitement répétitif comme des barreaux.

### LD-016 — Rythme dense / calme / dense
**Section :** densité.  
La densité varie le long de l’axe X ; elle ne doit jamais former un tapis uniforme de props.

### LD-017 — Fond lent
**Section :** parallaxe.  
Structures lointaines suivent 0,08 à 0,18 du déplacement caméra pour conserver leur masse.

### LD-018 — Plan médian mesuré
**Section :** parallaxe.  
Conduites, racks et architectures secondaires suivent 0,28 à 0,48 du déplacement caméra.

### LD-019 — Avant-plan ponctuel
**Section :** parallaxe.  
Chaînes, vapeur, câbles et silhouettes d’avant-plan suivent 1,08 à 1,20 mais ne masquent jamais durablement le joueur.

### LD-020 — Horizon top-aligné
**Section :** parallaxe.  
Aucune couche de fond ne commence sous le bord supérieur ; les masses principales existent dès y=0.

### LD-021 — Silhouette du Runner
**Section :** combat.  
Dans une zone de chasse, au moins un couloir visuel reste libre autour de la silhouette du Runner pendant ses attaques majeures.

### LD-022 — Couverture non décorative
**Section :** combat.  
Les gros props près du plan jouable ne simulent pas une couverture si le système ne les traite pas comme telle.

### LD-023 — Angles morts intentionnels
**Section :** combat.  
Les occultants en profondeur sont placés pour créer une décision et non pour cacher gratuitement l’action.

### LD-024 — Landmarks uniques
**Section :** navigation.  
Chaque secteur possède au moins deux landmarks reconnaissables de loin et non réutilisés à l’identique ailleurs.

### LD-025 — Entrée et sortie distinctes
**Section :** navigation.  
Les extrémités d’un secteur utilisent silhouettes, éclairage ou signalétique différents pour éviter les demi-tours involontaires.

### LD-026 — Secret intégré
**Section :** navigation.  
Un secret s’intègre à l’architecture : conduit, espace derrière structure, passerelle haute ou maintenance ; jamais une porte flottante hors contexte.

### LD-027 — État de Fiorina
**Section :** lore.  
Métal usé, humidité, réparations, conduites apparentes et équipements réemployés dominent ; aucune technologie propre et neuve sans justification.

### LD-028 — Pas de luxe
**Section :** lore.  
Les espaces carcéraux et techniques restent austères ; couleurs, mobilier et éclairage traduisent récupération et privation.

### LD-029 — Patna tranche visuellement
**Section :** lore.  
Le matériel de la Compagnie est plus propre, portable et normalisé afin de contraster avec Fiorina sans reskin total du décor.

### LD-030 — Source visible
**Section :** lumière.  
Toute lumière forte doit avoir une source plausible : lampe, four, panneau, ouverture ou équipement portable.

### LD-031 — Contraste local
**Section :** lumière.  
Les points interactifs gagnent en contraste local plutôt qu’en ajoutant des contours UI permanents.

### LD-032 — Audit par écran
**Section :** qa.  
Chaque écran vérifie densité, familles, répétition, supports, landmark, lisibilité de route, silhouette joueur/Runner et absence de texte technique.

## Fiches secteur (9)

### hybrid-storm-yard
- **Fonction dominante :** intempérie / épave
- **Densité :** 40 props (cible 34–44)
- **Familles utilisées :** structure, utility, environment, storage, signage
- **Landmarks :** coque EEV brisée ; tour de prise d’air
- **Familles autorisées :** structure, utility, environment, storage, signage
- **Familles interdites :** medical, foundry, company
- **Parallaxe :** fond 0.1, médian 0.34, avant 1.12
- **Intention :** Vent, pluie, drainage, tôles, conduites extérieures. Le vide horizontal sert la lecture de l’épave et des déplacements en profondeur.

**Checklist secteur**
1. Vérifier que les landmarks restent visibles depuis l'entrée.
2. Vérifier que le plus gros groupe de props ne bloque pas le chemin principal.
3. Vérifier au moins une respiration visuelle entre deux grappes denses.
4. Vérifier que les familles interdites sont absentes.
5. Vérifier la cohérence des appuis, conduites et accès de maintenance.
6. Vérifier que les props d'avant-plan ne masquent pas durablement Ripley ou le Runner.
7. Vérifier que la sortie du secteur est distincte de l'entrée.
8. Vérifier que les secrets éventuels utilisent l'architecture existante.

### hybrid-eev-infirmary
- **Fonction dominante :** médical improvisé
- **Densité :** 37 props (cible 30–38)
- **Familles utilisées :** structure, utility, medical, storage, signage, environment
- **Landmarks :** module EEV ; baie médicale
- **Familles autorisées :** structure, utility, medical, storage, signage, environment
- **Familles interdites :** foundry, company
- **Parallaxe :** fond 0.12, médian 0.38, avant 1.08
- **Intention :** Passage du militaire accidenté au soin pénitentiaire : cabinets, rideaux, lavage, câbles provisoires et métal humide.

**Checklist secteur**
1. Vérifier que les landmarks restent visibles depuis l'entrée.
2. Vérifier que le plus gros groupe de props ne bloque pas le chemin principal.
3. Vérifier au moins une respiration visuelle entre deux grappes denses.
4. Vérifier que les familles interdites sont absentes.
5. Vérifier la cohérence des appuis, conduites et accès de maintenance.
6. Vérifier que les props d'avant-plan ne masquent pas durablement Ripley ou le Runner.
7. Vérifier que la sortie du secteur est distincte de l'entrée.
8. Vérifier que les secrets éventuels utilisent l'architecture existante.

### hybrid-cellblock
- **Fonction dominante :** détention
- **Densité :** 47 props (cible 42–54)
- **Familles utilisées :** structure, utility, detention, storage, signage, environment
- **Landmarks :** mur de cellules ; passerelle de surveillance
- **Familles autorisées :** structure, utility, detention, storage, signage, environment
- **Familles interdites :** medical, company
- **Parallaxe :** fond 0.09, médian 0.31, avant 1.14
- **Intention :** Répétition carcérale contrôlée par variations de cages, barreaux, chaînes et passerelles. Les grands rythmes verticaux dominent.

**Checklist secteur**
1. Vérifier que les landmarks restent visibles depuis l'entrée.
2. Vérifier que le plus gros groupe de props ne bloque pas le chemin principal.
3. Vérifier au moins une respiration visuelle entre deux grappes denses.
4. Vérifier que les familles interdites sont absentes.
5. Vérifier la cohérence des appuis, conduites et accès de maintenance.
6. Vérifier que les props d'avant-plan ne masquent pas durablement Ripley ou le Runner.
7. Vérifier que la sortie du secteur est distincte de l'entrée.
8. Vérifier que les secrets éventuels utilisent l'architecture existante.

### hybrid-service-tunnels
- **Fonction dominante :** maintenance
- **Densité :** 45 props (cible 36–46)
- **Familles utilisées :** structure, utility, storage, signage, environment
- **Landmarks :** collecteur principal ; ventilateur axial
- **Familles autorisées :** structure, utility, storage, signage, environment
- **Familles interdites :** medical, company
- **Parallaxe :** fond 0.14, médian 0.46, avant 1.1
- **Intention :** Conduits serrés, vannes, boîtes de jonction, racks, drainage et vapeur. Aucun gros prop ne doit masquer les pièges 2D.

**Checklist secteur**
1. Vérifier que les landmarks restent visibles depuis l'entrée.
2. Vérifier que le plus gros groupe de props ne bloque pas le chemin principal.
3. Vérifier au moins une respiration visuelle entre deux grappes denses.
4. Vérifier que les familles interdites sont absentes.
5. Vérifier la cohérence des appuis, conduites et accès de maintenance.
6. Vérifier que les props d'avant-plan ne masquent pas durablement Ripley ou le Runner.
7. Vérifier que la sortie du secteur est distincte de l'entrée.
8. Vérifier que les secrets éventuels utilisent l'architecture existante.

### hybrid-assembly-communications
- **Fonction dominante :** communications / assemblée
- **Densité :** 34 props (cible 34–44)
- **Familles utilisées :** structure, utility, detention, storage, signage
- **Landmarks :** mur radio ; tableau de relais
- **Familles autorisées :** structure, utility, detention, storage, signage
- **Familles interdites :** medical, foundry
- **Parallaxe :** fond 0.11, médian 0.35, avant 1.08
- **Intention :** Grand volume collectif réemployé pour communications : racks, câbles, vieux mobilier carcéral et axes de circulation clairs.

**Checklist secteur**
1. Vérifier que les landmarks restent visibles depuis l'entrée.
2. Vérifier que le plus gros groupe de props ne bloque pas le chemin principal.
3. Vérifier au moins une respiration visuelle entre deux grappes denses.
4. Vérifier que les familles interdites sont absentes.
5. Vérifier la cohérence des appuis, conduites et accès de maintenance.
6. Vérifier que les props d'avant-plan ne masquent pas durablement Ripley ou le Runner.
7. Vérifier que la sortie du secteur est distincte de l'entrée.
8. Vérifier que les secrets éventuels utilisent l'architecture existante.

### hybrid-foundry-hall
- **Fonction dominante :** fonderie
- **Densité :** 46 props (cible 44–58)
- **Familles utilisées :** structure, utility, foundry, storage, signage, environment
- **Landmarks :** creuset principal ; portique de levage
- **Familles autorisées :** structure, utility, foundry, storage, signage, environment
- **Familles interdites :** medical, detention
- **Parallaxe :** fond 0.08, médian 0.3, avant 1.18
- **Intention :** Le décor explique le flux du métal : four → creuset → levage → moule → laitier. Les chaînes et conduites suivent ce trajet.

**Checklist secteur**
1. Vérifier que les landmarks restent visibles depuis l'entrée.
2. Vérifier que le plus gros groupe de props ne bloque pas le chemin principal.
3. Vérifier au moins une respiration visuelle entre deux grappes denses.
4. Vérifier que les familles interdites sont absentes.
5. Vérifier la cohérence des appuis, conduites et accès de maintenance.
6. Vérifier que les props d'avant-plan ne masquent pas durablement Ripley ou le Runner.
7. Vérifier que la sortie du secteur est distincte de l'entrée.
8. Vérifier que les secrets éventuels utilisent l'architecture existante.

### hybrid-piston-mold
- **Fonction dominante :** piège industriel
- **Densité :** 37 props (cible 32–40)
- **Familles utilisées :** structure, utility, foundry, signage, environment
- **Landmarks :** batterie de pistons ; moule central
- **Familles autorisées :** structure, utility, foundry, signage, environment
- **Familles interdites :** medical, company
- **Parallaxe :** fond 0.12, médian 0.42, avant 1.1
- **Intention :** Densité maîtrisée : priorité aux pistons, alimentation en plomb et réseau d’eau ; le piège doit rester lisible en 2D stricte.

**Checklist secteur**
1. Vérifier que les landmarks restent visibles depuis l'entrée.
2. Vérifier que le plus gros groupe de props ne bloque pas le chemin principal.
3. Vérifier au moins une respiration visuelle entre deux grappes denses.
4. Vérifier que les familles interdites sont absentes.
5. Vérifier la cohérence des appuis, conduites et accès de maintenance.
6. Vérifier que les props d'avant-plan ne masquent pas durablement Ripley ou le Runner.
7. Vérifier que la sortie du secteur est distincte de l'entrée.
8. Vérifier que les secrets éventuels utilisent l'architecture existante.

### hybrid-furnace-patna
- **Fonction dominante :** four / récupération
- **Densité :** 45 props (cible 38–48)
- **Familles utilisées :** structure, utility, foundry, company, storage, signage, environment
- **Landmarks :** bouche du four ; cadre de récupération Patna
- **Familles autorisées :** structure, utility, foundry, company, storage, signage, environment
- **Familles interdites :** medical
- **Parallaxe :** fond 0.09, médian 0.32, avant 1.12
- **Intention :** Contraste entre Fiorina sale et matériel Patna plus propre. Les deux langages visuels se croisent sans se mélanger.

**Checklist secteur**
1. Vérifier que les landmarks restent visibles depuis l'entrée.
2. Vérifier que le plus gros groupe de props ne bloque pas le chemin principal.
3. Vérifier au moins une respiration visuelle entre deux grappes denses.
4. Vérifier que les familles interdites sont absentes.
5. Vérifier la cohérence des appuis, conduites et accès de maintenance.
6. Vérifier que les props d'avant-plan ne masquent pas durablement Ripley ou le Runner.
7. Vérifier que la sortie du secteur est distincte de l'entrée.
8. Vérifier que les secrets éventuels utilisent l'architecture existante.

### hybrid-final-platform
- **Fonction dominante :** finale
- **Densité :** 28 props (cible 28–36)
- **Familles utilisées :** structure, utility, foundry, company, signage, environment
- **Landmarks :** four principal ; plateforme terminale
- **Familles autorisées :** structure, utility, foundry, company, signage, environment
- **Familles interdites :** medical, detention
- **Parallaxe :** fond 0.1, médian 0.36, avant 1.08
- **Intention :** Composition plus épurée pour préserver les silhouettes et la décision finale. Props regroupés aux bords, centre lisible.

**Checklist secteur**
1. Vérifier que les landmarks restent visibles depuis l'entrée.
2. Vérifier que le plus gros groupe de props ne bloque pas le chemin principal.
3. Vérifier au moins une respiration visuelle entre deux grappes denses.
4. Vérifier que les familles interdites sont absentes.
5. Vérifier la cohérence des appuis, conduites et accès de maintenance.
6. Vérifier que les props d'avant-plan ne masquent pas durablement Ripley ou le Runner.
7. Vérifier que la sortie du secteur est distincte de l'entrée.
8. Vérifier que les secrets éventuels utilisent l'architecture existante.

## Catalogue de props (48)

| ID | Famille | Fonction | Couche | Forme | Hauteur |
|---|---|---|---|---|---|
| beam-rib | structure | charpente | far | beam | 120–260 |
| support-column | structure | support | mid | column | 120–300 |
| roof-truss | structure | charpente | far | truss | 90–220 |
| gantry-frame | structure | circulation | mid | gantry | 100–230 |
| bulkhead-frame | structure | séparation | mid | bulkhead | 100–220 |
| service-arch | structure | passage | mid | arch | 90–190 |
| pipe-bank | utility | fluides | mid | pipes | 60–160 |
| steam-main | utility | vapeur | mid | steam-pipe | 70–180 |
| cable-bundle | utility | énergie | far | cables | 40–120 |
| duct-large | utility | ventilation | mid | duct | 65–150 |
| valve-cluster | utility | maintenance | mid | valves | 45–100 |
| vent-fan | utility | ventilation | mid | fan | 55–120 |
| junction-box | utility | électricité | mid | box | 38–88 |
| conduit-rack | utility | distribution | far | rack | 80–170 |
| cell-bars | detention | détention | mid | bars | 100–210 |
| security-gate | detention | sécurité | mid | gate | 110–220 |
| bunk-stack | detention | vie carcérale | mid | bunks | 70–140 |
| restraint-ring | detention | contrainte | mid | ring | 35–72 |
| chain-drop | detention | contrainte | front | chains | 80–190 |
| mesh-cage | detention | sécurité | mid | cage | 90–180 |
| med-cabinet | medical | stockage médical | mid | cabinet | 60–120 |
| gurney | medical | soin | mid | gurney | 42–80 |
| monitor-bank | medical | diagnostic | mid | monitor | 55–110 |
| privacy-curtain | medical | soin | front | curtain | 80–160 |
| wash-station | medical | hygiène | mid | sink | 50–100 |
| crucible-shell | foundry | fusion | mid | crucible | 100–220 |
| mold-carriage | foundry | moulage | mid | mold | 70–160 |
| piston-stack | foundry | pression | mid | piston | 95–210 |
| chain-hoist | foundry | levage | front | hoist | 100–240 |
| slag-bin | foundry | déchets | mid | bin | 50–105 |
| ladle-arm | foundry | transfert | mid | ladle | 100–220 |
| furnace-mouth | foundry | four | far | furnace | 130–290 |
| crate-stack | storage | stockage | mid | crates | 45–110 |
| barrel-cluster | storage | stockage | mid | barrels | 45–100 |
| locker-bank | storage | stockage personnel | mid | lockers | 70–150 |
| pallet-rack | storage | logistique | far | pallet | 70–150 |
| warning-stencil | signage | orientation | mid | stencil | 24–48 |
| sector-board | signage | orientation | mid | board | 42–85 |
| hazard-stripe | signage | sécurité | mid | stripe | 18–34 |
| drain-channel | environment | évacuation | mid | drain | 20–42 |
| puddle-patch | environment | humidité | mid | puddle | 10–24 |
| steam-plume | environment | atmosphère | front | steam | 55–130 |
| rain-sheet | environment | intempérie | front | rain | 120–240 |
| ash-fall | environment | atmosphère | front | ash | 100–220 |
| grime-runoff | environment | usure | far | grime | 80–180 |
| company-case | company | récupération | mid | case | 50–100 |
| portable-lamp | company | éclairage | mid | lamp | 55–120 |
| recovery-frame | company | récupération | far | recovery | 110–230 |

## QA automatique

- Total set dressing : **359 props**.
- Règles : **32**.
- Archétypes : **48**.
- Audit global : **PASS**.

| Secteur | Props | Familles | Répétition max | Landmarks |
|---|---:|---:|---:|---:|
| hybrid-storm-yard | 40 | 5 | 12.5 % | 2 |
| hybrid-eev-infirmary | 37 | 6 | 8.1 % | 2 |
| hybrid-cellblock | 47 | 6 | 10.6 % | 2 |
| hybrid-service-tunnels | 45 | 5 | 8.9 % | 2 |
| hybrid-assembly-communications | 34 | 5 | 11.8 % | 2 |
| hybrid-foundry-hall | 46 | 6 | 8.7 % | 2 |
| hybrid-piston-mold | 37 | 5 | 13.5 % | 2 |
| hybrid-furnace-patna | 45 | 7 | 11.1 % | 2 |
| hybrid-final-platform | 28 | 6 | 10.7 % | 2 |

## Procédure d'audit visuel par écran

Pour chaque capture : vérifier d'abord la silhouette globale, puis le chemin, puis les landmarks, puis les fonctions techniques, puis seulement les petits détails. Si un prop ne répond à aucune fonction ou s'il attire plus l'œil que l'objectif sans raison narrative, il doit être retiré ou déplacé. La densité est une conséquence de la fonction du lieu, pas un objectif isolé.
