# Rapport QA — Alien 3 / Fiorina 161 V91

Date de génération : 24 septembre 2026.
Base auditée : `darknigthmare/aliens-tantalus-frontier` — commit `496996f5ea557d970ec625aa346876f3eaed1c5f`.

## Résultat

**PASS** sur toutes les suites autonomes livrées : V88, V89, V90, V91, topologie physique V91 et installation/désinstallation cumulative.

## V91 — campagne maximale Assembly

- validation V91 : OK ;
- 40 nœuds / 60 connexions / 6 zones ;
- 4 routes de bout en bout, inchangées en nombre ;
- 13/13 preuves V91 récupérées ;
- 13/13 dossiers V91 déverrouillés ;
- 3 pistons de fonderie présents et séquencés ;
- un ordre volontairement faux refusé par le test ;
- corridor de rabattement confirmé avant le moule ;
- Runner unique conservé ;
- 1 interception prédictive hors champ confirmée ;
- pic de chaleur du Hunter Director : 99/100 ;
- chaîne Assembly vérifiée : cuve à déchets → Runner contenu → attente seule insuffisante → message Compagnie → libération Golic ;
- cage Patna inspectée ;
- Bishop II distingué ;
- dernier acte Aaron enregistré ;
- custodie Morse enregistrée ;
- rallye Dillon exécuté pendant la panique sans supprimer l’accident du plan incendiaire ;
- reprise de sauvegarde V91 : OK ;
- grade de la passe de test : S (une erreur de piston est injectée volontairement pour tester le refus).

## QA physique V91

- 40/40 nœuds avec au moins une connexion ;
- 0 nœud orphelin ;
- 16 connecteurs verticaux vérifiés ;
- 111 surfaces simulées par la logique du compilateur de mission ;
- 13/13 stations V91 avec support physique ;
- marches horizontales V91 sans verticalité cachée supérieure au contrat du runtime.

## Régressions

### V88

- 11 phases ;
- 13 dossiers ;
- 20 nœuds / 26 connexions / 3 routes ;
- Runner détruit par plomb + choc thermique ;
- route canonique terminée ;
- synchronisation 100 dans le QA autonome.

### V89

- 24 nœuds / 33 connexions / 4 routes ;
- Assembly Cut complet ;
- 10/10 preuves ;
- flare réellement consommé ;
- impact conventionnel résisté ;
- comportement d’épargne de l’hôte ;
- embuscade du Runner ;
- finale Assembly sans émergence visible.

### V90

- 30 nœuds / 44 connexions / 4 routes ;
- 4/4 manifolds ;
- 6/6 fronts de feu ;
- retour EEV et scan médical ;
- plomb et eau préparés séparément ;
- 10/10 preuves V90 ;
- sauvegarde/reprise V90 conservée.

## Installation cumulative

Le test part d’une fixture antérieure au DLC :

1. V91 lance automatiquement l’installation V90.
2. V90 installe V89 si nécessaire.
3. V89 installe V88 si nécessaire.
4. V91 applique ses quatre modifications d’intégration.
5. Le QA runtime V91 est exécuté dans la fixture installée.
6. Le QA physique V91 est exécuté dans la fixture installée.
7. `uninstall-alien3-dlc-v91.mjs --full` retire V91 puis V90/V89/V88.
8. Les cinq fichiers de base contrôlés sont comparés par SHA-256.

**Résultat : restauration bit-à-bit OK pour les 5 fichiers.**

## Syntaxe

Tous les fichiers `.js` et `.mjs` du pack cumulatif ont passé `node --check` lors de la génération finale.

## Fidélité / sources de conception

La V91 s’appuie notamment sur les différences documentées entre montage cinéma, Assembly Cut et scènes restaurées : capture temporaire du Runner, message de la Compagnie avant la libération par Golic, expédition Boggs/Rains/Golic, incidents Clemens et Andrews, arrivée avec matériel de confinement, et différences de finale. Le texte du DLC est entièrement réécrit pour le jeu ; aucune reproduction longue du scénario ou des dialogues du film n’est incluse.

## Limite explicitement non revendiquée

Le pack ne contient pas le dépôt complet et ses assets massifs. `npm run check` et `npm run build` du projet **complet** doivent donc être lancés dans un checkout complet après installation. Les QA livrés valident le DLC, les ancres d’installation, les couches cumulatives, la topologie simulée et la restauration ; ils ne prétendent pas remplacer la CI du dépôt complet.
