# Intégration Production — Alien 3 V95

## Surface publique

L’installateur `scripts/install-alien3-dlc-v95-production.mjs` est cumulatif V88→V95. Après installation de développement, il supprime les backups `.alien3-*`, rapports d’installation, docs Alien 3 injectées, scripts QA physiques/runtime et désinstallateurs injectés par les différentes couches.

La surface finale attendue conserve :

- 16 modules runtime/définition dans `src/alien3-dlc-v88.js` → `src/alien3-dlc-runtime-v95.js` ;
- les modifications cumulatives de `src/special-operations-v67.js` ;
- `src/mission-levels-v52.js` pointant vers le template V95 ;
- `src/game-production-runtime.js` terminant la chaîne sur `V95ProductionEngine` ;
- `src/app.js` enregistrant et persistant les événements V95.

## Garde transactionnelle

Avant écriture, l’installateur mémorise les cinq fichiers de base et le manifeste audio. Après installation il lance, sauf `--no-build` :

1. `npm run check`
2. `npm run build`

Un échec déclenche une restauration automatique : cinq fichiers de base restaurés, 16 modules runtime supprimés, artefacts privés nettoyés, manifeste audio restauré, `dist/` supprimé.

Le test de rollback V95 force volontairement un `npm run check` en échec et confirme :

- `rollbackBitPerfect: true`
- `runtimeResidue: 0`

## État externe vérifié

Le commit de base audité `496996f5ea557d970ec625aa346876f3eaed1c5f` correspond à un déploiement Vercel READY. Ses logs de build réels montrent l’exécution de `node scripts/build.mjs` et la construction de 3450 entrées catalogue.

La connexion GitHub disponible ici est en lecture seule pour ce dépôt : création de branche, blob et fichier ont été refusées en 403. Aucun push V95 ni déploiement V95 n’est donc revendiqué.
