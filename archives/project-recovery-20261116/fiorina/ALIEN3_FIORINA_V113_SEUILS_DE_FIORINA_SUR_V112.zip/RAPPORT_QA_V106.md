# QA — Alien 3 V106

## Périmètre
Couche incrémentale sur V105 et hôte local simplifié. Aucune exécution de la campagne native complète ni certification des sprites définitifs.

## Résultats
- 47 cas unitaires V106.
- 18 scénarios d’installation ; scripts npm de test synthétiques.
- 67 assertions Chromium en sept groupes, 51 noms distincts. Les répétitions entre parcours sont incluses.
- 7 contrôles du HTML distribué sans API QA.
- V105 : 65 tests unitaires et 17 installations rejoués sans pilote V106 actif. V104 : 37 tests unitaires et 15 installations rejoués séparément.

## Parcours automatisés
| Style | Statut | Santé | Attaques / contacts / esquives | Temps simulé |
|---|---|---:|---|---:|
| rapide | complete | 24 | 2 / 2 / 0 | 18.48 s |
| prudent | complete | 100 | 1 / 0 / 1 | 19.28 s |
| accessibilite | complete | 64 | 2 / 2 / 0 | 18.48 s |
| explorateur-reprise | complete | 64 | 2 / 2 / 0 | 18.48 s |
| rabattage-avec-esquive | complete | 100 | 1 / 0 / 1 | 25.28 s |

Ces traversées utilisent les gestionnaires du clavier et une horloge à 60 Hz. Aucune pose ni progression n’est injectée pendant les parcours. Les scènes préparées pour la comparaison de lampe et l’échec sont distinctes et étiquetées. Les temps reflètent un robot qui connaît le chemin.

## Contrôles nouveaux
- Allumer/éteindre réellement la même lampe sans changer acteurs ni instant de capture.
- Attente physique de Dillon via G, export, import sur une autre page, même pose et même ordre, reprise sur le segment en cours.
- Le poste sûr est présent dans le fichier, validé séparément, et reste reprenable après échec. Un checkpoint corrompu ne remplace pas la session.
- Un bruit dans le même corridor utilise la distance réelle ; un détour reste évalué sur le graphe et une porte ajoute une pénalité.
- Une recherche avance réellement sur des connexions proches sans téléportation.
- Entrées texte, pause, archives, plan et chargement n’activent pas la coordination ou la simulation en arrière-plan.

## Modifications de la base
Quatre nouveaux modules V106, deux points de délégation insérés dans le propriétaire runtime V105, et un raccord du moteur de production. Le fichier V105 original est conservé dans support-v106 ; ses octets connus sont exigés par l’installateur. Ce n’est pas une affirmation « aucune source historique modifiée ».

## Portée des preuves
Les tests de blocage complet d’un détenu emploient une branche de graphe explicitement scellée en fixture ; ils ne prouvent pas qu’une seule porte coupe toutes les routes alternatives de Fiorina. Les screenshots du jeu sont des PNG natifs Chromium, pas une illustration de télémétrie. Les tests d’audio vérifient activation, événements, gain et pause ; aucune écoute physique sur matériel n’est certifiée. Aucun nouveau relevé GitHub ni erreur de droits n’est revendiqué pour ce tour.

## Restant
Qualification du pilote dans la campagne native avec tous les anciens objectifs/effets ; captures avec les vrais sprites ; essais humains ; manette physique, Safari, son sur matériel, performances cibles et fidélité artistique finale. Pas de final complet du film annoncé.