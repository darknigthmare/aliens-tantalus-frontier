# QA — Alien 3 V105

## Périmètre
Correctif incrémental V104–V105 et banc autonome utilisant les modules livrés. La boucle de déplacement du banc reste simplifiée ; le jeu principal complet, ses sprites et tous les montages ne sont pas exécutés.

## Résultats
- 65 cas unitaires V105.
- 17 scénarios d’installation sur fixtures ; leurs scripts npm synthétiques ne constituent pas un build natif.
- 53 assertions Chromium sur six groupes (37 noms distincts).
- 7 contrôles du fichier distribué sans API QA.
- 37 tests unitaires V104 et 15 scénarios d’installation V104 rejoués séparément. Les 57 anciens scripts non présents dans cette récupération ne sont pas revendiqués.

## Parcours
| Profil | Résultat | Santé finale | Attaques / contacts / esquives | Secondes simulées |
|---|---|---:|---|---:|
| rapide | complete | 24 | 2 / 2 / 0 | 18.48 |
| prudent | complete | 62 | 1 / 1 / 0 | 19.28 |
| accessibilite | complete | 64 | 2 / 2 / 0 | 18.48 |
| explorateur-reprise | complete | 64 | 2 / 2 / 0 | 18.48 |
| rabattage-avec-esquive | complete | 100 | 1 / 0 / 1 | 24.12 |

Les chemins sont exécutés par vraies touches avec horloge contrôlée à 60 Hz. Aucun placement de personnage ni état de progression n’est injecté pendant ces parcours. La santé différente entre difficultés n’est pas une comparaison de testeurs humains. Le scénario de mort place volontairement deux acteurs proches : il est séparé et étiqueté dirigé.

## Défauts corrigés pendant l’exécution
- Certaines échelles de fonderie n’avaient pas de plateforme d’approche dans le banc ; les approches sont dérivées de leurs connexions existantes, comme dans les données.
- Le Runner poursuivait une ancienne cible en terminant son segment dans la mauvaise direction ; il peut maintenant inverser ce segment depuis sa position réelle, sans téléportation.
- Les touches de déplacement modifiées par Ctrl étaient absorbées par le garde des raccourcis du banc ; la marche accroupie les reçoit maintenant.
- L’interpréteur de fichiers refuse aussi null, tableaux et valeurs scalaires sans exception ; les participants nuls et destinations inconnues sont refusés avant remplacement.

## Audio
AudioContext effectivement activé par le bouton ; gain ramené à zéro pendant la pause ; événements émis depuis les positions. Le son n’a pas été écouté sur un matériel physique certifié. Aucun fichier sonore externe téléchargé.

## Native
Le connecteur GitHub a lu main, package.json et game-production-runtime.js. La base est V86 au commit 496996f5ea557d970ec625aa346876f3eaed1c5f. Aucune écriture n’a été tentée ; aucune nouvelle erreur 403 n’est revendiquée. Les droits déclarés par le dépôt ne sont pas utilisés comme preuve de déploiement.

## Limites
Le pilote V105 s’active explicitement pour les séquences originales. Il n’est pas silencieusement greffé sur tous les pièges, cinématiques et objectifs historiques. Les sprites natifs sont délégués sauf opt-in des silhouettes vectorielles. Ni rendu photoréaliste, ni fidélité 1:1, ni final intégral du film certifié. Les résultats ne valent pas validation Safari, manette physique, localStorage sur disque ni performance sur matériels cibles.

## Régression visuelle
Les captures sont des PNG du canvas Chromium. Les statistiques et hashes figurent dans qa-v105/browser.json. Les atlas transparents sont exportés depuis le même module de dessin mais ne sont pas chargés par le runtime.