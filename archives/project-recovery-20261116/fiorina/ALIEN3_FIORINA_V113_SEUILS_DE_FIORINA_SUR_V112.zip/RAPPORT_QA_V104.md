# QA V104 — Continuité du complexe

## Résultats exécutés
- 37 cas de contrats et mixins V104.
- 15 scénarios d’installation synthétiques.
- 41 contrôles Chromium et 13 captures natives.
- 6 contrôles du HTML distribué sans API de test, avec horloge normale.

Ces catégories ne s’additionnent pas en un score de campagne. Les scripts historiques de la V103 complète n’ont pas été récupérés dans cette session et ne sont pas déclarés rejoués.

## Ronde continue
Trois lampes rallumées dans l’ordre, deux portes ouvertes, échelle montée puis descendue, retour en salle commune au bon étage. Export réel après la deuxième lampe, import réel sur page neuve, continuation de la même ronde. Aucun déplacement ni état de progression n’a été injecté dans ce parcours. Durée robot : 18.10 secondes simulées ; ce n’est pas une durée de jeu annoncée.

## États préparés
Les captures du feu, de la suie, de la coulée, du refroidissement, de la Compagnie et du HUD au repos utilisent des états de test explicitement choisis. Elles ne sont pas des événements remportés au cours de la ronde. Cette ronde de maintenance ne possède pas de prédateur actif.

## Correction importante
La donnée existante du plomb est `alien3V88.moltenLeadApplied`, celle du choc thermique `thermalShockApplied`, et le feu dispose de `alien3V90.firePlan.ignited` / `accidentResolved`. Les booléens explicites priment. La couche ne se contente plus de passer toute la fonderie en état chaud à cause d’un nom de chapitre.

## Installation
La mise à jour gère trois nouveaux modules et un raccord de moteur sur une base V103 reconnue. Les sources héritées exactes, les chemins et les modifications concurrentes sont vérifiés. Une validation du projet qui modifie des sources gérées est refusée plutôt que d’installer des octets différents de ceux vérifiés. Les commandes npm des tests sont synthétiques : aucun build natif du jeu n’est certifié.

## Limites
Le contrôleur du banc est simplifié, les personnages provisoires et la campagne complète absente de la validation. Les sprites définitifs, l’IA native, l’empilement de tous les anciens interactifs, le chemin intégral de chaque montage, la manette matérielle et Safari/iPhone restent à éprouver. Aucun push ni déploiement. Le rendu n’est pas photoréaliste ni certifié 1:1 au film.

## Preuves
`qa-v104/unit.json`, `installation.json`, `browser.json`, `delivered-html.json`, `preview-sources.json`, `design-source.json`, `captures/`.
