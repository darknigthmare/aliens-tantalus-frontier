# Exports visuels V105

Cinq repères et les poses de Ripley, Aaron, Morse, Dillon et du Runner. Les PNG transparents proviennent exactement des fonctions Canvas livrées. Les ancrages et dimensions sont dans atlas.json. Le jeu dessine ces fonctions directement : il ne charge pas ces atlas. Ces silhouettes stylisées ne sont pas annoncées comme des assets finaux fidèles 1:1 au film.
