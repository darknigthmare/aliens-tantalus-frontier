#!/usr/bin/env python3
from pathlib import Path
import json
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape,A4
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.lib.styles import ParagraphStyle
R=Path(__file__).resolve().parents[1];Q=R/'qa-v113';browser=json.loads((Q/'browser-summary.json').read_text());refs=json.loads((Q/'design-source.json').read_text())['references'];unit=json.loads((Q/'unit.json').read_text());inst=json.loads((Q/'installation.json').read_text())
font=Path('/usr/share/fonts/truetype/dejavu')
for n,f in [('Body','DejaVuSans.ttf'),('Bold','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(n,str(font/f)))
W,H=landscape(A4);M=36;CW=W-M*2;BG=HexColor('#101914');INK=HexColor('#e0e4d4');MUTED=HexColor('#b0bda7');GOLD=HexColor('#bbaa7d');LINE=HexColor('#41533c')
styles={k:ParagraphStyle(k,fontName='Body',fontSize=s,leading=l,textColor=INK if k=='body' else MUTED)for k,s,l in [('body',11,16),('caption',9.5,13.5),('small',9,13)]}
selected=[
 ('010_soins_ferme','Un seuil, pas un battant isolé','Retours de cloison, montants, coffre et seuil sont calculés depuis la géométrie existante. Position préparée pour inspection. Le placement au milieu de la liaison historique n’est pas déclaré conforme à une mesure du film.'),
 ('020_soins_ouvert','La même porte ouverte','Même position et même instant. Le volet se replie ; les murs et les appuis restent fixes. Le contrôleur local a ensuite été bloqué par la porte fermée, puis a franchi le seuil après E.'),
 ('012_fonderie_ferme','Fermeture de la fonderie','La fermeture industrielle conserve le même propriétaire de collision. Les retours maçonnés sont en retrait ; ils ne créent ni route ni obstacle invisible. Comparaison dirigée, pas une séquence du film.'),
 ('50_morse_attend_dillon','Deux détenus, deux silhouettes','Dillon conserve sa carrure large et ses couches de vêtements ; Morse est plus étroit. Capture pendant le parcours de rabattage, après l’ordre G. Les corps, vitesses, postes et sauvegardes restent ceux de V112.'),
 ('01_aaron','Ripley et Aaron dans le parcours','Le nouveau dessin est utilisé pendant une traque au clavier, pas seulement dans une galerie d’assets. La tenue brune de Ripley remplace sa silhouette générique ; Aaron conserve un rôle et une morphologie distincts.'),
 ('030_ripley_arrivee','Tenue d’arrivée','Haut gris, vêtements courts et cheveux courts : variante d’inspection du crash, guidée par une description de costume de production. Le prologue du Sulaco n’est pas joué par cette capture.'),
 ('032_ripley_manteau','Manteau extérieur','Le manteau vert est sélectionné par un état extérieur explicite. Les références de production guident les couches, les teintes et les coutures ; le visage reste une interprétation vectorielle, non une ressemblance photographique.'),
 ('033_enregistreur','L’enregistreur à son appui','Un nouveau boîtier est posé sur le point d’analyse du vol. Il ne suit pas le joueur et n’ajoute pas une collecte automatique. Le diagnostic complet de l’EEV reste indiqué comme partiellement non lié dans le registre.'),
 ('034_bishop','Bishop, élément de scène','Le fragment endommagé est un objet de décor ancré, distinct du représentant de la Compagnie. Il ne crée ni nouvelle conversation ni personnage mobile. Inspection dirigée à son support existant.'),
 ('037_equipe_recuperation','L’équipement de la Compagnie','Deux agents stylisés portent une arme noire uniquement après le drapeau d’arrivée. Ils ne sont pas insérés dans la simulation comme de nouveaux ennemis. Aucun fusil n’est donné à Ripley et aucun tir n’est ajouté.'),
 ('53_coulee_apres_file','Le parcours reste terminable','Coulée obtenue après déplacement des détenus, attentes aux postes et attaque évitée par saut. Parcours au clavier sans injection de position ou d’étape. Ce test original ne reconstitue pas le dénouement complet du film.'),
 ('54_retour_apres_file_reprise','Terminé après reprise du fichier','File exportée, fichier importé sur une nouvelle page, groupe relancé et rabattage terminé jusqu’au retour à Morse. Le format reste V112 : aucune migration artificielle n’est introduite par la présentation V113.')]
N=len(selected)+3;pdf=canvas.Canvas(str(R/'RAPPORT_ILLUSTRE_V113.pdf'),pagesize=(W,H),pageCompression=1);pdf.setTitle('ALIEN 3 — Fiorina 161 — V113 Seuils de Fiorina');pdf.setAuthor('Aliens: Tantalus Frontier — dossier de développement');pageNo=0

def para(text,x,top,w,style='body',limit=None):
 p=Paragraph(text,styles[style]);_,h=p.wrap(w,1000)
 if limit and h>limit:raise ValueError(f'overflow {h}/{limit}: '+text[:100])
 p.drawOn(pdf,x,top-h);return h

def new(title,kicker='RAPPORT ILLUSTRÉ'):
 global pageNo
 pageNo+=1;pdf.setFillColor(BG);pdf.rect(0,0,W,H,fill=1,stroke=0);pdf.setFillColor(GOLD);pdf.setFont('Bold',9);pdf.drawString(M,H-25,'ALIEN 3  /  FIORINA 161');pdf.setFont('Body',8.5);pdf.drawRightString(W-M,H-25,'V113 · '+kicker);pdf.setFillColor(INK);pdf.setFont('Bold',24)
 if pdfmetrics.stringWidth(title,'Bold',24)>CW:raise ValueError(title)
 pdf.drawString(M,H-60,title);pdf.setStrokeColor(LINE);pdf.line(M,30,W-M,30);pdf.setFont('Body',8);pdf.setFillColor(MUTED);pdf.drawString(M,16,'Banc local · contrôleur simplifié · art vectoriel non définitif');pdf.drawRightString(W-M,16,f'{pageNo:02} / {N:02}')

new('Seuils de Fiorina','PÉRIMÈTRE DE LA PASSE')
y=H-88
y-=para('<b>Trois seuils architecturés. Quatre silhouettes reprises. Quatre objets ancrés.</b> Cette passe transforme l’audit de fidélité en corrections visuelles effectivement utilisées par les parcours du banc.',M,y,CW,limit=55)+20
y-=para('Les portes conservent leurs positions et leurs collisions historiques. Le nouveau dessin leur donne un logement, des appuis et des retours de mur. Les personnages conservent leurs objectifs et leurs mouvements ; l’arme de récupération reste à son porteur visuel.',M,y,CW,limit=65)+20
rows=[['Preuve','Résultat','Portée'],['Unitaires V113',str(unit['cases'])+' cas','Base instrumentée V112'],['Installation',str(inst['cases'])+' scénarios','Projets et npm synthétiques'],['Chromium',str(browser['assertions'])+' assertions','Quatre groupes, dont cinq parcours'],['Fichier ordinaire','20 contrôles','Clavier et horloge normale, sans API QA'],['Codex','85 contrôles','Recherche, références, filtres, mobile']]
t=Table([[Paragraph(escape(v),styles['small'])for v in row]for row in rows],colWidths=[158,148,CW-306]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#2b3c2a')),('BACKGROUND',(0,1),(-1,-1),HexColor('#16271b')),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LEFTPADDING',(0,0),(-1,-1),11),('LINEBELOW',(0,0),(-1,-1),.4,LINE)]));_,th=t.wrap(CW,500);t.drawOn(pdf,M,y-th);y-=th+18
para('<b>Aucun build natif ni campagne intégrale du film.</b> Les 28 captures HTML proviennent de Chromium et des modules livrés. Ce PDF en sélectionne douze. Les poses d’inspection sont signalées séparément des traversées au clavier.',M,y,CW,'small',65);pdf.showPage()
for idx,(name,title,caption)in enumerate(selected,1):
 new(title,f'CAPTURE NATIVE {idx:02} / {len(selected):02}');path=Q/'captures'/(name+'.png');h=CW*720/1280;top=H-80;pdf.drawImage(str(path),M,top-h,width=CW,height=h,preserveAspectRatio=True);pdf.setStrokeColor(LINE);pdf.rect(M,top-h,CW,h,stroke=1,fill=0);para(caption,M,top-h-10,CW,'caption',43);pdf.showPage()
new('Les manques restent visibles','COUVERTURE, PAS CERTIFICATION')
y=H-92
for title,text in [
 ('Lieux et montages','Le registre contient 25 entrées principales, dont 19 liées à des points du graphe. Six n’ont pas de géométrie dédiée liée : Sulaco, hôte bovin, présence canine/chenil, bureau d’Andrews, confinement de Golic et intérieur de récupération. Aucun pourcentage de fidélité 1:1 n’est affiché.'),
 ('Morgue et continuité','Le palier supérieur hérité n’a pas été déplacé arbitrairement. La descente observée dans la version étendue demande une comparaison et une refonte du raccord, non réalisées dans cette passe.'),
 ('Personnages et équipement','Dix-sept fiches de personnages et vingt-quatre équipements ne signifient pas autant de personnages ou objets intégrés. Les références, propriétaires, éléments dessinés et absences ont des statuts séparés. Les acteurs non créés restent déclarés manquants.'),
 ('Qualification restante','La campagne native, ses sprites définitifs, tous les anciens interactifs et les deux montages complets restent à examiner dans le moteur principal. Aucun push ou déploiement n’a été effectué pour cette version.')]:
  pdf.setFillColor(GOLD);pdf.setFont('Bold',13);pdf.drawString(M,y,title);y-=15;y-=para(text,M,y,CW,'body',85)+23
pdf.showPage()
new('Références et reproductibilité','SOURCES ET LIVRABLES')
y=H-94
for r in refs:
 title=escape(r['title']);url=r['url'].replace('&','&amp;');text=f'<link href="{url}" color="#d1c398">{title}</link><br/>{escape(r["fact"])}'
 y-=para(text,M,y,CW,'small',51)+13
para('Sources brèves de comparaison, sans image ni dialogue du film redistribués. Le code, le registre détaillé, les scripts de vérification et les captures natives sont inclus dans le correctif. Les pages du codex documentent les manques au lieu de les comptabiliser comme scènes jouées.',M,y-5,CW,'small',65)
pdf.showPage();assert pageNo==N;pdf.save();(Q/'pdf.json').write_text(json.dumps({'pages':N,'selectedCaptures':len(selected),'allNativeCaptures':len(browser['screenshots']),'file':'RAPPORT_ILLUSTRE_V113.pdf'},indent=2)+'\n');print(json.dumps({'pages':N,'selectedCaptures':len(selected),'bytes':(R/'RAPPORT_ILLUSTRE_V113.pdf').stat().st_size}))
