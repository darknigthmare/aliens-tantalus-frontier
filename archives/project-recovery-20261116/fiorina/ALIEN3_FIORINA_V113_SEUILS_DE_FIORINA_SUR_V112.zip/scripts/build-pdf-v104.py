#!/usr/bin/env python3
"""Programmatic illustrated report from native Chromium canvas captures."""
from pathlib import Path
from xml.sax.saxutils import escape
import json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape,A4
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=Path(__file__).resolve().parents[1];Q=R/'qa-v104';b=json.loads((Q/'browser.json').read_text());u=json.loads((Q/'unit.json').read_text());i=json.loads((Q/'installation.json').read_text());d=json.loads((Q/'delivered-html.json').read_text());c=json.loads((Q/'codex-browser.json').read_text());labels=json.loads((Q/'captions.json').read_text())
for name,file in [('Body','DejaVuSans.ttf'),('Strong','DejaVuSans-Bold.ttf')]:
 f=Path('/usr/share/fonts/truetype/dejavu')/file
 if not f.is_file():raise FileNotFoundError('DejaVu Sans needed locally for PDF: '+str(f))
 pdfmetrics.registerFont(TTFont(name,str(f)))
W,H=landscape(A4);M=34;CW=W-2*M;BG=HexColor('#101b14');INK=HexColor('#dce5d1');MUTED=HexColor('#afbba5');LINE=HexColor('#445b40');ACCENT=HexColor('#c8b17c')
styles={k:ParagraphStyle(k,fontName='Body',fontSize=f,leading=l,textColor=MUTED if k in ['small','caption'] else INK)for k,f,l in [('body',10.5,15.4),('caption',9.1,12.7),('small',8.8,12.4),('cell',9.4,13.3)]}
pdf=canvas.Canvas(str(R/'RAPPORT_ILLUSTRE_V104.pdf'),pagesize=(W,H),pageCompression=1);pdf.setTitle('Alien 3 — Fiorina 161 V104 — États du complexe');pdf.setAuthor('Aliens: Tantalus Frontier / dossier de développement');total=2+len(b['captures']);pn=0

def para(text,x,top,width,style='body',maxh=None):
 p=Paragraph(text,styles[style]);_,h=p.wrap(width,1000)
 if maxh and h>maxh:raise ValueError(f'Overflow {h}>{maxh}: {text[:55]}')
 p.drawOn(pdf,x,top-h);return h

def page(title,section):
 global pn;pn+=1
 pdf.setFillColor(BG);pdf.rect(0,0,W,H,fill=1,stroke=0);pdf.setFillColor(ACCENT);pdf.setFont('Strong',9);pdf.drawString(M,H-24,'ALIEN 3  /  FIORINA 161');pdf.setFont('Body',8);pdf.drawRightString(W-M,H-24,'V104  ·  '+section)
 pdf.setFillColor(INK);pdf.setFont('Strong',24)
 if pdfmetrics.stringWidth(title,'Strong',24)>CW:raise ValueError(title)
 pdf.drawString(M,H-57,title);pdf.setStrokeColor(LINE);pdf.setLineWidth(.5);pdf.line(M,29,W-M,29);pdf.setFillColor(MUTED);pdf.setFont('Body',7.5);pdf.drawString(M,16,'Banc local · contrôleur simplifié · personnages provisoires · pas de build complet certifié');pdf.drawRightString(W-M,16,f'{pn:02d} / {total}')

def image(file,top=H-76):
 h=CW*720/1280;pdf.drawImage(str(R/file),M,top-h,width=CW,height=h,preserveAspectRatio=True,mask='auto');pdf.setStrokeColor(LINE);pdf.rect(M,top-h,CW,h,stroke=1,fill=0);return top-h

page('États du complexe','MISE À NIVEAU ET CONTINUATION')
y=image('qa-v104/captures/08_incendie.png')
para('Le décor suit les événements ; le HUD laisse respirer le niveau. <b>Capture préparée</b> du feu dans le banc. Le correctif V104 s’applique sur V103 ; la ronde est un parcours original distinct de la campagne du film.',M,y-10,CW,'caption',40);pdf.showPage()
page('Standards repris, preuves séparées','PÉRIMÈTRE')
top=H-82
para('<b>Nostromo V108 :</b> parcours terminables au clavier et fichiers de reprise validés. '
     '<b>Résurrection V115 :</b> présence physique aux interactions et continuité. '
     '<b>Romulus 0.10 :</b> pause, plan découvert et options. '
     '<b>Aliens V105 :</b> contraintes de profondeur partagées. Les particularités de combat et de narration de ces DLC ne sont pas copiées dans Alien 3.',M,top,CW,'body',68)
top-=79
rows=[['Vérification','Résultat','Portée'],['Contrats V104',f'{u["cases"]} cas passés','Données et mixins sur base instrumentée'],['Installation',f'{i["cases"]} scénarios passés','Projets synthétiques, restauration et concurrence'],['Chromium',f'{b["tests"]} contrôles passés','Ronde, interfaces et événements préparés'],['HTML distribué',f'{d["tests"]} contrôles passés','Horloge normale, sans API de test'],['Codex',f'{c["tests"]} contrôles passés','331 fiches, recherche, liens et format mobile']]
t=Table([[Paragraph(escape(x),styles['cell'])for x in row]for row in rows],colWidths=[170,160,CW-330]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#2b3c25')),('BACKGROUND',(0,1),(-1,-1),HexColor('#192b1b')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),11),('RIGHTPADDING',(0,0),(-1,-1),11),('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9),('LINEBELOW',(0,0),(-1,-1),.5,LINE)]));_,th=t.wrap(CW,350);t.drawOn(pdf,M,top-th);top-=th+20
para('<b>Ronde continue :</b> trois éclairages, deux ouvertures, une montée et une descente d’échelle, export à mi-parcours, import sur une nouvelle page puis retour. Le robot a consommé 18,10 secondes simulées, pas une durée annoncée pour un joueur.<br/><br/><b>Reste ouvert :</b> moteur principal, sprites définitifs, IA complète et campagne entière. Aucun build natif, push ou déploiement. Les anciens scripts historiques non récupérés ne sont pas ajoutés aux résultats courants.',M,top,CW,'small',115);pdf.showPage()
for j,shot in enumerate(b['captures'],1):
 name=Path(shot['file']).stem;title,caption=labels[name];page(title,f'CAPTURE NATIVE {j:02d} / {len(b["captures"])}');y=image(shot['file']);para(caption,M,y-10,CW,'caption',40);pdf.showPage()
assert pn==total
pdf.save();print(json.dumps({'ok':True,'pages':pn,'bytes':(R/'RAPPORT_ILLUSTRE_V104.pdf').stat().st_size}))
