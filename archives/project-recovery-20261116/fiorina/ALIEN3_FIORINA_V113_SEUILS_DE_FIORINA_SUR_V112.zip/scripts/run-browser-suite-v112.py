from pathlib import Path
import subprocess,sys,json,time
from concurrent.futures import ThreadPoolExecutor,as_completed
R=Path(__file__).resolve().parents[1];Q=R/'qa-v112';jobs=[('spacing-route',['verify-spacing-v112.py','route']),('spacing-resume',['verify-spacing-v112.py','resume']),('trap',['verify-browser-v112.py','trap']),('profiles',['verify-browser-v112.py','profiles']),('resume',['verify-browser-v112.py','resume']),('failure',['verify-browser-v112.py','failure']),('audio',['verify-browser-v112.py','audio']),('layout',['verify-browser-v112.py','layout']),('traffic-route',['verify-traffic-v112.py','route']),('routing-detour',['verify-routes-v112.py','detour'])]
def run(job):
 name,args=job;start=time.time()
 with (Q/('run-'+name+'.log')).open('w')as log:
  try:p=subprocess.run([sys.executable,str(R/'scripts'/args[0]),*args[1:]],stdout=log,stderr=subprocess.STDOUT,cwd=R,timeout=360);ok=p.returncode==0;error=None
  except Exception as e:ok=False;error=str(e)
 result={'job':name,'ok':ok,'error':error,'seconds':round(time.time()-start,2)};(Q/('run-'+name+'-exit.json')).write_text(json.dumps(result));return result
results=[]
with ThreadPoolExecutor(max_workers=2)as pool:
 for future in as_completed([pool.submit(run,j)for j in jobs]):
  r=future.result();results.append(r);print(json.dumps(r),flush=True)
(Q/'browser-suite-exit.json').write_text(json.dumps({'ok':all(r['ok']for r in results),'results':results},indent=2))
