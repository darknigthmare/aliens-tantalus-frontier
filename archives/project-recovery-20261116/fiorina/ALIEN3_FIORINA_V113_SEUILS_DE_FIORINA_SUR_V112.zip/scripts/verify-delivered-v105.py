#!/usr/bin/env python3
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'qa-v105';checks=[]
def check(name,ok,detail=None):
 if not ok:raise AssertionError(name+':'+str(detail))
 checks.append({'name':name,'ok':True,'details':detail})
with sync_playwright()as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium')or'/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport={'width':1280,'height':960});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((ROOT/'FIORINA_V105_JOUER.html').read_text(),wait_until='load');page.wait_for_timeout(160);check('Le fichier ordinaire ne publie aucune API de test',not page.evaluate('"fiorinaBench"in window'))
 page.locator('#hunt').click();page.wait_for_timeout(100)
 with page.expect_download()as dl:page.locator('#export-save').click()
 first=OUT/'delivered-before.json';dl.value.save_as(str(first));a=json.loads(first.read_text());check('Le menu lance une vraie traque',a['encounter']['mode']=='traque'and a['encounter']['stage']==0)
 page.locator('canvas').focus();page.keyboard.down('ArrowRight');page.wait_for_timeout(980);page.keyboard.up('ArrowRight');page.keyboard.press('KeyE');page.wait_for_timeout(70)
 with page.expect_download()as dl:page.locator('#export-save').click()
 last=OUT/'delivered-after.json';dl.value.save_as(str(last));z=json.loads(last.read_text())
 check('L’horloge ordinaire progresse sans API QA',z['encounter']['clock']>a['encounter']['clock']);check('Le clavier déplace le personnage dans le fichier exporté',z['base']['pose']['x']>a['base']['pose']['x']);check('E valide la conversation d’Aaron à portée',z['encounter']['stage']==1,z['base']['pose']);check('Le prédateur patrouille aussi avec requestAnimationFrame',z['encounter']['pursuit']['stats']['distance']>0);check('Aucune erreur JavaScript dans le chemin distribué',not errors,errors)
 b.close()
(OUT/'delivered.json').write_text(json.dumps({'ok':True,'tests':len(checks),'scope':'Delivered HTML without inspection API, real animation time, real keyboard and downloaded save files','results':checks,'sourceHash':hashlib.sha256((ROOT/'FIORINA_V105_JOUER.html').read_bytes()).hexdigest()},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'tests':len(checks)}))
