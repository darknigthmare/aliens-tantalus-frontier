#!/usr/bin/env python3
"""Illustrated PDF from native Chromium captures; no independent picture rendering."""
from pathlib import Path
from xml.sax.saxutils import escape
import json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape,A4
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=Path(__file__).resolve().parents[1];Q=R/'qa-v106';b=json.loads((Q/'browser.json').read_text());u=json.loads((Q/'unit.json').read_text());i=json.loads((Q/'installation.json').read_text());doc=json.loads((Q/'documentation.json').read_text());cx=json.loads((Q/'codex-browser.json').read_text());dh=json.loads((Q/'delivered.json').read_text())
for name,file in [('Body','DejaVuSans.ttf'),('Strong','DejaVuSans-Bold.ttf')]:
 p=Path('/usr/share/fonts/truetype/dejavu')/file
 if not p.is_file():raise FileNotFoundError('DejaVu Sans required locally: '+str(p))
 pdfmetrics.registerFont(TTFont(name,str(p)))
W,H=landscape(A4);M=34;CW=W-2*M;BG=HexColor('#0e1a13');INK=HexColor('#e3e8d6');MUTED=HexColor('#b7c3ad');LINE=HexColor('#52634a');GOLD=HexColor('#cdb786')
styles={k:ParagraphStyle(k,fontName='Body',fontSize=f,leading=l,textColor=MUTED if k in ['small','caption']else INK)for k,f,l in [('body',11,16),('caption',9.2,13),('small',9,12.7),('cell',9.5,13.5)]}
pdf=canvas.Canvas(str(R/'RAPPORT_ILLUSTRE_V106.pdf'),pagesize=(W,H),pageCompression=1);pdf.setTitle('ALIEN 3 — Fiorina 161 V106 — Traces dans la pénombre');pdf.setAuthor('Aliens: Tantalus Frontier / dossier de développement');total=3+len(b['screenshots']);pn=0

def para(text,x,top,width,style='body',maxh=None):
 p=Paragraph(text,styles[style]);_,height=p.wrap(width,999)
 if maxh and height>maxh:raise ValueError(f'Overflow {height}>{maxh}: {text[:60]}')
 p.drawOn(pdf,x,top-height);return height

def page(title,section):
 global pn;pn+=1;pdf.setFillColor(BG);pdf.rect(0,0,W,H,fill=1,stroke=0);pdf.setFillColor(GOLD);pdf.setFont('Strong',9);pdf.drawString(M,H-24,'ALIEN 3  /  FIORINA 161');pdf.setFont('Body',8);pdf.drawRightString(W-M,H-24,'V106  ·  '+section);pdf.setFillColor(INK);pdf.setFont('Strong',24)
 if pdfmetrics.stringWidth(title,'Strong',24)>CW:raise ValueError(title)
 pdf.drawString(M,H-57,title);pdf.setStrokeColor(LINE);pdf.line(M,29,W-M,29);pdf.setFillColor(MUTED);pdf.setFont('Body',7.5);pdf.drawString(M,16,'Banc local · modules partagés · silhouettes vectorielles · pas de campagne native complète certifiée');pdf.drawRightString(W-M,16,f'{pn:02d} / {total}')

def image(file,top=H-76):
 h=CW*720/1280;pdf.drawImage(str(R/file),M,top-h,width=CW,height=h,preserveAspectRatio=True,mask='auto');pdf.setStrokeColor(LINE);pdf.rect(M,top-h,CW,h,stroke=1,fill=0);return top-h

def table(rows,top,widths):
 t=Table([[Paragraph(escape(str(x)),styles['cell'])for x in row]for row in rows],colWidths=widths);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#2d3b26')),('BACKGROUND',(0,1),(-1,-1),HexColor('#182b1c')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,-1),.5,LINE)]));_,h=t.wrap(CW,999);t.drawOn(pdf,M,top-h);return top-h
page('Traces dans la pénombre','VERSION LOCALE CANDIDATE')
y=image('qa-v106/captures/14_lampe_eteinte.png');para('La même lampe de service agit sur le dessin et le délai de reconnaissance. Cette image est une <b>capture native d’une position dirigée</b>, comparée à la lampe allumée sans déplacer les acteurs. La pénombre aide ; elle ne protège pas à courte portée.',M,y-10,CW,'caption',40);pdf.showPage()
page('Des choix qui ont des conséquences','CHANGEMENTS ET LIMITES')
y=table([['Sujet','Comportement livré','Limite ou refus'],['Lumière','Lecture locale, posture et reconnaissance progressive.','Une lampe de l’étage voisin ne contribue pas ; proche, Ripley reste visible.'],['Audition','Origine sonore réelle, trajet du graphe et portes atténuantes.','Pas de réception depuis un futur point ; pas d’acoustique physique 3D annoncée.'],['Recherche','Déplacement vers trois voisins maximum de la dernière trace.','Budget limité ; pas de nouvelle position cachée lue à distance.'],['Détenus','G : attente/reprise à portée, sans changer la destination.','Attendre hors du poste ne remplit pas une condition du piège.'],['Reprise','Poste sûr validé séparément dans le fichier, attente et lumières conservées.','La pose morte ne s’exporte pas comme une partie active ; import en pause.']],H-82,[95,337,CW-432])
para('La nouvelle couche utilise <b>quatre modules</b> et <b>deux points de délégation</b> dans le propriétaire V105, plus le raccord du moteur. Les six fichiers gérés sont préparés sur une copie temporaire. L’installateur refuse les sources différentes et les modifications concurrentes ; ses tests emploient des projets synthétiques.',M,y-20,CW,'small',65)
para(f'Le codex de conception compte <b>{doc["cards"]} fiches</b>, dont {doc["newCards"]} nouveaux contrats. Les 20 sections, 30 ensembles et 284 accessoires historiques sont conservés. Aucun ajout de pièce fictive, de carte ou de grade destiné à gonfler la livraison.',M,y-97,CW,'small',52);pdf.showPage()
page('Les parcours et leurs preuves','TESTS EXÉCUTÉS')
rows=[['Style automatisé','Résultat','Santé','Attaques / contacts / évitées','Temps simulé']]
for r in b['routes']:
 s=r['result'];st=s['pursuit']['stats'];rows.append([r['profile'],'Terminé',s['hp'],f'{st["attacks"]} / {st["hits"]} / {st["misses"]}',f'{s["clock"]:.2f} s'])
y=table(rows,H-81,[185,85,60,220,CW-550]);y-=20
para('Les parcours utilisent le clavier et une horloge contrôlée à 60 Hz, sans injection de position ou d’avancement. Le robot connaît le trajet : ces temps ne sont pas des durées de campagne, et les profils ne sont pas des testeurs humains. Les positions dirigées d’éclairage et d’échec sont séparées.',M,y,CW,'body',65);y-=76
para(f'<b>{u["cases"]} tests unitaires</b>, <b>{i["cases"]} scénarios d’installation</b>, <b>{b["controlsExecuted"]} assertions Chromium</b> en sept groupes ({b["uniqueControlNames"]} noms distincts), {dh["tests"]} contrôles du HTML distribué sans API QA et {cx["tests"]} contrôles du codex. V105 (65 + 17) et V104 (37 + 15) sont rejouées séparément. Ces scopes ne s’additionnent pas en certification native.',M,y,CW,'small',57);y-=70
para('<b>Non revendiqué :</b> build complet Tantalus, campagne intégrale du film, sprites définitifs, écoute sur matériel, validation humaine, manette physique ou déploiement. Les séquences de traque et de rabattage restent originales et facultatives.',M,y,CW,'small',42);pdf.showPage()
titles={'01_aaron.png':'La consigne d’Aaron','02_releve.png':'Le relevé à l’étage','03_retour_aaron.png':'Retour auprès d’Aaron','04_plan.png':'Le plan suspend la chasse','05_archives.png':'Les archives ne coûtent pas de temps','06_attente_morse.png':'La présence avant l’armement','07_postes_tenus.png':'Deux postes réellement tenus','08_attaque_annoncee.png':'Une attaque annoncée','09_coulee.png':'La créature dans le moule','10_refroidissement.png':'Retour au collecteur','11_retour_morse.png':'Le rabattage est terminé','12_echec.png':'Échec et reprise','13_lampe_allumee.png':'La lampe fonctionne','14_lampe_eteinte.png':'La même lampe est éteinte','15_dillon_attend.png':'Dillon attend physiquement','16_dillon_repart.png':'Dillon reprend son trajet'}
for index,shot in enumerate(b['screenshots'],1):
 page(titles[Path(shot['file']).name],f'CAPTURE NATIVE {index:02d} / {len(b["screenshots"])}');y=image(shot['file']);scope='Test dirigé, distinct des parcours continus.'if'directed'in shot['scope']else'Actions réelles au clavier dans le banc.';para(escape(shot['caption'])+' '+scope+' Modules de rendu livrés, hôte de déplacement simplifié.',M,y-10,CW,'caption',40);pdf.showPage()
assert pn==total;pdf.save();print(json.dumps({'ok':True,'pages':pn,'bytes':(R/'RAPPORT_ILLUSTRE_V106.pdf').stat().st_size}))
