from pathlib import Path
import re,json,hashlib,os,tempfile
ROOT=Path(__file__).resolve().parents[1]
sources={}
def gather(name):
 if name in sources:return
 p=ROOT/name
 if not p.resolve().is_relative_to(ROOT):raise ValueError(name)
 code=p.read_text();sources[name]=code
 for spec in re.findall(r'(?:from\s*|import\s*)[\'\"]([^\'\"]+)[\'\"]',code):
  if spec.startswith('.'):
   target=(p.parent/spec).resolve().relative_to(ROOT).as_posix();gather(target)
gather('atelier-v108/app.js')
loader="""const cache=new Map();function norm(path){let out=[];for(const x of path.split('/')){if(x==='..')out.pop();else if(x!=='.'&&x)out.push(x);}return out.join('/');}function moduleUrl(id){if(cache.has(id))return cache.get(id);const base=id.slice(0,id.lastIndexOf('/')+1);let src=sources[id];if(src===undefined)throw Error('Missing '+id);src=src.replace(/(from\\s*|import\\s*)['\"]([^'\"]+)['\"]/g,(all,p,rel)=>rel.startsWith('.')?p+JSON.stringify(moduleUrl(norm(base+rel))):all);const url=URL.createObjectURL(new Blob([src],{type:'text/javascript'}));cache.set(id,url);return url;}await import(moduleUrl('atelier-v108/app.js'));"""
code='<script type="module">const sources='+json.dumps(sources,ensure_ascii=False).replace('</script','<\\/script')+';'+loader+'</script>'
html=(ROOT/'atelier-v108/index.html').read_text().replace('<script type="module" src="app.js"></script>',code)
out=ROOT/'FIORINA_V108_JOUER.html';fd,tmp=tempfile.mkstemp(prefix='fiorina108-',suffix='.html',dir=ROOT);os.close(fd);Path(tmp).write_text(html);os.replace(tmp,out)
(ROOT/'qa-v108/preview-sources.json').write_text(json.dumps({'modules':len(sources),'files':{n:hashlib.sha256(s.encode()).hexdigest()for n,s in sources.items()},'source':'V103 sources recovered from the provided Library preview, plus V104–V108'},indent=2))
print('Standalone',len(html.encode()),'bytes',len(sources),'modules')
