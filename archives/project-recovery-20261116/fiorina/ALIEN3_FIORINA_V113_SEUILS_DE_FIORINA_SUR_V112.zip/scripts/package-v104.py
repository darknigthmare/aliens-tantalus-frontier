#!/usr/bin/env python3
"""Create an inspectable incremental package, no fonts or cached Python files."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,zipfile,sys,ast
R=Path(__file__).resolve().parents[1]
results=[]
for f in sorted(list(R.rglob('*.js'))+list(R.rglob('*.mjs'))):
 p=subprocess.run(['node','--check',str(f)],capture_output=True,text=True)
 if p.returncode:raise RuntimeError(str(f)+p.stderr)
 results.append({'file':f.relative_to(R).as_posix(),'ok':True})
for f in sorted(R.rglob('*.py')):
 ast.parse(f.read_text());results.append({'file':f.relative_to(R).as_posix(),'ok':True})
(R/'qa-v104/syntax.json').write_text(json.dumps({'ok':True,'scope':'Syntax only, not execution coverage','files':len(results),'results':results},indent=2))
files=[]
for f in sorted(R.rglob('*')):
 if not f.is_file() or '__pycache__' in f.parts or f.name=='manifest-v104.json' or f.suffix in ['.pyc','.ttf','.otf','.zip']:continue
 raw=f.read_bytes();files.append({'path':f.relative_to(R).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
manifest={'schema':104,'package':'Alien 3 — Fiorina 161 V104, incremental update on V103','scope':'Three new runtime modules, source references, standalone validation host and reports; not the whole game','files':files,'count':len(files)}
(R/'manifest-v104.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
out=R.parent/'ALIEN3_FIORINA_V104_MISE_A_NIVEAU_SUR_V103.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f in files:z.write(R/f['path'],f['path'])
 z.write(R/'manifest-v104.json','manifest-v104.json')
 withbad=z.testzip()
 if withbad:raise ValueError(withbad)
print(json.dumps({'ok':True,'file':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'manifestFiles':len(files),'syntaxFiles':len(results)},ensure_ascii=False))
