#!/usr/bin/env python3
from pathlib import Path
import json,shutil,hashlib
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];checks=[];source=R/'ALIEN3_CODEX_LEVEL_DESIGN_V104.html'
def check(name,ok):
 if not ok:raise AssertionError(name)
 checks.append({'name':name,'ok':True})
with sync_playwright()as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(source.read_text(),wait_until='load')
 check('331 source-backed cards are available',page.locator('article').count()==331)
 page.locator('#kind').select_option('Sections');check('20 descriptive sections',page.locator('article').count()==20)
 page.locator('#kind').select_option('États du décor');check('Five event bindings',page.locator('article').count()==5)
 page.locator('#kind').select_option('Ronde originale');check('Four original-round steps',page.locator('article').count()==4)
 page.locator('#kind').select_option('Tout');page.locator('#search').fill('moule');check('Search narrows the actual records',0<page.locator('article').count()<331)
 page.locator('#search').fill('refroidissement');check('Accented search data is indexed',page.locator('article').count()>0)
 page.locator('#search').fill('<img src=x onerror=alert(1)>');check('Injected markup is treated only as search text',page.locator('article').count()==0 and page.locator('img').count()==0)
 page.locator('#search').fill('medical-care');page.locator('details').first.locator('summary').click();link=page.locator('[data-jump="medical-care"]').first;link.click();check('A reference opens its actual linked assembly record',page.locator('#medical-care').count()==1 and page.locator('#kind').input_value()=='Tout')
 page.locator('#kind').select_option('États du décor');page.locator('#search').fill('');page.screenshot(path=str(R/'qa-v104/codex.png'),full_page=False)
 page.set_viewport_size({'width':390,'height':844});check('Mobile layout has no horizontal document overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
 check('No JavaScript error in the codex',not errors)
 b.close()
(R/'qa-v104/codex-browser.json').write_text(json.dumps({'ok':True,'tests':len(checks),'checks':checks,'sha256':hashlib.sha256(source.read_bytes()).hexdigest()},ensure_ascii=False,indent=2));print(json.dumps({'ok':True,'tests':len(checks)}))
