#!/usr/bin/env python3
"""Package an incremental on-V112 patch with all exact source dependencies.
Historical screenshots and illustrated reports are omitted; fonts/caches never ship.
"""
from pathlib import Path
import re,json,hashlib,zipfile
R=Path(__file__).resolve().parents[1];out=R.parent/'ALIEN3_FIORINA_V113_SEUILS_DE_FIORINA_SUR_V112.zip';items=[];omitted=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R).as_posix()
 if re.fullmatch(r'manifest-v\d+\.json',p.name) or '__pycache__' in p.parts or p.suffix.lower()in['.pyc','.ttf','.otf','.woff','.woff2','.log'] or p.name.endswith('-exit.txt')or p.name.startswith(('log-','smoke')):continue
 if rel.startswith('qa-v113/')and (p.name.endswith('-state.json')or p.name in['browser-hunt.json']or p.name.startswith(('finalrun-','run-'))):continue
 oldReport=bool(re.match(r'RAPPORT_ILLUSTRE_V(?:10[4-9]|11[0-2])\.(pdf|html)$',rel))
 oldImage=bool(re.match(r'qa-v(?:10[4-9]|11[0-2])/',rel))and p.suffix.lower()in['.png','.jpg','.jpeg','.webp','.pdf']
 if oldReport or oldImage:omitted.append(rel);continue
 data=p.read_bytes();items.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema':113,'scope':'Incremental on 59 exact V112 sources: 3 added modules, 2 optional draw hooks in owner V105, engine link. Native build not executed. Save schema 112 preserved.','count':len(items),'omittedHistoricalGeneratedArtifacts':omitted,'files':items}
(R/'manifest-v113.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f in items:z.write(R/f['path'],f['path'])
 z.write(R/'manifest-v113.json','manifest-v113.json')
with zipfile.ZipFile(out)as z:
 assert z.testzip()is None
print(json.dumps({'ok':True,'archive':out.name,'manifestFiles':len(items),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
