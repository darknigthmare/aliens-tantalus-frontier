#!/usr/bin/env python3
"""Data-backed codex and self-contained illustrated report. Native screenshots only."""
from pathlib import Path
from html import escape as esc
import json,re,subprocess,collections,base64,hashlib
R=Path(__file__).resolve().parents[1];Q=R/'qa-v107';D=R/'docs';D.mkdir(exist_ok=True)
subprocess.run(['node',str(R/'scripts/export-design-v107.mjs')],check=True)
src=json.loads((Q/'design-source.json').read_text());u=json.loads((Q/'unit.json').read_text());inst=json.loads((Q/'install.json').read_text());browser=json.loads((Q/'browser.json').read_text());delivered=json.loads((Q/'delivered.json').read_text())
old=(R/'ALIEN3_CODEX_LEVEL_DESIGN_V106.html').read_text();start=old.index('const cards=')+len('const cards=');cards,end=json.JSONDecoder().raw_decode(old[start:]);assert len(cards)==437
for c in cards:
 if c['id']in['station-report','station-water','station-mold']:
  c['text']+=' V107 : certaines étapes exigent une action maintenue, à appui stable. Les gestes et interruptions sont détaillés dans les fiches Manœuvres V107 ; l’ancienne validation instantanée de ces étapes n’est plus active dans le pilote V107.'
 if c['id']=='station-pour':c['text']+=' V107 conserve volontairement la commande de coulée immédiate, au passage réel du Runner. Elle n’immobilise pas la créature avant sa validation et ne lui ajoute aucun déplacement forcé.'
 if c['id']=='encounter-traque':c['details'].append(['Relevé','operation107-report','E maintenu 1,10 s, ou mode Appuyer, au poste réel.'])
 if c['id']=='encounter-rabattage':c['details'].extend([['Amorçage','operation107-prime','Durée 1,80 s, annulation par mouvement/blessure/panneau.'],['Verrouillage','operation107-arm','Durée 1,25 s ; Morse et Dillon restent requis.'],['Refroidissement','operation107-cool','Durée 2,00 s après la coulée.']])
new=[]
def add(kind,id,title,text,details):new.append({'type':kind,'id':id,'title':title,'text':text,'details':details})
for d in src['operations']:
 position=d['position'];seconds=str(d['seconds']).replace('.',',')
 add('Manœuvres V107','operation107-'+d['id'],d['label'],f'Action de {seconds} s dans la séquence « {src["encounters"][d["mode"]]["title"]} ». L’opération ne donne pas son résultat au début : le propriétaire de progression V105 valide seulement après la durée et la dernière vérification. Le joueur peut s’éloigner sans être bloqué ; il perd alors l’avancement partiel.',[
 ['Séquence','encounter-'+d['mode'],f'Étape {d["stage"]} → {d["stageAfter"]}, pas une scène supplémentaire du film.'],['Station','station-'+d['station'],f'Point {d["nodeId"]} ; centre X {position["x"]+position["w"]/2}, pied Y {position["y"]+position["h"]}.'],['Appui',d['nodeId'],'Sol stable ; pas de saut ni de montée pendant le geste.'],['Accès','A3-107-depth','Portée 85 unités, hauteur 16 unités et profondeur 0,30. La position interpolée compte.'],['Interruption','A3-107-motion','Mouvement, relâchement, blessure, porte ou panneau ; pas d’objectif accordé.'],['Dessin','A3-107-draw-pure',f'Repère sur la pièce réelle : X {d["drawing"]["x"]:.2f}, Y {d["drawing"]["y"]:.2f}. Aucune attache à la tête de Ripley.'],['Bruit','A3-107-machinery',f'Puissance abstraite {d["power"]}, émission à la station ; cadence minimale 0,55 s même après annulation/reprise.'],['Commande accessible','access107-input','Appuyer conserve la durée, les mêmes vérifications et une annulation explicite.']])
for r in src['rules']:add('Règles V107',r['id'],r['text'].split(' ; ')[0],r['text'],[['Validation','qa-v107/unit.json',r['validation']],['Périmètre','Séquences originales','Le contrôleur simplifié du banc n’est pas le jeu principal complet.']])
add('Postes de commande','operator107-water','Petit poste du collecteur','Le point de commande historique du collecteur ne possédait pas de petit pupitre propre. V107 place quatre composants sur sa plateforme réelle : boîtier, tige, volant et cadran. Le cadran suit l’avancement de l’amorçage, puis l’état acquis. Ce petit ensemble décoratif n’ajoute aucune collision, nouvelle route ou collecte.',[['Appui','f161-water-header','La plateforme existante conserve son étendue et sa hauteur.'],*[[p['kind'],p['id'],f'X {p["x"]} ; Y {p["y"]} ; {p["w"]} × {p["h"]} ; pose {p["mount"]}, collision {p["collision"]}.']for p in src['fittings']]])
for p in src['fittings']:add('Composants V107',p['id'],{'housing':'Boîtier du collecteur','pipe':'Tige et conduite','wheel':'Volant de service','gauge':'Cadran de pression'}[p['kind']],'Composant du petit poste de commande ; position fixée à un appui du niveau, jamais à la caméra ou au personnage.',[['Ensemble','operator107-water','Raccord visuel, pas nouvelle machine de physique.'],['Appui',p['nodeId'],f'X {p["x"]} ; Y {p["y"]} ; largeur {p["w"]} ; hauteur {p["h"]}.'],['Pose',p['mount'],'Collision : aucune.']])
add('Commandes accessibles','access107-input','Maintenir ou appuyer','Le mode Maintenir demande de garder E. Le mode Appuyer démarre par une pression et s’annule par une autre. Les deux durent le même temps et restent interrompus par mouvement, blessure, porte, pause, plan ou archives. Le bouton tactile Agir reçoit un vrai maintien et libère l’état à l’annulation du pointeur.',[['Réglage','Options','Choix explicite dans le menu ; sauvegardé par fichier.'],['Sauvegarde','save107-current','Le choix est conservé sans reprendre une commande partielle.'],['Limite','Matériel','Le pointeur a été testé dans Chromium ; aucune manette physique n’a été qualifiée.']])
for id,title,text,details in [
 ('current','Fichier V107','L’enveloppe contient la session V106 vérifiée, le registre des manœuvres et un dernier poste sûr séparé. Aucune opération active n’est sérialisée. Les tâches consignées doivent correspondre à la progression existante, même si l’empreinte extérieure a été recalculée.',[['Limite','1 Mio','La taille est vérifiée avant analyse.'],['Contrat','A3-107-no-partial-import','Une reprise ne valide pas spontanément une commande.'],['Authenticité','Empreinte FNV','Détection de corruption, pas protection anti-triche.']]),
 ('checkpoint','Reprendre sans rejouer le geste','Le poste sûr doit rester vivant et actif, dans la même séquence, à un stade non futur. Une fin de manœuvre prépare son registre stable avant le callback de checkpoint ; une manœuvre partielle ne peut pas remplacer le poste sûr.',[['En cas d’échec','R','Repartir d’un poste antérieur, pas de la pose morte.'],['Options','access107-input','Le réglage Maintenir/Appuyer est conservé dans le poste.'],['Atomicité','save107-current','Le fichier entier est vérifié avant remplacement de la session.']]),
 ('migration','Reprendre les fichiers V105 et V106','Les fichiers antérieurs valides gardent leur progression. Les tâches déjà acquises sont dérivées des étapes et ne doivent pas être rejouées. Le poste sûr V106 est migré distinctement de l’état courant, même si sa progression est antérieure.',[['Héritage','save106-navigation','Position, navigation, portes et présence des participants restent contrôlées.'],['Reprise','Pause','L’import ne reprend ni touche maintenue ni bruit en transit.'],['Pas de cloud','Fichier explicite','Aucune sauvegarde automatique sur disque ni compte externe.']])]:
 add('Reprises V107','save107-'+id,title,text,details)
add('Bruits de préparation','sound107-work','La préparation s’entend','Les quatre manœuvres émettent depuis leur station. Les pas des détenus dépendent de leur distance réellement parcourue ; un détenu arrêté ne marche pas sur place. Un ordre audible provient du détenu qui répond à Ripley. Ces événements entrent dans le même calcul de portée V106 que les bruits du joueur.',[['Cadence des machines','0,55 s','Un nouveau geste n’efface pas la limite anti-rafale.'],['Pas des détenus','62 unités','Puissance 0,23 ; silence lorsque le corps ne se déplace pas.'],['Consigne','0,46','Puissance abstraite ; portée calculée sur les passages et portes.'],['Limite narrative','encounter-rabattage','Pendant les premiers préparatifs, le Runner est volontairement dormant ; l’ambiance sonore ne change pas cette condition de la séquence.']])
cards+=new;ids=[c['id']for c in cards];assert len(ids)==len(set(ids))
(Q/'codex-source.json').write_text(json.dumps({'schema':107,'cards':cards},ensure_ascii=False,indent=2)+'\n')
intro=['# Alien 3 — Codex de level design V107','## Manœuvres sous tension','',f'{len(cards)} fiches de conception, dont {len(new)} nouveaux contrats. Ce document est extérieur au jeu. Les 90 archives du joueur restent distinctes.','',
'## Périmètre','Couche incrémentale sur les sources V106 connues. Le banc emploie les fonctions livrées et un contrôleur de base simplifié ; aucun build natif complet, sprite définitif ou parcours du film entier n’est annoncé. Les deux séquences sont originales et facultatives.',
'Les 20 sections descriptives et les 30 assemblages historiques (284 composants) sont conservés. Un petit poste de commande ajoute quatre composants visibles à la plateforme du collecteur. Les indicateurs de geste utilisent le volant du moule ou le plateau déjà dessinés au lieu de suivre le personnage.',
'Les manœuvres temporisées sont reprises par le propriétaire d’objectif V105. La lecture exige 1,10 s, l’amorçage 1,80 s, le verrouillage 1,25 s et l’eau finale 2,00 s. La coulée reste instantanée, à condition que le Runner se trouve réellement dans le moule et que les postes soient tenus.',
'Les scènes dirigées pour la blessure et l’échec sont séparées des parcours au clavier. La durée simulée d’un robot qui connaît le chemin n’est pas annoncée comme durée de jeu. La cadence de dessin est découplée de l’avance temporelle QA ; les captures sont des screenshots Chromium natifs du rendu livré.', '']
for c in cards:intro.extend([f'### {c["title"]}',f'`{c["id"]}` · {c["type"]}',c['text'],'','| Élément | Référence | Contrat |','|---|---|---|',*['| '+' | '.join(str(v).replace('|',' / ').replace('\n',' ')for v in row)+' |'for row in c['details']],''])
(D/'ALIEN3_LEVEL_DESIGN_CODEX_V107.md').write_text('\n'.join(intro))
updated=old[:start]+json.dumps(cards,ensure_ascii=False)+old[start+end:]
updated=updated.replace('DOCUMENT DE CONCEPTION V106','DOCUMENT DE CONCEPTION V107').replace('Codex V106','Codex V107').replace('<h1>Traces dans la pénombre</h1>','<h1>Manœuvres sous tension</h1>').replace('437 fiches issues des données livrées',f'{len(cards)} fiches issues des données livrées')
updated=re.sub(r'(<div class="scope">).*?(</div>)',lambda x:x.group(1)+'Codex hors jeu. V107 ajoute les gestes maintenus, leurs interruptions, une commande accessible et un petit poste de collecteur, tout en conservant les étapes et les espaces existants. Les captures et parcours proviennent d’un banc local à contrôleur simplifié ; ils ne qualifient pas la campagne native complète.'+x.group(2),updated,count=1,flags=re.S)
options=''.join('<option>'+esc(k)+'</option>'for k in ['Tout',*dict.fromkeys(c['type']for c in cards)])
updated=re.sub(r'(<select id="kind"[^>]*>).*?(</select>)',lambda x:x.group(1)+options+x.group(2),updated,flags=re.S)
(R/'ALIEN3_CODEX_LEVEL_DESIGN_V107.html').write_text(updated)
(Q/'documentation.json').write_text(json.dumps({'schema':107,'cards':len(cards),'newCards':len(new),'byCategory':dict(collections.Counter(c['type']for c in cards)),'baseComponents':284,'newFittingComponents':4,'markdownLines':len(intro)},ensure_ascii=False,indent=2)+'\n')
css=re.search(r'<style>(.*?)</style>',old,re.S).group(1);panels=[]
for shot in browser['screenshots']:
 raw=(R/shot['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==shot['sha256']
 scope='Test dirigé explicitement préparé.'if'directed'in shot['scope']else'Parcours et interactions au clavier/pointeur dans le banc local.'
 panels.append(f'<section class="panel"><h2>{esc(shot["caption"])}</h2><img alt="Capture native du banc jouable" src="data:image/png;base64,{base64.b64encode(raw).decode()}"><p class="caption">{scope} Modules livrés, personnages provisoires, physique de base simplifiée. Aucune réillustration depuis des états JSON.</p></section>')
report=f'''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Alien 3 — Rapport V107</title><style>{css}</style><header><small>FIORINA 161 / RAPPORT V107</small><h1>Manœuvres sous tension</h1><p>Garder la main sur la commande, choisir le bon moment et tenir les postes.</p></header><main><div class="scope">Correctif sur V106 et aperçu autonome. Les séquences sont originales et facultatives ; aucun build natif complet, push ou déploiement n’est revendiqué.</div><section class="panel"><h2>Modifications vérifiées</h2><p>Quatre gestes temporisés avec annulation par mouvement, relâchement, blessure et panneaux ; commande accessible Appuyer avec les mêmes durées ; poste de collecteur ancré à son appui ; cadence sonore bornée et sauvegarde sans geste actif.</p><p>La coulée reste immédiate lorsque la créature est réellement dans le moule. Les occupants des postes, les huit lampes, les portes et les parcours restent ceux de la base. Aucun grade supplémentaire n’est ajouté.</p></section><section class="panel"><h2>Tests exécutés</h2><p>{u['cases']} cas unitaires ; {inst['cases']} scénarios d’installation sur fixtures ; {browser['controlsExecuted']} assertions Chromium ({browser['uniqueControlNames']} libellés distincts) ; {delivered['tests']} contrôles du HTML distribué sans API de test. Les reprises par fichier et les cas dirigés sont distingués des traversées continues.</p></section>{''.join(panels)}</main></html>'''
(R/'RAPPORT_ILLUSTRE_V107.html').write_text(report)
qa=['# QA — Alien 3 V107','','## Périmètre','Couche incrémentale sur V106. Banc à contrôleur simplifié utilisant les modules livrés. Aucune campagne native complète ni fidélité artistique 1:1 certifiée.','','## Résultats',f'- {u["cases"]} cas unitaires V107.',f'- {inst["cases"]} scénarios d’installation avec npm synthétique.',f'- {browser["controlsExecuted"]} assertions Chromium sur sept groupes, {browser["uniqueControlNames"]} noms distincts.',f'- {delivered["tests"]} contrôles du fichier ordinaire sans API QA.','','## Régression historique', '- V106 : 47 cas unitaires et 18 installations rejoués. V105 : 65 et 17. V104 : 37 et 15. Ces suites restent séparées du nouveau pilote et de la qualification native.', '', '## Parcours','| Profil | Statut | Santé | Attaques / contacts / esquives | Temps simulé |','|---|---|---:|---|---:|']
for r in browser['routes']:
 s=r['result'];st=s['pursuit']['stats'];qa.append(f'| {r["profile"]} | {s["status"]} | {s["hp"]} | {st["attacks"]} / {st["hits"]} / {st["misses"]} | {s["clock"]:.2f} s |')
qa+=['','Les traversées emploient le clavier et une horloge contrôlée, sans injection de position ou d’étape. Les frames de simulation peuvent avancer sans redessiner chacune ; les captures sont natives. Les robots connaissent le chemin ; leurs temps ne sont pas une durée de campagne.','', '## Corrections pendant la validation', '- Les durées nouvelles changent l’ordre d’arrivée aux postes : le premier refus observé au moule concerne Dillon encore en trajet, pas Morse. Le contrôle a été adapté au contrat réel, sans déplacer un participant.', '- Le contrôle du HTML ordinaire attend la position lue dans un fichier réellement exporté, plutôt qu’un nombre fixe de millisecondes dépendant de la charge du navigateur.', '- Un premier affichage de progression recouvrait le dialogue. Le dessin actif utilise maintenant une vue en lecture seule, sans double panneau.', '- Le repère d’action n’est plus centré sur la tête de Ripley ; il est sur le plateau ou le volant concerné.', '- Un poste de vanne est ajouté à l’appui historique du collecteur qui n’avait pas de petit pupitre propre.', '- Un délai sonore global persiste entre annulation et reprise pour empêcher les rafales de machine.', '- Le dernier poste sûr V106 est migré séparément du stade courant.', '- Les liens symboliques pendants sont refusés par l’installateur avant toute écriture.', '', '## Portée des tests', 'Les positions des tests unitaires sont des fixtures dirigées. Les contrôles de poignées et d’états physiques ne valent pas qualification de tout le moteur principal. Les pas et ordres des détenus sont audibles, mais le Runner reste volontairement dormant pendant la préparation antérieure à l’armement du piège.', 'Les tests d’audio vérifient l’activation, les événements et la pause ; aucune écoute sur matériel physique n’est certifiée. Pas de nouvelle lecture GitHub ni nouvelle erreur de droits revendiquée. Pas de sauvegarde automatique sur disque, cloud, manette physique ou validation Safari.', '', '## Installation', 'Quatre nouveaux modules, un raccord de moteur : aucune source V106 historique modifiée. Les 34 sources attendues sont vérifiées. Le travail est préparé dans une copie temporaire, puis les octets effectivement validés sont reportés vers la cible après contrôle des modifications concurrentes. Les fixtures emploient des commandes npm synthétiques ; aucun build complet du dépôt n’a été exécuté.', '', '## Restant', 'Qualification dans la campagne native complète ; montage des anciens objectifs/effets avec le pilote ; sprites définitifs ; sessions humaines ; art final ; performances et son sur les appareils cibles.']
(R/'RAPPORT_QA_V107.md').write_text('\n'.join(qa))
(D/'PORTEE_V107.md').write_text('''# Portée de la V107

| Sujet | Livré / vérifié | Non revendiqué |
|---|---|---|
| Manœuvres | Quatre gestes temporisés ; durée, présence et interruptions | Tous les objets interactifs de la campagne native |
| Accessibilité | Mode Appuyer conservant durée et contraintes ; bouton pointeur | Manette physique, session humaine, Safari |
| Rendu | Repères aux appuis réels et petit poste de vanne ; captures natives | Art définitif photoréaliste ou fidèle 1:1 |
| Sons | Machines à cadence bornée, pas réels des détenus, consignes locales | Chasse active pendant la préparation où le Runner reste dormant |
| Sauvegardes | Fichiers validés avant remplacement, poste sûr, migration V105/V106 | Autopersistence, cloud, anti-triche |
| Installation | Sources V106 exactes, copie de contrôle et rollback | Build complet Tantalus, push ou déploiement |
''')
(R/'README.md').write_text(f'''# Alien 3 — Fiorina 161 V107 · Manœuvres sous tension

Correctif incrémental **sur une V106 connue**, avec aperçu autonome. Ce n’est pas le jeu principal complet.

## Jouer
Ouvrir `FIORINA_V107_JOUER.html`. Aucun service externe ou asset distant n’est téléchargé. Les deux parcours originaux restent accessibles, ainsi que la ronde et l’inspection de la base.
Flèches / Q-D / A-D : marcher ; Haut/Bas : échelle ou profondeur ; Espace : sauter ; Maj : courir ; Ctrl : se baisser ; E : agir, ou maintenir aux stations ; F : bruit ; G : attendre/repartir ; I : éclairage ; M : plan ; C : archives ; Échap : pause ; R : poste sûr.
Dans les options, choisir **Appuyer pour manœuvrer** pour ne pas tenir la touche. La durée reste identique ; une seconde pression ou un déplacement annule. Les sons sont optionnels et désactivés par défaut.

Les 4 gestes sont : lire le relevé 1,10 s ; amorcer le collecteur 1,80 s ; verrouiller le moule 1,25 s ; ouvrir l’eau 2,00 s. Le levier de coulée reste immédiat et exige le Runner dans le moule. Le registre de sauvegarde ne conserve pas de geste partiel actif.

## Installer sur une copie V106
Node.js 20+. Extraire le correctif hors du dossier cible.
```sh
node scripts/install-v107.mjs /chemin/vers/projet-V106 --dry-run
node scripts/install-v107.mjs /chemin/vers/projet-V106
```
Les 34 sources V106 de `sources-v106-verified.json` doivent être identiques. L’installation ajoute 4 modules et raccorde le moteur ; elle ne modifie aucun propriétaire V106. Elle valide une copie temporaire par `npm run check` et `npm run build` avant report atomique. Les modifications concurrentes ou locales sont refusées. Les tests fournis utilisent des projets synthétiques, pas le build complet de Tantalus. `--skip-project-check` déclare explicitement que ces commandes sont sautées.
```sh
node scripts/install-v107.mjs --restore /chemin/vers/receipt.json
```
La restauration externe refuse d’écraser des modifications faites après installation.

## Sauvegarde
Exporter et importer un JSON explicite, limité à 1 Mio. Les fichiers V105/V106 valides sont repris avec leurs objectifs acquis et leur poste sûr. L’import reprend en pause. Les fichiers qui prétendent terminer une action avant l’étape correspondante sont refusés même avec empreinte recalculée. L’empreinte ne constitue pas une signature anti-triche.

## Documents
- `ALIEN3_CODEX_LEVEL_DESIGN_V107.html` : {len(cards)} fiches, {len(new)} nouveaux contrats.
- `docs/ALIEN3_LEVEL_DESIGN_CODEX_V107.md` : données détaillées et dépendances.
- `RAPPORT_ILLUSTRE_V107.html` / `.pdf` : captures natives, scopes séparés.
- `qa-v107/` : résultats, sauvegardes téléchargées, captures et empreintes.
Les rapports historiques inclus restent des preuves historiques, pas des exécutions de V107.

## Reproduire
```sh
node scripts/test-v107.mjs
node scripts/test-install-v107.mjs
python scripts/build-preview-v107.py
python scripts/verify-browser-v107.py profiles
python scripts/verify-browser-v107.py resume
python scripts/verify-browser-v107.py trap
python scripts/verify-browser-v107.py failure
python scripts/verify-browser-v107.py audio
python scripts/verify-browser-v107.py layout
python scripts/verify-work-v107.py
python scripts/aggregate-qa-v107.py
python scripts/verify-delivered-v107.py
python scripts/build-docs-v107.py
python scripts/verify-codex-v107.py
python scripts/build-pdf-v107.py
```
Playwright, Chromium et ReportLab sont requis pour les outils de contrôle. Les polices restent installées sur la machine ; aucun fichier de police n’est distribué.
Le banc utilise un contrôleur simplifié et des personnages provisoires. Aucun build complet Tantalus, parcours intégral du film, push, déploiement, session humaine ou qualification sonore matérielle n’est annoncé.
''')
print(json.dumps({'cards':len(cards),'newCards':len(new),'captures':len(browser['screenshots'])}))
