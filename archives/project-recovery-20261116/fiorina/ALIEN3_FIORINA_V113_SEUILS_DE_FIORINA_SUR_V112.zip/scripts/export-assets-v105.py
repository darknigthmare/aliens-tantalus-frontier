#!/usr/bin/env python3
"""Transparent reusable exports of the exact in-game V105 vector drawing functions.
These are not photographic assets or a claim of film-accurate final artwork.
"""
from pathlib import Path
import re,json,base64,hashlib,shutil
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'assets-v105';OUT.mkdir(exist_ok=True)
sources={}
def gather(name):
 if name in sources:return
 p=ROOT/name;sources[name]=p.read_text()
 for rel in re.findall(r'(?:from\s*|import\s*)[\'\"]([^\'\"]+)[\'\"]',sources[name]):
  if rel.startswith('.'):gather((p.parent/rel).resolve().relative_to(ROOT).as_posix())
gather('src/alien3-art-v105.js')
loader='''const sources=__SOURCES__;const cache=new Map();function norm(p){const a=[];for(const t of p.split('/')){if(t==='..')a.pop();else if(t!=='.'&&t)a.push(t);}return a.join('/');}function url(id){if(cache.has(id))return cache.get(id);const base=id.slice(0,id.lastIndexOf('/')+1);const src=sources[id].replace(/(from\\s*|import\\s*)['"]([^'"]+)['"]/g,(all,p,r)=>r.startsWith('.')?p+JSON.stringify(url(norm(base+r))):all);const out=URL.createObjectURL(new Blob([src],{type:'text/javascript'}));cache.set(id,out);return out;}window.art=await import(url('src/alien3-art-v105.js'));'''.replace('__SOURCES__',json.dumps(sources,ensure_ascii=False).replace('</script','<\\/script'))
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path=shutil.which('chromium')or'/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);p=b.new_page();errors=[];p.on('pageerror',lambda e:errors.append(str(e)));p.set_content('<script type="module">'+loader+'</script>');p.wait_for_function('!!window.art')
 items=[]
 for kind in ['eev','cell','pump','mold','furnace']:
  data=p.evaluate('''kind=>{const c=document.createElement('canvas');c.width=256;c.height=224;const x=c.getContext('2d');art.drawLandmarkV105(x,{kind,x:16,y:16,w:224,h:192},{flags:{leadHot:kind==='mold'},time:0});return c.toDataURL('image/png').split(',')[1];}''',kind)
  file=OUT/(kind+'.png');file.write_bytes(base64.b64decode(data));items.append({'id':kind,'file':file.name,'type':'landmark','frames':1,'size':[256,224],'localAnchor':[16,208],'scope':'Shared renderer snapshot; no new collider'})
 for role in ['ripley','aaron','morse','dillon','runner']:
  count=16 if role=='runner'else 8;fw=320 if role=='runner'else 96;fh=128 if role=='runner'else 120
  data=p.evaluate('''({role,count,fw,fh})=>{const c=document.createElement('canvas');c.width=fw*count;c.height=fh;const x=c.getContext('2d');for(let i=0;i<count;i++){x.save();x.translate(i*fw,0);const a={id:role,alive:true,x:fw/2-(role==='runner'?54.5:18),y:fh-12-(role==='runner'?70:90),w:role==='runner'?109:36,h:role==='runner'?70:90,depth:1,facing:1,moving:true,vx:50};if(role==='runner')art.drawRunnerV105(x,a,i*Math.PI/48,{mode:i<8?'chase':i<12?'windup':'recover',timer:i<12?.85-(i-8)*.2:.6});else art.drawPersonV105(x,a,i*2*Math.PI/(8*9.5));x.restore();}return c.toDataURL('image/png').split(',')[1];}''',{'role':role,'count':count,'fw':fw,'fh':fh})
  file=OUT/(role+'-poses.png');file.write_bytes(base64.b64decode(data));items.append({'id':role,'file':file.name,'type':'actor-poses','frames':count,'frameSize':[fw,fh],'footAnchor':[fw/2,fh-12],'animation':['locomotion:0-7','windup:8-11','recovery:12-15']if role=='runner'else['walk:0-7'],'scope':'Reusable reference atlas; runtime draws the vector module directly, not this atlas'})
 if errors:raise AssertionError(errors)
 b.close()
for item in items:item.update(bytes=(OUT/item['file']).stat().st_size,sha256=hashlib.sha256((OUT/item['file']).read_bytes()).hexdigest())
(OUT/'atlas.json').write_text(json.dumps({'version':105,'scope':'Vector assets exported from shipped renderer; not final photorealistic or 1:1 film artwork','items':items,'rendererHash':hashlib.sha256((ROOT/'src/alien3-art-v105.js').read_bytes()).hexdigest()},ensure_ascii=False,indent=2)+'\n')
(OUT/'README.md').write_text('# Exports visuels V105\n\nCinq repères et les poses de Ripley, Aaron, Morse, Dillon et du Runner. Les PNG transparents proviennent exactement des fonctions Canvas livrées. Les ancrages et dimensions sont dans atlas.json. Le jeu dessine ces fonctions directement : il ne charge pas ces atlas. Ces silhouettes stylisées ne sont pas annoncées comme des assets finaux fidèles 1:1 au film.\n')
print(json.dumps({'ok':True,'png':len(items),'actorFrames':sum(x['frames']for x in items if x['type']=='actor-poses')}))
