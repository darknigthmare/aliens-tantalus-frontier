from pathlib import Path
import json,hashlib,subprocess,sys,shutil,time
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'qa-v104';SHOTS=OUT/'captures';SHOTS.mkdir(exist_ok=True,parents=True)
subprocess.run([sys.executable,str(ROOT/'scripts/build-preview-v104.py')],check=True)
html=(ROOT/'FIORINA_V104_JOUER.html').read_text();checks=[];captures=[];errors=[];requests=[];route=[]
def check(name,ok,details=None):
 checks.append({'name':name,'ok':bool(ok),'details':details})
 if not ok:raise AssertionError(name+' '+str(details))
def open_page(browser,query='freeze=1'):
 page=browser.new_page(viewport={'width':1280,'height':1000},accept_downloads=True)
 page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url))
 page.set_content('<script>window.__FIORINA_QA__=true;window.__BENCH_QUERY__='+json.dumps(query)+'</script>'+html,wait_until='load');page.wait_for_function('!!window.fiorinaBench',timeout=12000);return page
def advance(p,n):p.evaluate('(n)=>{for(let i=0;i<n;i++)fiorinaBench.engine.update(1/60);fiorinaBench.render();}',n)
def pos(p):return p.evaluate('({x:fiorinaBench.engine.player.x,y:fiorinaBench.engine.player.y,stage:fiorinaBench.engine.alien3V104.round?.stage,clock:fiorinaBench.engine.alien3V104.clock})')
def walk(p,target,max_frames=1800):
 start=pos(p);key='ArrowRight'if start['x']<target else'ArrowLeft';p.locator('canvas').focus();p.keyboard.down(key);frames=0;last=start['x'];stalled=0
 while frames<max_frames:
  value=pos(p)['x'];d=target-value
  if abs(d)<5 or(key=='ArrowRight'and d<0)or(key=='ArrowLeft'and d>0):break
  step=min(20,max(1,int(abs(d)/3.2)));advance(p,step);frames+=step;after=pos(p)['x'];stalled=stalled+1 if abs(after-last)<.05 else 0;last=after
  if stalled>2:break
 p.keyboard.up(key);end=pos(p);route.append({'action':key,'target':target,'frames':frames,'before':start,'after':end});check('Traversal reaches x '+str(target),abs(end['x']-target)<7,end)
def shoot(p,name,scope='prepared inspection'):
 original=p.evaluate('document.body.classList.contains("capture")');p.evaluate('document.body.classList.add("capture");fiorinaBench.render()');p.set_viewport_size({'width':1280,'height':720});p.locator('canvas').screenshot(path=str(SHOTS/(name+'.png')))
 state=p.evaluate('({pose:fiorinaBench.engine.player,phase:fiorinaBench.engine.alien3V88.phase,flags:fiorinaBench.engine.getAlien3VisualFlagsV102(),state:fiorinaBench.engine.alien3V104,lights:fiorinaBench.engine.alien3V103.lights,room:fiorinaBench.engine.alien3RoomV104?.id})');captures.append({'file':'qa-v104/captures/'+name+'.png','scope':scope,'state':state})
 p.set_viewport_size({'width':1280,'height':1000});p.evaluate('(v)=>{document.body.classList.toggle("capture",v);}',original)
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=open_page(browser);check('Real recovered V103 and V104 mixins active',page.evaluate('fiorinaBench.engine.isAlien3MissionV104()&&fiorinaBench.engine.isAlien3MissionV103()'))
  page.locator('#round').click();check('Round begins at stage zero with three actual dark circuits',page.evaluate('fiorinaBench.engine.alien3V104.round.stage===0&&["care-light","cell-light","service-light"].every(k=>fiorinaBench.engine.alien3V103.lights[k]===false)'))
  shoot(page,'01_ronde_depart','continuous keyboard round: starting position')
  walk(page,1200);before=page.evaluate('fiorinaBench.engine.alien3V103.lights["care-light"]');page.keyboard.press('KeyI');advance(page,20);check('Care lamp switches on through real I input',not before and page.evaluate('fiorinaBench.engine.alien3V103.lights["care-light"]'));check('First objective recorded',pos(page)['stage']==1)
  walk(page,1442);page.keyboard.press('KeyE');check('Cell-block access opened with E',page.evaluate('fiorinaBench.engine.doors[0].open'));walk(page,1995);page.keyboard.press('KeyI');advance(page,20);check('Second light completed at its physical control',pos(page)['stage']==2)
  shoot(page,'02_cellules_retablies','continuous keyboard round after the second light')
  # Native file download and import in a fresh browser page, not a state-injection shortcut.
  with page.expect_download()as download_info:page.locator('#export-save').click()
  download=download_info.value;save_path=OUT/'round-export.json';download.save_as(str(save_path));data=json.loads(save_path.read_text());check('Actual download is a stage-two save',data['state']['round']['stage']==2)
  second=open_page(browser);second.locator('#save-file').set_input_files(str(save_path));second.wait_for_function('fiorinaBench.engine.alien3V104.round?.stage===2');check('Import restores in pause',second.evaluate('fiorinaBench.engine.paused'));check('Import preserves actual position',abs(pos(second)['x']-pos(page)['x'])<.001)
  bad=OUT/'invalid-save.json';bad.write_text('{invalid');before=second.evaluate('JSON.stringify(fiorinaBench.exportState())');second.locator('#save-file').set_input_files(str(bad));second.wait_for_function('document.querySelector("#save-status").textContent.includes("refusé")');check('Rejected file leaves state unchanged',second.evaluate('(v)=>JSON.stringify(fiorinaBench.exportState())===v',before))
  second.locator('#pause').click();page.close();page=second;page.locator('canvas').focus();check('Resume leaves pause cleanly',not page.evaluate('fiorinaBench.engine.paused'))
  walk(page,2770);page.keyboard.press('KeyE');check('Service access opens with E',page.evaluate('fiorinaBench.engine.doors[1].open'));walk(page,3052);page.keyboard.down('ArrowUp');advance(page,86);page.keyboard.up('ArrowUp');record=pos(page);route.append({'action':'ArrowUp','frames':86,'after':record});check('Same traversal climbs existing ladder to the upper workshop',abs(record['y']-240)<3,record)
  walk(page,3094);page.keyboard.press('KeyI');advance(page,20);check('Third lamp can only be operated at workshop level',pos(page)['stage']==3)
  shoot(page,'03_atelier_retabli','continuous keyboard round: upper workshop')
  walk(page,3052);page.keyboard.down('ArrowDown');advance(page,86);page.keyboard.up('ArrowDown');check('Descend to the main floor',abs(pos(page)['y']-420)<3,pos(page));walk(page,2282);advance(page,4);check('Return to assembly hall completes the round',page.evaluate('fiorinaBench.engine.alien3V104.round.finished'))
  route_end=page.evaluate('structuredClone(fiorinaBench.engine.alien3V104.round)');shoot(page,'04_ronde_terminee','continuous keyboard round: complete after export/import, no progress or position injection')
  page.keyboard.press('KeyM');check('Map opens',page.evaluate('fiorinaBench.engine.alien3MapOpenV103'));frozen=pos(page);page.keyboard.down('ArrowRight');advance(page,40);page.keyboard.up('ArrowRight');check('Map stops movement and the same simulation clock',pos(page)==frozen);shoot(page,'05_plan_releve','map of nodes actually visited by the round');page.keyboard.press('Escape');check('Map closes without adding pause',page.evaluate('!fiorinaBench.engine.alien3MapOpenV103&&!fiorinaBench.engine.paused'))
  page.keyboard.press('KeyC');page.keyboard.press('Slash');page.locator('#archive-search').fill('Runner');page.keyboard.press('Enter');check('Archive text search still returns discovered source entries',page.evaluate('fiorinaBench.engine.alien3CodexVisibleEntriesV99().length')>0);shoot(page,'06_archives','archive interaction in the local host (host exposes the archival catalog for inspection)');page.keyboard.press('KeyC')
  # Prepared visual-event scenes. These are explicitly not counted as continuous play.
  page.locator('.settings summary').click();page.locator('#sector').select_option('3');page.locator('#moment').select_option('quiet');shoot(page,'07_avant_le_feu')
  page.locator('#moment').select_option('fire');advance(page,4);shoot(page,'08_incendie');check('Fire phase uses actual fire-maze binding',page.evaluate('fiorinaBench.engine.getAlien3VisualFlagsV102().fire'))
  page.locator('#moment').select_option('soot');advance(page,4);shoot(page,'09_suie');check('After fire keeps soot, no flame',page.evaluate('fiorinaBench.engine.getAlien3VisualFlagsV102().soot&&!fiorinaBench.engine.getAlien3VisualFlagsV102().fire'))
  page.locator('#sector').select_option('6');page.locator('#moment').select_option('hot');shoot(page,'10_coulee');page.locator('#moment').select_option('steam');advance(page,9);shoot(page,'11_refroidissement');check('Thermal cooling enables steam in mold, not health damage',page.evaluate('fiorinaBench.engine.getAlien3VisualFlagsV102().steam&&fiorinaBench.engine.player.health===100'))
  page.locator('#sector').select_option('8');page.locator('#moment').select_option('quiet');page.evaluate('fiorinaBench.render()');hidden=page.evaluate('fiorinaBench.engine.alien3RenderStatsV103.props');page.locator('#moment').select_option('company');page.evaluate('fiorinaBench.render()');visible=page.evaluate('fiorinaBench.engine.alien3RenderStatsV103.props');check('Company kit still depends on arrival',visible-hidden==8,{'before':hidden,'after':visible});shoot(page,'12_arrivee_compagnie')
  # Test collision vetoes using directed placements, not the round.
  collision=page.evaluate('''()=>{const e=fiorinaBench.engine;e.player.health=100;Object.assign(e.player,{x:4200,y:420,depth:1});Object.assign(e.alien3RunnerV88,{x:4210,y:260,name:'Runner',id:'one-runner',alive:true});e.alien3RoomV104=null;e.paused=false;const bite=e.damagePlayer(e.player,20,{source:'Runner'});const fire=e.damagePlayer(e.player,7,{source:'fire'});return{bite,fire,hp:e.player.health,reason:e.alien3ContactsV104.reason};}''');check('Same code vetoes upper-floor bite, preserves ordinary damage',collision['bite']==0 and collision['fire']==7 and collision['hp']==93,collision)
  page.locator('#sector').select_option('5');page.evaluate('fiorinaBench.engine.player.x=4020;fiorinaBench.engine.player.health=100;');advance(page,320);check('Healthy idle has no permanent health panel',page.evaluate('fiorinaBench.engine.alien3HudV104.healthTime===0'))
  shoot(page,'13_hud_discret','prepared idle state: contextual HUD has faded')
  before=page.evaluate('JSON.stringify(fiorinaBench.exportState())');page.evaluate('()=>{for(let i=0;i<12;i++)fiorinaBench.render()}');check('Repeated rendering never modifies the save',page.evaluate('(v)=>JSON.stringify(fiorinaBench.exportState())===v',before))
  page.locator('#motion').check();page.locator('#contrast').check();page.locator('#hud-mode').select_option('always');check('Options update only their settings',page.evaluate('fiorinaBench.engine.alien3V104.settings.reducedMotion&&fiorinaBench.engine.alien3V104.settings.highContrast&&fiorinaBench.engine.alien3V104.settings.hud==="always"'))
  coverage=page.evaluate('''()=>{const e=fiorinaBench.engine,c=document.querySelector('canvas').getContext('2d');const out=[];for(const x of [0,2200,4920])for(const y of [0,60,110]){e.camera={x,y};c.clearRect(0,0,1280,720);e.drawBackdrop(c);const data=c.getImageData(0,0,1280,1).data;out.push([...data].every((v,i)=>i%4!==3||v===255));}return out;}''');check('Nine camera poses retain an opaque first pixel row',all(coverage))
  page.set_viewport_size({'width':844,'height':390});rect=page.locator('canvas').bounding_box();check('Mobile landscape canvas fits horizontally',rect['width']<=844,rect);page.set_viewport_size({'width':390,'height':844});rect=page.locator('canvas').bounding_box();check('Mobile portrait canvas fits horizontally',rect['width']<=390,rect)
  check('No JavaScript page error in tested paths',not errors,errors);check('No external HTTP request in the standalone host',not[u for u in requests if u.startswith(('http:','https:'))]);version=browser.version;browser.close()
 for s in captures:
  raw=(ROOT/s['file']).read_bytes();s['sha256']=hashlib.sha256(raw).hexdigest();s['bytes']=len(raw)
 result={'ok':True,'tests':len(checks),'scope':'Shared V101–V104 rendering modules in a simplified local controller; not the complete film campaign','checks':checks,'route':route,'round':route_end,'captures':captures,'browser':version,'errors':errors,'nativeProductionBuild':False}
 (OUT/'browser.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({'ok':True,'tests':len(checks),'captures':len(captures),'round':route_end},ensure_ascii=False))
except Exception as e:
 (OUT/'browser-failure.json').write_text(json.dumps({'ok':False,'error':str(e),'checks':checks,'route':route,'errors':errors},ensure_ascii=False,indent=2));raise
