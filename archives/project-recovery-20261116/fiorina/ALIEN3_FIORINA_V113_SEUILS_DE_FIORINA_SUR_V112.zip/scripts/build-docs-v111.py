#!/usr/bin/env python3
from pathlib import Path
from html import escape as esc
import json,re,subprocess,base64,hashlib,collections
R=Path(__file__).resolve().parents[1];Q=R/'qa-v111';D=R/'docs';D.mkdir(exist_ok=True)
subprocess.run(['node',str(R/'scripts/export-design-v111.mjs')],check=True)
src=json.loads((Q/'design-source.json').read_text());u=json.loads((Q/'unit.json').read_text());ins=json.loads((Q/'install.json').read_text());b=json.loads((Q/'browser.json').read_text());ordinary=json.loads((Q/'delivered.json').read_text());cx=json.loads((Q/'codex-browser.json').read_text())
old=(R/'ALIEN3_CODEX_LEVEL_DESIGN_V110.html').read_text();start=old.index('const cards=')+len('const cards=');cards,end=json.JSONDecoder().raw_decode(old[start:]);assert len(cards)==615
new=[]
def add(kind,id,title,text,details=[]):new.append({'type':kind,'id':id,'title':title,'text':text,'details':details})
for c in src['contracts']:add('Règles V111',c['id'],c['title'],c['text'],[['Base','v110-crew-step','La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.'],['Preuve','qa-v111/unit.json','Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.']])
case=src['caseDoor'];plan=case['decision']['plan'];add('Choix de parcours','route111-closed-gate','Morse devant la porte fermée','Le trajet est évalué depuis la position réelle au milieu de f161-e07. Continuer est bloqué par le battant. Revenir au carrefour puis prendre les passages inférieurs reste possible. Ce calcul n’ouvre pas la porte et ne remplace pas l’arrivée à la coulée.',[['Participant','participant-morse','Le personnage conserve sa vitesse et son but.'],['Porte','f161-e07',f'Pose de calcul : X {case["actor"]["x"]:.2f} ; pied Y {case["actor"]["y"]+case["actor"]["h"]:.2f}. Le corps ne peut pas pénétrer dans le battant.'],['Retour','f161-bishop','Retour le long du segment déjà parcouru, sans changement de coordonnées brusque.'],['Itinéraire','f161-tunnel-shrine',' → '.join(plan['route']['nodes'])],['Destination','f161-lead-primer','La commande est occupée seulement après la fin de segment et l’arrivée physique.']])
w=src['caseShortJet'];add('Choix de parcours','route111-wait-short','Attendre la fin d’un jet bref','Un détour praticable n’est pas forcément plus rapide. Le choix compare sa longueur physique, y compris les approches d’échelles, à la route ordinaire avec le temps chaud restant. Ce sont des temps estimés, pas une promesse de durée.',[['Conduite','purge109-foundry-purge',f'Cas dirigé de calcul : attente et trajet estimés à {w["decision"]["waitETA"]:.2f} s ; détour à {w["decision"]["detourETA"]:.2f} s. Le jet n’est pas prolongé pour fabriquer une préférence.'],['Pas réel','v110-crew-margin','Le personnage peut approcher, puis attend devant le vrai volume avec la marge corporelle.'],['Révision','v111-review','Une nouvelle ouverture ou la fin du danger déclenche une réévaluation.']])
for n in src['junctions']:
 edges=[e for e in src['connections']if n['id']in[e['from'],e['to']]]
 add('Carrefours de détour','route111-junction-'+n['id'],n['id'].replace('f161-','').replace('-',' ').capitalize(),f'Point existant ({n["x"]}, {n["y"]}), support de largeur {n["width"]}. Ce point n’est pas une nouvelle salle : il sert à vérifier qu’une décision de détour revient à une vraie jonction plutôt qu’à un emplacement inventé.',[['Appui',n['id'],'Le point appartient déjà au graphe V105.'],*[[e['id'],e['id'],'Approches successives : '+ ' → '.join(f'({p["x"]}, {p["y"]})'for p in e['points'])+f'. Longueur physique canonique : {e["length"]:.2f}.']for e in edges]])
for who,goal in [('morse','f161-lead-primer'),('dillon','f161-piston-c-node')]:
 add('Conduite du groupe','route111-'+who,who.capitalize()+' conserve sa mission','Le détour change le chemin, jamais l’objectif. G impose toujours une attente volontaire. Les bruits de pas comptent uniquement la distance réellement parcourue ; une décision ou une attente ne produit pas de faux pas.',[['Participant','participant-'+who,'Identité, santé, ordre et destination restent propriétaires des systèmes antérieurs.'],['Poste',goal,'Aucun succès ni armement n’est accordé parce qu’un trajet a été calculé.'],['Reprise','save111-cache','Les caches ne survivent pas à un import. La pose et son segment, eux, sont conservés.']])
for id,title,text in [('forward','Poursuivre','Un passage déjà libre conserve le déplacement historique. Hors obstacle et vapeur, la parité a été vérifiée pas par pas.'),('return','Revenir au carrefour','Le personnage inverse seulement un segment réversible et le parcourt dans l’autre sens. Un sens unique reste interdit.'),('detour','Prendre l’autre voie','La route choisie ne contient que des connexions existantes, sans conduit réservé au Runner. Chaque nouveau pas est encore vérifié.'),('wait','Attendre ou rester sur ordre','Un trajet absent ou disproportionné conserve une attente sûre. Une consigne volontaire reste prioritaire même si le passage se libère.')]:
 add('Décisions V111','routestate111-'+id,title,text,[['Navigation','v111-position','Le budget de vitesse est consommé une seule fois par pas de simulation.'],['Sécurité','v111-plume','Une porte qui se ferme ou un jet qui apparaît peut interrompre la route choisie.']])
for id,title,text in [('current','Position et registre courant','Les coordonnées et les segments canoniques viennent de la sauvegarde V105. V111 ajoute seulement un registre borné de décisions.'),('cache','Ne pas reprendre un trajet périmé','Le graphe filtré, les décisions provisoires, les temporisations de recherche et alertes sont jetés à l’import. Après reprise en pause, les portes et jets actuels sont réévalués.'),('safe','Dernier poste sûr distinct','Le poste sûr possède son propre registre. Une décision tardive dans la partie courante ne remplace pas cet état antérieur.'),('migration','Migration et refus','Les fichiers V105 à V110 valides reçoivent un registre vide. Une arrivée après détour ne peut pas dépasser le nombre de détours ; les identités et signatures doivent correspondre. L’empreinte protège contre la corruption, pas contre la triche.')]:
 add('Reprises V111','save111-'+id,title,text,[['Base','save110-current','Les validations antérieures continuent à vérifier poses, participants, piège, jets, boulons et ordres.'],['Faits','v111-save','Les données temporaires ne peuvent pas imposer une route depuis un fichier.']])
for c in cards:
 if c['id']=='v110-scope':c['text']+=' La V111 ajoute un choix de détour séparé ; ce contrat décrit seulement le périmètre V110.';c['details'].append(['Extension','v111-choice','Navigation adaptative sans nouvel objectif.'])
 if c['id']=='crewstate110-hot-wait':c['details'].append(['Choix ultérieur','route111-wait-short','En V111, la durée résiduelle peut rendre cette attente préférable à un détour.'])
# Extend old connections in place rather than recounting them as new geometry.
for c in cards:
 for e in src['connections']:
  if c['id']==e['id']:c['details'].append(['Groupe V111','v111-doors',f'Longueur canonique {e["length"]:.2f} unités avec approches d’échelle. La géométrie physique des portes est testée sur chaque segment.'])
cards+=new;assert len({c['id']for c in cards})==len(cards)
out=old[:start]+json.dumps(cards,ensure_ascii=False).replace('</script','<\\/script')+old[start+end:]
out=out.replace('DOCUMENT DE CONCEPTION V110','DOCUMENT DE CONCEPTION V111').replace('<h1>Garder le passage</h1>','<h1>Les détours de service</h1>').replace('615 fiches issues',f'{len(cards)} fiches issues')
out=out.replace('</select></div>',''.join('<option>'+esc(t)+'</option>'for t in dict.fromkeys(c['type']for c in new))+'</select></div>',1)
out=re.sub(r'<div class="scope">.*?</div>','<div class="scope">Codex de conception hors jeu. V111 ajoute un choix de trajet sur les passages existants : continuer, revenir au carrefour, contourner ou attendre. Les corps ne sont jamais téléportés. Les preuves concernent un banc à contrôleur simplifié, pas la campagne native complète.</div>',out,count=1,flags=re.S)
(R/'ALIEN3_CODEX_LEVEL_DESIGN_V111.html').write_text(out);(Q/'codex-source.json').write_text(json.dumps(cards,ensure_ascii=False,indent=2)+'\n')
md=['# ALIEN 3 — FIORINA 161 · CODEX DE LEVEL DESIGN V111','','## Périmètre','Document hors jeu produit à partir des contrats exécutables. Le modèle conserve 72 points, 119 connexions, 20 sections descriptives, 30 assemblages et 284 composants historiques. V111 ne crée ni salle ni nouvel asset.','',f'{len(cards)} fiches, dont {len(new)} nouveaux contrats. Les métriques de route sont des unités de jeu, pas des mesures des décors du film.','', '## Décision de parcours','Le moteur conserve ses portes et étages. Le planificateur exclut les conduits du Runner, teste les corps sur les segments d’approche et compare une attente finie au détour. Le pas réel reste vérifié après le calcul. Un segment à sens unique n’est pas inversé.','Un ordre G prévaut sur une route choisie. L’arrivée reste celle du propriétaire des objectifs. Les plans et alertes transitoires sont recalculés après import en pause. Le dernier poste sûr possède son propre registre.','','## Registre détaillé','']
for c in cards:
 md += [f'### {c["title"]}',f'`{c["id"]}` · {c["type"]}','',c['text'],'']
 for k,ref,text in c.get('details',[]):md += [f'**{k}** — `{ref}` : {text}','']
(D/'ALIEN3_LEVEL_DESIGN_CODEX_V111.md').write_text('\n'.join(md));(Q/'documentation.json').write_text(json.dumps({'cards':len(cards),'newCards':len(new),'types':dict(collections.Counter(c['type']for c in new)),'sourceHashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (R/'src').glob('*v111.js')}},ensure_ascii=False,indent=2)+'\n')
style='body{background:#0c1411;color:#d5decb;font:16px/1.65 system-ui,sans-serif;margin:0}main{max-width:1250px;margin:auto;padding:32px}h1{font-size:36px;font-weight:500}h2{font-size:24px;color:#c8d2b6}article{margin:28px 0 48px;padding:20px;background:#15251b;border:1px solid #45563e;border-radius:9px}img{display:block;width:100%;height:auto;margin:14px 0;border:1px solid #657157}.scope{border-left:3px solid #b89962;padding:17px 22px;background:#272d20;color:#d8d1b6}small{color:#a7b699}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:9px 12px;border-bottom:1px solid #465238}@media(max-width:600px){main{padding:18px}h1{font-size:26px}article{padding:12px}}'
sections=[]
for shot in b['screenshots']:
 p=R/shot['file'];assert hashlib.sha256(p.read_bytes()).hexdigest()==shot['sha256']
 setup='Test dirigé avec positions préparées.'if shot['scope'].startswith('directed')else'Parcours au clavier ou reprise de fichier après approche physique. Aucun déplacement de participant injecté.'
 sections.append(f'<article><h2>{esc(shot["caption"])}</h2><img alt="Capture native du banc local" src="data:image/png;base64,{base64.b64encode(p.read_bytes()).decode()}"><small>{esc(setup)} Modules livrés, contrôleur simplifié, silhouettes provisoires.</small></article>')
rows=''.join(f'<tr><td>{esc(str(x))}</td><td>{esc(str(y))}</td><td>{esc(z)}</td></tr>'for x,y,z in [('Contrats V111',u['cases'],'Base instrumentée et vrai graphe'),('Installation',ins['cases'],'Fixtures à commandes npm synthétiques'),('Chromium',b['controlsExecuted'],'Assertions réparties sur onze groupes'),('HTML distribué',ordinary['tests'],'Horloge ordinaire, aucun accès QA'),('Codex interactif',cx['tests'],'Recherche, références et affichage mobile')])
(R/'RAPPORT_ILLUSTRE_V111.html').write_text(f'<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Alien 3 V111 — Les détours de service</title><style>{style}</style><main><h1>Alien 3 — Les détours de service</h1><div class="scope">Rapport V111. Captures natives des modules livrés dans un banc local à physique simplifiée. Aucun build complet du jeu, parcours intégral du film, push ou déploiement n’a été réalisé.</div><article><h2>Un chemin possible, pas une arrivée inventée</h2><p>Morse peut revenir au carrefour depuis un segment bloqué, puis rejoindre son poste par les galeries existantes. La porte reste fermée. La vapeur, les étages, les corps et l’ordre volontaire sont vérifiés. Attendre un bref jet peut rester plus rapide qu’un grand détour.</p><p>Le détour et la reprise par fichier ont été parcourus au clavier. La chasse et le piège gardent leur propriétaire historique. Les temps ci-dessous sont ceux de robots connaissant le parcours, pas des durées de jeu humaines.</p></article><article><h2>Vérifications exécutées</h2><table><tr><th>Contrôle</th><th>Nombre réussi</th><th>Portée</th></tr>{rows}</table></article>'+''.join(sections)+'</main></html>')
route_rows=['| Profil | État | Santé | Contacts | Détours décidés | Retours de segment | Temps simulé |','|---|---|---:|---:|---:|---:|---:|']
for r in b['routes']:
 s=r['result'];st=s['routing']['stats'];route_rows.append(f'| {r["profile"]} | {s["status"]} | {s["hp"]} | {s["pursuit"]["stats"]["hits"]} | {st["detours"]} | {st["retreats"]} | {s["clock"]:.2f} s |')
qa=f'''# QA — Alien 3 V111

## Exécution réelle
- {u['cases']} cas unitaires sur base instrumentée.
- {ins['cases']} scénarios d’installation à npm synthétique.
- {b['controlsExecuted']} assertions Chromium, {b['uniqueControlNames']} libellés distincts, {len(b['phases'])} groupes.
- {ordinary['tests']} contrôles du HTML distribué sans API de test.
- {cx['tests']} contrôles du codex interactif.
- {len(b['screenshots'])} captures natives.

## Parcours
{chr(10).join(route_rows)}

Huit parcours sont terminés. La neuvième ligne (détour repris par fichier) valide l’arrivée du groupe aux postes ; elle ne prétend pas être une nouvelle fin complète du piège.

Les parcours utilisent les gestionnaires clavier et une horloge contrôlée. Le robot connaît les itinéraires. Le registre des détours contient des faits de décision, pas un cache de route exportable. Après import, un trajet qui se termine grâce au propriétaire historique n’est pas recompté comme une nouvelle décision V111.

## Corrections trouvées
- Un ancien test de largeur de porte utilisait 42 % de la largeur du corps ; le garde V111 utilise la demi-largeur et refuse la pénétration de l’épaule avant report du mouvement.
- Le premier contrôle visuel attendait à tort une coursive haute. Le calcul choisit les galeries inférieures, plus courtes ; la preuve teste maintenant un vrai changement d’étage plutôt qu’un chemin imposé par le test.
- L’essai de silence d’un détenu retenu comptait les pas de tout le groupe. Il vérifie désormais le parcours propre de Morse ; Dillon, encore en mouvement, peut légitimement marcher.
- Le test de lien dans le codex sélectionne la fiche exacte : une recherche peut aussi afficher les fiches qui la référencent.
- La capture du détour a été décalée dans le temps de simulation, sans changer les positions, pour montrer Morse entièrement dans le champ de jeu.

## Non revendiqué
Aucune nouvelle route, machine, blessure de détenu, panique complète ou modification du comportement du Runner. Les détours emploient le graphe existant et ne forcent pas les étapes du piège.
Banc avec physique simplifiée et silhouettes vectorielles provisoires. Pas de campagne native entière, test humain, appareil mobile physique, Safari, manette, écoute matérielle ou performance cible certifiée. Aucun build natif, push ou déploiement, et aucune nouvelle affirmation de refus de droits GitHub.

## Installation
Quatre nouveaux modules et un raccord moteur, contrôlés contre les 51 sources V110 livrées. Aucune source historique modifiée. Copie temporaire, vérification des mêmes octets, garde contre la concurrence et restauration externe. Les scripts npm des fixtures ne sont pas le build de Tantalus.

## Régressions séparées
V110 : 65 cas et 19 installations. V109 : 60 cas. Les suites historiques restent indépendantes de la qualification du moteur complet.
'''
(R/'RAPPORT_QA_V111.md').write_text(qa)
(D/'PORTEE_V111.md').write_text('''# Portée V111

| Sujet | Livré et vérifié | Non revendiqué |
|---|---|---|
| Groupe | Choix de trajet, retour sur segment réversible, détour réel, attente comparée | Panique complète, nouvelles blessures ou remplacement des missions |
| Obstacles | Mêmes portes et jets, étages et profondeurs cohérents | Nouveaux murs physiques, conduits humains ajoutés |
| Déplacement | Budget de vitesse unique et segments canoniques | Téléportation, arrivée ou étape injectées |
| Fichiers | Pose et segment conservés, caches supprimés, import en pause, poste sûr distinct | Autosave disque, cloud ou signature anti-triche |
| Rendu | Captures natives du canvas et modules livrés | Assets définitifs photoréalistes ou film reconstitué 1:1 |
| Intégration | 51 sources vérifiées, staging et restauration | Build natif complet, push et déploiement |
''')
(R/'README.md').write_text(f'''# ALIEN 3 — FIORINA 161 V111 · Les détours de service

Correctif incrémental sur une base V110 compatible, pas le jeu principal complet. Les modules antérieurs requis, outils et données utiles sont inclus ; le moteur principal et ses gros assets ne le sont pas.

## Jouer et lire
- `FIORINA_V111_JOUER.html` : aperçu autonome, sans requête externe.
- `ALIEN3_CODEX_LEVEL_DESIGN_V111.html` : codex hors jeu, {len(cards)} fiches.
- `docs/ALIEN3_LEVEL_DESIGN_CODEX_V111.md` : version détaillée.
- `RAPPORT_ILLUSTRE_V111.html` et `.pdf` : captures natives, avec portée précisée.
- `RAPPORT_QA_V111.md` : preuves et limites.

## Commandes
Flèches : marcher / échelle / profondeur ; Espace : saut ; E : interaction ; I : lampe ; F : bruit métallique ; T/Y : lancer/récupérer un boulon ; V : ouvrir/refermer une purge ; G : demander d’attendre/repartir ; M : plan ; C : archives ; R : dernier poste sûr ; Échap : pause.
Aucune nouvelle touche n’est ajoutée. Un ordre G reste prioritaire sur un détour. Les sélecteurs extérieurs servent à l’inspection ; les parcours restent originaux, pas une campagne complète du film.

## Installation dans une copie du projet
Node.js 20 ou ultérieur. Extraire ce correctif dans un autre dossier que la copie du jeu.
```sh
node scripts/install-v111.mjs /chemin/vers/projet --dry-run
node scripts/install-v111.mjs /chemin/vers/projet
```
Les 51 sources V110 exactes sont vérifiées. Les quatre modules nouveaux et le raccord moteur sont préparés dans une copie, puis les scripts `npm run check` et `npm run build` du projet sont exécutés. Les modifications ne sont reportées que si les octets et les sources sont restés inchangés. Les fixtures utilisent des npm synthétiques : elles ne prouvent pas un build du jeu.
`--skip-project-check` indique explicitement que ces deux contrôles sont omis. Une restauration externe est disponible avec le reçu retourné :
```sh
node scripts/install-v111.mjs --restore /chemin/vers/receipt.json
```

## Rejouer les preuves
```sh
node scripts/test-v111.mjs
node scripts/test-install-v111.mjs
python scripts/verify-routes-v111.py detour
python scripts/verify-routes-v111.py resume
python scripts/verify-browser-v111.py trap
python scripts/verify-delivered-v111.py
python scripts/verify-codex-v111.py
```
Les scripts Chromium nécessitent Playwright et Chromium disponibles localement. Le fichier distribué ordinaire ne publie pas d’API de test. Aucun build natif complet, push ou déploiement n’est revendiqué.
''')
print(json.dumps({'cards':len(cards),'newCards':len(new),'captures':len(b['screenshots'])}))
