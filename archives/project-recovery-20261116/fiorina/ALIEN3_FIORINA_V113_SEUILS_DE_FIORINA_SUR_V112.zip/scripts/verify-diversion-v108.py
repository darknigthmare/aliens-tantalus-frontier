#!/usr/bin/env python3
"""Continuous keyboard route plus explicitly separate directed physics/save checks."""
from browser_support_v108 import *
PHASE=sys.argv[1] if len(sys.argv)>1 else 'route'
def stock(p):return p.evaluate('fiorinaBench.engine.alien3DiversionV108')
def download(p,name):
 p.evaluate('document.body.classList.remove("capture")')
 with p.expect_download()as dl:p.locator('#export-save').click()
 dest=OUT/name;dl.value.save_as(dest);p.evaluate('document.body.classList.add("capture")');p.locator('canvas').focus();return dest
with sync_playwright()as pw:
 browser=pw.chromium.launch(executable_path=shutil.which('chromium')or'/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 if PHASE=='route':
  p=start(browser,difficulty='survie');walk(p,1320);press(p,'KeyE',15);walk(p,1442);press(p,'KeyE');walk(p,1770,True);hold(p,'ArrowUp',3)
  # Wait behind the player’s depth separation for an acoustically reachable floor.
  for _ in range(80):
   r=state(p)['runner']
   if abs(r['y']-440)<15 and abs(r['x']-state(p)['x'])<420:break
   tick(p,15)
  record('Le robot attend un passage réel du Runner au même étage avant la diversion',abs(state(p)['runner']['y']-440)<15)
  before=state(p);press(p,'KeyT',12);record('La touche T lance un objet depuis Ripley, pas depuis sa cible',stock(p)['stats']['thrown']==1 and stock(p)['bolts'][0]['state']=='flying' and abs(stock(p)['bolts'][0]['x']-before['x'])<120)
  record('Aucun bruit d’impact avant le contact physique',stock(p)['stats']['impacts']==0)
  snap(p,'18_lancer_dans_bloc','Lancer au clavier pendant la traque ; le boulon est encore en vol.')
  tick(p,48);record('Le Runner entend une diversion émise depuis le boulon',stock(p)['stats']['heard']>=1,{'stats':stock(p)['stats'],'trace':state(p)['pursuit']['trace'],'runner':state(p)['runner'],'bolt':stock(p)['bolts'][0]})
  trace=state(p)['pursuit']['trace'];record('La trace sonore n’est pas la position cachée de Ripley',trace['kind']=='noise' and abs(trace['x']-state(p)['x'])>100)
  snap(p,'19_enquete_au_bruit','Après l’impact, le Runner enquête sur une trace sonore. Sa position n’est pas forcée.')
  walk(p,2755,True);hold(p,'ArrowDown',3);walk(p,2770,True);press(p,'KeyE');walk(p,3052,True);hold(p,'ArrowUp',86);hold(p,'KeyE',70)
  record('Le relevé reste obtenu par le geste complet après la diversion',state(p)['stage']==2)
  hunt_back(p,'diversion-reelle',capture=False);record('Le parcours de traque est terminé avec la réserve réellement entamée',stock(p)['stats']['thrown']==1 and stock(p)['bolts'][0]['state']!='pocket')
  snap(p,'20_retour_apres_diversion','Retour vivant auprès d’Aaron après diversion, montée, lecture et trajet inverse, tous au clavier.')
  p.close()
 if PHASE=='recovery':
  p=start(browser,mode='trap');before=state(p);press(p,'KeyT',28);snap(p,'21_arc_fonderie','Lancer au poste de commande, en début de préparation où le Runner reste dormant.','keyboard approach, no active predator before trap arming')
  press(p,'KeyM');frozen=stock(p);tick(p,120);record('Le plan suspend exactement la position et la vitesse du boulon',stock(p)==frozen);press(p,'Escape');tick(p,100)
  bolt=stock(p)['bolts'][0];record('Le boulon se pose sur le sol et ne revient pas tout seul',bolt['state']=='rest' and stock(p)['stats']['recovered']==0)
  walk(p,bolt['x']-18);snap(p,'22_boulon_au_sol','Approche au clavier d’un boulon réellement posé ; la commande de récupération exige la proximité.','keyboard preparation route, predator dormant')
  press(p,'KeyY');record('Y récupère le même boulon sans quatrième identité',len(stock(p)['bolts'])==3 and all(b['state']=='pocket'for b in stock(p)['bolts']) and stock(p)['stats']['recovered']==1)
  press(p,'KeyY');record('Un second Y ne duplique pas la récupération',stock(p)['stats']['recovered']==1)
  # Use the real closed gate behind Dillon. Walking left changes facing naturally.
  walk(p,3905);beforeImpacts=stock(p)['stats']['impacts'];press(p,'KeyT',20);record('Le lancer contre la porte réelle fermée fait rebondir le boulon',stock(p)['stats']['impacts']>beforeImpacts and stock(p)['bolts'][0]['vx']>=0,stock(p)['bolts'][0])
  snap(p,'23_impact_porte','Boulon renvoyé par la porte existante fermée ; aucune collision n’est ajoutée aux accessoires du fond.','keyboard preparation route, real closed gate')
  record('Le Runner ne s’active pas pendant les préparatifs dormants',state(p)['pursuit']['mode']=='dormant')
  p.close()
 if PHASE=='resume':
  p=start(browser,mode='trap');press(p,'KeyT',14);saved=download(p,'boulon-en-vol-v108.json');raw=json.loads(saved.read_text());pose=stock(p)['bolts'][0]
  record('Le vrai fichier exporté contient une trajectoire encore active',raw['schema']==108 and raw['diversion']['bolts'][0]['state']=='flying')
  q=start(browser,mode='trap');q.evaluate('document.body.classList.remove("capture")');q.locator('#save-file').set_input_files(str(saved));q.wait_for_function('document.querySelector("#save-status").textContent.includes("restaurée")');q.evaluate('document.body.classList.add("capture")')
  record('Une nouvelle page reprend la même position, vitesse et réserve en pause',stock(q)==raw['diversion'] and q.evaluate('fiorinaBench.engine.paused'))
  before=stock(q);tick(q,180);record('L’import en pause ne laisse pas tomber le boulon',stock(q)==before)
  press(q,'Escape');tick(q,140);record('La trajectoire reprend sans recréer le premier lancer',stock(q)['stats']['thrown']==1 and stock(q)['bolts'][0]['state']=='rest')
  bolt=stock(q)['bolts'][0];walk(q,bolt['x']-18);press(q,'KeyY');record('L’objet importé peut être récupéré une seule fois',stock(q)['stats']['recovered']==1)
  snap(q,'24_reprise_recuperee','Boulon exporté en vol, importé sur une nouvelle page, laissé tomber puis récupéré au clavier.','file roundtrip followed by keyboard movement')
  # Corruption with recomputed checksum, through file input not a hidden import setter.
  bad=raw.copy();bad['diversion']=json.loads(json.dumps(raw['diversion']));bad['diversion']['bolts'][0]['x']+=1500
  forged=q.evaluate('''f=>{let h=2166136261;const s=JSON.stringify({base:f.base,diversion:f.diversion,safePoint:f.safePoint||null});for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}f.checksum=(h>>>0).toString(16).padStart(8,'0');return JSON.stringify(f);}''',bad)
  path=OUT/'boulon-falsifie-test.json';path.write_text(forged);q.evaluate('document.body.classList.remove("capture")');before=q.evaluate('JSON.stringify(fiorinaBench.exportState())');q.locator('#save-file').set_input_files(str(path));q.wait_for_function('document.querySelector("#save-status").textContent.includes("refusé")');record('Une position impossible est refusée malgré le recalcul de l’empreinte',q.evaluate('JSON.stringify(fiorinaBench.exportState())')==before)
  # Pointer commands use the same methods; no aimed teleport argument exists.
  q.evaluate('document.querySelector(".touchpad").style.display="flex"');button=q.locator('#throw-bolt');button.scroll_into_view_if_needed();bb=button.bounding_box();before=stock(q)['stats']['thrown'];q.mouse.click(bb['x']+bb['width']/2,bb['y']+bb['height']/2);record('Le bouton pointeur déclenche le même lancer limité',stock(q)['stats']['thrown']==before+1)
  p.close();q.close()
 record('Aucune exception JavaScript',not errors,errors);record('Aucune requête réseau externe',not external,external);version=browser.version;browser.close()
result={'ok':True,'scope':'V108 modules in simplified local host; no native campaign or physical device certification','browser':version,'controls':len(tests),'results':tests,'routes':routes,'screenshots':captures,'errors':errors,'externalRequests':external,'sourceHashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (ROOT/'src').glob('*v108.js')}}
(OUT/('browser-diversion-'+PHASE+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'controls':len(tests),'routes':len(routes),'captures':len(captures)}))
