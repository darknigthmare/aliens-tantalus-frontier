#!/usr/bin/env python3
"""Assemble measured reports; no rendered scenery is redrawn for these reports."""
from pathlib import Path
import json,hashlib,base64
from html import escape as esc
R=Path(__file__).resolve().parents[1];Q=R/'qa-v113';D=R/'docs'
u=json.loads((Q/'unit.json').read_text());install=json.loads((Q/'installation.json').read_text());delivered=json.loads((Q/'delivered.json').read_text());codex=json.loads((Q/'codex-browser.json').read_text());design=json.loads((Q/'design-source.json').read_text());documentation=json.loads((Q/'documentation.json').read_text())
files=['browser-profiles.json','browser-spacing-route.json','browser-spacing-resume.json','browser-fidelity.json'];groups=[json.loads((Q/f).read_text())for f in files];tests=[t for g in groups for t in g['results']];routes=[t for g in groups for t in g.get('routes',[])];screens=[s for g in groups for s in g['screenshots']];assert len({s['file']for s in screens})==len(screens)
for s in screens:
 assert hashlib.sha256((R/s['file']).read_bytes()).hexdigest()==s['sha256'],s['file']
summary={'ok':True,'groups':len(groups),'assertions':len(tests),'distinctLabels':len({t['name']for t in tests}),'results':tests,'routes':routes,'screenshots':screens,'scope':'Three hunt profiles, two complete trap routes (one with file reprise), and separate directed visual inspections. Bench controller, not full native campaign.','nativeBuild':False}
(Q/'browser-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
sourceHashes=json.loads((Q/'preview-sources.json').read_text())['files'];assert sourceHashes['src/alien3-dlc-runtime-v105.js']==hashlib.sha256((R/'support-v113/alien3-dlc-runtime-v105.patched.js').read_bytes()).hexdigest();assert all(sourceHashes['src/'+name]==hashlib.sha256((R/'src'/name).read_bytes()).hexdigest() for name in ['alien3-dlc-runtime-v113.js','alien3-fidelity-v113.js','alien3-art-v113.js']);(Q/'source-parity.json').write_text(json.dumps({'ok':True,'ownerFile':'src/alien3-dlc-runtime-v105.js','patchedOwnerHash':sourceHashes['src/alien3-dlc-runtime-v105.js'],'sourceFiles':sourceHashes,'scope':'Source strings used by the delivered standalone; installer applies the same patch-owner-v113 function.'},indent=2)+'\n')
qa=['# ALIEN 3 — FIORINA 161 · QA V113 — Seuils de Fiorina','','## Exécution réelle',f'- {u["cases"]} cas unitaires sur la base V112 instrumentée.',f'- {install["cases"]} scénarios d’installation avec npm synthétique.',f'- {len(tests)} assertions Chromium dans {len(groups)} groupes, {len({t["name"]for t in tests})} libellés distincts.',f'- {delivered["tests"]} contrôles du fichier jouable ordinaire sans API de test.',f'- {codex["tests"]} contrôles du codex interactif.',f'- {len(screens)} captures natives du canvas Chromium.','', '## Parcours continus','| Profil | État final | Santé | Durée simulée |','|---|---|---:|---:|']
for r in routes:qa.append(f'| {r["profile"]} | {r["result"]["status"]} | {r["result"]["hp"]} | {r["result"]["clock"]:.2f} s |')
qa+=['','Les cinq traversées listées utilisent les gestionnaires clavier et une horloge contrôlée. Elles ne modifient pas les positions, arrivées, ordres ou étapes par injection. La file reprise a été exportée, importée sur une nouvelle page et suivie jusqu’à la fin du rabattage. Les robots connaissent les itinéraires ; leurs temps ne sont pas des durées de campagne humaine.','', '## Comparaisons dirigées séparées','Trois portes fermées puis ouvertes à pose et instant identiques : la feuille et son voyant changent, les montants restent fixes. Une traversée locale vérifie le blocage par le seuil fermé puis le franchissement après E. Les deux états ne représentent pas deux scènes du film reconstituées.','Les tenues du crash, carcérale et extérieure de Ripley sont des états préparés pour inspection. Les agents de récupération apparaissent avec le drapeau d’arrivée, sans créer de participant de simulation ni d’arme dans l’inventaire. Les quatre objets ajoutés restent sur leurs appuis.','', '## Problèmes de fidélité assumés','Les trois portes conservent leurs positions de gameplay héritées. Le correctif les intègre dans des retours de cloison avec un rangement de volet ; il ne démontre pas que leur position correspond au plan du film. Les retours de cloison sont décoratifs, en retrait du passage.','Le registre contient 25 entrées de lieux et scènes principales, non un inventaire exhaustif certifié. Dix-neuf possèdent des points du graphe ; six n’ont pas de liaison : prologue Sulaco, hôte bovin, présence canine/chenil, bureau d’Andrews, confinement de Golic et intérieur de récupération. Un point existant n’est pas une preuve de scène reconstruite.','Le palier de morgue hérité reste en haut du modèle ; le raccord observé dans le montage étendu exige une comparaison et une refonte ultérieure, non effectuées dans ce patch.','Les 17 fiches de personnages ne signifient pas 17 nouveaux acteurs : quatre silhouettes du banc ont été reprises, Bishop est un fragment de décor et les deux agents de récupération sont des visuels conditionnels. Les autres rôles manquants restent indiqués. Le rendu vectoriel ne certifie pas la ressemblance des visages.','Le registre de 24 équipements sépare propriétaire, référence et état livré. La lampe portative, l’outil lourd et le diagnostic complet ne sont pas déclarés implémentés. Le fusil noir de la Compagnie n’est pas une arme jouable ajoutée.','', '## Sauvegarde et installation','Aucune nouvelle progression ni migration : le fichier V112 reste utilisé. Vingt dessins ne changent ni pose, ni inventaire, ni sauvegarde. Les archives joueur gardent leurs 90 dossiers.','L’installateur vérifie 59 sources V112. Il ajoute trois modules, met à jour deux points de délégation de dessin dans le propriétaire V105 et raccorde le moteur. L’original V105 est conservé dans la base du paquet ; la copie installée est obtenue par la même fonction de patch que celle utilisée pour l’aperçu. Les contrôles de concurrence et la restauration couvrent cinq fichiers.','Les npm des tests d’installation sont synthétiques et ne valident pas le build de Tantalus. La régression V112 (54 cas unitaires) a été rejouée séparément ; ses garanties ne prouvent pas une campagne native complète.','', '## Non revendiqué','Aucun build complet de Tantalus, parcours intégral du film, push ou déploiement V113. Pas d’écoute matérielle, de manette ou de Safari physique certifiés. Pas de nouvelle arme active, de nouveau combat de la Compagnie ou de reconstitution 1:1 totale.']
(R/'RAPPORT_QA_V113.md').write_text('\n'.join(qa)+'\n')
(D/'PORTEE_V113.md').write_text('''# Portée V113 — Seuils de Fiorina

| Sujet | Livré et vérifié | Non revendiqué |
|---|---|---|
| Portes | 3 habillages liés au rectangle, au seuil et à l’état réel ; retours maçonnés, montants, coffre, volet replié | Position mesurée du film, nouvelle collision ou nouvelle route |
| Corps | 4 silhouettes reprises, 3 variantes explicites de Ripley | Visages photoréalistes, 17 acteurs intégrés, nouvelle IA |
| Équipement | 4 objets ancrés, arme noire sur 2 silhouettes de récupération conditionnelles | Nouvel arsenal de Ripley, arme utilisable, exhaustivité des accessoires à l’écran |
| Lieux | 25 entrées de couverture, 19 liées à des points, 6 absentes explicitement marquées | 25 nouvelles pièces, absence de tout lieu manquant, certification 1:1 |
| Montages | Colonnes séparées pour la comparaison | Deux campagnes intégralement reconstituées |
| Données | 59 sources V112 vérifiées, 3 modules nouveaux et 2 délégations de dessin sur V105 | Build natif complet ou dépôt publiquement déployé |
| Reprise | Format V112 préservé et rabattage terminé après import | Autosauvegarde disque ou cloud |

Le modèle historique conserve 72 points, 119 connexions, 20 sections descriptives, 30 assemblages et 284 composants. Les quatre objets V113 ne sont ni quatre nouvelles pièces ni quatre nouveaux comportements interactifs.
''')
readme='''# ALIEN 3 — FIORINA 161 V113 · Seuils de Fiorina

Correctif incrémental sur une base V112 compatible. Ce paquet n’est pas le jeu principal complet.

## Ouvrir
- `FIORINA_V113_JOUER.html` : aperçu autonome, sans requête réseau externe. Le contrôleur de base est simplifié ; les modules V104–V113 sont partagés avec le correctif.
- `ALIEN3_CODEX_LEVEL_DESIGN_V113.html` : 770 fiches recherchables, y compris les manques de fidélité.
- `RAPPORT_ILLUSTRE_V113.html` et `.pdf` : captures natives Chromium, avec portée précise.
- `docs/PORTEE_V113.md` : ce qui est intégré et ce qui ne l’est pas.

## Installation
Node.js 20 ou ultérieur. Travailler sur une copie distincte du projet. Les 59 sources V112 doivent correspondre à `sources-v112-verified.json`.

```sh
node scripts/install-v113.mjs /chemin/vers/projet --dry-run
node scripts/install-v113.mjs /chemin/vers/projet
```

L’installateur prépare une copie temporaire, vérifie les mêmes octets, applique deux délégations de dessin facultatives au propriétaire V105, ajoute trois modules et raccorde le moteur. Il lance les `npm run check` et `npm run build` du projet avant de reporter les changements. L’option `--no-build` ne valide aucune compilation. Les tests fournis utilisent des projets synthétiques.

Une restauration externe est créée ; son chemin figure dans le résultat :

```sh
node scripts/install-v113.mjs --restore /chemin/receipt.json
```

La restauration refuse des fichiers modifiés après l’installation. Le paquet conserve l’original V105 et la copie patchée dans `support-v113/`. La fonction de modification est unique et utilisée par l’installateur comme par le bundle jouable.

## Jouer et inspecter
Les deux boutons de parcours lancent la traque originale d’Aaron et le dernier rabattage. Les sélecteurs extérieurs au canvas servent à inspecter des situations préparées ; ce ne sont pas des chapitres filmés entièrement rejoués. L’équipe de récupération est visible dans la situation d’arrivée et n’apparaît pas au milieu des parcours de test.
Flèches : se déplacer, échelle ou profondeur ; Espace : saut ; E : action ; G : consigne au détenu proche ; T/Y : lancer/récupérer un boulon ; V : purge ; C : archives ; M : plan ; Échap : pause/retour.
La sauvegarde conserve le format V112 : V113 ne change que la présentation et le registre de fidélité. Import en pause, pas de reprise automatique d’un geste suspendu.

## Rejouer les preuves
```sh
node scripts/test-v113.mjs
node scripts/test-install-v113.mjs
python scripts/verify-browser-v113.py profiles
python scripts/verify-spacing-v113.py route
python scripts/verify-spacing-v113.py resume
python scripts/verify-fidelity-v113.py
python scripts/verify-delivered-v113.py
python scripts/build-codex-v113.py
python scripts/verify-codex-v113.py
python scripts/build-reports-v113.py
python scripts/build-pdf-v113.py
```
Python Playwright et Chromium sont requis pour les contrôles navigateur ; ReportLab et DejaVu Sans pour le PDF. Aucune police n’est redistribuée comme fichier. Les anciens rapports illustrés sont omis pour éviter les doublons ; les sources et outils utiles sont conservés.

## Fidélité
Le rendu reste vectoriel stylisé. Les références de production guident vêtements, finitions et usages, mais ne prouvent pas les dimensions ou les visages 1:1. Le registre signale les six lieux/scènes non liés et le raccord de morgue non qualifié. Aucun build complet, push ou déploiement n’a été effectué pour cette livraison.
'''
(R/'README.md').write_text(readme)
css='''*{box-sizing:border-box}body{margin:0;background:#101714;color:#d9dfcf;font:16px/1.65 system-ui,sans-serif}main{max-width:1300px;margin:auto;padding:36px}h1{font-size:36px;font-weight:600}h2{font-size:25px;font-weight:500}.kicker{letter-spacing:.18em;color:#b9af87;font-size:13px}.note{padding:19px 24px;border-left:3px solid #b6a16c;background:#20261a;color:#d4c8a6}article{padding:22px;border:1px solid #425442;margin:30px 0;background:#14231b}img{width:100%;height:auto;display:block;border:1px solid #596646}p{color:#b4c2ad}small{color:#8fa388}table{width:100%;border-collapse:collapse;margin:18px 0}td,th{text-align:left;padding:9px;border-bottom:1px solid #3d513b}a{color:#d1d8aa}@media(max-width:650px){main{padding:18px}h1{font-size:29px}article{padding:12px}}'''
parts=[f'<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fiorina 161 — Rapport illustré V113</title><style>{css}</style><main><div class="kicker">ALIEN 3 · FIORINA 161</div><h1>Seuils de Fiorina</h1><div class="note">V113 — Captures natives des modules livrés. Banc avec physique simplifiée ; personnages vectoriels et architecture de gameplay, pas un rendu du jeu natif ni une reconstitution intégrale du film.</div>',f'<article><h2>Ce qui est vérifié</h2><p>{u["cases"]} cas unitaires, {install["cases"]} scénarios d’installation synthétiques, {len(tests)} assertions dans quatre groupes Chromium, {delivered["tests"]} contrôles du fichier ordinaire et {codex["tests"]} du codex. Ces preuves ont des portées distinctes.</p><p>Trois seuils sont architecturés ; quatre silhouettes et quatre objets ancrés sont repris. Le registre documente 17 personnages et 24 équipements, sans annoncer que tous sont intégrés. Dix-neuf entrées de lieux possèdent des repères dans le graphe, six sont non liées. Aucun lieu n’est certifié 1:1.</p></article>']
for s in screens:
 raw=(R/s['file']).read_bytes();scope='Comparaison préparée, hors traversée continue.' if s['scope'].startswith('directed') else 'Parcours au clavier, sans injection de position ou d’étape.' if s['scope'].startswith('continuous') else 'Export réel, import sur une nouvelle page et poursuite du parcours.'
 parts.append(f'<article><h2>{esc(s["caption"])}</h2><img src="data:image/png;base64,{base64.b64encode(raw).decode()}" alt="Capture native du DLC local"><p>{scope}</p><small>{esc(s["file"])}</small></article>')
parts.append('<article><h2>Références de comparaison</h2>')
for r in design['references']:parts.append(f'<p><a href="{esc(r["url"],quote=True)}" target="_blank" rel="noopener noreferrer">{esc(r["title"])}</a> — {esc(r["fact"])}</p>')
parts.append('</article></main></html>');(R/'RAPPORT_ILLUSTRE_V113.html').write_text(''.join(parts))
print(json.dumps({'screenshots':len(screens),'assertions':len(tests),'distinctLabels':len({t['name']for t in tests}),'routes':len(routes),'nativeBuild':False}))
