#!/usr/bin/env python3
"""Illustrated PDF from native Chromium captures; no independent picture rendering."""
from pathlib import Path
from xml.sax.saxutils import escape
import json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape,A4
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=Path(__file__).resolve().parents[1];Q=R/'qa-v107';b=json.loads((Q/'browser.json').read_text());u=json.loads((Q/'unit.json').read_text());i=json.loads((Q/'install.json').read_text());doc=json.loads((Q/'documentation.json').read_text());cx=json.loads((Q/'codex-browser.json').read_text());dh=json.loads((Q/'delivered.json').read_text())
for name,file in [('Body','DejaVuSans.ttf'),('Strong','DejaVuSans-Bold.ttf')]:
 p=Path('/usr/share/fonts/truetype/dejavu')/file
 if not p.is_file():raise FileNotFoundError('DejaVu Sans required locally: '+str(p))
 pdfmetrics.registerFont(TTFont(name,str(p)))
W,H=landscape(A4);M=34;CW=W-2*M;BG=HexColor('#0e1a13');INK=HexColor('#e3e8d6');MUTED=HexColor('#b7c3ad');LINE=HexColor('#52634a');GOLD=HexColor('#cdb786')
styles={k:ParagraphStyle(k,fontName='Body',fontSize=f,leading=l,textColor=MUTED if k in ['small','caption']else INK)for k,f,l in [('body',11,16),('caption',9.2,13),('small',9,12.7),('cell',9.5,13.5)]}
pdf=canvas.Canvas(str(R/'RAPPORT_ILLUSTRE_V107.pdf'),pagesize=(W,H),pageCompression=1);pdf.setTitle('ALIEN 3 — Fiorina 161 V107 — Manœuvres sous tension');pdf.setAuthor('Aliens: Tantalus Frontier / dossier de développement');total=3+len(b['screenshots']);pn=0

def para(text,x,top,width,style='body',maxh=None):
 p=Paragraph(text,styles[style]);_,height=p.wrap(width,999)
 if maxh and height>maxh:raise ValueError(f'Overflow {height}>{maxh}: {text[:60]}')
 p.drawOn(pdf,x,top-height);return height

def page(title,section):
 global pn;pn+=1;pdf.setFillColor(BG);pdf.rect(0,0,W,H,fill=1,stroke=0);pdf.setFillColor(GOLD);pdf.setFont('Strong',9);pdf.drawString(M,H-24,'ALIEN 3  /  FIORINA 161');pdf.setFont('Body',8);pdf.drawRightString(W-M,H-24,'V107  ·  '+section);pdf.setFillColor(INK);pdf.setFont('Strong',24)
 if pdfmetrics.stringWidth(title,'Strong',24)>CW:raise ValueError(title)
 pdf.drawString(M,H-57,title);pdf.setStrokeColor(LINE);pdf.line(M,29,W-M,29);pdf.setFillColor(MUTED);pdf.setFont('Body',7.5);pdf.drawString(M,16,'Banc local · modules partagés · silhouettes vectorielles · pas de campagne native complète certifiée');pdf.drawRightString(W-M,16,f'{pn:02d} / {total}')

def image(file,top=H-76):
 h=CW*720/1280;pdf.drawImage(str(R/file),M,top-h,width=CW,height=h,preserveAspectRatio=True,mask='auto');pdf.setStrokeColor(LINE);pdf.rect(M,top-h,CW,h,stroke=1,fill=0);return top-h

def table(rows,top,widths):
 t=Table([[Paragraph(escape(str(x)),styles['cell'])for x in row]for row in rows],colWidths=widths);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#2d3b26')),('BACKGROUND',(0,1),(-1,-1),HexColor('#182b1c')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,-1),.5,LINE)]));_,h=t.wrap(CW,999);t.drawOn(pdf,M,top-h);return top-h
page('Manœuvres sous tension','VERSION LOCALE CANDIDATE')
y=image('qa-v107/captures/13_amorcage.png');para('Maintenir la commande, lire sa progression et pouvoir interrompre le geste. Capture native après approche au clavier, devant le collecteur réel. Le petit poste de vanne est fixé à son appui ; l’indicateur n’est pas attaché au personnage.',M,y-10,CW,'caption',40);pdf.showPage()
page('Agir prend du temps','CHANGEMENTS ET CONTRAINTES')
y=table([['Manœuvre','Durée','Condition ou interruption'],['Relevé de service','1,10 seconde','Lecture à portée de l’établi. Bouger ou lâcher E interrompt.'],['Collecteur','1,80 seconde','Amorçage au bon étage, sur le bon plan et sans porte fermée interposée.'],['Moule','1,25 seconde','Morse et Dillon doivent tenir leurs postes pendant tout le geste.'],['Refroidissement','2,00 secondes','La coulée doit avoir eu lieu et Morse rester à son poste.'],['Coulée','Action immédiate','Le Runner doit réellement être dans le volume du moule ; pas de délai ajouté.']],H-82,[146,125,CW-271])
y-=22
para('L’option <b>Appuyer pour manœuvrer</b> conserve ces durées et ces contraintes. Un second appui ou un déplacement annule. La pause, le plan, les archives, la perte de focus et les dommages interrompent aussi l’action. Aucun geste partiel n’est conservé dans un fichier de reprise.',M,y,CW,'body',65);y-=78
para('La couche ajoute quatre modules et un raccord du moteur, sans réécrire les propriétaires V106. Elle vérifie les 34 sources antérieures. Les commandes npm des tests d’installation sont synthétiques : elles ne constituent pas une compilation du jeu principal.',M,y,CW,'small',52);y-=65
para(f'Codex hors jeu : <b>{doc["cards"]} fiches</b>, dont {doc["newCards"]} nouveaux contrats. Les 30 assemblages et 284 composants historiques restent présents ; un poste de vanne de quatre composants ancrés est ajouté. Les raccords et les sons ne constituent pas une simulation physique de fluides.',M,y,CW,'small',52);pdf.showPage()
page('Parcours et preuves','VALIDATION EXÉCUTÉE')
rows=[['Profil automatisé','Résultat','Santé','Attaques / contacts / évitées','Temps simulé']]
for r in b['routes']:
 s=r['result'];st=s['pursuit']['stats'];rows.append([r['profile'],'Terminé',s['hp'],f'{st["attacks"]} / {st["hits"]} / {st["misses"]}',f'{s["clock"]:.2f} s'])
y=table(rows,H-81,[185,85,60,220,CW-550]);y-=20
para('Clavier réel et horloge contrôlée à 60 Hz, sans injection de position ou d’étape dans les traversées. Le robot connaît le trajet ; ces temps ne sont pas des durées de campagne et ces profils ne sont pas des testeurs humains. L’échec et le dommage d’interruption sont des cas dirigés, séparés des parcours.',M,y,CW,'body',65);y-=76
para(f'<b>{u["cases"]} cas unitaires</b>, <b>{i["cases"]} scénarios d’installation</b>, <b>{b["controlsExecuted"]} assertions Chromium</b> en sept groupes ({b["uniqueControlNames"]} libellés distincts), {dh["tests"]} contrôles du HTML ordinaire et {cx["tests"]} contrôles du codex. Les suites V104, V105 et V106 ont été rejouées séparément. Ces scopes ne s’additionnent pas en certification de la campagne native.',M,y,CW,'small',65);y-=80
para('<b>Non revendiqué :</b> build complet Tantalus, adaptation intégrale du film, sprites définitifs, écoute sur matériel, essai humain, manette physique ou déploiement. Pendant les préparatifs du moule, le Runner reste dormant jusqu’à l’armement, selon la séquence existante.',M,y,CW,'small',44);pdf.showPage()
titles={'01_aaron.png':'La consigne d’Aaron','02_releve.png':'Lire le relevé à l’étage','03_retour_aaron.png':'Retour auprès d’Aaron','04_plan.png':'Le plan suspend la chasse','05_archives.png':'Consulter sans progresser','06_attente_postes.png':'Attendre les deux postes','06b_verrouillage.png':'Verrouiller le moule','07_postes_tenus.png':'Les postes sont tenus','08_attaque_annoncee.png':'Une attaque annoncée','09_coulee.png':'Saisir l’instant de la coulée','10_refroidissement.png':'Ouvrir le refroidissement','11_retour_morse.png':'Le rabattage est terminé','12_echec.png':'Échec et poste sûr','13_amorcage.png':'Amorcer le collecteur','14_plan_pendant_preparation.png':'Interrompre pour lire le plan','15_commande_appuyer.png':'Manœuvrer sans tenir la touche','16_interruption_blessure.png':'Une blessure interrompt le geste'}
for index,shot in enumerate(b['screenshots'],1):
 page(titles[Path(shot['file']).name],f'CAPTURE NATIVE {index:02d} / {len(b["screenshots"])}');y=image(shot['file']);scope='Cas dirigé, distinct des parcours continus.'if'directed'in shot['scope']else'Actions réelles au clavier dans le banc local.';para(escape(shot['caption'])+' '+scope+' Modules livrés, physique de base simplifiée.',M,y-10,CW,'caption',40);pdf.showPage()
assert pn==total;pdf.save();print(json.dumps({'ok':True,'pages':pn,'bytes':(R/'RAPPORT_ILLUSTRE_V107.pdf').stat().st_size}))
