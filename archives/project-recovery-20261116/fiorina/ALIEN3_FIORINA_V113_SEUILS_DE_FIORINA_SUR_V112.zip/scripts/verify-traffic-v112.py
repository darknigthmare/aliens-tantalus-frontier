#!/usr/bin/env python3
"""Real keyboard approaches, valves and NPC travel. Prepared tests are named separately."""
from browser_support_v112 import *
PHASE=sys.argv[1]if len(sys.argv)>1 else 'route'
def traffic(p):return state(p)['traffic']
def steam(p):return state(p)['steam']
def prisoner(p,name='dillon'):return next(a for a in state(p)['participants']if a['id']==name)
def approach(p):
 press(p,'KeyE');walk(p,3890,True);press(p,'KeyE');walk(p,4106,True)
 record('La vanne est atteinte après le signal et l’ouverture de la porte',state(p)['stage']==1 and abs(state(p)['x']-4106)<8)
 hold(p,'KeyV',84)
 record('Ouverture réelle avant la progression du groupe dans le jet',steam(p)['circuits'][2]['uses']==1)
 for _ in range(150):
  if traffic(p)['waiting'].get('dillon'):break
  tick(p,1)
 record('Dillon s’arrête réellement devant la partie chaude',traffic(p)['waiting'].get('dillon')=='foundry-purge' and prisoner(p)['x']+36<=4270-10,state(p))
 record('Attendre le jet ne signifie pas tenir le poste',prisoner(p)['nodeId']!='f161-piston-c-node' and prisoner(p)['order']=='move')
 return state(p)
def finish(p):
 walk(p,4362);hold(p,'ArrowUp',86);walk(p,4672);hold(p,'KeyE',110);record('Le collecteur exige toujours la manœuvre historique',state(p)['stage']==2)
 walk(p,4787,True);hold(p,'ArrowDown',86);walk(p,4902)
 for _ in range(150):
  if all(a['order']=='hold' for a in state(p)['participants']):break
  tick(p,4)
 hold(p,'KeyE',77);record('Les deux détenus ont atteint leur poste avant l’armement',state(p)['stage']==3 and all(a['order']=='hold'for a in state(p)['participants']),state(p))
 snap(p,'37_postes_apres_attente','Les détenus ont rejoint leurs postes par le graphe après l’arrêt devant la vapeur.')
 walk(p,4830)
 for _ in range(250):
  if state(p)['pursuit']['mode']=='windup':break
  tick(p,2)
 record('La chasse réactivée rejoint le moule sans injection',state(p)['pursuit']['mode']=='windup')
 walk(p,4918,True);p.keyboard.down('Space');tick(p,1);p.keyboard.up('Space');walk(p,5060,True);tick(p,20);press(p,'KeyE',15)
 record('La coulée capture le Runner réellement au piège',state(p)['stage']==4 and state(p)['pursuit']['mode']=='trapped')
 walk(p,4787,True);hold(p,'ArrowUp',86);walk(p,4672);hold(p,'KeyE',122)
 record('Le refroidissement reste ordonné après la coulée',state(p)['stage']==5 and not state(p)['runner']['alive'])
 walk(p,4362);hold(p,'ArrowDown',86);press(p,'KeyE');record('Retour final auprès de Morse après la fermeture et l’attente',state(p)['status']=='complete')
 snap(p,'38_retour_apres_fermeture','Fin du rabattage continu après purge, attente, ordre, fermeture et reprise du groupe.')
 routes.append({'profile':'rabattage-vanne-et-groupe','mode':'rabattage','setup':'UI start; keyboard travel, gate, valve, manual order, ladders and trap; no pose or stage injected', 'result':state(p)})
def download(p,name):
 p.evaluate('document.body.classList.remove("capture")')
 with p.expect_download()as dl:p.locator('#export-save').click()
 file=OUT/name;dl.value.save_as(file);p.evaluate('document.body.classList.add("capture")');p.locator('canvas').focus();return file
with sync_playwright()as pw:
 browser=pw.chromium.launch(executable_path=shutil.which('chromium')or'/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 if PHASE=='route':
  p=start(browser,mode='trap');approach(p);snap(p,'30_dillon_attend_le_jet','Dillon interrompt son déplacement avant le volume chaud ; sa commande n’est pas encore occupée.')
  x=prisoner(p)['x'];tick(p,12);record('Attente immobile et aucune téléportation vers la commande',prisoner(p)['x']==x)
  walk(p,4135);press(p,'KeyG');record('G transforme l’attente en consigne volontaire sans arrivée fictive',state(p)['senses']['holds'].get('dillon')==True)
  p.keyboard.down('KeyV');tick(p,28);record('La fermeture reste partielle avant 0,85 seconde',traffic(p)['closing']is not None and traffic(p)['stats']['closed']==0)
  snap(p,'31_refermer_en_cours','Maintien de V à la commande, pendant une fermeture partielle. Aucun remboursement de pression.')
  tick(p,23);p.keyboard.up('KeyV');record('La fermeture complète conserve une courte chaleur résiduelle',traffic(p)['stats']['closed']==1 and steam(p)['circuits'][2]['remaining']>1.2 and steam(p)['circuits'][2]['pressure']==30)
  snap(p,'32_jet_referme','Jet refermé par le joueur : la vapeur se dissipe sans disparition instantanée.')
  x=prisoner(p)['x'];tick(p,100);record('La dissipation n’annule pas l’ordre d’attendre du joueur',prisoner(p)['x']==x and state(p)['senses']['holds'].get('dillon')==True)
  snap(p,'33_attente_volontaire','La conduite n’est plus chaude, mais Dillon conserve l’ordre volontaire d’attendre.')
  press(p,'KeyG');tick(p,18);record('G le fait repartir depuis la position conservée',prisoner(p)['x']>x and state(p)['senses']['holds'].get('dillon')==False)
  snap(p,'34_reprise_depuis_appui','Dillon reprend sa route physique après la nouvelle consigne.')
  finish(p);p.close()
 if PHASE=='gesture':
  p=start(browser,mode='trap');approach(p);p.keyboard.down('KeyV');tick(p,20);p.keyboard.up('KeyV');tick(p,1)
  record('Relâcher V interrompt la fermeture sans rendre de pression',traffic(p)['closing']is None and traffic(p)['stats']['closed']==0 and steam(p)['circuits'][2]['pressure']==30)
  p.keyboard.down('KeyV');tick(p,4);press(p,'KeyM');p.keyboard.up('KeyV');record('Le plan annule le geste incomplet',traffic(p)['closing']is None);before=state(p);tick(p,60);record('Le plan suspend le jet et les déplacements en attente',state(p)==before);press(p,'Escape')
  p.evaluate('document.body.classList.remove("capture")');p.locator('#interaction').select_option('toggle');p.evaluate('document.body.classList.add("capture")');press(p,'KeyV',51)
  record('Le mode Appuyer referme la même vanne avec la même durée',traffic(p)['stats']['closed']==1)
  snap(p,'36_fermeture_accessible','Fermeture en mode Appuyer après annulation d’un maintien incomplet.')
  tick(p,820);p.evaluate('document.body.classList.remove("capture");document.querySelector(".touchpad").style.display="flex"');btn=p.locator('#purge');btn.scroll_into_view_if_needed();bb=btn.bounding_box();p.mouse.click(bb['x']+bb['width']/2,bb['y']+bb['height']/2);tick(p,85);record('Le bouton pointeur ouvre une nouvelle fois après recharge réelle',steam(p)['circuits'][2]['uses']==2)
  p.mouse.click(bb['x']+bb['width']/2,bb['y']+bb['height']/2);tick(p,51);record('Le même bouton pointe la fermeture plutôt que de créer un jet',traffic(p)['stats']['closed']==2 and steam(p)['circuits'][2]['uses']==2)
  pure=p.evaluate('JSON.stringify(fiorinaBench.exportState())');p.evaluate('()=>{for(let i=0;i<20;i++)fiorinaBench.render()}');record('Vingt dessins ne modifient ni pression ni trajectoire ni registre',p.evaluate('JSON.stringify(fiorinaBench.exportState())')==pure)
  p.close()
 record('Aucune erreur JavaScript V112 dans cette séquence',not errors,errors);record('Aucune requête réseau externe depuis le banc',not external,external);version=browser.version;browser.close()
result={'ok':True,'scope':'Native Chromium screenshots; shared shipped modules in simplified host. UI setup and keyboard route; file transfers are real downloads/imports. Not the full native film campaign.','browser':version,'controls':len(tests),'results':tests,'routes':routes,'screenshots':captures,'errors':errors,'externalRequests':external,'sourceHashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (ROOT/'src').glob('*v112.js')}}
(OUT/('browser-traffic-'+PHASE+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'controls':len(tests),'captures':len(captures)}))
