#!/usr/bin/env python3
"""Generate the outside-game codex, scope and illustrated HTML from executable contracts and native capture evidence."""
from pathlib import Path
from html import escape as esc
import json,re,subprocess,base64,hashlib
R=Path(__file__).resolve().parents[1];Q=R/'qa-v110';D=R/'docs';D.mkdir(exist_ok=True)
subprocess.run(['node',str(R/'scripts/export-design-v110.mjs')],check=True)
src=json.loads((Q/'design-source.json').read_text());u=json.loads((Q/'unit.json').read_text());ins=json.loads((Q/'install.json').read_text());b=json.loads((Q/'browser.json').read_text());ordinary=json.loads((Q/'delivered.json').read_text());rules=src['rules'];steam=src['steamRules']
old=(R/'ALIEN3_CODEX_LEVEL_DESIGN_V109.html').read_text();start=old.index('const cards=')+len('const cards=');cards,end=json.JSONDecoder().raw_decode(old[start:]);assert len(cards)==575
new=[]
def add(kind,id,title,text,details):new.append({'type':kind,'id':id,'title':title,'text':text,'details':details})
for rule in src['contracts']:add('Règles V110',rule['id'],rule['title'],rule['text'],[['Contrôle','qa-v110/unit.json','Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.'],['Parcours','encounter-rabattage','Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.']])
for site in src['geometry']['sites']:
 sid=site['id'];add('Fermetures locales','close110-'+sid,'Refermer · '+site['label'],f'La fermeture exige {rules["closeSeconds"]} seconde à ce même volant. Elle conserve au plus {rules["residualHot"]} seconde de chaleur résiduelle puis la traîne de {steam["tailSeconds"]} seconde. Les {steam["cost"]} unités dépensées à l’ouverture ne sont jamais remboursées.',[['Conduite propriétaire','purge109-'+sid,'Les coordonnées et le circuit de V109 restent les seules références ; aucune nouvelle machine ni réserve.'],['Appui',site['nodeId'],f'Support {site["supportId"]}, pied Y {site["foot"]}, profondeur {site["depth"]}.'],['Commande','input110-close',f'Volant ({site["controlX"]}, {site["controlY"]}), portée {steam["range"]}, hauteur ±{steam["height"]}, profondeur ±{steam["depth"]}. Même test à chaque pas de temps.'],['Jet partagé','field109-'+sid,f'Origine ({site["outletX"]}, {site["outletY"]}) ; portée maximale {steam["reach"]}. Fermé ou non, les portes coupent le même volume pour le rendu et les décisions.'],['Recharge','steamstate109-refill','La réserve recommence à monter seulement après disparition totale. Fermer peut avancer le début de recharge, pas rendre du stock immédiatement.']])
for who,node,goal in [('morse','f161-bishop','f161-lead-primer'),('dillon','f161-command-post-node','f161-piston-c-node')]:
 name=who.capitalize();add('Passages du groupe','crew110-'+who,name+' face à une purge','Chaque prochain déplacement est calculé avec le moteur de navigation V105 sur une copie de pose. Les seuls champs de mouvement sont reportés si le pas reste sûr. L’identité, le but, la santé et l’ordre du joueur ne sont pas remplacés.',[['Participant','participant-'+who,'Un seul corps conserve son segment courant et sa destination. Aucun téléport, nouvelle vie ou arrivée anticipée.'],['Départ',node,'Le point initial appartient au parcours de rabattage existant.'],['Poste',goal,'Le propriétaire du piège vérifie encore présence physique, fin de segment et bonne commande.'],['Obstacle','close110-foundry-purge',f'Marge {rules["margin"]} unités plus demi-largeur du corps ; même étage, même profondeur, champ chaud réellement tronqué par les portes.'],['Ordres','v110-crew-order','G reste prioritaire. Un ordre volontaire survit à la fin de vapeur ; G doit être redonné pour repartir.'],['Limite','v110-scope','Cette passe ne crée ni blessures aux détenus, ni panique complète, ni changement automatique de destination.']])
for id,title,text,detail in [('moving','En route','Le personnage suit son itinéraire et produit des pas seulement sur la distance réellement parcourue.','Le rendu n’avance ni le chemin, ni les compteurs.'),('hot-wait','Attente devant le jet','Le pas est refusé avant d’entrer dans la partie chaude ; la pose courante et le segment restent valides.','Le temps continue hors menus. La vapeur peut se dissiper d’elle-même ou être refermée par le joueur.'),('order-wait','Attente sur ordre','Une consigne d’attente est distincte du danger de la conduite.','Même si le jet a cessé, l’ordre volontaire reste vrai et la commande du piège n’est pas considérée comme occupée.'),('station','Poste tenu','Seule l’arrivée réelle au bon point termine le déplacement.','L’armement du moule conserve les conditions et les étapes de V105/V107.')]:
 add('États de passage','crewstate110-'+id,title,text,[['Contrat','v110-crew-resume',detail],['Groupe','crew110-dillon','Même mécanisme pour Morse et Dillon ; Aaron n’est pas introduit dans la fonderie.']])
for id,title,text in [('current','Registre courant V110','Le registre ajoute uniquement les fermetures par vanne et les mesures bornées du passage du groupe. Pression et jet restent ceux de V109. Ni fermeture partielle ni ancien indicateur de blocage ne sont importés.'),('checkpoint','Dernier poste sûr indépendant','Le poste sûr possède ses propres compteurs, ses réserves et ses ordres. Il ne peut pas être stocké pendant une fermeture active.'),('migration','Migration V105 à V109','Une ancienne partie valide reçoit zéro fermeture supplémentaire. Son poste sûr est migré indépendamment de son état courant ; aucun usage ancien n’est inventé.'),('validation','Rejet des contradictions','Une fermeture doit appartenir à un circuit utilisé : pas plus de fermetures que d’ouvertures. Les doublons, réserves falsifiées, statistiques incohérentes et fichiers dépassant 1 Mio sont refusés avant application.')]:
 add('Reprises V110','save110-'+id,title,text,[['Base','save109-current','La validation antérieure des poses, du piège, des boulons et des jets reste active.'],['Sécurité','v110-save-ledger','Empreinte de corruption et invariants de domaine, pas authentification anti-triche.'],['Pause','v110-save-recompute','La reprise est en pause. Au premier déplacement, l’attente thermique est recalculée, sans rejouer le geste ou le son de fermeture.']])
add('Commandes V110','input110-close','V · Ouvrir ou refermer','La touche V choisit la fermeture lorsque la conduite libère encore de la vapeur chaude. Sinon, elle conserve l’ouverture de V109 ou attend la fin du nuage. Aucun nouveau raccourci supplémentaire.',[['Maintenir','v110-valve-interrupt','Relâcher, bouger, sauter, prendre une échelle, subir des dégâts, ouvrir un menu ou perdre le focus annule le geste.'],['Appuyer','v110-valve-toggle','Un seul appui démarre le même travail ; un deuxième l’annule. Le bouton pointeur utilise les mêmes méthodes.'],['Concurrence','v110-valve-order','E, G, I, F et les boulons sont temporairement refusés pendant le geste. L’interface ne propose pas un ordre devenu indisponible.'],['Sortie','v110-valve-tail','Si la vapeur devient tiède avant la fin du travail, aucune fausse fermeture n’est comptée.']])
cards+=new;assert len({c['id']for c in cards})==len(cards)
# Annotate changed semantics on the older, still linkable pages.
for c in cards:
 if c['id']=='input109-purge':c['text']+=' À partir de V110, la même touche peut aussi refermer une vanne encore chaude ; consulter input110-close.';c['details'].append(['Fermeture','input110-close','Même emplacement, consommation d’ouverture conservée.'])
 if c['id']=='steamstate109-jet':c['details'].append(['Groupe','v110-crew-margin','À partir de V110, les déplacements des détenus peuvent attendre devant ce volume chaud. Aucun nouveau dégât ne leur est appliqué.'])
out=old[:start]+json.dumps(cards,ensure_ascii=False).replace('</script','<\\/script')+old[start+end:]
out=out.replace('DOCUMENT DE CONCEPTION V109','DOCUMENT DE CONCEPTION V110').replace('<h1>Le souffle des conduites</h1>','<h1>Garder le passage</h1>').replace('575 fiches issues',f'{len(cards)} fiches issues')
out=out.replace('</select></div>',''.join('<option>'+esc(k)+'</option>'for k in dict.fromkeys(c['type']for c in new))+'</select></div>',1)
out=re.sub(r'<div class="scope">.*?</div>','<div class="scope">Codex de conception hors jeu. V110 relie les purges au passage des détenus et permet de refermer les vannes. Les fichiers et captures valident le banc local à contrôleur simplifié ; aucun build complet du moteur principal ou parcours intégral du film n’est certifié.</div>',out,count=1,flags=re.S)
(R/'ALIEN3_CODEX_LEVEL_DESIGN_V110.html').write_text(out)
(Q/'codex-source.json').write_text(json.dumps(cards,ensure_ascii=False,indent=2)+'\n')
md=['# ALIEN 3 — FIORINA 161 · CODEX DE LEVEL DESIGN V110','','## Portée et sources','Ce document de conception est généré depuis les contrats et données exécutables livrés. Les captures sont natives Chromium ; le banc local n’est pas le moteur principal complet. Les mesures sont en unités de jeu et secondes simulées, pas un relevé des décors du film.','',f'{len(cards)} fiches, dont {len(new)} nouveaux contrats. La scène conserve 20 sections descriptives, 30 assemblages, 284 composants détaillés, 72 points et 119 connexions ; les petits groupes des commandes de versions précédentes sont identifiés à part. Aucun nouvel étage ni route n’est annoncé.','','## V110 — invariants de passage','- Une seule réserve et un seul jet, toujours détenus par V109.','- Une fermeture de 0,85 s, au plus 0,30 s de chaleur résiduelle et 1,20 s de dissipation.','- Aucun remboursement de pression ou arrêt du temps hors menu.','- Un pas de navigation vérifié avant mouvement ; aucune arrivée de détenu forcée.','- G reste une consigne volontaire indépendante de la sécurité thermique.','- La reprise est en pause et élimine les commandes transitoires.','','## Registre des fiches','']
for c in cards:
 md+=[f'### {c["title"]}',f'`{c["id"]}` · {c["type"]}','',c['text'],'']
 for k,ref,text in c.get('details',[]):md += [f'**{k}** — `{ref}` : {text}','']
(D/'ALIEN3_LEVEL_DESIGN_CODEX_V110.md').write_text('\n'.join(md))
(Q/'documentation.json').write_text(json.dumps({'cards':len(cards),'newCards':len(new),'types':dict(__import__('collections').Counter(c['type']for c in new)),'sourceHashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (R/'src').glob('*v110.js')}},ensure_ascii=False,indent=2)+'\n')
style='''body{background:#0c1411;color:#d5decb;font:16px/1.65 system-ui,sans-serif;margin:0}main{max-width:1250px;margin:auto;padding:32px}h1{font-size:36px;font-weight:500}h2{font-size:24px;color:#c8d2b6}article{margin:28px 0 48px;padding:20px;background:#15251b;border:1px solid #45563e;border-radius:9px}img{display:block;width:100%;height:auto;margin:14px 0;border:1px solid #657157}.scope{border-left:3px solid #b89962;padding:17px 22px;background:#272d20;color:#d8d1b6}p{max-width:1150px}small{color:#a7b699}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:9px 12px;border-bottom:1px solid #465238}code{color:#c9c7a3}@media(max-width:600px){main{padding:18px}h1{font-size:26px}article{padding:12px}}'''
sections=[]
for s in b['screenshots']:
 file=R/s['file'];assert hashlib.sha256(file.read_bytes()).hexdigest()==s['sha256']
 caption=s['caption'];scope='Test dirigé de contact et d’échec, avec positions préparées.' if s['scope'].startswith('directed') else 'Parcours au clavier ou essai de commande après approche physique ; aucun déplacement injecté.'
 sections.append(f'<article><h2>{esc(caption)}</h2><img alt="Capture native du banc local" src="data:image/png;base64,{base64.b64encode(file.read_bytes()).decode()}"><small>{esc(scope)} Rendu partagé, contrôleur simplifié, silhouettes provisoires.</small></article>')
rows=''.join(f'<tr><td>{esc(r[0])}</td><td>{esc(r[1])}</td><td>{esc(r[2])}</td></tr>'for r in [('Contrats V110',f'{u["cases"]} cas passés','Base instrumentée'),('Installation',f'{ins["cases"]} scénarios passés','npm synthétique sur fixtures'),('Chromium',f'{b["controlsExecuted"]} assertions, {b["uniqueControlNames"]} noms distincts','Dix groupes, captures natives'),('HTML distribué',f'{ordinary["tests"]} contrôles passés','Sans API de test, horloge normale')])
report=f'''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Alien 3 V110 — Garder le passage</title><style>{style}</style><main><h1>Alien 3 — Garder le passage</h1><div class="scope">Rapport V110 : quatre modules sur V109, captures natives du banc local. Il ne s’agit pas du rendu complet de Tantalus avec ses sprites définitifs et toute sa campagne. Aucun build complet, push ou déploiement n’a été effectué.</div><article><h2>Fermer une vanne, garder le groupe en route</h2><p>V referme le jet chaud en 0,85 seconde sans rendre la pression consommée. Le nuage garde une courte chaleur résiduelle avant de se dissiper. Morse et Dillon vérifient leur prochain pas et peuvent attendre devant le volume chaud. Leur destination et leurs ordres restent conservés. G peut imposer une attente qui ne s’annule pas à la fin de vapeur.</p><p>La purge ne blesse pas les détenus, ne termine pas un piège et ne désactive pas le Runner. Les trois circuits restent abstraits et indépendants ; ce n’est pas une simulation de pression industrielle complète.</p></article><article><h2>Résultats exécutés</h2><table><tr><th>Contrôle</th><th>Résultat</th><th>Portée</th></tr>{rows}</table></article>{''.join(sections)}</main></html>'''
(R/'RAPPORT_ILLUSTRE_V110.html').write_text(report)
route_rows=['| Profil | État | Santé | Contacts | Purges | Fermetures | Attentes thermiques | Temps simulé |','|---|---|---:|---:|---:|---:|---:|---:|']
for r in b['routes']:
 s=r['result'];route_rows.append(f'| {r["profile"]} | {s["status"]} | {s["hp"]} | {s["pursuit"]["stats"]["hits"]} | {s["steam"]["stats"]["opened"]} | {s["traffic"]["stats"]["closed"]} | {s["traffic"]["stats"]["waitingStarts"]} | {s["clock"]:.2f} s |')
qa=f'''# QA — Alien 3 V110

## Résultats exécutés
- {u['cases']} cas unitaires V110 sur une base instrumentée.
- {ins['cases']} scénarios d’installation à npm synthétique.
- {b['controlsExecuted']} assertions Chromium dans {len(b['phases'])} groupes ; {b['uniqueControlNames']} libellés distincts.
- {ordinary['tests']} contrôles du fichier distribué sans API de test.
- {len(b['screenshots'])} captures natives Chromium.

## Parcours au clavier
{chr(10).join(route_rows)}
Les robots connaissent les itinéraires. Les temps ne sont pas des durées de campagne humaine. Les parcours utilisent des gestionnaires clavier et une horloge contrôlée ; les arrivées, poses et étapes ne sont pas injectées. Les reprises utilisent de vrais fichiers téléchargés puis importés dans une nouvelle page.

## Corrections observées pendant cette passe
- Le script de parcours visait d’abord la commande de coulée au lieu du moule pour l’armement : le refus était correct. Le parcours de test a été corrigé pour rejoindre la vraie commande, sans modifier les objectifs.
- Une aide G restait affichée pendant une fermeture alors que cette action était refusée. La consigne indique maintenant que le déplacement interrompt la manœuvre.
- Une référence V109 subsistait dans un script navigateur copié. Tous les scripts V110 passent par un support commun et vérifient le schéma 110 du fichier réellement exécuté avant le parcours.

## Preuves ciblées
Fermeture au même poste et au même coût ; chaleur résiduelle ; pas de recharge avant fin du nuage ; arrêt préventif des détenus ; conservation d’un ordre G ; reprise depuis la pose réelle ; parité sans vapeur avec V109 ; fichier invalide refusé malgré empreinte recalculée ; contrôles de profondeur et d’étage ; bouton pointeur ; pureté du dessin.

## Régressions séparées
V109 : 60 cas et 19 installations. V108 : 59 cas et 19 installations. Les anciennes suites restent indépendantes de la qualification du moteur complet. Les parcours de traque et de rabattage hérités ont également été rejoués dans la composition V110.

## Limites
Le blocage est une attente prudente sur le trajet courant : pas de panique complète, pas de nouveau planificateur de détour, pas de blessure aux détenus. Un personnage déjà dans le volume peut en sortir si son pas réduit sa pénétration ; aucun téléport ni poussée ne sont appliqués.
Le Runner reste dormant pendant la préparation antérieure à l’armement du rabattage. La traque d’Aaron a aussi utilisé une fermeture alors que le prédateur restait actif.
Banc avec contrôleur simplifié et art vectoriel provisoire. Ni campagne native complète, sessions humaines, Safari, manettes matérielles ni écoute physique ne sont certifiés. Aucun nouveau build natif, push, déploiement ou refus de droits n’est prétendu ce tour.

## Installation
Quatre modules nouveaux et un raccord moteur sur 47 sources V109 exactes, aucune source historique modifiée. Staging, validation des mêmes octets, garde contre les changements concurrents et restauration externe. Les npm des fixtures ne sont pas le build natif.
'''
(R/'RAPPORT_QA_V110.md').write_text(qa)
(D/'PORTEE_V110.md').write_text('''# Portée V110

| Sujet | Livré et vérifié | Non revendiqué |
|---|---|---|
| Fermeture | Même volant, geste de 0,85 s, chaleur résiduelle, aucune restitution de réserve | Nouvelle simulation de pression ou suppression instantanée de nuage |
| Groupe | Prochain pas vérifié, attente puis reprise, ordres conservés | Nouveau moteur de panique, détour complet ou blessures des détenus |
| Piège | Arrivées réelles et séquence existante conservées | Reconstitution intégrale de la mort de Dillon ou du final du film |
| Fichiers | Reprise en pause, migration V105–V109, registre borné, poste sûr séparé | Autosave disque, cloud ou signature anti-triche |
| Rendu | Modules livrés, canvas natif et capture Chromium | Assets photoréalistes, campagne complète avec sprites finaux |
| Intégration | 47 sources vérifiées, staging et restauration | Build natif complet, push ou déploiement |
''')
(R/'README.md').write_text(f'''# ALIEN 3 — FIORINA 161 V110 · Garder le passage

Correctif incrémental pour une base V109 compatible. Il contient les sources antérieures nécessaires au banc et aux tests, pas le jeu Tantalus complet ni tous ses médias. L’installateur ne convertit pas automatiquement une base plus ancienne en V109.

## Jouer
Ouvrir `FIORINA_V110_JOUER.html`. Aucune requête externe ni API QA n’est active dans ce fichier ordinaire. Les sons sont désactivés par défaut. Choisir la traque ou le dernier rabattage. Le menu d’inspection extérieur au canvas sert à tester les lieux ; il ne représente pas un parcours de campagne.

V ouvre une purge disponible ou referme son jet chaud. Fermer demande 0,85 s, garde une courte dissipation et ne rembourse jamais la pression. Morse et Dillon peuvent attendre devant un jet, sans perdre leur destination. G conserve une attente volontaire indépendante de la vapeur.
Flèches / Q-D : mouvement ; Haut/Bas : échelle ou profondeur ; Espace : saut ; E : action ; Maj : courir ; Ctrl : se baisser ; F : bruit ; T : boulon ; Y : récupérer ; G : attendre/repartir ; I : lumière ; M : plan ; C : archives ; Échap : pause ; R : dernier poste sûr. Le mode Appuyer conserve les durées mais dispense du maintien de E/V.

## Installation dans une copie V109
Extraire ce paquet hors du projet cible. Les 47 modules de `sources-v109-verified.json` doivent correspondre. Quatre nouveaux modules et le lien moteur sont préparés dans une copie. Les commandes npm check et build de la copie doivent réussir avant report des mêmes octets. Les fixtures utilisent des npm synthétiques, pas Tantalus.
```sh
node scripts/install-v110.mjs /chemin/vers/projet-V109 --dry-run
node scripts/install-v110.mjs /chemin/vers/projet-V109
node scripts/install-v110.mjs --restore /chemin/vers/receipt.json
```
`--skip-project-check` saute explicitement le check/build natif. Les sources différentes, modifications concurrentes et chemins symboliques gérés sont refusés. Le reçu de restauration est extérieur au dossier de distribution.

## Fichiers de reprise
Export/import explicites jusqu’à 1 Mio. Migration V105 à V109. Une fermeture inachevée, un ancien indicateur d’attente et une alerte différée ne sont pas restaurés. La reprise est en pause ; l’attente devant le jet est recalculée à partir des corps et de la vapeur. Le poste sûr conserve son propre état. Pas de cloud ni d’autosave disque.

## Rapports
`ALIEN3_CODEX_LEVEL_DESIGN_V110.html` : {len(cards)} fiches hors jeu, recherche et références.
`docs/ALIEN3_LEVEL_DESIGN_CODEX_V110.md` : version détaillée.
`RAPPORT_ILLUSTRE_V110.html` / `.pdf` : captures natives et portée.
`RAPPORT_QA_V110.md`, `docs/PORTEE_V110.md`, `qa-v110/` : preuves.

## Reproduire
```sh
node scripts/test-v110.mjs
node scripts/test-install-v110.mjs
python scripts/build-preview-v110.py
# profiles, resume, trap, failure, audio, layout :
python scripts/verify-browser-v110.py profiles
# route, resume, gesture, hunt :
python scripts/verify-traffic-v110.py route
python scripts/aggregate-qa-v110.py
python scripts/verify-delivered-v110.py
python scripts/build-docs-v110.py
python scripts/verify-codex-v110.py
python scripts/build-pdf-v110.py
```
Python Playwright, Chromium et ReportLab sont nécessaires aux outils, pas à l’ouverture du HTML. Aucun fichier de police distribué. Le moteur principal, les parcours intégraux du film, les appareils physiques et les sprites définitifs restent à qualifier.
''')
print(json.dumps({'cards':len(cards),'newCards':len(new),'captures':len(b['screenshots'])}))
