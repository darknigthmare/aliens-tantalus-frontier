#!/usr/bin/env python3
from pathlib import Path
from html import escape as esc
import json,hashlib,base64,subprocess
R=Path(__file__).resolve().parents[1];Q=R/'qa-v112';D=R/'docs'
subprocess.run(['python',str(R/'scripts/build-codex-v112.py')],check=True)
load=lambda name:json.loads((Q/name).read_text())
u,ins,b,ordinary,cx,doc=(load(n)for n in ['unit.json','install.json','browser.json','delivered.json','codex-browser.json','documentation.json'])
assert all(x['ok']for x in [u,ins,b,ordinary,cx])
source=load('design-source.json');lines=['| Profil | État | Santé | Contacts | Attentes de circulation | Reprises | Pas à allure réduite | Temps simulé |','|---|---|---:|---:|---:|---:|---:|---:|']
for route in b['routes']:
 s=route['result'];st=s['spacing']['stats'];lines.append(f'| {route["profile"]} | {s["status"]} | {s["hp"]} | {s["pursuit"]["stats"]["hits"]} | {st["waits"]} | {st["resumes"]} | {st["limitedSteps"]} | {s["clock"]:.2f} s |')
qa=f'''# QA — Alien 3 V112 · Laisser passer

## Exécution réelle
- {u['cases']} cas unitaires sur base instrumentée et vrai graphe.
- {ins['cases']} scénarios d’installation à npm synthétique.
- {b['controlsExecuted']} assertions Chromium, {b['uniqueControlNames']} libellés distincts, {len(b['phases'])} groupes.
- {ordinary['tests']} contrôles du HTML distribué sans API de test.
- {cx['tests']} contrôles du codex interactif.
- {len(b['screenshots'])} captures natives issues des modules livrés.

## Parcours au clavier
{chr(10).join(lines)}

Les neuf parcours listés sont terminés. Le dernier inclut l’export de la file, l’import sur une nouvelle page, la reprise du groupe et toute la fin du rabattage, pas seulement l’arrivée des détenus.
Les robots connaissent les itinéraires. Les temps simulés ne sont pas des durées de campagne humaine. Les traversées utilisent les gestionnaires clavier ; les positions, étapes et arrivées ne sont pas injectées pendant les trajets. L’import reste en pause et aucune commande suspendue n’est rejouée.

## Problème reproduit puis corrigé
Un cas instrumenté de 600 pas a retenu Dillon avec l’ordre G pendant que Morse le rejoignait : {source['previous']['overlapFrames']} pas de rectangles corporels superposés en V111, {source['current']['overlapFrames']} en V112. Cette comparaison est dirigée, pas une traversée de campagne.
Le premier correctif stoppait trop souvent le suivant derrière un meneur plus lent. Il recalcule maintenant un budget plus court depuis la même pose initiale, sans reporter deux mouvements. Le parcours au clavier vérifie une reprise régulière et une marge maintenue.

## Garanties ciblées
- Largeur et hauteur des corps, même étage et profondeur, balayage du prochain pas.
- Entrée sur une échelle ou un élévateur occupé différée ; contrat isolé, pas de scénario navigateur de croisement spécifique revendiqué.
- L’ordre G reste prioritaire ; l’attente n’attribue jamais un poste ni une arrivée.
- Aucun faux pas sonore pour une pose immobile ; l’allure réduite compte sa distance réelle.
- Cache de file absent de la sauvegarde ; la pause importée ne fait pas avancer le groupe.
- Validation du registre : reprises ≤ attentes ≤ pas bloqués, durée d’attente compatible avec les durées des pas.
- Les files recalculées après import peuvent constituer un nouvel épisode d’attente dans le registre. La pose et les ordres ne sont pas réécrits pour éviter cette comptabilisation.
- Vingt dessins successifs ne modifient pas le fichier exporté.
- Le fichier ordinaire, à horloge requestAnimationFrame et sans API QA, démontre lui aussi l’arrêt derrière Dillon, l’absence de mouvement pendant son attente et le départ avec G.

## Limites
Circulation locale entre les détenus mobiles, pas un solveur multi-agent global. Deux acteurs face à face sans place de dégagement attendent ; aucune poussée, esquive latérale inventée ni téléportation n’est appliquée. Ripley et le Runner ne deviennent pas des murs de navigation pour le groupe.
Le Runner reste dormant pendant les préparatifs antérieurs à l’armement, conformément à la séquence héritée. Son comportement n’est pas modifié par V112.
Banc avec physique simplifiée et personnages vectoriels provisoires. Pas de campagne native entière, essai humain, appareil mobile physique, Safari, manette ou écoute matérielle certifiés. Aucun build natif, push, déploiement ni nouvelle affirmation de refus de droits GitHub.

## Installation
Quatre modules nouveaux et un raccord moteur sur 55 sources V111 vérifiées, sans modification des sources historiques. Copie temporaire, contrôle des mêmes octets, détection des modifications concurrentes, reçu de restauration externe. Les npm synthétiques des fixtures ne valident pas le build de Tantalus.

## Régressions séparées
V111 : 61 cas unitaires et 19 installations. V110 : 65 cas et 19 installations. Les anciennes suites restent indépendantes de la qualification native. Leurs trajets de traque, vapeur et détour ont aussi été rejoués dans la composition V112.
'''
(R/'RAPPORT_QA_V112.md').write_text(qa)
(D/'PORTEE_V112.md').write_text('''# Portée V112

| Sujet | Livré et vérifié | Non revendiqué |
|---|---|---|
| Corps du groupe | Marge, pas balayé, attente, allure réduite, reprise physique | Collision rigide globale, poussée ou téléportation |
| Verticalité | Nouvel entrant refusé sur une liaison déjà occupée, essais unitaires | Nouveau parcours navigateur de croisement vertical |
| Ordres et missions | Même G, même destination, arrivée réelle nécessaire | Nouvelle étape historique, nouveau montage du film |
| Obstacles | V111 conserve portes, vapeur et itinéraires | Nouveau raccourci, machine ou conduit humain |
| Fichiers | Registre validé, queue transitoire recalculée, dernier poste sûr distinct | Réservation périmée restaurée, autosave disque, cloud ou signature anti-triche |
| Banc | Parcours continu et fin complète après reprise par fichier | Campagne native entière ou test humain |
| Intégration | 55 sources vérifiées, staging, restauration externe | Build natif complet, push et déploiement |
''')
(R/'README.md').write_text(f'''# ALIEN 3 — FIORINA 161 V112 · Laisser passer

Correctif incrémental sur une base V111 exacte. Ce paquet inclut l’aperçu autonome, les dépendances source utiles, les outils, le codex et les preuves. Il n’est pas le jeu Tantalus complet et n’inclut pas ses gros assets ni tout son moteur.

## Accès rapide
- `FIORINA_V112_JOUER.html` : aperçu jouable autonome, aucune requête externe.
- `ALIEN3_CODEX_LEVEL_DESIGN_V112.html` : codex hors jeu, {doc['cards']} fiches, dont {doc['newCards']} contrats nouveaux.
- `docs/ALIEN3_LEVEL_DESIGN_CODEX_V112.md` : contenu détaillé.
- `RAPPORT_ILLUSTRE_V112.html` et `.pdf` : captures natives, portée précisée.
- `RAPPORT_QA_V112.md` : résultats, cas dirigés et limites.

## Commandes inchangées
Flèches : marche / échelle / profondeur ; Espace : saut ; E : interaction et manœuvre ; I : lampe ; F : bruit métallique ; T/Y : lancer/récupérer un boulon ; V : ouvrir/refermer une purge ; G : demander d’attendre/repartir ; M : plan ; C : archives ; R : dernier poste sûr ; Échap : pause.
V112 n’ajoute aucune touche. Pour constater la file : lancer le rabattage, donner le signal puis demander à Dillon d’attendre ; laisser Morse le rejoindre par le passage ouvert. G redonne ensuite le départ à Dillon. La couche ne facilite pas l’armement : les deux détenus doivent toujours rejoindre leur commande réelle.

## Installation dans une copie du projet
Node.js 20 ou ultérieur. Extraire ce correctif dans un dossier distinct de la copie V111 du jeu.
```sh
node scripts/install-v112.mjs /chemin/vers/projet --dry-run
node scripts/install-v112.mjs /chemin/vers/projet
```
Les 55 sources V111 sont contrôlées avant préparation de quatre modules nouveaux et du raccord moteur. Les scripts du projet `npm run check` et `npm run build` sont lancés dans la copie temporaire. Les mêmes octets sont reportés seulement si les sources et les chemins gérés n’ont pas changé. `--skip-project-check` signale explicitement l’omission de ces commandes.
Les tests de l’installateur emploient des fixtures à npm synthétique : ils ne constituent pas un build du jeu principal.
La restauration utilise le reçu placé hors de la distribution :
```sh
node scripts/install-v112.mjs --restore /chemin/vers/receipt.json
```
Aucune source V111 n’est éditée. Une base différente nécessite une fusion explicite : ne pas contourner la vérification en recopiant arbitrairement les empreintes.

## Rejouer les preuves
```sh
node scripts/test-v112.mjs
node scripts/test-install-v112.mjs
python scripts/build-preview-v112.py
python scripts/verify-spacing-v112.py route
python scripts/verify-spacing-v112.py resume
python scripts/verify-browser-v112.py trap
python scripts/verify-routes-v112.py detour
python scripts/verify-delivered-v112.py
python scripts/build-codex-v112.py
python scripts/verify-codex-v112.py
```
`run-browser-suite-v112.py` orchestre les dix groupes contrôlés. Les scripts de capture nécessitent Python Playwright et Chromium locaux. Le fichier distribué ordinaire n’expose pas d’API de test ; la variante instrumentée ne s’active que lorsque le banc est explicitement préparé par le test.
Pour reconstruire les documents : `aggregate-qa-v112.py`, `build-docs-v112.py`, puis `build-pdf-v112.py`. Pour sceller l’archive : `package-v112.py`.

## Portée
Les décisions de circulation sont locales. Un face-à-face sans dégagement peut laisser les détenus attendre. Ni Ripley ni le Runner n’est transformé en obstacle de navigation du groupe. Aucune nouvelle salle ou route, aucun blessé ou système de panique. Le Runner est inchangé et dormant pendant les préparatifs du rabattage jusqu’à l’armement.
Le rendu reste vectoriel provisoire et le contrôleur de base simplifié. Aucun build natif complet, parcours intégral du film, push ou déploiement n’est annoncé.
''')
style='body{background:#0c1411;color:#d5decb;font:16px/1.65 system-ui,sans-serif;margin:0}main{max-width:1250px;margin:auto;padding:32px}h1{font-size:36px;font-weight:500}h2{font-size:24px;color:#c8d2b6}article{margin:28px 0 48px;padding:20px;background:#15251b;border:1px solid #45563e;border-radius:9px}img{display:block;width:100%;height:auto;margin:14px 0;border:1px solid #657157}.scope{border-left:3px solid #b89962;padding:17px 22px;background:#272d20;color:#d8d1b6}small{color:#a7b699}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:9px 12px;border-bottom:1px solid #465238}@media(max-width:600px){main{padding:18px}h1{font-size:26px}article{padding:12px}}'
sections=[]
for shot in b['screenshots']:
 p=R/shot['file'];assert hashlib.sha256(p.read_bytes()).hexdigest()==shot['sha256'];setup='Test dirigé avec positions préparées.'if shot['scope'].startswith('directed')else'Parcours clavier/pointeur ou reprise de fichier après approche physique. Aucune position de participant injectée.'
 sections.append(f'<article><h2>{esc(shot["caption"])}</h2><img alt="Capture native du banc local" src="data:image/png;base64,{base64.b64encode(p.read_bytes()).decode()}"><small>{esc(setup)} Modules livrés, contrôleur simplifié, silhouettes provisoires.</small></article>')
rows=''.join(f'<tr><td>{esc(str(x))}</td><td>{esc(str(y))}</td><td>{esc(z)}</td></tr>'for x,y,z in [('Contrats V112',u['cases'],'Base instrumentée et vrai graphe'),('Installation',ins['cases'],'Fixtures à npm synthétique'),('Chromium',b['controlsExecuted'],f'Assertions dans {len(b["phases"])} groupes'),('HTML distribué',ordinary['tests'],'Horloge normale, sans API QA'),('Codex',cx['tests'],'Recherche, liens et mobile')])
(R/'RAPPORT_ILLUSTRE_V112.html').write_text(f'<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Alien 3 V112 — Laisser passer</title><style>{style}</style><main><h1>Alien 3 — Laisser passer</h1><div class="scope">Rapport V112 à captures natives des modules livrés. Banc local à physique simplifiée et personnages provisoires, pas le jeu natif complet. Aucun build natif, push ou déploiement effectué.</div><article><h2>Garder sa place sans traverser les autres</h2><p>Morse s’arrête derrière Dillon retenu par G, puis ajuste son allure quand il repart. Le déplacement utilise un seul budget et conserve ses vraies coordonnées. Les portes, la vapeur et les détours sont ceux des propriétaires précédents. L’arrivée aux commandes reste indispensable.</p><p>Le rabattage entier a été terminé après cette file. Une autre traversée l’a terminé après export, import sur une nouvelle page et reprise de l’attente. Le plan et les archives ne font pas avancer les participants.</p><p>La circulation verticale est contrôlée par des cas unitaires. Le correctif ne résout pas globalement les face-à-face sans place de dégagement et n’invente pas de poussée.</p></article><article><h2>Vérifications exécutées</h2><table><tr><th>Contrôle</th><th>Nombre réussi</th><th>Portée</th></tr>{rows}</table></article>'+''.join(sections)+'</main></html>')
print(json.dumps({'cards':doc['cards'],'captures':len(b['screenshots']),'browserControls':b['controlsExecuted']}))
