from browser_support_v113 import *
with sync_playwright()as pw:
 browser=pw.chromium.launch(executable_path=shutil.which('chromium')or'/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 if PHASE in ['all','profiles']:
  # Four profiles differ in route/controls, not four claims of human playtesting.
  p=start(browser,difficulty='survie');hunt_out(p,capture=True);hunt_back(p,capture=True);p.close()
  p=start(browser,difficulty='survie');hunt_out(p,'prudent');hunt_back(p,'prudent');p.close()
  p=start(browser,difficulty='decouverte',accessibility=True);hunt_out(p,'accessibilite');hunt_back(p,'accessibilite');record('Options de lisibilité et mouvement réduit conservées',p.evaluate('fiorinaBench.engine.alien3V104.settings.reducedMotion&&fiorinaBench.engine.alien3V104.settings.highContrast'));p.close()
 if PHASE in ['all','resume']:
  p=start(browser,difficulty='decouverte');print('RESUME started',flush=True);hunt_out(p,'explorateur');print('OUT finished',flush=True);press(p,'KeyM');before=state(p);tick(p,120);record('Le plan fige horloge, prédateur et détenus',state(p)==before);snap(p,'04_plan','Le plan consulté pendant le parcours suspend la simulation.');press(p,'Escape');press(p,'KeyC');before=state(p);tick(p,120);record('Les archives ne laissent pas avancer la chasse',state(p)==before);press(p,'Slash');p.locator('#archive-search').fill('Runner');p.keyboard.press('Enter');snap(p,'05_archives','Recherche Runner pendant la consultation, sans progression cachée.');press(p,'KeyC')
  # A real file export and import into a fresh page, then finish the route.
  p.evaluate('document.body.classList.remove("capture")')
  with p.expect_download()as dl:p.locator('#export-save').click()
  download=dl.value;file=OUT/'parcours-export-v112.json';download.save_as(file);record('Un vrai fichier de sauvegarde a été téléchargé',file.is_file()and json.loads(file.read_text())['schema']==112)
  saved=state(p);q=start(browser);q.evaluate('document.body.classList.remove("capture")');q.locator('#save-file').set_input_files(str(file));q.wait_for_function('document.querySelector("#save-status").textContent.includes("restaurée")')
  now=state(q);record('Nouvelle page : positions, santé, stade et détenus sont repris',all(now[k]==saved[k]for k in ['x','y','hp','stage']) and [(a['id'],a['x'],a['y'],a['goal'])for a in now['participants']]==[(a['id'],a['x'],a['y'],a['goal'])for a in saved['participants']],{'before':saved,'after':now})
  record('L’import reste en pause',q.evaluate('fiorinaBench.engine.paused'))
  bad=OUT/'save-corrompue-test.json';raw=json.loads(file.read_text());raw['checksum']='00000000';bad.write_text(json.dumps(raw));before=q.evaluate('JSON.stringify(fiorinaBench.exportState())');q.locator('#save-file').set_input_files(str(bad));q.wait_for_function('document.querySelector("#save-status").textContent.includes("refusé")');record('Un fichier corrompu ne remplace pas la session',q.evaluate('JSON.stringify(fiorinaBench.exportState())')==before)
  q.locator('#pause').click();q.evaluate('document.body.classList.add("capture")');q.locator('canvas').focus();hunt_back(q,'explorateur-reprise');p.close();q.close()
 if PHASE in ['all','trap']:
  # Full trap sequence; observe a denial while Morse is genuinely in transit.
  p=start(browser,mode='trap');press(p,'KeyE',15);walk(p,3890);press(p,'KeyE');walk(p,4362);hold(p,'ArrowUp',86);walk(p,4672);hold(p,'KeyE',110);record('Eau amorcée sur la coursive',state(p)['stage']==2)
  walk(p,4787);hold(p,'ArrowDown',86);walk(p,4902);press(p,'KeyE',8)
  record('La commande refuse tant que l’un des postes est encore en trajet',state(p)['stage']==2 and state(p)['operations']['active']is None and any(name in state(p)['notice']['text']for name in ['Dillon','Morse']),state(p))
  snap(p,'06_attente_postes','Refus réel : un détenu est encore en trajet vers sa commande.')
  for _ in range(100):
   if all(a['order']=='hold'for a in state(p)['participants']):break
   tick(p,4)
  p.keyboard.down('KeyE');tick(p,35)
  record('Le verrouillage reste partiel après une brève pression',state(p)['stage']==2 and state(p)['operations']['active']is not None)
  snap(p,'06b_verrouillage','Verrouillage partiel devant la commande, pendant le parcours au clavier.');p.keyboard.up('KeyE')
  hold(p,'KeyE',77);record('Le moule est armé seulement avec les deux postes tenus',state(p)['stage']==3 and all(a['order']=='hold'for a in state(p)['participants']));snap(p,'07_postes_tenus','Morse et Dillon sont arrivés par les passages ouverts, sans téléportation.')
  walk(p,4830)
  for _ in range(220):
   if state(p)['pursuit']['mode']=='windup':break
   tick(p,2)
  record('Le Runner rejoint le moule et prépare son attaque',state(p)['pursuit']['mode']=='windup');snap(p,'08_attaque_annoncee','Préparation d’attaque observée pendant le rabattage au clavier.')
  # Jump part-way through the escape, so evasion is judged during the attack, not a forced flag.
  walk(p,4918,True);p.keyboard.down('Space');tick(p,1);p.keyboard.up('Space');walk(p,5060,True);tick(p,20)
  record('Le saut est effectivement compté comme une attaque évitée',state(p)['pursuit']['stats']['misses']>=1)
  press(p,'KeyE',15);record('La coulée capture le Runner réellement dans le moule',state(p)['stage']==4 and state(p)['pursuit']['mode']=='trapped');snap(p,'09_coulee','Coulée après capture physique dans le volume du moule.')
  walk(p,4787,True);hold(p,'ArrowUp',86);walk(p,4672);hold(p,'KeyE',122);record('L’eau suit la coulée et neutralise le Runner',state(p)['stage']==5 and not state(p)['runner']['alive']);snap(p,'10_refroidissement','Retour au collecteur, eau libérée et neutralisation confirmée.')
  walk(p,4362);hold(p,'ArrowDown',86);press(p,'KeyE');record('Séquence de rabattage complète au clavier',state(p)['status']=='complete'and state(p)['stage']==6);snap(p,'11_retour_morse','Fin de la séquence originale, auprès de Morse.');routes.append({'profile':'rabattage-avec-esquive','mode':'rabattage','setup':'Physical keys and controlled frames; participant arrival and Runner position were never injected','result':state(p)})
  complete=state(p);tick(p,120);record('La fin arrête la chasse et les déplacements',state(p)==complete);p.close()
 if PHASE in ['all','failure']:
  # Directed failure/retry and sensor cases are explicit, never mixed into traversal evidence.
  p=start(browser);press(p,'KeyE') # no effect before physically near Aaron
  walk(p,1320);press(p,'KeyE',15)
  p.evaluate('''()=>{const e=fiorinaBench.engine,r=e.alien3RunnerV88;Object.assign(e.player,{x:1962,y:420,depth:1});Object.assign(r,{x:2045.5,y:440,facing:-1,depth:1,nav:{nodeId:'f161-cell-a',nextId:'f161-assembly-hall',edgeId:e.alien3NavV105.edges.find(x=>x.from==='f161-cell-a'&&x.to==='f161-assembly-hall').id,leg:0,points:[]}});e.alien3EncounterV105.pursuit.mode='chase';e.alien3EncounterV105.pursuit.grace=0;}''')
  for _ in range(12):
   tick(p,160)
   if state(p)['status']=='failed':break
  record('Une position de contact dirigée peut réellement mener à l’échec',state(p)['status']=='failed');snap(p,'12_echec','Test dirigé de contact : échec puis reprise du dernier poste sûr.','directed test with prepared actor positions')
  press(p,'KeyR');record('R reprend le checkpoint sans rejouer une attaque suspendue',state(p)['status']=='active'and state(p)['hp']>0 and state(p)['pursuit']['grace']>0 and state(p)['pursuit']['mode']!='windup');p.close()
 if PHASE in ['all','audio']:
  # User-activated Web Audio and pause gate (no physical listening certified).
  p=start(browser);p.evaluate('document.body.classList.remove("capture")');p.locator('#audio').check();p.wait_for_function('fiorinaBench.engine.alien3AudioV105.enabled');a=p.evaluate('({state:fiorinaBench.engine.alien3AudioV105.context.state,loops:fiorinaBench.engine.alien3AudioV105.loops.length})');record('AudioContext réellement démarré par un geste utilisateur',a['state']=='running',a)
  p.locator('canvas').focus();press(p,'KeyF',5);record('Un événement de bruit est envoyé au moteur audio',p.evaluate('fiorinaBench.engine.alien3AudioV105.eventsPlayed')>0)
  hold(p,'ArrowRight',20);before=state(p);press(p,'Escape');tick(p,120);record('Pause arrête la simulation et coupe la sortie audio',state(p)==before and p.evaluate('fiorinaBench.engine.alien3AudioV105.paused'))
  p.wait_for_timeout(80);record('Le gain audio rejoint zéro pendant la pause',p.evaluate('Math.abs(fiorinaBench.engine.alien3AudioV105.master.gain.value)')<.001)
  press(p,'Escape');p.locator('#audio').uncheck();record('Désactiver les sons ne change pas les objectifs',not p.evaluate('fiorinaBench.engine.alien3AudioV105.enabled')and state(p)['stage']==before['stage']);p.close()
 if PHASE in ['all','layout']:
  # Drawing purity, responsive viewports and exact source provenance.
  p=start(browser,mode='trap');pure=p.evaluate('''()=>{const before=JSON.stringify(fiorinaBench.exportState());for(let i=0;i<20;i++)fiorinaBench.render();return before===JSON.stringify(fiorinaBench.exportState());}''');record('Vingt dessins ne modifient pas le fichier de sauvegarde',pure)
  coverage=p.evaluate('''()=>{const e=fiorinaBench.engine,c=document.querySelector('canvas').getContext('2d'),result=[];for(const y of [0,55,110]){e.camera.y=y;c.clearRect(0,0,1280,720);e.drawBackdrop(c);const a=c.getImageData(0,0,1280,1).data;result.push(Array.from(a).filter((_,i)=>i%4===3).every(x=>x===255));}return result;}''');record('Le fond couvre toujours sa première ligne',all(coverage),coverage)
  for w,h in [(390,844),(844,390),(1920,1080)]:
   p.set_viewport_size({'width':w,'height':h});p.evaluate('document.body.classList.remove("capture");fiorinaBench.render()');bb=p.locator('canvas').bounding_box();record(f'Canvas contenu dans la largeur {w}×{h}',bb['width']<=w+1,bb)
   p.screenshot(path=str(SHOTS/f'format_{w}x{h}.png'),full_page=True)
  p.close()
 record('Aucune exception JavaScript dans les pages inspectées',not errors,errors);record('Aucune requête réseau externe depuis les aperçus',not external,external)
 version=browser.version;browser.close()
result={'ok':True,'scope':'Actual V113 modules in the simplified local host; neither full native game nor film campaign certified','browser':version,'controls':len(tests),'results':tests,'routes':routes,'screenshots':captures,'errors':errors,'externalRequests':external,'sourceHashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (ROOT/'src').glob('*v113.js')}}
(OUT/('browser-'+PHASE+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'controls':len(tests),'routes':len(routes),'captures':len(captures)},ensure_ascii=False))
