import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {compileAlien3StandardV104,STANDARD_RULES_V104,EVENT_BINDINGS_V104,ROUND_V104} from '../src/alien3-dlc-v104.js';
import {ALIEN3_RULES_V102,ALIEN3_FIORINA_TEMPLATE_V102,auditAlien3DecorV102} from '../src/alien3-dlc-v102.js';
import {ALIEN3_RULES_V103,auditAlien3CirculationV103} from '../src/alien3-dlc-v103.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),model=compileAlien3StandardV104();
const out={version:104,scope:'Actual recovered V103 plus three V104 modules; geometry in this export is template-derived, not a surveyed film set',model,rules:[...ALIEN3_RULES_V102,...ALIEN3_RULES_V103,...STANDARD_RULES_V104],events:EVENT_BINDINGS_V104,round:ROUND_V104,routes:ALIEN3_FIORINA_TEMPLATE_V102.routes,decorAudit:auditAlien3DecorV102(model.scene.decor),circulationAudit:auditAlien3CirculationV103(model.scene)};
fs.writeFileSync(path.join(root,'qa-v104/design-source.json'),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({nodes:model.scene.nodes.length,rules:out.rules.length,props:model.scene.decor.props.length}));
