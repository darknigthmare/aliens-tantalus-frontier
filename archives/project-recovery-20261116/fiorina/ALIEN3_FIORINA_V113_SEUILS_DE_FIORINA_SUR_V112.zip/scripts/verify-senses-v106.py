#!/usr/bin/env python3
"""Focused live-render tests of V106 additions; prepared positions are labelled directed."""
from pathlib import Path
import json,hashlib,subprocess,sys,shutil
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'qa-v106';SHOTS=OUT/'captures';SHOTS.mkdir(exist_ok=True)
subprocess.run([sys.executable,str(ROOT/'scripts/build-preview-v106.py')],check=True)
HTML=(ROOT/'FIORINA_V106_JOUER.html').read_text();tests=[];shots=[];errors=[];requests=[]
def check(name,ok,details=None):
 if not ok:raise AssertionError(name+' '+str(details))
 tests.append({'name':name,'ok':True,'details':details});print('PASS',name,flush=True)
def tick(p,n):p.evaluate('(n)=>{for(let i=0;i<n;i++)fiorinaBench.tick(1/60)}',n)
def key(p,k,n=0):p.locator('canvas').focus();p.keyboard.press(k);tick(p,n)
def snap(p,name,caption,scope):
 p.evaluate('fiorinaBench.render()');f=SHOTS/(name+'.png');p.locator('canvas').screenshot(path=str(f));shots.append({'file':'qa-v106/captures/'+f.name,'caption':caption,'scope':scope,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'state':p.evaluate('({player:fiorinaBench.engine.player,senses:fiorinaBench.engine.alien3SensesV106,encounter:fiorinaBench.engine.alien3EncounterV105})')})
def page(browser,mode='hunt'):
 p=browser.new_page(viewport={'width':1280,'height':900});p.set_default_timeout(10000);p.on('pageerror',lambda e:errors.append(str(e)));p.on('request',lambda r:requests.append(r.url)if r.url.startswith(('http:','https:'))else None)
 p.set_content('<script>window.__FIORINA_QA__=true;window.__BENCH_QUERY__="freeze=1"</script>'+HTML,wait_until='load');p.wait_for_function('!!window.fiorinaBench');p.locator('.settings summary').click();p.locator('#difficulty').select_option('decouverte');p.locator('#'+mode).click();p.evaluate('document.body.classList.add("capture")');return p
with sync_playwright() as w:
 browser=w.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 p=page(browser)
 # A clearly directed placement at a real switch. I still performs the actual interaction.
 p.evaluate('''()=>{const e=fiorinaBench.engine;Object.assign(e.player,{x:2008.5,y:420,depth:1,grounded:true,vx:0,vy:0});e.update(.016);e.camera.x=e.player.x-465;}''')
 snap(p,'13_lampe_allumee','Même commande et mêmes acteurs : lampe de la coursive allumée.','directed position at the existing cell-light; actual shared renderer')
 state_before=p.evaluate('({x:fiorinaBench.engine.player.x,y:fiorinaBench.engine.player.y,runnerX:fiorinaBench.engine.alien3RunnerV88.x})')
 key(p,'KeyI');check('I coupe réellement la commande de la coursive',p.evaluate('fiorinaBench.engine.alien3V103.lights["cell-light"]')==False)
 snap(p,'14_lampe_eteinte','La commande a été éteinte par I : pénombre locale au même étage.','same directed position, no clock advance; real I input toggled circuit')
 state_after=p.evaluate('({x:fiorinaBench.engine.player.x,y:fiorinaBench.engine.player.y,runnerX:fiorinaBench.engine.alien3RunnerV88.x})')
 check('La paire avant/après ne déplace ni joueur ni Runner',state_before==state_after)
 from PIL import Image,ImageChops
 im1=Image.open(SHOTS/'13_lampe_allumee.png').convert('RGB');im2=Image.open(SHOTS/'14_lampe_eteinte.png').convert('RGB');check('Les images allumée et éteinte sont réellement différentes',ImageChops.difference(im1,im2).getbbox() is not None)
 # No renderer modifications of simulation state.
 check('Vingt dessins de pénombre ne modifient pas la sauvegarde',p.evaluate('''()=>{const a=JSON.stringify(fiorinaBench.exportState());for(let i=0;i<20;i++)fiorinaBench.render();return a===JSON.stringify(fiorinaBench.exportState());}'''))
 p.close()
 p=page(browser,'trap');key(p,'KeyE',12);key(p,'KeyG');d=lambda:p.evaluate('fiorinaBench.engine.alien3EncounterV105.participants.find(a=>a.id==="dillon")')
 held=d();check('G donne un vrai ordre d’attente à Dillon proche',p.evaluate('fiorinaBench.engine.alien3SensesV106.holds.dillon')==True)
 tick(p,90);check('Dillon attend sans avancer ou atteindre artificiellement sa commande',d()['x']==held['x'] and d()['nav']==held['nav'])
 snap(p,'15_dillon_attend','Dillon attend à sa position réelle après un ordre donné avec G.','UI start + actual E and G, no participant position injections')
 p.evaluate('document.body.classList.remove("capture")')
 with p.expect_download()as dl:p.locator('#export-save').click()
 path=OUT/'attente-export-v106.json';dl.value.save_as(path);raw=json.loads(path.read_text());check('Le fichier exporté contient attente et poste sûr',raw['schema']==106 and raw['senses']['holds']['dillon'] and raw['safePoint'] is not None)
 q=page(browser,'trap');q.evaluate('document.body.classList.remove("capture")');q.locator('#save-file').set_input_files(str(path));q.wait_for_function('document.querySelector("#save-status").textContent.includes("restaurée")');check('Une nouvelle page reprend l’ordre et la position',q.evaluate('(x)=>fiorinaBench.engine.alien3SensesV106.holds.dillon&&fiorinaBench.engine.alien3EncounterV105.participants.find(a=>a.id==="dillon").x===x',held['x']))
 check('L’import reprend en pause',q.evaluate('fiorinaBench.engine.paused'))
 q.locator('#pause').click();q.evaluate('document.body.classList.add("capture")');key(q,'KeyG');tick(q,70)
 after=q.evaluate('fiorinaBench.engine.alien3EncounterV105.participants.find(a=>a.id==="dillon")');check('G relance le même détenu sur son trajet plutôt que le téléporter',after['x']>held['x'] and after['x']<held['x']+150 and after['goal']=='f161-piston-c-node')
 snap(q,'16_dillon_repart','Après import sur une nouvelle page, Dillon reprend son déplacement.','real save-file import, pause button and G; participant movement from the same saved position')
 # Corrupt nested checkpoint, recompute outer checksum by emulating the simple FNV corruption detector.
 bad=json.loads(path.read_text());bad['safePoint']['base']['encounter']['signature']='bad';broken=OUT/'checkpoint-corrompu.json';broken.write_text(json.dumps(bad));q.evaluate('document.body.classList.remove("capture")');before=q.evaluate('JSON.stringify(fiorinaBench.exportState())');q.locator('#save-file').set_input_files(str(broken));q.wait_for_function('document.querySelector("#save-status").textContent.includes("refusé")');check('Un poste sûr corrompu ne remplace pas la session',q.evaluate('JSON.stringify(fiorinaBench.exportState())')==before)
 # Inputs in text fields cannot accidentally command participants.
 q.evaluate('document.querySelector("#archive-search").hidden=false');q.locator('#archive-search').focus();before=q.evaluate('fiorinaBench.engine.alien3SensesV106.stats.holdOrders');q.keyboard.type('g');check('Saisir G dans le champ de recherche ne donne pas d’ordre',q.evaluate('fiorinaBench.engine.alien3SensesV106.stats.holdOrders')==before)
 q.close();p.close()
 check('Aucune erreur JavaScript',not errors,errors);check('Aucune requête externe',not requests,requests)
 browser.close()
(OUT/'browser-senses.json').write_text(json.dumps({'ok':True,'scope':'Shared V106 modules in local simplified controller; directed light pair separated from input-driven coordination sequence','controls':len(tests),'results':tests,'screenshots':shots},ensure_ascii=False,indent=2))
print(json.dumps({'ok':True,'controls':len(tests),'captures':len(shots)}))
