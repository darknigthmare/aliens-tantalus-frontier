#!/usr/bin/env python3
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'qa-v108';checks=[]
def check(name,ok,detail=None):
 if not ok:raise AssertionError(name+':'+str(detail))
 checks.append({'name':name,'ok':True,'details':detail})
with sync_playwright()as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium')or'/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport={'width':1280,'height':960});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((ROOT/'FIORINA_V108_JOUER.html').read_text(),wait_until='load');page.wait_for_timeout(160);check('Le fichier ordinaire ne publie aucune API de test',not page.evaluate('"fiorinaBench"in window'))
 page.locator('#hunt').click();page.wait_for_timeout(100)
 with page.expect_download()as dl:page.locator('#export-save').click()
 first=OUT/'delivered-before.json';dl.value.save_as(str(first));a=json.loads(first.read_text());check('Le menu lance une vraie traque',a['base']['base']['base']['encounter']['mode']=='traque'and a['base']['base']['base']['encounter']['stage']==0)
 # The ordinary renderer's real frame rate varies with load. Approach in bounded
 # keyboard increments, reading only genuinely downloaded public save files.
 # This avoids mistaking a slow headless frame rate for a missing interaction.
 z=a;last=OUT/'delivered-after.json';steps=0
 while z['base']['base']['base']['base']['pose']['x']<1303 and steps<18:
  page.locator('canvas').focus();page.keyboard.down('ArrowRight');page.wait_for_timeout(220);page.keyboard.up('ArrowRight')
  with page.expect_download()as dl:page.locator('#export-save').click()
  dl.value.save_as(str(last));z=json.loads(last.read_text());steps+=1
 check('Approche au clavier contrôlée par les fichiers réellement exportés',1303<=z['base']['base']['base']['base']['pose']['x']<1440,{'increments':steps,'x':z['base']['base']['base']['base']['pose']['x']})
 page.locator('canvas').focus();page.keyboard.press('KeyE');page.wait_for_timeout(80)
 with page.expect_download()as dl:page.locator('#export-save').click()
 dl.value.save_as(str(last));z=json.loads(last.read_text())
 check('L’horloge ordinaire progresse sans API QA',z['base']['base']['base']['encounter']['clock']>a['base']['base']['base']['encounter']['clock']);check('Le clavier déplace le personnage dans le fichier exporté',z['base']['base']['base']['base']['pose']['x']>a['base']['base']['base']['base']['pose']['x']);check('E valide la conversation d’Aaron à portée',z['base']['base']['base']['encounter']['stage']==1,z['base']['base']['base']['base']['pose']);check('Le prédateur patrouille aussi avec requestAnimationFrame',z['base']['base']['base']['encounter']['pursuit']['stats']['distance']>0);check('Une réserve de trois boulons est présente dans le fichier distribué',len(z['diversion']['bolts'])==3 and all(x['state']=='pocket'for x in z['diversion']['bolts']))
 page.locator('canvas').focus();page.keyboard.press('KeyT');page.wait_for_timeout(200)
 with page.expect_download()as dl:page.locator('#export-save').click()
 path=OUT/'delivered-bolt.json';dl.value.save_as(str(path));bolt=json.loads(path.read_text())
 check('T lance effectivement un objet dans le HTML ordinaire',bolt['diversion']['stats']['thrown']==1 and sum(x['state']=='pocket'for x in bolt['diversion']['bolts'])==2,bolt['diversion'])
 check('Aucune erreur JavaScript dans le chemin distribué',not errors,errors)
 b.close()
(OUT/'delivered.json').write_text(json.dumps({'ok':True,'tests':len(checks),'scope':'Delivered HTML without inspection API, real animation time, real keyboard and downloaded save files','results':checks,'sourceHash':hashlib.sha256((ROOT/'FIORINA_V108_JOUER.html').read_bytes()).hexdigest()},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'tests':len(checks)}))
