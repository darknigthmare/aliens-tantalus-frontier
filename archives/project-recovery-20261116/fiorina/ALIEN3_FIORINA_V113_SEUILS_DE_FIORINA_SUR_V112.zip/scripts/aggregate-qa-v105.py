from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1];Q=R/'qa-v105';phases=['profiles','resume','trap','failure','audio','layout'];reports=[json.loads((Q/f'browser-{p}.json').read_text())for p in phases];results=[dict(phase=p,**t)for p,r in zip(phases,reports)for t in r['results']];captures=[x for r in reports for x in r['screenshots']];routes=[x for r in reports for x in r['routes']]
for r in reports:
 assert r['ok'] and not r['errors'] and not r['externalRequests']
 for name,h in r['sourceHashes'].items():assert hashlib.sha256((R/'src'/name).read_bytes()).hexdigest()==h,(name,'stale browser evidence')
for c in captures:assert hashlib.sha256((R/c['file']).read_bytes()).hexdigest()==c['sha256']
report={'ok':True,'controlsExecuted':len(results),'uniqueControlNames':len({r['name']for r in results}),'phases':phases,'results':results,'routes':routes,'screenshots':captures,'browser':reports[0]['browser'],'scope':'Native Chromium shots, shared shipped renderer, local simplified host; original slices not a full film campaign. 4 automated play styles, not human playtests.','sourceHashes':reports[0]['sourceHashes'],'nativeBuild':False}
(Q/'browser.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'controls':len(results),'uniqueNames':report['uniqueControlNames'],'traversals':len(routes),'captures':len(captures)}))
