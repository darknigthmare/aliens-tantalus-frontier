import {Runtime as Previous,model,actor,gates} from './fixture-v107.mjs';
import {withAlien3DlcRuntimeV108} from '../src/alien3-dlc-runtime-v108.js';
import {CAMPAIGN_V104} from '../src/alien3-dlc-v104.js';
export {model,actor,gates};export const Runtime=withAlien3DlcRuntimeV108(Previous);
export const game=(mode='traque')=>{const e=new Runtime();e.start({campaign:{id:CAMPAIGN_V104},alien3EncounterV105:mode});return e;};
