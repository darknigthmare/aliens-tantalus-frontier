#!/usr/bin/env python3
"""Illustrated PDF from native Chromium captures; no independent picture rendering."""
from pathlib import Path
from xml.sax.saxutils import escape
import json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape,A4
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=Path(__file__).resolve().parents[1];Q=R/'qa-v112';b=json.loads((Q/'browser.json').read_text());u=json.loads((Q/'unit.json').read_text());i=json.loads((Q/'install.json').read_text());doc=json.loads((Q/'documentation.json').read_text());cx=json.loads((Q/'codex-browser.json').read_text());dh=json.loads((Q/'delivered.json').read_text())
for name,file in [('Body','DejaVuSans.ttf'),('Strong','DejaVuSans-Bold.ttf')]:
 p=Path('/usr/share/fonts/truetype/dejavu')/file
 if not p.is_file():raise FileNotFoundError('DejaVu Sans required locally: '+str(p))
 pdfmetrics.registerFont(TTFont(name,str(p)))
W,H=landscape(A4);M=34;CW=W-2*M;BG=HexColor('#0e1a13');INK=HexColor('#e3e8d6');MUTED=HexColor('#b7c3ad');LINE=HexColor('#52634a');GOLD=HexColor('#cdb786')
styles={k:ParagraphStyle(k,fontName='Body',fontSize=f,leading=l,textColor=MUTED if k in ['small','caption']else INK)for k,f,l in [('body',11,16),('caption',9.2,13),('small',9,12.7),('cell',9.5,13.5)]}
pdf=canvas.Canvas(str(R/'RAPPORT_ILLUSTRE_V112.pdf'),pagesize=(W,H),pageCompression=1);pdf.setTitle('ALIEN 3 — Fiorina 161 V112 — Laisser passer');pdf.setAuthor('Aliens: Tantalus Frontier / dossier de développement')
selectedNames=['50_morse_attend_dillon.png','51_le_groupe_repart.png','52_postes_apres_file.png','53_coulee_apres_file.png','54_retour_apres_file.png','55_file_apres_import.png','51_le_groupe_repart_reprise.png','54_retour_apres_file_reprise.png','41_porte_refermee.png','43_detour_inferieur.png','44_postes_apres_detour.png','45_coulee_apres_detour.png','30_dillon_attend_le_jet.png','31_refermer_en_cours.png','33_attente_volontaire.png','08_attaque_annoncee.png']
selected=[next(x for x in b['screenshots']if Path(x['file']).name==n)for n in selectedNames];total=3+len(selected);pn=0

def para(text,x,top,width,style='body',maxh=None):
 p=Paragraph(text,styles[style]);_,height=p.wrap(width,999)
 if maxh and height>maxh:raise ValueError(f'Overflow {height}>{maxh}: {text[:60]}')
 p.drawOn(pdf,x,top-height);return height

def page(title,section):
 global pn;pn+=1;pdf.setFillColor(BG);pdf.rect(0,0,W,H,fill=1,stroke=0);pdf.setFillColor(GOLD);pdf.setFont('Strong',9);pdf.drawString(M,H-24,'ALIEN 3  /  FIORINA 161');pdf.setFont('Body',8);pdf.drawRightString(W-M,H-24,'V112  ·  '+section);pdf.setFillColor(INK);pdf.setFont('Strong',24)
 if pdfmetrics.stringWidth(title,'Strong',24)>CW:raise ValueError(title)
 pdf.drawString(M,H-57,title);pdf.setStrokeColor(LINE);pdf.line(M,29,W-M,29);pdf.setFillColor(MUTED);pdf.setFont('Body',7.5);pdf.drawString(M,16,'Banc local · modules partagés · silhouettes vectorielles · pas de campagne native complète certifiée');pdf.drawRightString(W-M,16,f'{pn:02d} / {total}')

def image(file,top=H-76):
 h=CW*720/1280;pdf.drawImage(str(R/file),M,top-h,width=CW,height=h,preserveAspectRatio=True,mask='auto');pdf.setStrokeColor(LINE);pdf.rect(M,top-h,CW,h,stroke=1,fill=0);return top-h

def table(rows,top,widths):
 t=Table([[Paragraph(escape(str(x)),styles['cell'])for x in row]for row in rows],colWidths=widths);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#2d3b26')),('BACKGROUND',(0,1),(-1,-1),HexColor('#182b1c')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,-1),.5,LINE)]));_,h=t.wrap(CW,999);t.drawOn(pdf,M,top-h);return top-h
page('Laisser passer','VERSION LOCALE CANDIDATE')
y=image('qa-v112/captures/50_morse_attend_dillon.png');para('Morse conserve sa distance derrière Dillon retenu par G. Capture native pendant un parcours au clavier : les modules livrés sont exécutés dans un banc à physique de base et personnages provisoires.',M,y-10,CW,'caption',40);pdf.showPage()
page('Une place pour chacun','COMPORTEMENTS ET LIMITES')
y=table([['Élément','Comportement livré','Limite'],['Corps du détenu','Prochain pas balayé avec le corps entier.','Pas de collision globale ni de poussée.'],['Suivi','Allure réduite derrière un meneur plus lent.','Un seul budget, pas de correction téléportée.'],['Ordre G','Le détenu garde sa consigne d’attente.','Le voisin ne le traverse pas.'],['Liaison verticale','Un nouvel entrant attend si elle est occupée.','Contrat unitaire, pas de croisement navigateur annoncé.'],['Détours','Même proposition V111, puis marge corporelle.','Aucune route ni arrivée créée.'],['Reprise','Pose et segment conservés, file recalculée.','Pas de réservation persistante imposée.']],H-82,[112,329,CW-441]);y-=18
para('Le rabattage complet est terminé après cette attente, puis de nouveau après export et import sur une nouvelle page. Les postes, l’attaque esquivée, la coulée et le refroidissement conservent leurs conditions antérieures.',M,y,CW,'body',50);y-=63
para(f'Codex de conception : <b>{doc["cards"]} fiches</b>, dont {doc["newCards"]} contrats nouveaux. 72 points et 119 connexions conservés. Aucun nouveau modèle artistique. Un face-à-face sans dégagement peut rester bloqué : ce n’est pas un solveur multi-agent global.',M,y,CW,'small',50);pdf.showPage()
page('Parcours et reprise jusqu’au bout','PREUVES EXÉCUTÉES')
rows=[['Parcours automatisé','Résultat','Santé','Attentes / reprises']]
labels={'rapide':'Traque rapide','prudent':'Traque prudente','accessibilite':'Traque accessible','explorateur-reprise':'Traque avec reprise','rabattage-avec-esquive':'Rabattage avec esquive','rabattage-vanne-et-groupe':'Vanne, attente et groupe','rabattage-porte-et-detour':'Porte fermée et détour','rabattage-file-et-depart':'File puis départ avec G','rabattage-file-reprise':'File importée puis piège complet'}
for route in b['routes']:
 st=route['result'];rows.append([labels.get(route['profile'],route['profile']),'Terminé' if st['status']=='complete' else st['status'],st['hp'],str(st['spacing']['stats']['waits'])+' / '+str(st['spacing']['stats']['resumes'])])
y=table(rows,H-81,[258,148,90,CW-496]);y-=14
para('Clavier et horloge contrôlée, sans injection de pose, d’arrivée ou d’étape pendant les traversées. Les robots connaissent le chemin. La file recalculée après import peut compter comme un nouvel épisode d’attente ; cela ne change ni les poses ni les ordres.',M,y,CW,'small',40);y-=47
para(f'<b>{u["cases"]} cas unitaires</b>, <b>{i["cases"]} installations synthétiques</b>, <b>{b["controlsExecuted"]} assertions Chromium</b> ({b["uniqueControlNames"]} libellés distincts), {dh["tests"]} contrôles du fichier ordinaire et {cx["tests"]} contrôles du codex. Pas de build natif complet, campagne entière ou déploiement certifiés.',M,y,CW,'small',50);pdf.showPage()
titles={'50_morse_attend_dillon.png':'Attendre sans traverser Dillon','51_le_groupe_repart.png':'Repartir à l’allure du groupe','52_postes_apres_file.png':'Les postes sont réellement occupés','53_coulee_apres_file.png':'La coulée garde ses conditions','54_retour_apres_file.png':'Terminer après avoir laissé passer','55_file_apres_import.png':'Retrouver la file après import','51_le_groupe_repart_reprise.png':'Reprendre depuis les positions restaurées','54_retour_apres_file_reprise.png':'Un piège entier après la reprise','41_porte_refermee.png':'Les portes bloquent toujours les trajets','43_detour_inferieur.png':'Le détour inférieur reste possible','44_postes_apres_detour.png':'Arriver après le détour existant','45_coulee_apres_detour.png':'Le piège reste terminable après le détour','30_dillon_attend_le_jet.png':'Ne pas confondre compagnon et vapeur','31_refermer_en_cours.png':'Refermer à la commande existante','33_attente_volontaire.png':'La consigne volontaire reste prioritaire','08_attaque_annoncee.png':'Le Runner conserve son attaque annoncée'}
for index,shot in enumerate(selected,1):
 page(titles[Path(shot['file']).name],f'CAPTURE NATIVE {index:02d} / {len(selected)}');y=image(shot['file']);scope='Nouvelle page après export et import explicites.'if'file export' in shot['scope']else'Actions au clavier/pointeur dans le banc local.';para(escape(shot['caption'])+' '+scope,M,y-10,CW,'caption',40);pdf.showPage()
assert pn==total;pdf.save();report={'ok':True,'pages':pn,'nativeScreenshotsInPdf':len(selected),'nativeScreenshotsAvailable':len(b['screenshots']),'bytes':(R/'RAPPORT_ILLUSTRE_V112.pdf').stat().st_size};(Q/'pdf.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
