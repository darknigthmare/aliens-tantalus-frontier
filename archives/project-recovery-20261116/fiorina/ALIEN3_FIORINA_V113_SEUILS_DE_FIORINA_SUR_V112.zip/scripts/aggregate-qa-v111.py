from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1];Q=R/'qa-v111'
phases=['profiles','resume','trap','failure','audio','layout','traffic-route','traffic-gesture','traffic-hunt','routing-detour','routing-resume']
reports=[json.loads((Q/f'browser-{p}.json').read_text())for p in phases]
results=[dict(phase=p,**t)for p,r in zip(phases,reports)for t in r['results']];shots=[s for r in reports for s in r['screenshots']];routes=[v for r in reports for v in r.get('routes',[])]
for r in reports:
 assert r['ok'] and not r.get('errors') and not r.get('externalRequests')
 for n,h in r['sourceHashes'].items():assert hashlib.sha256((R/'src'/n).read_bytes()).hexdigest()==h,(n,'stale evidence')
for s in shots:assert hashlib.sha256((R/s['file']).read_bytes()).hexdigest()==s['sha256'],s['file']
unique={}
for s in shots:
 if s['file']in unique:assert unique[s['file']]['sha256']==s['sha256']
 else:unique[s['file']]=s
shots=list(unique.values())
out={'ok':True,'controlsExecuted':len(results),'uniqueControlNames':len(set(t['name']for t in results)),'phases':phases,'results':results,'routes':routes,'screenshots':shots,'browser':reports[0]['browser'],'sourceHashes':reports[0]['sourceHashes'],'scope':'Shipped modules in simplified host. Real keyboard traversals and exported file resumes, controlled clock; prepared failure case identified separately. No full native campaign, human QA or physical device qualification.','nativeBuild':False}
(Q/'browser.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'controls':len(results),'unique':out['uniqueControlNames'],'routes':len(routes),'screenshots':len(shots)}))
