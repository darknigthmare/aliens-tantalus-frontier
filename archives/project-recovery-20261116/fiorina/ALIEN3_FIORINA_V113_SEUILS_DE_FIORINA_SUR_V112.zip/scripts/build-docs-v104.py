#!/usr/bin/env python3
"""Publish source-backed design notes, cross-DLC matrix and illustrated report."""
from pathlib import Path
from xml.sax.saxutils import escape
import json,subprocess,base64,hashlib
ROOT=Path(__file__).resolve().parents[1];Q=ROOT/'qa-v104';DOC=ROOT/'docs';DOC.mkdir(exist_ok=True)
subprocess.run(['node',str(ROOT/'scripts/export-design-v104.mjs')],check=True)
data=json.loads((Q/'design-source.json').read_text());scene=data['model']['scene'];unit=json.loads((Q/'unit.json').read_text());inst=json.loads((Q/'installation.json').read_text());browser=json.loads((Q/'browser.json').read_text());delivered=json.loads((Q/'delivered-html.json').read_text())
provenance=json.loads((ROOT/'sources-v103-recovered.json').read_text())
rows=[
('Parcours réellement terminable','Nostromo V108, rapport : cinq circuits au clavier, dont Sous la coque.','Ajouté à l’aperçu','Ronde originale : trois éclairages, deux accès ouverts, montée et descente à l’atelier, retour. Export à mi-parcours puis import et fin sur page neuve.','La ronde n’est pas un chapitre supplémentaire du film ni une certification de la campagne.'),
('Présence physique pour agir','Résurrection V115 : Call au port FATHER et Purvis près de Wren ; Aliens V105 : profondeur partagée.','Renforcé','Les commandes d’éclairage conservent portée, étage, profondeur et refus à travers une porte fermée. La position interpolée est prise en compte.','Aucune nouvelle escorte ni coordination des détenus ajoutée.'),
('Contact sans traverser les étages','Résurrection V113–V115 : espace propre à chaque acteur et contact atteignable.','Ajouté','Un veto refuse la morsure trop éloignée, à un autre étage, derrière une porte ou sur une autre profondeur. Le feu ordinaire reste délégué.','La locomotion et les attaques de toutes les couches historiques ne sont pas remplacées.'),
('Horloge suspendue par les interfaces','Nostromo V108 et Romulus 0.10 : pause, carte et archives.','Aligné dans V104','Une seule progression temporelle V104, delta borné ; carte, archives, pause, chargement et mort arrêtent sa simulation.','Pas de qualification de tous les systèmes externes au mixin.'),
('HUD lisible, peu envahissant','Nostromo V108 : informations extérieures ; Résurrection : objectifs au même plan que l’action.','Adapté','Lieu et vitales temporaires ; santé conservée sous seuil critique ; priorité à l’action proche et à la consigne de ronde.','Le cadre natif Alien 3 reste Canvas ; ce n’est pas le shell DOM complet de Nostromo.'),
('Décor lié aux événements','Romulus 0.10 : états de traversée ; Résurrection V115 : continuité des séquences.','Ajouté','Feu, suie, plomb chaud, refroidissement et arrivée de la Compagnie dérivent des drapeaux existants.','Les effets ajoutés sont visuels, sans nouveaux dégâts ni manipulation des objectifs.'),
('Plan limité à la découverte','Romulus 0.10 : accès observés, pas d’organismes cachés ; Alien 3 V103 : nœuds visités.','Conservé et retesté','La ronde révèle les points traversés ; plan et archives sont mutuellement exclusifs.','Pas de carte omnisciente ni de révélation de la position du Runner.'),
('Reprise fiable par fichier','Nostromo V108 : imports validés avant remplacement ; Résurrection V115 : fichiers JSON bornés.','Ajouté à l’aperçu','Fichier JSON limité à 1 Mio ; identité, signature de géométrie, pose, portes, lumières, ordre des étapes et paramètres vérifiés. Import toujours en pause.','La signature de géométrie détecte une incompatibilité accidentelle ; ce n’est pas une authentification. Pas de persistance localStorage certifiée.'),
('Anciens enregistrements préservés','Résurrection V115 : migrations n’inventant pas de ressources.','Adapté','La reprise native sans volet V104 initialise seulement ce volet. Pas de ronde, de ressources ni de découvertes inventées.','L’ancien aperçu V103 n’exportait pas le nouveau format de fichiers ; aucune compatibilité fictive de fichier V103 n’est annoncée.'),
('Options d’accessibilité','Romulus 0.10 : lisibilité renforcée et mouvements réduits.','Ajouté','Mouvements d’ambiance réduits, contraste du HUD et affichage permanent au choix ; progression inchangée.','Pas de certification manette matérielle, Safari/iPhone ou audit complet d’accessibilité.'),
('Installation non destructive','Résurrection V115 et Alien 3 V103 : signatures, stage et retour protégeant les éditions locales.','Renforcé','Trois nouveaux modules et un raccord ; vérification des sources V103 ; copie temporaire ; npm check/build ; refus des mutations pendant les contrôles.','Essais sur projets synthétiques. Pas de build du dépôt complet.'),
('Preuves visuelles honnêtes','Nostromo V108 et Résurrection V115 : captures natives avec provenance et portée.','Appliqué','Treize captures Chromium des modules partagés ; ronde continue distincte des événements préparés ; aperçu distribué testé sans API QA.','Art provisoire et contrôleur simplifié. Aucun screenshot n’est annoncé comme production full-assets.'),
('Différences conservées','Aliens V105 : escouade, armes, véhicules ; Romulus : autres organismes et séquences.','Non transféré par choix','Alien 3 garde sa logique de survie industrielle, un Runner et ses pièges historiques.','Pas de Marines armés, de Power Loader ou de vague de nouvelles castes importés de force.'),
('Menace active de la branche autonome','Nostromo V108 : patrouille, audition, recherche et attaque préparée.','À faire','Le correctif prépare des contacts plus sûrs.','La ronde actuelle reste une maintenance sans prédateur actif. Une IA équivalente n’est pas revendiquée.'),
('Intégration et art natifs','Tous les rapports récents distinguent hôte et production.','À faire','Les modules, le banc, les documents et les contrôles sont fournis.','Jeu principal, assets définitifs, campagne complète, publication et performance cible non qualifiés.')]
mat=[dict(criterion=c,reference=r,status=s,implemented=a,limit=l) for c,r,s,a,l in rows]
(DOC/'MATRICE_ALIGNEMENT_V104.json').write_text(json.dumps({'version':104,'basis':'Documents retrouvés et lus ; aucune égalité globale de maturité annoncée','rows':mat},ensure_ascii=False,indent=2))
md=['# Mise à niveau inter-DLC — Alien 3 V104','', 'Cette matrice distingue les standards repris, les différences conservées et ce qui reste à intégrer. Les numéros de version ne mesurent pas à eux seuls la qualité ni la complétude des DLC.', '', '| Critère | Référence vérifiée | Statut V104 | Réalisé | Limite |','|---|---|---|---|---|']
for c,r,s,a,l in rows:md.append(f'| {c} | {r} | {s} | {a} | {l} |')
md+=['','## Références documentaires','- Alien / Nostromo : `RAPPORT_DEVELOPPEMENT_V108.html`, branche autonome « Sous la coque », datée du 28 septembre 2026 dans la Bibliothèque.','- Alien Resurrection : `README_V115.md`, « Continuité des participants », candidat V115.','- Romulus : interface de `ALIEN_ROMULUS_PASSAGES_v0.10.html` ; les options et menus y sont directement vérifiables, pas toutes leurs mécaniques par cette lecture seule.','- Aliens 1986 : `QA_REPORT.md`, section V105 « Room-by-Room Hybrid Level Design ». C’est la référence Aliens retrouvée ; aucune affirmation qu’il s’agit de sa toute dernière livraison.','- Alien 3 : `RAPPORT_QA_V103.md`, « Passages et réseaux ». Les chiffres et réserves de ce document priment sur les résumés contradictoires plus anciens.']
(DOC/'MATRICE_ALIGNEMENT_V104.md').write_text('\n'.join(md))
# Descriptive geometry is directly exported from the live modules.
nodes={n['id']:n for n in scene['nodes']};groups={g['id']:g for g in scene['decor']['groups']};props=scene['decor']['props'];circuits=scene['circuits'];utilities=scene['utilities'];edges=scene['edges'];cards=[]
fmt=lambda x:f'{x:.2f}'.rstrip('0').rstrip('.') if isinstance(x,(int,float)) else str(x)
name_kind={'walk':'Marche','ladder':'Échelle','lift':'Ascenseur','gate':'Porte','airlock':'Sas','slope':'Pente','vent':'Conduit'}
geo=lambda p:f'X {fmt(p["x"])} ; Y {fmt(p["y"])} ; {fmt(p["w"])} × {fmt(p["h"])}'
for s in scene['spaces']:
 ns=[nodes[n]for n in s['nodeIds']];gs=[g for g in groups.values() if g['nodeId'] in s['nodeIds']]
 details=[['Appui',n['id'],f'X {fmt(n["x"])} ; pied Y {fmt(n["y"])} ; largeur {fmt(n["width"])}']for n in ns]+[['Ensemble',g['id'],geo(g)]for g in gs]
 text=f'{s["usage"]} Repère : {s["landmark"]}. Étendue descriptive X {fmt(s["x"])}–{fmt(s["right"])} ; sol représentatif Y {fmt(s["floor"])}. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.'
 cards.append(dict(type='Sections',id=s['id'],title=s['label'],text=text,details=details))
for g in groups.values():
 pp=[p for p in props if p['assemblyId']==g['id']];connected=[r for r in circuits if r['assemblyId']==g['id']]
 text=f'Appui {g["supportId"]} ; point {g["nodeId"]} ; échelle uniforme {fmt(g["scale"])} ; condition {g["condition"]}. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.'
 details=[['Composant '+p['kind'],p['id'],geo(p)+' ; pose '+p['mount']]for p in pp]+[['Raccord',r['id'],r['sourceId']+' → '+r['targetId']]for r in connected]
 cards.append(dict(type='Assemblages',id=g['id'],title=g['label'],text=text,details=details))
for r in circuits:
 text='Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.'
 details=[['Source',r['sourceId'],r['assemblyId']],['Réception',r['targetId'],r['condition']]]+[['Sommet',str(i+1),f'X {fmt(p["x"])} ; Y {fmt(p["y"])}']for i,p in enumerate(r['points'])]
 cards.append(dict(type='Réseaux',id=r['id'],title='Raccord — '+groups[r['assemblyId']]['label'],text=text,details=details))
for u in utilities:
 text=f'Action I ; support {u["supportId"]}, pied Y {fmt(u["footY"])} et profondeur {u["depth"]}. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés.'
 details=[['Commande',u['id'],geo(u)]]+[['Lampe',k,'Récepteur réellement dessiné']for k in u['targets']]
 if u['id'] in data['round']['utilities']:details.append(['Ronde originale',str(data['round']['utilities'].index(u['id'])+1),'Doit être rallumée à son tour. La même commande hors ronde ne termine aucune quête.'])
 cards.append(dict(type='Commandes',id=u['id'],title=u['label'],text=text,details=details))
for g in scene['gates']:
 details=[['Départ',g['from'],f'Sol {nodes[g["from"]]["y"]}'],['Arrivée',g['to'],f'Sol {nodes[g["to"]]["y"]}'],['Cadre',g['id'],geo(g)],['Source',g['geometrySource'],'Géométrie native utilisée si fournie au compilateur.']]
 cards.append(dict(type='Portes',id=g['id'],title=g['label'],text='Porte historique. Cadre, feuille et seuil suivent ses dimensions ; le dessin ne crée ni nouveau verrou ni nouvelle condition d’ouverture. Une feuille ouverte ne reste pas opaque devant le chemin. La fermeture peut refuser un contact du Runner et l’accès à une commande située derrière.',details=details))
for n in nodes.values():
 links=[e for e in edges if n['id'] in (e['from'],e['to'])];owner=[s['label']for s in scene['spaces'] if n['id'] in s['nodeIds']]
 details=[['Voisin', e['to']if e['from']==n['id']else e['from'],name_kind.get(e['kind'],e['kind'])+' ; '+e['id']]for e in links]
 cards.append(dict(type='Points',id=n['id'],title=n['id'].replace('f161-','').replace('-',' '),text=f'Position X {n["x"]}, pied Y {n["y"]}, largeur {n["width"]}. Section descriptive : {", ".join(owner)or"point de liaison du graphe, hors section nommée"}. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.',details=details))
for e in edges:
 a,b=nodes[e['from']],nodes[e['to']];text=f'{name_kind.get(e["kind"],e["kind"])} entre deux points historiques ; dénivelé {b["y"]-a["y"]}. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.'
 details=[['Départ',a['id'],f'({a["x"]}, {a["y"]})'],['Arrivée',b['id'],f'({b["x"]}, {b["y"]})'],['Direction','Sens unique'if e.get('oneWay')else'Deux sens','Sous réserve des verrous et conditions hérités']]
 cards.append(dict(type='Connexions',id=e['id'],title=name_kind.get(e['kind'],e['kind'])+' — '+e['id'],text=text,details=details))
for rule in data['rules']:cards.append(dict(type='Règles',id=rule['id'],title=rule['id'],text=rule['text'],details=[['Preuve attendue',rule.get('validation',rule.get('check','scope')),'Contrat documenté ; la méthode est séparée du résultat des tests.']]))
for event in data['events']:cards.append(dict(type='États du décor',id=event['id'],title=event['label'],text=event['result']+' La consultation ou le dessin seul ne déclenche pas la transition historique.',details=[['État source',event['read'],'Les booléens explicites priment sur les raccourcis de phase.']]+[['Ensemble',id,groups[id]['label']]for id in event['assemblies']]))
for stage,instruction in enumerate(data['round']['instructions']):
 uid=data['round']['utilities'][stage]if stage<3 else None
 details=[['Cible',uid or data['round']['endNode'],'Appui réel au bon étage'],['Action','I : rallumer'if uid else'Rejoindre le point de retour','Une étape hors ordre ne se valide pas.']]
 cards.append(dict(type='Ronde originale',id='round-'+str(stage+1),title=f'{stage+1}. {instruction}',text='Parcours optionnel de l’aperçu, activé explicitement depuis son bouton. Il n’est pas injecté automatiquement dans la campagne Alien 3. Les trois circuits sont éteints au lancement de ce parcours ; aucune réserve du film n’est donnée. Une importation valide reprend en pause, sans sauter une étape.',details=details))
intro=['# ALIEN 3 — FIORINA 161','## Codex de level design V104 · Continuité et états du complexe','',
'## Portée','Ce document décrit les données réellement livrées. Il conserve vingt sections descriptives, trente ensembles et 284 composants de la base V103 retrouvée. Il n’annonce pas de nouvelles pièces mesurées à l’identique des plateaux du film. Les 72 points, 119 connexions et quatre routes restent inchangés. La géométrie de ce registre est dérivée du template ; le compilateur peut utiliser un plan natif lorsqu’il est fourni.',
'Les corrections V104 visent la cohérence entre événement, décor, accès, pause et reprise. La ronde des éclairages est un parcours original et autonome du banc, pas une reconstitution de scène ajoutée au film. Les autres DLC servent de référence de qualité de système, pas de justification pour importer armes ou créatures incompatibles.',
'', '## Règles de composition et d’usage','Les baies restent en retrait du plan jouable. Les vannes, câbles et lampes sont associés à une fonction, pas dispersés pour augmenter le nombre d’objets. Le fond couvre y=0 ; les effets locaux prennent l’appui de leur ensemble, jamais la hauteur du personnage. Les passages et l’extrémité des échelles doivent rester visibles. Une lumière de service ne modifie pas la perception du Runner tant qu’un système de furtivité compatible ne l’utilise pas explicitement.',
'', '## Cycle d’état','Au repos, les machines gardent leurs couleurs normales. Un drapeau de feu actif ajoute flammes locales et halos aux ensembles concernés ; l’après-incendie conserve la suie sans continuer à dessiner des flammes. La lueur du plomb dépend de moltenLeadApplied. Le refroidissement dépend de thermalShockApplied. La présence du matériel Patna dépend de la Compagnie, jamais de la seule abscisse du joueur. Ces cinq rendus ne produisent pas de nouveaux dégâts.',
'', '## Interactions et horloge','Une commande exige portée, étage, profondeur et chemin non coupé par une porte. Pendant un passage de profondeur, la position interpolée est prise en compte. Le plan, les archives, la pause, le chargement et la mort stoppent la couche V104 ; le temps delta est borné à 0,05 seconde. Un dessin ne modifie pas la progression. Les dommages ordinaires de feu restent ceux des couches propriétaires ; le nouveau garde de contact du Runner est un veto supplémentaire, pas une nouvelle IA.',
'', '## Sauvegardes','Les fichiers de l’aperçu sont limités à 1 Mio et validés intégralement avant remplacement : format, identité de campagne, signature de géométrie, états de portes, lampes, position appuyée, découvertes, paramètres et préfixe exact d’étapes. Une pose en l’air, dans une porte fermée ou avec une profondeur fractionnaire est refusée. L’import rouvre la partie en pause. La signature FNV détecte une incompatibilité accidentelle et n’est ni un secret ni une protection anti-triche. La reprise native V103 initialise le volet V104 sans inventer une ronde. Aucune persistance localStorage sur disque n’est certifiée.',
'', '## Contrôles exécutés',f'{unit["cases"]} cas de contrats et mixin ; {inst["cases"]} scénarios d’installation ; {browser["tests"]} contrôles Chromium sur le banc ; {delivered["tests"]} contrôles du HTML distribué sans API de test. Ces périmètres ne sont pas additionnés en une certification du jeu complet. Les 57 scripts historiques V103 ne sont pas disponibles dans cette récupération et ne sont pas présentés comme rejoués.',
'', '## Catalogue détaillé',f'{len(cards)} fiches, dont 48 règles et cinq liaisons événement-décor ; les 284 composants sont listés dans leurs assemblages, pas comptés une seconde fois comme nouveaux assets.','']
for card in cards:
 intro.extend([f'### {card["type"]} · {card["title"]}',f'Référence : `{card["id"]}`',card['text'],'','| Élément | Référence | Détail |','|---|---|---|'])
 intro.extend('| '+' | '.join(str(x).replace('|','/')for x in row)+' |'for row in card['details']);intro.append('')
intro.extend(['## Limites à lever dans le moteur principal','L’intégration dans le dépôt natif, les sprites définitifs, l’empilement de tous les anciens interactifs et effets, les collisions de production et le parcours intégral de chaque montage restent à examiner. Aucun push ni déploiement n’est annoncé. Le codex est un outil de production consultable, pas une collection obligatoire ni un score à augmenter en jouant.'])
(DOC/'ALIEN3_LEVEL_DESIGN_CODEX_V104.md').write_text('\n'.join(intro))
css='''*{box-sizing:border-box}body{margin:0;background:#0c1712;color:#dae2ce;font:15px/1.7 system-ui,sans-serif}header,main{max-width:1240px;margin:auto;padding:30px 28px}header{padding-top:44px}header small{letter-spacing:.18em;color:#a7b394}h1{font-weight:450;font-size:38px;line-height:1.2;color:#e1d7b1}h2{font-size:23px;font-weight:500;color:#d8cd9f}.scope{border-left:3px solid #b6a174;background:#223123;padding:16px 20px;margin:20px 0}.tools{display:flex;gap:10px;flex-wrap:wrap;position:sticky;top:0;z-index:2;background:#0c1712;padding:15px 0}input,select,button{background:#233828;color:#dae2ce;padding:12px;border:1px solid #597456;border-radius:5px;font:inherit}input{flex:1;min-width:200px}button{cursor:pointer}.ref{border:0;background:none;color:#c4d8a6;padding:0;font:inherit;text-align:left;text-decoration:underline}.count{font-size:13px;color:#a0b696;margin:8px 0 25px}article,section.panel{background:#14241a;border:1px solid #354b35;border-radius:9px;padding:21px;margin:0 0 21px}article h2{margin:9px 0}small,.caption{color:#a2b093;font-size:12px}table{width:100%;border-collapse:collapse;font-size:12px;margin:13px 0}td,th{text-align:left;vertical-align:top;border-bottom:1px solid #364b35;padding:8px;overflow-wrap:anywhere}th{color:#cec69e;background:#223721}summary{cursor:pointer;color:#bfd2ae}img{width:100%;height:auto;display:block;border:1px solid #486540;margin:16px 0}code{font-size:12px;overflow-wrap:anywhere}a{color:#c4d8a6}@media(max-width:650px){header,main{padding:22px 14px}h1{font-size:28px}article{padding:14px}table{display:block;overflow:auto}}'''
esc=escape
app='''const cards=__DATA__,q=document.querySelector('#search'),f=document.querySelector('#kind'),box=document.querySelector('#cards');const norm=s=>String(s).normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase();const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const ids=new Set(cards.map(c=>c.id));const cell=s=>{const v=String(s),dest=ids.has(v)?v:ids.has(v.split('/')[0])?v.split('/')[0]:null;return dest?'<button class=\"ref\" data-jump=\"'+esc(dest)+'\">'+esc(v)+'</button>':esc(v);};function render(){const term=norm(q.value),a=cards.filter(c=>(f.value==='Tout'||c.type===f.value)&&(!term||norm(JSON.stringify(c)).includes(term)));document.querySelector('#count').textContent=a.length+' fiches affichées sur '+cards.length;box.innerHTML=a.map(c=>'<article id="'+esc(c.id)+'"><small>'+esc(c.type)+' · '+esc(c.id)+'</small><h2>'+esc(c.title)+'</h2><p>'+esc(c.text)+'</p>'+(c.details.length?'<details><summary>Détails et coordonnées</summary><table><thead><tr><th>Élément</th><th>Référence</th><th>Détail</th></tr></thead><tbody>'+c.details.map(row=>'<tr>'+row.map(s=>'<td>'+cell(s)+'</td>').join('')+'</tr>').join('')+'</tbody></table></details>':'')+'</article>').join('');}box.addEventListener('click',ev=>{const b=ev.target.closest('[data-jump]');if(!b)return;q.value='';f.value='Tout';render();const article=document.getElementById(b.dataset.jump);article?.scrollIntoView({block:'center'});if(article){article.tabIndex=-1;article.focus({preventScroll:true});}});q.addEventListener('input',render);f.addEventListener('change',render);render();'''.replace('__DATA__',json.dumps(cards,ensure_ascii=False).replace('</script','<\\/script'))
filters=''.join('<option>'+esc(x)+'</option>'for x in ['Tout',*dict.fromkeys(c['type']for c in cards)])
html=f'''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Alien 3 — Codex V104</title><style>{css}</style><header><small>FIORINA 161 / DOCUMENT DE CONCEPTION V104</small><h1>Continuité et états du complexe</h1><p>{len(cards)} fiches issues des données livrées : pièces descriptives, ensembles, composants, raccords, commandes, portes, points et connexions, règles et états.</p></header><main><div class="scope">Ce codex est extérieur au jeu. Les vingt sections décrivent le niveau historique ; elles ne sont pas vingt nouvelles cartes. Le correctif et l’aperçu ne constituent pas le jeu Tantalus complet. La ronde des éclairages est originale et facultative.</div><div class="tools"><input id="search" type="search" aria-label="Rechercher dans le codex" placeholder="Lieu, lampe, étage, sauvegarde…"><select id="kind" aria-label="Catégorie">{filters}</select></div><p id="count" class="count" aria-live="polite"></p><div id="cards"></div></main><script>{app}</script></html>'''
(ROOT/'ALIEN3_CODEX_LEVEL_DESIGN_V104.html').write_text(html)
counts={k:sum(c['type']==k for c in cards)for k in dict.fromkeys(c['type']for c in cards)}
(Q/'documentation.json').write_text(json.dumps({'cards':len(cards),'byCategory':counts,'componentsNested':len(props),'markdownLines':len(intro)},ensure_ascii=False,indent=2))
# Native capture captions and scope, fully embedded for portability.
labels={
'01_ronde_depart':('Départ de la ronde','Parcours continu. Les trois lampes sont éteintes au lancement explicite de la ronde originale.'),
'02_cellules_retablies':('Cellules rétablies','Parcours continu. La lampe de soin et l’éclairage des cellules ont été rallumés avec I à leur commande réelle.'),
'03_atelier_retabli':('L’atelier à l’étage','Parcours continu après export et import sur une page neuve. La même échelle est montée au clavier avant d’utiliser la lampe.'),
'04_ronde_terminee':('Retour dans la salle commune','Parcours continu. Trois commandes, deux portes ouvertes et retour au bon niveau. Ce résultat ne termine aucune mission du film.'),
'05_plan_releve':('Plan après la traversée','Le plan provient des positions visitées pendant la ronde, pas d’une liste de découvertes injectée.'),
'06_archives':('Archives de Fiorina','Interaction dans le banc. Les archives sont disponibles pour inspection ; ce n’est pas un déverrouillage complet obtenu en campagne.'),
'07_avant_le_feu':('Avant l’incendie','État préparé pour inspecter le raccord des événements. Le nom de chapitre seul ne force plus la coulée ni un feu.'),
'08_incendie':('Départ du feu','État préparé. Le drapeau de feu actif pilote les foyers locaux et les halos. La nouvelle couche ne crée pas de dégâts.'),
'09_suie':('Après l’incendie','État préparé après résolution. Les dépôts restent visibles, sans continuer à dessiner la flamme.'),
'10_coulee':('Coulée','État préparé. La lueur provient de moltenLeadApplied, et non d’une interprétation générale du nom de phase.'),
'11_refroidissement':('Refroidissement','État préparé. La vapeur du moule et du collecteur dépend de thermalShockApplied ; elle ne valide pas le piège à la place du joueur.'),
'12_arrivee_compagnie':('Arrivée de la Compagnie','État préparé. Huit composants de récupération apparaissent avec l’arrivée, pas avec la position horizontale.'),
'13_hud_discret':('HUD au repos','État préparé. Les panneaux de lieu et de santé s’effacent ; une action proche ou une santé critique peuvent rester visibles.')}
sections=[]
for shot in browser['captures']:
 name=Path(shot['file']).stem;title,caption=labels[name];raw=(ROOT/shot['file']).read_bytes();sections.append(f'<section class="panel"><h2>{esc(title)}</h2><p>{esc(caption)}</p><img alt="Capture native Chromium du banc local : {esc(title)}" src="data:image/png;base64,{base64.b64encode(raw).decode()}"><p class="caption">1280 × 720 · renderer partagé V101–V104 · personnages provisoires et contrôleur simplifié · SHA-256 {hashlib.sha256(raw).hexdigest()[:16]}…</p></section>')
report=f'''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Alien 3 — Rapport illustré V104</title><style>{css}</style><header><small>FIORINA 161 / RAPPORT V104</small><h1>Le complexe garde les traces du passage</h1><p>Mise à niveau de standards vérifiables, ronde terminable et états environnementaux raccordés aux événements existants.</p></header><main><div class="scope">Correctif incrémental pour V103 et aperçu autonome. Les images suivantes sont des captures natives du canvas dans Chromium, pas des reconstitutions illustrées après coup. Elles montrent un banc local, pas le moteur complet avec ses sprites définitifs. Aucun push, déploiement ou build complet n’est annoncé.</div><section class="panel"><h2>Preuves exécutées</h2><table><tr><th>Contrôle</th><th>Résultat</th><th>Portée</th></tr><tr><td>Contrats V104</td><td>{unit['cases']} cas</td><td>Données et mixins sur une base instrumentée</td></tr><tr><td>Installation</td><td>{inst['cases']} scénarios</td><td>Sources V103 exactes et projets synthétiques</td></tr><tr><td>Chromium</td><td>{browser['tests']} contrôles</td><td>Ronde continue et états préparés séparés</td></tr><tr><td>HTML distribué</td><td>{delivered['tests']} contrôles</td><td>Horloge normale, sans API de test</td></tr></table><p>La ronde a été menée au clavier, avec ouverture de portes, montée et descente d’échelle, export à mi-parcours puis import sur page neuve. Les {browser['round']['seconds']:.2f} secondes simulées mesurent un robot connaissant l’itinéraire, pas une durée annoncée pour un joueur.</p></section>{''.join(sections)}</main></html>'''
(ROOT/'RAPPORT_ILLUSTRE_V104.html').write_text(report)
(Q/'captions.json').write_text(json.dumps(labels,ensure_ascii=False,indent=2))
qa=f'''# QA V104 — Continuité du complexe

## Résultats exécutés
- {unit['cases']} cas de contrats et mixins V104.
- {inst['cases']} scénarios d’installation synthétiques.
- {browser['tests']} contrôles Chromium et 13 captures natives.
- {delivered['tests']} contrôles du HTML distribué sans API de test, avec horloge normale.

Ces catégories ne s’additionnent pas en un score de campagne. Les scripts historiques de la V103 complète n’ont pas été récupérés dans cette session et ne sont pas déclarés rejoués.

## Ronde continue
Trois lampes rallumées dans l’ordre, deux portes ouvertes, échelle montée puis descendue, retour en salle commune au bon étage. Export réel après la deuxième lampe, import réel sur page neuve, continuation de la même ronde. Aucun déplacement ni état de progression n’a été injecté dans ce parcours. Durée robot : {browser['round']['seconds']:.2f} secondes simulées ; ce n’est pas une durée de jeu annoncée.

## États préparés
Les captures du feu, de la suie, de la coulée, du refroidissement, de la Compagnie et du HUD au repos utilisent des états de test explicitement choisis. Elles ne sont pas des événements remportés au cours de la ronde. Cette ronde de maintenance ne possède pas de prédateur actif.

## Correction importante
La donnée existante du plomb est `alien3V88.moltenLeadApplied`, celle du choc thermique `thermalShockApplied`, et le feu dispose de `alien3V90.firePlan.ignited` / `accidentResolved`. Les booléens explicites priment. La couche ne se contente plus de passer toute la fonderie en état chaud à cause d’un nom de chapitre.

## Installation
La mise à jour gère trois nouveaux modules et un raccord de moteur sur une base V103 reconnue. Les sources héritées exactes, les chemins et les modifications concurrentes sont vérifiés. Une validation du projet qui modifie des sources gérées est refusée plutôt que d’installer des octets différents de ceux vérifiés. Les commandes npm des tests sont synthétiques : aucun build natif du jeu n’est certifié.

## Limites
Le contrôleur du banc est simplifié, les personnages provisoires et la campagne complète absente de la validation. Les sprites définitifs, l’IA native, l’empilement de tous les anciens interactifs, le chemin intégral de chaque montage, la manette matérielle et Safari/iPhone restent à éprouver. Aucun push ni déploiement. Le rendu n’est pas photoréaliste ni certifié 1:1 au film.

## Preuves
`qa-v104/unit.json`, `installation.json`, `browser.json`, `delivered-html.json`, `preview-sources.json`, `design-source.json`, `captures/`.
'''
(ROOT/'RAPPORT_QA_V104.md').write_text(qa)
readme=f'''# Alien 3 — Fiorina 161 V104

**Correctif incrémental sur V103 + aperçu autonome. Ce n’est pas le jeu principal complet ni une nouvelle archive cumulative V88–V104.**

La base de cette livraison est le véritable HTML autonome V103 « Passages et réseaux », retrouvé dans la Bibliothèque, dont les 22 modules incorporés ont été extraits sans modifier leurs sources. Le ZIP cumulatif V103 a été localisé mais ses octets bruts n’ont pas pu être matérialisés par l’accès disponible. Le fichier `sources-v103-recovered.json` décrit les modules récupérés et leurs empreintes. Les 21 fichiers sous `src/` sont des sources de référence requises pour vérifier la compatibilité ; l’installateur n’en écrase aucun.

## Ouvrir
- `FIORINA_V104_JOUER.html` : aperçu autonome sans téléchargement externe.
- `ALIEN3_CODEX_LEVEL_DESIGN_V104.html` : codex de conception avec {len(cards)} fiches recherchables.
- `RAPPORT_ILLUSTRE_V104.html` et `.pdf` : captures natives et limites.
- `docs/MATRICE_ALIGNEMENT_V104.md` : standards vérifiés dans les autres DLC et statut de leur adaptation.

Le bouton **Commencer la ronde** lance un parcours original optionnel : rallumer trois lampes, franchir deux accès et revenir en salle commune. Ce parcours n’est pas automatiquement greffé à la campagne historique. Le sélecteur de lieu et celui des événements sont explicitement des outils d’inspection, pas de progression narrative. Les archives de l’aperçu restent ouvertes à l’inspection.

## Commandes
Flèches / A-D / Q-D : déplacement ; Espace : saut ; Haut/Bas : échelle ou profondeur selon le lieu ; E : porte proche ; I : éclairage local ; M : plan ; C : archives ; Échap : fermer ou mettre en pause. Les paramètres permettent mouvement réduit, contraste du HUD et affichage permanent. Le haut du décor reste couvert dès y=0.
Exporter/Importer manipulent de vrais fichiers JSON, limités à 1 Mio. L’import valide l’identité, la géométrie, l’ordre des étapes, les lampes, portes et la pose avant de remplacer l’état ; il reprend en pause. Aucun localStorage sur disque n’est certifié. Le format de fichier V104 n’est pas annoncé compatible avec un hypothétique export de l’ancien aperçu V103.

## Installer dans une copie V103
Node.js 20 ou ultérieur. Extraire ce paquet hors du dossier cible et conserver une sauvegarde personnelle.

```sh
node scripts/install-v104.mjs /chemin/vers/projet-V103 --dry-run
node scripts/install-v104.mjs /chemin/vers/projet-V103
```

L’installation exige la signature exacte des sources V103 connues et les raccords du moteur. Un fichier modifié localement est refusé pour ne pas l’écraser. Trois nouveaux modules et un seul raccord de moteur sont gérés. La préparation s’effectue dans une copie temporaire, puis `npm run check` et `npm run build` du projet sont exécutés avant report des sources. Les scénarios de livraison utilisent des fixtures synthétiques, pas un checkout natif validé.
`--skip-project-check` est un diagnostic explicitement sans certification du projet, pas une façon de contourner une incompatibilité de source. Le script refuse une autre base au lieu d’appliquer un empilement incomplet.

## Restaurer
Le résultat d’installation fournit un reçu de récupération situé hors de la distribution publique.

```sh
node scripts/install-v104.mjs --restore /chemin/vers/receipt.json
```

Le retour refuse d’écraser les changements faits après installation. Aucune sauvegarde utilisateur du navigateur n’est réécrite par l’installateur.

## Reproduire
```sh
node scripts/test-v104.mjs > qa-v104/unit.json
node scripts/test-install-v104.mjs > qa-v104/installation.json
python scripts/verify-browser-v104.py
python scripts/verify-delivered-v104.py
python scripts/build-docs-v104.py
python scripts/build-pdf-v104.py
python scripts/verify-codex-v104.py
```

Python Playwright et Chromium sont nécessaires pour les captures ; ReportLab et une police DejaVu Sans locale pour le PDF. Les scripts ne téléchargent rien. Le code et l’API d’inspection du banc ne sont pas présents dans le HTML livré à l’utilisateur sous forme d’API publique ; seule une variable injectée avant chargement par les tests active cette instrumentation.

## Limites de livraison
Aucun build complet avec le moteur principal et ses assets, aucun parcours intégral du film, aucune nouvelle IA autonome de chasse, aucun push GitHub et aucun déploiement Vercel. Les tests V104 et leurs portées priment sur les anciens résumés du projet. Les différences de gameplay avec Aliens, Romulus et Resurrection restent intentionnelles.
'''
(ROOT/'README.md').write_text(readme)
(ROOT/'CHANGELOG_V104.md').write_text('''# V104 — Continuité du complexe

- Raccord visuel aux vrais drapeaux de feu, plomb et choc thermique ; traces de suie persistantes.
- HUD contextuel avec vitales critiques, options de contraste et de mouvement.
- Contrôle supplémentaire des morsures : distance, étage, profondeur interpolée, portes.
- Horloge V104 arrêtée par les interfaces, pause et chargement ; dessin sans progression.
- Ronde originale locale terminable et export/import atomique au niveau de la validation.
- Correctif incrémental de trois modules sur V103, sans écraser les sources héritées.
- Matrice inter-DLC, codex généré depuis les données et captures natives Chromium.
''')
print(json.dumps({'cards':len(cards),'byCategory':counts,'mdLines':len(intro),'images':len(browser['captures'])},ensure_ascii=False))
