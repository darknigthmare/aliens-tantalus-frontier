#!/usr/bin/env python3
"""Illustrated PDF, native screenshots and separately identified renderer exports."""
from pathlib import Path
from xml.sax.saxutils import escape
import json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape,A4
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=Path(__file__).resolve().parents[1];Q=R/'qa-v105';b=json.loads((Q/'browser.json').read_text());u=json.loads((Q/'unit.json').read_text());i=json.loads((Q/'installation.json').read_text());doc=json.loads((Q/'documentation.json').read_text());c=json.loads((Q/'codex-browser.json').read_text());dh=json.loads((Q/'delivered.json').read_text())
for name,file in [('Body','DejaVuSans.ttf'),('Strong','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(name,str(Path('/usr/share/fonts/truetype/dejavu')/file)))
W,H=landscape(A4);M=34;CW=W-2*M;BG=HexColor('#0e1a13');INK=HexColor('#dce6d0');MUTED=HexColor('#aebda6');LINE=HexColor('#445b3e');GOLD=HexColor('#cdb786')
styles={k:ParagraphStyle(k,fontName='Body',fontSize=f,leading=l,textColor=MUTED if k in ['small','caption'] else INK)for k,f,l in [('body',11,16),('caption',9.2,13),('small',9,12.7),('cell',9.5,13.5)]}
pdf=canvas.Canvas(str(R/'RAPPORT_ILLUSTRE_V105.pdf'),pagesize=(W,H),pageCompression=1);pdf.setTitle('ALIEN 3 — Fiorina 161 V105 — Traques et préparatifs');pdf.setAuthor('Aliens: Tantalus Frontier / dossier de développement');total=4+len(b['screenshots']);pn=0

def para(text,x,top,width,style='body',maxh=None):
 p=Paragraph(text,styles[style]);_,h=p.wrap(width,999)
 if maxh and h>maxh:raise ValueError(f'Overflow {h}>{maxh}: {text[:65]}')
 p.drawOn(pdf,x,top-h);return h

def page(title,section):
 global pn;pn+=1
 pdf.setFillColor(BG);pdf.rect(0,0,W,H,fill=1,stroke=0);pdf.setFillColor(GOLD);pdf.setFont('Strong',9);pdf.drawString(M,H-24,'ALIEN 3  /  FIORINA 161');pdf.setFont('Body',8);pdf.drawRightString(W-M,H-24,'V105  ·  '+section);pdf.setFillColor(INK);pdf.setFont('Strong',24)
 if pdfmetrics.stringWidth(title,'Strong',24)>CW:raise ValueError(title)
 pdf.drawString(M,H-57,title);pdf.setStrokeColor(LINE);pdf.line(M,29,W-M,29);pdf.setFillColor(MUTED);pdf.setFont('Body',7.5);pdf.drawString(M,16,'Banc local · renderer partagé · silhouettes vectorielles · pas de campagne native complète certifiée');pdf.drawRightString(W-M,16,f'{pn:02d} / {total}')

def image(file,top=H-76):
 h=CW*720/1280;pdf.drawImage(str(R/file),M,top-h,width=CW,height=h,preserveAspectRatio=True,mask='auto');pdf.setStrokeColor(LINE);pdf.rect(M,top-h,CW,h,stroke=1,fill=0);return top-h

def table(rows,top,widths):
 t=Table([[Paragraph(escape(str(x)),styles['cell'])for x in row]for row in rows],colWidths=widths);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#2c3d25')),('BACKGROUND',(0,1),(-1,-1),HexColor('#172b1b')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,-1),.5,LINE)]));_,h=t.wrap(CW,600);t.drawOn(pdf,M,top-h);return top-h
page('Traques et préparatifs','VERSION LOCALE CANDIDATE')
y=image('qa-v105/captures/08_attaque_annoncee.png');para('Le Runner rejoint le moule et annonce son attaque. Cette image est une <b>capture native du parcours au clavier</b>, pas une mise en scène reconstruite après coup. Deux séquences originales vérifient la chasse et les postes tenus ; elles ne constituent pas la campagne intégrale du film.',M,y-10,CW,'caption',40);pdf.showPage()
page('Les cinq axes : réalisé, puis restant','PÉRIMÈTRE')
y=table([['Axe','Travail livré','Limite conservée'],['Intégration','Préflight GitHub et installeur V104→V105 en copie temporaire.','Le dépôt natif reste V86. Aucun build complet ni déploiement.'],['Runner','Patrouille, vue, bruit, trace, recherche, poursuite et attaque annoncée.','Pilote activé explicitement dans les deux séquences originales.'],['Détenus','Morse et Dillon rejoignent réellement leurs postes avant le piège.','Ce test ne reproduit pas la mort de Dillon ni le final de Ripley.'],['Repères','Cinq familles redessinées ; humains différenciés et Runner animé.','Art vectoriel stylisé, pas assets finaux certifiés 1:1.'],['Ambiance','Audio optionnel, pan local et arrêt en pause ; quatre styles de parcours.','Activation technique vérifiée, pas écoute matérielle ni testeurs humains.']],H-83,[125,330,CW-455])
para('Le contrôle du dépôt a lu <b>package.json</b> et le raccord du moteur au commit 496996f5ea557d970ec625aa346876f3eaed1c5f. La classe publique reste V86ProductionEngine. Le correctif demande V104ProductionEngine et refuse une installation aveugle sur V86.',M,y-20,CW,'small',65);pdf.showPage()
page('Des parcours, pas seulement des états','VÉRIFICATIONS')
rows=[['Profil automatisé','Résultat','Santé finale','Attaques / évitées','Temps simulé']]
for route in b['routes']:
 s=route['result'];st=s['pursuit']['stats'];rows.append([route['profile'],'Terminé',s['hp'],f'{st["attacks"]} / {st["misses"]}',f'{s["clock"]:.2f} s'])
y=table(rows,H-84,[192,100,98,172,CW-562]);y-=20
para('Les temps mesurent un robot connaissant le chemin et utilisant les gestionnaires du clavier à 60 Hz. Aucune position, arrivée de détenu ou progression n’est injectée pendant ces traversées. Le parcours exploratoire est exporté puis repris sur une nouvelle page. Le test de mort utilise, lui, des positions préparées et reste séparé.',M,y,CW,'body',68);y-=78
para(f'<b>{u["cases"]} cas unitaires</b>, <b>{i["cases"]} scénarios d’installation</b>, six groupes Chromium ({b["controlsExecuted"]} assertions, {b["uniqueControlNames"]} libellés distincts), {dh["tests"]} contrôles du fichier autonome sans API QA et {c["tests"]} contrôles du codex. Les 37 tests et 15 fixtures V104 sont rejoués séparément. Ces preuves ne s’additionnent pas en certification de la campagne complète.',M,y,CW,'small',65);pdf.showPage()
titles=['Consigne d’Aaron','Le relevé dans l’atelier','Retour vivant à l’infirmerie','Le plan suspend la chasse','Archives pendant la traversée','Attendre Morse','Deux postes réellement tenus','Une attaque annoncée','La coulée dans le moule','Retour au collecteur','Rejoindre Morse','Échec et reprise']
for index,shot in enumerate(b['screenshots']):
 page(titles[index],f'CAPTURE NATIVE {index+1:02d} / {len(b["screenshots"])}');y=image(shot['file']);scope='Test dirigé : positions préparées pour vérifier l’échec.'if'directed'in shot['scope']else'Parcours continu au clavier dans le banc local.';para(shot['caption']+' '+scope+' Renderer partagé avec les modules livrés ; physique de base simplifiée.',M,y-10,CW,'caption',40);pdf.showPage()
page('Exports séparés, mêmes fonctions de dessin','ATELIER VISUEL')
labels=[('eev','EEV'),('cell','Cellules'),('pump','Pompe'),('mold','Moule'),('furnace','Four')]
for n,(file,label)in enumerate(labels):
 x=M+n*(CW/5);pdf.drawImage(str(R/'assets-v105'/f'{file}.png'),x+8,H-260,width=CW/5-16,height=160,preserveAspectRatio=True,mask='auto');pdf.setFillColor(INK);pdf.setFont('Strong',11);pdf.drawCentredString(x+CW/10,H-285,label)
para('Les cinq familles conservent leurs appuis, dimensions et collisions hérités. Les dix PNG transparents sont des exports de référence : le jeu dessine directement les fonctions vectorielles, il ne charge pas ces atlas. Aucune finalisation photographique ou fidélité 1:1 au film n’est annoncée.',M,H-313,CW,'body',64)
para('<b>48 poses d’acteurs :</b> huit poses de marche pour Ripley, Aaron, Morse et Dillon ; seize poses de locomotion, préparation et récupération pour le Runner. Les ancrages de pieds, les dimensions de cellule et les empreintes sont fournis dans assets-v105/atlas.json.',M,H-400,CW,'body',64)
para(f'<b>Codex :</b> {doc["cards"]} fiches dont {doc["newCards"]} contrats V105. Les identifiants des sections et des assemblages homonymes ont été séparés pour éviter des liens ambigus.',M,H-485,CW,'small',40);pdf.showPage()
assert pn==total;pdf.save();print(json.dumps({'ok':True,'pages':pn,'bytes':(R/'RAPPORT_ILLUSTRE_V105.pdf').stat().st_size}))
