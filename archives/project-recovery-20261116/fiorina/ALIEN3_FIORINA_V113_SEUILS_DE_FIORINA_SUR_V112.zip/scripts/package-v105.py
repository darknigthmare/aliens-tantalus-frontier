from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parents[1];out=R.parent/'ALIEN3_FIORINA_V105_TRAQUES_PREPARATIFS_SUR_V104.zip';manifest=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name=='manifest-v105.json' or '__pycache__'in p.parts:continue
 data=p.read_bytes();manifest.append({'path':p.relative_to(R).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(R/'manifest-v105.json').write_text(json.dumps({'schema':105,'scope':'Incremental patch on V104, native production build NOT executed','files':manifest,'count':len(manifest)},ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(R.rglob('*')):
  if p.is_file()and'__pycache__'not in p.parts:z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(out)as z:assert z.testzip() is None
print(json.dumps({'ok':True,'manifestFiles':len(manifest),'archive':out.name,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
