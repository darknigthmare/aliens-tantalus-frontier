#!/usr/bin/env python3
from pathlib import Path
import json,shutil,hashlib
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'qa-v104';checks=[]
def check(name,ok):
 if not ok:raise AssertionError(name)
 checks.append({'name':name,'ok':True})
with sync_playwright()as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':1280,'height':960});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((ROOT/'FIORINA_V104_JOUER.html').read_text(),wait_until='load');page.wait_for_timeout(180)
 check('Delivered HTML does not expose the inspection API',not page.evaluate('"fiorinaBench" in window'))
 page.locator('#round').click();page.wait_for_timeout(120)
 with page.expect_download()as dl:page.locator('#export-save').click()
 first=OUT/'delivered-before.json';dl.value.save_as(str(first));a=json.loads(first.read_text())
 check('Native menu launches the original round',a['state']['round']['stage']==0)
 page.locator('canvas').focus();page.keyboard.down('ArrowRight');page.wait_for_timeout(420);page.keyboard.up('ArrowRight');page.keyboard.press('KeyI');page.wait_for_timeout(110)
 with page.expect_download()as dl:page.locator('#export-save').click()
 second=OUT/'delivered-after.json';dl.value.save_as(str(second));c=json.loads(second.read_text())
 check('Normal animation clock advances without a QA tick API',c['state']['clock']>a['state']['clock'])
 check('Real keyboard movement is reflected in an exported file',c['pose']['x']>a['pose']['x'])
 check('A real I command at the care lamp advances the first objective',c['state']['round']['stage']==1)
 check('No JavaScript error in the delivered HTML path',not errors)
 b.close()
result={'ok':True,'tests':len(checks),'scope':'Final HTML without QA API, normal requestAnimationFrame clock, actual keyboard and file downloads','checks':checks,'before':a['pose'],'after':c['pose'],'sha256':hashlib.sha256((ROOT/'FIORINA_V104_JOUER.html').read_bytes()).hexdigest()}
(OUT/'delivered-html.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({'ok':True,'tests':len(checks)}))
