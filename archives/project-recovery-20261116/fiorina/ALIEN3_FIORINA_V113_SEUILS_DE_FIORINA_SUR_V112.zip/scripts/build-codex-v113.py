#!/usr/bin/env python3
from pathlib import Path
from html import escape as esc
import json,re,subprocess,collections
R=Path(__file__).resolve().parents[1];Q=R/'qa-v113';D=R/'docs';D.mkdir(exist_ok=True)
subprocess.run(['node',str(R/'scripts/export-design-v113.mjs')],check=True)
src=json.loads((Q/'design-source.json').read_text());old=(R/'ALIEN3_CODEX_LEVEL_DESIGN_V112.html').read_text();start=old.index('const cards=')+len('const cards=');cards,end=json.JSONDecoder().raw_decode(old[start:]);assert len(cards)==685
new=[]
def add(kind,id,title,text,details=[]):new.append({'type':kind,'id':id,'title':title,'text':text,'details':details})
refIds={r['id']:'ref113-'+r['id'] for r in src['references']}
refs=lambda ids:[[ 'Référence',refIds[x],'Source de comparaison, indépendante du statut de dessin ou de simulation.' ]for x in ids]
fmt=lambda n:f'{n:.2f}'.rstrip('0').rstrip('.')
for r in src['references']:
 add('Références V113',refIds[r['id']],r['title'],r['fact']+' Type de preuve : '+r['type']+'. Consultation le 29 septembre 2026 ; les pages de vente servent uniquement de description de pièces de production. Aucun média du film n’est inclus.',[['Source',r['url'],'Description de production ou piste secondaire identifiée. Ni prix ni disponibilité commerciale ne sont utilisés.']])
for p in src['portals']:
 box=lambda key:'X '+fmt(p[key]['x'])+', Y '+fmt(p[key]['y'])+', '+fmt(p[key]['w'])+' × '+fmt(p[key]['h'])
 add('Seuils V113','portal113-'+p['id'],p['title'],p['reason']+' Le passage utilise toujours la collision et le verrou existants. Le volet segmenté se replie vers son coffre ; ouvert, il ne laisse pas de masse opaque. Ces retours de cloison améliorent la cohérence locale, pas la preuve d’un emplacement identique à celui du film.',[
 ['Connexion',p['edgeId'],'Propriétaire unique du verrou : '+p['collisionOwner']],['Depuis',p['from'],'Appui conservé.'],['Vers',p['to'],'Appui conservé.'],['Ouverture',p['id'],box('opening')+' ; pied Y '+fmt(p['foot'])],['Coffre','rule113-volet-rangement',box('housing')],['Montant gauche','rule113-seuil-proprietaire',box('leftPier')],['Montant droit','rule113-seuil-proprietaire',box('rightPier')],['Retour gauche','rule113-seuil-proprietaire',box('leftReturn')],['Retour droit','rule113-seuil-proprietaire',box('rightReturn')],['Seuil','rule113-seuil-proprietaire',box('threshold')],['Fidélité','rule113-absence-visible','Position héritée, non comparée à une géométrie mesurée du film. Aucun changement de topologie.']])
status={'runtime':'Silhouette utilisée par un participant existant','catalogue-only':'Fiche seulement, pas de personnage jouable ajouté','scenery':'Élément de décor sur appui','arrival-render-only':'Visuel conditionnel à l’arrivée, sans nouvelle IA','inherited-runtime':'Comportement et dessin historiques conservés'}
for c in src['cast']:
 desc=status[c['status']]+'. Modèle '+c['shape']+'. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.'
 if c['id']=='ripley':desc+=' Le rig distingue arrivée en gris, tenue carcérale brune avec coutures croisées et manteau extérieur vert. Le changement dépend d’un état explicite, pas du dessin.'
 if c['id']=='dillon':desc+=' Corps plus large, manteau, gilet et capuche distincts ; aucune taille de collision modifiée.'
 if c['id']in ['morse','aaron']:desc+=' Morphologie et couche de vêtements distinctes. Référence précise de costume encore à compléter.'
 add('Personnages V113','cast113-'+c['id'],c['name'],desc,refs(c['references'])+[['Statut','rule113-absence-visible',status[c['status']]],['Rendu','rule113-dessin-pur','Le dessin ne crée ni arrivée, ni inventaire, ni participant.'],['Équipement','rule113-arme-proprietaire',', '.join(c['equipment'])or'Aucun nouvel équipement attribué.']])
for e in src['equipment']:
 add('Équipement V113','item113-'+e['id'],e['title'],e['notes']+f' Propriétaire : {e["owner"]}. Usage : {e["role"]}. Preuve : {e["evidence"]}. État réel : {e["implemented"]}. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.',refs(e['references'])+[['Porteur','cast113-'+e['owner']if any(c['id']==e['owner']for c in src['cast'])else'rule113-arme-proprietaire',e['owner']]]+[['Appui',n,'Appui hérité ; aucun déplacement arbitraire de l’objet.']for n in e['nodeIds']]+[['Objets liés','rule113-absence-visible',', '.join(e['boundIds'])or'Aucun objet de décor lié : garder le manque visible.']])
cut={'both':'Cinéma et Assembly, comparaison séparée requise','assembly':'Assembly seulement dans ce registre','theatrical':'Cinéma seulement dans ce registre'}
for l in src['locations']:
 add('Lieux et scènes V113','place113-'+l['id'],l['title'],cut[l['cuts']]+'. '+l['problem']+' Statut : '+('repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film.'if l['nodeIds']else'aucune géométrie dédiée liée dans le modèle actuel.')+' Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.',[['Montage','rule113-chronologie',cut[l['cuts']]],['Preuve','rule113-absence-visible','Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.']]+[['Point',n,'Coordonnée du jeu, pas une mesure du film.']for n in l['nodeIds']]+([['Repérage secondaire','ref113-cut-register','Différences à rapprocher d’une copie autorisée ; pas de séquence native entière validée.']]if l['cuts']!='both'or l['id']=='morgue'else []))
for r in src['rules']:
 add('Règles V113','rule113-'+r['id'],r['id'].replace('-',' ').capitalize(),r['text'],[['Contrôle','qa-v113/unit.json','Contrats instrumentés, puis comparaison de captures et parcours clavier séparés.']])
cards+=new;assert len(cards)==770 and len({c['id']for c in cards})==770 and len(new)==85
out=old[:start]+json.dumps(cards,ensure_ascii=False).replace('</script','<\\/script')+old[start+end:]
out=out.replace('DOCUMENT DE CONCEPTION V112','DOCUMENT DE CONCEPTION V113').replace('<h1>Laisser passer</h1>','<h1>Seuils de Fiorina</h1>').replace('685 fiches issues','770 fiches issues')
out=out.replace('</select></div>',''.join('<option>'+esc(t)+'</option>'for t in dict.fromkeys(c['type']for c in new))+'</select></div>',1)
scope='Codex de conception hors jeu. V113 relie les portes à une architecture, reprend quatre silhouettes et ajoute quatre objets ancrés. Le registre distingue référence, dessin, gameplay et manque : 19 repères de lieux liés sur 25 entrées, six non liés. Aucune pièce n’est certifiée 1:1. Les deux colonnes de montage ne sont pas deux campagnes terminées.'
out=re.sub(r'<div class="scope">.*?</div>','<div class="scope">'+scope+'</div>',out,count=1,flags=re.S)
(R/'ALIEN3_CODEX_LEVEL_DESIGN_V113.html').write_text(out);(Q/'codex-source.json').write_text(json.dumps(cards,ensure_ascii=False,indent=2)+'\n')
md=['# ALIEN 3 — FIORINA 161 · CODEX DE LEVEL DESIGN V113','','## Périmètre',scope,'770 fiches, dont 85 nouveaux contrats. Les 284 composants historiques restent dans leurs assemblages ; les quatre objets de V113 sont identifiés séparément. Les trois portes restent à leur emplacement de gameplay hérité : la passe leur donne des appuis et des retours de cloison, sans en déduire une position film certifiée.','','## Couverture mesurée','| Lieu ou scène | Montage | Repères liés | Reste à vérifier |','|---|---|---:|---|']
for l in src['locations']:md.append(f'| {l["title"]} | {l["cuts"]} | {len(l["nodeIds"])} | {l["problem"]} |')
md+=['','## Équipement : statut indépendant du catalogue','| Objet | Propriétaire | État réel | Éléments liés |','|---|---|---|---|']
for e in src['equipment']:md.append(f'| {e["title"]} | {e["owner"]} | {e["implemented"]} | {len(e["boundIds"])} |')
md+=['','## Méthode de validation','Une porte doit être reliée à un rectangle réel, un lien existant et un appui. Les retours de cloison sont en retrait, sans nouvelle collision cachée. Le même état de porte gouverne le verrou, le dessin, les interactions et les anciens systèmes. Les tests de cette version ne remplacent pas un nouveau parcours exhaustif de chacun des 119 liens.','Les personnages dessinés conservent leurs collisions, positions, vitesse, destinations, ordres et sauvegardes. Les agents de récupération sont des visuels conditionnels, pas de nouveaux combattants. Le changement du propriétaire V105 est limité à deux délégations de dessin facultatives ; ses autres méthodes restent inchangées.','La fidélité scène par scène reste ouverte : prologue du Sulaco, hôtes selon montage, bureau d’Andrews, confinement de Golic, intérieur de récupération et raccord de la morgue font partie des manques signalés. Les parcours de traque et rabattage du banc sont originaux, pas une reconstitution intégrale du film.','','## Registre détaillé','']
for c in cards:
 md += ['### '+c['title'],f'`{c["id"]}` · {c["type"]}','',c['text'],'']
 for title,ref,text in c.get('details',[]):md += [f'**{title}** — `{ref}` : {text}','']
(D/'ALIEN3_LEVEL_DESIGN_CODEX_V113.md').write_text('\n'.join(md))
(Q/'documentation.json').write_text(json.dumps({'cards':len(cards),'newCards':len(new),'types':dict(collections.Counter(c['type']for c in new)),'audit':src['audit']},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'cards':len(cards),'newCards':len(new)}))
