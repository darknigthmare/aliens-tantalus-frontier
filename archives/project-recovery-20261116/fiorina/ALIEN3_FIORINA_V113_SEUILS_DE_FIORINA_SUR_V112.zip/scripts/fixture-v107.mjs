import assert from 'node:assert/strict';
import * as N from '../src/alien3-navigation-v105.js';
import * as P from '../src/alien3-pursuit-v105.js';
import * as E from '../src/alien3-encounter-v105.js';
import {withAlien3DlcRuntimeV105,makeSaveV105,parseSaveV105} from '../src/alien3-dlc-runtime-v105.js';
import {withAlien3DlcRuntimeV104} from '../src/alien3-dlc-runtime-v104.js';
import {withAlien3DlcRuntimeV103} from '../src/alien3-dlc-runtime-v103.js';
import {withAlien3DlcRuntimeV102} from '../src/alien3-dlc-runtime-v102.js';
import {withAlien3DlcRuntimeV101} from '../src/alien3-dlc-runtime-v101.js';
import {CAMPAIGN_V104,fnv104} from '../src/alien3-dlc-v104.js';
import {FiorinaAudioV105} from '../src/alien3-audio-v105.js';
import {withAlien3DlcRuntimeV106}from '../src/alien3-dlc-runtime-v106.js';
import {withAlien3DlcRuntimeV107} from '../src/alien3-dlc-runtime-v107.js';
export const model=N.compileNavigationV105();
export const actor=(node,id='ripley')=>N.actorOnNodeV105(model,node,{id,name:id==='runner-unique-v105'?'Runner':id,w:id==='runner-unique-v105'?109:36,h:id==='runner-unique-v105'?70:90});
export const gates=()=>model.scene.gates.map(g=>({...g,open:true,progress:1}));
class Base{constructor(){this.player={...actor('f161-infirmary'),health:100,maxHealth:100,grounded:true};this.alien3RunnerV88=actor('f161-cell-b','runner-unique-v105');this.keys=new Set();this.doors=gates();this.camera={x:0,y:0};this.running=true;this.paused=false;this.animationTime=0;this.mission={state:'active'};this.alien3V88={phase:'infirmary'};this.alien3V89={company:{visible:false}};this.alien3V98={codexUi:{open:false}};this.alien3V99={codexGraph:{currentId:null}};this.missionLevelRuntime=null;this.count=0;this.onEvent=()=>{};}start(){return{};}stop(){this.running=false;}update(t){this.animationTime+=t;this.count++;}damagePlayer(p,n){p.health-=n;return n;}getSnapshot(){return{};}captureResumeState(){return{specialOperation:{base:'kept'}};}applyResumeState(){this.applied=(this.applied||0)+1;return{applied:true};}drawWorld(){}drawHud(){}drawBackdrop(){}drawActor(){this.nativeActor=(this.nativeActor||0)+1;}drawEnemy(){this.nativeEnemy=(this.nativeEnemy||0)+1;}interact(){const d=this.doors.find(d=>Math.abs(this.player.x+this.player.w/2-d.x-d.w/2)<85&&Math.abs(this.player.y+this.player.h-d.y-d.h)<28);if(!d)return false;if(d.open&&!this.alien3DoorClearV105(d))return false;d.open=!d.open;d.progress=d.open?1:0;return true;}getInteractionPrompt(){return'';}clearGameplayInput(){this.keys.clear();}}

export const Runtime=withAlien3DlcRuntimeV107(withAlien3DlcRuntimeV106(withAlien3DlcRuntimeV105(withAlien3DlcRuntimeV104(withAlien3DlcRuntimeV103(withAlien3DlcRuntimeV102(withAlien3DlcRuntimeV101(Base)))))));
export const game=mode=>{const e=new Runtime();e.start({campaign:{id:CAMPAIGN_V104},alien3EncounterV105:mode});return e;};
