#!/usr/bin/env python3
"""Illustrated PDF from native Chromium captures; no independent picture rendering."""
from pathlib import Path
from xml.sax.saxutils import escape
import json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape,A4
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=Path(__file__).resolve().parents[1];Q=R/'qa-v111';b=json.loads((Q/'browser.json').read_text());u=json.loads((Q/'unit.json').read_text());i=json.loads((Q/'install.json').read_text());doc=json.loads((Q/'documentation.json').read_text());cx=json.loads((Q/'codex-browser.json').read_text());dh=json.loads((Q/'delivered.json').read_text())
for name,file in [('Body','DejaVuSans.ttf'),('Strong','DejaVuSans-Bold.ttf')]:
 p=Path('/usr/share/fonts/truetype/dejavu')/file
 if not p.is_file():raise FileNotFoundError('DejaVu Sans required locally: '+str(p))
 pdfmetrics.registerFont(TTFont(name,str(p)))
W,H=landscape(A4);M=34;CW=W-2*M;BG=HexColor('#0e1a13');INK=HexColor('#e3e8d6');MUTED=HexColor('#b7c3ad');LINE=HexColor('#52634a');GOLD=HexColor('#cdb786')
styles={k:ParagraphStyle(k,fontName='Body',fontSize=f,leading=l,textColor=MUTED if k in ['small','caption']else INK)for k,f,l in [('body',11,16),('caption',9.2,13),('small',9,12.7),('cell',9.5,13.5)]}
pdf=canvas.Canvas(str(R/'RAPPORT_ILLUSTRE_V111.pdf'),pagesize=(W,H),pageCompression=1);pdf.setTitle('ALIEN 3 — Fiorina 161 V111 — Les détours de service');pdf.setAuthor('Aliens: Tantalus Frontier / dossier de développement')
selectedNames=['41_porte_refermee.png','42_retour_carrefour.png','43_detour_inferieur.png','44_postes_apres_detour.png','45_coulee_apres_detour.png','46_retour_morse.png','47_reprise_detour.png','48_postes_apres_import.png','30_dillon_attend_le_jet.png','31_refermer_en_cours.png','33_attente_volontaire.png','34_reprise_depuis_appui.png','06b_verrouillage.png','08_attaque_annoncee.png','10_refroidissement.png','40_retour_traque.png']
selected=[next(x for x in b['screenshots']if Path(x['file']).name==n)for n in selectedNames];total=3+len(selected);pn=0

def para(text,x,top,width,style='body',maxh=None):
 p=Paragraph(text,styles[style]);_,height=p.wrap(width,999)
 if maxh and height>maxh:raise ValueError(f'Overflow {height}>{maxh}: {text[:60]}')
 p.drawOn(pdf,x,top-height);return height

def page(title,section):
 global pn;pn+=1;pdf.setFillColor(BG);pdf.rect(0,0,W,H,fill=1,stroke=0);pdf.setFillColor(GOLD);pdf.setFont('Strong',9);pdf.drawString(M,H-24,'ALIEN 3  /  FIORINA 161');pdf.setFont('Body',8);pdf.drawRightString(W-M,H-24,'V111  ·  '+section);pdf.setFillColor(INK);pdf.setFont('Strong',24)
 if pdfmetrics.stringWidth(title,'Strong',24)>CW:raise ValueError(title)
 pdf.drawString(M,H-57,title);pdf.setStrokeColor(LINE);pdf.line(M,29,W-M,29);pdf.setFillColor(MUTED);pdf.setFont('Body',7.5);pdf.drawString(M,16,'Banc local · modules partagés · silhouettes vectorielles · pas de campagne native complète certifiée');pdf.drawRightString(W-M,16,f'{pn:02d} / {total}')

def image(file,top=H-76):
 h=CW*720/1280;pdf.drawImage(str(R/file),M,top-h,width=CW,height=h,preserveAspectRatio=True,mask='auto');pdf.setStrokeColor(LINE);pdf.rect(M,top-h,CW,h,stroke=1,fill=0);return top-h

def table(rows,top,widths):
 t=Table([[Paragraph(escape(str(x)),styles['cell'])for x in row]for row in rows],colWidths=widths);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#2d3b26')),('BACKGROUND',(0,1),(-1,-1),HexColor('#182b1c')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,-1),.5,LINE)]));_,h=t.wrap(CW,999);t.drawOn(pdf,M,top-h);return top-h
page('Les détours de service','VERSION LOCALE CANDIDATE')
y=image('qa-v111/captures/43_detour_inferieur.png');para('Morse emprunte les passages inférieurs après la fermeture de la porte de fonderie. Capture native pendant une traversée au clavier. Les modules livrés sont exécutés dans un banc à physique de base et personnages provisoires.',M,y-10,CW,'caption',40);pdf.showPage()
page('Choisir un passage, sans traverser les murs','COMPORTEMENTS ET LIMITES')
y=table([['Élément','Comportement livré','Limite'],['Porte fermée','Retour au carrefour puis route ouverte.','Même acteur, segment et budget de vitesse.'],['Vapeur chaude','Comparer attente et trajet alternatif.','Un détour trop long est refusé.'],['Corps du détenu','Marge égale à la demi-largeur devant le battant.','Pas de passage d’épaule dans la porte.'],['Ordre G','L’attente volontaire reste prioritaire.','Un chemin calculé ne vaut pas une arrivée.'],['Détour','Graphe et jambes physiques déjà existants.','Pas de conduit du Runner ni de contresens.'],['Reprise','Pose conservée, itinéraire recalculé.','Pas de chemin imposé par un fichier.']],H-82,[114,334,CW-448]);y-=18
para('Le rabattage a été terminé avec la porte de fonderie maintenue fermée. Morse rejoint la coulée par les passages inférieurs ; Dillon occupe sa commande. L’attaque, la coulée et le refroidissement restent ceux de la séquence existante.',M,y,CW,'body',50);y-=64
para(f'Codex de level design : <b>{doc["cards"]} fiches</b>, dont {doc["newCards"]} nouveaux contrats. Aucun nouveau secteur ni accessoire n’est compté. Les 72 points et les 119 connexions historiques sont conservés.',M,y,CW,'small',40);pdf.showPage()
page('Parcours continus et reprises distinctes','PREUVES EXÉCUTÉES')
rows=[['Parcours automatisé','Résultat','Santé','Détours décidés']]
labels={'rapide':'Traque rapide','prudent':'Traque prudente','accessibilite':'Traque accessible','explorateur-reprise':'Traque avec reprise','rabattage-avec-esquive':'Rabattage avec esquive','rabattage-vanne-et-groupe':'Vanne, attente et groupe','purge-refermee-en-traque':'Fermeture en traque','rabattage-porte-et-detour':'Porte fermée et détour','detour-repris-par-fichier':'Reprise au milieu du détour'}
for route in b['routes']:
 st=route['result'];finished=st['status']=='complete';rows.append([labels.get(route['profile'],route['profile']),'Terminé' if finished else 'Postes rejoints seulement',st['hp'],st['routing']['stats']['detours']])
y=table(rows,H-81,[256,222,90,CW-568]);y-=14
para('Traversées au clavier et horloge contrôlée, sans injection de position ni d’étape. Les robots connaissent le chemin. La reprise du détour valide l’arrivée du groupe ; elle n’est pas annoncée comme un deuxième piège entier repris depuis le fichier.',M,y,CW,'small',40);y-=47
para(f'<b>{u["cases"]} cas unitaires</b>, <b>{i["cases"]} installations synthétiques</b>, <b>{b["controlsExecuted"]} assertions Chromium</b> ({b["uniqueControlNames"]} libellés distincts), {dh["tests"]} contrôles du fichier ordinaire et {cx["tests"]} contrôles du codex. Pas de build Tantalus, campagne entière, sprites finaux, essais humains ou déploiement certifiés.',M,y,CW,'small',50);pdf.showPage()
titles={'41_porte_refermee.png':'Une porte ferme le trajet direct','42_retour_carrefour.png':'Revenir depuis la position réelle','43_detour_inferieur.png':'Passer par les galeries inférieures','44_postes_apres_detour.png':'Les deux détenus ont rejoint leurs postes','45_coulee_apres_detour.png':'La coulée attend la capture','46_retour_morse.png':'Le rabattage est terminé','47_reprise_detour.png':'Reprendre au milieu du détour','48_postes_apres_import.png':'Des arrivées réelles après l’import','30_dillon_attend_le_jet.png':'Parfois, attendre reste le meilleur choix','31_refermer_en_cours.png':'Refermer sans récupérer la pression','33_attente_volontaire.png':'L’ordre de rester conserve sa priorité','34_reprise_depuis_appui.png':'Repartir sans changer de position','06b_verrouillage.png':'Préparer le moule à sa commande','08_attaque_annoncee.png':'L’attaque du Runner reste esquivable','10_refroidissement.png':'Revenir libérer l’eau','40_retour_traque.png':'La traque d’Aaron reste terminable'}
for index,shot in enumerate(selected,1):
 page(titles[Path(shot['file']).name],f'CAPTURE NATIVE {index:02d} / {len(selected)}');y=image(shot['file']);scope='Nouvelle page après export et import explicites.'if'file export' in shot['scope']else'Actions au clavier/pointeur dans le banc local.';para(escape(shot['caption'])+' '+scope,M,y-10,CW,'caption',40);pdf.showPage()
assert pn==total;pdf.save();report={'ok':True,'pages':pn,'nativeScreenshotsInPdf':len(selected),'nativeScreenshotsAvailable':len(b['screenshots']),'bytes':(R/'RAPPORT_ILLUSTRE_V111.pdf').stat().st_size};(Q/'pdf.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
