#!/usr/bin/env python3
"""Illustrated PDF from native Chromium captures; no independent picture rendering."""
from pathlib import Path
from xml.sax.saxutils import escape
import json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape,A4
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=Path(__file__).resolve().parents[1];Q=R/'qa-v110';b=json.loads((Q/'browser.json').read_text());u=json.loads((Q/'unit.json').read_text());i=json.loads((Q/'install.json').read_text());doc=json.loads((Q/'documentation.json').read_text());cx=json.loads((Q/'codex-browser.json').read_text());dh=json.loads((Q/'delivered.json').read_text())
for name,file in [('Body','DejaVuSans.ttf'),('Strong','DejaVuSans-Bold.ttf')]:
 p=Path('/usr/share/fonts/truetype/dejavu')/file
 if not p.is_file():raise FileNotFoundError('DejaVu Sans required locally: '+str(p))
 pdfmetrics.registerFont(TTFont(name,str(p)))
W,H=landscape(A4);M=34;CW=W-2*M;BG=HexColor('#0e1a13');INK=HexColor('#e3e8d6');MUTED=HexColor('#b7c3ad');LINE=HexColor('#52634a');GOLD=HexColor('#cdb786')
styles={k:ParagraphStyle(k,fontName='Body',fontSize=f,leading=l,textColor=MUTED if k in ['small','caption']else INK)for k,f,l in [('body',11,16),('caption',9.2,13),('small',9,12.7),('cell',9.5,13.5)]}
pdf=canvas.Canvas(str(R/'RAPPORT_ILLUSTRE_V110.pdf'),pagesize=(W,H),pageCompression=1);pdf.setTitle('ALIEN 3 — Fiorina 161 V110 — Garder le passage');pdf.setAuthor('Aliens: Tantalus Frontier / dossier de développement')
selectedNames=['01_aaron.png','30_dillon_attend_le_jet.png','31_refermer_en_cours.png','32_jet_referme.png','33_attente_volontaire.png','34_reprise_depuis_appui.png','37_postes_apres_attente.png','06b_verrouillage.png','08_attaque_annoncee.png','09_coulee.png','10_refroidissement.png','38_retour_apres_fermeture.png','35_attente_reprise.png','36_fermeture_accessible.png','39_refermer_en_traque.png','40_retour_traque.png']
selected=[next(x for x in b['screenshots']if Path(x['file']).name==n)for n in selectedNames];total=3+len(selected);pn=0

def para(text,x,top,width,style='body',maxh=None):
 p=Paragraph(text,styles[style]);_,height=p.wrap(width,999)
 if maxh and height>maxh:raise ValueError(f'Overflow {height}>{maxh}: {text[:60]}')
 p.drawOn(pdf,x,top-height);return height

def page(title,section):
 global pn;pn+=1;pdf.setFillColor(BG);pdf.rect(0,0,W,H,fill=1,stroke=0);pdf.setFillColor(GOLD);pdf.setFont('Strong',9);pdf.drawString(M,H-24,'ALIEN 3  /  FIORINA 161');pdf.setFont('Body',8);pdf.drawRightString(W-M,H-24,'V110  ·  '+section);pdf.setFillColor(INK);pdf.setFont('Strong',24)
 if pdfmetrics.stringWidth(title,'Strong',24)>CW:raise ValueError(title)
 pdf.drawString(M,H-57,title);pdf.setStrokeColor(LINE);pdf.line(M,29,W-M,29);pdf.setFillColor(MUTED);pdf.setFont('Body',7.5);pdf.drawString(M,16,'Banc local · modules partagés · silhouettes vectorielles · pas de campagne native complète certifiée');pdf.drawRightString(W-M,16,f'{pn:02d} / {total}')

def image(file,top=H-76):
 h=CW*720/1280;pdf.drawImage(str(R/file),M,top-h,width=CW,height=h,preserveAspectRatio=True,mask='auto');pdf.setStrokeColor(LINE);pdf.rect(M,top-h,CW,h,stroke=1,fill=0);return top-h

def table(rows,top,widths):
 t=Table([[Paragraph(escape(str(x)),styles['cell'])for x in row]for row in rows],colWidths=widths);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#2d3b26')),('BACKGROUND',(0,1),(-1,-1),HexColor('#182b1c')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,-1),.5,LINE)]));_,h=t.wrap(CW,999);t.drawOn(pdf,M,top-h);return top-h
page('Garder le passage','VERSION LOCALE CANDIDATE')
y=image('qa-v110/captures/30_dillon_attend_le_jet.png');para('Refermer un jet, attendre sa dissipation et laisser les détenus rejoindre leurs commandes. Capture native pendant une approche au clavier. Les modules livrés sont exécutés dans un banc à physique de base et personnages provisoires.',M,y-10,CW,'caption',40);pdf.showPage()
page('La vanne et le groupe partagent le danger','CHANGEMENTS ET LIMITES')
y=table([['Élément','Comportement livré','Limite'],['Refermer avec V','Geste de 0,85 s à la même commande.','Bon étage, profondeur, appui et accès.'],['Chaleur résiduelle','Au plus 0,30 s chaude + 1,20 s de dissipation.','Le jet ne disparaît pas instantanément.'],['Pression','Aucun remboursement des 70 unités dépensées.','Recharge après la fin complète du nuage.'],['Détenus','Prochain pas vérifié devant la vraie plume.','Pas de nouveau détour, dommage ou téléport.'],['Ordre G','Attente volontaire prioritaire ; reprise sur nouvel ordre.','Attendre ne signifie pas tenir son poste.'],['Reprise','Position, réserve et registre conservés.','Import en pause ; danger recalculé au premier pas.']],H-82,[125,338,CW-463]);y-=18
para('Le parcours de rabattage attend réellement Dillon devant le jet, lui demande de rester sur place, referme la vanne puis lui redonne le départ. Le moule attend ensuite l’arrivée physique des deux détenus à leurs commandes.',M,y,CW,'body',50);y-=64
para(f'Codex de level design : <b>{doc["cards"]} fiches</b>, dont {doc["newCards"]} nouveaux contrats. Aucun nouveau composant industriel n’est compté : les trois vannes et leurs volumes sont ceux de V109.',M,y,CW,'small',40);pdf.showPage()
page('Des parcours vérifiés, pas un film complet','PREUVES EXÉCUTÉES')
rows=[['Profil automatisé','Santé','Contacts','Ouvertures / fermetures','Temps simulé']]
for route in b['routes']:
 st=route['result'];ss=st.get('steam',{}).get('stats',{});ts=st.get('traffic',{}).get('stats',{});rows.append([route['profile'],st['hp'],st['pursuit']['stats']['hits'],f'{ss.get("opened",0)} / {ts.get("closed",0)}',f'{st["clock"]:.2f} s'])
y=table(rows,H-81,[211,70,86,175,CW-542]);y-=16
para('Traversées au clavier et horloge contrôlée, sans injection de position ni d’étape. Les robots connaissent le chemin. Le test d’échec préparé et les vérifications sur bases instrumentées restent distincts de ces parcours.',M,y,CW,'small',42);y-=53
para(f'<b>{u["cases"]} cas unitaires</b>, <b>{i["cases"]} installations synthétiques</b>, <b>{b["controlsExecuted"]} assertions Chromium</b> ({b["uniqueControlNames"]} libellés distincts), {dh["tests"]} contrôles du fichier ordinaire et {cx["tests"]} contrôles du codex. Régressions V109/V108 exécutées séparément.',M,y,CW,'small',40);y-=53
para('<b>Non revendiqué :</b> build complet Tantalus, parcours intégral du film, sprites définitifs, essais humains, manette physique, Safari, écoute matérielle ou déploiement. Quatre nouveaux modules et un raccord de moteur sur les 47 sources V109 vérifiées, sans modification de ces sources.',M,y,CW,'small',40);pdf.showPage()
titles={'01_aaron.png':'La consigne d’Aaron','30_dillon_attend_le_jet.png':'Dillon s’arrête devant la vapeur','31_refermer_en_cours.png':'Refermer à la commande réelle','32_jet_referme.png':'Le jet tombe, la chaleur reste','33_attente_volontaire.png':'Votre ordre reste prioritaire','34_reprise_depuis_appui.png':'Repartir depuis la même position','37_postes_apres_attente.png':'Les deux commandes sont tenues','06b_verrouillage.png':'Le moule garde sa préparation','08_attaque_annoncee.png':'L’attaque reste évitable','09_coulee.png':'Une capture physique avant la coulée','10_refroidissement.png':'Rejoindre et libérer l’eau','38_retour_apres_fermeture.png':'Retour auprès de Morse','35_attente_reprise.png':'Reprendre le groupe par fichier','36_fermeture_accessible.png':'Appuyer au lieu de maintenir','39_refermer_en_traque.png':'Refermer pendant la chasse','40_retour_traque.png':'Rapporter le relevé à Aaron'}
for index,shot in enumerate(selected,1):
 page(titles[Path(shot['file']).name],f'CAPTURE NATIVE {index:02d} / {len(selected)}');y=image(shot['file']);scope='Nouvelle page après export et import explicites.'if'file export' in shot['scope']else'Actions au clavier/pointeur dans le banc local.';para(escape(shot['caption'])+' '+scope,M,y-10,CW,'caption',40);pdf.showPage()
assert pn==total;pdf.save();report={'ok':True,'pages':pn,'nativeScreenshotsInPdf':len(selected),'nativeScreenshotsAvailable':len(b['screenshots']),'bytes':(R/'RAPPORT_ILLUSTRE_V110.pdf').stat().st_size};(Q/'pdf.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
