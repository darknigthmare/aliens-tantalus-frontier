import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import * as F from '../src/alien3-fidelity-v113.js';import {compileAlien3StandardV104} from '../src/alien3-dlc-v104.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),model=compileAlien3StandardV104(),scene=model.scene;
fs.mkdirSync(path.join(root,'qa-v113'),{recursive:true});
fs.writeFileSync(path.join(root,'qa-v113/design-source.json'),JSON.stringify({schema:113,audit:F.coverageAuditV113(scene),references:F.REFERENCES_V113,portals:F.bindPortalsV113(scene),cast:F.CAST_V113,equipment:F.inventoryCoverageV113(scene),locations:F.LOCATION_COVERAGE_V113,props:F.compileEvidencePropsV113(scene),rules:F.STYLE_RULES_V113,nodes:scene.nodes,edges:scene.edges,sections:model.sections||[],legacy:{assemblies:scene.decor.groups.length,components:scene.decor.props.length}},null,2)+'\n');
console.log(F.coverageAuditV113(scene));
