#!/usr/bin/env python3
"""Generate V108 contracts and illustrated HTML from executable definitions and native screenshots."""
from pathlib import Path
from html import escape as esc
import json,re,subprocess,collections,base64,hashlib
R=Path(__file__).resolve().parents[1];Q=R/'qa-v108';D=R/'docs';D.mkdir(exist_ok=True)
subprocess.run(['node',str(R/'scripts/export-design-v108.mjs')],check=True)
src=json.loads((Q/'design-source.json').read_text());u=json.loads((Q/'unit.json').read_text());ins=json.loads((Q/'install.json').read_text());browser=json.loads((Q/'browser.json').read_text());dh=json.loads((Q/'delivered.json').read_text());r=src['rules']
old=(R/'ALIEN3_CODEX_LEVEL_DESIGN_V107.html').read_text();start=old.index('const cards=')+len('const cards=');cards,end=json.JSONDecoder().raw_decode(old[start:]);assert len(cards)==475
new=[]
def add(type,id,title,text,details):new.append({'type':type,'id':id,'title':title,'text':text,'details':details})
for rule in src['contracts']:
 add('Règles V108',rule['id'],rule['text'].split(' ; ')[0],rule['text'],[['Vérification','qa-v108/unit.json',rule['validation']],['Champ d’application','encounter-traque','Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.']])
states=[('pocket','Dans la poche','Aucune pose mondiale : X et Y sont nuls, les vitesses valent zéro. Le compteur de lancers reste conservé pour empêcher la copie d’un même objet.','La touche T prend une identité disponible, jamais un nouvel objet.'),('flying','En vol','Position, vitesse, profondeur et origine sont conservées. La gravité et les intersections sont calculées en sous-pas ; un événement sonore n’est produit que lors d’un impact réel.','Un import conserve la trajectoire et attend la reprise explicite.'),('rest','Posé au sol','Le pied du boulon, y + 3,5, doit coïncider avec la hauteur d’un support identifié. Il ne revient pas automatiquement dans la poche.','La touche Y exige proximité, appui, même étage, même profondeur et aucun battant fermé interposé.'),('lost','Perdu','Un boulon hors du niveau ou dans le plomb chaud n’est plus récupérable dans ce parcours. La même identité reste comptée comme perdue.','Le dernier poste sûr peut contenir un état antérieur distinct ; aucune recharge temporelle n’est ajoutée.')]
for id,title,text,extra in states:add('États des boulons','state108-'+id,title,text,[['Transition','A3-108-save-count',extra],['Limite','A3-108-no-damage','Aucun dégât, étourdissement ou blocage d’acteur.']])
for f in src['geometry']['floors']:
 add('Surfaces de collision V108','surface108-'+f['id'],'Support de lancer · '+f['id'],f'Surface fusionnée à la hauteur Y {f["y"]}, étendue X {f["x"]} à {f["x"]+f["w"]}, épaisseur de collision {f["h"]}. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.',[['Coordonnées','A3-108-solid',f'X {f["x"]}, Y {f["y"]}, largeur {f["w"]}, hauteur {f["h"]} unités du jeu.'],['Repos','state108-rest',f'Centre du boulon posé à Y {f["y"]-r["radius"]}.'],['Balayage','A3-108-arc',f'Intégration en sous-pas de {r["step"]:.6f} seconde au plus ; collision également sous la plateforme.']])
for gate in src['doors']:
 add('Portes et projectiles','gate108-'+gate['id'],'Impact sur '+gate['id'],f'Porte existante de Fiorina : X {gate["x"]}, Y {gate["y"]}, dimensions {gate["w"]} × {gate["h"]}. Ouverte, elle laisse passer le boulon. Fermée, le segment de vol peut la rencontrer et repartir en sens inverse avec une vitesse amortie.',[['Porte d’origine',gate['id'],'Aucun nouveau battant ni verrou de mission.'],['Origine sonore','A3-108-impact','L’événement vient du point touché sur le battant, pas de la position actuelle de Ripley.'],['Sauvegarde','save108-current','La validation reconstruit la géométrie réelle depuis les états de porte sauvegardés.']])
add('Commandes V108','input108-throw','Lancer un boulon','T ou le bouton « Lancer » prend l’un des trois boulons en poche. Le départ se fait à la main et suit la direction du corps. Il n’existe pas de paramètre de ciblage distant ni de lancer instantanément matérialisé près du Runner.',[['Poche','state108-pocket',f'Réserve maximale {r["reserve"]} ; cadence {r["cooldown"]} s.'],['Appui','A3-108-origin','Ripley doit être vivante, au sol et hors d’une montée.'],['Conflit','A3-108-busy','Une manœuvre active conserve la priorité.'],['Arc','state108-flying',f'Vitesse initiale horizontale {r["speed"]} ; verticale {r["lift"]} ; gravité {r["gravity"]} en unités du jeu.']])
add('Commandes V108','input108-recover','Ramasser le boulon','Y ou le bouton « Ramasser » récupère une identité posée à portée réelle. Ce n’est ni une aspiration à distance ni un remplissage automatique après un lancer.',[['Portée','A3-108-near-pickup',f'{r["pickupRange"]} unités horizontales, {r["pickupHeight"]} verticales et {r["pickupDepth"]} de profondeur.'],['Surface','state108-rest','Le support doit encore justifier le repos.'],['Conservation','A3-108-recover','Un second appui ne produit pas de quatrième objet.']])
for bolt in src['initial']['bolts']:
 add('Objets persistants V108','object108-'+bolt['id'],'Boulon '+bolt['id'].split('-')[-1],'Identité persistante d’un objet métallique ordinaire. La forme et les capacités sont les mêmes pour les trois objets ; ces fiches ne correspondent pas à trois nouveaux modèles artistiques.',[['Au départ','state108-pocket','Dans la poche, jamais déjà posé devant le joueur.'],['En déplacement','state108-flying','Origine et nombre de lancers restent associés à cette identité.'],['Récupération','input108-recover','Le même identifiant est rendu à la poche.'],['Perte','state108-lost','Aucune duplication ni réapparition pendant le parcours.']])
for id,title,text,details in [
 ('current','Fichier V108','La session V107 est validée puis le registre des trois boulons. Un objet en vol conserve sa pose, sa vitesse et sa profondeur ; un objet posé doit coïncider avec un appui réel. L’enveloppe est limitée à 1 Mio.',[['Validation','A3-108-checksum','L’empreinte FNV détecte une corruption, pas une signature anti-triche. Les invariants et collisions sont vérifiés ensuite.'],['Comptage','A3-108-save-count','Trois états au total, identités uniques, compteurs de lancers et de récupérations cohérents.'],['Import','A3-108-save-air','Reprise en pause, sans refaire l’impact précédent.']]),
 ('checkpoint','Poche du dernier poste sûr','Le poste sûr garde sa réserve et ses poses propres, distinctes de la partie courante. Une manœuvre active ne remplace pas ce poste. Il doit être vivant, actif, dans la même séquence et à un stade non futur.',[['Reprise','save107-checkpoint','Le propriétaire V107 garde son registre de gestes terminés.'],['Atomicité','save108-current','La validation d’un poste corrompu refuse tout le fichier avant de remplacer la session.']]),
 ('migration','Migrer un fichier antérieur','Les fichiers V105, V106 et V107 valides reçoivent trois boulons en poche. Le poste sûr antérieur est migré séparément. Aucun état d’attente, lumière ou objectif déjà acquis n’est remplacé par une nouvelle partie.',[['Sources','save106-navigation','Contrôles historiques de position et navigation conservés.'],['Manœuvres','save107-current','Pas de préparation partielle réactivée.'],['Périmètre','A3-108-scope','Pas de cloud, autosauvegarde sur disque ou certification anti-triche.']])]:add('Reprises V108','save108-'+id,title,text,details)
add('Perception V108','hearing108-impact','Enquêter sur un impact','Le bruit entre dans l’audition V106 avec la position réellement touchée. Le Runner peut conserver la trace de l’impact et rechercher un point atteignable du réseau proche. Il ne reçoit pas la position cachée actuelle de Ripley.',[['Intensité','A3-108-impact',f'Premier impact : puissance abstraite {r["power"]}. Rebonds : {r["power"]*.52:.4f}. Cadence minimale {r["impactGap"]} s.'],['Contraintes','A3-108-attention','Une attaque déjà engagée ou une reconnaissance récente ne sont pas annulées par la diversion.'],['Distance','A3-108-trace','Un détour d’étage ou une porte peuvent rendre le bruit inaudible.'],['Rabattage','A3-108-dormant','Pendant la préparation antérieure à l’armement, le prédateur reste dormant.']])
add('Rendu V108','art108-bolt','Petit objet, repère local','Le boulon est dessiné par le module livré à sa position mondiale avec la même profondeur logique que lors du lancer. Le bref repère d’impact s’efface aussi au repos ; il ne pulse pas indéfiniment.',[['Pureté','A3-108-render','Dessiner ne fait avancer ni objet, ni perception, ni sauvegarde.'],['Réserve','input108-throw','Le petit panneau affiche seulement la commande utile et le nombre en poche.'],['Art','Silhouettes provisoires','Aucun nouveau sprite officiel ni pack photoréaliste annoncé.']])
for c in cards:
 if c['id']=='encounter-traque':c['details'].append(['Diversion','input108-throw','Boulon lancé, bruit depuis l’impact ; aucune garantie de l’attirer hors de portée.'])
 if c['id']=='encounter-rabattage':c['details'].append(['Préparation','A3-108-dormant','Les boulons ne réveillent pas la créature durant la phase explicitement dormante.'])
cards+=new;assert len({c['id']for c in cards})==len(cards)
(Q/'codex-source.json').write_text(json.dumps({'schema':108,'cards':cards},ensure_ascii=False,indent=2)+'\n')
intro=['# Alien 3 — Codex de level design V108','## Échos de métal','',f'{len(cards)} fiches, dont {len(new)} nouveaux contrats. Document de conception extérieur au jeu ; les 90 archives du joueur restent distinctes.','',
'## Périmètre et géométrie','Couche incrémentale sur les sources V107 exactes. Le banc utilise les mêmes modules que le correctif, sur une physique de base simplifiée. Aucun build natif complet, sprite définitif, nouveau chapitre de film ou parcours intégral du film n’est annoncé.',
'Le graphe, les 20 sections descriptives et les 30 assemblages historiques (284 composants) sont conservés. Le poste de collecteur de V107 garde ses quatre composants. Les supports continus au même niveau sont fusionnés pour le balayage des boulons ; ce calcul ne crée ni nouvelle plateforme ni décoration rendue solide.',
'Un lancer utilise trois identités au maximum. Les objets au repos sont récupérables à proximité ; les pertes sont conservées pour le parcours. La sauvegarde ne recharge pas le stock courant et ne rejoue pas un bruit. Une reprise au dernier poste sûr peut naturellement retrouver l’état antérieur de ce poste.',
'La diversion entre dans l’audition existante. Elle n’annule pas une attaque, ne téléporte pas le Runner et n’a pas une portée infinie. Les trajectoires utilisent les supports et battants ; elles ne constituent pas une simulation physique de tout le décor 3D.', '']
for c in cards:intro.extend([f'### {c["title"]}',f'`{c["id"]}` · {c["type"]}',c['text'],'','| Élément | Référence | Contrat |','|---|---|---|',*['| '+' | '.join(str(v).replace('|',' / ').replace('\n',' ')for v in row)+' |'for row in c['details']],''])
(D/'ALIEN3_LEVEL_DESIGN_CODEX_V108.md').write_text('\n'.join(intro))
updated=old[:start]+json.dumps(cards,ensure_ascii=False)+old[start+end:]
updated=updated.replace('DOCUMENT DE CONCEPTION V107','DOCUMENT DE CONCEPTION V108').replace('Codex V107','Codex V108').replace('<h1>Manœuvres sous tension</h1>','<h1>Échos de métal</h1>').replace('475 fiches issues des données livrées',f'{len(cards)} fiches issues des données livrées')
updated=re.sub(r'(<div class="scope">).*?(</div>)',lambda x:x.group(1)+'Codex hors jeu. Trois boulons persistants, trajectoire, collisions, impacts audibles et récupération proche. Les tests distinguent les parcours au clavier des fixtures dirigées. Le contrôleur local reste simplifié ; aucune campagne native complète n’est certifiée.'+x.group(2),updated,count=1,flags=re.S)
options=''.join('<option>'+esc(k)+'</option>'for k in ['Tout',*dict.fromkeys(c['type']for c in cards)])
updated=re.sub(r'(<select id="kind"[^>]*>).*?(</select>)',lambda x:x.group(1)+options+x.group(2),updated,flags=re.S)
(R/'ALIEN3_CODEX_LEVEL_DESIGN_V108.html').write_text(updated)
(Q/'documentation.json').write_text(json.dumps({'schema':108,'cards':len(cards),'newCards':len(new),'byCategory':dict(collections.Counter(c['type']for c in cards)),'baseComponents':284,'existingFittingComponents':4,'newPersistentObjects':3,'collisionFloors':len(src['geometry']['floors']),'markdownLines':len(intro)},ensure_ascii=False,indent=2)+'\n')
css=re.search(r'<style>(.*?)</style>',old,re.S).group(1);panels=[]
for shot in browser['screenshots']:
 raw=(R/shot['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==shot['sha256']
 scope='Cas dirigé avec positions explicitement préparées.'if'directed'in shot['scope']else('Préparation au clavier, Runner dormant à ce stade.'if'dormant'in shot['scope']or'before trap arming'in shot['scope']else'Parcours ou interaction au clavier/pointeur dans le banc local.')
 panels.append(f'<section class="panel"><h2>{esc(shot["caption"])}</h2><img alt="Capture native du banc jouable" src="data:image/png;base64,{base64.b64encode(raw).decode()}"><p class="caption">{scope} Modules livrés, personnages provisoires et contrôleur simplifié. Aucune réillustration des captures.</p></section>')
(R/'RAPPORT_ILLUSTRE_V108.html').write_text(f'''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Alien 3 — Rapport V108</title><style>{css}</style><header><small>FIORINA 161 · RAPPORT V108</small><h1>Échos de métal</h1><p>Trois boulons, des impacts réellement localisés et des reprises qui conservent leur trajectoire.</p></header><main><div class="scope">Banc local utilisant les modules livrés, pas le jeu natif complet. Les supports de collision proviennent de la géométrie de ce banc. Aucun build complet, push, déploiement, test humain ou écoute physique n’est certifié.</div><section class="panel"><h2>Vérifications exécutées</h2><p>{u['cases']} cas unitaires, {ins['cases']} scénarios d’installation synthétiques, {browser['controlsExecuted']} assertions Chromium en {len(browser['phases'])} groupes et {dh['tests']} contrôles du fichier ordinaire sans API QA. Les répétitions entre parcours sont incluses.</p><p>Les quatre profils habituels et le rabattage restent terminables. Un parcours supplémentaire a attendu le passage réel du Runner au même étage, lancé une diversion et rapporté le relevé sans contact. Le robot connaît les itinéraires : ses temps ne sont pas des durées de campagne.</p></section>{''.join(panels)}</main></html>''')
qa=['# QA — Alien 3 V108','', '## Portée','Couche incrémentale sur V107. Banc à contrôleur simplifié et personnages provisoires, utilisant les modules livrés. Aucun moteur natif complet ni montage du film entier certifié.','', '## Résultats',f'- {u["cases"]} cas unitaires V108.',f'- {ins["cases"]} scénarios d’installation, avec scripts npm synthétiques.',f'- {browser["controlsExecuted"]} assertions Chromium en {len(browser["phases"])} groupes ; {browser["uniqueControlNames"]} libellés distincts.',f'- {dh["tests"]} contrôles du fichier ordinaire sans API QA.','- Régressions séparées : V107 56 cas et 19 installations ; V106 47 et 18 ; V105 65 et 17 ; V104 37 et 15. Ces essais ne qualifient pas la pile native complète.','','## Parcours','| Profil automatisé | Résultat | Santé | Attaques / contacts / esquives | Lancers / sons entendus | Temps simulé |','|---|---|---:|---|---|---:|']
for route in browser['routes']:
 s=route['result'];st=s['pursuit']['stats'];bolt=s.get('diversion',{}).get('stats',{});qa.append(f'| {route["profile"]} | {s["status"]} | {s["hp"]} | {st["attacks"]} / {st["hits"]} / {st["misses"]} | {bolt.get("thrown",0)} / {bolt.get("heard",0)} | {s["clock"]:.2f} s |')
qa+=['','Le parcours avec diversion attend un retour réel du Runner au même étage avant le lancer. Un premier essai à l’étage supérieur était hors de portée acoustique ; ce refus n’a pas été transformé en écoute forcée. Les parcours sont au clavier avec horloge contrôlée, sans injection de position ou d’étape. Le robot connaît le chemin et lit l’état pour ses assertions ; ce n’est pas un essai humain.', '', '## Contrôles nouveaux','- Lancer au point de départ réel, aucun son avant impact, trace auditive depuis le boulon.','- Rebond sur une vraie porte fermée ; récupération d’une identité au sol ; aucun quatrième objet.','- Plan et import en pause figent trajectoire et vitesse.','- Export réel en vol, import sur une nouvelle page, réception au sol et récupération.','- Fichier à position impossible refusé malgré recalcul de l’empreinte ; géométrie de porte reconstruite avant validation.','- Le repère d’impact s’efface au repos ; aucun pulse perpétuel après arrêt.','- Contrôle ordinaire requestAnimationFrame et clavier T sans objet d’inspection publié.','','## Limites','La diversion n’ajoute aucun dégât ni stun. Le Runner n’écoute pas forcément un bruit hors de portée, durant une attaque ou lorsque sa trace visuelle garde la priorité. Il conserve sa navigation sur le graphe existant, pas un navmesh continu. Le calcul des boulons ne rend pas le décor entier physiquement interactif. Le prédateur reste dormant pendant la préparation antérieure à l’armement.', 'Son : activation, événements et coupure testés dans Chromium, aucune écoute sur matériel. Manette, Safari, tests humains, sprites définitifs, campagne native entière et performances cibles restent ouverts. Pas de nouvelle lecture GitHub ni erreur de droits revendiquée ce tour.','', '## Installation','Quatre nouveaux modules et un raccord du moteur. Aucun fichier V107 historique modifié. Les 38 sources connues sont comparées à leurs empreintes avant staging. Les tests npm des fixtures restent synthétiques, pas un build réel de Tantalus. Les sources modifiées, la concurrence et les chemins symboliques gérés sont refusés.']
(R/'RAPPORT_QA_V108.md').write_text('\n'.join(qa))
(D/'PORTEE_V108.md').write_text('''# Portée V108

| Sujet | Livré / vérifié | Non revendiqué |
|---|---|---|
| Boulons | Trois identités, arc, rebonds, récupération et pertes | Armes, dégâts, stun, physique 3D complète |
| Bruit | Impact local → audition existante, portée et portes | Diversion garantie, annulation d’attaque, poursuite exacte hors graphe |
| Sauvegarde | Vol et sol validés, poste sûr séparé, migration V105–V107 | Cloud, autosave disque, sécurité anti-triche |
| Rendu | PNG natifs du canvas des modules livrés | Art final, sprites officiels, photoréalisme |
| Parcours | Six trajectoires automatisées dont diversion ; clavier réel | Film complet, sessions humaines |
| Intégration | Installation sur les sources exactes V107 et tests adversariaux | Build complet Tantalus, push ou déploiement |
''')
(R/'README.md').write_text(f'''# Alien 3 — Fiorina 161 V108 · Échos de métal

Correctif incrémental **sur une base V107 compatible**, avec aperçu autonome. Ce n’est pas le jeu principal complet.

## Jouer
Ouvrir `FIORINA_V108_JOUER.html` dans un navigateur. Aucun serveur ni asset distant nécessaire. Les personnages et la physique de base restent simplifiés.
Les deux parcours originaux, la ronde et l’inspection de la base sont conservés. T lance un boulon à la main ; Y récupère un boulon posé à portée. Trois identités par parcours, pas de recharge automatique. Les sons restent optionnels et désactivés par défaut.
Autres commandes : flèches / Q-D / A-D déplacement ; Haut/Bas échelle ou profondeur ; Espace saut ; Maj course ; Ctrl discrétion ; E action et manœuvres ; F bruit sur place ; G attendre/repartir ; I lumière ; M plan ; C archives ; Échap pause ; R poste sûr. Les boutons à l’écran utilisent les mêmes méthodes.

## Installer sur une copie V107
Node.js 20+. Extraire le correctif hors du dossier cible.
```sh
node scripts/install-v108.mjs /chemin/vers/projet-V107 --dry-run
node scripts/install-v108.mjs /chemin/vers/projet-V107
```
Les 38 sources de `sources-v107-verified.json` doivent être identiques. L’installation ajoute quatre modules et un raccord de moteur. Elle prépare une copie temporaire, exécute `npm run check` et `npm run build` dans cette copie, puis reporte les octets validés après contrôle de concurrence. Les essais fournis utilisent des projets synthétiques. `--skip-project-check` saute explicitement la validation du projet et ne doit pas être interprété comme un build réussi.
```sh
node scripts/install-v108.mjs --restore /chemin/vers/receipt.json
```
La restauration externe refuse d’écraser une modification survenue depuis installation.

## Reprises
Fichier explicite limité à 1 Mio ; migrations V105/V106/V107. Le vol en cours est conservé sans rejouer le bruit passé, et l’import reste en pause. Les manœuvres partielles ne redémarrent pas. Le dernier poste sûr conserve son propre stock. Pas d’autosauvegarde disque, cloud ou signature anti-triche.

## Documents
- `ALIEN3_CODEX_LEVEL_DESIGN_V108.html` : {len(cards)} fiches, {len(new)} nouveaux contrats ; recherche et liens.
- `docs/ALIEN3_LEVEL_DESIGN_CODEX_V108.md` : données et règles complètes.
- `RAPPORT_ILLUSTRE_V108.html` / `.pdf` : {len(browser['screenshots'])} captures natives, périmètres séparés.
- `RAPPORT_QA_V108.md`, `docs/PORTEE_V108.md` : portée exacte et limites.
- `qa-v108/` : résultats, exports réellement téléchargés, images et empreintes.

## Reproduire
```sh
node scripts/test-v108.mjs
node scripts/test-install-v108.mjs
python scripts/build-preview-v108.py
# Six phases : profiles, resume, trap, failure, audio, layout
python scripts/verify-browser-v108.py profiles
# Trois phases nouvelles : route, recovery, resume
python scripts/verify-diversion-v108.py route
python scripts/aggregate-qa-v108.py
python scripts/verify-delivered-v108.py
python scripts/build-docs-v108.py
python scripts/verify-codex-v108.py
python scripts/build-pdf-v108.py
```
L’agrégateur exige que les neuf phases aient été exécutées. Python Playwright, Chromium et ReportLab sont requis pour les outils de contrôle ; aucun fichier de police n’est distribué.
Les anciennes sources, outils et contrats nécessaires à la reproduction restent inclus. Les anciens rapports illustrés et captures sont omis du nouveau ZIP pour éviter leur accumulation ; ce ne sont pas des preuves V108.
Aucun build complet du dépôt, parcours intégral du film, push, déploiement, session humaine ou qualification physique du son et de la manette n’est annoncé.
''')
print(json.dumps({'cards':len(cards),'newCards':len(new),'captures':len(browser['screenshots'])}))
