import fs from 'node:fs';import path from 'node:path';import{fileURLToPath}from'node:url';
import{compileNavigationV105}from'../src/alien3-navigation-v105.js';
import{STEAM_RULES_V109 as rules,STEAM_DESIGN_V109 as contracts,compileSteamV109,createSteamV109}from'../src/alien3-steam-v109.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),model=compileNavigationV105(),geometry=compileSteamV109(model);
const d={schema:109,rules,contracts,geometry,doors:model.scene.gates,initial:createSteamV109({mode:'traque'},model),base:{sections:model.scene.spaces.length,assemblies:model.scene.decor.groups.length,components:model.scene.decor.props.length,nodes:model.nodes.length,edges:model.edges.length},scope:'Three finite pressure circuits with shared geometric fields. No new route or fluid solver; local encounter extension on V108.'};
fs.mkdirSync(path.join(root,'qa-v109'),{recursive:true});fs.writeFileSync(path.join(root,'qa-v109/design-source.json'),JSON.stringify(d,null,2)+'\n');
