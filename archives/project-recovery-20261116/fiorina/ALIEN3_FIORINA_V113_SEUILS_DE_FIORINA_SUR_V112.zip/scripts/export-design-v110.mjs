import fs from 'node:fs';import path from 'node:path';import {fileURLToPath}from'node:url';
import {compileNavigationV105}from'../src/alien3-navigation-v105.js';
import {STEAM_RULES_V109,compileSteamV109}from'../src/alien3-steam-v109.js';
import {TRAFFIC_RULES_V110,TRAFFIC_DESIGN_V110,createTrafficV110}from'../src/alien3-traffic-v110.js';
import {ENCOUNTERS_V105}from'../src/alien3-encounter-v105.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),m=compileNavigationV105();
const data={schema:110,rules:TRAFFIC_RULES_V110,steamRules:STEAM_RULES_V109,contracts:TRAFFIC_DESIGN_V110,geometry:compileSteamV109(m),participants:ENCOUNTERS_V105.rabattage.roster,initial:createTrafficV110({mode:'rabattage'},m),base:{sections:m.scene.spaces.length,assemblies:m.scene.decor.groups.length,components:m.scene.decor.props.length,nodes:m.nodes.length,edges:m.edges.length},scope:'Four additive modules on the verified V109 sources; closing and crew avoidance in the two original validation encounters, not a native full campaign.'};
fs.mkdirSync(path.join(root,'qa-v110'),{recursive:true});fs.writeFileSync(path.join(root,'qa-v110/design-source.json'),JSON.stringify(data,null,2)+'\n');
