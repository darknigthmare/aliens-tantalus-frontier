#!/usr/bin/env python3
"""Real-keyboard closed-gate detour and new-page save; no pose/stage edits in the route."""
from browser_support_v112 import *
PHASE=sys.argv[1]if len(sys.argv)>1 else 'detour'
if PHASE!='detour':raise SystemExit('V112: utiliser detour ; la reprise complète de file est vérifiée par verify-spacing-v112.py resume.')
def prisoner(p,id='morse'):return next(a for a in state(p)['participants']if a['id']==id)
def route_stats(p):return state(p)['routing']['stats']
def download(p,name):
 p.evaluate('document.body.classList.remove("capture")')
 with p.expect_download()as dl:p.locator('#export-save').click()
 file=OUT/name;dl.value.save_as(file);p.evaluate('document.body.classList.add("capture")');p.locator('canvas').focus();return file

def mid_gate(p):
 press(p,'KeyE');walk(p,3890);press(p,'KeyE')
 record('Le signal et la porte sont actionnés à leur emplacement par E',state(p)['stage']==1 and p.evaluate('fiorinaBench.engine.doors[2].open'))
 for _ in range(300):
  if prisoner(p)['x']+18>3720:break
  tick(p,1)
 record('Morse est réellement engagé sur le segment avant la fermeture',3720<prisoner(p)['x']+18<3770 and prisoner(p)['nextId']is not None,prisoner(p))
 press(p,'KeyE')
 record('La porte existante se referme sans traverser Morse',not p.evaluate('fiorinaBench.engine.doors[2].open') and prisoner(p)['x']+36<3828)
 snap(p,'41_porte_refermee','La porte de la fonderie est refermée après le signal, alors que Morse est engagé sur son trajet.')
 for _ in range(100):
  if route_stats(p)['retreats']>0:break
  tick(p,1)
 record('Morse choisit un retour au carrefour sans téléportation',route_stats(p)['retreats']>=1 and prisoner(p)['x']+36<=3828,route_stats(p))
 snap(p,'42_retour_carrefour','Morse revient physiquement vers le carrefour plutôt que de rester appuyé contre le battant fermé.')
 # Check every simulated step for both continuity and actual floor/segment identity.
 history=p.evaluate('''()=>{const e=fiorinaBench.engine,p=e.alien3EncounterV105.participants.find(p=>p.id==='morse'),trace=[];for(let i=0;i<440;i++){const x=p.x,y=p.y;fiorinaBench.tick(1/60);trace.push({x:p.x,y:p.y,delta:Math.hypot(p.x-x,p.y-y),node:p.nav.nodeId,next:p.nav.nextId,edge:p.nav.edgeId});}return trace;}''')
 record('Le détour respecte le budget de déplacement à chaque pas',max(t['delta']for t in history)<=112/60+1e-5,{'maxStep':max(t['delta']for t in history),'steps':len(history)})
 record('Morse descend par une connexion existante, pas par un raccourci inventé',max(t['y']for t in history)>470 and all(t['edge']is None or t['edge'].startswith('f161-e')for t in history))
 snap(p,'43_detour_inferieur','Morse utilise les passages inférieurs existants. La porte de fonderie reste fermée.')
 return history

def finish(p):
 walk(p,4362);hold(p,'ArrowUp',86);walk(p,4672);hold(p,'KeyE',110)
 record('Le collecteur est préparé à son vrai poste après le détour',state(p)['stage']==2)
 walk(p,4787,True);hold(p,'ArrowDown',86);walk(p,4902)
 for _ in range(400):
  if all(a['order']=='hold'for a in state(p)['participants']):break
  tick(p,4)
 record('Morse rejoint sa destination et Dillon tient la sienne sans ouvrir la porte',all(a['order']=='hold'for a in state(p)['participants']) and not p.evaluate('fiorinaBench.engine.doors[2].open') and route_stats(p)['arrivalsAfterDetour']>=1,state(p))
 snap(p,'44_postes_apres_detour','Les deux commandes sont tenues après le retour de Morse par le niveau inférieur.')
 hold(p,'KeyE',77);record('La présence aux deux postes permet seulement alors l’armement',state(p)['stage']==3)
 walk(p,4830)
 for _ in range(250):
  if state(p)['pursuit']['mode']=='windup':break
  tick(p,2)
 record('Le Runner prépare une attaque après son arrivée réelle',state(p)['pursuit']['mode']=='windup')
 walk(p,4918,True);p.keyboard.down('Space');tick(p,1);p.keyboard.up('Space');walk(p,5060,True);tick(p,20);press(p,'KeyE',15)
 record('Le piège capture le Runner présent dans le moule',state(p)['stage']==4 and state(p)['pursuit']['mode']=='trapped')
 snap(p,'45_coulee_apres_detour','La coulée suit l’arrivée des détenus et le rabattage au clavier ; aucune présence n’est injectée.')
 walk(p,4787,True);hold(p,'ArrowUp',86);walk(p,4672);hold(p,'KeyE',122)
 record('L’eau n’est libérée qu’après la coulée',state(p)['stage']==5 and not state(p)['runner']['alive'])
 walk(p,4362);hold(p,'ArrowDown',86);press(p,'KeyE');record('Rabattage terminé malgré la fermeture du passage initial',state(p)['status']=='complete')
 snap(p,'46_retour_morse','Retour auprès de Morse après détour, préparation, coulée et refroidissement.')
 routes.append({'profile':'rabattage-porte-et-detour','mode':'rabattage','setup':'Physical keyboard commands, real closed gate after crew started moving, actual ladder/walk detour; no actor pose or stage injection','result':state(p)})

with sync_playwright()as pw:
 browser=pw.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 p=start(browser,mode='trap');history=mid_gate(p)
 finish(p)
 p.close();record('Aucune erreur JavaScript du parcours V112',not errors,errors);record('Aucune requête réseau externe',not external,external);version=browser.version;browser.close()
result={'ok':True,'scope':'Native canvas and shared modules, local simplified host. Continuous keyboard route; no pose/stage injection during traversal. Not the full film campaign.','browser':version,'controls':len(tests),'results':tests,'routes':routes,'screenshots':captures,'errors':errors,'externalRequests':external,'sourceHashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (ROOT/'src').glob('*v112.js')}}
(OUT/('browser-routing-'+PHASE+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'controls':len(tests),'captures':len(captures)}))
