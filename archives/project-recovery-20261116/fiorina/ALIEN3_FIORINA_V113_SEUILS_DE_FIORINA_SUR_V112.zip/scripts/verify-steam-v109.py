#!/usr/bin/env python3
"""Continuous keyboard purge route; prepared physics comparisons are explicitly separate."""
from browser_support_v109 import *
PHASE=sys.argv[1]if len(sys.argv)>1 else 'route'
def steam(p):return p.evaluate('fiorinaBench.engine.alien3SteamV109')
def download(p,name):
 p.evaluate('document.body.classList.remove("capture")')
 with p.expect_download()as dl:p.locator('#export-save').click()
 path=OUT/name;dl.value.save_as(path);p.evaluate('document.body.classList.add("capture")');p.locator('canvas').focus();return path
with sync_playwright()as pw:
 browser=pw.chromium.launch(executable_path=shutil.which('chromium')or'/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 if PHASE=='route':
  p=start(browser,difficulty='decouverte');walk(p,1320);press(p,'KeyE',15);walk(p,1442);press(p,'KeyE');walk(p,1770,True);hold(p,'ArrowUp',3);walk(p,2755,True);hold(p,'ArrowDown',3);walk(p,2770,True);press(p,'KeyE');walk(p,2994,True)
  snap(p,'18_vanne_des_galeries','Vanne approchée au clavier pendant la traque active. Aucun déplacement injecté.')
  p.keyboard.down('KeyV');tick(p,40);record('La pression reste intacte pendant le geste partiel',steam(p)['work']is not None and steam(p)['circuits'][0]['pressure']==100);snap(p,'19_ouverture_en_cours','Ouverture partielle à la commande. Le repère est sur le volant.')
  tick(p,46);p.keyboard.up('KeyV');record('La purge est ouverte par le geste complet en traque',steam(p)['stats']['opened']==1,{'steam':steam(p),'state':state(p)})
  snap(p,'20_purge_des_galeries','Jet localisé après ouverture au clavier, pendant la traque.')
  walk(p,3330,True);snap(p,'21_au_dela_du_jet','Ripley a franchi le secteur par déplacement réel ; le jet ne remplace pas sa position.')
  walk(p,3052,True);hold(p,'ArrowUp',86);hold(p,'KeyE',70);record('Le relevé est obtenu après la purge, par le geste historique',state(p)['stage']==2)
  hunt_back(p,'purge-en-traque');record('Retour vivant après purge sans consommation des boulons',state(p)['status']=='complete' and steam(p)['stats']['opened']==1 and state(p)['diversion']['stats']['thrown']==0)
  snap(p,'22_retour_apres_purge','Retour complet auprès d’Aaron après l’usage du réseau de purge.')
  routes.append({'profile':'purge-en-traque-detail','setup':'UI start, keyboard travel/valves/ladder. No actor positions or stages injected. Known-route automated profile.', 'result':state(p)})
  p.close()
 if PHASE=='ventilation':
  p=start(browser);hunt_out(p,'visite-ventilation');walk(p,3102);hold(p,'KeyV',86)
  record('La vanne haute est atteinte par déplacement et échelle',steam(p)['circuits'][1]['uses']==1 and abs(state(p)['y']-240)<1)
  record('La purge haute ne vide pas la conduite du dessous',steam(p)['circuits'][0]['pressure']==100 and steam(p)['circuits'][0]['remaining']==0)
  snap(p,'29_purge_de_ventilation','Purge supérieure atteinte au clavier après montée et récupération du relevé.')
  walk(p,3052);hunt_back(p,'purge-ventilation');record('Retour auprès d’Aaron après la purge haute',state(p)['status']=='complete');p.close()
 if PHASE in ['geometry','resume','gesture']:
  # Reach the upper and foundry control on foot during the dormant preparation. No actor relocation.
  p=start(browser,mode='trap');press(p,'KeyE',15);walk(p,3890);press(p,'KeyE');walk(p,4106)
  if PHASE=='geometry':
   p.keyboard.down('KeyV');tick(p,86);p.keyboard.up('KeyV');record('Purge de fonderie au poste accessible sans modifier le piège',steam(p)['circuits'][2]['uses']==1 and state(p)['stage']==1)
   snap(p,'23_purge_de_fonderie','Purge de fonderie obtenue au clavier pendant la préparation où le Runner reste dormant.')
   walk(p,4330,True);hp=state(p)['hp'];tick(p,65);record('Rester dans le jet chaud inflige des brûlures',state(p)['hp']<hp,{'before':hp,'after':state(p)['hp']})
   snap(p,'24_danger_du_jet','Essai volontaire de traversée dangereuse au même étage, sans repositionnement forcé.')
   walk(p,4490,True);hp=state(p)['hp'];tick(p,80);record('Quitter le volume coupe les brûlures',state(p)['hp']==hp)
   record('Ni coulée ni refroidissement automatique',state(p)['flags']['poured']==False and state(p)['flags']['cooled']==False)
   p.close()
   # A prepared door at a known nozzle is used solely for geometric comparison; never mixed with traversal evidence.
   q=start(browser,mode='trap');q.evaluate('''()=>{const e=fiorinaBench.engine;const c=e.alien3SteamV109.circuits[0];c.uses=1;c.pressure=30;c.remaining=4;e.alien3SteamV109.stats.opened=1;Object.assign(e.player,{x:3000,y:420,depth:1,grounded:true});e.camera={x:2570,y:0};e.doors.push({id:'comparison-gate',x:3198,y:400,w:20,h:110,open:false,progress:0});}''')
   snap(q,'25_conduite_fermee','Comparaison dirigée : un battant de test fermé coupe le jet. Ce battant n’est pas ajouté à la campagne.',scope='directed geometry fixture, actor and gate positions prepared')
   closed=q.evaluate('(()=>{const c=document.querySelector("canvas").getContext("2d");return Array.from(c.getImageData(632,375,150,70).data)})()')
   q.evaluate('fiorinaBench.engine.doors.at(-1).open=true;fiorinaBench.engine.doors.at(-1).progress=1;fiorinaBench.render()')
   snap(q,'26_conduite_ouverte','Même instant préparé : le battant ouvert laisse le jet se prolonger.',scope='directed geometry fixture, same instant as closed-door comparison')
   opened=q.evaluate('(()=>{const c=document.querySelector("canvas").getContext("2d");return Array.from(c.getImageData(632,375,150,70).data)})()');record('La comparaison de porte change réellement les pixels du jet',closed!=opened)
   before=q.evaluate('JSON.stringify(fiorinaBench.exportState())');q.evaluate('(()=>{for(let i=0;i<20;i++)fiorinaBench.render()})()');record('Vingt dessins des conduites ne changent pas la sauvegarde',q.evaluate('JSON.stringify(fiorinaBench.exportState())')==before)
   q.close()
  if PHASE=='resume':
   hold(p,'KeyV',86);tick(p,50);file=download(p,'purge-active-v109.json');saved=json.loads(file.read_text());record('Un fichier réel contient le jet en cours et sa réserve',saved['schema']==109 and 0<saved['steam']['circuits'][2]['remaining']<6 and saved['steam']['circuits'][2]['pressure']==30)
   q=start(browser,mode='trap');q.evaluate('document.body.classList.remove("capture")');q.locator('#save-file').set_input_files(str(file));q.wait_for_function('document.querySelector("#save-status").textContent.includes("restaurée")')
   record('Import conservant le jet et restant en pause',q.evaluate('fiorinaBench.engine.paused') and steam(q)['circuits'][2]['remaining']==saved['steam']['circuits'][2]['remaining'])
   before=state(q);tick(q,120);record('Le jet importé ne s’écoule pas pendant la pause',state(q)==before)
   bad=json.loads(file.read_text());bad['steam']['circuits'][2]['pressure']=100
   forged=q.evaluate('''f=>{const body={base:f.base,steam:f.steam,safePoint:f.safePoint||null};let h=2166136261;const s=JSON.stringify(body);for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}f.checksum=(h>>>0).toString(16).padStart(8,'0');return JSON.stringify(f);}''',bad)
   broken=OUT/'purge-falsifiee-v109.json';broken.write_text(forged);before=q.evaluate('JSON.stringify(fiorinaBench.exportState())');q.locator('#save-file').set_input_files(str(broken));q.wait_for_function('document.querySelector("#save-status").textContent.includes("refusé")');record('Un jet actif à pression gratuite est refusé malgré une empreinte recalculée',q.evaluate('JSON.stringify(fiorinaBench.exportState())')==before)
   q.locator('#pause').click();q.evaluate('document.body.classList.add("capture")');q.locator('canvas').focus();tick(q,60);record('Reprendre écoule seulement le temps restant',0<steam(q)['circuits'][2]['remaining']<saved['steam']['circuits'][2]['remaining'])
   snap(q,'27_jet_repris','Reprise du jet depuis un fichier téléchargé puis importé dans une nouvelle page.')
   tick(q,900);record('La réserve revient après dissipation du jet',steam(q)['circuits'][2]['pressure']==100 and steam(q)['circuits'][2]['remaining']==0)
   q.close();p.close()
  if PHASE=='gesture':
   hold(p,'KeyV',35);tick(p,1);record('Relâcher V tôt interrompt sans dépenser la pression',steam(p)['work']is None and steam(p)['circuits'][2]['pressure']==100)
   p.keyboard.down('KeyV');tick(p,25);p.keyboard.down('ArrowLeft');tick(p,1);p.keyboard.up('ArrowLeft');p.keyboard.up('KeyV');record('Le déplacement est libre et annule le geste',steam(p)['work']is None)
   p.evaluate('document.body.classList.remove("capture")');p.locator('#interaction').select_option('toggle');p.evaluate('document.body.classList.add("capture")');press(p,'KeyV',86);record('Appuyer fonctionne sans maintien et sans raccourcir le geste',steam(p)['circuits'][2]['uses']==1)
   snap(p,'28_appuyer_pour_purger','Le mode accessible Appuyer ouvre la même conduite avec la même durée.')
   press(p,'KeyM');before=state(p);tick(p,150);record('Le plan suspend aussi le jet et la recharge',state(p)==before);press(p,'Escape')
   tick(p,730);p.evaluate('document.body.classList.remove("capture");document.querySelector(".touchpad").style.display="flex"');button=p.locator('#purge');button.scroll_into_view_if_needed();bb=button.bounding_box();p.mouse.click(bb['x']+bb['width']/2,bb['y']+bb['height']/2);tick(p,86)
   record('Le bouton pointeur partage l’interaction accessible',steam(p)['circuits'][2]['uses']==2)
   p.close()
 record('Aucune erreur JavaScript V109',not errors,errors);record('Aucune requête externe depuis le banc',not external,external);version=browser.version;browser.close()
result={'ok':True,'scope':'Shared V109 runtime in simplified local host; continuous keyboard routes separated from directed collision fixture. Not full native campaign.','browser':version,'controls':len(tests),'results':tests,'routes':routes,'screenshots':captures,'errors':errors,'externalRequests':external,'sourceHashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (ROOT/'src').glob('*v109.js')}}
(OUT/('browser-steam-'+PHASE+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'controls':len(tests),'captures':len(captures)}))
