#!/usr/bin/env python3
"""Seal the incremental V109 distribution without historical image/report duplication.
Source files, prior build tools, codex templates and provenance are retained.
No font files, browser caches, temporary logs or obsolete illustrated reports ship.
"""
from pathlib import Path
import json,hashlib,zipfile,re
R=Path(__file__).resolve().parents[1]
out=R.parent/'ALIEN3_FIORINA_V109_SOUFFLE_DES_CONDUITES_SUR_V108.zip'
items=[];omitted=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R).as_posix()
 if p.name=='manifest-v109.json' or '__pycache__' in p.parts or p.suffix.lower() in ['.pyc','.ttf','.otf','.woff','.woff2','.log'] or p.name.endswith('-exit.txt') or p.name.startswith('log-') or p.name=='smoke.png':continue
 historical=bool(re.match(r'RAPPORT_ILLUSTRE_V(?:104|105|106|107|108)\.(pdf|html)$',rel)) or (bool(re.match(r'qa-v(?:104|105|106|107|108)/',rel)) and p.suffix.lower() in ['.png','.jpg','.webp','.pdf'])
 if historical:omitted.append(rel);continue
 data=p.read_bytes()
 items.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema':109,'scope':'Incremental on exact V108 sources; five added modules and one engine link; local playable host. Full native game build NOT executed.','count':len(items),'omittedHistoricalGeneratedArtifacts':omitted,'files':items}
(R/'manifest-v109.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in items:z.write(R/f['path'],f['path'])
 z.write(R/'manifest-v109.json','manifest-v109.json')
with zipfile.ZipFile(out) as z:
 bad=z.testzip()
 if bad:raise RuntimeError(bad)
print(json.dumps({'ok':True,'manifestFiles':len(items),'historicalArtifactsOmitted':len(omitted),'archive':out.name,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
