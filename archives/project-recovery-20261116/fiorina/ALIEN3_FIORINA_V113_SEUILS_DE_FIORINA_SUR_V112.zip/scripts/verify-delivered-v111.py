#!/usr/bin/env python3
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib,shutil
R=Path(__file__).resolve().parents[1];Q=R/'qa-v111';checks=[]
def check(name,ok,detail=None):
 if not ok:raise AssertionError(name+': '+str(detail))
 checks.append({'name':name,'ok':True,'details':detail})
def schema(f,n):
 while f.get('schema')!=n:f=f['base']
 return f
def encounter(f):
 while f.get('schema')!=105:f=f['base']
 return f['encounter']
def pose(f):
 while f.get('schema')!=105:f=f['base']
 return f['base']['pose']
with sync_playwright()as pw:
 b=pw.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);p=b.new_page(viewport={'width':1360,'height':960});errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 p.set_content((R/'FIORINA_V111_JOUER.html').read_text(),wait_until='load');p.wait_for_timeout(150)
 check('Le fichier distribué ne publie pas l’API QA',not p.evaluate('"fiorinaBench" in window'))
 p.locator('#trap').click()
 def download(name):
  with p.expect_download()as dl:p.locator('#export-save').click()
  path=Q/name;dl.value.save_as(path);return json.loads(path.read_text())
 first=download('delivered-before.json');check('Le menu lance le rabattage original',encounter(first)['mode']=='rabattage'and first['schema']==111)
 check('Trois conduites chargées figurent dans le fichier réel',len(schema(first,109)['steam']['circuits'])==3 and all(c['pressure']==100 for c in schema(first,109)['steam']['circuits']))
 out=first
 for _ in range(20):
  if pose(out)['x']>=4076:break
  p.locator('canvas').focus();p.keyboard.down('ArrowRight');p.wait_for_timeout(200);p.keyboard.up('ArrowRight');out=download('delivered-approach.json')
 check('La vanne est approchée sans API cachée',4076<=pose(out)['x']<=4150,pose(out))
 check('L’horloge de requestAnimationFrame avance',encounter(out)['clock']>encounter(first)['clock'])
 p.locator('canvas').focus();p.keyboard.down('KeyV')
 for _ in range(24):
  p.wait_for_timeout(200);out=download('delivered-purge.json')
  if schema(out,109)['steam']['stats']['opened']>0:break
 p.keyboard.up('KeyV')
 check('V ouvre réellement une purge dans le HTML ordinaire',schema(out,109)['steam']['stats']['opened']==1 and schema(out,109)['steam']['circuits'][2]['pressure']==30,schema(out,109)['steam'])
 check('Le geste ne valide pas le premier objectif historique',encounter(out)['stage']==0)
 check('L’export en cours de jet contient un temps restant fini',0<schema(out,109)['steam']['circuits'][2]['remaining']<=6)
 check('Les boulons hérités restent disponibles',schema(out,108)['diversion']['stats']['thrown']==0 and len(schema(out,108)['diversion']['bolts'])==3)
 p.locator('canvas').focus();p.keyboard.down('KeyV')
 for _ in range(14):
  p.wait_for_timeout(120);out=download('delivered-closed.json')
  if schema(out,110)['traffic']['stats']['closed']>0:break
 p.keyboard.up('KeyV')
 check('V referme le jet dans le fichier ordinaire sans API de test',schema(out,110)['traffic']['stats']['closed']==1,schema(out,110)['traffic'])
 check('La fermeture ne rembourse pas la réserve et ne crée pas une ouverture',schema(out,109)['steam']['circuits'][2]['pressure']==30 and schema(out,109)['steam']['stats']['opened']==1)
 check('Le jet refermé conserve une courte dissipation',0<schema(out,109)['steam']['circuits'][2]['remaining']<=1.5)
 p.locator('#pause').click();paused=download('delivered-paused.json');p.wait_for_timeout(300);after=download('delivered-still-paused.json');check('Pause du fichier ordinaire fige le temps restant',schema(after,109)['steam']==schema(paused,109)['steam'] and schema(after,110)['traffic']==schema(paused,110)['traffic'])
 check('Le fichier V111 ne divulgue aucune route future du groupe',out['routes']['schema']==111 and 'memory'not in out['routes'])
 check('Aucune erreur JavaScript',not errors,errors);b.close()
(Q/'delivered.json').write_text(json.dumps({'ok':True,'tests':len(checks),'checks':checks,'sourceHash':hashlib.sha256((R/'FIORINA_V111_JOUER.html').read_bytes()).hexdigest(),'scope':'Ordinary delivered HTML, no QA API; real exported files used to read progress'},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'tests':len(checks)}))
