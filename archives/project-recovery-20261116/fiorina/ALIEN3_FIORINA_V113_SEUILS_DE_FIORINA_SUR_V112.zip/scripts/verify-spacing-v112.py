#!/usr/bin/env python3
"""Continuous keyboard queue, release and complete trap; file reprise on a fresh page.
Only UI start establishes the initial pose. No progress/position edits during traversal.
"""
from browser_support_v112 import *
PHASE=sys.argv[1]if len(sys.argv)>1 else 'route'
_native_snap=snap
def snap(page,name,*args,**kwargs):
 if PHASE=='resume' and not name.startswith('55_'):name+='_reprise'
 return _native_snap(page,name,*args,**kwargs)
def crew(p,id):return next(a for a in state(p)['participants']if a['id']==id)
def setup_queue(p):
 press(p,'KeyE',1)
 record('Le signal est donné à Dillon avant la coordination',state(p)['stage']==1)
 press(p,'KeyG',1)
 record('G demande réellement à Dillon d’attendre',state(p)['senses']['holds'].get('dillon') is True)
 walk(p,3890);press(p,'KeyE');record('La porte ouverte donne accès à Morse',p.evaluate('fiorinaBench.engine.doors[2].open'))
 walk(p,3990)
 for _ in range(100):
  if state(p)['spacing']['waiting'].get('morse'):break
  tick(p,4)
 a,b=crew(p,'morse'),crew(p,'dillon');gap=b['x']-a['x']-36
 record('Morse conserve une marge devant le corps de Dillon',14-1e-4<=gap<=17 and state(p)['spacing']['waiting'].get('morse',{}).get('actorId')=='dillon',{'gap':gap,'morse':a,'dillon':b})
 pose=(a['x'],a['y'],a['nodeId'],a['nextId']);stride=p.evaluate('JSON.stringify(fiorinaBench.engine.alien3CrewStrideV107)');sounds=state(p)['operations']['stats']['crewSteps'];tick(p,90)
 a=crew(p,'morse');record('L’attente garde la même pose et le même segment',pose==(a['x'],a['y'],a['nodeId'],a['nextId']))
 record('Une file immobile ne crée aucun bruit de pas',p.evaluate('JSON.stringify(fiorinaBench.engine.alien3CrewStrideV107)')==stride and state(p)['operations']['stats']['crewSteps']==sounds)
 record('Le détenu bloqué n’est pas déclaré arrivé',a['order']!='hold' and a['nodeId']!=a['goal'])
 snap(p,'50_morse_attend_dillon','Morse garde une marge derrière Dillon retenu par G. La porte est ouverte, mais le corps du détenu n’est plus traversé.')
 press(p,'KeyM');before=state(p);tick(p,90);record('Le plan suspend aussi la file d’attente',state(p)==before);press(p,'Escape')
 press(p,'KeyC');before=state(p);tick(p,90);record('Les archives n’avancent pas les participants en attente',state(p)==before);press(p,'KeyC')
 return p

def release(p):
 old=(crew(p,'morse')['x'],crew(p,'dillon')['x']);press(p,'KeyG')
 record('Un nouveau G redonne le départ à Dillon, sans ordre caché sur Morse',not state(p)['senses']['holds'].get('dillon'))
 trace=p.evaluate('''()=>{const e=fiorinaBench.engine,a=e.alien3EncounterV105.participants.find(p=>p.id==='morse'),b=e.alien3EncounterV105.participants.find(p=>p.id==='dillon'),out=[];for(let i=0;i<75;i++){const x=a.x,y=a.y,bx=b.x,by=b.y;fiorinaBench.tick(1/60);out.push({x:a.x,y:a.y,step:Math.hypot(a.x-x,a.y-y),otherStep:Math.hypot(b.x-bx,b.y-by),gap:b.x-a.x-a.w});}return out;}''')
 record('La reprise respecte un seul budget et maintient la marge',all(t['step']<=112/60+1e-5 and t['otherStep']<=105/60+1e-5 and t['gap']>=14-1e-4 for t in trace),{'minGap':min(t['gap']for t in trace),'maxStep':max(t['step']for t in trace)})
 record('Le suivant réduit son allure au lieu d’avancer par à-coups',all(t['step']>1.6 for t in trace[3:]) and state(p)['spacing']['stats']['limitedSteps']>15)
 record('Aucune position n’est replacée lors de la reprise',crew(p,'morse')['x']>old[0] and crew(p,'dillon')['x']>old[1])
 snap(p,'51_le_groupe_repart','Dillon et Morse repartent depuis leurs positions réelles. Le suivant ajuste son pas pour ne pas rattraper son voisin.')

def finish(p,tag):
 walk(p,4362);hold(p,'ArrowUp',86);walk(p,4672);hold(p,'KeyE',110)
 record('L’eau est préparée par la manœuvre existante',state(p)['stage']==2)
 walk(p,4787,True);hold(p,'ArrowDown',86);walk(p,4902)
 for _ in range(350):
  if all(a['order']=='hold'for a in state(p)['participants']):break
  tick(p,4)
 record('Les deux arrivées physiques restent nécessaires au piège',all(a['order']=='hold'for a in state(p)['participants']) and crew(p,'morse')['nodeId']=='f161-lead-primer'and crew(p,'dillon')['nodeId']=='f161-piston-c-node')
 snap(p,'52_postes_apres_file','Les commandes sont atteintes après attente et reprise de la file, jamais par validation de la nouvelle couche.')
 hold(p,'KeyE',77);record('Le moule ne s’arme qu’après les deux arrivées',state(p)['stage']==3)
 walk(p,4830)
 for _ in range(250):
  if state(p)['pursuit']['mode']=='windup':break
  tick(p,2)
 record('Le Runner conserve sa préparation d’attaque',state(p)['pursuit']['mode']=='windup')
 walk(p,4918,True);p.keyboard.down('Space');tick(p,1);p.keyboard.up('Space');walk(p,5060,True);tick(p,20);press(p,'KeyE',15)
 record('La coulée demande encore le Runner réellement au moule',state(p)['stage']==4 and state(p)['pursuit']['mode']=='trapped')
 snap(p,'53_coulee_apres_file','Coulée après les postes tenus et une esquive au clavier. La circulation du groupe n’a modifié aucun objectif.')
 walk(p,4787,True);hold(p,'ArrowUp',86);walk(p,4672);hold(p,'KeyE',122)
 record('Le refroidissement suit la coulée sans raccourci',state(p)['stage']==5 and not state(p)['runner']['alive'])
 walk(p,4362);hold(p,'ArrowDown',86);press(p,'KeyE')
 record('Rabattage terminé après la file — '+tag,state(p)['status']=='complete',{'health':state(p)['hp'],'clock':state(p)['clock'],'spacing':state(p)['spacing']['stats']})
 snap(p,'54_retour_apres_file','Retour final auprès de Morse après une séquence complète avec attente corporelle et reprise.')
 routes.append({'profile':tag,'mode':'rabattage','setup':'Held G order and released by real keys; full keyboard traversal with no pose/stage/arrival injection','result':state(p)})

with sync_playwright()as pw:
 browser=pw.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);p=start(browser,mode='trap');setup_queue(p)
 if PHASE=='resume':
  p.evaluate('document.body.classList.remove("capture")')
  with p.expect_download()as dl:p.locator('#export-save').click()
  file=OUT/'file-attente-v112.json';dl.value.save_as(file);raw=json.loads(file.read_text());p.evaluate('document.body.classList.add("capture")')
  record('Le fichier contient un registre, pas une réservation persistante',raw['schema']==112 and 'waiting'not in raw['spacing']and 'memory'not in raw['base']['routes'])
  q=start(browser,mode='trap');q.evaluate('document.body.classList.remove("capture")');q.locator('#save-file').set_input_files(str(file));q.wait_for_function('document.querySelector("#save-status").textContent.includes("restaurée")')
  record('Nouvelle page : poses, segments et ordre G sont restaurés',[(a['x'],a['y'],a['nodeId'],a['nextId'])for a in state(q)['participants']]==[(a['x'],a['y'],a['nodeId'],a['nextId'])for a in state(p)['participants']] and state(q)['senses']['holds'].get('dillon'))
  record('La file transitoire est vide en pause, pas récupérée du fichier',state(q)['spacing']['waiting']=={} and q.evaluate('fiorinaBench.engine.paused'))
  before=state(q);tick(q,120);record('La pause importée préserve les positions et compteurs',state(q)==before)
  bad=json.loads(file.read_text());bad['spacing']['stats']['resumes']=bad['spacing']['stats']['waits']+1
  text=q.evaluate('''r=>{const body={base:r.base,spacing:r.spacing,safePoint:r.safePoint||null},s=JSON.stringify(body);let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}r.checksum=(h>>>0).toString(16).padStart(8,'0');return JSON.stringify(r);}''',bad)
  corrupt=OUT/'file-attente-invalide.json';corrupt.write_text(text);before=q.evaluate('JSON.stringify(fiorinaBench.exportState())');q.locator('#save-file').set_input_files(str(corrupt));q.wait_for_function('document.querySelector("#save-status").textContent.includes("refusé")')
  record('Un registre incohérent recalculé ne remplace pas la partie',q.evaluate('JSON.stringify(fiorinaBench.exportState())')==before)
  q.locator('#pause').click();q.evaluate('document.body.classList.add("capture")');q.locator('canvas').focus();tick(q,1)
  record('La reprise recalcule l’attente depuis les corps présents',state(q)['spacing']['waiting'].get('morse',{}).get('actorId')=='dillon')
  snap(q,'55_file_apres_import','Le fichier a été importé dans une nouvelle page. La file est recalculée depuis les corps, pas imposée par une réservation périmée.','real export/import during keyboard traversal')
  p.close();p=q
 release(p);finish(p,'rabattage-file-reprise'if PHASE=='resume'else'rabattage-file-et-depart')
 pure=p.evaluate('''()=>{const s=JSON.stringify(fiorinaBench.exportState());for(let i=0;i<20;i++)fiorinaBench.render();return s===JSON.stringify(fiorinaBench.exportState());}''');record('Vingt rendus ne font progresser ni file ni sauvegarde',pure)
 p.close();record('Aucune erreur JavaScript pendant le parcours V112',not errors,errors);record('Aucune requête réseau externe',not external,external);version=browser.version;browser.close()
result={'ok':True,'controls':len(tests),'results':tests,'routes':routes,'screenshots':captures,'errors':errors,'externalRequests':external,'browser':version,'scope':'Local shared modules in simplified host. Continuous keyboard traversal, no pose/stage changes. Not a native campaign validation.','sourceHashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (ROOT/'src').glob('*v112.js')}}
(OUT/('browser-spacing-'+PHASE+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'controls':len(tests),'captures':len(captures)}))
