#!/usr/bin/env python3
"""Codex and reports generated from executable contracts and verified native captures."""
from pathlib import Path
from html import escape as esc
import json,re,subprocess,collections,base64,hashlib
R=Path(__file__).resolve().parents[1];Q=R/'qa-v109';D=R/'docs';D.mkdir(exist_ok=True)
subprocess.run(['node',str(R/'scripts/export-design-v109.mjs')],check=True)
src=json.loads((Q/'design-source.json').read_text());u=json.loads((Q/'unit.json').read_text());ins=json.loads((Q/'install.json').read_text());b=json.loads((Q/'browser.json').read_text());ordinary=json.loads((Q/'delivered.json').read_text());rules=src['rules']
old=(R/'ALIEN3_CODEX_LEVEL_DESIGN_V108.html').read_text();start=old.index('const cards=')+len('const cards=');cards,end=json.JSONDecoder().raw_decode(old[start:]);assert len(cards)==535
new=[]
def add(kind,id,title,text,details):new.append({'type':kind,'id':id,'title':title,'text':text,'details':details})
for rule in src['contracts']:add('Règles V109',rule['id'],rule['text'].split('.')[0],rule['text'],[['Preuve','qa-v109/unit.json','Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète.'],['Parcours','encounter-traque','Les ouvertures au clavier sont séparées des comparaisons de porte dirigées.']])
for site in src['geometry']['sites']:
 sid=site['id'];cid='purge109-'+sid
 add('Conduites de purge',cid,site['label'],f'Poste rattaché à {site["nodeId"]}, dans l’ensemble {site["assembly"]}. Une réserve de 100 unités abstraites alimente ce seul jet. Ouvrir coûte {rules["cost"]} unités et ne dépense ni eau du piège ni plomb.',[['Appui',site['nodeId'],f'Pied Y {site["foot"]}, support {site["supportId"]}, profondeur {site["depth"]}.'],['Commande','input109-purge',f'Centre du volant ({site["controlX"]}, {site["controlY"]}), portée horizontale {rules["range"]}, tolérance verticale {rules["height"]}, profondeur ±{rules["depth"]}.'],['Buse','field109-'+sid,f'Origine ({site["outletX"]}, {site["outletY"]}) ; sens {site["sign"]}, portée maximale {rules["reach"]}.'],['Réserve','steamstate109-refill',f'Recharge de {rules["recharge"]} unités/s après fin de dissipation ; aucun cumul de jets.']])
 parts=[('box','Boîtier de vanne',f'X {site["controlX"]-20}, Y {site["controlY"]-30}, 40 × 55 unités. Platine en retrait ; aucun obstacle nouveau.'),('wheel','Volant et cadran',f'Volant de rayon 12 à ({site["controlX"]}, {site["controlY"]+4}), cadran de rayon 8 à Y {site["controlY"]-19}. L’aiguille utilise la réserve réelle.'),('line','Liaison et buse',f'Liaison depuis ({site["controlX"]+18}, {site["controlY"]-19}) via X {site["outletX"]-15} vers ({site["outletX"]}, {site["outletY"]}).')]
 for id,title,text in parts:add('Composants V109','part109-'+sid+'-'+id,title+' · '+site['label'],text,[['Ensemble propriétaire',cid,'Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques.'],['Silhouette','art109-render','L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra.']])
 add('Volumes de vapeur','field109-'+sid,'Jet · '+site['label'],f'Champ de référence X {site["outletX"]} à {site["outletX"]+rules["reach"]}, Y {site["foot"]-rules["plumeHeight"]} à {site["foot"]}, profondeur {site["depth"]}. Le dessin, la reconnaissance et la chaleur consultent ce même volume.',[['Conduite',cid,'Une porte fermée tronque ce champ à sa première face ; un battant à l’autre étage ne le tronque pas.'],['Reconnaissance','sense109-vision','Au-delà de 90 unités, le jet dense interrompt la vue à travers son volume. Le contact proche et la trace mémorisée restent possibles.'],['Chaleur','steamstate109-jet',f'Après {rules["heatWarmup"]} seconde d’exposition, {rules["damagePerPeriod"]} points toutes les {rules["damagePeriod"]} seconde tant que Ripley reste dedans.']])
for id,title,text,detail in [
 ('ready','Conduite disponible','Le cadran présente une réserve suffisante. La conduite n’a aucun jet actif.','Au moins 70 unités ; contrôle à portée et présence continue pendant le geste.'),
 ('opening','Ouvrir le volant','Le geste dure 1,4 seconde. La pression n’est pas retirée avant la fin.','Le déplacement reste libre ; mouvement, saut, dégâts, relâchement ou panneau interrompent le geste.'),
 ('jet','Souffle chaud','Le jet chaud dure 4,8 secondes ; il est bruyant, obscurcissant et dangereux pour Ripley.','Il ne blesse pas le Runner et aucun dommage nouveau aux détenus n’est ajouté. La préparation du piège reste dormante.'),
 ('tail','Dissipation','Une traîne de 1,2 seconde suit le souffle ; sa densité visuelle diminue et elle n’inflige plus de chaleur.','La traîne ne recharge pas encore le circuit. Le masquage visuel cesse quand la densité passe sous le seuil.'),
 ('refill','Remise en pression','La réserve remonte seulement après disparition du jet. Elle ne dépasse pas 100 unités.','À partir de 30 unités, il faut environ 5,72 secondes après dissipation pour revenir à 70, dix secondes pour retrouver 100.')]:
 add('États des conduites','steamstate109-'+id,title,text,[['Contrat','A3-109-pressure',detail],['Fichier','save109-current','État courant exporté explicitement ; aucun son ni geste partiel rejoué.']])
add('Perception V109','sense109-vision','Voir à travers la vapeur','La perception V106 est prolongée avec le champ réel du jet. Le volume dense interrompt la reconnaissance à distance, mais ne supprime ni la dernière trace ni une attaque engagée.',[['Portée proche','A3-109-sight',f'À {rules["nearSight"]} unités ou moins, cette couche ne masque pas la vue. Les portes et contraintes historiques continuent à s’appliquer.'],['Étage','A3-109-collision','Les deux corps doivent se trouver au même étage que le jet et dans sa profondeur pour ce masquage.'],['Parité','qa-v109/unit.json','Sans vapeur, 180 frames de décisions V106/V109 sont comparées directement.']])
add('Perception V109','sense109-sound','Entendre dans le souffle','Le sifflement vient de la buse. Un petit bruit émis dans le jet, ou reçu par le Runner qui le traverse, garde son origine et son identifiant mais sa puissance est multipliée par 0,60.',[['Intensité','A3-109-sound','Bruit d’ouverture 1,0 ; impulsions de souffle 0,56, au plus une toutes les 0,95 s. Aucune rafale sonore à chaque frame.'],['Boulons','hearing108-impact','Les impacts des boulons restent suivis. Un bruit masqué n’est pas téléporté vers la conduite.'],['Limite','A3-109-danger','Le bruit propre de la purge n’est pas atténué par elle-même et peut attirer le Runner. Pas de silence magique.']])
add('Commandes V109','input109-purge','Actionner une purge','V ou le bouton Purge ouvre le poste accessible. Le mode Maintenir demande une pression continue ; le mode Appuyer partage la durée et permet une annulation par second appui.',[['Accès','A3-109-distance','Au sol, bon étage, profondeur intermédiaire vérifiée et aucune porte entre le corps et le volant.'],['Conflits','A3-109-abort','Une préparation de piège en cours refuse la purge. Pendant le geste, E, le lancer, le bruit volontaire et les ordres aux détenus sont refusés. Fuir reste autorisé.'],['Pause','A3-109-pause','Plan, archives et perte de focus annulent le geste. La vapeur déjà libérée attend la reprise.']])
for id,title,text in [
 ('current','Fichier de reprise V109','Le fichier V108 valide est enveloppé avec le registre des trois conduites. La pression, la durée restante et les comptes d’utilisation sont conservés. Le geste en cours est retiré, et les événements sonores ne sont pas rejoués.'),
 ('checkpoint','Réserves du dernier poste sûr','Le poste sûr possède son propre registre, différent de la situation actuelle. Il ne peut être enregistré pendant un geste. Reprendre après un échec retrouve l’état vivant de ce poste.'),
 ('migration','Migration V105 à V108','Les anciennes sauvegardes valides reçoivent trois circuits initialement pleins. Leur poste sûr est migré séparément de leur progression et inventaire actuels.'),
 ('validation','Refus d’un état incohérent','Une réserve gratuite pendant un jet actif, une conduite inconnue, une durée infinie, un compte d’utilisation contradictoire ou un fichier trop volumineux sont refusés avant remplacement de la session.')]:
 add('Reprises V109','save109-'+id,title,text,[['Validation','A3-109-save','Limite 1 Mio ; empreinte de corruption et invariants de domaine, pas signature anti-triche.'],['Pause','A3-109-pause','Import en pause. Marge de 0,9 seconde à la reprise avant un nouveau dégât de vapeur, pour ne pas exécuter un impact suspendu.'],['Base','save108-current','Les contrôles de position, d’inventaire, de participants et de progression antérieurs restent actifs.']])
add('Rendu V109','art109-render','Vapeur localisée et raccordée','Trois postes utilisent les appuis du réseau existant. Le jet visible est découpé exactement sur le volume d’effet. La commande s’efface partiellement si elle recouvre Ripley.',[['Dessin','A3-109-scope','Les images du rapport viennent du canvas de ces modules ; aucune réillustration ni superposition de screenshot historique.'],['Lisibilité','A3-109-danger','Le repère de progression se trouve sur le volant. Un avertissement de brûlure utilise une phrase courte.'],['Mouvement réduit','A3-109-pause','Ambiances immobiles supprime la translation des bouffées, pas les durées de jeu ni la baisse de densité.']])
cards+=new;assert len({c['id']for c in cards})==len(cards)
# Preserve the working accessible renderer; replace only its embedded dataset and header.
out=old[:start]+json.dumps(cards,ensure_ascii=False).replace('</script','<\\/script')+old[start+end:]
out=out.replace('FIORINA 161 / DOCUMENT DE CONCEPTION V108','FIORINA 161 / DOCUMENT DE CONCEPTION V109').replace('<h1>Échos de métal</h1>','<h1>Le souffle des conduites</h1>').replace('535 fiches issues',f'{len(cards)} fiches issues')
newopts=''.join('<option>'+esc(k)+'</option>'for k in dict.fromkeys(c['type']for c in new));out=out.replace('</select></div>',newopts+'</select></div>',1)
out=re.sub(r'<div class="scope">.*?</div>','<div class="scope">Codex de conception hors jeu. Trois purges aux appuis réels : pression, vapeur dangereuse, vision et bruit localisés. Le banc reste simplifié et distinct de la campagne native.</div>',out,count=1,flags=re.S)
(R/'ALIEN3_CODEX_LEVEL_DESIGN_V109.html').write_text(out);(Q/'codex-source.json').write_text(json.dumps({'schema':109,'cards':cards},ensure_ascii=False,indent=2)+'\n')
md=['# Alien 3 — Codex de level design V109','## Le souffle des conduites','',f'{len(cards)} fiches, dont {len(new)} nouveaux contrats. Document de conception extérieur au jeu ; les 90 archives du joueur ne sont pas une collection de ces fiches.','',
'## Périmètre','Trois postes sont rattachés à des appuis existants et aux installations de pompage, de ventilation et de fonderie. Leurs volumes sont communs au dessin, au masquage visuel et à la chaleur. Une réserve abstraite finie se recharge avec le temps, pas une simulation de thermodynamique ni un débit d’eau du piège.','Le jet reste dangereux pour Ripley, bruyant et visible par les deux acteurs. Il ne remplace pas une porte, n’efface pas la mémoire du Runner et ne blesse pas les détenus. Aucune nouvelle carte ni aucun nouvel organisme ne sont créés.','Les neuf groupes de formes des postes ne sont pas neuf modèles originaux séparés : ce sont trois compositions d’un même équipement. Le reste du décor demeure celui de la base.','Les captures exécutent le renderer livré dans un banc à physique de base et personnages simplifiés. Les parcours et les comparaisons dirigées de portes sont séparés dans le rapport.','']
for c in cards:md += [f'### {c["title"]}',f'`{c["id"]}` · {c["type"]}',c['text'],'','| Élément | Référence | Contrat |','|---|---|---|',*['| '+' | '.join(str(x).replace('|','/')for x in row)+' |'for row in c['details']],'']
(D/'ALIEN3_LEVEL_DESIGN_CODEX_V109.md').write_text('\n'.join(md));counts=dict(collections.Counter(c['type']for c in cards));(Q/'documentation.json').write_text(json.dumps({'schema':109,'cards':len(cards),'newCards':len(new),'byCategory':counts,'baseComponents':src['base']['components'],'valves':3,'fittingGroups':9,'markdownLines':len(md)},ensure_ascii=False,indent=2)+'\n')
css=re.search(r'<style>(.*?)</style>',old,re.S).group(1);panels=[]
for shot in b['screenshots']:
 raw=(R/shot['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==shot['sha256']
 scope='Comparaison dirigée : positions et/ou battant préparés, distincte des traversées.'if'directed'in shot['scope']else'Parcours ou interaction au clavier/pointeur. Le robot connaît le chemin ; ce n’est pas une session humaine.'
 panels.append(f'<section class="panel"><h2>{esc(shot["caption"])}</h2><img alt="Capture native de Fiorina dans le banc local" src="data:image/png;base64,{base64.b64encode(raw).decode()}"><p class="caption">{scope} Modules livrés, base physique et silhouettes simplifiées.</p></section>')
(R/'RAPPORT_ILLUSTRE_V109.html').write_text(f'''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Alien 3 — Rapport V109</title><style>{css}</style><header><small>FIORINA 161 · RAPPORT V109</small><h1>Le souffle des conduites</h1><p>Trois purges limitées, de la vapeur visible et dangereuse, des reprises qui conservent la pression.</p></header><main><div class="scope">Captures natives des modules livrés exécutés dans un banc à physique simplifiée. Pas de rendu inventé à partir d’un JSON, pas de build Tantalus complet ni de campagne intégrale certifiée.</div><section class="panel"><h2>Vérifications exécutées</h2><p>{u['cases']} cas unitaires, {ins['cases']} installations sur projets synthétiques, {b['controlsExecuted']} assertions Chromium en {len(b['phases'])} groupes et {ordinary['tests']} contrôles du HTML ordinaire sans API QA. Les répétitions entre parcours sont comptées.</p><p>Le parcours de purge des galeries rapporte le relevé à Aaron : la vapeur masque effectivement plusieurs contrôles de vision, mais inflige aussi trois points de brûlure lors du franchissement. La voie haute et le rabattage ont également été parcourus au clavier.</p></section>{''.join(panels)}</main></html>''')
qa=['# QA — Alien 3 V109','', '## Résultats et portée',f'- {u["cases"]} cas unitaires V109 sur base instrumentée.',f'- {ins["cases"]} scénarios d’installation à npm synthétique.',f'- {b["controlsExecuted"]} assertions Chromium dans {len(b["phases"])} groupes ; {b["uniqueControlNames"]} libellés distincts.',f'- {ordinary["tests"]} contrôles du fichier distribué sans API de test.',f'- {len(b["screenshots"])} captures natives Chromium.','Les deux séquences restent des parcours originaux de validation. Aucun build natif complet ni fidélité 1:1 du film ne sont certifiés.','', '## Parcours au clavier','| Profil | État | Santé | Contacts | Purges | Brûlures | Durée simulée |','|---|---|---:|---:|---:|---:|---:|']
for route in b['routes']:
 s=route['result'];st=s.get('steam',{}).get('stats',{});qa.append(f'| {route["profile"]} | {s["status"]} | {s["hp"]} | {s["pursuit"]["stats"]["hits"]} | {st.get("opened",0)} | {st.get("heatDamage",0)} | {s["clock"]:.2f} s |')
qa += ['','Les parcours emploient les gestionnaires clavier et une horloge contrôlée ; aucune position, arrivée de détenu ou étape n’est injectée pendant les traversées. Les robots connaissent les itinéraires. Les valeurs de temps ne sont pas des durées de campagne humaine.','', '## Corrections pendant les contrôles','- Un bruit au niveau du pied était exactement sur la frontière du volume ; son test de masquage utilise maintenant une petite hauteur de référence tout en conservant le pied et l’origine de l’événement.','- Une référence de fichier V108 subsistait dans un script navigateur copié. Le script vérifie maintenant le schéma 109 du fichier exécuté avant le début du parcours ; toutes les preuves finales proviennent de la nouvelle page.','- Les formes de vapeur ont un bord radial adouci et la commande est moins opaque quand elle recouvre Ripley.','- L’essai de recharge attend la fin du souffle puis les dix secondes nécessaires pour passer de 30 à 100, sans demander une recharge artificiellement instantanée.','', '## Preuves ciblées','- Sans jet, parité des décisions V106/V109 vérifiée sur 180 frames.','- Champ de vapeur commun au rendu, à la vue et à la chaleur ; portes fermées et étages distincts testés.','- Reprise par fichier téléchargé puis importé sur une nouvelle page : jet, pression et pause conservés.','- Geste incomplet non repris ; fichier incohérent refusé malgré empreinte recalculée.','- Appuyer et bouton pointeur utilisent la même durée et le même coût.','', '## Régressions séparées','V108 : 59 cas unitaires et 19 installations ; V107 : 56 et 19. Les suites historiques restent indépendantes de la qualification du moteur complet. Une route V108 de diversion par boulon a aussi été rejouée dans la composition V109.','', '## Limites','Les trois réserves sont abstraites et indépendantes ; ce n’est pas une simulation de réseau de pression complet. Les jets n’endommagent pas le Runner ni les détenus, et ne déclenchent ni plomb ni refroidissement. Les anciennes sources restent les propriétaires des objectifs. Le prédateur reste dormant pendant la préparation avant armement.','Banc avec physique de base et acteurs vectoriels provisoires. Pas de campagne native entière, session humaine, manette physique, Safari, écoute matérielle ou tests de performance cibles. Pas de nouvelle lecture GitHub ou refus de droit prétendu ce tour.','', '## Installation','Cinq nouveaux modules et un raccord du moteur sur les 42 sources V108 exactes. Aucun module antérieur modifié. Travail préparé dans une copie, contrôles npm du projet puis report des octets validés et contrôle de concurrence. Les commandes des fixtures sont synthétiques, pas un build de Tantalus.']
(R/'RAPPORT_QA_V109.md').write_text('\n'.join(qa))
(D/'PORTEE_V109.md').write_text('''# Portée V109

| Sujet | Livré / vérifié | Non revendiqué |
|---|---|---|
| Purges | Trois commandes, réserve et durée finies | Simulation thermodynamique ou nouveau réseau de mission |
| Chasse | Jet dense gêne la vue distante, petits sons atténués, sifflement local | Invisibilité, mémoire effacée, attaque annulée, diversion garantie |
| Chaleur | Brûlure de Ripley dans le jet actif, même étage et profondeur | Arme contre le Runner ou nouveaux dégâts aux détenus |
| Reprise | Réserve et jet conservés, import en pause, poste sûr séparé | Autosave disque, cloud, anti-triche |
| Rendu | Modules réels, captures natives et ambiances immobiles | Art final ou représentation officielle du film |
| Intégration | Sources exactes V108, staging et restauration testés | Build natif complet, push ou déploiement |
''')
(R/'README.md').write_text(f'''# Alien 3 — Fiorina 161 V109 · Le souffle des conduites

Correctif incrémental **sur une base V108 compatible**, avec aperçu jouable autonome. Ce n’est pas le jeu principal complet.

## Jouer
Ouvrir `FIORINA_V109_JOUER.html` dans un navigateur. Aucun téléchargement externe. V ouvre une purge proche après 1,4 seconde. Son jet chaud dure 4,8 secondes puis se dissipe sur 1,2 seconde. La réserve se recharge après extinction. Les sons sont optionnels et désactivés par défaut.
Flèches / Q-D : mouvement ; Haut/Bas : échelle ou profondeur ; Espace : saut ; E : action ; Maj : courir ; Ctrl : se baisser ; F : bruit ; T : lancer un boulon ; Y : récupérer ; G : attendre/repartir ; I : éclairage ; M : plan ; C : archives ; Échap : pause ; R : dernier poste sûr. Le mode Appuyer dispense de maintenir E et V, pas de respecter les durées. Les boutons à l’écran utilisent les mêmes méthodes.

## Installation sur une copie V108
Extraire ce paquet hors du dossier cible. Node.js 20 ou plus.
```sh
node scripts/install-v109.mjs /chemin/vers/projet-V108 --dry-run
node scripts/install-v109.mjs /chemin/vers/projet-V108
node scripts/install-v109.mjs --restore /chemin/vers/receipt.json
```
Les 42 fichiers de `sources-v108-verified.json` doivent correspondre. Cinq nouveaux modules et un raccord de moteur sont préparés dans une copie ; les commandes npm `check` et `build` du projet sont exécutées avant report. `--skip-project-check` saute explicitement ces validations. Les sources modifiées, modifications concurrentes et chemins symboliques gérés sont refusés. Les tests du paquet utilisent des projets synthétiques : aucun build natif complet n’est annoncé.

## Sauvegardes
Fichiers explicites jusqu’à 1 Mio ; migrations V105 à V108. Une reprise conserve la pression et la durée du jet, mais aucun geste partiel ni son suspendu. Elle attend en pause et laisse 0,9 seconde avant un nouveau dégât de vapeur. Le dernier poste sûr garde un état indépendant. Aucun cloud ou autosave disque.

## Rapports et codex
`ALIEN3_CODEX_LEVEL_DESIGN_V109.html` : {len(cards)} fiches de conception hors jeu.
`docs/ALIEN3_LEVEL_DESIGN_CODEX_V109.md` : version détaillée en texte.
`RAPPORT_ILLUSTRE_V109.html` / `.pdf` : images natives et portée explicitement séparée.
`RAPPORT_QA_V109.md`, `docs/PORTEE_V109.md`, `qa-v109/` : preuves et limites.

## Reproduire
```sh
node scripts/test-v109.mjs
node scripts/test-install-v109.mjs
python scripts/build-preview-v109.py
# Répéter avec profiles, resume, trap, failure, audio, layout :
python scripts/verify-browser-v109.py profiles
# Répéter avec route, geometry, resume, gesture, ventilation :
python scripts/verify-steam-v109.py route
python scripts/verify-diversion-v109.py route
python scripts/aggregate-qa-v109.py
python scripts/verify-delivered-v109.py
python scripts/build-docs-v109.py
python scripts/verify-codex-v109.py
python scripts/build-pdf-v109.py
```
Python Playwright, Chromium et ReportLab sont requis pour ces outils, mais pas pour ouvrir l’aperçu. Aucun fichier de police distribué. Les captures et rapports précédents ne sont pas inclus comme preuves de cette version. Le jeu natif entier, les montages du film, les sprites finaux et les appareils physiques restent à qualifier.
''')
print(json.dumps({'cards':len(cards),'newCards':len(new),'captures':len(b['screenshots'])}))
