#!/usr/bin/env python3
"""Seal an incremental V108 package without duplicating old illustrated reports.
Previous source, build scripts, codex templates and data provenance are retained.
Old captures/reports are historical, not evidence for this version; excluded explicitly.
"""
from pathlib import Path
import json,hashlib,zipfile,re
R=Path(__file__).resolve().parents[1];out=R.parent/'ALIEN3_FIORINA_V108_ECHOS_DE_METAL_SUR_V107.zip';items=[];omitted=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R).as_posix()
 if p.name=='manifest-v108.json' or '__pycache__' in p.parts or p.suffix.lower()in['.pyc','.ttf','.otf','.woff','.woff2','.log'] or p.name.endswith('-exit.txt') or p.name=='smoke.png':continue
 historical=bool(re.match(r'RAPPORT_ILLUSTRE_V(?:104|105|106|107)\.(pdf|html)$',rel)) or (bool(re.match(r'qa-v(?:104|105|106|107)/',rel)) and p.suffix.lower()in['.png','.jpg','.webp','.pdf'])
 if historical:omitted.append(rel);continue
 b=p.read_bytes();items.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'schema':108,'scope':'Incremental on exact V107 sources; optional encounter modules and self-contained simplified host. Full native game build NOT executed.','count':len(items),'omittedHistoricalGeneratedArtifacts':omitted,'files':items}
(R/'manifest-v108.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f in items:z.write(R/f['path'],f['path'])
 z.write(R/'manifest-v108.json','manifest-v108.json')
with zipfile.ZipFile(out)as z:
 bad=z.testzip()
 if bad:raise RuntimeError(bad)
print(json.dumps({'ok':True,'files':len(items),'historicalImagesOmitted':len(omitted),'archive':out.name,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
