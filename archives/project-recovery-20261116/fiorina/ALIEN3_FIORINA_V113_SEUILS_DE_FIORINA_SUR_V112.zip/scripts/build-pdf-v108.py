#!/usr/bin/env python3
"""Illustrated PDF from native Chromium captures; no independent picture rendering."""
from pathlib import Path
from xml.sax.saxutils import escape
import json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape,A4
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=Path(__file__).resolve().parents[1];Q=R/'qa-v108';b=json.loads((Q/'browser.json').read_text());u=json.loads((Q/'unit.json').read_text());i=json.loads((Q/'install.json').read_text());doc=json.loads((Q/'documentation.json').read_text());cx=json.loads((Q/'codex-browser.json').read_text());dh=json.loads((Q/'delivered.json').read_text())
for name,file in [('Body','DejaVuSans.ttf'),('Strong','DejaVuSans-Bold.ttf')]:
 p=Path('/usr/share/fonts/truetype/dejavu')/file
 if not p.is_file():raise FileNotFoundError('DejaVu Sans required locally: '+str(p))
 pdfmetrics.registerFont(TTFont(name,str(p)))
W,H=landscape(A4);M=34;CW=W-2*M;BG=HexColor('#0e1a13');INK=HexColor('#e3e8d6');MUTED=HexColor('#b7c3ad');LINE=HexColor('#52634a');GOLD=HexColor('#cdb786')
styles={k:ParagraphStyle(k,fontName='Body',fontSize=f,leading=l,textColor=MUTED if k in ['small','caption']else INK)for k,f,l in [('body',11,16),('caption',9.2,13),('small',9,12.7),('cell',9.5,13.5)]}
pdf=canvas.Canvas(str(R/'RAPPORT_ILLUSTRE_V108.pdf'),pagesize=(W,H),pageCompression=1);pdf.setTitle('ALIEN 3 — Fiorina 161 V108 — Échos de métal');pdf.setAuthor('Aliens: Tantalus Frontier / dossier de développement');total=3+len(b['screenshots']);pn=0

def para(text,x,top,width,style='body',maxh=None):
 p=Paragraph(text,styles[style]);_,height=p.wrap(width,999)
 if maxh and height>maxh:raise ValueError(f'Overflow {height}>{maxh}: {text[:60]}')
 p.drawOn(pdf,x,top-height);return height

def page(title,section):
 global pn;pn+=1;pdf.setFillColor(BG);pdf.rect(0,0,W,H,fill=1,stroke=0);pdf.setFillColor(GOLD);pdf.setFont('Strong',9);pdf.drawString(M,H-24,'ALIEN 3  /  FIORINA 161');pdf.setFont('Body',8);pdf.drawRightString(W-M,H-24,'V108  ·  '+section);pdf.setFillColor(INK);pdf.setFont('Strong',24)
 if pdfmetrics.stringWidth(title,'Strong',24)>CW:raise ValueError(title)
 pdf.drawString(M,H-57,title);pdf.setStrokeColor(LINE);pdf.line(M,29,W-M,29);pdf.setFillColor(MUTED);pdf.setFont('Body',7.5);pdf.drawString(M,16,'Banc local · modules partagés · silhouettes vectorielles · pas de campagne native complète certifiée');pdf.drawRightString(W-M,16,f'{pn:02d} / {total}')

def image(file,top=H-76):
 h=CW*720/1280;pdf.drawImage(str(R/file),M,top-h,width=CW,height=h,preserveAspectRatio=True,mask='auto');pdf.setStrokeColor(LINE);pdf.rect(M,top-h,CW,h,stroke=1,fill=0);return top-h

def table(rows,top,widths):
 t=Table([[Paragraph(escape(str(x)),styles['cell'])for x in row]for row in rows],colWidths=widths);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#2d3b26')),('BACKGROUND',(0,1),(-1,-1),HexColor('#182b1c')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,-1),.5,LINE)]));_,h=t.wrap(CW,999);t.drawOn(pdf,M,top-h);return top-h
page('Échos de métal','VERSION LOCALE CANDIDATE')
y=image('qa-v108/captures/19_enquete_au_bruit.png');para('Un boulon lancé à la main, un impact localisé et une recherche du Runner qui suit les passages. Capture native pendant une traque au clavier. Les personnages et la physique de base restent simplifiés ; ce n’est pas le build de production complet.',M,y-10,CW,'caption',40);pdf.showPage()
page('Une diversion, pas une arme','CHANGEMENTS ET LIMITES')
y=table([['Élément','Comportement livré','Limite'],['Trois boulons','Identités stables : poche, vol, sol ou perte.','Pas de recharge automatique.'],['Lancer T','Arc depuis la main, selon l’orientation et la profondeur.','Appui stable et manœuvre inactive.'],['Impact','Sol ou porte fermée ; rebonds amortis, bruit local.','Le décor arrière ne devient pas solide.'],['Récupération Y','Proximité, même étage et même profondeur.','Aucune récupération au-delà d’un battant fermé.'],['Audition','La trace vient du choc et passe par le calcul existant.','Pas de stun ni d’attaque annulée.'],['Fichier de reprise','Pose et vitesse conservées, import en pause.','Le dernier poste sûr a son stock propre.']],H-82,[133,322,CW-455]);y-=19
para('Un premier essai était hors de portée : la créature se trouvait à l’étage supérieur. Le parcours validé attend son passage réel au même niveau avant le lancer. Aucune écoute forcée ni téléportation n’a remplacé cette condition.',M,y,CW,'body',54);y-=67
para(f'Codex de conception : <b>{doc["cards"]} fiches</b>, dont {doc["newCards"]} nouveaux contrats. Les 20 sections et 30 assemblages historiques restent présents. Les trois objets persistants ne sont pas présentés comme trois modèles artistiques distincts.',M,y,CW,'small',42);pdf.showPage()
page('Parcours et vérifications','PREUVES EXÉCUTÉES')
rows=[['Profil automatisé','Santé','Contacts','Lancers / entendus','Temps simulé']]
for route in b['routes']:
 s=route['result'];st=s['pursuit']['stats'];bolts=s.get('diversion',{}).get('stats',{});rows.append([route['profile'],s['hp'],st['hits'],f'{bolts.get("thrown",0)} / {bolts.get("heard",0)}',f'{s["clock"]:.2f} s'])
y=table(rows,H-81,[224,74,90,176,CW-564]);y-=19
para('Les six traversées utilisent le clavier et une horloge contrôlée, sans injection de position ou d’étape. Le robot connaît le trajet et lit l’état pour ses assertions ; ses temps ne sont pas des durées de campagne. L’échec préparé et les essais du matériel sont explicitement séparés.',M,y,CW,'body',56);y-=71
para(f'<b>{u["cases"]} cas unitaires</b>, <b>{i["cases"]} installations synthétiques</b>, <b>{b["controlsExecuted"]} assertions Chromium</b> en {len(b["phases"])} groupes ({b["uniqueControlNames"]} libellés distincts), {dh["tests"]} contrôles du HTML ordinaire et {cx["tests"]} contrôles du codex. Les régressions V104 à V107 sont exécutées séparément.',M,y,CW,'small',46);y-=58
para('<b>Non revendiqué :</b> build complet Tantalus, film intégral, sprites définitifs, essai humain, manette physique, Safari, écoute sur matériel ou déploiement. Quatre nouveaux modules et un raccord de moteur, avec 38 sources antérieures vérifiées.',M,y,CW,'small',40);pdf.showPage()
titles={'01_aaron.png':'La consigne d’Aaron','02_releve.png':'Lire le relevé à l’étage','03_retour_aaron.png':'Retour auprès d’Aaron','04_plan.png':'Le plan suspend la chasse','05_archives.png':'Consulter les archives','06_attente_postes.png':'Attendre les deux postes','06b_verrouillage.png':'Verrouiller le moule','07_postes_tenus.png':'Les postes sont tenus','08_attaque_annoncee.png':'Une attaque annoncée','09_coulee.png':'La coulée au bon instant','10_refroidissement.png':'Refroidir le moule','11_retour_morse.png':'Le rabattage est terminé','12_echec.png':'Échec et poste sûr','18_lancer_dans_bloc.png':'Lancer depuis sa position','19_enquete_au_bruit.png':'La trace vient du choc','20_retour_apres_diversion.png':'Retour après la diversion','21_arc_fonderie.png':'Un arc au-dessus du sol','22_boulon_au_sol.png':'Rejoindre l’objet posé','23_impact_porte.png':'Un battant fait obstacle','24_reprise_recuperee.png':'Récupérer après une reprise'}
for index,shot in enumerate(b['screenshots'],1):
 page(titles[Path(shot['file']).name],f'CAPTURE NATIVE {index:02d} / {len(b["screenshots"])}');y=image(shot['file']);scope='Test dirigé avec poses préparées.'if'directed'in shot['scope']else'Actions au clavier/pointeur dans le banc local.';para(escape(shot['caption'])+' '+scope,M,y-10,CW,'caption',40);pdf.showPage()
assert pn==total;pdf.save();print(json.dumps({'ok':True,'pages':pn,'bytes':(R/'RAPPORT_ILLUSTRE_V108.pdf').stat().st_size}))
