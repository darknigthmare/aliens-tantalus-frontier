#!/usr/bin/env python3
"""Seal actual delivered bytes, not inferred links. No font files or working logs."""
from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parents[1];out=R.parent/'ALIEN3_FIORINA_V107_MANOEUVRES_SOUS_TENSION_SUR_V106.zip';items=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name=='manifest-v107.json' or '__pycache__' in p.parts or p.suffix in ['.pyc','.ttf','.otf','.woff','.woff2','.log'] or p.name.endswith('-exit.txt'):continue
 data=p.read_bytes();items.append({'path':p.relative_to(R).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema':107,'scope':'Incremental on exact V106 sources; shared optional encounter modules with standalone simplified host. Full native production build NOT executed. Historical reports are not current-run evidence.','count':len(items),'files':items}
(R/'manifest-v107.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in items:z.write(R/f['path'],f['path'])
 z.write(R/'manifest-v107.json','manifest-v107.json')
with zipfile.ZipFile(out) as z:
 bad=z.testzip()
 if bad:raise RuntimeError(bad)
result={'ok':True,'manifestFiles':len(items),'archive':out.name,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
print(json.dumps(result,indent=2))
