from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1];Q=R/'qa-v109';phases=['profiles','resume','trap','failure','audio','layout','steam-route','steam-geometry','steam-resume','steam-gesture','steam-ventilation','diversion-route'];reports=[json.loads((Q/f'browser-{p}.json').read_text())for p in phases]
results=[dict(phase=p,**t)for p,r in zip(phases,reports)for t in r['results']];shots=[s for r in reports for s in r['screenshots']];routes=[x for r in reports for x in r.get('routes',[])if not x.get('profile','').endswith('-detail')]
for r in reports:
 assert r['ok'] and not r.get('errors') and not r.get('externalRequests')
 for name,h in r['sourceHashes'].items():assert hashlib.sha256((R/'src'/name).read_bytes()).hexdigest()==h,(name,'stale evidence')
for s in shots:assert hashlib.sha256((R/s['file']).read_bytes()).hexdigest()==s['sha256'],s['file']
assert len({s['file']for s in shots})==len(shots)
out={'ok':True,'controlsExecuted':len(results),'uniqueControlNames':len({t['name']for t in results}),'phases':phases,'results':results,'routes':routes,'screenshots':shots,'browser':reports[0]['browser'],'sourceHashes':reports[0]['sourceHashes'],'scope':'Shipped V109 update/render modules in a simplified host. Keyboard traversals distinct from directed gate geometry and failure comparisons. Controlled clock, native screenshots. No full production campaign or human testing.','nativeBuild':False}
(Q/'browser.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'controls':len(results),'unique':out['uniqueControlNames'],'routes':len(routes),'screenshots':len(shots)}))
