#!/usr/bin/env python3
"""Real canvas screenshots. Directed comparisons explicitly separate from keyboard routes."""
from browser_support_v113 import *
def inspection_state(p):
 return p.evaluate('''()=>{const e=fiorinaBench.engine;return {player:{x:e.player.x,y:e.player.y,w:e.player.w,h:e.player.h,depth:e.player.depth},phase:e.alien3V88.phase,encounter:e.alien3EncounterV105?.mode||null,flags:e.getAlien3VisualFlagsV102(),doors:e.doors.map(d=>({id:d.id,x:d.x,y:d.y,w:d.w,h:d.h,open:d.open,progress:d.progress})),participants:e.alien3EncounterV105?.participants.map(a=>a.id)||[],audit:e.alien3FidelityAuditV113};}''')
def shot(p,name,caption):
 p.evaluate('fiorinaBench.render()');file=SHOTS/(name+'.png');p.locator('canvas').screenshot(path=str(file))
 s=inspection_state(p);(OUT/(name+'-state.json')).write_text(json.dumps(s,ensure_ascii=False,indent=2))
 captures.append({'file':'qa-v113/captures/'+file.name,'caption':caption,'scope':'directed visual inspection; prepared pose/flags, not a campaign traversal','state':s,'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
with sync_playwright()as pw:
 b=pw.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);p=start(b)
 record('Le renderer V113 est effectivement actif',p.evaluate('fiorinaBench.engine.isAlien3FidelityV113()'))
 record('Le fichier distingue 19 repères liés et six lieux absents',p.evaluate('fiorinaBench.engine.alien3FidelityAuditV113.locationsBound')==19 and len(p.evaluate('fiorinaBench.engine.alien3FidelityAuditV113.locationsUnbound'))==6)
 # Every door is drawn from its own geometry, closed/open at the same instant.
 for idx,label in enumerate(['soins','galeries','fonderie']):
  p.evaluate('''i=>{fiorinaBench.setLocation([1,2,5][i]);const e=fiorinaBench.engine,d=e.doors[i];e.camera.x=Math.max(0,Math.min(4920,d.x-580));e.camera.y=0;e.player.x=d.x-118;e.player.y=d.y+d.h-e.player.h;e.alien3RunnerV88.alive=false;e.animationTime=0;d.open=false;d.progress=0;fiorinaBench.render();}''',idx)
  before=inspection_state(p);shot(p,f'01{idx}_{label}_ferme',f'Porte {label} fermée : retours de cloison, appuis et logement suivent le rectangle existant.')
  p.evaluate('(i)=>{const d=fiorinaBench.engine.doors[i];d.open=true;d.progress=1;fiorinaBench.render();}',idx)
  after=inspection_state(p);shot(p,f'02{idx}_{label}_ouvert',f'Même porte {label} ouverte : le battant se replie dans son logement, le seuil reste au même appui.')
  record('Géométrie et collision inchangées — '+label,all(before['doors'][idx][k]==after['doors'][idx][k]for k in ['x','y','w','h','id']))
  # Actual pixel difference is confined to the shutter opening; fixed frames must be stable.
  diff=p.evaluate('''i=>{const e=fiorinaBench.engine,d=e.doors[i],c=document.querySelector('canvas').getContext('2d');d.open=false;d.progress=0;fiorinaBench.render();const a=c.getImageData(0,0,1280,720).data;d.open=true;d.progress=1;fiorinaBench.render();const z=c.getImageData(0,0,1280,720).data;let changed=0,outside=0;for(let y=0;y<720;y++)for(let x=0;x<1280;x++){const k=(y*1280+x)*4;if(a[k]!==z[k]||a[k+1]!==z[k+1]||a[k+2]!==z[k+2]){changed++;const inLeaf=x>=d.x-e.camera.x-3&&x<=d.x+d.w-e.camera.x+3&&y>=d.y-e.camera.y-3&&y<=d.y+d.h-e.camera.y+3;const inLamp=x>=d.x+d.w+22-e.camera.x&&x<=d.x+d.w+33-e.camera.x&&y>=d.y+44-e.camera.y&&y<=d.y+68-e.camera.y;if(!inLeaf&&!inLamp)outside++;}}return {changed,outside};}''',idx)
  record('Seuls le volet et son voyant changent — '+label,diff['changed']>100 and diff['outside']==0,diff)
 # Walk up to a closed door, bounce, use E, and cross. Pose only established once for this directed collision test.
 p.evaluate('''()=>{fiorinaBench.setLocation(1);const e=fiorinaBench.engine,d=e.doors[0];e.player.x=d.x-e.player.w-28;e.player.y=d.y+d.h-e.player.h;e.player.grounded=true;e.alien3RunnerV88.alive=false;d.open=false;d.progress=0;}''')
 p.locator('canvas').focus();p.keyboard.down('ArrowRight');tick(p,35);p.keyboard.up('ArrowRight')
 record('Un seuil fermé bloque réellement le contrôleur local',p.evaluate('fiorinaBench.engine.player.x+fiorinaBench.engine.player.w<=fiorinaBench.engine.doors[0].x+.01'))
 press(p,'KeyE');record('E ouvre le même passage',p.evaluate('fiorinaBench.engine.doors[0].open'))
 p.keyboard.down('ArrowRight');tick(p,36);p.keyboard.up('ArrowRight')
 record('Le seuil ouvert peut réellement être franchi',p.evaluate('fiorinaBench.engine.player.x>fiorinaBench.engine.doors[0].x+fiorinaBench.engine.doors[0].w'))
 # Scenario states alter clothes without granting weapons.
 p.evaluate('fiorinaBench.setLocation(0)');shot(p,'030_ripley_arrivee','Tenue du crash : haut gris et vêtements courts. Variante inspectée, sans reconstitution du prologue.')
 p.evaluate('fiorinaBench.setLocation(1)');shot(p,'031_ripley_prison','Ripley : silhouette rasée, couches brunes, matelassage simplifié et bottes.')
 p.evaluate('''()=>{fiorinaBench.setLocation(0);fiorinaBench.engine.alien3V88.phase='coast';fiorinaBench.render();}''');shot(p,'032_ripley_manteau','Variante extérieure du manteau vert, dessinée par le même rig ; sélection d’inspection explicite.')
 # Actual new objects on their declared supports, no new navigation or pickup added.
 for node,name,phase in [('f161-flight-analysis-v94','033_enregistreur','bishop'),('f161-bishop','034_bishop','bishop'),('f161-chemical-store','035_torche','fire-plan')]:
  p.evaluate('''({node,phase})=>{fiorinaBench.setLocation(4);const e=fiorinaBench.engine,n=e.alien3SceneV103.nodes.find(n=>n.id===node);e.player.x=n.x-75;e.player.y=n.y-e.player.h;e.player.grounded=true;e.camera.x=Math.max(0,Math.min(4920,n.x-580));e.camera.y=0;e.alien3V88.phase=phase;e.alien3RunnerV88.alive=false;fiorinaBench.render();}''',{'node':node,'phase':phase})
  shot(p,name,{'033_enregistreur':'Enregistreur sur le support d’analyse existant. Décor raccordé, sans nouvelle collecte.','034_bishop':'Fragment de Bishop posé sur son support ; aucun nouvel événement narratif déclenché.','035_torche':'Torche et récipients de préparation. La flamme n’apparaît qu’avec l’état incendiaire réellement fourni.'}[name])
 # Directed same-frame comparison, not fake Company actors added to simulation.
 p.evaluate('''()=>{fiorinaBench.setLocation(8);const e=fiorinaBench.engine;e.player.x=5580;e.camera.x=4890;e.alien3V88.phase='leadworks';e.alien3V89.company.visible=false;fiorinaBench.render();}''');before=inspection_state(p);shot(p,'036_avant_compagnie','Avant l’arrivée : aucun agent ni fusil de la Compagnie ajouté par V113.')
 p.evaluate('''()=>{const e=fiorinaBench.engine;e.alien3V88.phase='company';e.alien3V89.company.visible=true;fiorinaBench.render();}''');shot(p,'037_equipe_recuperation','À l’arrivée : deux silhouettes de récupération avec arme noire. Visuel conditionnel, sans IA ni tir nouveaux.')
 record('Le matériel de récupération respecte son état d’arrivée',not before['flags']['companyArrived'] and inspection_state(p)['flags']['companyArrived'])
 record('Dessiner l’équipe n’ajoute aucun participant à la simulation',before['participants']==inspection_state(p)['participants']==[])
 # Locked art and poses remain unchanged by repeated renders; old owner semantics unchanged.
 p.close();p=start(b,mode='trap')
 pre=p.evaluate('JSON.stringify(fiorinaBench.exportState())')
 p.evaluate('()=>{for(let i=0;i<20;i++)fiorinaBench.render()}')
 record('Vingt dessins laissent identiques positions, inventaire et sauvegarde',pre==p.evaluate('JSON.stringify(fiorinaBench.exportState())'))
 record('Pas de migration inutile de sauvegarde',p.evaluate('fiorinaBench.exportState().schema')==112)
 coverage=p.evaluate('''()=>{const e=fiorinaBench.engine,c=document.querySelector('canvas').getContext('2d'),out=[];for(const y of[0,55,110]){e.camera.y=y;c.clearRect(0,0,1280,720);e.drawBackdrop(c);out.push(Array.from(c.getImageData(0,0,1280,1).data).filter((_,i)=>i%4===3).every(a=>a===255));}return out;}''')
 record('Le décor couvre le bord haut malgré le défilement vertical',all(coverage),coverage)
 for w,h in [(390,844),(844,390)]:
  p.set_viewport_size({'width':w,'height':h});p.evaluate('document.body.classList.remove("capture");fiorinaBench.render()');bb=p.locator('canvas').bounding_box();record(f'Canvas sans débordement horizontal {w}×{h}',bb['width']<=w+1,bb)
 record('Aucune erreur JavaScript de dessin ou d’interaction',not errors,errors);record('Aucune requête réseau externe dans le fichier local',not external,external)
 version=b.version;b.close()
result={'ok':True,'controls':len(tests),'results':tests,'screenshots':captures,'browser':version,'errors':errors,'externalRequests':external,'scope':'Native browser screenshots of directed visual inspections and a directed local door crossing. Not a film campaign traversal or final native art.'}
(OUT/'browser-fidelity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'controls':len(tests),'captures':len(captures)}))
