#!/usr/bin/env python3
"""Native Chromium verification. Continuous keyboard routes and directed tests are separated."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib,subprocess,sys,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'qa-v113';SHOTS=OUT/'captures';SHOTS.mkdir(parents=True,exist_ok=True)
subprocess.run([sys.executable,str(ROOT/'scripts/build-preview-v113.py')],check=True)
PHASE=sys.argv[1] if len(sys.argv)>1 else 'all'
HTML=(ROOT/'FIORINA_V113_JOUER.html').read_text();tests=[];captures=[];routes=[];errors=[];external=[]
def record(name,ok,details=None):
 if not ok:raise AssertionError(name+' '+str(details))
 print('PASS',name,flush=True)
 tests.append({'name':name,'ok':True,**({'details':details}if details is not None else {})})
def state(p):return p.evaluate('''()=>{const e=fiorinaBench.engine,s=e.alien3EncounterV105;return{x:e.player.x,y:e.player.y,hp:e.player.health,depth:e.player.depth,stamina:s?.stamina,stage:s?.stage,status:s?.status,clock:s?.clock,pursuit:s?.pursuit,runner:{x:e.alien3RunnerV88.x,y:e.alien3RunnerV88.y,alive:e.alien3RunnerV88.alive},notice:s?.notice,participants:s?.participants.map(a=>({id:a.id,x:a.x,y:a.y,nodeId:a.nav.nodeId,goal:a.goal,order:a.order,blocked:a.blocked,nextId:a.nav.nextId,edgeId:a.nav.edgeId})),flags:s?.flags,senses:e.alien3SensesV106,operations:e.alien3OperationsV107,diversion:e.alien3DiversionV108,steam:e.alien3SteamV109,traffic:e.alien3TrafficV110,spacing:e.alien3SpacingV112,routing:{stats:e.alien3RoutesV111?.stats,memory:Object.fromEntries(Object.entries(e.alien3RoutesV111?.memory||{}).map(([id,m])=>[id,{active:m.active,decision:m.decision,goal:m.goal}]))}};}''')
def tick(p,n):p.evaluate('(n)=>{for(let i=0;i<n;i++)fiorinaBench.tick(1/60)}',n)
def press(p,key,n=0):p.locator('canvas').focus();p.keyboard.press(key);tick(p,n)
def hold(p,key,n):p.locator('canvas').focus();p.keyboard.down(key);tick(p,n);p.keyboard.up(key)
def walk(p,x,run=False,crouch=False):
 before=state(p);key='ArrowRight'if before['x']<x else'ArrowLeft';p.locator('canvas').focus()
 if crouch:p.keyboard.down('ControlLeft')
 if run:p.keyboard.down('ShiftLeft')
 p.keyboard.down(key)
 stagnant=0;last=None
 for _ in range(300):
  s=state(p);dx=x-s['x']
  stagnant=stagnant+1 if last==s['x'] else 0;last=s['x']
  if stagnant>16:raise AssertionError('Movement blocked '+str({'target':x,'state':s}))
  if s['status']!='active' or abs(dx)<5 or(key=='ArrowRight'and dx<0)or(key=='ArrowLeft'and dx>0):break
  tick(p,max(1,min(12,int(abs(dx)/(1.6 if crouch else 4.5)))))
 p.keyboard.up(key)
 if run:p.keyboard.up('ShiftLeft')
 if crouch:p.keyboard.up('ControlLeft')
 s=state(p)
 if abs(s['x']-x)>8:raise AssertionError('Route stalled '+str({'target':x,'state':s}))
 return s

def snap(p,name,caption,scope='continuous keyboard route'):
 p.evaluate('fiorinaBench.render()');file=SHOTS/(name+'.png');p.locator('canvas').screenshot(path=str(file))
 (OUT/(name+'-state.json')).write_text(json.dumps(state(p),ensure_ascii=False,indent=2))
 captures.append({'file':'qa-v113/captures/'+file.name,'caption':caption,'scope':scope,'state':state(p),'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})

def start(browser,mode='hunt',difficulty='decouverte',accessibility=False):
 p=browser.new_page(viewport={'width':1280,'height':900},device_scale_factor=1);p.set_default_timeout(8000);p.on('pageerror',lambda e:errors.append(str(e)));p.on('request',lambda r:external.append(r.url)if r.url.startswith(('http:','https:'))else None)
 p.set_content('<script>window.__FIORINA_QA__=true;window.__BENCH_QUERY__="freeze=1&capture=1"</script>'+HTML,wait_until='load');p.wait_for_function('!!window.fiorinaBench');assert p.evaluate('fiorinaBench.exportState().schema')==112
 # The capture layout hides the outer host controls; show them only for real UI setup then re-hide.
 p.evaluate('document.body.classList.remove("capture")');p.locator('.settings summary').click();p.locator('#difficulty').select_option(difficulty)
 if accessibility:p.locator('#motion').check();p.locator('#contrast').check();p.locator('#hud-mode').select_option('always')
 p.locator('#'+mode).click();p.evaluate('document.body.classList.add("capture")');p.locator('canvas').focus();return p

def hunt_out(p,profile='rapide',capture=False):
 walk(p,1320);press(p,'KeyE',15)
 if capture:snap(p,'01_aaron','Aaron donne une consigne au début du parcours original.')
 walk(p,1442,crouch=profile=='prudent');press(p,'KeyE')
 if profile=='prudent':
  walk(p,1770,True);hold(p,'ArrowUp',3);record('Le parcours prudent emploie réellement le plan arrière',state(p)['depth']==0);walk(p,2755,True);hold(p,'ArrowDown',3)
 walk(p,2770,True);press(p,'KeyE');walk(p,3052,True);hold(p,'ArrowUp',86);record('La montée réelle rejoint le relevé à l’étage',abs(state(p)['y']-240)<1);hold(p,'KeyE',70)
 record('Le relevé est acquis par E au poste réel',state(p)['stage']==2)
 if capture:snap(p,'02_releve','Relevé atteint par déplacement et échelle, sans injection de position.')
def hunt_back(p,profile='rapide',capture=False):
 hold(p,'ArrowDown',86);walk(p,2910,True);press(p,'KeyE')
 if profile=='prudent':
  walk(p,2765,True);hold(p,'ArrowUp',3);walk(p,1770,True);hold(p,'ArrowDown',3)
 walk(p,1590,True);press(p,'KeyE');walk(p,1400,True);press(p,'KeyE')
 record('Retour complet auprès d’Aaron — '+profile,state(p)['status']=='complete',{'health':state(p)['hp'],'seconds':state(p)['clock']})
 if capture:snap(p,'03_retour_aaron','Le relevé est rendu après une traversée complète des galeries.')
 routes.append({'profile':profile,'mode':'traque','setup':'UI start, physical keys and controlled 60 Hz frames; no position/progress changes','result':state(p)})
