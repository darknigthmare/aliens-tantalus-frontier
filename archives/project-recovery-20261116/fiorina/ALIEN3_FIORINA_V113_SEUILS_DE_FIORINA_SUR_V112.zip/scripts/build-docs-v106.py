#!/usr/bin/env python3
"""Codex and illustrated report from actual V106 data and native screenshot records."""
from pathlib import Path
from html import escape as esc
import json,re,subprocess,collections,base64,hashlib
R=Path(__file__).resolve().parents[1];Q=R/'qa-v106';D=R/'docs';D.mkdir(exist_ok=True)
subprocess.run(['node',str(R/'scripts/export-design-v106.mjs')],check=True)
src=json.loads((Q/'design-source.json').read_text());u=json.loads((Q/'unit.json').read_text());inst=json.loads((Q/'installation.json').read_text());browser=json.loads((Q/'browser.json').read_text());dh=json.loads((Q/'delivered.json').read_text())
old=(R/'ALIEN3_CODEX_LEVEL_DESIGN_V105.html').read_text();start=old.index('const cards=')+len('const cards=');cards,end=json.JSONDecoder().raw_decode(old[start:]);assert len(cards)==396
for c in cards:
 if c['id']=='runner-search':
  c['text']='V106 : après une trace perdue, le Runner explore au maximum trois points voisins réellement atteignables. Il avance à 110 unités/s pendant un budget de 5,2 secondes, puis reprend la patrouille. Aucun bond vers le joueur invisible.'
  c['details']=[['Durée','5,2 secondes','La pause et les panneaux suspendent ce délai.'],['Choix','A3-106-search-room','Voisins du point de trace ; une route coupée n’est pas effacée artificiellement.']]
 if c['id']=='runner-chase':
  c['text']='V106 : la vue conserve direction, hauteur, profondeur et portes, puis accumule une reconnaissance selon l’éclairage et la posture. La pénombre retarde l’identification mais ne protège pas à courte portée. La dernière trace reste une observation passée.'
  c['details'].append(['Lecture du lieu','A3-106-dark-not-safe','Seules les séquences originales activent ce pilote.'])
 if c['id']=='runner-investigate':
  c['text']='V106 : un bruit garde son origine et sa date. Sa portée acoustique est mesurée depuis le corps du Runner sur son segment, avec les détours du graphe et l’atténuation des portes. Chaque numéro d’événement est consommé au plus une fois.'
  c['details'].append(['Origine réelle','A3-106-sound-edge','Pas de réception depuis l’extrémité lointaine du chemin.'])
 if c['type']=='Commandes':
  c['text']+=' Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.'
 if c['id']in ['participant-dillon','participant-morse']:
  c['details'].append(['Ordre proche','order106-'+c['id'].split('-')[-1],'G : attendre/repartir sans effacer destination et segment. Un détenu retenu hors de son poste ne valide pas le piège.'])
 if c['id']=='v105-NATIVE':c['text']='La livraison V105 avait constaté une base distante V86 ; cette constatation historique n’est pas une nouvelle vérification du dépôt. V106 exige les octets connus de V105 et n’annonce aucun build natif complet.'
new=[]
def card(kind,id,title,text,details):new.append({'type':kind,'id':id,'title':title,'text':text,'details':details})
for r in src['designRules']:
 card('Règles V106',r['id'],r['text'].split(' ; ')[0],r['text'],[['Portée','Séquences originales V105–V106','Pas de remplacement aveugle du pilote de campagne natif.'],['Preuves','qa-v106/unit.json','Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.']])
for light in src['lights']:
 card('Lumière et perception','senses106-'+light['id'],light['label'], 'La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.',[['Appui',light['nodeId'],f'X {light["x"]}, sol {light["footY"]} ; profondeur {light["depth"]}.'],['Influence','245 unités','Mesure du jeu, pas des mètres relevés sur les décors du film.'],['Étage','28 unités','Au-delà, la lampe ne contribue pas à la reconnaissance.'],['États','I','Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur.'],['Proche dans l’ombre','74 unités','La pénombre n’annule pas la reconnaissance à courte distance.'],['Exceptions','A3-106-light-native','Four et coulée chaude gardent leur lumière propre.']])
for door in src['doors']:
 card('Portes et acoustique','hearing106-'+door['id'],'Acoustique · '+door['id'],'La porte existante conserve son passage et son état. Sa manœuvre réelle produit un bruit unique ; une fermeture refusée parce qu’un corps occupe le seuil ne produit pas ce bruit. Une porte fermée ajoute de l’atténuation, pas une téléportation sonore.',[['Connexion',door['edgeId'],f'{door["from"]} → {door["to"]}'],['Amont',door['from'],str(door['fromPoint'])],['Aval',door['to'],str(door['toPoint'])],['Atténuation porte',str(door['closedAttenuation']),'Coût acoustique abstrait ajouté au trajet.'],['Bruit de manœuvre',str(door['doorNoisePower']),'Puissance émise depuis la porte ; portée finale évaluée depuis le récepteur.'],['Bruit direct','A3-106-sound-edge','Un corridor de sol continu emploie la distance réelle plutôt qu’un détour artificiel par son point le plus proche.']])
for p in src['controllers']:
 active=p['goal']is not None
 card('Coordination V106','order106-'+p['id'],p['name']+' · présence et consignes',('Un ordre d’attente conserve la pose, le segment en cours et la destination. G relance le déplacement normal depuis le même endroit. Une fois son poste atteint, le détenu y reste plutôt que de recevoir une fausse nouvelle destination.'if active else'Aaron reste au poste de la séquence antérieure ; il ne reçoit pas une commande de déplacement et ne réapparaît pas dans la fonderie.'),[['Parcours','encounter-'+p['mode'],'Présence limitée à la séquence concernée.'],['Départ',p['home'],'Point réellement occupé à l’initialisation.'],['Poste',p['goal']or p['home'],'Position vérifiée avant armement/coulée ; ordre et présence ne sont pas interchangeables.'],['Ordre à portée','106 / 24 / 0,35','Distance, différence de pieds et profondeur ; une porte fermée bloque la consigne.'],['Reprise','save106-session','L’ordre et la navigation sont validés et conservés par fichier.']])
for ident,title,text,details in [
 ('session','Fichier de partie V106','L’enveloppe V106 contient le fichier V105 de base, le registre de perception et un dernier poste sûr séparé. La taille est bornée à 1 Mio et l’empreinte sert à détecter la corruption accidentelle, pas à garantir l’authenticité du joueur.',[['Migration','105 → 106','Une sauvegarde V105 valide reçoit un registre de perception neuf sans démarrer une autre séquence.'],['Vie privée','Local','Aucun téléchargement serveur ni compte ; pas de persistance localStorage annoncée.'],['Panneaux','Pause','L’import reprend en pause, sans relancer une attaque suspendue.']]),
 ('safe','Dernier poste sûr','Le poste sûr doit être vivant, actif, de la même séquence et ne pas avoir une progression future. Après échec, l’export fournit ce poste plutôt que de faire passer la pose morte pour une partie sauvegardable.',[['Reprendre','R','Le poste antérieur est utilisé ; l’attaque en transit est neutralisée en récupération.'],['Intégrité','save106-session','Le poste est validé lui aussi, pas seulement l’enveloppe principale.'],['Limite','Fichier explicite','Le point sûr n’est pas une sauvegarde automatique sur disque.']]),
 ('navigation','Position et navigation dans les reprises','Un acteur au repos doit être à son point déclaré ; un acteur en trajet doit appartenir au segment courant. Une pose falsifiée mais placée sur un autre sol valide reste refusée, même si son checksum a été recalculé.',[['Repos','Tolérance 7 unités','Mesurée au pied central du corps.'],['Mouvement','Segment courant','Conserver les coordonnées, ne pas téléporter pour rendre le fichier acceptable.'],['Événements transitoires','A3-106-save-no-events','Bruits, appels et attaques suspendus ne sont pas rejoués.']])]:
 card('Reprises V106','save106-'+ident,title,text,details)
cards+=new;ids=[c['id']for c in cards];assert len(ids)==len(set(ids))
(Q/'codex-source.json').write_text(json.dumps({'schema':106,'cards':cards},ensure_ascii=False,indent=2)+'\n')
intro=['# ALIEN 3 — FIORINA 161','## Codex V106 · Traces dans la pénombre','',f'{len(cards)} fiches, dont {len(new)} nouveaux contrats V106. Les 284 composants de décor restent détaillés dans les assemblages hérités ; ils ne sont pas de nouveaux assets de cette version.','', '## Périmètre et héritage','Correctif incrémental sur les octets connus V105, pas archive du jeu complet. Les deux parcours sont des séquences originales facultatives. La couche native n’est activée que par ce pilote ; aucune reconstitution intégrale du film ni validation de tous les montages n’est annoncée.', '', '## Paramètres de perception','Les valeurs ci-dessous sont des réglages du jeu. Elles ne décrivent pas des distances ou comportements scientifiquement mesurés de la créature.','| Paramètre | Valeur |','|---|---:|',*[f'| {k} | {v} |'for k,v in src['rules'].items()],'', '## Différences concrètes','La lumière des commandes existantes influe sur le délai de reconnaissance. Un bruit est évalué depuis le corps réel du Runner, non depuis un futur nœud de navigation. La recherche explore les voisins atteignables de la dernière trace. Les consignes de proximité retiennent un détenu sans valider sa présence au poste. Les reprises transportent un poste sûr vérifié indépendamment.','', '## Fiches de conception','']
for c in cards:
 intro.extend([f'### {c["title"]}',f'`{c["id"]}` · {c["type"]}',c['text'],'','| Élément | Référence | Contrat |','|---|---|---|',*['| '+' | '.join(str(v).replace('|',' / ').replace('\n',' ')for v in row)+' |'for row in c['details']],''])
(D/'ALIEN3_LEVEL_DESIGN_CODEX_V106.md').write_text('\n'.join(intro))
updated=old[:start]+json.dumps(cards,ensure_ascii=False)+old[start+end:]
updated=updated.replace('DOCUMENT DE CONCEPTION V105','DOCUMENT DE CONCEPTION V106').replace('Codex V105','Codex V106').replace('<h1>Chasse et préparation du piège</h1>','<h1>Traces dans la pénombre</h1>').replace('396 fiches issues des données livrées',f'{len(cards)} fiches issues des données livrées')
updated=re.sub(r'(<div class="scope">).*?(</div>)',lambda m:m.group(1)+'Codex hors jeu. V106 conserve les espaces et accessoires existants, et relie lumière, audition, coordination et reprise par fichier dans les séquences originales. Le banc local utilise un contrôleur simplifié et des silhouettes provisoires ; il ne certifie pas le moteur principal complet. La couche de lumière V106 remplace les limites de perception V105 seulement quand ce pilote est actif.'+m.group(2),updated,count=1,flags=re.S)
options=''.join('<option>'+esc(t)+'</option>'for t in ['Tout',*dict.fromkeys(c['type']for c in cards)])
updated=re.sub(r'(<select id="kind"[^>]*>).*?(</select>)',lambda x:x.group(1)+options+x.group(2),updated,flags=re.S)
(R/'ALIEN3_CODEX_LEVEL_DESIGN_V106.html').write_text(updated)
(Q/'documentation.json').write_text(json.dumps({'schema':106,'cards':len(cards),'newCards':len(new),'byCategory':dict(collections.Counter(c['type']for c in cards)),'componentsNested':284,'markdownLines':len(intro)},ensure_ascii=False,indent=2)+'\n')
css=re.search(r'<style>(.*?)</style>',old,re.S).group(1)
sections=[]
for shot in browser['screenshots']:
 raw=(R/shot['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==shot['sha256']
 scope='Position dirigée pour comparaison d’éclairage ou vérification de l’échec.'if'directed'in shot['scope']else'Interaction et parcours au clavier dans le banc local.'
 sections.append(f'<section class="panel"><h2>{esc(shot["caption"])}</h2><img alt="Capture native du jeu local" src="data:image/png;base64,{base64.b64encode(raw).decode()}"><p class="caption">{scope} Modules livrés ; physique de base simplifiée ; aucune réillustration depuis un état JSON.</p></section>')
report=f'''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Alien 3 — Rapport V106</title><style>{css}</style><header><small>FIORINA 161 / RAPPORT V106</small><h1>Traces dans la pénombre</h1><p>Les lumières comptent, les bruits traversent les passages, et les détenus peuvent attendre sans disparaître.</p></header><main><div class="scope">Correctif sur V105 et banc jouable autonome, pas la campagne native complète. Les deux séquences sont originales et facultatives. Aucun push, déploiement ou build complet du dépôt n’a été effectué pour V106.</div><section class="panel"><h2>Changements livrés</h2><p>Reconnaissance progressive liée aux lampes du bon étage, proche visibilité non annulée, bruit de porte avec origine réelle et atténuation, exploration des voisins de la dernière trace, ordre G à proximité, état d’attente conservé par fichier et dernier poste sûr séparément validé. Le rendu n’ajoute ni succès ni progression.</p><p>Les 20 sections descriptives, 30 assemblages et 284 accessoires historiques ne sont pas gonflés. Les archives destinées au joueur conservent leurs 90 dossiers ; le codex de conception s’enrichit à {len(cards)} fiches.</p></section><section class="panel"><h2>Vérifications</h2><p>{u['cases']} cas unitaires V106 ; {inst['cases']} scénarios d’installation sur fixtures ; {browser['controlsExecuted']} assertions Chromium sur sept groupes ({browser['uniqueControlNames']} libellés distincts) ; {dh['tests']} contrôles du fichier autonome sans API de test. Les scénarios dirigés sont séparés des parcours continus.</p><p>La traque est terminée dans quatre styles automatisés ; le rabattage est terminé avec une attaque évitée par un saut. Ces mesures ne représentent ni des testeurs humains ni une durée de campagne.</p></section>{''.join(sections)}</main></html>'''
(R/'RAPPORT_ILLUSTRE_V106.html').write_text(report)
qa=['# QA — Alien 3 V106','', '## Périmètre','Couche incrémentale sur V105 et hôte local simplifié. Aucune exécution de la campagne native complète ni certification des sprites définitifs.', '', '## Résultats',f'- {u["cases"]} cas unitaires V106.',f'- {inst["cases"]} scénarios d’installation ; scripts npm de test synthétiques.',f'- {browser["controlsExecuted"]} assertions Chromium en sept groupes, {browser["uniqueControlNames"]} noms distincts. Les répétitions entre parcours sont incluses.',f'- {dh["tests"]} contrôles du HTML distribué sans API QA.', '- V105 : 65 tests unitaires et 17 installations rejoués sans pilote V106 actif. V104 : 37 tests unitaires et 15 installations rejoués séparément.', '', '## Parcours automatisés','| Style | Statut | Santé | Attaques / contacts / esquives | Temps simulé |','|---|---|---:|---|---:|']
for r in browser['routes']:
 s=r['result'];st=s['pursuit']['stats'];qa.append(f'| {r["profile"]} | {s["status"]} | {s["hp"]} | {st["attacks"]} / {st["hits"]} / {st["misses"]} | {s["clock"]:.2f} s |')
qa+=['', 'Ces traversées utilisent les gestionnaires du clavier et une horloge à 60 Hz. Aucune pose ni progression n’est injectée pendant les parcours. Les scènes préparées pour la comparaison de lampe et l’échec sont distinctes et étiquetées. Les temps reflètent un robot qui connaît le chemin.', '', '## Contrôles nouveaux', '- Allumer/éteindre réellement la même lampe sans changer acteurs ni instant de capture.', '- Attente physique de Dillon via G, export, import sur une autre page, même pose et même ordre, reprise sur le segment en cours.', '- Le poste sûr est présent dans le fichier, validé séparément, et reste reprenable après échec. Un checkpoint corrompu ne remplace pas la session.', '- Un bruit dans le même corridor utilise la distance réelle ; un détour reste évalué sur le graphe et une porte ajoute une pénalité.', '- Une recherche avance réellement sur des connexions proches sans téléportation.', '- Entrées texte, pause, archives, plan et chargement n’activent pas la coordination ou la simulation en arrière-plan.', '', '## Modifications de la base', 'Quatre nouveaux modules V106, deux points de délégation insérés dans le propriétaire runtime V105, et un raccord du moteur de production. Le fichier V105 original est conservé dans support-v106 ; ses octets connus sont exigés par l’installateur. Ce n’est pas une affirmation « aucune source historique modifiée ».', '', '## Portée des preuves', 'Les tests de blocage complet d’un détenu emploient une branche de graphe explicitement scellée en fixture ; ils ne prouvent pas qu’une seule porte coupe toutes les routes alternatives de Fiorina. Les screenshots du jeu sont des PNG natifs Chromium, pas une illustration de télémétrie. Les tests d’audio vérifient activation, événements, gain et pause ; aucune écoute physique sur matériel n’est certifiée. Aucun nouveau relevé GitHub ni erreur de droits n’est revendiqué pour ce tour.', '', '## Restant', 'Qualification du pilote dans la campagne native avec tous les anciens objectifs/effets ; captures avec les vrais sprites ; essais humains ; manette physique, Safari, son sur matériel, performances cibles et fidélité artistique finale. Pas de final complet du film annoncé.']
(R/'RAPPORT_QA_V106.md').write_text('\n'.join(qa))
readme=f'''# Alien 3 — Fiorina 161 V106 · Traces dans la pénombre

**Correctif incrémental sur une V105 connue + aperçu autonome. Ce n’est pas une archive du jeu principal complet.**

## Jouer
Ouvrir `FIORINA_V106_JOUER.html` dans un navigateur récent. Aucun asset ni service externe n’est téléchargé.
Les séquences originales « Un bruit dans les galeries » et « Le dernier rabattage » sont conservées et approfondies. La ronde V104 et les outils d’inspection restent disponibles séparément.
Flèches / A-D / Q-D : marcher ; Haut/Bas : échelle ou profondeur ; Espace : saut ; Ctrl : se baisser ; Maj : courir ; F : bruit métallique ; E : interaction / porte ; I : lumière ; **G : faire attendre/repartir un détenu proche** ; C : archives ; M : plan ; Échap : pause ; R : reprise après échec.
La lumière de service influence la reconnaissance seulement lorsque le pilote de chasse optionnel est actif. La pénombre ne rend pas invisible au contact. Sons éteints par défaut ; options de contraste et mouvement réduit.

## Sauvegardes
Exporter/Importer produit un fichier JSON <=1 Mio, validé avant remplacement. Les fichiers V105 valides migrent vers V106. L’état d’attente et la navigation sont conservés ; les bruits en vol, appels et attaques suspendues ne sont pas rejoués. Le fichier conserve aussi le dernier poste sûr, actif et vivant, de la même séquence. Après un échec, l’export et R repartent de ce poste : la pose morte n’est pas annoncée sauvegardée. L’import reste en pause. L’empreinte détecte la corruption accidentelle, pas une signature anti-triche. Aucune sauvegarde locale sur disque automatique n’est promise.

## Installation
Node.js 20+. Extraire ce paquet hors du projet cible et travailler sur une copie V105. Les sources V105 connues doivent correspondre à `sources-v105-verified.json`.
```sh
node scripts/install-v106.mjs /chemin/vers/projet-V105 --dry-run
node scripts/install-v106.mjs /chemin/vers/projet-V105
```
L’installateur ajoute quatre modules, introduit deux points de délégation dans `alien3-dlc-runtime-v105.js`, et raccorde le moteur. Six fichiers au total sont gérés. La version originale du propriétaire V105 figure dans `support-v106`. Les commandes du projet check/build s’exécutent sur une copie temporaire ; sources modifiées et écritures concurrentes sont refusées. Les tests d’installation livrés restent des fixtures, pas un build du projet complet. `--skip-project-check` saute explicitement la qualification du projet.
Le reçu externe permet le retour exact, sauf modification ultérieure :
```sh
node scripts/install-v106.mjs --restore /chemin/vers/receipt.json
```
La présence de sources V104/V105 ou de leurs installateurs dans ce paquet ne rend pas une base V86 compatible automatiquement.

## Documents
- `ALIEN3_CODEX_LEVEL_DESIGN_V106.html` : {len(cards)} fiches, dont {len(new)} nouveaux contrats.
- `docs/ALIEN3_LEVEL_DESIGN_CODEX_V106.md` : bible détaillée et données par lampe, porte, détenu et sauvegarde.
- `RAPPORT_ILLUSTRE_V106.html` / `.pdf` : rapport à captures natives, scopes séparés.
- `qa-v106/` : résultats, exports réels, captures, données et empreintes.
- `assets-v105/` : exports historiques de silhouettes vectorielles, pas des sprites définitifs nouveaux en V106.

## Reproduire
```sh
node scripts/test-v106.mjs
node scripts/test-install-v106.mjs
python scripts/build-preview-v106.py
python scripts/verify-browser-v106.py profiles
python scripts/verify-browser-v106.py resume
python scripts/verify-browser-v106.py trap
python scripts/verify-browser-v106.py failure
python scripts/verify-browser-v106.py audio
python scripts/verify-browser-v106.py layout
python scripts/verify-senses-v106.py
python scripts/aggregate-qa-v106.py
python scripts/verify-delivered-v106.py
python scripts/build-docs-v106.py
python scripts/verify-codex-v106.py
python scripts/build-pdf-v106.py
```
Playwright/Chromium et ReportLab doivent être installés pour les outils de vérification. Les polices locales sont incorporées au PDF uniquement ; aucun fichier de police n’est distribué. Les rapports historiques conservés ne sont pas des preuves d’exécution V106. Aucun push, déploiement ou build complet natif n’est revendiqué.
'''
(R/'README.md').write_text(readme)
(D/'PORTEE_V106.md').write_text('''# Portée de la V106

| Sujet | Livré et vérifié | Pas revendiqué |
|---|---|---|
| Éclairage | Couplage réel des huit lampes avec le délai de reconnaissance, bon étage et portes | Simulation physique d’éclairage, invisibilité en ombre |
| Audition | Origine réelle, trajet local/graphe, atténuation de porte, événement unique | Acoustique réaliste d’une scène 3D |
| Recherche | Déplacement vers trois voisins au maximum depuis la trace perdue | IA native complète de tous les montages |
| Coordination | Ordres G de proximité, attente et reprise sans téléportation, présence réelle aux commandes | Groupe militaire commandable à distance |
| Sauvegarde | Validation atomique, position/nav cohérente, dernier poste sûr, migration V105 | Cloud, auto-save sur disque, garantie anti-triche |
| Rendu | Captures natives des modules partagés, options conservées | Art final 1:1, sprites complets du dépôt |
| Intégration | Installateur sur copie V105 et fixtures adversariales | Build complet Tantalus, push ou déploiement |
''')
print(json.dumps({'cards':len(cards),'newCards':len(new),'captures':len(browser['screenshots'])}))
