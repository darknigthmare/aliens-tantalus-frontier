#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parents[1];out=R.parent/'ALIEN3_FIORINA_V106_TRACES_PENOMBRE_SUR_V105.zip';items=[]
for p in sorted(R.rglob('*')):
 if not p.is_file()or p.name=='manifest-v106.json'or'__pycache__'in p.parts or p.suffix in ['.pyc','.ttf','.otf','.woff','.woff2']:continue
 data=p.read_bytes();items.append({'path':p.relative_to(R).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema':106,'scope':'Incremental on known V105 bytes; shared optional encounter code + standalone simplified host; full native production build NOT executed','count':len(items),'files':items}
(R/'manifest-v106.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f in items:z.write(R/f['path'],f['path'])
 z.write(R/'manifest-v106.json','manifest-v106.json')
with zipfile.ZipFile(out)as z:assert z.testzip()is None
print(json.dumps({'ok':True,'manifestFiles':len(items),'archive':out.name,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
