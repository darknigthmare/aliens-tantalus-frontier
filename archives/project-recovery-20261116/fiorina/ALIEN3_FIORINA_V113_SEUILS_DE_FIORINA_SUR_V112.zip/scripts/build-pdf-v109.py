#!/usr/bin/env python3
"""Illustrated PDF from native Chromium captures; no independent picture rendering."""
from pathlib import Path
from xml.sax.saxutils import escape
import json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape,A4
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=Path(__file__).resolve().parents[1];Q=R/'qa-v109';b=json.loads((Q/'browser.json').read_text());u=json.loads((Q/'unit.json').read_text());i=json.loads((Q/'install.json').read_text());doc=json.loads((Q/'documentation.json').read_text());cx=json.loads((Q/'codex-browser.json').read_text());dh=json.loads((Q/'delivered.json').read_text())
for name,file in [('Body','DejaVuSans.ttf'),('Strong','DejaVuSans-Bold.ttf')]:
 p=Path('/usr/share/fonts/truetype/dejavu')/file
 if not p.is_file():raise FileNotFoundError('DejaVu Sans required locally: '+str(p))
 pdfmetrics.registerFont(TTFont(name,str(p)))
W,H=landscape(A4);M=34;CW=W-2*M;BG=HexColor('#0e1a13');INK=HexColor('#e3e8d6');MUTED=HexColor('#b7c3ad');LINE=HexColor('#52634a');GOLD=HexColor('#cdb786')
styles={k:ParagraphStyle(k,fontName='Body',fontSize=f,leading=l,textColor=MUTED if k in ['small','caption']else INK)for k,f,l in [('body',11,16),('caption',9.2,13),('small',9,12.7),('cell',9.5,13.5)]}
pdf=canvas.Canvas(str(R/'RAPPORT_ILLUSTRE_V109.pdf'),pagesize=(W,H),pageCompression=1);pdf.setTitle('ALIEN 3 — Fiorina 161 V109 — Le souffle des conduites');pdf.setAuthor('Aliens: Tantalus Frontier / dossier de développement');selectedNames=['01_aaron.png','09_coulee.png','10_refroidissement.png','19_enquete_au_bruit.png','18_vanne_des_galeries.png','19_ouverture_en_cours.png','20_purge_des_galeries.png','21_au_dela_du_jet.png','22_retour_apres_purge.png','23_purge_de_fonderie.png','24_danger_du_jet.png','25_conduite_fermee.png','26_conduite_ouverte.png','27_jet_repris.png','28_appuyer_pour_purger.png','29_purge_de_ventilation.png'];selected=[next(x for x in b['screenshots']if Path(x['file']).name==n)for n in selectedNames];total=3+len(selected);pn=0

def para(text,x,top,width,style='body',maxh=None):
 p=Paragraph(text,styles[style]);_,height=p.wrap(width,999)
 if maxh and height>maxh:raise ValueError(f'Overflow {height}>{maxh}: {text[:60]}')
 p.drawOn(pdf,x,top-height);return height

def page(title,section):
 global pn;pn+=1;pdf.setFillColor(BG);pdf.rect(0,0,W,H,fill=1,stroke=0);pdf.setFillColor(GOLD);pdf.setFont('Strong',9);pdf.drawString(M,H-24,'ALIEN 3  /  FIORINA 161');pdf.setFont('Body',8);pdf.drawRightString(W-M,H-24,'V109  ·  '+section);pdf.setFillColor(INK);pdf.setFont('Strong',24)
 if pdfmetrics.stringWidth(title,'Strong',24)>CW:raise ValueError(title)
 pdf.drawString(M,H-57,title);pdf.setStrokeColor(LINE);pdf.line(M,29,W-M,29);pdf.setFillColor(MUTED);pdf.setFont('Body',7.5);pdf.drawString(M,16,'Banc local · modules partagés · silhouettes vectorielles · pas de campagne native complète certifiée');pdf.drawRightString(W-M,16,f'{pn:02d} / {total}')

def image(file,top=H-76):
 h=CW*720/1280;pdf.drawImage(str(R/file),M,top-h,width=CW,height=h,preserveAspectRatio=True,mask='auto');pdf.setStrokeColor(LINE);pdf.rect(M,top-h,CW,h,stroke=1,fill=0);return top-h

def table(rows,top,widths):
 t=Table([[Paragraph(escape(str(x)),styles['cell'])for x in row]for row in rows],colWidths=widths);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#2d3b26')),('BACKGROUND',(0,1),(-1,-1),HexColor('#182b1c')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,-1),.5,LINE)]));_,h=t.wrap(CW,999);t.drawOn(pdf,M,top-h);return top-h
page('Le souffle des conduites','VERSION LOCALE CANDIDATE')
y=image('qa-v109/captures/20_purge_des_galeries.png');para('Une purge limitée, un jet localisé et une chasse qui reste dangereuse. Capture native après ouverture au clavier. Les décors et systèmes viennent des modules livrés ; la physique de base et les personnages restent simplifiés.',M,y-10,CW,'caption',40);pdf.showPage()
page('Brouiller la vue, pas devenir invisible','CHANGEMENTS ET LIMITES')
y=table([['Élément','Comportement livré','Limite'],['Trois conduites','Galeries, ventilation et fonderie ; réserves séparées.','Pas de nouveau trajet ni simulation de fluides.'],['Ouvrir avec V','Geste de 1,40 s ; 70 unités de pression dépensées.','Présence, appui, profondeur et accès vérifiés.'],['Vapeur','4,8 s de souffle chaud + 1,2 s de dissipation.','Porte fermée : jet tronqué à la face.'],['Chasse','Vue distante gênée ; petits bruits locaux atténués.','Le sifflement attire ; trace et attaque conservées.'],['Chaleur','Brûlure après exposition au même étage.','Pas de dégâts au Runner ou aux détenus.'],['Reprise','Pression et durée restante conservées.','Import en pause ; aucun geste ou son rejoué.']],H-82,[125,338,CW-463]);y-=18
para('Le parcours des galeries a masqué des contrôles de vision, mais a aussi coûté trois points de santé en traversant le jet. Le robot a ensuite rapporté le relevé à Aaron. Ce résultat ne garantit pas une fuite pour tout joueur ou toute situation.',M,y,CW,'body',50);y-=64
para(f'Codex de level design : <b>{doc["cards"]} fiches</b>, dont {doc["newCards"]} nouveaux contrats. Trois postes, neuf groupes de formes de raccordement ; les ensembles historiques ne sont pas recomptés comme de nouveaux assets.',M,y,CW,'small',40);pdf.showPage()
page('Des parcours observés, pas un film complet','PREUVES EXÉCUTÉES')
rows=[['Profil automatisé','Santé','Contacts','Purges / brûlures','Temps simulé']]
for route in b['routes']:
 st=route['result'];steam=st.get('steam',{}).get('stats',{});rows.append([route['profile'],st['hp'],st['pursuit']['stats']['hits'],f'{steam.get("opened",0)} / {steam.get("heatDamage",0)}',f'{st["clock"]:.2f} s'])
y=table(rows,H-81,[211,70,86,175,CW-542]);y-=15
para('Traversées au clavier avec horloge contrôlée, sans injection de position ni d’étape. Les robots connaissent le chemin et lisent l’état pour vérifier le résultat. Les comparaisons dirigées de porte et l’échec préparé restent distincts.',M,y,CW,'small',42);y-=54
para(f'<b>{u["cases"]} cas unitaires</b>, <b>{i["cases"]} installations synthétiques</b>, <b>{b["controlsExecuted"]} assertions Chromium</b> ({b["uniqueControlNames"]} libellés distincts), {dh["tests"]} contrôles du fichier ordinaire et {cx["tests"]} contrôles du codex. Les régressions V108 et V107 sont séparées.',M,y,CW,'small',40);y-=53
para('<b>Non revendiqué :</b> build complet Tantalus, parcours intégral du film, sprites définitifs, essais humains, manette physique, Safari, écoute matérielle ou déploiement. Cinq nouveaux modules et un raccord de moteur, sans modification des 42 sources V108 vérifiées.',M,y,CW,'small',40);pdf.showPage()
titles={'01_aaron.png':'La consigne d’Aaron','09_coulee.png':'La coulée reste terminable','10_refroidissement.png':'Refroidissement au poste réel','19_enquete_au_bruit.png':'Les diversions restent actives','18_vanne_des_galeries.png':'Atteindre la vanne','19_ouverture_en_cours.png':'Le geste avant la décharge','20_purge_des_galeries.png':'Purge dans les galeries','21_au_dela_du_jet.png':'Franchir le volume dangereux','22_retour_apres_purge.png':'Retour vivant après la purge','23_purge_de_fonderie.png':'Conduite de la fonderie','24_danger_du_jet.png':'La vapeur peut brûler','25_conduite_fermee.png':'Battant fermé : jet arrêté','26_conduite_ouverte.png':'Battant ouvert : jet prolongé','27_jet_repris.png':'Reprendre un jet actif','28_appuyer_pour_purger.png':'Mode Appuyer et même durée','29_purge_de_ventilation.png':'Ventilation de l’étage supérieur'}
for index,shot in enumerate(selected,1):
 page(titles[Path(shot['file']).name],f'CAPTURE NATIVE {index:02d} / {len(selected)}');y=image(shot['file']);scope='Comparaison dirigée avec positions ou porte préparées.'if'directed'in shot['scope']else'Actions au clavier/pointeur dans le banc local.';para(escape(shot['caption'])+' '+scope,M,y-10,CW,'caption',40);pdf.showPage()
assert pn==total;pdf.save();report={'ok':True,'pages':pn,'nativeScreenshotsInPdf':len(selected),'nativeScreenshotsAvailable':len(b['screenshots']),'bytes':(R/'RAPPORT_ILLUSTRE_V109.pdf').stat().st_size};(Q/'pdf.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
