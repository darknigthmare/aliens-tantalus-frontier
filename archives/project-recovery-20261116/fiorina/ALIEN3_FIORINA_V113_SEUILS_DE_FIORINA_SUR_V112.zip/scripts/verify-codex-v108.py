from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib,shutil
R=Path(__file__).resolve().parents[1];Q=R/'qa-v108';source=R/'ALIEN3_CODEX_LEVEL_DESIGN_V108.html';checks=[]
def check(name,ok):
 if not ok:raise AssertionError(name)
 checks.append({'name':name,'ok':True})
with sync_playwright()as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium')or'/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(source.read_text(),wait_until='load')
 check('535 fiches générées depuis le socle et les contrats V108',page.locator('article').count()==535)
 check('Identifiants HTML uniques, sections et assemblages distingués',page.evaluate('()=>{const ids=[...document.querySelectorAll("article[id]")].map(x=>x.id);return new Set(ids).size===ids.length;}'))
 for name,total in [('Sections',20),('Participants V105',3),('Parcours V105',2),('Étapes V105',9),('États du Runner',9),('Repères visuels V105',5),('Audio V105',10),('Règles V106',24),('Lumière et perception',8),('Portes et acoustique',3),('Coordination V106',3),('Reprises V106',3),('Manœuvres V107',4),('Règles V107',24),('Postes de commande',1),('Composants V107',4),('Commandes accessibles',1),('Reprises V107',3),('Bruits de préparation',1),('Règles V108',30),('États des boulons',4),('Surfaces de collision V108',13),('Portes et projectiles',3),('Commandes V108',2),('Objets persistants V108',3),('Reprises V108',3),('Perception V108',1),('Rendu V108',1)]:
  page.locator('#kind').select_option(name);check(name+' : '+str(total),page.locator('article').count()==total)
 page.locator('#kind').select_option('Tout');page.locator('#search').fill('Morse');check('Recherche réelle par nom de participant',0<page.locator('article').count()<535)
 page.locator('#search').fill('boulon');check('Recherche sur les nouvelles identités physiques',page.locator('article').count()>0)
 page.locator('#search').fill('surface108-support-0');page.locator('details').first.locator('summary').click();page.locator('[data-jump="state108-rest"]').first.click();check('Un support mène à la fiche réelle de repos',page.locator('#state108-rest').count()==1)
 page.locator('#search').fill('<img src=x onerror=alert(1)>');check('Recherche non interprétée en HTML',page.locator('article').count()==0 and page.locator('img').count()==0)
 page.locator('#search').fill('participant-morse');page.locator('details').first.locator('summary').click();page.locator('[data-jump="f161-lead-primer"]').first.click();check('Le lien de Morse mène au véritable point du graphe',page.locator('#f161-lead-primer').count()==1)
 page.locator('#search').fill('');page.locator('#kind').select_option('Commandes V108');page.screenshot(path=str(Q/'codex.png'))
 page.set_viewport_size({'width':390,'height':844});check('Codex sans débordement horizontal sur mobile',page.evaluate('document.documentElement.scrollWidth<=innerWidth'));check('Aucune erreur JavaScript',not errors);b.close()
(Q/'codex-browser.json').write_text(json.dumps({'ok':True,'tests':len(checks),'checks':checks,'sha256':hashlib.sha256(source.read_bytes()).hexdigest()},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'tests':len(checks)}))
