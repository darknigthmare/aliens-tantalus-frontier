#!/usr/bin/env python3
"""Real inputs for station holds, cancellation, toggle accessibility and file resumption.
Prepared damage/door fixtures are explicitly separated from the keyboard traversal.
"""
from browser_support_v107 import *

def to_water(p):
 press(p,'KeyE',15);walk(p,3890);press(p,'KeyE');walk(p,4362);hold(p,'ArrowUp',86);walk(p,4672)
 record('Le collecteur est rejoint par déplacement et échelle',state(p)['stage']==1 and abs(state(p)['y']-240)<1)

def download(p,name):
 p.evaluate('document.body.classList.remove("capture")')
 with p.expect_download()as dl:p.locator('#export-save').click()
 dest=OUT/name;dl.value.save_as(dest)
 p.evaluate('document.body.classList.add("capture")');p.locator('canvas').focus()
 return dest

with sync_playwright()as pw:
 browser=pw.chromium.launch(executable_path=shutil.which('chromium')or'/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 p=start(browser,mode='trap');to_water(p)
 p.keyboard.down('KeyE');tick(p,35)
 record('Maintenir commence sans amorcer immédiatement',state(p)['stage']==1 and state(p)['operations']['active']['elapsed']>.5)
 snap(p,'13_amorcage','Le collecteur se prépare sous maintien de E. Parcours au clavier, pas état injecté.')
 p.keyboard.up('KeyE');tick(p,1)
 record('Relâcher annule la manœuvre partielle',state(p)['operations']['active'] is None and state(p)['stage']==1)
 p.keyboard.down('KeyE');tick(p,15);p.keyboard.down('ArrowRight');tick(p,4);p.keyboard.up('ArrowRight');p.keyboard.up('KeyE')
 record('Le mouvement reprend librement et interrompt la commande',state(p)['operations']['active'] is None and state(p)['stage']==1 and state(p)['x']>4672)
 walk(p,4672);p.keyboard.down('KeyE');tick(p,20);press(p,'KeyM');p.keyboard.up('KeyE');before=state(p);tick(p,180)
 record('Ouvrir le plan annule puis fige la préparation',state(p)==before and state(p)['operations']['active']is None and state(p)['stage']==1)
 snap(p,'14_plan_pendant_preparation','Plan consulté après interruption ; aucune préparation cachée ne se poursuit.')
 press(p,'Escape');p.keyboard.down('KeyE');tick(p,20);press(p,'KeyC');p.keyboard.up('KeyE');before=state(p);tick(p,90)
 record('Les archives interrompent aussi la manœuvre',state(p)==before and state(p)['operations']['active']is None)
 press(p,'KeyC')
 # Actual export while a partial gesture is active. The snapshot cannot auto-resume it.
 p.keyboard.down('KeyE');tick(p,25);saved=download(p,'operation-partielle-v107.json');p.keyboard.up('KeyE')
 raw=json.loads(saved.read_text());record('Le fichier ne sérialise jamais une commande active',raw['schema']==107 and raw['operations']['active']is None and raw['operations']['completed']==[])
 q=start(browser,mode='trap');q.evaluate('document.body.classList.remove("capture")');q.locator('#save-file').set_input_files(str(saved));q.wait_for_function('document.querySelector("#save-status").textContent.includes("restaurée")')
 record('Importer sur une autre page conserve le stade, mais pas la commande partielle',state(q)['stage']==1 and state(q)['operations']['active']is None and q.evaluate('fiorinaBench.engine.paused'))
 # Choose the accessible input option by the actual settings menu, while paused.
 q.locator('#interaction').select_option('toggle');q.locator('#pause').click();q.evaluate('document.body.classList.add("capture")');q.locator('canvas').focus()
 press(q,'KeyE');tick(q,50)
 record('Le mode Appuyer progresse sans garder une touche enfoncée',state(q)['operations']['inputMode']=='toggle' and state(q)['operations']['active']['elapsed']>.8 and not q.evaluate('fiorinaBench.engine.keys.has("KeyE")'))
 snap(q,'15_commande_appuyer','Option « Appuyer » : durée et contraintes identiques, sans maintien de la touche.')
 tick(q,61);record('La préparation se termine une seule fois',state(q)['stage']==2 and state(q)['operations']['stats']['completed']==1)
 completed=download(q,'operation-terminee-v107.json');raw=json.loads(completed.read_text());record('Le poste sûr inclut l’opération terminée et son réglage',raw['safePoint']['operations']['completed']==['prime'] and raw['safePoint']['operations']['inputMode']=='toggle')
 z=start(browser,mode='trap');z.evaluate('document.body.classList.remove("capture")');z.locator('#save-file').set_input_files(str(completed));z.wait_for_function('document.querySelector("#save-status").textContent.includes("restaurée")')
 record('Le réglage Appuyer est restauré dans les contrôles visibles',z.locator('#interaction').input_value()=='toggle' and state(z)['stage']==2)
 # A recomputed outer hash cannot forge completion at an earlier stage.
 raw=json.loads(saved.read_text());raw['operations']['completed']=['prime']
 forged=z.evaluate('''f=>{const text=JSON.stringify({base:f.base,operations:f.operations,safePoint:f.safePoint||null});let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619);}f.checksum=(h>>>0).toString(16).padStart(8,'0');return JSON.stringify(f);}''',raw)
 bad=OUT/'operation-falsifiee-test.json';bad.write_text(forged);before=z.evaluate('JSON.stringify(fiorinaBench.exportState())');z.locator('#save-file').set_input_files(str(bad));z.wait_for_function('document.querySelector("#save-status").textContent.includes("refusé")')
 record('La progression falsifiée est refusée malgré une empreinte recalculée',z.evaluate('JSON.stringify(fiorinaBench.exportState())')==before)
 p.close();q.close();z.close()
 # Pointer input for the same actuator is exercised using the real touch button.
 t=start(browser,mode='trap');to_water(t);t.evaluate('document.body.classList.remove("capture");document.querySelector(".touchpad").style.display="flex"');button=t.locator('#act');button.scroll_into_view_if_needed();bb=button.bounding_box();t.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);t.mouse.down();tick(t,35)
 record('Le bouton tactile produit une action maintenue',state(t)['operations']['active']is not None and state(t)['stage']==1)
 t.mouse.up();tick(t,1);record('Relâcher le pointeur libère la commande et la touche',state(t)['operations']['active']is None and not t.evaluate('fiorinaBench.engine.keys.has("KeyE")'))
 t.close()
 # Directed state for interruption under damage, explicitly not claimed as route.
 d=start(browser,mode='trap');to_water(d);d.keyboard.down('KeyE');tick(d,30)
 before=state(d)['hp'];d.evaluate("fiorinaBench.engine.damagePlayer(fiorinaBench.engine.player,7,{source:'fire'})")
 record('Une blessure réelle annule sans rendre le joueur invulnérable',state(d)['hp']==before-7 and state(d)['operations']['active']is None)
 snap(d,'16_interruption_blessure','Test dirigé : dommage de feu appliqué pendant une manœuvre, puis interruption.', 'directed damage test after keyboard access')
 d.keyboard.up('KeyE');d.close()
 record('Aucune exception JavaScript dans les essais de manœuvre',not errors,errors);record('Aucune requête réseau externe dans les essais',not external,external)
 browserVersion=browser.version;browser.close()
report={'ok':True,'scope':'Actual shared V107 runtime with simplified bench. Traversal/key/pointer tests separate from directed wound. No full native campaign claimed.','browser':browserVersion,'controls':len(tests),'results':tests,'routes':routes,'screenshots':captures,'errors':errors,'externalRequests':external,'sourceHashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (ROOT/'src').glob('*v107.js')}}
(OUT/'browser-work.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'controls':len(tests),'captures':len(captures)}))
