# ALIEN 3 — FIORINA 161 · QA V113 — Seuils de Fiorina

## Exécution réelle
- 32 cas unitaires sur la base V112 instrumentée.
- 19 scénarios d’installation avec npm synthétique.
- 85 assertions Chromium dans 4 groupes, 59 libellés distincts.
- 20 contrôles du fichier jouable ordinaire sans API de test.
- 85 contrôles du codex interactif.
- 28 captures natives du canvas Chromium.

## Parcours continus
| Profil | État final | Santé | Durée simulée |
|---|---|---:|---:|
| rapide | complete | 62 | 19.27 s |
| prudent | complete | 62 | 20.08 s |
| accessibilite | complete | 82 | 19.27 s |
| rabattage-file-et-depart | complete | 100 | 31.25 s |
| rabattage-file-reprise | complete | 100 | 31.27 s |

Les cinq traversées listées utilisent les gestionnaires clavier et une horloge contrôlée. Elles ne modifient pas les positions, arrivées, ordres ou étapes par injection. La file reprise a été exportée, importée sur une nouvelle page et suivie jusqu’à la fin du rabattage. Les robots connaissent les itinéraires ; leurs temps ne sont pas des durées de campagne humaine.

## Comparaisons dirigées séparées
Trois portes fermées puis ouvertes à pose et instant identiques : la feuille et son voyant changent, les montants restent fixes. Une traversée locale vérifie le blocage par le seuil fermé puis le franchissement après E. Les deux états ne représentent pas deux scènes du film reconstituées.
Les tenues du crash, carcérale et extérieure de Ripley sont des états préparés pour inspection. Les agents de récupération apparaissent avec le drapeau d’arrivée, sans créer de participant de simulation ni d’arme dans l’inventaire. Les quatre objets ajoutés restent sur leurs appuis.

## Problèmes de fidélité assumés
Les trois portes conservent leurs positions de gameplay héritées. Le correctif les intègre dans des retours de cloison avec un rangement de volet ; il ne démontre pas que leur position correspond au plan du film. Les retours de cloison sont décoratifs, en retrait du passage.
Le registre contient 25 entrées de lieux et scènes principales, non un inventaire exhaustif certifié. Dix-neuf possèdent des points du graphe ; six n’ont pas de liaison : prologue Sulaco, hôte bovin, présence canine/chenil, bureau d’Andrews, confinement de Golic et intérieur de récupération. Un point existant n’est pas une preuve de scène reconstruite.
Le palier de morgue hérité reste en haut du modèle ; le raccord observé dans le montage étendu exige une comparaison et une refonte ultérieure, non effectuées dans ce patch.
Les 17 fiches de personnages ne signifient pas 17 nouveaux acteurs : quatre silhouettes du banc ont été reprises, Bishop est un fragment de décor et les deux agents de récupération sont des visuels conditionnels. Les autres rôles manquants restent indiqués. Le rendu vectoriel ne certifie pas la ressemblance des visages.
Le registre de 24 équipements sépare propriétaire, référence et état livré. La lampe portative, l’outil lourd et le diagnostic complet ne sont pas déclarés implémentés. Le fusil noir de la Compagnie n’est pas une arme jouable ajoutée.

## Sauvegarde et installation
Aucune nouvelle progression ni migration : le fichier V112 reste utilisé. Vingt dessins ne changent ni pose, ni inventaire, ni sauvegarde. Les archives joueur gardent leurs 90 dossiers.
L’installateur vérifie 59 sources V112. Il ajoute trois modules, met à jour deux points de délégation de dessin dans le propriétaire V105 et raccorde le moteur. L’original V105 est conservé dans la base du paquet ; la copie installée est obtenue par la même fonction de patch que celle utilisée pour l’aperçu. Les contrôles de concurrence et la restauration couvrent cinq fichiers.
Les npm des tests d’installation sont synthétiques et ne valident pas le build de Tantalus. La régression V112 (54 cas unitaires) a été rejouée séparément ; ses garanties ne prouvent pas une campagne native complète.

## Non revendiqué
Aucun build complet de Tantalus, parcours intégral du film, push ou déploiement V113. Pas d’écoute matérielle, de manette ou de Safari physique certifiés. Pas de nouvelle arme active, de nouveau combat de la Compagnie ou de reconstitution 1:1 totale.
