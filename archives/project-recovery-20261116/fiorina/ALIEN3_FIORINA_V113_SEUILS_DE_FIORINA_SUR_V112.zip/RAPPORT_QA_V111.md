# QA — Alien 3 V111

## Exécution réelle
- 61 cas unitaires sur base instrumentée.
- 19 scénarios d’installation à npm synthétique.
- 121 assertions Chromium, 89 libellés distincts, 11 groupes.
- 15 contrôles du HTML distribué sans API de test.
- 64 contrôles du codex interactif.
- 31 captures natives.

## Parcours
| Profil | État | Santé | Contacts | Détours décidés | Retours de segment | Temps simulé |
|---|---|---:|---:|---:|---:|---:|
| rapide | complete | 62 | 1 | 0 | 0 | 19.27 s |
| prudent | complete | 62 | 1 | 0 | 0 | 20.08 s |
| accessibilite | complete | 82 | 1 | 0 | 0 | 19.27 s |
| explorateur-reprise | complete | 82 | 1 | 0 | 0 | 19.27 s |
| rabattage-avec-esquive | complete | 100 | 0 | 0 | 0 | 26.07 s |
| rabattage-vanne-et-groupe | complete | 100 | 0 | 1 | 1 | 34.68 s |
| purge-refermee-en-traque | complete | 82 | 1 | 0 | 0 | 21.30 s |
| rabattage-porte-et-detour | complete | 100 | 0 | 1 | 1 | 34.57 s |
| detour-repris-par-fichier | active | 100 | 0 | 1 | 1 | 17.50 s |

Huit parcours sont terminés. La neuvième ligne (détour repris par fichier) valide l’arrivée du groupe aux postes ; elle ne prétend pas être une nouvelle fin complète du piège.

Les parcours utilisent les gestionnaires clavier et une horloge contrôlée. Le robot connaît les itinéraires. Le registre des détours contient des faits de décision, pas un cache de route exportable. Après import, un trajet qui se termine grâce au propriétaire historique n’est pas recompté comme une nouvelle décision V111.

## Corrections trouvées
- Un ancien test de largeur de porte utilisait 42 % de la largeur du corps ; le garde V111 utilise la demi-largeur et refuse la pénétration de l’épaule avant report du mouvement.
- Le premier contrôle visuel attendait à tort une coursive haute. Le calcul choisit les galeries inférieures, plus courtes ; la preuve teste maintenant un vrai changement d’étage plutôt qu’un chemin imposé par le test.
- L’essai de silence d’un détenu retenu comptait les pas de tout le groupe. Il vérifie désormais le parcours propre de Morse ; Dillon, encore en mouvement, peut légitimement marcher.
- Le test de lien dans le codex sélectionne la fiche exacte : une recherche peut aussi afficher les fiches qui la référencent.
- La capture du détour a été décalée dans le temps de simulation, sans changer les positions, pour montrer Morse entièrement dans le champ de jeu.

## Non revendiqué
Aucune nouvelle route, machine, blessure de détenu, panique complète ou modification du comportement du Runner. Les détours emploient le graphe existant et ne forcent pas les étapes du piège.
Banc avec physique simplifiée et silhouettes vectorielles provisoires. Pas de campagne native entière, test humain, appareil mobile physique, Safari, manette, écoute matérielle ou performance cible certifiée. Aucun build natif, push ou déploiement, et aucune nouvelle affirmation de refus de droits GitHub.

## Installation
Quatre nouveaux modules et un raccord moteur, contrôlés contre les 51 sources V110 livrées. Aucune source historique modifiée. Copie temporaire, vérification des mêmes octets, garde contre la concurrence et restauration externe. Les scripts npm des fixtures ne sont pas le build de Tantalus.

## Régressions séparées
V110 : 65 cas et 19 installations. V109 : 60 cas. Les suites historiques restent indépendantes de la qualification du moteur complet.
