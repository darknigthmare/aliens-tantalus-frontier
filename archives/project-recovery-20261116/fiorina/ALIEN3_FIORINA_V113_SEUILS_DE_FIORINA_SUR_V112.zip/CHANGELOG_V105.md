# V105 — Traques et préparatifs

- Préflight réel du dépôt et garde d’installation sur V104 ; pas de build natif revendiqué.
- Graphe de navigation commun, portes respectées, inversion de trajet sans téléportation.
- Un Runner : patrouille, audition, vue, trace, recherche, attaque préparée et récupération.
- Deux séquences originales du banc avec Aaron, puis Morse/Dillon physiquement à leurs postes.
- Cinq repères redessinés ; humains différenciés ; Runner articulé ; exports transparents du renderer.
- Audio synthétisé optionnel, spatial et interrompu par les interfaces.
- Sauvegardes validées avant remplacement, grâce de reprise et contrôles de données nulles.
- Contrôle Ctrl corrigé ; approches des échelles dérivées du graphe.
- 396 fiches de conception, références uniques pour sections et assemblages homonymes.
- Captures natives et preuves séparant traversées, états dirigés, tests et intégration native manquante.
