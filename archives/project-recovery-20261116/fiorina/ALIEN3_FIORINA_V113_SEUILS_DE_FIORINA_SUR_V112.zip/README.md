# ALIEN 3 — FIORINA 161 V113 · Seuils de Fiorina

Correctif incrémental sur une base V112 compatible. Ce paquet n’est pas le jeu principal complet.

## Ouvrir
- `FIORINA_V113_JOUER.html` : aperçu autonome, sans requête réseau externe. Le contrôleur de base est simplifié ; les modules V104–V113 sont partagés avec le correctif.
- `ALIEN3_CODEX_LEVEL_DESIGN_V113.html` : 770 fiches recherchables, y compris les manques de fidélité.
- `RAPPORT_ILLUSTRE_V113.html` et `.pdf` : captures natives Chromium, avec portée précise.
- `docs/PORTEE_V113.md` : ce qui est intégré et ce qui ne l’est pas.

## Installation
Node.js 20 ou ultérieur. Travailler sur une copie distincte du projet. Les 59 sources V112 doivent correspondre à `sources-v112-verified.json`.

```sh
node scripts/install-v113.mjs /chemin/vers/projet --dry-run
node scripts/install-v113.mjs /chemin/vers/projet
```

L’installateur prépare une copie temporaire, vérifie les mêmes octets, applique deux délégations de dessin facultatives au propriétaire V105, ajoute trois modules et raccorde le moteur. Il lance les `npm run check` et `npm run build` du projet avant de reporter les changements. L’option `--no-build` ne valide aucune compilation. Les tests fournis utilisent des projets synthétiques.

Une restauration externe est créée ; son chemin figure dans le résultat :

```sh
node scripts/install-v113.mjs --restore /chemin/receipt.json
```

La restauration refuse des fichiers modifiés après l’installation. Le paquet conserve l’original V105 et la copie patchée dans `support-v113/`. La fonction de modification est unique et utilisée par l’installateur comme par le bundle jouable.

## Jouer et inspecter
Les deux boutons de parcours lancent la traque originale d’Aaron et le dernier rabattage. Les sélecteurs extérieurs au canvas servent à inspecter des situations préparées ; ce ne sont pas des chapitres filmés entièrement rejoués. L’équipe de récupération est visible dans la situation d’arrivée et n’apparaît pas au milieu des parcours de test.
Flèches : se déplacer, échelle ou profondeur ; Espace : saut ; E : action ; G : consigne au détenu proche ; T/Y : lancer/récupérer un boulon ; V : purge ; C : archives ; M : plan ; Échap : pause/retour.
La sauvegarde conserve le format V112 : V113 ne change que la présentation et le registre de fidélité. Import en pause, pas de reprise automatique d’un geste suspendu.

## Rejouer les preuves
```sh
node scripts/test-v113.mjs
node scripts/test-install-v113.mjs
python scripts/verify-browser-v113.py profiles
python scripts/verify-spacing-v113.py route
python scripts/verify-spacing-v113.py resume
python scripts/verify-fidelity-v113.py
python scripts/verify-delivered-v113.py
python scripts/build-codex-v113.py
python scripts/verify-codex-v113.py
python scripts/build-reports-v113.py
python scripts/build-pdf-v113.py
```
Python Playwright et Chromium sont requis pour les contrôles navigateur ; ReportLab et DejaVu Sans pour le PDF. Aucune police n’est redistribuée comme fichier. Les anciens rapports illustrés sont omis pour éviter les doublons ; les sources et outils utiles sont conservés.

## Fidélité
Le rendu reste vectoriel stylisé. Les références de production guident vêtements, finitions et usages, mais ne prouvent pas les dimensions ou les visages 1:1. Le registre signale les six lieux/scènes non liés et le raccord de morgue non qualifié. Aucun build complet, push ou déploiement n’a été effectué pour cette livraison.
