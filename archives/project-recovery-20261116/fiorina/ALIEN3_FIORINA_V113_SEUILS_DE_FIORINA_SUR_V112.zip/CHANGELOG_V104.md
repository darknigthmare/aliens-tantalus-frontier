# V104 — Continuité du complexe

- Raccord visuel aux vrais drapeaux de feu, plomb et choc thermique ; traces de suie persistantes.
- HUD contextuel avec vitales critiques, options de contraste et de mouvement.
- Contrôle supplémentaire des morsures : distance, étage, profondeur interpolée, portes.
- Horloge V104 arrêtée par les interfaces, pause et chargement ; dessin sans progression.
- Ronde originale locale terminable et export/import atomique au niveau de la validation.
- Correctif incrémental de trois modules sur V103, sans écraser les sources héritées.
- Matrice inter-DLC, codex généré depuis les données et captures natives Chromium.
