# QA — Alien 3 V112 · Laisser passer

## Exécution réelle
- 54 cas unitaires sur base instrumentée et vrai graphe.
- 19 scénarios d’installation à npm synthétique.
- 139 assertions Chromium, 100 libellés distincts, 10 groupes.
- 20 contrôles du HTML distribué sans API de test.
- 73 contrôles du codex interactif.
- 37 captures natives issues des modules livrés.

## Parcours au clavier
| Profil | État | Santé | Contacts | Attentes de circulation | Reprises | Pas à allure réduite | Temps simulé |
|---|---|---:|---:|---:|---:|---:|---:|
| rapide | complete | 62 | 1 | 0 | 0 | 0 | 19.27 s |
| prudent | complete | 62 | 1 | 0 | 0 | 0 | 20.08 s |
| accessibilite | complete | 82 | 1 | 0 | 0 | 0 | 19.27 s |
| explorateur-reprise | complete | 82 | 1 | 0 | 0 | 0 | 19.27 s |
| rabattage-avec-esquive | complete | 100 | 0 | 0 | 0 | 0 | 26.07 s |
| rabattage-vanne-et-groupe | complete | 100 | 0 | 0 | 0 | 0 | 34.68 s |
| rabattage-porte-et-detour | complete | 100 | 0 | 0 | 0 | 0 | 34.57 s |
| rabattage-file-et-depart | complete | 100 | 0 | 1 | 1 | 268 | 31.25 s |
| rabattage-file-reprise | complete | 100 | 0 | 2 | 1 | 268 | 31.27 s |

Les neuf parcours listés sont terminés. Le dernier inclut l’export de la file, l’import sur une nouvelle page, la reprise du groupe et toute la fin du rabattage, pas seulement l’arrivée des détenus.
Les robots connaissent les itinéraires. Les temps simulés ne sont pas des durées de campagne humaine. Les traversées utilisent les gestionnaires clavier ; les positions, étapes et arrivées ne sont pas injectées pendant les trajets. L’import reste en pause et aucune commande suspendue n’est rejouée.

## Problème reproduit puis corrigé
Un cas instrumenté de 600 pas a retenu Dillon avec l’ordre G pendant que Morse le rejoignait : 38 pas de rectangles corporels superposés en V111, 0 en V112. Cette comparaison est dirigée, pas une traversée de campagne.
Le premier correctif stoppait trop souvent le suivant derrière un meneur plus lent. Il recalcule maintenant un budget plus court depuis la même pose initiale, sans reporter deux mouvements. Le parcours au clavier vérifie une reprise régulière et une marge maintenue.

## Garanties ciblées
- Largeur et hauteur des corps, même étage et profondeur, balayage du prochain pas.
- Entrée sur une échelle ou un élévateur occupé différée ; contrat isolé, pas de scénario navigateur de croisement spécifique revendiqué.
- L’ordre G reste prioritaire ; l’attente n’attribue jamais un poste ni une arrivée.
- Aucun faux pas sonore pour une pose immobile ; l’allure réduite compte sa distance réelle.
- Cache de file absent de la sauvegarde ; la pause importée ne fait pas avancer le groupe.
- Validation du registre : reprises ≤ attentes ≤ pas bloqués, durée d’attente compatible avec les durées des pas.
- Les files recalculées après import peuvent constituer un nouvel épisode d’attente dans le registre. La pose et les ordres ne sont pas réécrits pour éviter cette comptabilisation.
- Vingt dessins successifs ne modifient pas le fichier exporté.
- Le fichier ordinaire, à horloge requestAnimationFrame et sans API QA, démontre lui aussi l’arrêt derrière Dillon, l’absence de mouvement pendant son attente et le départ avec G.

## Limites
Circulation locale entre les détenus mobiles, pas un solveur multi-agent global. Deux acteurs face à face sans place de dégagement attendent ; aucune poussée, esquive latérale inventée ni téléportation n’est appliquée. Ripley et le Runner ne deviennent pas des murs de navigation pour le groupe.
Le Runner reste dormant pendant les préparatifs antérieurs à l’armement, conformément à la séquence héritée. Son comportement n’est pas modifié par V112.
Banc avec physique simplifiée et personnages vectoriels provisoires. Pas de campagne native entière, essai humain, appareil mobile physique, Safari, manette ou écoute matérielle certifiés. Aucun build natif, push, déploiement ni nouvelle affirmation de refus de droits GitHub.

## Installation
Quatre modules nouveaux et un raccord moteur sur 55 sources V111 vérifiées, sans modification des sources historiques. Copie temporaire, contrôle des mêmes octets, détection des modifications concurrentes, reçu de restauration externe. Les npm synthétiques des fixtures ne valident pas le build de Tantalus.

## Régressions séparées
V111 : 61 cas unitaires et 19 installations. V110 : 65 cas et 19 installations. Les anciennes suites restent indépendantes de la qualification native. Leurs trajets de traque, vapeur et détour ont aussi été rejoués dans la composition V112.
