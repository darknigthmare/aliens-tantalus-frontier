import {withAlien3DlcRuntimeV104} from '../src/alien3-dlc-runtime-v104.js';
import {makeBenchSaveV104,parseBenchSaveV104,validateBenchSaveV104,roundObjectiveV104,ROUND_V104,stableSpaceV104,visualEventsV104} from '../src/alien3-dlc-v104.js';
import {compileAlien3CirculationV103} from '../src/alien3-dlc-v103.js';
import {withAlien3DlcRuntimeV103} from '../src/alien3-dlc-runtime-v103.js';
const circulation=compileAlien3CirculationV103();
import {ALIEN3_DEFAULT_SCENE_V102 as scene,ALIEN3_FIORINA_TEMPLATE_V102 as topology,ALIEN3_CAMPAIGN_ID_V102,ALIEN3_SECTOR_BRIEFS_V102,sectorAt102,clamp102} from '../src/alien3-dlc-v102.js';
import {withAlien3DlcRuntimeV102} from '../src/alien3-dlc-runtime-v102.js';
import {withAlien3DlcRuntimeV101} from '../src/alien3-dlc-runtime-v101.js';
import {ALIEN3_DLC_CODEX_V99} from '../src/alien3-dlc-v99.js';
const canvas=document.querySelector('canvas'),c=canvas.getContext('2d');
// Actual simplified movement/collisions for the visual bench, not the production engine.
const nodes=new Map(topology.nodes.map(n=>[n.id,n]));
const surfaces=topology.nodes.map(n=>({id:n.id,x:n.x-n.width/2,y:n.y,w:n.width}));
for(const e of topology.edges){const a=nodes.get(e.from),b=nodes.get(e.to);if(a.y===b.y&&['walk','gate','airlock'].includes(e.kind))surfaces.push({id:e.id,x:Math.min(a.x,b.x),w:Math.abs(a.x-b.x),y:a.y});}
const ladders=topology.edges.filter(e=>['ladder','lift'].includes(e.kind)).map(e=>{const a=nodes.get(e.from),b=nodes.get(e.to);return {id:e.id,x:(a.x+b.x)/2,top:Math.min(a.y,b.y),bottom:Math.max(a.y,b.y)};});
function drawPerson(ctx,p,time){
 const lane=p.depth??1,scale=lane===0?.88:lane===2?1.04:1,dy=lane===0?-26:lane===2?18:0;const walk=Math.abs(p.vx)>2?Math.sin(time*10)*11:0;
 ctx.save();ctx.translate(p.x+p.w/2,p.y+p.h+dy);ctx.scale(p.facing*scale,scale);ctx.fillStyle='rgba(1,9,5,.48)';ctx.beginPath();ctx.ellipse(0,0,27,5,0,0,Math.PI*2);ctx.fill();
 const limb=(x,y,x2,y2,w,col)=>{ctx.strokeStyle=col;ctx.lineWidth=w;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x2,y2);ctx.stroke();};
 limb(-5,-36,-7-walk*.4,-20,9,'#303c31');limb(-7-walk*.4,-20,-8-walk*.8,-5,8,'#56634c');limb(7,-35,7+walk*.4,-20,10,'#6a775b');limb(7+walk*.4,-20,8+walk*.8,-4,8,'#718264');limb(-9-walk*.8,-4,-2-walk*.8,-3,6,'#1b261e');limb(8+walk*.8,-3,17+walk*.8,-3,6,'#273627');
 ctx.fillStyle='#7d8c68';ctx.beginPath();ctx.moveTo(-12,-72);ctx.lineTo(10,-72);ctx.lineTo(15,-37);ctx.lineTo(-13,-37);ctx.closePath();ctx.fill();ctx.fillStyle='#4e6149';ctx.fillRect(-8,-65,13,20);ctx.strokeStyle='#a6ab7f';ctx.lineWidth=1;ctx.strokeRect(-7,-63,11,14);
 limb(-10,-67,-16-walk*.25,-49,7,'#657254');limb(-16-walk*.25,-49,-10-walk*.5,-35,5,'#a2a386');limb(10,-67,16+walk*.25,-51,7,'#8d9b75');limb(16+walk*.25,-51,26+walk*.4,-45,5,'#b6b191');
 ctx.fillStyle='#a9a285';ctx.fillRect(-3,-79,8,9);ctx.beginPath();ctx.ellipse(1,-85,8,10,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#6e7b5b';ctx.fillRect(-6,-96,12,4);ctx.fillStyle='#303a2b';ctx.fillRect(6,-86,2,2);ctx.restore();
}
function drawRunner(ctx,r,time){
 if(!r.alive)return;const lane=r.depth??1,scale=lane===0?.88:lane===2?1.04:1,dy=lane===0?-26:lane===2?18:0;ctx.save();ctx.translate(r.x+r.w/2,r.y+r.h+dy);ctx.scale(r.facing*scale,scale);ctx.strokeStyle='#899381';ctx.fillStyle='#273b30';ctx.lineWidth=1.1;
 ctx.beginPath();ctx.moveTo(-41,-31);ctx.bezierCurveTo(-103,-72,-111,-7,-159,-44);ctx.bezierCurveTo(-107,-34,-118,-78,-42,-42);ctx.fill();ctx.stroke();
 ctx.beginPath();ctx.ellipse(-7,-42,40,14,.1,0,Math.PI*2);ctx.fill();ctx.stroke();for(let i=0;i<8;i++){ctx.beginPath();ctx.ellipse(-34+i*7,-43,3,12,.1,0,Math.PI*2);ctx.stroke();}
 ctx.beginPath();ctx.moveTo(11,-56);ctx.bezierCurveTo(34,-78,91,-78,102,-58);ctx.bezierCurveTo(111,-43,55,-44,27,-41);ctx.closePath();ctx.fillStyle='#4b6051';ctx.fill();ctx.stroke();ctx.fillStyle='#c0c0a1';ctx.fillRect(72,-43,19,2);
 for(let i=0;i<4;i++){const x=i<2?-36:18,side=i%2?-1:1;ctx.strokeStyle=i%2?'#91a18c':'#435c48';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(x,-41);ctx.lineTo(x+side*(14+Math.sin(time*7)*4),-19);ctx.lineTo(x+side*25,0);ctx.stroke();ctx.lineWidth=1.3;ctx.beginPath();ctx.moveTo(x+side*25,-1);ctx.lineTo(x+side*25+17,-1);ctx.stroke();}
 ctx.restore();
}
class BenchPhysics{
 constructor(){this.keys=new Set();this.laneClock=0;this.laneLatch=0;this.doors=circulation.gates.map(g=>({...g,open:true,progress:1}));this.mission={state:'active'};this.player={x:130,y:420,w:36,h:90,health:88,maxHealth:100,alive:true,vx:0,vy:0,facing:1,depth:1,grounded:true};this.alien3RunnerV88={x:400,y:440,w:109,h:70,alive:false,facing:-1};this.camera={x:0,y:0};this.running=true;this.paused=false;this.animationTime=0;this.alien3V88={phase:'wreckage'};this.alien3V89={company:{visible:false}};this.alien3V98={codexUi:{open:false}};this.alien3V99={codexGraph:{currentId:'a3c-place-foundry'}};this.missionLevelRuntime={graph:{nodes:topology.nodes}};}
 start(){return {bench:true};}stop(){this.running=false;}damagePlayer(p,n){p.health=Math.max(0,p.health-n);return n;}isAlien3MissionV100(){return true;}alien3CodexUnlockedV99(){return ALIEN3_DLC_CODEX_V99.map(x=>x.id);}alien3CodexViewedV99(){return [];}alien3CodexBookmarksV99(){return [...(this.bookmarks||[])];}currentAlien3HybridSectorV97(){return sectorAt102(this.player.x);}alien3CodexVisibleEntriesV99(){const q=(this.searchText||'').toLowerCase();return ALIEN3_DLC_CODEX_V99.filter(x=>(!this.codexCategory||x.category===this.codexCategory)&&(!q||(x.title+' '+x.body).toLowerCase().includes(q)));}getInteractionPrompt(){const p=this.player;const d=this.doors.find(d=>Math.abs(p.x+p.w/2-d.x-d.w/2)<85&&Math.abs(p.y+p.h-d.y-d.h)<28);return d?(d.open?'E  Fermer le passage':'E  Ouvrir le passage'):'';}captureResumeState(){return {schema:1};}applyResumeState(){return {applied:true};}getSnapshot(){return {};}
 update(dt){if(this.paused||this.alien3V98.codexUi.open)return;this.animationTime+=dt;const p=this.player;const dir=Number(this.keys.has('ArrowRight')||this.keys.has('KeyD'))-Number(this.keys.has('ArrowLeft')||this.keys.has('KeyA')||this.keys.has('KeyQ'));p.vx=dir*192;if(dir)p.facing=dir;
 const up=this.keys.has('ArrowUp')||this.keys.has('KeyW')||this.keys.has('KeyZ'),down=this.keys.has('ArrowDown')||this.keys.has('KeyS');const ladder=ladders.find(l=>Math.abs(p.x+p.w/2-l.x)<27&&p.y+p.h>=l.top-8&&p.y+p.h<=l.bottom+8);
 if(ladder&&(up||down)){p.x=ladder.x-p.w/2;p.y=clamp102(p.y+(down?1:-1)*130*dt,ladder.top-p.h,ladder.bottom-p.h);p.vy=0;p.grounded=true;}else{
 const laneDir=Number(down)-Number(up);if(!laneDir)this.laneLatch=0;else if(sectorAt102(p.x).mode==='depth'&&this.laneLatch!==laneDir){p.depth=clamp102(p.depth+laneDir,0,2);this.laneLatch=laneDir;}
 if(this.keys.has('Space')&&p.grounded){p.vy=-395;p.grounded=false;}const old=p.y+p.h;p.vy+=930*dt;p.y+=p.vy*dt;p.grounded=false;
 for(const floor of surfaces){if(p.x+p.w>floor.x&&p.x<floor.x+floor.w&&old<=floor.y+3&&p.y+p.h>=floor.y&&p.vy>=0){p.y=floor.y-p.h;p.vy=0;p.grounded=true;break;}}
 }
 this.laneClock=Math.max(0,(this.laneClock||0)-dt);const prevX=p.x;p.x=clamp102(p.x+p.vx*dt,1,6160);for(const d of this.doors){if(d.open||p.y+p.h<=d.y||p.y>=d.y+d.h)continue;if(p.x+p.w>d.x&&p.x<d.x+d.w){p.x=prevX+p.w<=d.x?d.x-p.w:prevX>=d.x+d.w?d.x+d.w:prevX;p.vx=0;}}if(p.y>800){p.y=420;p.vy=0;}
 this.camera.x=clamp102(p.x-465,0,4920);this.camera.y=clamp102(p.y-400,0,110);
 }
 drawBackdrop(){}drawForeground(){}drawHud(){}
 clearGameplayInput(){this.keys.clear();}
 interact(){const p=this.player;const d=this.doors.find(d=>Math.abs(p.x+p.w/2-d.x-d.w/2)<85&&Math.abs(p.y+p.h-d.y-d.h)<28);if(!d)return false;d.open=!d.open;d.progress=d.open?1:0;return true;}
 fire(){return true;}
 drawWorld(ctx){
 // Every floor is taken from the supplied topology. Art lines are not new collision paths.
 const seen=new Set();for(const s of surfaces){const key=[Math.round(s.x),s.y,Math.round(s.w)].join(':');if(seen.has(key)||s.x+s.w<this.camera.x||s.x>this.camera.x+1280)continue;seen.add(key);
 this.drawPlatform(ctx,{...s,h:13});}
 for(const l of ladders){if(l.x<this.camera.x-20||l.x>this.camera.x+1300)continue;ctx.strokeStyle='#718066';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(l.x-13,l.top);ctx.lineTo(l.x-13,l.bottom);ctx.moveTo(l.x+13,l.top);ctx.lineTo(l.x+13,l.bottom);ctx.stroke();ctx.lineWidth=2;for(let y=l.top+12;y<l.bottom;y+=16){ctx.beginPath();ctx.moveTo(l.x-13,y);ctx.lineTo(l.x+13,y);ctx.stroke();}}
 for(const d of this.doors)this.drawDoor(ctx,d);
 const actors=[{actor:this.player,draw:drawPerson},{actor:this.alien3RunnerV88,draw:drawRunner}].sort((a,b)=>(a.actor.depth??1)-(b.actor.depth??1));for(const a of actors)a.draw(ctx,a.actor,this.animationTime);
 }
}
const Engine=withAlien3DlcRuntimeV104(withAlien3DlcRuntimeV103(withAlien3DlcRuntimeV102(withAlien3DlcRuntimeV101(BenchPhysics))));let e=new Engine();e.start({campaign:{id:ALIEN3_CAMPAIGN_ID_V102}});
const locations=[['Côte et épave',380,510,'wreckage'],['Infirmerie',1200,510,'infirmary'],['Détention',2230,510,'trap-prep'],['Galeries',3190,510,'bishop'],['Supervision',3890,510,'trap-prep'],['Fonderie',4260,510,'leadworks'],['Moule et pistons',4920,510,'molten-lead'],['Four principal',5500,510,'thermal-shock'],['Arrivée de la Compagnie',5900,510,'company']];
const sel=document.querySelector('#sector');locations.forEach((a,i)=>sel.add(new Option(a[0],String(i))));
function setLocation(i){const a=locations[Math.max(0,Math.min(8,i))];sel.value=String(i);Object.assign(e.player,{x:a[1],y:a[2]-90,vx:0,vy:0,depth:1,grounded:true});e.alien3V88.phase=a[3];e.alien3V89.company.visible=i===8;Object.assign(e.alien3RunnerV88,{x:a[1]+215,y:a[2]-70,alive:i>=2&&i<8});e.camera.x=clamp102(a[1]-465,0,4920);e.camera.y=0;e.animationTime=0;e.alien3NoticeV103=null;e.laneLatch=0;e.alien3V104.round=null;e.alien3V104.events={burned:false,leadSeen:false,coolingSeen:false,companySeen:false};e.alien3RoomV104=stableSpaceV104(e.alien3StandardV104,e.player);e.alien3HudV104.roomTime=4;render();}
function render(){c.clearRect(0,0,1280,720);e.drawBackdrop(c);c.save();c.translate(-e.camera.x,-e.camera.y);e.drawWorld(c);c.restore();e.drawForeground(c);e.drawHud(c);if(e.paused&&!e.alien3V98.codexUi.open&&!e.alien3MapOpenV103){c.fillStyle='rgba(7,16,12,.65)';c.fillRect(0,0,1280,720);c.font='27px sans-serif';c.fillStyle='#d2d5b8';c.fillText('Pause',599,344);}document.querySelector('#status').textContent=roundObjectiveV104(e.alien3V104)||'Explorez les pièces et retrouvez leurs archives.';document.querySelector('#progress').textContent=e.alien3V104.round?(e.alien3V104.round.finished?'Ronde terminée':`Ronde · ${Math.min(3,e.alien3V104.round.stage)}/3 éclairages`):'Exploration libre';}
sel.onchange=()=>{setLocation(Number(sel.value));canvas.focus();};document.querySelector('#map').onclick=()=>{e.alien3MapOpenV103?e.closeAlien3MapV103():e.openAlien3MapV103();render();canvas.focus();};document.querySelector('#utility').onclick=()=>{e.useAlien3UtilityV103();render();canvas.focus();};document.querySelector('#company').onclick=()=>{e.alien3V104.round=null;e.alien3V89.company.visible=!e.alien3V89.company.visible;render();};document.querySelector('#archive').onclick=()=>{e.closeAlien3MapV103();e.alien3V98.codexUi.open=!e.alien3V98.codexUi.open;render();};document.querySelector('#pause').onclick=()=>{e.paused=!e.paused;render();};
const search=document.querySelector('#archive-search');search.oninput=()=>{e.alien3V99.codexGraph.query=search.value;const list=e.alien3CodexVisibleEntriesV99();if(list[0])e.alien3V99.codexGraph.currentId=list[0].id;render();};search.onkeydown=ev=>{if(ev.code==='Escape'||ev.code==='Enter'){ev.stopPropagation();search.hidden=true;canvas.focus();}};
addEventListener('keydown',ev=>{if(/INPUT|SELECT|BUTTON/.test(ev.target.tagName)||ev.isComposing||ev.ctrlKey||ev.metaKey||ev.altKey)return;
if(e.alien3V98.codexUi.open&&!ev.repeat){
 const list=e.alien3CodexVisibleEntriesV99(),index=Math.max(0,list.findIndex(x=>x.id===e.alien3V99.codexGraph.currentId));
 if(['Comma','Period'].includes(ev.code)&&list.length){e.alien3V99.codexGraph.currentId=list[(index+(ev.code==='Period'?1:list.length-1))%list.length].id;ev.preventDefault();render();return;}
 if(['BracketLeft','BracketRight'].includes(ev.code)){const cats=['',...new Set(ALIEN3_DLC_CODEX_V99.map(x=>x.category))],i=Math.max(0,cats.indexOf(e.codexCategory||''));e.codexCategory=cats[(i+(ev.code==='BracketRight'?1:cats.length-1))%cats.length];e.alien3V98.codexUi.selectedCategory=e.codexCategory||'TOUS';const next=e.alien3CodexVisibleEntriesV99();if(next[0])e.alien3V99.codexGraph.currentId=next[0].id;render();return;}
 if(ev.code==='Slash'){ev.preventDefault();search.hidden=false;search.focus();return;}
 if(ev.code==='KeyB'){e.bookmarks ||=new Set();const id=e.alien3V99.codexGraph.currentId;e.bookmarks.has(id)?e.bookmarks.delete(id):e.bookmarks.add(id);render();return;}
}
if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(ev.code))ev.preventDefault();e.keys.add(ev.code);if(!ev.repeat&&ev.code==='Escape'){e.paused=!e.paused;e.keys.clear();}if(!ev.repeat&&ev.code==='KeyE'){e.interact();}if(!ev.repeat&&ev.code==='KeyC'){e.alien3V98.codexUi.open=!e.alien3V98.codexUi.open;search.hidden=true;e.keys.clear();}render();});addEventListener('keyup',ev=>e.keys.delete(ev.code));addEventListener('blur',()=>{e.keys.clear();e.paused=true;});
let last=performance.now();const params=new URLSearchParams(window.__BENCH_QUERY__ || location.search);const freeze=params.has('freeze');if(params.has('capture'))document.body.classList.add('capture');
function loop(t){const dt=Math.min(.034,(t-last)/1000);last=t;if(!freeze)e.update(dt);render();requestAnimationFrame(loop);}setLocation(Number(params.get('room')||0));requestAnimationFrame(loop);
if(window.__FIORINA_QA__===true)window.fiorinaBench={get engine(){return e;},scene,circulation,locations,setLocation,render,startRound,importText,exportState:()=>makeBenchSaveV104(e),tick:dt=>{e.update(dt);render();},mode:'local-shared-renderer-not-full-campaign'};

for(const button of document.querySelectorAll('[data-key]')){const key=button.dataset.key;button.addEventListener('pointerdown',ev=>{ev.preventDefault();if(e.paused||e.alien3ModalV103())return;button.setPointerCapture(ev.pointerId);e.keys.add(key);});for(const name of ['pointerup','pointercancel','lostpointercapture'])button.addEventListener(name,()=>e.keys.delete(key));}

function message(text){document.querySelector('#save-status').textContent=text;}
function syncSettings(){const s=e.alien3V104.settings;document.querySelector('#motion').checked=s.reducedMotion;document.querySelector('#contrast').checked=s.highContrast;document.querySelector('#hud-mode').value=s.hud;e.reducedMotion=s.reducedMotion;}
function startRound(){const prefs=structuredClone(e.alien3V104.settings);e.stop();e=new Engine();e.start({campaign:{id:ALIEN3_CAMPAIGN_ID_V102},alien3LocalRoundV104:true});Object.assign(e.player,{x:1120,y:420,health:100,maxHealth:100,alive:true,grounded:true});e.alien3V88.phase='infirmary';e.alien3RunnerV88.alive=false;for(const d of e.doors){d.open=false;d.progress=0;}e.alien3V104.settings=prefs;e.alien3RoomV104=stableSpaceV104(e.alien3StandardV104,e.player);e.paused=false;e.keys.clear();e.camera={x:655,y:0};syncSettings();render();canvas.focus();message('Une ronde originale : trois éclairages à rétablir, puis retour dans la salle commune.');}
function importText(text){const candidate=parseBenchSaveV104(text,e.alien3StandardV104);if(!candidate.ok){message('Fichier refusé : '+candidate.reason+'. La partie courante est conservée.');return candidate;}const s=candidate.snapshot;e.keys.clear();e.alien3MapOpenV103=false;e.alien3V98.codexUi.open=false;Object.assign(e.player,s.pose,{vx:0,vy:0,alive:true,grounded:true,climbing:false});for(const d of e.doors){d.open=s.doors.find(x=>x.id===d.id).open;d.progress=d.open?1:0;}e.alien3V103.lights=s.lights;e.alien3V103.visitedNodes=s.visited;e.alien3V104=s.state;e.alien3V88.phase=s.phase;e.alien3V90=null;e.alien3V89.company.visible=s.phase==='company'||s.phase==='finale';e.alien3RoomV104=stableSpaceV104(e.alien3StandardV104,e.player);e.camera={x:clamp102(e.player.x-465,0,4920),y:clamp102(e.player.y-400,0,110)};e.alien3NoticeV103=null;e.alien3UtilityCooldownV103=0;e.alien3HudV104={roomTime:4,healthTime:4,roundTime:4,health:e.player.health};e.alien3RunnerV88.alive=false;e.paused=true;syncSettings();message('Partie restaurée en pause. Reprendre pour continuer.');render();return {ok:true};}
document.querySelector('#round').onclick=startRound;
document.querySelector('#export-save').onclick=()=>{try{const text=JSON.stringify(makeBenchSaveV104(e),null,2),url=URL.createObjectURL(new Blob([text],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='fiorina-ronde-v104.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);message('Sauvegarde exportée.');}catch(err){message(err.message);}};
document.querySelector('#import-save').onclick=()=>document.querySelector('#save-file').click();
document.querySelector('#save-file').onchange=async event=>{const f=event.target.files[0];if(!f)return;if(f.size>1048576){message('Fichier trop volumineux. La partie est conservée.');return;}importText(await f.text());event.target.value='';};
document.querySelector('#motion').onchange=ev=>{e.alien3V104.settings.reducedMotion=ev.target.checked;e.reducedMotion=ev.target.checked;render();};
document.querySelector('#contrast').onchange=ev=>{e.alien3V104.settings.highContrast=ev.target.checked;render();};
document.querySelector('#hud-mode').onchange=ev=>{e.alien3V104.settings.hud=ev.target.value;render();};
document.querySelector('#moment').onchange=ev=>{e.alien3V104.round=null;const value=ev.target.value;const phase={quiet:'trap-prep',fire:'fire-maze',soot:'leadworks',hot:'molten-lead',steam:'thermal-shock',company:'company'}[value];e.alien3V88.phase=phase;e.alien3V90={firePlan:{ignited:value==='fire',accidentResolved:value==='soot'}};e.alien3V104.events.burned=value==='soot';e.alien3V89.company.visible=value==='company';render();};
syncSettings();
