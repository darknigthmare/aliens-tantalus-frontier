# Les cinq axes — statut V105

| Axe | État réel | Portée |
|---|---|---|
| Intégration native | Préflight réel effectué, validation complète non réalisée | Le dépôt consulté est V86. Le raccord V104 attendu est absent ; les octets du jeu complet et ses assets ne sont pas exécutés. Le script preflight-v105.mjs prépare un contrôle local en lecture seule. |
| Chasse du Runner | Implémentée dans les séquences originales | Patrouille, perception bornée, audition, dernière trace, recherche, poursuite, attaque annoncée et reprise ; pas de remplacement aveugle de toute l’IA de campagne. |
| Détenus et pièges | Implémentés et parcourus au clavier | Morse et Dillon suivent les portes et le graphe. Leur présence réelle conditionne l’armement et la coulée. Aaron appartient seulement au parcours antérieur. |
| Repères et animations | Améliorés ; art final non certifié | Cinq familles de repères redessinées à leurs appuis ; humains différenciés et Runner animé. Dix PNG transparents de référence / 48 poses exportées. Le jeu utilise les fonctions vectorielles, non les atlas. |
| Ambiance et profils | Implémentés et vérifiés techniquement | Audio synthétisé optionnel, panorama local, pause. Quatre parcours automatisés de traque et un rabattage ; pas quatre testeurs humains ni une écoute matérielle certifiée. |
