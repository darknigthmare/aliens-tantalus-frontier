# Portée V113 — Seuils de Fiorina

| Sujet | Livré et vérifié | Non revendiqué |
|---|---|---|
| Portes | 3 habillages liés au rectangle, au seuil et à l’état réel ; retours maçonnés, montants, coffre, volet replié | Position mesurée du film, nouvelle collision ou nouvelle route |
| Corps | 4 silhouettes reprises, 3 variantes explicites de Ripley | Visages photoréalistes, 17 acteurs intégrés, nouvelle IA |
| Équipement | 4 objets ancrés, arme noire sur 2 silhouettes de récupération conditionnelles | Nouvel arsenal de Ripley, arme utilisable, exhaustivité des accessoires à l’écran |
| Lieux | 25 entrées de couverture, 19 liées à des points, 6 absentes explicitement marquées | 25 nouvelles pièces, absence de tout lieu manquant, certification 1:1 |
| Montages | Colonnes séparées pour la comparaison | Deux campagnes intégralement reconstituées |
| Données | 59 sources V112 vérifiées, 3 modules nouveaux et 2 délégations de dessin sur V105 | Build natif complet ou dépôt publiquement déployé |
| Reprise | Format V112 préservé et rabattage terminé après import | Autosauvegarde disque ou cloud |

Le modèle historique conserve 72 points, 119 connexions, 20 sections descriptives, 30 assemblages et 284 composants. Les quatre objets V113 ne sont ni quatre nouvelles pièces ni quatre nouveaux comportements interactifs.
