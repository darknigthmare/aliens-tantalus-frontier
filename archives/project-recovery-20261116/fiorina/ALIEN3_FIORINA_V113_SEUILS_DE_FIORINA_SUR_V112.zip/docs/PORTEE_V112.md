# Portée V112

| Sujet | Livré et vérifié | Non revendiqué |
|---|---|---|
| Corps du groupe | Marge, pas balayé, attente, allure réduite, reprise physique | Collision rigide globale, poussée ou téléportation |
| Verticalité | Nouvel entrant refusé sur une liaison déjà occupée, essais unitaires | Nouveau parcours navigateur de croisement vertical |
| Ordres et missions | Même G, même destination, arrivée réelle nécessaire | Nouvelle étape historique, nouveau montage du film |
| Obstacles | V111 conserve portes, vapeur et itinéraires | Nouveau raccourci, machine ou conduit humain |
| Fichiers | Registre validé, queue transitoire recalculée, dernier poste sûr distinct | Réservation périmée restaurée, autosave disque, cloud ou signature anti-triche |
| Banc | Parcours continu et fin complète après reprise par fichier | Campagne native entière ou test humain |
| Intégration | 55 sources vérifiées, staging, restauration externe | Build natif complet, push et déploiement |
