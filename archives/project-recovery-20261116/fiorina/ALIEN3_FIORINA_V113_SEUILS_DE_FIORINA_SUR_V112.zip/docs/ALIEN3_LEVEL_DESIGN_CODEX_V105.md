# ALIEN 3 — FIORINA 161
## Codex V105 · Chasse et préparation du piège

396 fiches : socle V104 inchangé et 65 fiches de contrats réellement livrés. Les 284 accessoires historiques ne sont pas comptés comme 284 nouveaux assets.

## Réalité de la livraison
Correctif incrémental sur V104, six nouveaux modules et un raccord. Le dépôt consulté reste V86 au commit 496996f5ea557d970ec625aa346876f3eaed1c5f ; aucun build complet ni déploiement n’a été effectué. Le contrôle d’installation se déroule sur des fixtures synthétiques.
Deux séquences originales du banc démontrent les contrats : récupérer un relevé et le rapporter à Aaron ; préparer un rabattage industriel avec Morse et Dillon. Elles ne recréent pas la mort filmée de Dillon, la chute finale de Ripley ni les variantes complètes du montage. Aucun dialogue du film n’est copié ici.

## Navigation et perception
Le graphe conserve 72 points et 119 connexions. Le chemin est recalculé au nœud, ou inversé en cours de segment lorsque le nouveau but le nécessite, sans changer brutalement de position. Une porte fermée bloque les déplacements et les rayons. Le Runner observe uniquement une cible visible ou un bruit atteignable, mémorise la dernière trace, cherche puis retourne en patrouille. La géométrie du banc est dérivée des données ; elle n’est pas une capture de collision native complète.
Le prédateur utilise un seul corps. Son attaque prépare 0,85 seconde, évalue le contact, puis récupère 1,30 seconde. La valeur affichée dans le codex est celle du module, pas une durée de campagne. Les corps vectoriels suivent leur profondeur logique.

## Participants, préparation et final local
Aaron reste au circuit antérieur. Au signal de Dillon, Morse marche de son départ jusqu’à la coulée et Dillon rejoint sa commande. Les postes doivent être tenus à l’armement et à la coulée. Les actions refusées expliquent le blocage. La présence du Runner dans le moule est testée avant la coulée ; le refroidissement doit suivre. Les drapeaux déclenchent les effets visuels correspondants mais ne terminent pas une mission historique.

## Validation et limites
65 cas unitaires, 17 essais d’installation ; six groupes Chromium avec 53 assertions exécutées (37 libellés distincts), quatre styles automatisés pour la traque et un rabattage complet au clavier. Les tests humains, manette matérielle, Safari, assets définitifs et campagne complète ne sont pas certifiés.

## Catalogue détaillé

### Sections · Côte et épave
ID : `section-shore`
[Socle V104 conservé] Approche extérieure ; l’épave conduit vers le complexe. Repère : Coque éventrée et prise d’air. Étendue descriptive X 50–770 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-spawn | X 180 ; pied Y 510 ; largeur 260 |
| Appui | f161-eev | X 620 ; pied Y 510 ; largeur 300 |
| Ensemble | coast-intake | X 87.5 ; Y 510 ; 185 × 146 |
| Ensemble | coast-wreck | X 485.5 ; Y 510 ; 269 × 158 |

### Sections · Infirmerie
ID : `section-medical`
[Socle V104 conservé] Soins et circulation principale ; le mobilier reste derrière le passage. Repère : Brancard, lavabo et lampe de soin. Étendue descriptive X 970–1670 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-infirmary | X 1120 ; pied Y 510 ; largeur 300 |
| Appui | f161-clemens-bed | X 1380 ; pied Y 510 ; largeur 180 |
| Appui | f161-funeral-walk | X 1580 ; pied Y 510 ; largeur 180 |
| Ensemble | medical-care | X 1002 ; Y 510 ; 236 × 131.44 |
| Ensemble | clemens-room | X 1302 ; Y 510 ; 156 × 86.89 |

### Sections · Morgue et dossiers
ID : `section-morgue`
[Socle V104 conservé] Palier supérieur, séparé de l’infirmerie par son altitude. Repère : Table mortuaire et armoire. Étendue descriptive X 1175–1630 ; sol représentatif Y 350. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-master-archive-node | X 1260 ; pied Y 350 ; largeur 170 |
| Appui | f161-morgue-high | X 1500 ; pied Y 350 ; largeur 260 |
| Ensemble | morgue-bay | X 1382 ; Y 350 ; 236 × 111.27 |

### Sections · Cellules ouest
ID : `section-west-cells`
[Socle V104 conservé] Coursive basse ; les cellules peintes ne sont pas des passages ajoutés. Repère : Barreaux et couchettes. Étendue descriptive X 1750–2450 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-cell-a | X 1900 ; pied Y 510 ; largeur 300 |
| Appui | f161-assembly-hall | X 2300 ; pied Y 510 ; largeur 300 |
| Ensemble | cell-a | X 1767 ; Y 510 ; 266 × 154 |

### Sections · Cellules est
ID : `section-east-cells`
[Socle V104 conservé] Approche du verrou des galeries ; conserver une sortie identifiable. Repère : Volet réel à l’est. Étendue descriptive X 2470–2820 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-cell-b | X 2620 ; pied Y 510 ; largeur 300 |
| Appui | f161-shutter-cell-node | X 2740 ; pied Y 510 ; largeur 160 |
| Ensemble | cell-b | X 2487 ; Y 510 ; 266 × 154 |

### Sections · Réfectoire
ID : `section-refectory`
[Socle V104 conservé] Tables regroupées ; accès par les connecteurs déjà présents. Repère : Longue table et bancs. Étendue descriptive X 2180–2565 ; sol représentatif Y 350. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-mess-high | X 2320 ; pied Y 350 ; largeur 280 |
| Appui | f161-mess-ceiling | X 2470 ; pied Y 350 ; largeur 190 |
| Ensemble | mess | X 2198 ; Y 350 ; 244 × 137 |

### Sections · Communications
ID : `section-comms`
[Socle V104 conservé] Poste haut réel, distinct du secteur caméra nommé communications. Repère : Deux écrans sur console. Étendue descriptive X 2630–2810 ; sol représentatif Y 350. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-comms-high | X 2720 ; pied Y 350 ; largeur 180 |
| Ensemble | actual-comms | X 2642 ; Y 350 ; 156 × 96.24 |

### Sections · Recueillement
ID : `section-prayer`
[Socle V104 conservé] Palier haut austère, sans nouvelle porte au fond. Repère : Livre et petites flammes. Étendue descriptive X 2055–2585 ; sol représentatif Y 190. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-faith-dais-v94 | X 2180 ; pied Y 190 ; largeur 250 |
| Appui | f161-perch-cell-v93 | X 2500 ; pied Y 190 ; largeur 170 |
| Ensemble | faith | X 2067 ; Y 190 ; 226 × 133.89 |

### Sections · Pompage et secours
ID : `section-service`
[Socle V104 conservé] Eau, entretien et passage principal ; éclairage de service indépendant des objectifs. Repère : Pompe sur semelle. Étendue descriptive X 2920–3650 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-service-low | X 3070 ; pied Y 510 ; largeur 300 |
| Appui | f161-rescue-post-node | X 3330 ; pied Y 510 ; largeur 170 |
| Appui | f161-bishop | X 3500 ; pied Y 510 ; largeur 300 |
| Ensemble | service-pump | X 2957.5 ; Y 510 ; 225 × 150 |

### Sections · Ventilation
ID : `section-ventilation`
[Socle V104 conservé] Palier technique supérieur ; une échelle ne doit pas changer la profondeur. Repère : Ventilateur sous grille. Étendue descriptive X 2855–3270 ; sol représentatif Y 330. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-fan-shaft | X 2940 ; pied Y 330 ; largeur 170 |
| Appui | f161-service-high | X 3070 ; pied Y 330 ; largeur 280 |
| Appui | f161-steam-service-node | X 3190 ; pied Y 330 ; largeur 160 |
| Ensemble | murphy-fan | X 2887 ; Y 330 ; 106 × 61.39 |
| Ensemble | service-shop | X 3017 ; Y 330 ; 106 × 64.58 |

### Sections · Atelier des batteries
ID : `section-batteries`
[Socle V104 conservé] Établi et rangement au-dessus de la circulation basse. Repère : Panneau à outils. Étendue descriptive X 3265–3625 ; sol représentatif Y 330. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-hunt-service-v95 | X 3370 ; pied Y 330 ; largeur 210 |
| Appui | f161-battery-locker-v94 | X 3500 ; pied Y 330 ; largeur 250 |
| Ensemble | battery-store | X 3387 ; Y 330 ; 226 × 137.69 |

### Sections · Galeries basses
ID : `section-lower-service`
[Socle V104 conservé] Dessous du complexe ; les regards vers les étages ne constituent pas un accès. Repère : Alcôve et réseaux. Étendue descriptive X 2930–3775 ; sol représentatif Y 630. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-service-deep | X 3070 ; pied Y 630 ; largeur 280 |
| Appui | f161-tunnel-shrine | X 3420 ; pied Y 630 ; largeur 210 |
| Appui | f161-golic-cache-v94 | X 3660 ; pied Y 630 ; largeur 230 |
| Ensemble | deep-shrine | X 3327 ; Y 630 ; 186 × 110.19 |

### Sections · Réserve et supervision
ID : `section-supply`
[Socle V104 conservé] Stockage puis commande industrielle ; respecter la position du portail existant. Repère : Fûts et console de supervision. Étendue descriptive X 3565–4050 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-chemical-store | X 3670 ; pied Y 510 ; largeur 210 |
| Appui | f161-command-post-node | X 3960 ; pied Y 510 ; largeur 180 |
| Ensemble | chemical-store | X 3577 ; Y 510 ; 186 × 106.08 |
| Ensemble | command | X 3882 ; Y 510 ; 156 × 96.24 |

### Sections · Fonderie
ID : `section-leadworks`
[Socle V104 conservé] Regrouper alimentation, creuset et levage, sans ajouter de danger décoratif. Repère : Creuset sous portique. Étendue descriptive X 4030–4570 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-leadworks | X 4200 ; pied Y 510 ; largeur 340 |
| Appui | f161-lead-primer | X 4380 ; pied Y 510 ; largeur 190 |
| Appui | f161-piston-a-node | X 4480 ; pied Y 510 ; largeur 180 |
| Ensemble | leadworks | X 4122 ; Y 510 ; 156 × 118.09 |
| Ensemble | lead-primer | X 4302 ; Y 510 ; 156 × 104 |

### Sections · Collecteur supérieur
ID : `section-water`
[Socle V104 conservé] Conduite d’eau séparée visuellement du transfert de métal. Repère : Réservoir et vérins. Étendue descriptive X 4420–4910 ; sol représentatif Y 330. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-sprinkler | X 4560 ; pied Y 330 ; largeur 280 |
| Appui | f161-water-header | X 4690 ; pied Y 330 ; largeur 190 |
| Appui | f161-piston-b-node | X 4820 ; pied Y 330 ; largeur 180 |
| Ensemble | water-header | X 4447.5 ; Y 330 ; 225 × 150 |
| Ensemble | piston-upper | X 4742 ; Y 330 ; 156 × 97.05 |

### Sections · Cuve et évacuation
ID : `section-waste`
[Socle V104 conservé] Niveau inférieur : reprise des effluents et retour hydraulique. Repère : Réservoir bas et caniveau. Étendue descriptive X 3915–4890 ; sol représentatif Y 630. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-waste-tank | X 4070 ; pied Y 630 ; largeur 310 |
| Appui | f161-sluice-low | X 4500 ; pied Y 630 ; largeur 280 |
| Appui | f161-pressure-alcove-v95 | X 4780 ; pied Y 630 ; largeur 220 |
| Ensemble | waste | X 3957.5 ; Y 630 ; 225 × 150 |
| Ensemble | lower-pressure | X 4682 ; Y 630 ; 196 × 130.67 |

### Sections · Moule et pistons
ID : `section-mold`
[Socle V104 conservé] Le piège et ses commandes historiques conservent leurs conditions. Repère : Bac de coulée bas. Étendue descriptive X 4740–5230 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-mold | X 4920 ; pied Y 510 ; largeur 360 |
| Appui | f161-piston-c-node | X 5140 ; pied Y 510 ; largeur 180 |
| Ensemble | mold | X 4783.5 ; Y 510 ; 273 × 143 |

### Sections · Four principal
ID : `section-furnace`
[Socle V104 conservé] Approche chaude puis confrontation ; ne pas masquer les personnages. Repère : Bouche circulaire du four. Étendue descriptive X 5310–5750 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-furnace | X 5480 ; pied Y 510 ; largeur 340 |
| Appui | f161-parley-v93 | X 5660 ; pied Y 510 ; largeur 180 |
| Ensemble | main-furnace | X 5402 ; Y 510 ; 156 × 110.29 |
| Ensemble | parley | X 5582 ; Y 510 ; 156 × 102.23 |

### Sections · Passerelles du four
ID : `section-gantries`
[Socle V104 conservé] Commande haute avec débouchés d’échelles conservés. Repère : Treuil et caillebotis. Étendue descriptive X 5210–5880 ; sol représentatif Y 330. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-furnace-high | X 5350 ; pied Y 330 ; largeur 280 |
| Appui | f161-furnace-overlook | X 5580 ; pied Y 330 ; largeur 220 |
| Appui | f161-furnace-gantry | X 5740 ; pied Y 330 ; largeur 280 |
| Ensemble | furnace-gantry | X 5232.5 ; Y 330 ; 235 × 154 |

### Sections · Approche et plateforme
ID : `section-arrival`
[Socle V104 conservé] L’équipement de récupération reste conditionné à l’arrivée de la Compagnie. Repère : Cage portable et projecteur. Étendue descriptive X 5650–6190 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-company | X 5800 ; pied Y 510 ; largeur 300 |
| Appui | f161-patna-cage-node | X 5930 ; pied Y 510 ; largeur 160 |
| Appui | f161-extraction | X 6040 ; pied Y 510 ; largeur 300 |
| Ensemble | patna-kit | X 5887 ; Y 510 ; 86 × 42.85 |
| Ensemble | final-landing | X 5997 ; Y 510 ; 86 × 56.36 |

### Assemblages · Prise d’air côtière
ID : `coast-intake`
[Socle V104 conservé] Appui node-platform-f161-spawn ; point f161-spawn ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant fan | coast-intake/0 | X 87.5 ; Y 398 ; 84 × 84 ; pose wall |
| Composant duct | coast-intake/1 | X 167.5 ; Y 414 ; 105 × 48 ; pose wall |
| Composant junction | coast-intake/2 | X 230.5 ; Y 470 ; 38 × 38 ; pose wall |
| Composant gauge | coast-intake/3 | X 194.5 ; Y 467 ; 22 × 22 ; pose wall |
| Composant pipe | coast-intake/4 | X 175.5 ; Y 480 ; 42 × 10 ; pose wall |
| Composant drain | coast-intake/5 | X 94.5 ; Y 503 ; 100 × 7 ; pose floor |
| Composant lamp | coast-intake/6 | X 127.5 ; Y 364 ; 40 × 13 ; pose ceiling |
| Composant cable | coast-intake/7 | X 244.5 ; Y 409 ; 7 × 52 ; pose wall |
| Composant support | coast-intake/8 | X 92.5 ; Y 490 ; 6 × 20 ; pose floor |
| Composant stencil | coast-intake/9 | X 188.5 ; Y 370 ; 77 × 19 ; pose wall |
| Raccord | coast-intake-lighting-run | coast-intake/2 → coast-intake/6 |

### Assemblages · Épave et matériel de secours
ID : `coast-wreck`
[Socle V104 conservé] Appui node-platform-f161-eev ; point f161-eev ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant eev | coast-wreck/0 | X 485.5 ; Y 396 ; 236 × 114 ; pose floor |
| Composant cable | coast-wreck/1 | X 496.5 ; Y 471 ; 80 × 12 ; pose wall |
| Composant case | coast-wreck/2 | X 664.5 ; Y 476 ; 43 × 34 ; pose floor |
| Composant drain | coast-wreck/3 | X 498.5 ; Y 504 ; 139 × 6 ; pose floor |
| Composant lamp | coast-wreck/4 | X 565.5 ; Y 352 ; 41 × 13 ; pose ceiling |
| Composant junction | coast-wreck/5 | X 728.5 ; Y 461 ; 26 × 44 ; pose wall |
| Composant pipe | coast-wreck/6 | X 726.5 ; Y 405 ; 10 × 45 ; pose wall |
| Composant stencil | coast-wreck/7 | X 660.5 ; Y 367 ; 72 × 20 ; pose wall |
| Raccord | coast-wreck-lighting-run | coast-wreck/5 → coast-wreck/4 |

### Assemblages · Poste de soin
ID : `medical-care`
[Socle V104 conservé] Appui node-platform-f161-infirmary ; point f161-infirmary ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant cabinet | medical-care/0 | X 1002 ; Y 411.42 ; 44.81 × 98.58 ; pose floor |
| Composant gurney | medical-care/1 | X 1067.72 ; Y 466.19 ; 105.55 × 43.81 ; pose floor |
| Composant monitor | medical-care/2 | X 1110.54 ; Y 408.43 ; 51.78 × 38.84 ; pose wall |
| Composant sink | medical-care/3 | X 1186.22 ; Y 452.24 ; 51.78 × 57.76 ; pose floor |
| Composant bottle | medical-care/4 | X 1010.96 ; Y 425.36 ; 5.97 × 13.94 ; pose wall |
| Composant bottle | medical-care/5 | X 1023.91 ; Y 425.36 ; 5.97 × 13.94 ; pose wall |
| Composant bottle | medical-care/6 | X 1194.19 ; Y 435.32 ; 5.97 × 14.94 ; pose wall |
| Composant lamp | medical-care/7 | X 1074.69 ; Y 378.56 ; 97.59 × 11.95 ; pose ceiling |
| Composant cable | medical-care/8 | X 1159.33 ; Y 446.27 ; 7.97 × 54.77 ; pose wall |
| Composant pipe | medical-care/9 | X 1231.03 ; Y 419.38 ; 6.97 × 21.91 ; pose wall |
| Composant tray | medical-care/10 | X 1085.65 ; Y 454.24 ; 46.8 × 8.96 ; pose wall |
| Composant stencil | medical-care/11 | X 1004.99 ; Y 381.54 ; 54.77 × 16.93 ; pose wall |

### Assemblages · Chambre médicale
ID : `clemens-room`
[Socle V104 conservé] Appui node-platform-f161-clemens-bed ; point f161-clemens-bed ; échelle uniforme 0.66 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant cabinet | clemens-room/0 | X 1302 ; Y 444.84 ; 29.62 × 65.16 ; pose floor |
| Composant gurney | clemens-room/1 | X 1345.44 ; Y 481.04 ; 69.77 × 28.96 ; pose floor |
| Composant monitor | clemens-room/2 | X 1373.75 ; Y 442.86 ; 34.23 × 25.67 ; pose wall |
| Composant sink | clemens-room/3 | X 1423.77 ; Y 471.82 ; 34.23 × 38.18 ; pose floor |
| Composant bottle | clemens-room/4 | X 1307.92 ; Y 454.05 ; 3.95 × 9.22 ; pose wall |
| Composant bottle | clemens-room/5 | X 1316.48 ; Y 454.05 ; 3.95 × 9.22 ; pose wall |
| Composant bottle | clemens-room/6 | X 1429.04 ; Y 460.63 ; 3.95 × 9.87 ; pose wall |
| Composant lamp | clemens-room/7 | X 1350.05 ; Y 423.11 ; 64.51 × 7.9 ; pose ceiling |
| Composant cable | clemens-room/8 | X 1406 ; Y 467.87 ; 5.27 × 36.2 ; pose wall |
| Composant pipe | clemens-room/9 | X 1453.39 ; Y 450.1 ; 4.61 × 14.48 ; pose wall |
| Composant tray | clemens-room/10 | X 1357.29 ; Y 473.14 ; 30.94 × 5.92 ; pose wall |
| Composant stencil | clemens-room/11 | X 1303.97 ; Y 425.09 ; 36.2 × 11.19 ; pose wall |

### Assemblages · Baie mortuaire
ID : `morgue-bay`
[Socle V104 conservé] Appui node-platform-f161-morgue-high ; point f161-morgue-high ; échelle uniforme 0.9 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant cabinet | morgue-bay/0 | X 1382 ; Y 271.03 ; 52.05 × 78.97 ; pose floor |
| Composant gurney | morgue-bay/1 | X 1458.27 ; Y 312.31 ; 98.71 × 37.69 ; pose floor |
| Composant sink | morgue-bay/2 | X 1576.72 ; Y 296.16 ; 41.28 × 53.84 ; pose floor |
| Composant lamp | morgue-bay/3 | X 1463.66 ; Y 238.73 ; 77.17 × 10.77 ; pose ceiling |
| Composant drain | morgue-bay/4 | X 1461.86 ; Y 345.51 ; 96.91 × 4.49 ; pose floor |
| Composant tray | morgue-bay/5 | X 1504.04 ; Y 298.85 ; 37.69 × 8.97 ; pose wall |
| Composant junction | morgue-bay/6 | X 1588.39 ; Y 256.68 ; 22.43 × 21.54 ; pose wall |
| Composant stencil | morgue-bay/7 | X 1384.69 ; Y 239.63 ; 52.05 × 14.36 ; pose wall |
| Raccord | morgue-bay-lighting-run | morgue-bay/6 → morgue-bay/3 |

### Assemblages · Cellules ouest
ID : `cell-a`
[Socle V104 conservé] Appui node-platform-f161-cell-a ; point f161-cell-a ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant cell | cell-a/0 | X 1767 ; Y 378 ; 73 × 132 ; pose floor |
| Composant bunk | cell-a/1 | X 1861 ; Y 407 ; 111 × 103 ; pose floor |
| Composant basin | cell-a/2 | X 1990 ; Y 462 ; 35 × 48 ; pose floor |
| Composant lamp | cell-a/3 | X 1784 ; Y 356 ; 37 × 11 ; pose ceiling |
| Composant blanket | cell-a/4 | X 1880 ; Y 471 ; 42 × 8 ; pose wall |
| Composant cup | cell-a/5 | X 1965 ; Y 499 ; 8 × 11 ; pose floor |
| Composant stencil | cell-a/6 | X 1874 ; Y 368 ; 73 × 19 ; pose wall |
| Composant pipe | cell-a/7 | X 2027 ; Y 401 ; 6 × 89 ; pose wall |
| Composant cable | cell-a/8 | X 1779 ; Y 368 ; 234 × 5 ; pose wall |
| Composant drain | cell-a/9 | X 1988 ; Y 505 ; 36 × 5 ; pose floor |

### Assemblages · Cellules est
ID : `cell-b`
[Socle V104 conservé] Appui node-platform-f161-cell-b ; point f161-cell-b ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant cell | cell-b/0 | X 2487 ; Y 378 ; 73 × 132 ; pose floor |
| Composant bunk | cell-b/1 | X 2581 ; Y 407 ; 111 × 103 ; pose floor |
| Composant basin | cell-b/2 | X 2710 ; Y 462 ; 35 × 48 ; pose floor |
| Composant lamp | cell-b/3 | X 2504 ; Y 356 ; 37 × 11 ; pose ceiling |
| Composant blanket | cell-b/4 | X 2600 ; Y 471 ; 42 × 8 ; pose wall |
| Composant cup | cell-b/5 | X 2685 ; Y 499 ; 8 × 11 ; pose floor |
| Composant stencil | cell-b/6 | X 2594 ; Y 368 ; 73 × 19 ; pose wall |
| Composant pipe | cell-b/7 | X 2747 ; Y 401 ; 6 × 89 ; pose wall |
| Composant cable | cell-b/8 | X 2499 ; Y 368 ; 234 × 5 ; pose wall |
| Composant drain | cell-b/9 | X 2708 ; Y 505 ; 36 × 5 ; pose floor |

### Assemblages · Réfectoire
ID : `mess`
[Socle V104 conservé] Appui node-platform-f161-mess-high ; point f161-mess-high ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant table | mess/0 | X 2212 ; Y 305 ; 156 × 45 ; pose floor |
| Composant bench | mess/1 | X 2202 ; Y 326 ; 65 × 24 ; pose floor |
| Composant bench | mess/2 | X 2312 ; Y 326 ; 65 × 24 ; pose floor |
| Composant cup | mess/3 | X 2244 ; Y 296 ; 8 × 10 ; pose wall |
| Composant cup | mess/4 | X 2290 ; Y 296 ; 8 × 10 ; pose wall |
| Composant bowl | mess/5 | X 2324 ; Y 299 ; 21 × 7 ; pose wall |
| Composant rack | mess/6 | X 2388 ; Y 241 ; 53 × 109 ; pose floor |
| Composant lamp | mess/7 | X 2246 ; Y 215 ; 78 × 12 ; pose ceiling |
| Composant stencil | mess/8 | X 2389 ; Y 213 ; 53 × 17 ; pose wall |
| Composant cable | mess/9 | X 2391 ; Y 227 ; 42 × 5 ; pose wall |
| Raccord | mess-lighting-run | mess/6 → mess/7 |

### Assemblages · Lieu de recueillement
ID : `faith`
[Socle V104 conservé] Appui node-platform-f161-faith-dais-v94 ; point f161-faith-dais-v94 ; échelle uniforme 0.95 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant altar | faith/0 | X 2106.88 ; Y 134.92 ; 113.95 × 55.08 ; pose floor |
| Composant bench | faith/1 | X 2067 ; Y 166.26 ; 54.13 × 23.74 ; pose floor |
| Composant bench | faith/2 | X 2238.87 ; Y 166.26 ; 54.13 × 23.74 ; pose floor |
| Composant candle | faith/3 | X 2138.22 ; Y 111.18 ; 5.7 × 23.74 ; pose wall |
| Composant candle | faith/4 | X 2198.99 ; Y 114.98 ; 5.7 × 19.94 ; pose wall |
| Composant book | faith/5 | X 2168.61 ; Y 125.43 ; 22.79 × 7.6 ; pose wall |
| Composant lamp | faith/6 | X 2155.31 ; Y 56.11 ; 22.79 × 10.45 ; pose ceiling |
| Composant stencil | faith/7 | X 2108.78 ; Y 76.05 ; 112.05 × 20.89 ; pose wall |

### Assemblages · Poste de communication
ID : `actual-comms`
[Socle V104 conservé] Appui node-platform-f161-comms-high ; point f161-comms-high ; échelle uniforme 0.63 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant console | actual-comms/0 | X 2644.52 ; Y 302.19 ; 84.29 × 47.81 ; pose floor |
| Composant rack | actual-comms/1 | X 2756.48 ; Y 266.34 ; 41.52 × 83.66 ; pose floor |
| Composant monitor | actual-comms/2 | X 2652.06 ; Y 272.63 ; 32.71 × 23.9 ; pose wall |
| Composant monitor | actual-comms/3 | X 2691.69 ; Y 272.63 ; 32.71 × 23.9 ; pose wall |
| Composant spool | actual-comms/4 | X 2736.98 ; Y 331.76 ; 18.24 × 18.24 ; pose floor |
| Composant junction | actual-comms/5 | X 2733.21 ; Y 281.44 ; 16.98 × 18.24 ; pose wall |
| Composant cable | actual-comms/6 | X 2721.26 ; Y 297.79 ; 39.63 × 5.03 ; pose wall |
| Composant lamp | actual-comms/7 | X 2652.69 ; Y 255.65 ; 28.31 × 6.29 ; pose ceiling |
| Composant stencil | actual-comms/8 | X 2757.11 ; Y 253.76 ; 40.89 × 9.44 ; pose wall |
| Composant stool | actual-comms/9 | X 2683.52 ; Y 329.87 ; 15.1 × 20.13 ; pose floor |
| Raccord | actual-comms-lighting-run | actual-comms/5 → actual-comms/7 |

### Assemblages · Ventilateur de maintenance
ID : `murphy-fan`
[Socle V104 conservé] Appui node-platform-f161-fan-shaft ; point f161-fan-shaft ; échelle uniforme 0.41 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant fan | murphy-fan/0 | X 2890.27 ; Y 277.61 ; 47.47 × 47.47 ; pose wall |
| Composant duct | murphy-fan/1 | X 2937.75 ; Y 292.76 ; 52.8 × 23.33 ; pose wall |
| Composant junction | murphy-fan/2 | X 2969.26 ; Y 275.16 ; 13.92 × 12.69 ; pose wall |
| Composant gauge | murphy-fan/3 | X 2951.66 ; Y 279.66 ; 8.59 × 8.59 ; pose wall |
| Composant valve | murphy-fan/4 | X 2943.48 ; Y 318.95 ; 11.05 × 11.05 ; pose wall |
| Composant pipe | murphy-fan/5 | X 2891.09 ; Y 324.68 ; 101.91 × 3.68 ; pose wall |
| Composant drain | murphy-fan/6 | X 2894.37 ; Y 327.95 ; 38.47 × 2.05 ; pose floor |
| Composant lamp | murphy-fan/7 | X 2899.69 ; Y 268.61 ; 18.42 × 4.09 ; pose ceiling |
| Composant grille | murphy-fan/8 | X 2967.63 ; Y 319.77 ; 21.69 × 8.59 ; pose wall |
| Composant cable | murphy-fan/9 | X 2983.18 ; Y 274.75 ; 2.86 × 15.55 ; pose wall |
| Raccord | murphy-fan-lighting-run | murphy-fan/2 → murphy-fan/7 |

### Assemblages · Pompage des galeries
ID : `service-pump`
[Socle V104 conservé] Appui node-platform-f161-service-low ; point f161-service-low ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant pump | service-pump/0 | X 2985.5 ; Y 430 ; 83 × 80 ; pose floor |
| Composant tank | service-pump/1 | X 3122.5 ; Y 384 ; 60 × 126 ; pose floor |
| Composant valve | service-pump/2 | X 3086.5 ; Y 471 ; 27 × 27 ; pose wall |
| Composant gauge | service-pump/3 | X 3003.5 ; Y 402 ; 24 × 24 ; pose wall |
| Composant pipe | service-pump/4 | X 3056.5 ; Y 481 ; 84 × 10 ; pose wall |
| Composant pipe | service-pump/5 | X 3135.5 ; Y 384 ; 8 × 19 ; pose wall |
| Composant junction | service-pump/6 | X 2966.5 ; Y 448 ; 23 × 25 ; pose wall |
| Composant drain | service-pump/7 | X 2960.5 ; Y 505 ; 116 × 5 ; pose floor |
| Composant lamp | service-pump/8 | X 3056.5 ; Y 360 ; 37 × 10 ; pose ceiling |
| Composant stencil | service-pump/9 | X 2978.5 ; Y 371 ; 72 × 18 ; pose wall |
| Raccord | service-pump-lighting-run | service-pump/6 → service-pump/8 |

### Assemblages · Entretien des réseaux
ID : `service-shop`
[Socle V104 conservé] Appui node-platform-f161-service-high ; point f161-service-high ; échelle uniforme 0.45 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant bench | service-shop/0 | X 3018.78 ; Y 306.84 ; 57.9 × 23.16 ; pose floor |
| Composant rack | service-shop/1 | X 3097.17 ; Y 276.11 ; 25.83 × 53.89 ; pose floor |
| Composant toolboard | service-shop/2 | X 3024.57 ; Y 280.56 ; 47.66 × 22.71 ; pose wall |
| Composant case | service-shop/3 | X 3082.47 ; Y 314.86 ; 15.14 × 15.14 ; pose floor |
| Composant lamp | service-shop/4 | X 3029.92 ; Y 268.09 ; 35.18 × 4.9 ; pose ceiling |
| Composant junction | service-shop/5 | X 3082.92 ; Y 282.79 ; 12.03 × 14.7 ; pose wall |
| Composant spool | service-shop/6 | X 3101.18 ; Y 309.51 ; 13.36 × 13.36 ; pose wall |
| Composant pipe | service-shop/7 | X 3021.45 ; Y 272.99 ; 96.2 × 2.67 ; pose wall |
| Composant stencil | service-shop/8 | X 3082.03 ; Y 265.42 ; 35.63 × 7.57 ; pose wall |
| Composant tray | service-shop/9 | X 3045.5 ; Y 301.05 ; 14.25 × 4.45 ; pose wall |
| Raccord | service-shop-lighting-run | service-shop/5 → service-shop/4 |

### Assemblages · Alcôve des galeries
ID : `deep-shrine`
[Socle V104 conservé] Appui node-platform-f161-tunnel-shrine ; point f161-tunnel-shrine ; échelle uniforme 0.78 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant altar | deep-shrine/0 | X 3359.82 ; Y 584.67 ; 93.78 × 45.33 ; pose floor |
| Composant bench | deep-shrine/1 | X 3327 ; Y 610.46 ; 44.55 × 19.54 ; pose floor |
| Composant bench | deep-shrine/2 | X 3468.45 ; Y 610.46 ; 44.55 × 19.54 ; pose floor |
| Composant candle | deep-shrine/3 | X 3385.61 ; Y 565.13 ; 4.69 × 19.54 ; pose wall |
| Composant candle | deep-shrine/4 | X 3435.63 ; Y 568.26 ; 4.69 × 16.41 ; pose wall |
| Composant book | deep-shrine/5 | X 3410.62 ; Y 576.86 ; 18.76 × 6.25 ; pose wall |
| Composant lamp | deep-shrine/6 | X 3399.68 ; Y 519.81 ; 18.76 × 8.6 ; pose ceiling |
| Composant stencil | deep-shrine/7 | X 3361.39 ; Y 536.22 ; 92.22 × 17.19 ; pose wall |

### Assemblages · Recharge des batteries
ID : `battery-store`
[Socle V104 conservé] Appui node-platform-f161-battery-locker-v94 ; point f161-battery-locker-v94 ; échelle uniforme 0.95 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant bench | battery-store/0 | X 3390.8 ; Y 280.62 ; 123.45 × 49.38 ; pose floor |
| Composant rack | battery-store/1 | X 3557.92 ; Y 215.1 ; 55.08 × 114.9 ; pose floor |
| Composant toolboard | battery-store/2 | X 3403.14 ; Y 224.6 ; 101.61 × 48.43 ; pose wall |
| Composant case | battery-store/3 | X 3526.59 ; Y 297.71 ; 32.29 × 32.29 ; pose floor |
| Composant lamp | battery-store/4 | X 3414.54 ; Y 198.01 ; 75.02 × 10.45 ; pose ceiling |
| Composant junction | battery-store/5 | X 3527.54 ; Y 229.34 ; 25.64 × 31.34 ; pose wall |
| Composant spool | battery-store/6 | X 3566.47 ; Y 286.32 ; 28.49 × 28.49 ; pose wall |
| Composant pipe | battery-store/7 | X 3396.5 ; Y 208.45 ; 205.11 × 5.7 ; pose wall |
| Composant stencil | battery-store/8 | X 3525.64 ; Y 192.31 ; 75.97 × 16.14 ; pose wall |
| Composant tray | battery-store/9 | X 3447.77 ; Y 268.28 ; 30.39 × 9.5 ; pose wall |
| Raccord | battery-store-lighting-run | battery-store/5 → battery-store/4 |

### Assemblages · Réserve de produits
ID : `chemical-store`
[Socle V104 conservé] Appui node-platform-f161-chemical-store ; point f161-chemical-store ; échelle uniforme 0.71 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant rack | chemical-store/0 | X 3577 ; Y 423.01 ; 53.04 × 86.99 ; pose floor |
| Composant barrel | chemical-store/1 | X 3650.55 ; Y 460.49 ; 27.58 × 49.51 ; pose floor |
| Composant barrel | chemical-store/2 | X 3687.33 ; Y 460.49 ; 27.58 × 49.51 ; pose floor |
| Composant case | chemical-store/3 | X 3727.64 ; Y 485.95 ; 30.41 × 24.05 ; pose floor |
| Composant lamp | chemical-store/4 | X 3644.89 ; Y 403.92 ; 31.12 × 7.07 ; pose ceiling |
| Composant grille | chemical-store/5 | X 3657.62 ; Y 421.6 ; 57.29 × 22.63 ; pose wall |
| Composant valve | chemical-store/6 | X 3747.44 ; Y 445.64 ; 15.56 × 15.56 ; pose wall |
| Composant pipe | chemical-store/7 | X 3627.21 ; Y 437.86 ; 30.41 × 4.95 ; pose wall |
| Composant stencil | chemical-store/8 | X 3583.37 ; Y 405.33 ; 47.38 × 11.32 ; pose wall |
| Composant drain | chemical-store/9 | X 3644.89 ; Y 506.46 ; 79.21 × 3.54 ; pose floor |
| Raccord | chemical-store-lighting-run | chemical-store/0 → chemical-store/4 |

### Assemblages · Supervision de la fonderie
ID : `command`
[Socle V104 conservé] Appui node-platform-f161-command-post-node ; point f161-command-post-node ; échelle uniforme 0.63 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant console | command/0 | X 3884.52 ; Y 462.19 ; 84.29 × 47.81 ; pose floor |
| Composant rack | command/1 | X 3996.48 ; Y 426.34 ; 41.52 × 83.66 ; pose floor |
| Composant monitor | command/2 | X 3892.06 ; Y 432.63 ; 32.71 × 23.9 ; pose wall |
| Composant monitor | command/3 | X 3931.69 ; Y 432.63 ; 32.71 × 23.9 ; pose wall |
| Composant spool | command/4 | X 3976.98 ; Y 491.76 ; 18.24 × 18.24 ; pose floor |
| Composant junction | command/5 | X 3973.21 ; Y 441.44 ; 16.98 × 18.24 ; pose wall |
| Composant cable | command/6 | X 3961.26 ; Y 457.79 ; 39.63 × 5.03 ; pose wall |
| Composant lamp | command/7 | X 3892.69 ; Y 415.65 ; 28.31 × 6.29 ; pose ceiling |
| Composant stencil | command/8 | X 3997.11 ; Y 413.76 ; 40.89 × 9.44 ; pose wall |
| Composant stool | command/9 | X 3923.52 ; Y 489.87 ; 15.1 × 20.13 ; pose floor |
| Raccord | command-lighting-run | command/5 → command/7 |

### Assemblages · Collecte des effluents
ID : `waste`
[Socle V104 conservé] Appui node-platform-f161-waste-tank ; point f161-waste-tank ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant pump | waste/0 | X 3985.5 ; Y 550 ; 83 × 80 ; pose floor |
| Composant tank | waste/1 | X 4122.5 ; Y 504 ; 60 × 126 ; pose floor |
| Composant valve | waste/2 | X 4086.5 ; Y 591 ; 27 × 27 ; pose wall |
| Composant gauge | waste/3 | X 4003.5 ; Y 522 ; 24 × 24 ; pose wall |
| Composant pipe | waste/4 | X 4056.5 ; Y 601 ; 84 × 10 ; pose wall |
| Composant pipe | waste/5 | X 4135.5 ; Y 504 ; 8 × 19 ; pose wall |
| Composant junction | waste/6 | X 3966.5 ; Y 568 ; 23 × 25 ; pose wall |
| Composant drain | waste/7 | X 3960.5 ; Y 625 ; 116 × 5 ; pose floor |
| Composant lamp | waste/8 | X 4056.5 ; Y 480 ; 37 × 10 ; pose ceiling |
| Composant stencil | waste/9 | X 3978.5 ; Y 491 ; 72 × 18 ; pose wall |
| Raccord | waste-lighting-run | waste/6 → waste/8 |

### Assemblages · Creuset et transfert
ID : `leadworks`
[Socle V104 conservé] Appui node-platform-f161-leadworks ; point f161-leadworks ; échelle uniforme 0.62 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant crucible | leadworks/0 | X 4151.83 ; Y 424.85 ; 72.1 × 85.15 ; pose floor |
| Composant gantry | leadworks/1 | X 4127.59 ; Y 406.21 ; 133.63 × 103.79 ; pose floor |
| Composant hoist | leadworks/2 | X 4174.83 ; Y 414.29 ; 29.83 × 40.4 ; pose ceiling |
| Composant ladle | leadworks/3 | X 4242.57 ; Y 441.63 ; 35.43 × 68.37 ; pose floor |
| Composant gauge | leadworks/4 | X 4128.22 ; Y 475.2 ; 14.29 × 14.29 ; pose wall |
| Composant pipe | leadworks/5 | X 4127.59 ; Y 489.49 ; 26.1 × 6.22 ; pose wall |
| Composant slag | leadworks/6 | X 4240.09 ; Y 490.11 ; 25.48 × 19.89 ; pose floor |
| Composant lamp | leadworks/7 | X 4241.95 ; Y 391.91 ; 19.89 × 7.46 ; pose ceiling |
| Composant stencil | leadworks/8 | X 4150.59 ; Y 397.51 ; 49.72 × 11.19 ; pose wall |
| Composant grille | leadworks/9 | X 4194.1 ; Y 505.65 ; 26.1 × 4.35 ; pose floor |

### Assemblages · Alimentation du creuset
ID : `lead-primer`
[Socle V104 conservé] Appui node-platform-f161-lead-primer ; point f161-lead-primer ; échelle uniforme 0.69 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant pump | lead-primer/0 | X 4321.41 ; Y 454.53 ; 57.55 × 55.47 ; pose floor |
| Composant tank | lead-primer/1 | X 4416.4 ; Y 422.64 ; 41.6 × 87.36 ; pose floor |
| Composant valve | lead-primer/2 | X 4391.44 ; Y 482.96 ; 18.72 × 18.72 ; pose wall |
| Composant gauge | lead-primer/3 | X 4333.89 ; Y 435.12 ; 16.64 × 16.64 ; pose wall |
| Composant pipe | lead-primer/4 | X 4370.64 ; Y 489.89 ; 58.24 × 6.93 ; pose wall |
| Composant pipe | lead-primer/5 | X 4425.41 ; Y 422.64 ; 5.55 × 13.17 ; pose wall |
| Composant junction | lead-primer/6 | X 4308.24 ; Y 467.01 ; 15.95 × 17.33 ; pose wall |
| Composant drain | lead-primer/7 | X 4304.08 ; Y 506.53 ; 80.43 × 3.47 ; pose floor |
| Composant lamp | lead-primer/8 | X 4370.64 ; Y 406 ; 25.65 × 6.93 ; pose ceiling |
| Composant stencil | lead-primer/9 | X 4316.56 ; Y 413.63 ; 49.92 × 12.48 ; pose wall |
| Raccord | lead-primer-lighting-run | lead-primer/6 → lead-primer/8 |

### Assemblages · Collecteur d’eau supérieur
ID : `water-header`
[Socle V104 conservé] Appui node-platform-f161-sprinkler ; point f161-sprinkler ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant pump | water-header/0 | X 4475.5 ; Y 250 ; 83 × 80 ; pose floor |
| Composant tank | water-header/1 | X 4612.5 ; Y 204 ; 60 × 126 ; pose floor |
| Composant valve | water-header/2 | X 4576.5 ; Y 291 ; 27 × 27 ; pose wall |
| Composant gauge | water-header/3 | X 4493.5 ; Y 222 ; 24 × 24 ; pose wall |
| Composant pipe | water-header/4 | X 4546.5 ; Y 301 ; 84 × 10 ; pose wall |
| Composant pipe | water-header/5 | X 4625.5 ; Y 204 ; 8 × 19 ; pose wall |
| Composant junction | water-header/6 | X 4456.5 ; Y 268 ; 23 × 25 ; pose wall |
| Composant drain | water-header/7 | X 4450.5 ; Y 325 ; 116 × 5 ; pose floor |
| Composant lamp | water-header/8 | X 4546.5 ; Y 180 ; 37 × 10 ; pose ceiling |
| Composant stencil | water-header/9 | X 4468.5 ; Y 191 ; 72 × 18 ; pose wall |
| Raccord | water-header-lighting-run | water-header/6 → water-header/8 |

### Assemblages · Pistons supérieurs
ID : `piston-upper`
[Socle V104 conservé] Appui node-platform-f161-piston-b-node ; point f161-piston-b-node ; échelle uniforme 0.6 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant piston | piston-upper/0 | X 4750.34 ; Y 258.55 ; 34.53 × 71.45 ; pose floor |
| Composant piston | piston-upper/1 | X 4806.9 ; Y 258.55 ; 34.53 × 71.45 ; pose floor |
| Composant piston | piston-upper/2 | X 4863.47 ; Y 258.55 ; 34.53 × 71.45 ; pose floor |
| Composant pipe | piston-upper/3 | X 4747.36 ; Y 247.83 ; 149.45 × 6.55 ; pose wall |
| Composant gauge | piston-upper/4 | X 4848.58 ; Y 288.32 ; 13.69 × 13.69 ; pose wall |
| Composant valve | piston-upper/5 | X 4787.25 ; Y 298.44 ; 14.29 × 14.29 ; pose wall |
| Composant junction | piston-upper/6 | X 4789.63 ; Y 265.69 ; 13.69 × 16.67 ; pose wall |
| Composant lamp | piston-upper/7 | X 4810.47 ; Y 235.33 ; 25.01 × 6.55 ; pose ceiling |
| Composant stencil | piston-upper/8 | X 4749.15 ; Y 232.95 ; 44.66 × 10.72 ; pose wall |
| Composant drain | piston-upper/9 | X 4787.85 ; Y 327.02 ; 75.02 × 2.98 ; pose floor |
| Raccord | piston-upper-lighting-run | piston-upper/6 → piston-upper/7 |

### Assemblages · Moule de coulée
ID : `mold`
[Socle V104 conservé] Appui node-platform-f161-mold ; point f161-mold ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant mold | mold/0 | X 4787.5 ; Y 468 ; 231 × 42 ; pose floor |
| Composant pipe | mold/1 | X 4807.5 ; Y 414 ; 195 × 9 ; pose wall |
| Composant valve | mold/2 | X 4997.5 ; Y 414 ; 26 × 26 ; pose wall |
| Composant gauge | mold/3 | X 4793.5 ; Y 421 ; 23 × 23 ; pose wall |
| Composant lamp | mold/4 | X 4840.5 ; Y 367 ; 105 × 12 ; pose ceiling |
| Composant grille | mold/5 | X 4787.5 ; Y 501 ; 229 × 9 ; pose floor |
| Composant stencil | mold/6 | X 4861.5 ; Y 391 ; 91 × 20 ; pose wall |
| Composant junction | mold/7 | X 5032.5 ; Y 439 ; 24 × 37 ; pose wall |
| Raccord | mold-lighting-run | mold/7 → mold/4 |

### Assemblages · Retour hydraulique
ID : `lower-pressure`
[Socle V104 conservé] Appui node-platform-f161-pressure-alcove-v95 ; point f161-pressure-alcove-v95 ; échelle uniforme 0.87 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant pump | lower-pressure/0 | X 4706.39 ; Y 560.31 ; 72.3 × 69.69 ; pose floor |
| Composant tank | lower-pressure/1 | X 4825.73 ; Y 520.24 ; 52.27 × 109.76 ; pose floor |
| Composant valve | lower-pressure/2 | X 4794.37 ; Y 596.03 ; 23.52 × 23.52 ; pose wall |
| Composant gauge | lower-pressure/3 | X 4722.07 ; Y 535.92 ; 20.91 × 20.91 ; pose wall |
| Composant pipe | lower-pressure/4 | X 4768.24 ; Y 604.74 ; 73.17 × 8.71 ; pose wall |
| Composant pipe | lower-pressure/5 | X 4837.06 ; Y 520.24 ; 6.97 × 16.55 ; pose wall |
| Composant junction | lower-pressure/6 | X 4689.84 ; Y 575.99 ; 20.04 × 21.78 ; pose wall |
| Composant drain | lower-pressure/7 | X 4684.61 ; Y 625.64 ; 101.05 × 4.36 ; pose floor |
| Composant lamp | lower-pressure/8 | X 4768.24 ; Y 499.33 ; 32.23 × 8.71 ; pose ceiling |
| Composant stencil | lower-pressure/9 | X 4700.29 ; Y 508.92 ; 62.72 × 15.68 ; pose wall |
| Raccord | lower-pressure-lighting-run | lower-pressure/6 → lower-pressure/8 |

### Assemblages · Four principal
ID : `main-furnace`
[Socle V104 conservé] Appui node-platform-f161-furnace ; point f161-furnace ; échelle uniforme 0.57 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant furnace | main-furnace/0 | X 5414.57 ; Y 406 ; 101.71 × 104 ; pose floor |
| Composant pipe | main-furnace/1 | X 5524.86 ; Y 437.43 ; 8 × 65.71 ; pose wall |
| Composant gauge | main-furnace/2 | X 5522.57 ; Y 454 ; 14.29 × 14.29 ; pose wall |
| Composant slag | main-furnace/3 | X 5538 ; Y 490 ; 20 × 20 ; pose floor |
| Composant lamp | main-furnace/4 | X 5408.86 ; Y 399.71 ; 20.57 × 6.29 ; pose ceiling |
| Composant stencil | main-furnace/5 | X 5526.57 ; Y 418.57 ; 27.43 × 10.86 ; pose wall |
| Composant grille | main-furnace/6 | X 5412.29 ; Y 503.14 ; 105.71 × 6.86 ; pose floor |
| Composant junction | main-furnace/7 | X 5539.71 ; Y 459.14 ; 13.14 × 20.57 ; pose wall |
| Raccord | main-furnace-lighting-run | main-furnace/7 → main-furnace/4 |

### Assemblages · Commande de passerelle
ID : `furnace-gantry`
[Socle V104 conservé] Appui node-platform-f161-furnace-high ; point f161-furnace-high ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant winch | furnace-gantry/0 | X 5270.5 ; Y 262 ; 80 × 68 ; pose floor |
| Composant junction | furnace-gantry/1 | X 5381.5 ; Y 231 ; 36 × 51 ; pose wall |
| Composant pipe | furnace-gantry/2 | X 5255.5 ; Y 214 ; 210 × 9 ; pose wall |
| Composant valve | furnace-gantry/3 | X 5441.5 ; Y 215 ; 26 × 26 ; pose wall |
| Composant lamp | furnace-gantry/4 | X 5371.5 ; Y 176 ; 38 × 11 ; pose ceiling |
| Composant grille | furnace-gantry/5 | X 5256.5 ; Y 322 ; 139 × 8 ; pose floor |
| Composant stencil | furnace-gantry/6 | X 5258.5 ; Y 180 ; 74 × 19 ; pose wall |
| Composant support | furnace-gantry/7 | X 5355.5 ; Y 306 ; 12 × 24 ; pose floor |
| Raccord | furnace-gantry-lighting-run | furnace-gantry/1 → furnace-gantry/4 |

### Assemblages · Approche de la Compagnie
ID : `parley`
[Socle V104 conservé] Appui node-platform-f161-parley-v93 ; point f161-parley-v93 ; échelle uniforme 0.66 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant winch | parley/0 | X 5607.23 ; Y 464.86 ; 53.11 × 45.14 ; pose floor |
| Composant junction | parley/1 | X 5680.91 ; Y 444.28 ; 23.9 × 33.86 ; pose wall |
| Composant pipe | parley/2 | X 5597.27 ; Y 433 ; 139.4 × 5.97 ; pose wall |
| Composant valve | parley/3 | X 5720.74 ; Y 433.66 ; 17.26 × 17.26 ; pose wall |
| Composant lamp | parley/4 | X 5674.27 ; Y 407.77 ; 25.23 × 7.3 ; pose ceiling |
| Composant grille | parley/5 | X 5597.93 ; Y 504.69 ; 92.27 × 5.31 ; pose floor |
| Composant stencil | parley/6 | X 5599.26 ; Y 410.43 ; 49.12 × 12.61 ; pose wall |
| Composant support | parley/7 | X 5663.65 ; Y 494.07 ; 7.97 × 15.93 ; pose floor |
| Raccord | parley-lighting-run | parley/1 → parley/4 |

### Assemblages · Matériel de récupération
ID : `patna-kit`
[Socle V104 conservé] Appui node-platform-f161-patna-cage-node ; point f161-patna-cage-node ; échelle uniforme 0.31 ; condition company. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant recovery | patna-kit/0 | X 5893.16 ; Y 467.15 ; 39.76 × 42.85 ; pose floor |
| Composant case | patna-kit/1 | X 5939.4 ; Y 497.98 ; 20.65 × 12.02 ; pose floor |
| Composant lampstand | patna-kit/2 | X 5964.68 ; Y 467.15 ; 8.32 × 42.85 ; pose floor |
| Composant monitor | patna-kit/3 | X 5941.25 ; Y 486.27 ; 13.25 × 9.25 ; pose wall |
| Composant cable | patna-kit/4 | X 5930.15 ; Y 505.99 ; 14.8 × 2.47 ; pose wall |
| Composant stencil | patna-kit/5 | X 5939.09 ; Y 475.78 ; 23.43 × 6.16 ; pose wall |
| Composant case | patna-kit/6 | X 5887.31 ; Y 499.83 ; 10.79 × 10.17 ; pose floor |
| Composant clamp | patna-kit/7 | X 5908.89 ; Y 485.65 ; 8.01 × 8.32 ; pose wall |

### Assemblages · Plateforme terminale
ID : `final-landing`
[Socle V104 conservé] Appui node-platform-f161-extraction ; point f161-extraction ; échelle uniforme 0.37 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant winch | final-landing/0 | X 6010.91 ; Y 485.11 ; 29.28 × 24.89 ; pose floor |
| Composant junction | final-landing/1 | X 6051.53 ; Y 473.77 ; 13.17 × 18.66 ; pose wall |
| Composant pipe | final-landing/2 | X 6005.42 ; Y 467.55 ; 76.85 × 3.29 ; pose wall |
| Composant valve | final-landing/3 | X 6073.49 ; Y 467.91 ; 9.51 × 9.51 ; pose wall |
| Composant lamp | final-landing/4 | X 6047.87 ; Y 453.64 ; 13.91 × 4.03 ; pose ceiling |
| Composant grille | final-landing/5 | X 6005.78 ; Y 507.07 ; 50.87 × 2.93 ; pose floor |
| Composant stencil | final-landing/6 | X 6006.51 ; Y 455.11 ; 27.08 × 6.95 ; pose wall |
| Composant support | final-landing/7 | X 6042.01 ; Y 501.22 ; 4.39 × 8.78 ; pose floor |
| Raccord | final-landing-lighting-run | final-landing/1 → final-landing/4 |

### Assemblages · Émetteur de service
ID : `final-transmitter`
[Socle V104 conservé] Appui node-platform-f161-final-transmission-v94 ; point f161-final-transmission-v94 ; échelle uniforme 0.67 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Détail |
|---|---|---|
| Composant console | final-transmitter/0 | X 6019.68 ; Y 279.13 ; 89.69 × 50.87 ; pose floor |
| Composant rack | final-transmitter/1 | X 6138.82 ; Y 240.98 ; 44.18 × 89.02 ; pose floor |
| Composant monitor | final-transmitter/2 | X 6027.71 ; Y 247.67 ; 34.81 × 25.44 ; pose wall |
| Composant monitor | final-transmitter/3 | X 6069.88 ; Y 247.67 ; 34.81 × 25.44 ; pose wall |
| Composant spool | final-transmitter/4 | X 6118.07 ; Y 310.59 ; 19.41 × 19.41 ; pose floor |
| Composant junction | final-transmitter/5 | X 6114.06 ; Y 257.04 ; 18.07 × 19.41 ; pose wall |
| Composant cable | final-transmitter/6 | X 6101.34 ; Y 274.44 ; 42.17 × 5.35 ; pose wall |
| Composant lamp | final-transmitter/7 | X 6028.38 ; Y 229.6 ; 30.12 × 6.69 ; pose ceiling |
| Composant stencil | final-transmitter/8 | X 6139.49 ; Y 227.59 ; 43.51 × 10.04 ; pose wall |
| Composant stool | final-transmitter/9 | X 6061.18 ; Y 308.58 ; 16.06 × 21.42 ; pose floor |
| Raccord | final-transmitter-lighting-run | final-transmitter/5 → final-transmitter/7 |

### Réseaux · Raccord — Prise d’air côtière
ID : `coast-intake-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | coast-intake/2 | coast-intake |
| Réception | coast-intake/6 | always |
| Sommet | 1 | X 249.5 ; Y 489 |
| Sommet | 2 | X 249.5 ; Y 359 |
| Sommet | 3 | X 147.5 ; Y 359 |
| Sommet | 4 | X 147.5 ; Y 370.5 |

### Réseaux · Raccord — Épave et matériel de secours
ID : `coast-wreck-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | coast-wreck/5 | coast-wreck |
| Réception | coast-wreck/4 | always |
| Sommet | 1 | X 741.5 ; Y 483 |
| Sommet | 2 | X 741.5 ; Y 347 |
| Sommet | 3 | X 586 ; Y 347 |
| Sommet | 4 | X 586 ; Y 358.5 |

### Réseaux · Raccord — Baie mortuaire
ID : `morgue-bay-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | morgue-bay/6 | morgue-bay |
| Réception | morgue-bay/3 | always |
| Sommet | 1 | X 1599.6 ; Y 267.44 |
| Sommet | 2 | X 1599.6 ; Y 233.73 |
| Sommet | 3 | X 1502.24 ; Y 233.73 |
| Sommet | 4 | X 1502.24 ; Y 244.11 |

### Réseaux · Raccord — Réfectoire
ID : `mess-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | mess/6 | mess |
| Réception | mess/7 | always |
| Sommet | 1 | X 2414.5 ; Y 295.5 |
| Sommet | 2 | X 2414.5 ; Y 210 |
| Sommet | 3 | X 2285 ; Y 210 |
| Sommet | 4 | X 2285 ; Y 221 |

### Réseaux · Raccord — Poste de communication
ID : `actual-comms-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | actual-comms/5 | actual-comms |
| Réception | actual-comms/7 | always |
| Sommet | 1 | X 2741.7 ; Y 290.56 |
| Sommet | 2 | X 2741.7 ; Y 250.65 |
| Sommet | 3 | X 2666.85 ; Y 250.65 |
| Sommet | 4 | X 2666.85 ; Y 258.79 |

### Réseaux · Raccord — Ventilateur de maintenance
ID : `murphy-fan-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | murphy-fan/2 | murphy-fan |
| Réception | murphy-fan/7 | always |
| Sommet | 1 | X 2976.22 ; Y 281.5 |
| Sommet | 2 | X 2976.22 ; Y 263.61 |
| Sommet | 3 | X 2908.9 ; Y 263.61 |
| Sommet | 4 | X 2908.9 ; Y 270.66 |

### Réseaux · Raccord — Pompage des galeries
ID : `service-pump-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | service-pump/6 | service-pump |
| Réception | service-pump/8 | always |
| Sommet | 1 | X 2978 ; Y 460.5 |
| Sommet | 2 | X 2978 ; Y 355 |
| Sommet | 3 | X 3075 ; Y 355 |
| Sommet | 4 | X 3075 ; Y 365 |

### Réseaux · Raccord — Entretien des réseaux
ID : `service-shop-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | service-shop/5 | service-shop |
| Réception | service-shop/4 | always |
| Sommet | 1 | X 3088.93 ; Y 290.14 |
| Sommet | 2 | X 3088.93 ; Y 263.09 |
| Sommet | 3 | X 3047.51 ; Y 263.09 |
| Sommet | 4 | X 3047.51 ; Y 270.54 |

### Réseaux · Raccord — Recharge des batteries
ID : `battery-store-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | battery-store/5 | battery-store |
| Réception | battery-store/4 | always |
| Sommet | 1 | X 3540.36 ; Y 245.01 |
| Sommet | 2 | X 3540.36 ; Y 193.01 |
| Sommet | 3 | X 3452.05 ; Y 193.01 |
| Sommet | 4 | X 3452.05 ; Y 203.23 |

### Réseaux · Raccord — Réserve de produits
ID : `chemical-store-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | chemical-store/0 | chemical-store |
| Réception | chemical-store/4 | always |
| Sommet | 1 | X 3603.52 ; Y 466.51 |
| Sommet | 2 | X 3603.52 ; Y 398.92 |
| Sommet | 3 | X 3660.45 ; Y 398.92 |
| Sommet | 4 | X 3660.45 ; Y 407.45 |

### Réseaux · Raccord — Supervision de la fonderie
ID : `command-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | command/5 | command |
| Réception | command/7 | always |
| Sommet | 1 | X 3981.7 ; Y 450.56 |
| Sommet | 2 | X 3981.7 ; Y 410.65 |
| Sommet | 3 | X 3906.85 ; Y 410.65 |
| Sommet | 4 | X 3906.85 ; Y 418.79 |

### Réseaux · Raccord — Collecte des effluents
ID : `waste-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | waste/6 | waste |
| Réception | waste/8 | always |
| Sommet | 1 | X 3978 ; Y 580.5 |
| Sommet | 2 | X 3978 ; Y 475 |
| Sommet | 3 | X 4075 ; Y 475 |
| Sommet | 4 | X 4075 ; Y 485 |

### Réseaux · Raccord — Alimentation du creuset
ID : `lead-primer-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | lead-primer/6 | lead-primer |
| Réception | lead-primer/8 | always |
| Sommet | 1 | X 4316.21 ; Y 475.68 |
| Sommet | 2 | X 4316.21 ; Y 401 |
| Sommet | 3 | X 4383.47 ; Y 401 |
| Sommet | 4 | X 4383.47 ; Y 409.47 |

### Réseaux · Raccord — Collecteur d’eau supérieur
ID : `water-header-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | water-header/6 | water-header |
| Réception | water-header/8 | always |
| Sommet | 1 | X 4468 ; Y 280.5 |
| Sommet | 2 | X 4468 ; Y 175 |
| Sommet | 3 | X 4565 ; Y 175 |
| Sommet | 4 | X 4565 ; Y 185 |

### Réseaux · Raccord — Pistons supérieurs
ID : `piston-upper-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | piston-upper/6 | piston-upper |
| Réception | piston-upper/7 | always |
| Sommet | 1 | X 4796.48 ; Y 274.03 |
| Sommet | 2 | X 4796.48 ; Y 230.33 |
| Sommet | 3 | X 4822.98 ; Y 230.33 |
| Sommet | 4 | X 4822.98 ; Y 238.6 |

### Réseaux · Raccord — Moule de coulée
ID : `mold-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | mold/7 | mold |
| Réception | mold/4 | always |
| Sommet | 1 | X 5044.5 ; Y 457.5 |
| Sommet | 2 | X 5044.5 ; Y 362 |
| Sommet | 3 | X 4893 ; Y 362 |
| Sommet | 4 | X 4893 ; Y 373 |

### Réseaux · Raccord — Retour hydraulique
ID : `lower-pressure-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | lower-pressure/6 | lower-pressure |
| Réception | lower-pressure/8 | always |
| Sommet | 1 | X 4699.86 ; Y 586.88 |
| Sommet | 2 | X 4699.86 ; Y 494.33 |
| Sommet | 3 | X 4784.36 ; Y 494.33 |
| Sommet | 4 | X 4784.36 ; Y 503.69 |

### Réseaux · Raccord — Four principal
ID : `main-furnace-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | main-furnace/7 | main-furnace |
| Réception | main-furnace/4 | always |
| Sommet | 1 | X 5546.29 ; Y 469.43 |
| Sommet | 2 | X 5546.29 ; Y 394.71 |
| Sommet | 3 | X 5419.14 ; Y 394.71 |
| Sommet | 4 | X 5419.14 ; Y 402.86 |

### Réseaux · Raccord — Commande de passerelle
ID : `furnace-gantry-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | furnace-gantry/1 | furnace-gantry |
| Réception | furnace-gantry/4 | always |
| Sommet | 1 | X 5399.5 ; Y 256.5 |
| Sommet | 2 | X 5399.5 ; Y 171 |
| Sommet | 3 | X 5390.5 ; Y 171 |
| Sommet | 4 | X 5390.5 ; Y 181.5 |

### Réseaux · Raccord — Approche de la Compagnie
ID : `parley-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | parley/1 | parley |
| Réception | parley/4 | always |
| Sommet | 1 | X 5692.86 ; Y 461.21 |
| Sommet | 2 | X 5692.86 ; Y 402.77 |
| Sommet | 3 | X 5686.89 ; Y 402.77 |
| Sommet | 4 | X 5686.89 ; Y 411.42 |

### Réseaux · Raccord — Plateforme terminale
ID : `final-landing-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | final-landing/1 | final-landing |
| Réception | final-landing/4 | always |
| Sommet | 1 | X 6058.11 ; Y 483.1 |
| Sommet | 2 | X 6058.11 ; Y 448.64 |
| Sommet | 3 | X 6054.82 ; Y 448.64 |
| Sommet | 4 | X 6054.82 ; Y 455.66 |

### Réseaux · Raccord — Émetteur de service
ID : `final-transmitter-lighting-run`
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Détail |
|---|---|---|
| Source | final-transmitter/5 | final-transmitter |
| Réception | final-transmitter/7 | always |
| Sommet | 1 | X 6123.09 ; Y 266.75 |
| Sommet | 2 | X 6123.09 ; Y 224.6 |
| Sommet | 3 | X 6043.44 ; Y 224.6 |
| Sommet | 4 | X 6043.44 ; Y 232.94 |

### Commandes · Éclairage de la prise d’air
ID : `shore-light`
[Socle V104 conservé] Action I ; support node-platform-f161-spawn, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés.

| Élément | Référence | Détail |
|---|---|---|
| Commande | shore-light | X 259.5 ; Y 456 ; 13 × 29 |
| Lampe | coast-intake/6 | Récepteur réellement dessiné |

### Commandes · Lampe de soin
ID : `care-light`
[Socle V104 conservé] Action I ; support node-platform-f161-infirmary, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés.

| Élément | Référence | Détail |
|---|---|---|
| Commande | care-light | X 1225 ; Y 456 ; 13 × 29 |
| Lampe | medical-care/7 | Récepteur réellement dessiné |
| Ronde originale | 1 | Doit être rallumée à son tour. La même commande hors ronde ne termine aucune quête. |

### Commandes · Éclairage de la coursive
ID : `cell-light`
[Socle V104 conservé] Action I ; support node-platform-f161-cell-a, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés.

| Élément | Référence | Détail |
|---|---|---|
| Commande | cell-light | X 2020 ; Y 456 ; 13 × 29 |
| Lampe | cell-a/3 | Récepteur réellement dessiné |
| Ronde originale | 2 | Doit être rallumée à son tour. La même commande hors ronde ne termine aucune quête. |

### Commandes · Lampe des communications
ID : `comms-light`
[Socle V104 conservé] Action I ; support node-platform-f161-comms-high, pied Y 350 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés.

| Élément | Référence | Détail |
|---|---|---|
| Commande | comms-light | X 2785 ; Y 296 ; 13 × 29 |
| Lampe | actual-comms/7 | Récepteur réellement dessiné |

### Commandes · Lampe de l’établi
ID : `service-light`
[Socle V104 conservé] Action I ; support node-platform-f161-service-high, pied Y 330 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés.

| Élément | Référence | Détail |
|---|---|---|
| Commande | service-light | X 3110 ; Y 276 ; 13 × 29 |
| Lampe | service-shop/4 | Récepteur réellement dessiné |
| Ronde originale | 3 | Doit être rallumée à son tour. La même commande hors ronde ne termine aucune quête. |

### Commandes · Éclairage du creuset
ID : `lead-light`
[Socle V104 conservé] Action I ; support node-platform-f161-leadworks, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés.

| Élément | Référence | Détail |
|---|---|---|
| Commande | lead-light | X 4265 ; Y 456 ; 13 × 29 |
| Lampe | leadworks/7 | Récepteur réellement dessiné |

### Commandes · Lampe du moule
ID : `mold-light`
[Socle V104 conservé] Action I ; support node-platform-f161-mold, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés.

| Élément | Référence | Détail |
|---|---|---|
| Commande | mold-light | X 5043.5 ; Y 456 ; 13 × 29 |
| Lampe | mold/4 | Récepteur réellement dessiné |

### Commandes · Éclairage de la plateforme
ID : `landing-light`
[Socle V104 conservé] Action I ; support node-platform-f161-extraction, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés.

| Élément | Référence | Détail |
|---|---|---|
| Commande | landing-light | X 6070 ; Y 456 ; 13 × 29 |
| Lampe | final-landing/4 | Récepteur réellement dessiné |

### Portes · Accès aux cellules
ID : `f161-infirmary-gate`
[Socle V104 conservé] Porte historique. Cadre, feuille et seuil suivent ses dimensions ; le dessin ne crée ni nouveau verrou ni nouvelle condition d’ouverture. Une feuille ouverte ne reste pas opaque devant le chemin. La fermeture peut refuser un contact du Runner et l’accès à une commande située derrière.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-infirmary | Sol 510 |
| Arrivée | f161-cell-a | Sol 510 |
| Cadre | f161-infirmary-gate | X 1488 ; Y 378 ; 44 × 132 |
| Source | template-derived | Géométrie native utilisée si fournie au compilateur. |

### Portes · Galeries de service
ID : `f161-cellblock-gate`
[Socle V104 conservé] Porte historique. Cadre, feuille et seuil suivent ses dimensions ; le dessin ne crée ni nouveau verrou ni nouvelle condition d’ouverture. Une feuille ouverte ne reste pas opaque devant le chemin. La fermeture peut refuser un contact du Runner et l’accès à une commande située derrière.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-cell-b | Sol 510 |
| Arrivée | f161-service-low | Sol 510 |
| Cadre | f161-cellblock-gate | X 2823 ; Y 378 ; 44 × 132 |
| Source | template-derived | Géométrie native utilisée si fournie au compilateur. |

### Portes · Accès à la fonderie
ID : `f161-leadworks-gate`
[Socle V104 conservé] Porte historique. Cadre, feuille et seuil suivent ses dimensions ; le dessin ne crée ni nouveau verrou ni nouvelle condition d’ouverture. Une feuille ouverte ne reste pas opaque devant le chemin. La fermeture peut refuser un contact du Runner et l’accès à une commande située derrière.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-bishop | Sol 510 |
| Arrivée | f161-leadworks | Sol 510 |
| Cadre | f161-leadworks-gate | X 3828 ; Y 378 ; 44 × 132 |
| Source | template-derived | Géométrie native utilisée si fournie au compilateur. |

### Points · spawn
ID : `f161-spawn`
[Socle V104 conservé] Position X 180, pied Y 510, largeur 260. Section descriptive : Côte et épave. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-eev | Marche ; f161-e01 |

### Points · eev
ID : `f161-eev`
[Socle V104 conservé] Position X 620, pied Y 510, largeur 300. Section descriptive : Côte et épave. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-spawn | Marche ; f161-e01 |
| Voisin | f161-infirmary | Marche ; f161-e02 |
| Voisin | f161-flight-analysis-v94 | Échelle ; f161-e89 |
| Voisin | f161-wreckage-incident-v94 | Échelle ; f161-e91 |

### Points · infirmary
ID : `f161-infirmary`
[Socle V104 conservé] Position X 1120, pied Y 510, largeur 300. Section descriptive : Infirmerie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-eev | Marche ; f161-e02 |
| Voisin | f161-cell-a | Porte ; f161-e03 |
| Voisin | f161-morgue-high | Échelle ; f161-e12 |
| Voisin | f161-service-deep | Conduit ; f161-e19 |
| Voisin | f161-clemens-bed | Marche ; f161-e46 |
| Voisin | f161-wreckage-incident-v94 | Échelle ; f161-e92 |

### Points · morgue high
ID : `f161-morgue-high`
[Socle V104 conservé] Position X 1500, pied Y 350, largeur 260. Section descriptive : Morgue et dossiers. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-infirmary | Échelle ; f161-e12 |
| Voisin | f161-mess-high | Marche ; f161-e13 |
| Voisin | f161-funeral-walk | Échelle ; f161-e48 |
| Voisin | f161-master-archive-node | Marche ; f161-e62 |
| Voisin | f161-flight-analysis-v94 | Marche ; f161-e90 |

### Points · cell a
ID : `f161-cell-a`
[Socle V104 conservé] Position X 1900, pied Y 510, largeur 300. Section descriptive : Cellules ouest. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-infirmary | Porte ; f161-e03 |
| Voisin | f161-mess-high | Échelle ; f161-e23 |
| Voisin | f161-assembly-hall | Marche ; f161-e27 |
| Voisin | f161-shelter-cell-v95 | Échelle ; f161-e104 |

### Points · mess high
ID : `f161-mess-high`
[Socle V104 conservé] Position X 2320, pied Y 350, largeur 280. Section descriptive : Réfectoire. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-morgue-high | Marche ; f161-e13 |
| Voisin | f161-service-high | Marche ; f161-e14 |
| Voisin | f161-cell-a | Échelle ; f161-e23 |
| Voisin | f161-assembly-hall | Échelle ; f161-e29 |
| Voisin | f161-mess-ceiling | Marche ; f161-e49 |
| Voisin | f161-faith-dais-v94 | Échelle ; f161-e93 |

### Points · cell b
ID : `f161-cell-b`
[Socle V104 conservé] Position X 2620, pied Y 510, largeur 300. Section descriptive : Cellules est. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-service-low | Porte ; f161-e05 |
| Voisin | f161-assembly-hall | Marche ; f161-e28 |
| Voisin | f161-shutter-cell-node | Marche ; f161-e63 |

### Points · service low
ID : `f161-service-low`
[Socle V104 conservé] Position X 3070, pied Y 510, largeur 300. Section descriptive : Pompage et secours. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-cell-b | Porte ; f161-e05 |
| Voisin | f161-bishop | Marche ; f161-e06 |
| Voisin | f161-service-high | Échelle ; f161-e24 |
| Voisin | f161-service-deep | Échelle ; f161-e25 |
| Voisin | f161-fuel-manifold-a | Marche ; f161-e35 |
| Voisin | f161-rescue-post-node | Marche ; f161-e67 |

### Points · service high
ID : `f161-service-high`
[Socle V104 conservé] Position X 3070, pied Y 330, largeur 280. Section descriptive : Ventilation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-mess-high | Marche ; f161-e14 |
| Voisin | f161-tunnel-high | Marche ; f161-e15 |
| Voisin | f161-service-low | Échelle ; f161-e24 |
| Voisin | f161-fan-shaft | Marche ; f161-e51 |
| Voisin | f161-steam-service-node | Marche ; f161-e65 |
| Voisin | f161-perch-service-v93 | Échelle ; f161-e80 |
| Voisin | f161-battery-locker-v94 | Marche ; f161-e95 |
| Voisin | f161-hunt-service-v95 | Marche ; f161-e110 |

### Points · service deep
ID : `f161-service-deep`
[Socle V104 conservé] Position X 3070, pied Y 630, largeur 280. Section descriptive : Galeries basses. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-infirmary | Conduit ; f161-e19 |
| Voisin | f161-tunnel-low | Marche ; f161-e20 |
| Voisin | f161-service-low | Échelle ; f161-e25 |
| Voisin | f161-tunnel-shrine | Marche ; f161-e52 |
| Voisin | f161-refuge-service-v95 | Marche ; f161-e108 |

### Points · bishop
ID : `f161-bishop`
[Socle V104 conservé] Position X 3500, pied Y 510, largeur 300. Section descriptive : Pompage et secours. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-service-low | Marche ; f161-e06 |
| Voisin | f161-leadworks | Porte ; f161-e07 |
| Voisin | f161-fuel-manifold-b | Marche ; f161-e37 |
| Voisin | f161-chemical-store | Marche ; f161-e38 |
| Voisin | f161-tunnel-shrine | Échelle ; f161-e53 |
| Voisin | f161-rescue-post-node | Marche ; f161-e68 |
| Voisin | f161-shutter-service-node | Marche ; f161-e69 |

### Points · tunnel high
ID : `f161-tunnel-high`
[Socle V104 conservé] Position X 3820, pied Y 330, largeur 280. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-service-high | Marche ; f161-e15 |
| Voisin | f161-sprinkler | Marche ; f161-e16 |
| Voisin | f161-chemical-store | Échelle ; f161-e39 |
| Voisin | f161-command-post-node | Échelle ; f161-e71 |
| Voisin | f161-battery-locker-v94 | Marche ; f161-e96 |
| Voisin | f161-battery-junction-v94 | Marche ; f161-e99 |

### Points · tunnel low
ID : `f161-tunnel-low`
[Socle V104 conservé] Position X 3820, pied Y 630, largeur 280. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-service-deep | Marche ; f161-e20 |
| Voisin | f161-leadworks | Échelle ; f161-e21 |
| Voisin | f161-waste-tank | Marche ; f161-e30 |
| Voisin | f161-golic-cache-v94 | Marche ; f161-e98 |
| Voisin | f161-hunt-junction-v95 | Marche ; f161-e114 |

### Points · leadworks
ID : `f161-leadworks`
[Socle V104 conservé] Position X 4200, pied Y 510, largeur 340. Section descriptive : Fonderie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-bishop | Porte ; f161-e07 |
| Voisin | f161-mold | Marche ; f161-e08 |
| Voisin | f161-tunnel-low | Échelle ; f161-e21 |
| Voisin | f161-furnace | Conduit ; f161-e22 |
| Voisin | f161-sprinkler | Échelle ; f161-e26 |
| Voisin | f161-sluice-low | Échelle ; f161-e32 |
| Voisin | f161-lead-primer | Marche ; f161-e40 |
| Voisin | f161-piston-a-node | Marche ; f161-e54 |
| Voisin | f161-command-post-node | Marche ; f161-e72 |

### Points · sprinkler
ID : `f161-sprinkler`
[Socle V104 conservé] Position X 4560, pied Y 330, largeur 280. Section descriptive : Collecteur supérieur. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-tunnel-high | Marche ; f161-e16 |
| Voisin | f161-furnace-high | Marche ; f161-e17 |
| Voisin | f161-leadworks | Échelle ; f161-e26 |
| Voisin | f161-water-header | Marche ; f161-e42 |
| Voisin | f161-piston-b-node | Marche ; f161-e56 |
| Voisin | f161-bait-switch-v95 | Marche ; f161-e117 |

### Points · mold
ID : `f161-mold`
[Socle V104 conservé] Position X 4920, pied Y 510, largeur 360. Section descriptive : Moule et pistons. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-leadworks | Marche ; f161-e08 |
| Voisin | f161-furnace | Marche ; f161-e09 |
| Voisin | f161-lead-primer | Marche ; f161-e41 |
| Voisin | f161-water-header | Échelle ; f161-e43 |
| Voisin | f161-piston-a-node | Marche ; f161-e55 |
| Voisin | f161-piston-b-node | Échelle ; f161-e57 |
| Voisin | f161-piston-c-node | Marche ; f161-e58 |
| Voisin | f161-shutter-foundry-node | Marche ; f161-e75 |
| Voisin | f161-chase-reroute-v94 | Échelle ; f161-e101 |

### Points · furnace high
ID : `f161-furnace-high`
[Socle V104 conservé] Position X 5350, pied Y 330, largeur 280. Section descriptive : Passerelles du four. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-sprinkler | Marche ; f161-e17 |
| Voisin | f161-furnace | Échelle ; f161-e18 |
| Voisin | f161-furnace-gantry | Marche ; f161-e33 |
| Voisin | f161-furnace-overlook | Marche ; f161-e44 |
| Voisin | f161-chase-observer-v95 | Marche ; f161-e119 |

### Points · furnace
ID : `f161-furnace`
[Socle V104 conservé] Position X 5480, pied Y 510, largeur 340. Section descriptive : Four principal. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-mold | Marche ; f161-e09 |
| Voisin | f161-company | Marche ; f161-e10 |
| Voisin | f161-furnace-high | Échelle ; f161-e18 |
| Voisin | f161-leadworks | Conduit ; f161-e22 |
| Voisin | f161-piston-c-node | Marche ; f161-e59 |
| Voisin | f161-parley-v93 | Marche ; f161-e85 |
| Voisin | f161-chase-reroute-v94 | Échelle ; f161-e102 |

### Points · company
ID : `f161-company`
[Socle V104 conservé] Position X 5800, pied Y 510, largeur 300. Section descriptive : Approche et plateforme. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-furnace | Marche ; f161-e10 |
| Voisin | f161-extraction | Marche ; f161-e11 |
| Voisin | f161-furnace-gantry | Échelle ; f161-e34 |
| Voisin | f161-furnace-overlook | Échelle ; f161-e45 |
| Voisin | f161-patna-cage-node | Marche ; f161-e60 |
| Voisin | f161-parley-v93 | Marche ; f161-e86 |
| Voisin | f161-witness-v93 | Échelle ; f161-e87 |

### Points · extraction
ID : `f161-extraction`
[Socle V104 conservé] Position X 6040, pied Y 510, largeur 300. Section descriptive : Approche et plateforme. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-company | Marche ; f161-e11 |
| Voisin | f161-patna-cage-node | Marche ; f161-e61 |
| Voisin | f161-witness-v93 | Échelle ; f161-e88 |

### Points · assembly hall
ID : `f161-assembly-hall`
[Socle V104 conservé] Position X 2300, pied Y 510, largeur 300. Section descriptive : Cellules ouest. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-cell-a | Marche ; f161-e27 |
| Voisin | f161-cell-b | Marche ; f161-e28 |
| Voisin | f161-mess-high | Échelle ; f161-e29 |
| Voisin | f161-shelter-cell-v95 | Échelle ; f161-e105 |

### Points · waste tank
ID : `f161-waste-tank`
[Socle V104 conservé] Position X 4070, pied Y 630, largeur 310. Section descriptive : Cuve et évacuation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-tunnel-low | Marche ; f161-e30 |
| Voisin | f161-sluice-low | Marche ; f161-e31 |
| Voisin | f161-hunt-junction-v95 | Marche ; f161-e115 |

### Points · sluice low
ID : `f161-sluice-low`
[Socle V104 conservé] Position X 4500, pied Y 630, largeur 280. Section descriptive : Cuve et évacuation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-waste-tank | Marche ; f161-e31 |
| Voisin | f161-leadworks | Échelle ; f161-e32 |

### Points · furnace gantry
ID : `f161-furnace-gantry`
[Socle V104 conservé] Position X 5740, pied Y 330, largeur 280. Section descriptive : Passerelles du four. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-furnace-high | Marche ; f161-e33 |
| Voisin | f161-company | Échelle ; f161-e34 |

### Points · fuel manifold a
ID : `f161-fuel-manifold-a`
[Socle V104 conservé] Position X 2960, pied Y 510, largeur 180. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-service-low | Marche ; f161-e35 |
| Voisin | f161-fuel-manifold-b | Marche ; f161-e36 |

### Points · fuel manifold b
ID : `f161-fuel-manifold-b`
[Socle V104 conservé] Position X 3240, pied Y 510, largeur 180. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-fuel-manifold-a | Marche ; f161-e36 |
| Voisin | f161-bishop | Marche ; f161-e37 |

### Points · chemical store
ID : `f161-chemical-store`
[Socle V104 conservé] Position X 3670, pied Y 510, largeur 210. Section descriptive : Réserve et supervision. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-bishop | Marche ; f161-e38 |
| Voisin | f161-tunnel-high | Échelle ; f161-e39 |
| Voisin | f161-shutter-service-node | Marche ; f161-e70 |

### Points · lead primer
ID : `f161-lead-primer`
[Socle V104 conservé] Position X 4380, pied Y 510, largeur 190. Section descriptive : Fonderie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-leadworks | Marche ; f161-e40 |
| Voisin | f161-mold | Marche ; f161-e41 |

### Points · water header
ID : `f161-water-header`
[Socle V104 conservé] Position X 4690, pied Y 330, largeur 190. Section descriptive : Collecteur supérieur. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-sprinkler | Marche ; f161-e42 |
| Voisin | f161-mold | Échelle ; f161-e43 |
| Voisin | f161-steam-lead-node | Marche ; f161-e73 |
| Voisin | f161-battery-junction-v94 | Marche ; f161-e100 |

### Points · furnace overlook
ID : `f161-furnace-overlook`
[Socle V104 conservé] Position X 5580, pied Y 330, largeur 220. Section descriptive : Passerelles du four. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-furnace-high | Marche ; f161-e44 |
| Voisin | f161-company | Échelle ; f161-e45 |

### Points · clemens bed
ID : `f161-clemens-bed`
[Socle V104 conservé] Position X 1380, pied Y 510, largeur 180. Section descriptive : Infirmerie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-infirmary | Marche ; f161-e46 |
| Voisin | f161-funeral-walk | Marche ; f161-e47 |

### Points · funeral walk
ID : `f161-funeral-walk`
[Socle V104 conservé] Position X 1580, pied Y 510, largeur 180. Section descriptive : Infirmerie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-clemens-bed | Marche ; f161-e47 |
| Voisin | f161-morgue-high | Échelle ; f161-e48 |

### Points · mess ceiling
ID : `f161-mess-ceiling`
[Socle V104 conservé] Position X 2470, pied Y 350, largeur 190. Section descriptive : Réfectoire. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-mess-high | Marche ; f161-e49 |
| Voisin | f161-comms-high | Marche ; f161-e50 |
| Voisin | f161-perch-cell-v93 | Échelle ; f161-e77 |

### Points · comms high
ID : `f161-comms-high`
[Socle V104 conservé] Position X 2720, pied Y 350, largeur 180. Section descriptive : Communications. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-mess-ceiling | Marche ; f161-e50 |
| Voisin | f161-shutter-cell-node | Échelle ; f161-e64 |
| Voisin | f161-perch-cell-v93 | Échelle ; f161-e78 |
| Voisin | f161-watch-cell-v95 | Échelle ; f161-e107 |

### Points · fan shaft
ID : `f161-fan-shaft`
[Socle V104 conservé] Position X 2940, pied Y 330, largeur 170. Section descriptive : Ventilation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-service-high | Marche ; f161-e51 |
| Voisin | f161-steam-service-node | Marche ; f161-e66 |

### Points · tunnel shrine
ID : `f161-tunnel-shrine`
[Socle V104 conservé] Position X 3420, pied Y 630, largeur 210. Section descriptive : Galeries basses. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-service-deep | Marche ; f161-e52 |
| Voisin | f161-bishop | Échelle ; f161-e53 |
| Voisin | f161-golic-cache-v94 | Marche ; f161-e97 |
| Voisin | f161-refuge-service-v95 | Marche ; f161-e109 |

### Points · piston a node
ID : `f161-piston-a-node`
[Socle V104 conservé] Position X 4480, pied Y 510, largeur 180. Section descriptive : Fonderie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-leadworks | Marche ; f161-e54 |
| Voisin | f161-mold | Marche ; f161-e55 |

### Points · piston b node
ID : `f161-piston-b-node`
[Socle V104 conservé] Position X 4820, pied Y 330, largeur 180. Section descriptive : Collecteur supérieur. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-sprinkler | Marche ; f161-e56 |
| Voisin | f161-mold | Échelle ; f161-e57 |
| Voisin | f161-steam-lead-node | Marche ; f161-e74 |
| Voisin | f161-perch-lead-v93 | Échelle ; f161-e84 |

### Points · piston c node
ID : `f161-piston-c-node`
[Socle V104 conservé] Position X 5140, pied Y 510, largeur 180. Section descriptive : Moule et pistons. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-mold | Marche ; f161-e58 |
| Voisin | f161-furnace | Marche ; f161-e59 |
| Voisin | f161-shutter-foundry-node | Marche ; f161-e76 |

### Points · patna cage node
ID : `f161-patna-cage-node`
[Socle V104 conservé] Position X 5930, pied Y 510, largeur 160. Section descriptive : Approche et plateforme. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-company | Marche ; f161-e60 |
| Voisin | f161-extraction | Marche ; f161-e61 |

### Points · master archive node
ID : `f161-master-archive-node`
[Socle V104 conservé] Position X 1260, pied Y 350, largeur 170. Section descriptive : Morgue et dossiers. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-morgue-high | Marche ; f161-e62 |

### Points · shutter cell node
ID : `f161-shutter-cell-node`
[Socle V104 conservé] Position X 2740, pied Y 510, largeur 160. Section descriptive : Cellules est. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-cell-b | Marche ; f161-e63 |
| Voisin | f161-comms-high | Échelle ; f161-e64 |

### Points · steam service node
ID : `f161-steam-service-node`
[Socle V104 conservé] Position X 3190, pied Y 330, largeur 160. Section descriptive : Ventilation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-service-high | Marche ; f161-e65 |
| Voisin | f161-fan-shaft | Marche ; f161-e66 |
| Voisin | f161-perch-service-v93 | Échelle ; f161-e79 |

### Points · rescue post node
ID : `f161-rescue-post-node`
[Socle V104 conservé] Position X 3330, pied Y 510, largeur 170. Section descriptive : Pompage et secours. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-service-low | Marche ; f161-e67 |
| Voisin | f161-bishop | Marche ; f161-e68 |
| Voisin | f161-triage-v93 | Marche ; f161-e81 |

### Points · shutter service node
ID : `f161-shutter-service-node`
[Socle V104 conservé] Position X 3650, pied Y 510, largeur 160. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-bishop | Marche ; f161-e69 |
| Voisin | f161-chemical-store | Marche ; f161-e70 |
| Voisin | f161-triage-v93 | Marche ; f161-e82 |
| Voisin | f161-triage-overflow-v95 | Marche ; f161-e113 |

### Points · command post node
ID : `f161-command-post-node`
[Socle V104 conservé] Position X 3960, pied Y 510, largeur 180. Section descriptive : Réserve et supervision. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-tunnel-high | Échelle ; f161-e71 |
| Voisin | f161-leadworks | Marche ; f161-e72 |

### Points · steam lead node
ID : `f161-steam-lead-node`
[Socle V104 conservé] Position X 4710, pied Y 330, largeur 160. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-water-header | Marche ; f161-e73 |
| Voisin | f161-piston-b-node | Marche ; f161-e74 |
| Voisin | f161-perch-lead-v93 | Échelle ; f161-e83 |

### Points · shutter foundry node
ID : `f161-shutter-foundry-node`
[Socle V104 conservé] Position X 5050, pied Y 510, largeur 160. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-mold | Marche ; f161-e75 |
| Voisin | f161-piston-c-node | Marche ; f161-e76 |

### Points · perch cell v93
ID : `f161-perch-cell-v93`
[Socle V104 conservé] Position X 2500, pied Y 190, largeur 170. Section descriptive : Recueillement. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-mess-ceiling | Échelle ; f161-e77 |
| Voisin | f161-comms-high | Échelle ; f161-e78 |
| Voisin | f161-faith-dais-v94 | Marche ; f161-e94 |
| Voisin | f161-watch-cell-v95 | Marche ; f161-e106 |

### Points · perch service v93
ID : `f161-perch-service-v93`
[Socle V104 conservé] Position X 3310, pied Y 190, largeur 170. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-steam-service-node | Échelle ; f161-e79 |
| Voisin | f161-service-high | Échelle ; f161-e80 |

### Points · triage v93
ID : `f161-triage-v93`
[Socle V104 conservé] Position X 3490, pied Y 510, largeur 190. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-rescue-post-node | Marche ; f161-e81 |
| Voisin | f161-shutter-service-node | Marche ; f161-e82 |
| Voisin | f161-triage-overflow-v95 | Marche ; f161-e112 |

### Points · perch lead v93
ID : `f161-perch-lead-v93`
[Socle V104 conservé] Position X 4720, pied Y 190, largeur 170. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-steam-lead-node | Échelle ; f161-e83 |
| Voisin | f161-piston-b-node | Échelle ; f161-e84 |

### Points · parley v93
ID : `f161-parley-v93`
[Socle V104 conservé] Position X 5660, pied Y 510, largeur 180. Section descriptive : Four principal. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-furnace | Marche ; f161-e85 |
| Voisin | f161-company | Marche ; f161-e86 |

### Points · witness v93
ID : `f161-witness-v93`
[Socle V104 conservé] Position X 6030, pied Y 330, largeur 170. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-company | Échelle ; f161-e87 |
| Voisin | f161-extraction | Échelle ; f161-e88 |
| Voisin | f161-final-transmission-v94 | Marche ; f161-e103 |
| Voisin | f161-archive-checksum-v95 | Échelle ; f161-e120 |

### Points · flight analysis v94
ID : `f161-flight-analysis-v94`
[Socle V104 conservé] Position X 780, pied Y 330, largeur 220. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-eev | Échelle ; f161-e89 |
| Voisin | f161-morgue-high | Marche ; f161-e90 |

### Points · wreckage incident v94
ID : `f161-wreckage-incident-v94`
[Socle V104 conservé] Position X 820, pied Y 630, largeur 220. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-eev | Échelle ; f161-e91 |
| Voisin | f161-infirmary | Échelle ; f161-e92 |

### Points · faith dais v94
ID : `f161-faith-dais-v94`
[Socle V104 conservé] Position X 2180, pied Y 190, largeur 250. Section descriptive : Recueillement. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-mess-high | Échelle ; f161-e93 |
| Voisin | f161-perch-cell-v93 | Marche ; f161-e94 |

### Points · battery locker v94
ID : `f161-battery-locker-v94`
[Socle V104 conservé] Position X 3500, pied Y 330, largeur 250. Section descriptive : Atelier des batteries. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-service-high | Marche ; f161-e95 |
| Voisin | f161-tunnel-high | Marche ; f161-e96 |
| Voisin | f161-hunt-service-v95 | Marche ; f161-e111 |

### Points · golic cache v94
ID : `f161-golic-cache-v94`
[Socle V104 conservé] Position X 3660, pied Y 630, largeur 230. Section descriptive : Galeries basses. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-tunnel-shrine | Marche ; f161-e97 |
| Voisin | f161-tunnel-low | Marche ; f161-e98 |

### Points · battery junction v94
ID : `f161-battery-junction-v94`
[Socle V104 conservé] Position X 4020, pied Y 330, largeur 250. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-tunnel-high | Marche ; f161-e99 |
| Voisin | f161-water-header | Marche ; f161-e100 |
| Voisin | f161-bait-switch-v95 | Marche ; f161-e116 |

### Points · chase reroute v94
ID : `f161-chase-reroute-v94`
[Socle V104 conservé] Position X 5050, pied Y 630, largeur 250. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-mold | Échelle ; f161-e101 |
| Voisin | f161-furnace | Échelle ; f161-e102 |
| Voisin | f161-pressure-alcove-v95 | Marche ; f161-e118 |

### Points · final transmission v94
ID : `f161-final-transmission-v94`
[Socle V104 conservé] Position X 6100, pied Y 330, largeur 190. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-witness-v93 | Marche ; f161-e103 |

### Points · shelter cell v95
ID : `f161-shelter-cell-v95`
[Socle V104 conservé] Position X 2050, pied Y 630, largeur 220. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-cell-a | Échelle ; f161-e104 |
| Voisin | f161-assembly-hall | Échelle ; f161-e105 |

### Points · watch cell v95
ID : `f161-watch-cell-v95`
[Socle V104 conservé] Position X 2660, pied Y 190, largeur 190. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-perch-cell-v93 | Marche ; f161-e106 |
| Voisin | f161-comms-high | Échelle ; f161-e107 |

### Points · refuge service v95
ID : `f161-refuge-service-v95`
[Socle V104 conservé] Position X 2990, pied Y 630, largeur 230. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-service-deep | Marche ; f161-e108 |
| Voisin | f161-tunnel-shrine | Marche ; f161-e109 |

### Points · hunt service v95
ID : `f161-hunt-service-v95`
[Socle V104 conservé] Position X 3370, pied Y 330, largeur 210. Section descriptive : Atelier des batteries. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-service-high | Marche ; f161-e110 |
| Voisin | f161-battery-locker-v94 | Marche ; f161-e111 |

### Points · triage overflow v95
ID : `f161-triage-overflow-v95`
[Socle V104 conservé] Position X 3600, pied Y 510, largeur 220. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-triage-v93 | Marche ; f161-e112 |
| Voisin | f161-shutter-service-node | Marche ; f161-e113 |

### Points · hunt junction v95
ID : `f161-hunt-junction-v95`
[Socle V104 conservé] Position X 3900, pied Y 630, largeur 210. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-tunnel-low | Marche ; f161-e114 |
| Voisin | f161-waste-tank | Marche ; f161-e115 |

### Points · bait switch v95
ID : `f161-bait-switch-v95`
[Socle V104 conservé] Position X 4320, pied Y 330, largeur 210. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-battery-junction-v94 | Marche ; f161-e116 |
| Voisin | f161-sprinkler | Marche ; f161-e117 |

### Points · pressure alcove v95
ID : `f161-pressure-alcove-v95`
[Socle V104 conservé] Position X 4780, pied Y 630, largeur 220. Section descriptive : Cuve et évacuation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-chase-reroute-v94 | Marche ; f161-e118 |

### Points · chase observer v95
ID : `f161-chase-observer-v95`
[Socle V104 conservé] Position X 5280, pied Y 330, largeur 210. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-furnace-high | Marche ; f161-e119 |

### Points · archive checksum v95
ID : `f161-archive-checksum-v95`
[Socle V104 conservé] Position X 5960, pied Y 190, largeur 190. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Détail |
|---|---|---|
| Voisin | f161-witness-v93 | Échelle ; f161-e120 |

### Connexions · Marche — f161-e01
ID : `f161-e01`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-spawn | (180, 510) |
| Arrivée | f161-eev | (620, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e02
ID : `f161-e02`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-eev | (620, 510) |
| Arrivée | f161-infirmary | (1120, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Porte — f161-e03
ID : `f161-e03`
[Socle V104 conservé] Porte entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-infirmary | (1120, 510) |
| Arrivée | f161-cell-a | (1900, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Porte — f161-e05
ID : `f161-e05`
[Socle V104 conservé] Porte entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-cell-b | (2620, 510) |
| Arrivée | f161-service-low | (3070, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e06
ID : `f161-e06`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-service-low | (3070, 510) |
| Arrivée | f161-bishop | (3500, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Porte — f161-e07
ID : `f161-e07`
[Socle V104 conservé] Porte entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-bishop | (3500, 510) |
| Arrivée | f161-leadworks | (4200, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e08
ID : `f161-e08`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-leadworks | (4200, 510) |
| Arrivée | f161-mold | (4920, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e09
ID : `f161-e09`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-mold | (4920, 510) |
| Arrivée | f161-furnace | (5480, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e10
ID : `f161-e10`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-furnace | (5480, 510) |
| Arrivée | f161-company | (5800, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e11
ID : `f161-e11`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-company | (5800, 510) |
| Arrivée | f161-extraction | (6040, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e12
ID : `f161-e12`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-infirmary | (1120, 510) |
| Arrivée | f161-morgue-high | (1500, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e13
ID : `f161-e13`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-morgue-high | (1500, 350) |
| Arrivée | f161-mess-high | (2320, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e14
ID : `f161-e14`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé -20. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-mess-high | (2320, 350) |
| Arrivée | f161-service-high | (3070, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e15
ID : `f161-e15`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-service-high | (3070, 330) |
| Arrivée | f161-tunnel-high | (3820, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e16
ID : `f161-e16`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-tunnel-high | (3820, 330) |
| Arrivée | f161-sprinkler | (4560, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e17
ID : `f161-e17`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-sprinkler | (4560, 330) |
| Arrivée | f161-furnace-high | (5350, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e18
ID : `f161-e18`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-furnace-high | (5350, 330) |
| Arrivée | f161-furnace | (5480, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Conduit — f161-e19
ID : `f161-e19`
[Socle V104 conservé] Conduit entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-infirmary | (1120, 510) |
| Arrivée | f161-service-deep | (3070, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e20
ID : `f161-e20`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-service-deep | (3070, 630) |
| Arrivée | f161-tunnel-low | (3820, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e21
ID : `f161-e21`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-tunnel-low | (3820, 630) |
| Arrivée | f161-leadworks | (4200, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Conduit — f161-e22
ID : `f161-e22`
[Socle V104 conservé] Conduit entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-leadworks | (4200, 510) |
| Arrivée | f161-furnace | (5480, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e23
ID : `f161-e23`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-cell-a | (1900, 510) |
| Arrivée | f161-mess-high | (2320, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e24
ID : `f161-e24`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-service-low | (3070, 510) |
| Arrivée | f161-service-high | (3070, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e25
ID : `f161-e25`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-service-low | (3070, 510) |
| Arrivée | f161-service-deep | (3070, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e26
ID : `f161-e26`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-leadworks | (4200, 510) |
| Arrivée | f161-sprinkler | (4560, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e27
ID : `f161-e27`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-cell-a | (1900, 510) |
| Arrivée | f161-assembly-hall | (2300, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e28
ID : `f161-e28`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-assembly-hall | (2300, 510) |
| Arrivée | f161-cell-b | (2620, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e29
ID : `f161-e29`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-assembly-hall | (2300, 510) |
| Arrivée | f161-mess-high | (2320, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e30
ID : `f161-e30`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-tunnel-low | (3820, 630) |
| Arrivée | f161-waste-tank | (4070, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e31
ID : `f161-e31`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-waste-tank | (4070, 630) |
| Arrivée | f161-sluice-low | (4500, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e32
ID : `f161-e32`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-sluice-low | (4500, 630) |
| Arrivée | f161-leadworks | (4200, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e33
ID : `f161-e33`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-furnace-high | (5350, 330) |
| Arrivée | f161-furnace-gantry | (5740, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e34
ID : `f161-e34`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-furnace-gantry | (5740, 330) |
| Arrivée | f161-company | (5800, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e35
ID : `f161-e35`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-service-low | (3070, 510) |
| Arrivée | f161-fuel-manifold-a | (2960, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e36
ID : `f161-e36`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-fuel-manifold-a | (2960, 510) |
| Arrivée | f161-fuel-manifold-b | (3240, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e37
ID : `f161-e37`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-fuel-manifold-b | (3240, 510) |
| Arrivée | f161-bishop | (3500, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e38
ID : `f161-e38`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-bishop | (3500, 510) |
| Arrivée | f161-chemical-store | (3670, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e39
ID : `f161-e39`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-chemical-store | (3670, 510) |
| Arrivée | f161-tunnel-high | (3820, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e40
ID : `f161-e40`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-leadworks | (4200, 510) |
| Arrivée | f161-lead-primer | (4380, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e41
ID : `f161-e41`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-lead-primer | (4380, 510) |
| Arrivée | f161-mold | (4920, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e42
ID : `f161-e42`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-sprinkler | (4560, 330) |
| Arrivée | f161-water-header | (4690, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e43
ID : `f161-e43`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-water-header | (4690, 330) |
| Arrivée | f161-mold | (4920, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e44
ID : `f161-e44`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-furnace-high | (5350, 330) |
| Arrivée | f161-furnace-overlook | (5580, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e45
ID : `f161-e45`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-furnace-overlook | (5580, 330) |
| Arrivée | f161-company | (5800, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e46
ID : `f161-e46`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-infirmary | (1120, 510) |
| Arrivée | f161-clemens-bed | (1380, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e47
ID : `f161-e47`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-clemens-bed | (1380, 510) |
| Arrivée | f161-funeral-walk | (1580, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e48
ID : `f161-e48`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-funeral-walk | (1580, 510) |
| Arrivée | f161-morgue-high | (1500, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e49
ID : `f161-e49`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-mess-high | (2320, 350) |
| Arrivée | f161-mess-ceiling | (2470, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e50
ID : `f161-e50`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-mess-ceiling | (2470, 350) |
| Arrivée | f161-comms-high | (2720, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e51
ID : `f161-e51`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-service-high | (3070, 330) |
| Arrivée | f161-fan-shaft | (2940, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e52
ID : `f161-e52`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-service-deep | (3070, 630) |
| Arrivée | f161-tunnel-shrine | (3420, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e53
ID : `f161-e53`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-tunnel-shrine | (3420, 630) |
| Arrivée | f161-bishop | (3500, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e54
ID : `f161-e54`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-leadworks | (4200, 510) |
| Arrivée | f161-piston-a-node | (4480, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e55
ID : `f161-e55`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-piston-a-node | (4480, 510) |
| Arrivée | f161-mold | (4920, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e56
ID : `f161-e56`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-sprinkler | (4560, 330) |
| Arrivée | f161-piston-b-node | (4820, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e57
ID : `f161-e57`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-piston-b-node | (4820, 330) |
| Arrivée | f161-mold | (4920, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e58
ID : `f161-e58`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-mold | (4920, 510) |
| Arrivée | f161-piston-c-node | (5140, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e59
ID : `f161-e59`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-piston-c-node | (5140, 510) |
| Arrivée | f161-furnace | (5480, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e60
ID : `f161-e60`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-company | (5800, 510) |
| Arrivée | f161-patna-cage-node | (5930, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e61
ID : `f161-e61`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-patna-cage-node | (5930, 510) |
| Arrivée | f161-extraction | (6040, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e62
ID : `f161-e62`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-morgue-high | (1500, 350) |
| Arrivée | f161-master-archive-node | (1260, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e63
ID : `f161-e63`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-cell-b | (2620, 510) |
| Arrivée | f161-shutter-cell-node | (2740, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e64
ID : `f161-e64`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-shutter-cell-node | (2740, 510) |
| Arrivée | f161-comms-high | (2720, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e65
ID : `f161-e65`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-service-high | (3070, 330) |
| Arrivée | f161-steam-service-node | (3190, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e66
ID : `f161-e66`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-steam-service-node | (3190, 330) |
| Arrivée | f161-fan-shaft | (2940, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e67
ID : `f161-e67`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-service-low | (3070, 510) |
| Arrivée | f161-rescue-post-node | (3330, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e68
ID : `f161-e68`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-rescue-post-node | (3330, 510) |
| Arrivée | f161-bishop | (3500, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e69
ID : `f161-e69`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-bishop | (3500, 510) |
| Arrivée | f161-shutter-service-node | (3650, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e70
ID : `f161-e70`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-shutter-service-node | (3650, 510) |
| Arrivée | f161-chemical-store | (3670, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e71
ID : `f161-e71`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-tunnel-high | (3820, 330) |
| Arrivée | f161-command-post-node | (3960, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e72
ID : `f161-e72`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-command-post-node | (3960, 510) |
| Arrivée | f161-leadworks | (4200, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e73
ID : `f161-e73`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-water-header | (4690, 330) |
| Arrivée | f161-steam-lead-node | (4710, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e74
ID : `f161-e74`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-steam-lead-node | (4710, 330) |
| Arrivée | f161-piston-b-node | (4820, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e75
ID : `f161-e75`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-mold | (4920, 510) |
| Arrivée | f161-shutter-foundry-node | (5050, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e76
ID : `f161-e76`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-shutter-foundry-node | (5050, 510) |
| Arrivée | f161-piston-c-node | (5140, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e77
ID : `f161-e77`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-mess-ceiling | (2470, 350) |
| Arrivée | f161-perch-cell-v93 | (2500, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e78
ID : `f161-e78`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-perch-cell-v93 | (2500, 190) |
| Arrivée | f161-comms-high | (2720, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e79
ID : `f161-e79`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-steam-service-node | (3190, 330) |
| Arrivée | f161-perch-service-v93 | (3310, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e80
ID : `f161-e80`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-perch-service-v93 | (3310, 190) |
| Arrivée | f161-service-high | (3070, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e81
ID : `f161-e81`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-rescue-post-node | (3330, 510) |
| Arrivée | f161-triage-v93 | (3490, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e82
ID : `f161-e82`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-triage-v93 | (3490, 510) |
| Arrivée | f161-shutter-service-node | (3650, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e83
ID : `f161-e83`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-steam-lead-node | (4710, 330) |
| Arrivée | f161-perch-lead-v93 | (4720, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e84
ID : `f161-e84`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-perch-lead-v93 | (4720, 190) |
| Arrivée | f161-piston-b-node | (4820, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e85
ID : `f161-e85`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-furnace | (5480, 510) |
| Arrivée | f161-parley-v93 | (5660, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e86
ID : `f161-e86`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-parley-v93 | (5660, 510) |
| Arrivée | f161-company | (5800, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e87
ID : `f161-e87`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-company | (5800, 510) |
| Arrivée | f161-witness-v93 | (6030, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e88
ID : `f161-e88`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-witness-v93 | (6030, 330) |
| Arrivée | f161-extraction | (6040, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e89
ID : `f161-e89`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-eev | (620, 510) |
| Arrivée | f161-flight-analysis-v94 | (780, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e90
ID : `f161-e90`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 20. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-flight-analysis-v94 | (780, 330) |
| Arrivée | f161-morgue-high | (1500, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e91
ID : `f161-e91`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-eev | (620, 510) |
| Arrivée | f161-wreckage-incident-v94 | (820, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e92
ID : `f161-e92`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-wreckage-incident-v94 | (820, 630) |
| Arrivée | f161-infirmary | (1120, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e93
ID : `f161-e93`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-mess-high | (2320, 350) |
| Arrivée | f161-faith-dais-v94 | (2180, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e94
ID : `f161-e94`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-faith-dais-v94 | (2180, 190) |
| Arrivée | f161-perch-cell-v93 | (2500, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e95
ID : `f161-e95`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-service-high | (3070, 330) |
| Arrivée | f161-battery-locker-v94 | (3500, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e96
ID : `f161-e96`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-battery-locker-v94 | (3500, 330) |
| Arrivée | f161-tunnel-high | (3820, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e97
ID : `f161-e97`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-tunnel-shrine | (3420, 630) |
| Arrivée | f161-golic-cache-v94 | (3660, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e98
ID : `f161-e98`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-golic-cache-v94 | (3660, 630) |
| Arrivée | f161-tunnel-low | (3820, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e99
ID : `f161-e99`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-tunnel-high | (3820, 330) |
| Arrivée | f161-battery-junction-v94 | (4020, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e100
ID : `f161-e100`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-battery-junction-v94 | (4020, 330) |
| Arrivée | f161-water-header | (4690, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e101
ID : `f161-e101`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-mold | (4920, 510) |
| Arrivée | f161-chase-reroute-v94 | (5050, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e102
ID : `f161-e102`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-chase-reroute-v94 | (5050, 630) |
| Arrivée | f161-furnace | (5480, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e103
ID : `f161-e103`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-witness-v93 | (6030, 330) |
| Arrivée | f161-final-transmission-v94 | (6100, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e104
ID : `f161-e104`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-cell-a | (1900, 510) |
| Arrivée | f161-shelter-cell-v95 | (2050, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e105
ID : `f161-e105`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-shelter-cell-v95 | (2050, 630) |
| Arrivée | f161-assembly-hall | (2300, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e106
ID : `f161-e106`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-perch-cell-v93 | (2500, 190) |
| Arrivée | f161-watch-cell-v95 | (2660, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e107
ID : `f161-e107`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-watch-cell-v95 | (2660, 190) |
| Arrivée | f161-comms-high | (2720, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e108
ID : `f161-e108`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-service-deep | (3070, 630) |
| Arrivée | f161-refuge-service-v95 | (2990, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e109
ID : `f161-e109`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-refuge-service-v95 | (2990, 630) |
| Arrivée | f161-tunnel-shrine | (3420, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e110
ID : `f161-e110`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-service-high | (3070, 330) |
| Arrivée | f161-hunt-service-v95 | (3370, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e111
ID : `f161-e111`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-hunt-service-v95 | (3370, 330) |
| Arrivée | f161-battery-locker-v94 | (3500, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e112
ID : `f161-e112`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-triage-v93 | (3490, 510) |
| Arrivée | f161-triage-overflow-v95 | (3600, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e113
ID : `f161-e113`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-triage-overflow-v95 | (3600, 510) |
| Arrivée | f161-shutter-service-node | (3650, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e114
ID : `f161-e114`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-tunnel-low | (3820, 630) |
| Arrivée | f161-hunt-junction-v95 | (3900, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e115
ID : `f161-e115`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-hunt-junction-v95 | (3900, 630) |
| Arrivée | f161-waste-tank | (4070, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e116
ID : `f161-e116`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-battery-junction-v94 | (4020, 330) |
| Arrivée | f161-bait-switch-v95 | (4320, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e117
ID : `f161-e117`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-bait-switch-v95 | (4320, 330) |
| Arrivée | f161-sprinkler | (4560, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e118
ID : `f161-e118`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-chase-reroute-v94 | (5050, 630) |
| Arrivée | f161-pressure-alcove-v95 | (4780, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Marche — f161-e119
ID : `f161-e119`
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-furnace-high | (5350, 330) |
| Arrivée | f161-chase-observer-v95 | (5280, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Connexions · Échelle — f161-e120
ID : `f161-e120`
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Détail |
|---|---|---|
| Départ | f161-witness-v93 | (6030, 330) |
| Arrivée | f161-archive-checksum-v95 | (5960, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Règles · A3-ANCHOR
ID : `A3-ANCHOR`
[Socle V104 conservé] Tout décor a un support nommé ; coordonnées indépendantes du joueur.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-FINITE
ID : `A3-FINITE`
[Socle V104 conservé] Positions et dimensions finies et positives.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-ID
ID : `A3-ID`
[Socle V104 conservé] Identifiants uniques, parents existants.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-FOOT
ID : `A3-FOOT`
[Socle V104 conservé] Les meubles reposent sur le plan de pose ; pas sur la caméra.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-BOUND
ID : `A3-BOUND`
[Socle V104 conservé] Les éléments restent dans la baie de leur assemblage.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-NO_FAKE_COVER
ID : `A3-NO_FAKE_COVER`
[Socle V104 conservé] Décor d’arrière-plan non collidable et explicitement sans couverture.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-CONDITION
ID : `A3-CONDITION`
[Socle V104 conservé] Le matériel de récupération dépend de l’arrivée de la Compagnie.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-ROUTE
ID : `A3-ROUTE`
[Socle V104 conservé] Aucun nœud, verrou ou ordre de mission ajouté pour justifier le décor.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-DRAW_PURE
ID : `A3-DRAW_PURE`
[Socle V104 conservé] Le rendu ne change ni progression ni sauvegarde.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-TOP
ID : `A3-TOP`
[Socle V104 conservé] Fond opaque depuis le premier pixel du champ, quelle que soit la caméra.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | browser | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-HUD
ID : `A3-HUD`
[Socle V104 conservé] Les panneaux ordinaires couvrent moins de 9 % de l’écran.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-READ
ID : `A3-READ`
[Socle V104 conservé] Les premiers plans s’effacent à proximité des silhouettes.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-PARALLAX
ID : `A3-PARALLAX`
[Socle V104 conservé] Les machines proches suivent le monde ; seule l’architecture distante dérive.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | browser | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-LUX
ID : `A3-LUX`
[Socle V104 conservé] Une lumière forte a une source dessinée.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | visual | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-RHYTHM
ID : `A3-RHYTHM`
[Socle V104 conservé] Alcôves équipées puis respirations, sans tapis uniforme de petits objets.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | visual | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-IDENTITY
ID : `A3-IDENTITY`
[Socle V104 conservé] Une forme identifiable remplace chaque bloc générique.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | visual | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-FILM
ID : `A3-FILM`
[Socle V104 conservé] Plans et dimensions de jeu : adaptation, pas relevé certifié des plateaux.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | disclosure | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-ROOMS
ID : `A3-ROOMS`
[Socle V104 conservé] La pièce, son étage et ses voisins priment sur les limites de caméra.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | disclosure | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-103-SPACE
ID : `A3-103-SPACE`
[Socle V104 conservé] Une section décrit un lieu et un étage ; elle ne crée pas une nouvelle salle instanciée.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | scope | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-103-PORTAL
ID : `A3-103-PORTAL`
[Socle V104 conservé] Un cadre de porte provient d’une arête gate/airlock ; la feuille et la collision restent pilotées par la porte native.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-103-GATE-GEOMETRY
ID : `A3-103-GATE-GEOMETRY`
[Socle V104 conservé] Une porte fournie par le plan compilé est utilisée sans déplacer sa collision.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-103-VERTICAL-PRIORITY
ID : `A3-103-VERTICAL-PRIORITY`
[Socle V104 conservé] Haut/Bas donnent la priorité à une échelle réellement atteignable, avant un changement de profondeur.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-103-CIRCUIT
ID : `A3-103-CIRCUIT`
[Socle V104 conservé] Un réseau décoratif possède une source et un récepteur du même ensemble, reliés par un tracé continu.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-103-LIGHT
ID : `A3-103-LIGHT`
[Socle V104 conservé] Couper un éclairage de service ne coupe ni le feu du four, ni l’eau du piège, ni un objectif.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-103-REACH
ID : `A3-103-REACH`
[Socle V104 conservé] Une commande exige proximité, niveau, plan médian, personnage vivant et absence de porte fermée entre les deux.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-103-PAUSE
ID : `A3-103-PAUSE`
[Socle V104 conservé] Le plan et les archives arrêtent la simulation ; la fermeture ne supprime pas une pause préexistante.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-103-MAP
ID : `A3-103-MAP`
[Socle V104 conservé] Le plan ne montre ni ennemis ni dossiers secrets ; un nœud n’est relevé qu’au voisinage du personnage.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-103-PERSIST
ID : `A3-103-PERSIST`
[Socle V104 conservé] Les visites et les éclairages sont sauvegardés ; ni la géométrie ni l’ouverture du plan ne sont sérialisées.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-103-REDUCED-MOTION
ID : `A3-103-REDUCED-MOTION`
[Socle V104 conservé] Le mouvement réduit conserve les états lisibles sans animation de panneaux.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · A3-103-PROVENANCE
ID : `A3-103-PROVENANCE`
[Socle V104 conservé] Banc visuel et tests isolés ne constituent pas une validation de la campagne complète.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | scope | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC01
ID : `SC01`
[Socle V104 conservé] Une scène compilée fournit les appuis, les commandes, les portes et le plan.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | data | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC02
ID : `SC02`
[Socle V104 conservé] Une coordonnée monde n’est pas retraitée comme une coordonnée écran.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | data | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC03
ID : `SC03`
[Socle V104 conservé] Le fond couvre le premier pixel ; les particules restent dans leur alcôve.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | browser | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC04
ID : `SC04`
[Socle V104 conservé] Un saut conserve le nom du lieu jusqu’à la réception.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC05
ID : `SC05`
[Socle V104 conservé] Un contact exige proximité, hauteur, profondeur et absence de porte fermée.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC06
ID : `SC06`
[Socle V104 conservé] Les états visuels sont issus des événements, jamais de l’abscisse du joueur.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC07
ID : `SC07`
[Socle V104 conservé] Le feu, les dépôts de suie, le plomb chaud et le refroidissement restent distincts.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | data | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC08
ID : `SC08`
[Socle V104 conservé] La Compagnie ne se dessine pas avant son arrivée.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC09
ID : `SC09`
[Socle V104 conservé] Le HUD normal est temporaire ; les vitales restent visibles en danger.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | browser | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC10
ID : `SC10`
[Socle V104 conservé] Le plan et les archives suspendent l’horloge de cette couche.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC11
ID : `SC11`
[Socle V104 conservé] La sauvegarde valide identité et géométrie avant de remplacer l’état.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC12
ID : `SC12`
[Socle V104 conservé] Un fichier refusé ne détruit ni la partie courante ni sa reprise.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | browser | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC13
ID : `SC13`
[Socle V104 conservé] Les phases d’attaque, touches et fenêtres ouvertes ne sont pas rejouées à l’import.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | data | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC14
ID : `SC14`
[Socle V104 conservé] La ronde originale doit être terminée au clavier sans positions injectées.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | browser | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC15
ID : `SC15`
[Socle V104 conservé] Un mécanisme local d’éclairage ne termine pas une mission du film.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC16
ID : `SC16`
[Socle V104 conservé] Les captures sont natives du renderer partagé, pas une reconstitution après coup.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | evidence | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC17
ID : `SC17`
[Socle V104 conservé] Les tests préparés, la ronde et le moteur complet ont des preuves distinctes.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | scope | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Règles · SC18
ID : `SC18`
[Socle V104 conservé] Les options de mouvement et de lisibilité n’altèrent pas la progression.

| Élément | Référence | Détail |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### États du décor · Départ du feu
ID : `outbreak`
[Socle V104 conservé] Flamme locale et fumée, sans nouveaux dégâts. La consultation ou le dessin seul ne déclenche pas la transition historique.

| Élément | Référence | Détail |
|---|---|---|
| État source | alien3V90.firePlan.ignited et non accidentResolved ; repli fireMazeIgnited | Les booléens explicites priment sur les raccourcis de phase. |
| Ensemble | service-pump | Pompage des galeries |
| Ensemble | chemical-store | Réserve de produits |

### États du décor · Après l’incendie
ID : `aftermath`
[Socle V104 conservé] Suie conservée après extinction ; aucune flamme ajoutée. La consultation ou le dessin seul ne déclenche pas la transition historique.

| Élément | Référence | Détail |
|---|---|---|
| État source | Feu observé ou firePlan.accidentResolved | Les booléens explicites priment sur les raccourcis de phase. |
| Ensemble | service-pump | Pompage des galeries |
| Ensemble | chemical-store | Réserve de produits |

### États du décor · Coulée
ID : `molten`
[Socle V104 conservé] Lueur chaude aux récepteurs industriels. La consultation ou le dessin seul ne déclenche pas la transition historique.

| Élément | Référence | Détail |
|---|---|---|
| État source | alien3V88.moltenLeadApplied ; repli de phase uniquement si absent | Les booléens explicites priment sur les raccourcis de phase. |
| Ensemble | leadworks | Creuset et transfert |
| Ensemble | lead-primer | Alimentation du creuset |
| Ensemble | mold | Moule de coulée |

### États du décor · Refroidissement
ID : `cooling`
[Socle V104 conservé] Vapeur localisée ; pas de changement du débit ou de la victoire. La consultation ou le dessin seul ne déclenche pas la transition historique.

| Élément | Référence | Détail |
|---|---|---|
| État source | alien3V88.thermalShockApplied ; repli de phase uniquement si absent | Les booléens explicites priment sur les raccourcis de phase. |
| Ensemble | mold | Moule de coulée |
| Ensemble | water-header | Collecteur d’eau supérieur |

### États du décor · Récupération
ID : `recovery`
[Socle V104 conservé] Matériel existant de la Compagnie visible. La consultation ou le dessin seul ne déclenche pas la transition historique.

| Élément | Référence | Détail |
|---|---|---|
| État source | alien3V89.company.visible === true ou phase company/finale | Les booléens explicites priment sur les raccourcis de phase. |
| Ensemble | patna-kit | Matériel de récupération |

### Ronde originale · 1. Rétablir la lampe de soin.
ID : `round-1`
[Socle V104 conservé] Parcours optionnel de l’aperçu, activé explicitement depuis son bouton. Il n’est pas injecté automatiquement dans la campagne Alien 3. Les trois circuits sont éteints au lancement de ce parcours ; aucune réserve du film n’est donnée. Une importation valide reprend en pause, sans sauter une étape.

| Élément | Référence | Détail |
|---|---|---|
| Cible | care-light | Appui réel au bon étage |
| Action | I : rallumer | Une étape hors ordre ne se valide pas. |

### Ronde originale · 2. Rétablir l’éclairage des cellules ouest.
ID : `round-2`
[Socle V104 conservé] Parcours optionnel de l’aperçu, activé explicitement depuis son bouton. Il n’est pas injecté automatiquement dans la campagne Alien 3. Les trois circuits sont éteints au lancement de ce parcours ; aucune réserve du film n’est donnée. Une importation valide reprend en pause, sans sauter une étape.

| Élément | Référence | Détail |
|---|---|---|
| Cible | cell-light | Appui réel au bon étage |
| Action | I : rallumer | Une étape hors ordre ne se valide pas. |

### Ronde originale · 3. Monter à l’atelier et rétablir sa lampe.
ID : `round-3`
[Socle V104 conservé] Parcours optionnel de l’aperçu, activé explicitement depuis son bouton. Il n’est pas injecté automatiquement dans la campagne Alien 3. Les trois circuits sont éteints au lancement de ce parcours ; aucune réserve du film n’est donnée. Une importation valide reprend en pause, sans sauter une étape.

| Élément | Référence | Détail |
|---|---|---|
| Cible | service-light | Appui réel au bon étage |
| Action | I : rallumer | Une étape hors ordre ne se valide pas. |

### Ronde originale · 4. Revenir dans la salle commune.
ID : `round-4`
[Socle V104 conservé] Parcours optionnel de l’aperçu, activé explicitement depuis son bouton. Il n’est pas injecté automatiquement dans la campagne Alien 3. Les trois circuits sont éteints au lancement de ce parcours ; aucune réserve du film n’est donnée. Une importation valide reprend en pause, sans sauter une étape.

| Élément | Référence | Détail |
|---|---|---|
| Cible | f161-assembly-hall | Appui réel au bon étage |
| Action | Rejoindre le point de retour | Une étape hors ordre ne se valide pas. |

### Parcours V105 · Un bruit dans les galeries
ID : `encounter-traque`
Séquence originale activée explicitement dans le banc ; elle ne termine pas automatiquement une mission de la campagne historique. Aucun équipement militaire ajouté. Aaron appartient au parcours antérieur, pas à la fonderie.

| Élément | Référence | Détail |
|---|---|---|
| Joueur | f161-infirmary | Départ de la séquence |
| Runner | f161-cell-b | Un objet acteur conservé |
| Étape 1 | objective-traque-0 | Parler à Aaron près de l’infirmerie. |
| Étape 2 | objective-traque-1 | Monter à l’atelier et prendre le relevé de service. |
| Étape 3 | objective-traque-2 | Rapporter le relevé à Aaron. |

### Étapes V105 · Parler à Aaron près de l’infirmerie.
ID : `objective-traque-0`
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Détail |
|---|---|---|
| Séquence | encounter-traque | Un bruit dans les galeries |
| Ordre | 1 | Une action hors ordre ne donne aucun état final. |

### Étapes V105 · Monter à l’atelier et prendre le relevé de service.
ID : `objective-traque-1`
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Détail |
|---|---|---|
| Séquence | encounter-traque | Un bruit dans les galeries |
| Ordre | 2 | Une action hors ordre ne donne aucun état final. |

### Étapes V105 · Rapporter le relevé à Aaron.
ID : `objective-traque-2`
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Détail |
|---|---|---|
| Séquence | encounter-traque | Un bruit dans les galeries |
| Ordre | 3 | Une action hors ordre ne donne aucun état final. |

### Parcours V105 · Le dernier rabattage
ID : `encounter-rabattage`
Séquence originale activée explicitement dans le banc ; elle ne termine pas automatiquement une mission de la campagne historique. Aucun équipement militaire ajouté. Aaron appartient au parcours antérieur, pas à la fonderie.

| Élément | Référence | Détail |
|---|---|---|
| Joueur | f161-command-post-node | Départ de la séquence |
| Runner | f161-furnace | Un objet acteur conservé |
| Étape 1 | objective-rabattage-0 | Donner le signal à Dillon au poste de commande. |
| Étape 2 | objective-rabattage-1 | Amorcer le réseau d’eau, sur la coursive haute. |
| Étape 3 | objective-rabattage-2 | Attendre Morse et Dillon, puis armer le piège au moule. |
| Étape 4 | objective-rabattage-3 | Attirer le Runner dans le moule ; rejoindre Dillon et lancer la coulée. |
| Étape 5 | objective-rabattage-4 | Remonter au collecteur pour libérer l’eau. |
| Étape 6 | objective-rabattage-5 | Rejoindre Morse près de la salle de coulée. |

### Étapes V105 · Donner le signal à Dillon au poste de commande.
ID : `objective-rabattage-0`
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Détail |
|---|---|---|
| Séquence | encounter-rabattage | Le dernier rabattage |
| Ordre | 1 | Une action hors ordre ne donne aucun état final. |

### Étapes V105 · Amorcer le réseau d’eau, sur la coursive haute.
ID : `objective-rabattage-1`
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Détail |
|---|---|---|
| Séquence | encounter-rabattage | Le dernier rabattage |
| Ordre | 2 | Une action hors ordre ne donne aucun état final. |

### Étapes V105 · Attendre Morse et Dillon, puis armer le piège au moule.
ID : `objective-rabattage-2`
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Détail |
|---|---|---|
| Séquence | encounter-rabattage | Le dernier rabattage |
| Ordre | 3 | Une action hors ordre ne donne aucun état final. |

### Étapes V105 · Attirer le Runner dans le moule ; rejoindre Dillon et lancer la coulée.
ID : `objective-rabattage-3`
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Détail |
|---|---|---|
| Séquence | encounter-rabattage | Le dernier rabattage |
| Ordre | 4 | Une action hors ordre ne donne aucun état final. |

### Étapes V105 · Remonter au collecteur pour libérer l’eau.
ID : `objective-rabattage-4`
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Détail |
|---|---|---|
| Séquence | encounter-rabattage | Le dernier rabattage |
| Ordre | 5 | Une action hors ordre ne donne aucun état final. |

### Étapes V105 · Rejoindre Morse près de la salle de coulée.
ID : `objective-rabattage-5`
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Détail |
|---|---|---|
| Séquence | encounter-rabattage | Le dernier rabattage |
| Ordre | 6 | Une action hors ordre ne donne aucun état final. |

### Postes V105 · Aaron
ID : `station-aaron`
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-clemens-bed | X 1380, sol 510 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Postes V105 · Relevé de service
ID : `station-report`
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-service-high | X 3070, sol 330 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Postes V105 · Dillon
ID : `station-brief`
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-command-post-node | X 3960, sol 510 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Postes V105 · Vanne du collecteur
ID : `station-water`
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-water-header | X 4690, sol 330 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Postes V105 · Commande du moule
ID : `station-mold`
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-mold | X 4920, sol 510 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Postes V105 · Commande de coulée
ID : `station-pour`
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-piston-c-node | X 5140, sol 510 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Postes V105 · Morse
ID : `station-return`
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105.

| Élément | Référence | Détail |
|---|---|---|
| Appui | f161-lead-primer | X 4380, sol 510 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Participants V105 · Aaron
ID : `participant-aaron`
Donne la consigne et reçoit le relevé. Aucun déplacement ni réapparition dans le final. Les corps sont des silhouettes vectorielles stylisées. Ce test n’est pas la mort filmée de Dillon ni la fin complète du film.

| Élément | Référence | Détail |
|---|---|---|
| Point de présence | f161-clemens-bed | Position physique vérifiée, vivant et trajet terminé |
| Séquence | encounter-traque | Présence limitée à son parcours |
| Navigation | Graphe commun | Même portes et appuis que la menace |

### Participants V105 · Morse
ID : `participant-morse`
Part près de Bishop et rejoint le poste de coulée après le signal. Une porte fermée le fait attendre ; un simple drapeau d’arrivée ne suffit pas. Les corps sont des silhouettes vectorielles stylisées. Ce test n’est pas la mort filmée de Dillon ni la fin complète du film.

| Élément | Référence | Détail |
|---|---|---|
| Point de présence | f161-lead-primer | Position physique vérifiée, vivant et trajet terminé |
| Séquence | encounter-rabattage | Présence limitée à son parcours |
| Navigation | Graphe commun | Même portes et appuis que la menace |

### Participants V105 · Dillon
ID : `participant-dillon`
Reçoit la consigne au poste de commande puis rejoint la fermeture. Sa présence et celle de Morse restent nécessaires pour armer puis couler. Les corps sont des silhouettes vectorielles stylisées. Ce test n’est pas la mort filmée de Dillon ni la fin complète du film.

| Élément | Référence | Détail |
|---|---|---|
| Point de présence | f161-piston-c-node | Position physique vérifiée, vivant et trajet terminé |
| Séquence | encounter-rabattage | Présence limitée à son parcours |
| Navigation | Graphe commun | Même portes et appuis que la menace |

### États du Runner · En attente du signal
ID : `runner-dormant`
Le rabattage conserve le prédateur en attente jusqu’à l’armement réel du moule.

| Élément | Référence | Détail |
|---|---|---|
| Contrat | encounter-rabattage | Un unique acteur |

### États du Runner · Patrouille
ID : `runner-patrol`
Suite de points connus, avec chemins calculés sur les connexions ouvertes. Aucun bond de position vers Ripley.

| Élément | Référence | Détail |
|---|---|---|
| Contrat | encounter-traque | Un unique acteur |
| patrolSpeed | 94 | Valeur utilisée par le module de poursuite |

### États du Runner · Investigation sonore
ID : `runner-investigate`
Le bruit produit une destination mémorisée au moment de son émission ; le prédateur ne lit pas la destination cachée du joueur.

| Élément | Référence | Détail |
|---|---|---|
| Contrat | encounter-traque | Un unique acteur |
| hearing | 620 | Valeur utilisée par le module de poursuite |
| investigateSpeed | 126 | Valeur utilisée par le module de poursuite |

### États du Runner · Recherche de trace perdue
ID : `runner-search`
La dernière trace expire après huit secondes ; la recherche dure 4,5 secondes et ne suit pas un acteur invisible à travers les murs.

| Élément | Référence | Détail |
|---|---|---|
| Contrat | encounter-traque | Un unique acteur |
| traceTTL | 8 | Valeur utilisée par le module de poursuite |
| search | 4.5 | Valeur utilisée par le module de poursuite |

### États du Runner · Poursuite
ID : `runner-chase`
Vue limitée par portée, direction, hauteur, profondeur et portes. La profondeur du Runner converge progressivement vers la trace vue.

| Élément | Référence | Détail |
|---|---|---|
| Contrat | encounter-traque | Un unique acteur |
| sight | 460 | Valeur utilisée par le module de poursuite |
| chaseSpeed | 206 | Valeur utilisée par le module de poursuite |

### États du Runner · Préparation de l’attaque
ID : `runner-windup`
Préparation de 0,85 seconde. Le corps reste sur place, l’orientation montre la cible, puis le contact réel est testé à l’impact.

| Élément | Référence | Détail |
|---|---|---|
| Contrat | encounter-traque | Un unique acteur |
| windup | 0.85 | Valeur utilisée par le module de poursuite |
| depthSpeed | 1.18 | Valeur utilisée par le module de poursuite |

### États du Runner · Reprise après attaque
ID : `runner-recover`
Après un hit ou une esquive, récupération de 1,30 seconde. Une sauvegarde ne rejoue pas une attaque suspendue.

| Élément | Référence | Détail |
|---|---|---|
| Contrat | encounter-traque | Un unique acteur |
| recovery | 1.3 | Valeur utilisée par le module de poursuite |
| resumeGrace | 1.25 | Valeur utilisée par le module de poursuite |

### États du Runner · Pris dans le moule
ID : `runner-trapped`
La coulée capture uniquement un Runner présent dans la plage du moule ; elle ne le téléporte pas au centre.

| Élément | Référence | Détail |
|---|---|---|
| Contrat | encounter-rabattage | Un unique acteur |

### États du Runner · Neutralisé
ID : `runner-dead`
Le refroidissement termine la menace de ce parcours original. Cette neutralisation ne valide pas le final de toute la campagne.

| Élément | Référence | Détail |
|---|---|---|
| Contrat | encounter-rabattage | Un unique acteur |

### Repères visuels V105 · EEV éventré
ID : `art-eev`
Le renderer remplace 1 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

| Élément | Référence | Détail |
|---|---|---|
| Fonction | drawLandmarkV105 | src/alien3-art-v105.js |
| Export | assets-v105/eev.png | Atlas de référence ; le runtime dessine directement les vecteurs. |

### Repères visuels V105 · Grilles du bloc
ID : `art-cell`
Le renderer remplace 2 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

| Élément | Référence | Détail |
|---|---|---|
| Fonction | drawLandmarkV105 | src/alien3-art-v105.js |
| Export | assets-v105/cell.png | Atlas de référence ; le runtime dessine directement les vecteurs. |

### Repères visuels V105 · Pompe à flasques
ID : `art-pump`
Le renderer remplace 5 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

| Élément | Référence | Détail |
|---|---|---|
| Fonction | drawLandmarkV105 | src/alien3-art-v105.js |
| Export | assets-v105/pump.png | Atlas de référence ; le runtime dessine directement les vecteurs. |

### Repères visuels V105 · Moule à vérins
ID : `art-mold`
Le renderer remplace 1 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

| Élément | Référence | Détail |
|---|---|---|
| Fonction | drawLandmarkV105 | src/alien3-art-v105.js |
| Export | assets-v105/mold.png | Atlas de référence ; le runtime dessine directement les vecteurs. |

### Repères visuels V105 · Four maçonné
ID : `art-furnace`
Le renderer remplace 1 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

| Élément | Référence | Détail |
|---|---|---|
| Fonction | drawLandmarkV105 | src/alien3-art-v105.js |
| Export | assets-v105/furnace.png | Atlas de référence ; le runtime dessine directement les vecteurs. |

### Audio V105 · Pas du joueur
ID : `sound-steps`
Le mouvement produit des signaux ; courir augmente le bruit de simulation, se baisser le réduit. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Détail |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Audio V105 · Appuis du Runner
ID : `sound-foot-runner`
Panorama et atténuation utilisent la position du seul acteur. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Détail |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Audio V105 · Heurt métallique
ID : `sound-metal`
F émet depuis la position actuelle, au sol et après un délai de deux secondes. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Détail |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Audio V105 · Préparation d’attaque
ID : `sound-windup`
Indice sonore limité ; aucune carte exacte du prédateur. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Détail |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Audio V105 · Contact
ID : `sound-bite`
Joué uniquement après le contact réellement validé. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Détail |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Audio V105 · Eau
ID : `sound-water`
Associé aux commandes du collecteur. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Détail |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Audio V105 · Coulée
ID : `sound-lead`
Associé à la commande physique de coulée. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Détail |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Audio V105 · Commande
ID : `sound-switch`
Retour court d’interaction. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Détail |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Audio V105 · Bourdonnement
ID : `sound-hum`
Oscillateur grave de 53/68 Hz selon la famille du lieu. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Détail |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Audio V105 · Ventilation
ID : `sound-vent`
Bruit filtré original, généré localement avec une graine fixe. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Détail |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Règles V105 · PATH
ID : `v105-PATH`
Tout déplacement IA suit une connexion réelle et les mêmes portes.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · NO-SNAP
ID : `v105-NO-SNAP`
Un changement de cible inverse le chemin en cours sans téléporter le corps.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · FLOOR
ID : `v105-FLOOR`
L’attaque exige proximité de hauteur et plan compatibles.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · DOOR
ID : `v105-DOOR`
Un battant fermé bloque passage, vue et contact ; les détenus attendent le passage.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · MEMORY
ID : `v105-MEMORY`
Une trace garde un lieu passé, pas la destination cachée du joueur.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · SERIAL
ID : `v105-SERIAL`
Un bruit déjà consommé ne se réacquiert pas indéfiniment.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · WINDUP
ID : `v105-WINDUP`
Le contact est différé de 0,85 seconde et vérifié au moment de l’impact.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · MISS
ID : `v105-MISS`
Une attaque ratée impose une récupération, sans hit compensatoire.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · PRESENCE
ID : `v105-PRESENCE`
La préparation du moule exige Morse et Dillon aux postes physiques.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · CAPTURE
ID : `v105-CAPTURE`
La coulée ne capture que le Runner réellement dans le volume autorisé.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · AARON
ID : `v105-AARON`
Aaron ne réapparaît pas dans la séquence finale.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · OWNER
ID : `v105-OWNER`
Le pilote V105 et le pilote historique ne causent pas deux attaques du même Runner.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · PAUSE
ID : `v105-PAUSE`
Pause, plan, archives, chargement et mort arrêtent la couche entière.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · SAVE
ID : `v105-SAVE`
Le fichier est validé avant remplacement ; corruption et poses incohérentes sont refusées.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · GRACE
ID : `v105-GRACE`
La reprise n’exécute pas une préparation d’attaque suspendue et laisse une courte grâce.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · FILES
ID : `v105-FILES`
Les exports sont de vrais fichiers ; aucune persistance localStorage native n’est inventée.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · ART
ID : `v105-ART`
Les repères améliorés conservent les appuis historiques ; les sprites natifs restent délégués sans opt-in vectoriel.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · AUDIO
ID : `v105-AUDIO`
L’audio est éteint par défaut et ne produit jamais d’effet de gameplay par lui-même.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · NATIVE
ID : `v105-NATIVE`
Le dépôt V86 n’est pas une cible V104 compatible ; le préflight refuse l’installation aveugle.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Règles V105 · SCOPE
ID : `v105-SCOPE`
Une traversée originale du banc n’est pas une victoire de la campagne du film.

| Élément | Référence | Détail |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |
