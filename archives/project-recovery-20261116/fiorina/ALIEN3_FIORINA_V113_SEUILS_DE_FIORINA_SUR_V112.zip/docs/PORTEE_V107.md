# Portée de la V107

| Sujet | Livré / vérifié | Non revendiqué |
|---|---|---|
| Manœuvres | Quatre gestes temporisés ; durée, présence et interruptions | Tous les objets interactifs de la campagne native |
| Accessibilité | Mode Appuyer conservant durée et contraintes ; bouton pointeur | Manette physique, session humaine, Safari |
| Rendu | Repères aux appuis réels et petit poste de vanne ; captures natives | Art définitif photoréaliste ou fidèle 1:1 |
| Sons | Machines à cadence bornée, pas réels des détenus, consignes locales | Chasse active pendant la préparation où le Runner reste dormant |
| Sauvegardes | Fichiers validés avant remplacement, poste sûr, migration V105/V106 | Autopersistence, cloud, anti-triche |
| Installation | Sources V106 exactes, copie de contrôle et rollback | Build complet Tantalus, push ou déploiement |
