# Portée V108

| Sujet | Livré / vérifié | Non revendiqué |
|---|---|---|
| Boulons | Trois identités, arc, rebonds, récupération et pertes | Armes, dégâts, stun, physique 3D complète |
| Bruit | Impact local → audition existante, portée et portes | Diversion garantie, annulation d’attaque, poursuite exacte hors graphe |
| Sauvegarde | Vol et sol validés, poste sûr séparé, migration V105–V107 | Cloud, autosave disque, sécurité anti-triche |
| Rendu | PNG natifs du canvas des modules livrés | Art final, sprites officiels, photoréalisme |
| Parcours | Six trajectoires automatisées dont diversion ; clavier réel | Film complet, sessions humaines |
| Intégration | Installation sur les sources exactes V107 et tests adversariaux | Build complet Tantalus, push ou déploiement |
