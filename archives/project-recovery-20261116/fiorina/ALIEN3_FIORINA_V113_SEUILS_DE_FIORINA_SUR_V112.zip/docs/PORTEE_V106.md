# Portée de la V106

| Sujet | Livré et vérifié | Pas revendiqué |
|---|---|---|
| Éclairage | Couplage réel des huit lampes avec le délai de reconnaissance, bon étage et portes | Simulation physique d’éclairage, invisibilité en ombre |
| Audition | Origine réelle, trajet local/graphe, atténuation de porte, événement unique | Acoustique réaliste d’une scène 3D |
| Recherche | Déplacement vers trois voisins au maximum depuis la trace perdue | IA native complète de tous les montages |
| Coordination | Ordres G de proximité, attente et reprise sans téléportation, présence réelle aux commandes | Groupe militaire commandable à distance |
| Sauvegarde | Validation atomique, position/nav cohérente, dernier poste sûr, migration V105 | Cloud, auto-save sur disque, garantie anti-triche |
| Rendu | Captures natives des modules partagés, options conservées | Art final 1:1, sprites complets du dépôt |
| Intégration | Installateur sur copie V105 et fixtures adversariales | Build complet Tantalus, push ou déploiement |
