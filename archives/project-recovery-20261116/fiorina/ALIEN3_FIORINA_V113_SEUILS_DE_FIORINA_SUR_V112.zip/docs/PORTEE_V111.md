# Portée V111

| Sujet | Livré et vérifié | Non revendiqué |
|---|---|---|
| Groupe | Choix de trajet, retour sur segment réversible, détour réel, attente comparée | Panique complète, nouvelles blessures ou remplacement des missions |
| Obstacles | Mêmes portes et jets, étages et profondeurs cohérents | Nouveaux murs physiques, conduits humains ajoutés |
| Déplacement | Budget de vitesse unique et segments canoniques | Téléportation, arrivée ou étape injectées |
| Fichiers | Pose et segment conservés, caches supprimés, import en pause, poste sûr distinct | Autosave disque, cloud ou signature anti-triche |
| Rendu | Captures natives du canvas et modules livrés | Assets définitifs photoréalistes ou film reconstitué 1:1 |
| Intégration | 51 sources vérifiées, staging et restauration | Build natif complet, push et déploiement |
