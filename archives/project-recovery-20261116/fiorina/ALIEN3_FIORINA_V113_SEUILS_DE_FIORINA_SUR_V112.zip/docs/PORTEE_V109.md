# Portée V109

| Sujet | Livré / vérifié | Non revendiqué |
|---|---|---|
| Purges | Trois commandes, réserve et durée finies | Simulation thermodynamique ou nouveau réseau de mission |
| Chasse | Jet dense gêne la vue distante, petits sons atténués, sifflement local | Invisibilité, mémoire effacée, attaque annulée, diversion garantie |
| Chaleur | Brûlure de Ripley dans le jet actif, même étage et profondeur | Arme contre le Runner ou nouveaux dégâts aux détenus |
| Reprise | Réserve et jet conservés, import en pause, poste sûr séparé | Autosave disque, cloud, anti-triche |
| Rendu | Modules réels, captures natives et ambiances immobiles | Art final ou représentation officielle du film |
| Intégration | Sources exactes V108, staging et restauration testés | Build natif complet, push ou déploiement |
