# Alien 3 — Codex de level design V109
## Le souffle des conduites

575 fiches, dont 40 nouveaux contrats. Document de conception extérieur au jeu ; les 90 archives du joueur ne sont pas une collection de ces fiches.

## Périmètre
Trois postes sont rattachés à des appuis existants et aux installations de pompage, de ventilation et de fonderie. Leurs volumes sont communs au dessin, au masquage visuel et à la chaleur. Une réserve abstraite finie se recharge avec le temps, pas une simulation de thermodynamique ni un débit d’eau du piège.
Le jet reste dangereux pour Ripley, bruyant et visible par les deux acteurs. Il ne remplace pas une porte, n’efface pas la mémoire du Runner et ne blesse pas les détenus. Aucune nouvelle carte ni aucun nouvel organisme ne sont créés.
Les neuf groupes de formes des postes ne sont pas neuf modèles originaux séparés : ce sont trois compositions d’un même équipement. Le reste du décor demeure celui de la base.
Les captures exécutent le renderer livré dans un banc à physique de base et personnages simplifiés. Les parcours et les comparaisons dirigées de portes sont séparés dans le rapport.

### Côte et épave
`section-shore` · Sections
[Socle V104 conservé] Approche extérieure ; l’épave conduit vers le complexe. Repère : Coque éventrée et prise d’air. Étendue descriptive X 50–770 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-spawn | X 180 ; pied Y 510 ; largeur 260 |
| Appui | f161-eev | X 620 ; pied Y 510 ; largeur 300 |
| Ensemble | coast-intake | X 87.5 ; Y 510 ; 185 × 146 |
| Ensemble | coast-wreck | X 485.5 ; Y 510 ; 269 × 158 |

### Infirmerie
`section-medical` · Sections
[Socle V104 conservé] Soins et circulation principale ; le mobilier reste derrière le passage. Repère : Brancard, lavabo et lampe de soin. Étendue descriptive X 970–1670 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-infirmary | X 1120 ; pied Y 510 ; largeur 300 |
| Appui | f161-clemens-bed | X 1380 ; pied Y 510 ; largeur 180 |
| Appui | f161-funeral-walk | X 1580 ; pied Y 510 ; largeur 180 |
| Ensemble | medical-care | X 1002 ; Y 510 ; 236 × 131.44 |
| Ensemble | clemens-room | X 1302 ; Y 510 ; 156 × 86.89 |

### Morgue et dossiers
`section-morgue` · Sections
[Socle V104 conservé] Palier supérieur, séparé de l’infirmerie par son altitude. Repère : Table mortuaire et armoire. Étendue descriptive X 1175–1630 ; sol représentatif Y 350. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-master-archive-node | X 1260 ; pied Y 350 ; largeur 170 |
| Appui | f161-morgue-high | X 1500 ; pied Y 350 ; largeur 260 |
| Ensemble | morgue-bay | X 1382 ; Y 350 ; 236 × 111.27 |

### Cellules ouest
`section-west-cells` · Sections
[Socle V104 conservé] Coursive basse ; les cellules peintes ne sont pas des passages ajoutés. Repère : Barreaux et couchettes. Étendue descriptive X 1750–2450 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-cell-a | X 1900 ; pied Y 510 ; largeur 300 |
| Appui | f161-assembly-hall | X 2300 ; pied Y 510 ; largeur 300 |
| Ensemble | cell-a | X 1767 ; Y 510 ; 266 × 154 |

### Cellules est
`section-east-cells` · Sections
[Socle V104 conservé] Approche du verrou des galeries ; conserver une sortie identifiable. Repère : Volet réel à l’est. Étendue descriptive X 2470–2820 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-cell-b | X 2620 ; pied Y 510 ; largeur 300 |
| Appui | f161-shutter-cell-node | X 2740 ; pied Y 510 ; largeur 160 |
| Ensemble | cell-b | X 2487 ; Y 510 ; 266 × 154 |

### Réfectoire
`section-refectory` · Sections
[Socle V104 conservé] Tables regroupées ; accès par les connecteurs déjà présents. Repère : Longue table et bancs. Étendue descriptive X 2180–2565 ; sol représentatif Y 350. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-mess-high | X 2320 ; pied Y 350 ; largeur 280 |
| Appui | f161-mess-ceiling | X 2470 ; pied Y 350 ; largeur 190 |
| Ensemble | mess | X 2198 ; Y 350 ; 244 × 137 |

### Communications
`section-comms` · Sections
[Socle V104 conservé] Poste haut réel, distinct du secteur caméra nommé communications. Repère : Deux écrans sur console. Étendue descriptive X 2630–2810 ; sol représentatif Y 350. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-comms-high | X 2720 ; pied Y 350 ; largeur 180 |
| Ensemble | actual-comms | X 2642 ; Y 350 ; 156 × 96.24 |

### Recueillement
`section-prayer` · Sections
[Socle V104 conservé] Palier haut austère, sans nouvelle porte au fond. Repère : Livre et petites flammes. Étendue descriptive X 2055–2585 ; sol représentatif Y 190. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-faith-dais-v94 | X 2180 ; pied Y 190 ; largeur 250 |
| Appui | f161-perch-cell-v93 | X 2500 ; pied Y 190 ; largeur 170 |
| Ensemble | faith | X 2067 ; Y 190 ; 226 × 133.89 |

### Pompage et secours
`section-service` · Sections
[Socle V104 conservé] Eau, entretien et passage principal ; éclairage de service indépendant des objectifs. Repère : Pompe sur semelle. Étendue descriptive X 2920–3650 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-service-low | X 3070 ; pied Y 510 ; largeur 300 |
| Appui | f161-rescue-post-node | X 3330 ; pied Y 510 ; largeur 170 |
| Appui | f161-bishop | X 3500 ; pied Y 510 ; largeur 300 |
| Ensemble | service-pump | X 2957.5 ; Y 510 ; 225 × 150 |

### Ventilation
`section-ventilation` · Sections
[Socle V104 conservé] Palier technique supérieur ; une échelle ne doit pas changer la profondeur. Repère : Ventilateur sous grille. Étendue descriptive X 2855–3270 ; sol représentatif Y 330. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-fan-shaft | X 2940 ; pied Y 330 ; largeur 170 |
| Appui | f161-service-high | X 3070 ; pied Y 330 ; largeur 280 |
| Appui | f161-steam-service-node | X 3190 ; pied Y 330 ; largeur 160 |
| Ensemble | murphy-fan | X 2887 ; Y 330 ; 106 × 61.39 |
| Ensemble | service-shop | X 3017 ; Y 330 ; 106 × 64.58 |

### Atelier des batteries
`section-batteries` · Sections
[Socle V104 conservé] Établi et rangement au-dessus de la circulation basse. Repère : Panneau à outils. Étendue descriptive X 3265–3625 ; sol représentatif Y 330. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-hunt-service-v95 | X 3370 ; pied Y 330 ; largeur 210 |
| Appui | f161-battery-locker-v94 | X 3500 ; pied Y 330 ; largeur 250 |
| Ensemble | battery-store | X 3387 ; Y 330 ; 226 × 137.69 |

### Galeries basses
`section-lower-service` · Sections
[Socle V104 conservé] Dessous du complexe ; les regards vers les étages ne constituent pas un accès. Repère : Alcôve et réseaux. Étendue descriptive X 2930–3775 ; sol représentatif Y 630. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-service-deep | X 3070 ; pied Y 630 ; largeur 280 |
| Appui | f161-tunnel-shrine | X 3420 ; pied Y 630 ; largeur 210 |
| Appui | f161-golic-cache-v94 | X 3660 ; pied Y 630 ; largeur 230 |
| Ensemble | deep-shrine | X 3327 ; Y 630 ; 186 × 110.19 |

### Réserve et supervision
`section-supply` · Sections
[Socle V104 conservé] Stockage puis commande industrielle ; respecter la position du portail existant. Repère : Fûts et console de supervision. Étendue descriptive X 3565–4050 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-chemical-store | X 3670 ; pied Y 510 ; largeur 210 |
| Appui | f161-command-post-node | X 3960 ; pied Y 510 ; largeur 180 |
| Ensemble | chemical-store | X 3577 ; Y 510 ; 186 × 106.08 |
| Ensemble | command | X 3882 ; Y 510 ; 156 × 96.24 |

### Fonderie
`section-leadworks` · Sections
[Socle V104 conservé] Regrouper alimentation, creuset et levage, sans ajouter de danger décoratif. Repère : Creuset sous portique. Étendue descriptive X 4030–4570 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-leadworks | X 4200 ; pied Y 510 ; largeur 340 |
| Appui | f161-lead-primer | X 4380 ; pied Y 510 ; largeur 190 |
| Appui | f161-piston-a-node | X 4480 ; pied Y 510 ; largeur 180 |
| Ensemble | leadworks | X 4122 ; Y 510 ; 156 × 118.09 |
| Ensemble | lead-primer | X 4302 ; Y 510 ; 156 × 104 |

### Collecteur supérieur
`section-water` · Sections
[Socle V104 conservé] Conduite d’eau séparée visuellement du transfert de métal. Repère : Réservoir et vérins. Étendue descriptive X 4420–4910 ; sol représentatif Y 330. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-sprinkler | X 4560 ; pied Y 330 ; largeur 280 |
| Appui | f161-water-header | X 4690 ; pied Y 330 ; largeur 190 |
| Appui | f161-piston-b-node | X 4820 ; pied Y 330 ; largeur 180 |
| Ensemble | water-header | X 4447.5 ; Y 330 ; 225 × 150 |
| Ensemble | piston-upper | X 4742 ; Y 330 ; 156 × 97.05 |

### Cuve et évacuation
`section-waste` · Sections
[Socle V104 conservé] Niveau inférieur : reprise des effluents et retour hydraulique. Repère : Réservoir bas et caniveau. Étendue descriptive X 3915–4890 ; sol représentatif Y 630. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-waste-tank | X 4070 ; pied Y 630 ; largeur 310 |
| Appui | f161-sluice-low | X 4500 ; pied Y 630 ; largeur 280 |
| Appui | f161-pressure-alcove-v95 | X 4780 ; pied Y 630 ; largeur 220 |
| Ensemble | waste | X 3957.5 ; Y 630 ; 225 × 150 |
| Ensemble | lower-pressure | X 4682 ; Y 630 ; 196 × 130.67 |

### Moule et pistons
`section-mold` · Sections
[Socle V104 conservé] Le piège et ses commandes historiques conservent leurs conditions. Repère : Bac de coulée bas. Étendue descriptive X 4740–5230 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-mold | X 4920 ; pied Y 510 ; largeur 360 |
| Appui | f161-piston-c-node | X 5140 ; pied Y 510 ; largeur 180 |
| Ensemble | mold | X 4783.5 ; Y 510 ; 273 × 143 |

### Four principal
`section-furnace` · Sections
[Socle V104 conservé] Approche chaude puis confrontation ; ne pas masquer les personnages. Repère : Bouche circulaire du four. Étendue descriptive X 5310–5750 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-furnace | X 5480 ; pied Y 510 ; largeur 340 |
| Appui | f161-parley-v93 | X 5660 ; pied Y 510 ; largeur 180 |
| Ensemble | main-furnace | X 5402 ; Y 510 ; 156 × 110.29 |
| Ensemble | parley | X 5582 ; Y 510 ; 156 × 102.23 |

### Passerelles du four
`section-gantries` · Sections
[Socle V104 conservé] Commande haute avec débouchés d’échelles conservés. Repère : Treuil et caillebotis. Étendue descriptive X 5210–5880 ; sol représentatif Y 330. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-furnace-high | X 5350 ; pied Y 330 ; largeur 280 |
| Appui | f161-furnace-overlook | X 5580 ; pied Y 330 ; largeur 220 |
| Appui | f161-furnace-gantry | X 5740 ; pied Y 330 ; largeur 280 |
| Ensemble | furnace-gantry | X 5232.5 ; Y 330 ; 235 × 154 |

### Approche et plateforme
`section-arrival` · Sections
[Socle V104 conservé] L’équipement de récupération reste conditionné à l’arrivée de la Compagnie. Repère : Cage portable et projecteur. Étendue descriptive X 5650–6190 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-company | X 5800 ; pied Y 510 ; largeur 300 |
| Appui | f161-patna-cage-node | X 5930 ; pied Y 510 ; largeur 160 |
| Appui | f161-extraction | X 6040 ; pied Y 510 ; largeur 300 |
| Ensemble | patna-kit | X 5887 ; Y 510 ; 86 × 42.85 |
| Ensemble | final-landing | X 5997 ; Y 510 ; 86 × 56.36 |

### Prise d’air côtière
`coast-intake` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-spawn ; point f161-spawn ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant fan | coast-intake/0 | X 87.5 ; Y 398 ; 84 × 84 ; pose wall |
| Composant duct | coast-intake/1 | X 167.5 ; Y 414 ; 105 × 48 ; pose wall |
| Composant junction | coast-intake/2 | X 230.5 ; Y 470 ; 38 × 38 ; pose wall |
| Composant gauge | coast-intake/3 | X 194.5 ; Y 467 ; 22 × 22 ; pose wall |
| Composant pipe | coast-intake/4 | X 175.5 ; Y 480 ; 42 × 10 ; pose wall |
| Composant drain | coast-intake/5 | X 94.5 ; Y 503 ; 100 × 7 ; pose floor |
| Composant lamp | coast-intake/6 | X 127.5 ; Y 364 ; 40 × 13 ; pose ceiling |
| Composant cable | coast-intake/7 | X 244.5 ; Y 409 ; 7 × 52 ; pose wall |
| Composant support | coast-intake/8 | X 92.5 ; Y 490 ; 6 × 20 ; pose floor |
| Composant stencil | coast-intake/9 | X 188.5 ; Y 370 ; 77 × 19 ; pose wall |
| Raccord | coast-intake-lighting-run | coast-intake/2 → coast-intake/6 |

### Épave et matériel de secours
`coast-wreck` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-eev ; point f161-eev ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant eev | coast-wreck/0 | X 485.5 ; Y 396 ; 236 × 114 ; pose floor |
| Composant cable | coast-wreck/1 | X 496.5 ; Y 471 ; 80 × 12 ; pose wall |
| Composant case | coast-wreck/2 | X 664.5 ; Y 476 ; 43 × 34 ; pose floor |
| Composant drain | coast-wreck/3 | X 498.5 ; Y 504 ; 139 × 6 ; pose floor |
| Composant lamp | coast-wreck/4 | X 565.5 ; Y 352 ; 41 × 13 ; pose ceiling |
| Composant junction | coast-wreck/5 | X 728.5 ; Y 461 ; 26 × 44 ; pose wall |
| Composant pipe | coast-wreck/6 | X 726.5 ; Y 405 ; 10 × 45 ; pose wall |
| Composant stencil | coast-wreck/7 | X 660.5 ; Y 367 ; 72 × 20 ; pose wall |
| Raccord | coast-wreck-lighting-run | coast-wreck/5 → coast-wreck/4 |

### Poste de soin
`medical-care` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-infirmary ; point f161-infirmary ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant cabinet | medical-care/0 | X 1002 ; Y 411.42 ; 44.81 × 98.58 ; pose floor |
| Composant gurney | medical-care/1 | X 1067.72 ; Y 466.19 ; 105.55 × 43.81 ; pose floor |
| Composant monitor | medical-care/2 | X 1110.54 ; Y 408.43 ; 51.78 × 38.84 ; pose wall |
| Composant sink | medical-care/3 | X 1186.22 ; Y 452.24 ; 51.78 × 57.76 ; pose floor |
| Composant bottle | medical-care/4 | X 1010.96 ; Y 425.36 ; 5.97 × 13.94 ; pose wall |
| Composant bottle | medical-care/5 | X 1023.91 ; Y 425.36 ; 5.97 × 13.94 ; pose wall |
| Composant bottle | medical-care/6 | X 1194.19 ; Y 435.32 ; 5.97 × 14.94 ; pose wall |
| Composant lamp | medical-care/7 | X 1074.69 ; Y 378.56 ; 97.59 × 11.95 ; pose ceiling |
| Composant cable | medical-care/8 | X 1159.33 ; Y 446.27 ; 7.97 × 54.77 ; pose wall |
| Composant pipe | medical-care/9 | X 1231.03 ; Y 419.38 ; 6.97 × 21.91 ; pose wall |
| Composant tray | medical-care/10 | X 1085.65 ; Y 454.24 ; 46.8 × 8.96 ; pose wall |
| Composant stencil | medical-care/11 | X 1004.99 ; Y 381.54 ; 54.77 × 16.93 ; pose wall |

### Chambre médicale
`clemens-room` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-clemens-bed ; point f161-clemens-bed ; échelle uniforme 0.66 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant cabinet | clemens-room/0 | X 1302 ; Y 444.84 ; 29.62 × 65.16 ; pose floor |
| Composant gurney | clemens-room/1 | X 1345.44 ; Y 481.04 ; 69.77 × 28.96 ; pose floor |
| Composant monitor | clemens-room/2 | X 1373.75 ; Y 442.86 ; 34.23 × 25.67 ; pose wall |
| Composant sink | clemens-room/3 | X 1423.77 ; Y 471.82 ; 34.23 × 38.18 ; pose floor |
| Composant bottle | clemens-room/4 | X 1307.92 ; Y 454.05 ; 3.95 × 9.22 ; pose wall |
| Composant bottle | clemens-room/5 | X 1316.48 ; Y 454.05 ; 3.95 × 9.22 ; pose wall |
| Composant bottle | clemens-room/6 | X 1429.04 ; Y 460.63 ; 3.95 × 9.87 ; pose wall |
| Composant lamp | clemens-room/7 | X 1350.05 ; Y 423.11 ; 64.51 × 7.9 ; pose ceiling |
| Composant cable | clemens-room/8 | X 1406 ; Y 467.87 ; 5.27 × 36.2 ; pose wall |
| Composant pipe | clemens-room/9 | X 1453.39 ; Y 450.1 ; 4.61 × 14.48 ; pose wall |
| Composant tray | clemens-room/10 | X 1357.29 ; Y 473.14 ; 30.94 × 5.92 ; pose wall |
| Composant stencil | clemens-room/11 | X 1303.97 ; Y 425.09 ; 36.2 × 11.19 ; pose wall |

### Baie mortuaire
`morgue-bay` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-morgue-high ; point f161-morgue-high ; échelle uniforme 0.9 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant cabinet | morgue-bay/0 | X 1382 ; Y 271.03 ; 52.05 × 78.97 ; pose floor |
| Composant gurney | morgue-bay/1 | X 1458.27 ; Y 312.31 ; 98.71 × 37.69 ; pose floor |
| Composant sink | morgue-bay/2 | X 1576.72 ; Y 296.16 ; 41.28 × 53.84 ; pose floor |
| Composant lamp | morgue-bay/3 | X 1463.66 ; Y 238.73 ; 77.17 × 10.77 ; pose ceiling |
| Composant drain | morgue-bay/4 | X 1461.86 ; Y 345.51 ; 96.91 × 4.49 ; pose floor |
| Composant tray | morgue-bay/5 | X 1504.04 ; Y 298.85 ; 37.69 × 8.97 ; pose wall |
| Composant junction | morgue-bay/6 | X 1588.39 ; Y 256.68 ; 22.43 × 21.54 ; pose wall |
| Composant stencil | morgue-bay/7 | X 1384.69 ; Y 239.63 ; 52.05 × 14.36 ; pose wall |
| Raccord | morgue-bay-lighting-run | morgue-bay/6 → morgue-bay/3 |

### Cellules ouest
`cell-a` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-cell-a ; point f161-cell-a ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant cell | cell-a/0 | X 1767 ; Y 378 ; 73 × 132 ; pose floor |
| Composant bunk | cell-a/1 | X 1861 ; Y 407 ; 111 × 103 ; pose floor |
| Composant basin | cell-a/2 | X 1990 ; Y 462 ; 35 × 48 ; pose floor |
| Composant lamp | cell-a/3 | X 1784 ; Y 356 ; 37 × 11 ; pose ceiling |
| Composant blanket | cell-a/4 | X 1880 ; Y 471 ; 42 × 8 ; pose wall |
| Composant cup | cell-a/5 | X 1965 ; Y 499 ; 8 × 11 ; pose floor |
| Composant stencil | cell-a/6 | X 1874 ; Y 368 ; 73 × 19 ; pose wall |
| Composant pipe | cell-a/7 | X 2027 ; Y 401 ; 6 × 89 ; pose wall |
| Composant cable | cell-a/8 | X 1779 ; Y 368 ; 234 × 5 ; pose wall |
| Composant drain | cell-a/9 | X 1988 ; Y 505 ; 36 × 5 ; pose floor |

### Cellules est
`cell-b` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-cell-b ; point f161-cell-b ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant cell | cell-b/0 | X 2487 ; Y 378 ; 73 × 132 ; pose floor |
| Composant bunk | cell-b/1 | X 2581 ; Y 407 ; 111 × 103 ; pose floor |
| Composant basin | cell-b/2 | X 2710 ; Y 462 ; 35 × 48 ; pose floor |
| Composant lamp | cell-b/3 | X 2504 ; Y 356 ; 37 × 11 ; pose ceiling |
| Composant blanket | cell-b/4 | X 2600 ; Y 471 ; 42 × 8 ; pose wall |
| Composant cup | cell-b/5 | X 2685 ; Y 499 ; 8 × 11 ; pose floor |
| Composant stencil | cell-b/6 | X 2594 ; Y 368 ; 73 × 19 ; pose wall |
| Composant pipe | cell-b/7 | X 2747 ; Y 401 ; 6 × 89 ; pose wall |
| Composant cable | cell-b/8 | X 2499 ; Y 368 ; 234 × 5 ; pose wall |
| Composant drain | cell-b/9 | X 2708 ; Y 505 ; 36 × 5 ; pose floor |

### Réfectoire
`mess` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-mess-high ; point f161-mess-high ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant table | mess/0 | X 2212 ; Y 305 ; 156 × 45 ; pose floor |
| Composant bench | mess/1 | X 2202 ; Y 326 ; 65 × 24 ; pose floor |
| Composant bench | mess/2 | X 2312 ; Y 326 ; 65 × 24 ; pose floor |
| Composant cup | mess/3 | X 2244 ; Y 296 ; 8 × 10 ; pose wall |
| Composant cup | mess/4 | X 2290 ; Y 296 ; 8 × 10 ; pose wall |
| Composant bowl | mess/5 | X 2324 ; Y 299 ; 21 × 7 ; pose wall |
| Composant rack | mess/6 | X 2388 ; Y 241 ; 53 × 109 ; pose floor |
| Composant lamp | mess/7 | X 2246 ; Y 215 ; 78 × 12 ; pose ceiling |
| Composant stencil | mess/8 | X 2389 ; Y 213 ; 53 × 17 ; pose wall |
| Composant cable | mess/9 | X 2391 ; Y 227 ; 42 × 5 ; pose wall |
| Raccord | mess-lighting-run | mess/6 → mess/7 |

### Lieu de recueillement
`faith` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-faith-dais-v94 ; point f161-faith-dais-v94 ; échelle uniforme 0.95 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant altar | faith/0 | X 2106.88 ; Y 134.92 ; 113.95 × 55.08 ; pose floor |
| Composant bench | faith/1 | X 2067 ; Y 166.26 ; 54.13 × 23.74 ; pose floor |
| Composant bench | faith/2 | X 2238.87 ; Y 166.26 ; 54.13 × 23.74 ; pose floor |
| Composant candle | faith/3 | X 2138.22 ; Y 111.18 ; 5.7 × 23.74 ; pose wall |
| Composant candle | faith/4 | X 2198.99 ; Y 114.98 ; 5.7 × 19.94 ; pose wall |
| Composant book | faith/5 | X 2168.61 ; Y 125.43 ; 22.79 × 7.6 ; pose wall |
| Composant lamp | faith/6 | X 2155.31 ; Y 56.11 ; 22.79 × 10.45 ; pose ceiling |
| Composant stencil | faith/7 | X 2108.78 ; Y 76.05 ; 112.05 × 20.89 ; pose wall |

### Poste de communication
`actual-comms` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-comms-high ; point f161-comms-high ; échelle uniforme 0.63 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant console | actual-comms/0 | X 2644.52 ; Y 302.19 ; 84.29 × 47.81 ; pose floor |
| Composant rack | actual-comms/1 | X 2756.48 ; Y 266.34 ; 41.52 × 83.66 ; pose floor |
| Composant monitor | actual-comms/2 | X 2652.06 ; Y 272.63 ; 32.71 × 23.9 ; pose wall |
| Composant monitor | actual-comms/3 | X 2691.69 ; Y 272.63 ; 32.71 × 23.9 ; pose wall |
| Composant spool | actual-comms/4 | X 2736.98 ; Y 331.76 ; 18.24 × 18.24 ; pose floor |
| Composant junction | actual-comms/5 | X 2733.21 ; Y 281.44 ; 16.98 × 18.24 ; pose wall |
| Composant cable | actual-comms/6 | X 2721.26 ; Y 297.79 ; 39.63 × 5.03 ; pose wall |
| Composant lamp | actual-comms/7 | X 2652.69 ; Y 255.65 ; 28.31 × 6.29 ; pose ceiling |
| Composant stencil | actual-comms/8 | X 2757.11 ; Y 253.76 ; 40.89 × 9.44 ; pose wall |
| Composant stool | actual-comms/9 | X 2683.52 ; Y 329.87 ; 15.1 × 20.13 ; pose floor |
| Raccord | actual-comms-lighting-run | actual-comms/5 → actual-comms/7 |

### Ventilateur de maintenance
`murphy-fan` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-fan-shaft ; point f161-fan-shaft ; échelle uniforme 0.41 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant fan | murphy-fan/0 | X 2890.27 ; Y 277.61 ; 47.47 × 47.47 ; pose wall |
| Composant duct | murphy-fan/1 | X 2937.75 ; Y 292.76 ; 52.8 × 23.33 ; pose wall |
| Composant junction | murphy-fan/2 | X 2969.26 ; Y 275.16 ; 13.92 × 12.69 ; pose wall |
| Composant gauge | murphy-fan/3 | X 2951.66 ; Y 279.66 ; 8.59 × 8.59 ; pose wall |
| Composant valve | murphy-fan/4 | X 2943.48 ; Y 318.95 ; 11.05 × 11.05 ; pose wall |
| Composant pipe | murphy-fan/5 | X 2891.09 ; Y 324.68 ; 101.91 × 3.68 ; pose wall |
| Composant drain | murphy-fan/6 | X 2894.37 ; Y 327.95 ; 38.47 × 2.05 ; pose floor |
| Composant lamp | murphy-fan/7 | X 2899.69 ; Y 268.61 ; 18.42 × 4.09 ; pose ceiling |
| Composant grille | murphy-fan/8 | X 2967.63 ; Y 319.77 ; 21.69 × 8.59 ; pose wall |
| Composant cable | murphy-fan/9 | X 2983.18 ; Y 274.75 ; 2.86 × 15.55 ; pose wall |
| Raccord | murphy-fan-lighting-run | murphy-fan/2 → murphy-fan/7 |

### Pompage des galeries
`service-pump` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-service-low ; point f161-service-low ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant pump | service-pump/0 | X 2985.5 ; Y 430 ; 83 × 80 ; pose floor |
| Composant tank | service-pump/1 | X 3122.5 ; Y 384 ; 60 × 126 ; pose floor |
| Composant valve | service-pump/2 | X 3086.5 ; Y 471 ; 27 × 27 ; pose wall |
| Composant gauge | service-pump/3 | X 3003.5 ; Y 402 ; 24 × 24 ; pose wall |
| Composant pipe | service-pump/4 | X 3056.5 ; Y 481 ; 84 × 10 ; pose wall |
| Composant pipe | service-pump/5 | X 3135.5 ; Y 384 ; 8 × 19 ; pose wall |
| Composant junction | service-pump/6 | X 2966.5 ; Y 448 ; 23 × 25 ; pose wall |
| Composant drain | service-pump/7 | X 2960.5 ; Y 505 ; 116 × 5 ; pose floor |
| Composant lamp | service-pump/8 | X 3056.5 ; Y 360 ; 37 × 10 ; pose ceiling |
| Composant stencil | service-pump/9 | X 2978.5 ; Y 371 ; 72 × 18 ; pose wall |
| Raccord | service-pump-lighting-run | service-pump/6 → service-pump/8 |

### Entretien des réseaux
`service-shop` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-service-high ; point f161-service-high ; échelle uniforme 0.45 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant bench | service-shop/0 | X 3018.78 ; Y 306.84 ; 57.9 × 23.16 ; pose floor |
| Composant rack | service-shop/1 | X 3097.17 ; Y 276.11 ; 25.83 × 53.89 ; pose floor |
| Composant toolboard | service-shop/2 | X 3024.57 ; Y 280.56 ; 47.66 × 22.71 ; pose wall |
| Composant case | service-shop/3 | X 3082.47 ; Y 314.86 ; 15.14 × 15.14 ; pose floor |
| Composant lamp | service-shop/4 | X 3029.92 ; Y 268.09 ; 35.18 × 4.9 ; pose ceiling |
| Composant junction | service-shop/5 | X 3082.92 ; Y 282.79 ; 12.03 × 14.7 ; pose wall |
| Composant spool | service-shop/6 | X 3101.18 ; Y 309.51 ; 13.36 × 13.36 ; pose wall |
| Composant pipe | service-shop/7 | X 3021.45 ; Y 272.99 ; 96.2 × 2.67 ; pose wall |
| Composant stencil | service-shop/8 | X 3082.03 ; Y 265.42 ; 35.63 × 7.57 ; pose wall |
| Composant tray | service-shop/9 | X 3045.5 ; Y 301.05 ; 14.25 × 4.45 ; pose wall |
| Raccord | service-shop-lighting-run | service-shop/5 → service-shop/4 |

### Alcôve des galeries
`deep-shrine` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-tunnel-shrine ; point f161-tunnel-shrine ; échelle uniforme 0.78 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant altar | deep-shrine/0 | X 3359.82 ; Y 584.67 ; 93.78 × 45.33 ; pose floor |
| Composant bench | deep-shrine/1 | X 3327 ; Y 610.46 ; 44.55 × 19.54 ; pose floor |
| Composant bench | deep-shrine/2 | X 3468.45 ; Y 610.46 ; 44.55 × 19.54 ; pose floor |
| Composant candle | deep-shrine/3 | X 3385.61 ; Y 565.13 ; 4.69 × 19.54 ; pose wall |
| Composant candle | deep-shrine/4 | X 3435.63 ; Y 568.26 ; 4.69 × 16.41 ; pose wall |
| Composant book | deep-shrine/5 | X 3410.62 ; Y 576.86 ; 18.76 × 6.25 ; pose wall |
| Composant lamp | deep-shrine/6 | X 3399.68 ; Y 519.81 ; 18.76 × 8.6 ; pose ceiling |
| Composant stencil | deep-shrine/7 | X 3361.39 ; Y 536.22 ; 92.22 × 17.19 ; pose wall |

### Recharge des batteries
`battery-store` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-battery-locker-v94 ; point f161-battery-locker-v94 ; échelle uniforme 0.95 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant bench | battery-store/0 | X 3390.8 ; Y 280.62 ; 123.45 × 49.38 ; pose floor |
| Composant rack | battery-store/1 | X 3557.92 ; Y 215.1 ; 55.08 × 114.9 ; pose floor |
| Composant toolboard | battery-store/2 | X 3403.14 ; Y 224.6 ; 101.61 × 48.43 ; pose wall |
| Composant case | battery-store/3 | X 3526.59 ; Y 297.71 ; 32.29 × 32.29 ; pose floor |
| Composant lamp | battery-store/4 | X 3414.54 ; Y 198.01 ; 75.02 × 10.45 ; pose ceiling |
| Composant junction | battery-store/5 | X 3527.54 ; Y 229.34 ; 25.64 × 31.34 ; pose wall |
| Composant spool | battery-store/6 | X 3566.47 ; Y 286.32 ; 28.49 × 28.49 ; pose wall |
| Composant pipe | battery-store/7 | X 3396.5 ; Y 208.45 ; 205.11 × 5.7 ; pose wall |
| Composant stencil | battery-store/8 | X 3525.64 ; Y 192.31 ; 75.97 × 16.14 ; pose wall |
| Composant tray | battery-store/9 | X 3447.77 ; Y 268.28 ; 30.39 × 9.5 ; pose wall |
| Raccord | battery-store-lighting-run | battery-store/5 → battery-store/4 |

### Réserve de produits
`chemical-store` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-chemical-store ; point f161-chemical-store ; échelle uniforme 0.71 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant rack | chemical-store/0 | X 3577 ; Y 423.01 ; 53.04 × 86.99 ; pose floor |
| Composant barrel | chemical-store/1 | X 3650.55 ; Y 460.49 ; 27.58 × 49.51 ; pose floor |
| Composant barrel | chemical-store/2 | X 3687.33 ; Y 460.49 ; 27.58 × 49.51 ; pose floor |
| Composant case | chemical-store/3 | X 3727.64 ; Y 485.95 ; 30.41 × 24.05 ; pose floor |
| Composant lamp | chemical-store/4 | X 3644.89 ; Y 403.92 ; 31.12 × 7.07 ; pose ceiling |
| Composant grille | chemical-store/5 | X 3657.62 ; Y 421.6 ; 57.29 × 22.63 ; pose wall |
| Composant valve | chemical-store/6 | X 3747.44 ; Y 445.64 ; 15.56 × 15.56 ; pose wall |
| Composant pipe | chemical-store/7 | X 3627.21 ; Y 437.86 ; 30.41 × 4.95 ; pose wall |
| Composant stencil | chemical-store/8 | X 3583.37 ; Y 405.33 ; 47.38 × 11.32 ; pose wall |
| Composant drain | chemical-store/9 | X 3644.89 ; Y 506.46 ; 79.21 × 3.54 ; pose floor |
| Raccord | chemical-store-lighting-run | chemical-store/0 → chemical-store/4 |

### Supervision de la fonderie
`command` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-command-post-node ; point f161-command-post-node ; échelle uniforme 0.63 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant console | command/0 | X 3884.52 ; Y 462.19 ; 84.29 × 47.81 ; pose floor |
| Composant rack | command/1 | X 3996.48 ; Y 426.34 ; 41.52 × 83.66 ; pose floor |
| Composant monitor | command/2 | X 3892.06 ; Y 432.63 ; 32.71 × 23.9 ; pose wall |
| Composant monitor | command/3 | X 3931.69 ; Y 432.63 ; 32.71 × 23.9 ; pose wall |
| Composant spool | command/4 | X 3976.98 ; Y 491.76 ; 18.24 × 18.24 ; pose floor |
| Composant junction | command/5 | X 3973.21 ; Y 441.44 ; 16.98 × 18.24 ; pose wall |
| Composant cable | command/6 | X 3961.26 ; Y 457.79 ; 39.63 × 5.03 ; pose wall |
| Composant lamp | command/7 | X 3892.69 ; Y 415.65 ; 28.31 × 6.29 ; pose ceiling |
| Composant stencil | command/8 | X 3997.11 ; Y 413.76 ; 40.89 × 9.44 ; pose wall |
| Composant stool | command/9 | X 3923.52 ; Y 489.87 ; 15.1 × 20.13 ; pose floor |
| Raccord | command-lighting-run | command/5 → command/7 |

### Collecte des effluents
`waste` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-waste-tank ; point f161-waste-tank ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant pump | waste/0 | X 3985.5 ; Y 550 ; 83 × 80 ; pose floor |
| Composant tank | waste/1 | X 4122.5 ; Y 504 ; 60 × 126 ; pose floor |
| Composant valve | waste/2 | X 4086.5 ; Y 591 ; 27 × 27 ; pose wall |
| Composant gauge | waste/3 | X 4003.5 ; Y 522 ; 24 × 24 ; pose wall |
| Composant pipe | waste/4 | X 4056.5 ; Y 601 ; 84 × 10 ; pose wall |
| Composant pipe | waste/5 | X 4135.5 ; Y 504 ; 8 × 19 ; pose wall |
| Composant junction | waste/6 | X 3966.5 ; Y 568 ; 23 × 25 ; pose wall |
| Composant drain | waste/7 | X 3960.5 ; Y 625 ; 116 × 5 ; pose floor |
| Composant lamp | waste/8 | X 4056.5 ; Y 480 ; 37 × 10 ; pose ceiling |
| Composant stencil | waste/9 | X 3978.5 ; Y 491 ; 72 × 18 ; pose wall |
| Raccord | waste-lighting-run | waste/6 → waste/8 |

### Creuset et transfert
`leadworks` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-leadworks ; point f161-leadworks ; échelle uniforme 0.62 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant crucible | leadworks/0 | X 4151.83 ; Y 424.85 ; 72.1 × 85.15 ; pose floor |
| Composant gantry | leadworks/1 | X 4127.59 ; Y 406.21 ; 133.63 × 103.79 ; pose floor |
| Composant hoist | leadworks/2 | X 4174.83 ; Y 414.29 ; 29.83 × 40.4 ; pose ceiling |
| Composant ladle | leadworks/3 | X 4242.57 ; Y 441.63 ; 35.43 × 68.37 ; pose floor |
| Composant gauge | leadworks/4 | X 4128.22 ; Y 475.2 ; 14.29 × 14.29 ; pose wall |
| Composant pipe | leadworks/5 | X 4127.59 ; Y 489.49 ; 26.1 × 6.22 ; pose wall |
| Composant slag | leadworks/6 | X 4240.09 ; Y 490.11 ; 25.48 × 19.89 ; pose floor |
| Composant lamp | leadworks/7 | X 4241.95 ; Y 391.91 ; 19.89 × 7.46 ; pose ceiling |
| Composant stencil | leadworks/8 | X 4150.59 ; Y 397.51 ; 49.72 × 11.19 ; pose wall |
| Composant grille | leadworks/9 | X 4194.1 ; Y 505.65 ; 26.1 × 4.35 ; pose floor |

### Alimentation du creuset
`lead-primer` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-lead-primer ; point f161-lead-primer ; échelle uniforme 0.69 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant pump | lead-primer/0 | X 4321.41 ; Y 454.53 ; 57.55 × 55.47 ; pose floor |
| Composant tank | lead-primer/1 | X 4416.4 ; Y 422.64 ; 41.6 × 87.36 ; pose floor |
| Composant valve | lead-primer/2 | X 4391.44 ; Y 482.96 ; 18.72 × 18.72 ; pose wall |
| Composant gauge | lead-primer/3 | X 4333.89 ; Y 435.12 ; 16.64 × 16.64 ; pose wall |
| Composant pipe | lead-primer/4 | X 4370.64 ; Y 489.89 ; 58.24 × 6.93 ; pose wall |
| Composant pipe | lead-primer/5 | X 4425.41 ; Y 422.64 ; 5.55 × 13.17 ; pose wall |
| Composant junction | lead-primer/6 | X 4308.24 ; Y 467.01 ; 15.95 × 17.33 ; pose wall |
| Composant drain | lead-primer/7 | X 4304.08 ; Y 506.53 ; 80.43 × 3.47 ; pose floor |
| Composant lamp | lead-primer/8 | X 4370.64 ; Y 406 ; 25.65 × 6.93 ; pose ceiling |
| Composant stencil | lead-primer/9 | X 4316.56 ; Y 413.63 ; 49.92 × 12.48 ; pose wall |
| Raccord | lead-primer-lighting-run | lead-primer/6 → lead-primer/8 |

### Collecteur d’eau supérieur
`water-header` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-sprinkler ; point f161-sprinkler ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant pump | water-header/0 | X 4475.5 ; Y 250 ; 83 × 80 ; pose floor |
| Composant tank | water-header/1 | X 4612.5 ; Y 204 ; 60 × 126 ; pose floor |
| Composant valve | water-header/2 | X 4576.5 ; Y 291 ; 27 × 27 ; pose wall |
| Composant gauge | water-header/3 | X 4493.5 ; Y 222 ; 24 × 24 ; pose wall |
| Composant pipe | water-header/4 | X 4546.5 ; Y 301 ; 84 × 10 ; pose wall |
| Composant pipe | water-header/5 | X 4625.5 ; Y 204 ; 8 × 19 ; pose wall |
| Composant junction | water-header/6 | X 4456.5 ; Y 268 ; 23 × 25 ; pose wall |
| Composant drain | water-header/7 | X 4450.5 ; Y 325 ; 116 × 5 ; pose floor |
| Composant lamp | water-header/8 | X 4546.5 ; Y 180 ; 37 × 10 ; pose ceiling |
| Composant stencil | water-header/9 | X 4468.5 ; Y 191 ; 72 × 18 ; pose wall |
| Raccord | water-header-lighting-run | water-header/6 → water-header/8 |

### Pistons supérieurs
`piston-upper` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-piston-b-node ; point f161-piston-b-node ; échelle uniforme 0.6 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant piston | piston-upper/0 | X 4750.34 ; Y 258.55 ; 34.53 × 71.45 ; pose floor |
| Composant piston | piston-upper/1 | X 4806.9 ; Y 258.55 ; 34.53 × 71.45 ; pose floor |
| Composant piston | piston-upper/2 | X 4863.47 ; Y 258.55 ; 34.53 × 71.45 ; pose floor |
| Composant pipe | piston-upper/3 | X 4747.36 ; Y 247.83 ; 149.45 × 6.55 ; pose wall |
| Composant gauge | piston-upper/4 | X 4848.58 ; Y 288.32 ; 13.69 × 13.69 ; pose wall |
| Composant valve | piston-upper/5 | X 4787.25 ; Y 298.44 ; 14.29 × 14.29 ; pose wall |
| Composant junction | piston-upper/6 | X 4789.63 ; Y 265.69 ; 13.69 × 16.67 ; pose wall |
| Composant lamp | piston-upper/7 | X 4810.47 ; Y 235.33 ; 25.01 × 6.55 ; pose ceiling |
| Composant stencil | piston-upper/8 | X 4749.15 ; Y 232.95 ; 44.66 × 10.72 ; pose wall |
| Composant drain | piston-upper/9 | X 4787.85 ; Y 327.02 ; 75.02 × 2.98 ; pose floor |
| Raccord | piston-upper-lighting-run | piston-upper/6 → piston-upper/7 |

### Moule de coulée
`mold` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-mold ; point f161-mold ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant mold | mold/0 | X 4787.5 ; Y 468 ; 231 × 42 ; pose floor |
| Composant pipe | mold/1 | X 4807.5 ; Y 414 ; 195 × 9 ; pose wall |
| Composant valve | mold/2 | X 4997.5 ; Y 414 ; 26 × 26 ; pose wall |
| Composant gauge | mold/3 | X 4793.5 ; Y 421 ; 23 × 23 ; pose wall |
| Composant lamp | mold/4 | X 4840.5 ; Y 367 ; 105 × 12 ; pose ceiling |
| Composant grille | mold/5 | X 4787.5 ; Y 501 ; 229 × 9 ; pose floor |
| Composant stencil | mold/6 | X 4861.5 ; Y 391 ; 91 × 20 ; pose wall |
| Composant junction | mold/7 | X 5032.5 ; Y 439 ; 24 × 37 ; pose wall |
| Raccord | mold-lighting-run | mold/7 → mold/4 |

### Retour hydraulique
`lower-pressure` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-pressure-alcove-v95 ; point f161-pressure-alcove-v95 ; échelle uniforme 0.87 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant pump | lower-pressure/0 | X 4706.39 ; Y 560.31 ; 72.3 × 69.69 ; pose floor |
| Composant tank | lower-pressure/1 | X 4825.73 ; Y 520.24 ; 52.27 × 109.76 ; pose floor |
| Composant valve | lower-pressure/2 | X 4794.37 ; Y 596.03 ; 23.52 × 23.52 ; pose wall |
| Composant gauge | lower-pressure/3 | X 4722.07 ; Y 535.92 ; 20.91 × 20.91 ; pose wall |
| Composant pipe | lower-pressure/4 | X 4768.24 ; Y 604.74 ; 73.17 × 8.71 ; pose wall |
| Composant pipe | lower-pressure/5 | X 4837.06 ; Y 520.24 ; 6.97 × 16.55 ; pose wall |
| Composant junction | lower-pressure/6 | X 4689.84 ; Y 575.99 ; 20.04 × 21.78 ; pose wall |
| Composant drain | lower-pressure/7 | X 4684.61 ; Y 625.64 ; 101.05 × 4.36 ; pose floor |
| Composant lamp | lower-pressure/8 | X 4768.24 ; Y 499.33 ; 32.23 × 8.71 ; pose ceiling |
| Composant stencil | lower-pressure/9 | X 4700.29 ; Y 508.92 ; 62.72 × 15.68 ; pose wall |
| Raccord | lower-pressure-lighting-run | lower-pressure/6 → lower-pressure/8 |

### Four principal
`main-furnace` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-furnace ; point f161-furnace ; échelle uniforme 0.57 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant furnace | main-furnace/0 | X 5414.57 ; Y 406 ; 101.71 × 104 ; pose floor |
| Composant pipe | main-furnace/1 | X 5524.86 ; Y 437.43 ; 8 × 65.71 ; pose wall |
| Composant gauge | main-furnace/2 | X 5522.57 ; Y 454 ; 14.29 × 14.29 ; pose wall |
| Composant slag | main-furnace/3 | X 5538 ; Y 490 ; 20 × 20 ; pose floor |
| Composant lamp | main-furnace/4 | X 5408.86 ; Y 399.71 ; 20.57 × 6.29 ; pose ceiling |
| Composant stencil | main-furnace/5 | X 5526.57 ; Y 418.57 ; 27.43 × 10.86 ; pose wall |
| Composant grille | main-furnace/6 | X 5412.29 ; Y 503.14 ; 105.71 × 6.86 ; pose floor |
| Composant junction | main-furnace/7 | X 5539.71 ; Y 459.14 ; 13.14 × 20.57 ; pose wall |
| Raccord | main-furnace-lighting-run | main-furnace/7 → main-furnace/4 |

### Commande de passerelle
`furnace-gantry` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-furnace-high ; point f161-furnace-high ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant winch | furnace-gantry/0 | X 5270.5 ; Y 262 ; 80 × 68 ; pose floor |
| Composant junction | furnace-gantry/1 | X 5381.5 ; Y 231 ; 36 × 51 ; pose wall |
| Composant pipe | furnace-gantry/2 | X 5255.5 ; Y 214 ; 210 × 9 ; pose wall |
| Composant valve | furnace-gantry/3 | X 5441.5 ; Y 215 ; 26 × 26 ; pose wall |
| Composant lamp | furnace-gantry/4 | X 5371.5 ; Y 176 ; 38 × 11 ; pose ceiling |
| Composant grille | furnace-gantry/5 | X 5256.5 ; Y 322 ; 139 × 8 ; pose floor |
| Composant stencil | furnace-gantry/6 | X 5258.5 ; Y 180 ; 74 × 19 ; pose wall |
| Composant support | furnace-gantry/7 | X 5355.5 ; Y 306 ; 12 × 24 ; pose floor |
| Raccord | furnace-gantry-lighting-run | furnace-gantry/1 → furnace-gantry/4 |

### Approche de la Compagnie
`parley` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-parley-v93 ; point f161-parley-v93 ; échelle uniforme 0.66 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant winch | parley/0 | X 5607.23 ; Y 464.86 ; 53.11 × 45.14 ; pose floor |
| Composant junction | parley/1 | X 5680.91 ; Y 444.28 ; 23.9 × 33.86 ; pose wall |
| Composant pipe | parley/2 | X 5597.27 ; Y 433 ; 139.4 × 5.97 ; pose wall |
| Composant valve | parley/3 | X 5720.74 ; Y 433.66 ; 17.26 × 17.26 ; pose wall |
| Composant lamp | parley/4 | X 5674.27 ; Y 407.77 ; 25.23 × 7.3 ; pose ceiling |
| Composant grille | parley/5 | X 5597.93 ; Y 504.69 ; 92.27 × 5.31 ; pose floor |
| Composant stencil | parley/6 | X 5599.26 ; Y 410.43 ; 49.12 × 12.61 ; pose wall |
| Composant support | parley/7 | X 5663.65 ; Y 494.07 ; 7.97 × 15.93 ; pose floor |
| Raccord | parley-lighting-run | parley/1 → parley/4 |

### Matériel de récupération
`patna-kit` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-patna-cage-node ; point f161-patna-cage-node ; échelle uniforme 0.31 ; condition company. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant recovery | patna-kit/0 | X 5893.16 ; Y 467.15 ; 39.76 × 42.85 ; pose floor |
| Composant case | patna-kit/1 | X 5939.4 ; Y 497.98 ; 20.65 × 12.02 ; pose floor |
| Composant lampstand | patna-kit/2 | X 5964.68 ; Y 467.15 ; 8.32 × 42.85 ; pose floor |
| Composant monitor | patna-kit/3 | X 5941.25 ; Y 486.27 ; 13.25 × 9.25 ; pose wall |
| Composant cable | patna-kit/4 | X 5930.15 ; Y 505.99 ; 14.8 × 2.47 ; pose wall |
| Composant stencil | patna-kit/5 | X 5939.09 ; Y 475.78 ; 23.43 × 6.16 ; pose wall |
| Composant case | patna-kit/6 | X 5887.31 ; Y 499.83 ; 10.79 × 10.17 ; pose floor |
| Composant clamp | patna-kit/7 | X 5908.89 ; Y 485.65 ; 8.01 × 8.32 ; pose wall |

### Plateforme terminale
`final-landing` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-extraction ; point f161-extraction ; échelle uniforme 0.37 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant winch | final-landing/0 | X 6010.91 ; Y 485.11 ; 29.28 × 24.89 ; pose floor |
| Composant junction | final-landing/1 | X 6051.53 ; Y 473.77 ; 13.17 × 18.66 ; pose wall |
| Composant pipe | final-landing/2 | X 6005.42 ; Y 467.55 ; 76.85 × 3.29 ; pose wall |
| Composant valve | final-landing/3 | X 6073.49 ; Y 467.91 ; 9.51 × 9.51 ; pose wall |
| Composant lamp | final-landing/4 | X 6047.87 ; Y 453.64 ; 13.91 × 4.03 ; pose ceiling |
| Composant grille | final-landing/5 | X 6005.78 ; Y 507.07 ; 50.87 × 2.93 ; pose floor |
| Composant stencil | final-landing/6 | X 6006.51 ; Y 455.11 ; 27.08 × 6.95 ; pose wall |
| Composant support | final-landing/7 | X 6042.01 ; Y 501.22 ; 4.39 × 8.78 ; pose floor |
| Raccord | final-landing-lighting-run | final-landing/1 → final-landing/4 |

### Émetteur de service
`final-transmitter` · Assemblages
[Socle V104 conservé] Appui node-platform-f161-final-transmission-v94 ; point f161-final-transmission-v94 ; échelle uniforme 0.67 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

| Élément | Référence | Contrat |
|---|---|---|
| Composant console | final-transmitter/0 | X 6019.68 ; Y 279.13 ; 89.69 × 50.87 ; pose floor |
| Composant rack | final-transmitter/1 | X 6138.82 ; Y 240.98 ; 44.18 × 89.02 ; pose floor |
| Composant monitor | final-transmitter/2 | X 6027.71 ; Y 247.67 ; 34.81 × 25.44 ; pose wall |
| Composant monitor | final-transmitter/3 | X 6069.88 ; Y 247.67 ; 34.81 × 25.44 ; pose wall |
| Composant spool | final-transmitter/4 | X 6118.07 ; Y 310.59 ; 19.41 × 19.41 ; pose floor |
| Composant junction | final-transmitter/5 | X 6114.06 ; Y 257.04 ; 18.07 × 19.41 ; pose wall |
| Composant cable | final-transmitter/6 | X 6101.34 ; Y 274.44 ; 42.17 × 5.35 ; pose wall |
| Composant lamp | final-transmitter/7 | X 6028.38 ; Y 229.6 ; 30.12 × 6.69 ; pose ceiling |
| Composant stencil | final-transmitter/8 | X 6139.49 ; Y 227.59 ; 43.51 × 10.04 ; pose wall |
| Composant stool | final-transmitter/9 | X 6061.18 ; Y 308.58 ; 16.06 × 21.42 ; pose floor |
| Raccord | final-transmitter-lighting-run | final-transmitter/5 → final-transmitter/7 |

### Raccord — Prise d’air côtière
`coast-intake-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | coast-intake/2 | coast-intake |
| Réception | coast-intake/6 | always |
| Sommet | 1 | X 249.5 ; Y 489 |
| Sommet | 2 | X 249.5 ; Y 359 |
| Sommet | 3 | X 147.5 ; Y 359 |
| Sommet | 4 | X 147.5 ; Y 370.5 |

### Raccord — Épave et matériel de secours
`coast-wreck-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | coast-wreck/5 | coast-wreck |
| Réception | coast-wreck/4 | always |
| Sommet | 1 | X 741.5 ; Y 483 |
| Sommet | 2 | X 741.5 ; Y 347 |
| Sommet | 3 | X 586 ; Y 347 |
| Sommet | 4 | X 586 ; Y 358.5 |

### Raccord — Baie mortuaire
`morgue-bay-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | morgue-bay/6 | morgue-bay |
| Réception | morgue-bay/3 | always |
| Sommet | 1 | X 1599.6 ; Y 267.44 |
| Sommet | 2 | X 1599.6 ; Y 233.73 |
| Sommet | 3 | X 1502.24 ; Y 233.73 |
| Sommet | 4 | X 1502.24 ; Y 244.11 |

### Raccord — Réfectoire
`mess-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | mess/6 | mess |
| Réception | mess/7 | always |
| Sommet | 1 | X 2414.5 ; Y 295.5 |
| Sommet | 2 | X 2414.5 ; Y 210 |
| Sommet | 3 | X 2285 ; Y 210 |
| Sommet | 4 | X 2285 ; Y 221 |

### Raccord — Poste de communication
`actual-comms-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | actual-comms/5 | actual-comms |
| Réception | actual-comms/7 | always |
| Sommet | 1 | X 2741.7 ; Y 290.56 |
| Sommet | 2 | X 2741.7 ; Y 250.65 |
| Sommet | 3 | X 2666.85 ; Y 250.65 |
| Sommet | 4 | X 2666.85 ; Y 258.79 |

### Raccord — Ventilateur de maintenance
`murphy-fan-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | murphy-fan/2 | murphy-fan |
| Réception | murphy-fan/7 | always |
| Sommet | 1 | X 2976.22 ; Y 281.5 |
| Sommet | 2 | X 2976.22 ; Y 263.61 |
| Sommet | 3 | X 2908.9 ; Y 263.61 |
| Sommet | 4 | X 2908.9 ; Y 270.66 |

### Raccord — Pompage des galeries
`service-pump-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | service-pump/6 | service-pump |
| Réception | service-pump/8 | always |
| Sommet | 1 | X 2978 ; Y 460.5 |
| Sommet | 2 | X 2978 ; Y 355 |
| Sommet | 3 | X 3075 ; Y 355 |
| Sommet | 4 | X 3075 ; Y 365 |

### Raccord — Entretien des réseaux
`service-shop-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | service-shop/5 | service-shop |
| Réception | service-shop/4 | always |
| Sommet | 1 | X 3088.93 ; Y 290.14 |
| Sommet | 2 | X 3088.93 ; Y 263.09 |
| Sommet | 3 | X 3047.51 ; Y 263.09 |
| Sommet | 4 | X 3047.51 ; Y 270.54 |

### Raccord — Recharge des batteries
`battery-store-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | battery-store/5 | battery-store |
| Réception | battery-store/4 | always |
| Sommet | 1 | X 3540.36 ; Y 245.01 |
| Sommet | 2 | X 3540.36 ; Y 193.01 |
| Sommet | 3 | X 3452.05 ; Y 193.01 |
| Sommet | 4 | X 3452.05 ; Y 203.23 |

### Raccord — Réserve de produits
`chemical-store-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | chemical-store/0 | chemical-store |
| Réception | chemical-store/4 | always |
| Sommet | 1 | X 3603.52 ; Y 466.51 |
| Sommet | 2 | X 3603.52 ; Y 398.92 |
| Sommet | 3 | X 3660.45 ; Y 398.92 |
| Sommet | 4 | X 3660.45 ; Y 407.45 |

### Raccord — Supervision de la fonderie
`command-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | command/5 | command |
| Réception | command/7 | always |
| Sommet | 1 | X 3981.7 ; Y 450.56 |
| Sommet | 2 | X 3981.7 ; Y 410.65 |
| Sommet | 3 | X 3906.85 ; Y 410.65 |
| Sommet | 4 | X 3906.85 ; Y 418.79 |

### Raccord — Collecte des effluents
`waste-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | waste/6 | waste |
| Réception | waste/8 | always |
| Sommet | 1 | X 3978 ; Y 580.5 |
| Sommet | 2 | X 3978 ; Y 475 |
| Sommet | 3 | X 4075 ; Y 475 |
| Sommet | 4 | X 4075 ; Y 485 |

### Raccord — Alimentation du creuset
`lead-primer-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | lead-primer/6 | lead-primer |
| Réception | lead-primer/8 | always |
| Sommet | 1 | X 4316.21 ; Y 475.68 |
| Sommet | 2 | X 4316.21 ; Y 401 |
| Sommet | 3 | X 4383.47 ; Y 401 |
| Sommet | 4 | X 4383.47 ; Y 409.47 |

### Raccord — Collecteur d’eau supérieur
`water-header-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | water-header/6 | water-header |
| Réception | water-header/8 | always |
| Sommet | 1 | X 4468 ; Y 280.5 |
| Sommet | 2 | X 4468 ; Y 175 |
| Sommet | 3 | X 4565 ; Y 175 |
| Sommet | 4 | X 4565 ; Y 185 |

### Raccord — Pistons supérieurs
`piston-upper-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | piston-upper/6 | piston-upper |
| Réception | piston-upper/7 | always |
| Sommet | 1 | X 4796.48 ; Y 274.03 |
| Sommet | 2 | X 4796.48 ; Y 230.33 |
| Sommet | 3 | X 4822.98 ; Y 230.33 |
| Sommet | 4 | X 4822.98 ; Y 238.6 |

### Raccord — Moule de coulée
`mold-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | mold/7 | mold |
| Réception | mold/4 | always |
| Sommet | 1 | X 5044.5 ; Y 457.5 |
| Sommet | 2 | X 5044.5 ; Y 362 |
| Sommet | 3 | X 4893 ; Y 362 |
| Sommet | 4 | X 4893 ; Y 373 |

### Raccord — Retour hydraulique
`lower-pressure-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | lower-pressure/6 | lower-pressure |
| Réception | lower-pressure/8 | always |
| Sommet | 1 | X 4699.86 ; Y 586.88 |
| Sommet | 2 | X 4699.86 ; Y 494.33 |
| Sommet | 3 | X 4784.36 ; Y 494.33 |
| Sommet | 4 | X 4784.36 ; Y 503.69 |

### Raccord — Four principal
`main-furnace-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | main-furnace/7 | main-furnace |
| Réception | main-furnace/4 | always |
| Sommet | 1 | X 5546.29 ; Y 469.43 |
| Sommet | 2 | X 5546.29 ; Y 394.71 |
| Sommet | 3 | X 5419.14 ; Y 394.71 |
| Sommet | 4 | X 5419.14 ; Y 402.86 |

### Raccord — Commande de passerelle
`furnace-gantry-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | furnace-gantry/1 | furnace-gantry |
| Réception | furnace-gantry/4 | always |
| Sommet | 1 | X 5399.5 ; Y 256.5 |
| Sommet | 2 | X 5399.5 ; Y 171 |
| Sommet | 3 | X 5390.5 ; Y 171 |
| Sommet | 4 | X 5390.5 ; Y 181.5 |

### Raccord — Approche de la Compagnie
`parley-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | parley/1 | parley |
| Réception | parley/4 | always |
| Sommet | 1 | X 5692.86 ; Y 461.21 |
| Sommet | 2 | X 5692.86 ; Y 402.77 |
| Sommet | 3 | X 5686.89 ; Y 402.77 |
| Sommet | 4 | X 5686.89 ; Y 411.42 |

### Raccord — Plateforme terminale
`final-landing-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | final-landing/1 | final-landing |
| Réception | final-landing/4 | always |
| Sommet | 1 | X 6058.11 ; Y 483.1 |
| Sommet | 2 | X 6058.11 ; Y 448.64 |
| Sommet | 3 | X 6054.82 ; Y 448.64 |
| Sommet | 4 | X 6054.82 ; Y 455.66 |

### Raccord — Émetteur de service
`final-transmitter-lighting-run` · Réseaux
[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

| Élément | Référence | Contrat |
|---|---|---|
| Source | final-transmitter/5 | final-transmitter |
| Réception | final-transmitter/7 | always |
| Sommet | 1 | X 6123.09 ; Y 266.75 |
| Sommet | 2 | X 6123.09 ; Y 224.6 |
| Sommet | 3 | X 6043.44 ; Y 224.6 |
| Sommet | 4 | X 6043.44 ; Y 232.94 |

### Éclairage de la prise d’air
`shore-light` · Commandes
[Socle V104 conservé] Action I ; support node-platform-f161-spawn, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

| Élément | Référence | Contrat |
|---|---|---|
| Commande | shore-light | X 259.5 ; Y 456 ; 13 × 29 |
| Lampe | coast-intake/6 | Récepteur réellement dessiné |

### Lampe de soin
`care-light` · Commandes
[Socle V104 conservé] Action I ; support node-platform-f161-infirmary, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

| Élément | Référence | Contrat |
|---|---|---|
| Commande | care-light | X 1225 ; Y 456 ; 13 × 29 |
| Lampe | medical-care/7 | Récepteur réellement dessiné |
| Ronde originale | 1 | Doit être rallumée à son tour. La même commande hors ronde ne termine aucune quête. |

### Éclairage de la coursive
`cell-light` · Commandes
[Socle V104 conservé] Action I ; support node-platform-f161-cell-a, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

| Élément | Référence | Contrat |
|---|---|---|
| Commande | cell-light | X 2020 ; Y 456 ; 13 × 29 |
| Lampe | cell-a/3 | Récepteur réellement dessiné |
| Ronde originale | 2 | Doit être rallumée à son tour. La même commande hors ronde ne termine aucune quête. |

### Lampe des communications
`comms-light` · Commandes
[Socle V104 conservé] Action I ; support node-platform-f161-comms-high, pied Y 350 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

| Élément | Référence | Contrat |
|---|---|---|
| Commande | comms-light | X 2785 ; Y 296 ; 13 × 29 |
| Lampe | actual-comms/7 | Récepteur réellement dessiné |

### Lampe de l’établi
`service-light` · Commandes
[Socle V104 conservé] Action I ; support node-platform-f161-service-high, pied Y 330 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

| Élément | Référence | Contrat |
|---|---|---|
| Commande | service-light | X 3110 ; Y 276 ; 13 × 29 |
| Lampe | service-shop/4 | Récepteur réellement dessiné |
| Ronde originale | 3 | Doit être rallumée à son tour. La même commande hors ronde ne termine aucune quête. |

### Éclairage du creuset
`lead-light` · Commandes
[Socle V104 conservé] Action I ; support node-platform-f161-leadworks, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

| Élément | Référence | Contrat |
|---|---|---|
| Commande | lead-light | X 4265 ; Y 456 ; 13 × 29 |
| Lampe | leadworks/7 | Récepteur réellement dessiné |

### Lampe du moule
`mold-light` · Commandes
[Socle V104 conservé] Action I ; support node-platform-f161-mold, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

| Élément | Référence | Contrat |
|---|---|---|
| Commande | mold-light | X 5043.5 ; Y 456 ; 13 × 29 |
| Lampe | mold/4 | Récepteur réellement dessiné |

### Éclairage de la plateforme
`landing-light` · Commandes
[Socle V104 conservé] Action I ; support node-platform-f161-extraction, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

| Élément | Référence | Contrat |
|---|---|---|
| Commande | landing-light | X 6070 ; Y 456 ; 13 × 29 |
| Lampe | final-landing/4 | Récepteur réellement dessiné |

### Accès aux cellules
`f161-infirmary-gate` · Portes
[Socle V104 conservé] Porte historique. Cadre, feuille et seuil suivent ses dimensions ; le dessin ne crée ni nouveau verrou ni nouvelle condition d’ouverture. Une feuille ouverte ne reste pas opaque devant le chemin. La fermeture peut refuser un contact du Runner et l’accès à une commande située derrière.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-infirmary | Sol 510 |
| Arrivée | f161-cell-a | Sol 510 |
| Cadre | f161-infirmary-gate | X 1488 ; Y 378 ; 44 × 132 |
| Source | template-derived | Géométrie native utilisée si fournie au compilateur. |

### Galeries de service
`f161-cellblock-gate` · Portes
[Socle V104 conservé] Porte historique. Cadre, feuille et seuil suivent ses dimensions ; le dessin ne crée ni nouveau verrou ni nouvelle condition d’ouverture. Une feuille ouverte ne reste pas opaque devant le chemin. La fermeture peut refuser un contact du Runner et l’accès à une commande située derrière.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-cell-b | Sol 510 |
| Arrivée | f161-service-low | Sol 510 |
| Cadre | f161-cellblock-gate | X 2823 ; Y 378 ; 44 × 132 |
| Source | template-derived | Géométrie native utilisée si fournie au compilateur. |

### Accès à la fonderie
`f161-leadworks-gate` · Portes
[Socle V104 conservé] Porte historique. Cadre, feuille et seuil suivent ses dimensions ; le dessin ne crée ni nouveau verrou ni nouvelle condition d’ouverture. Une feuille ouverte ne reste pas opaque devant le chemin. La fermeture peut refuser un contact du Runner et l’accès à une commande située derrière.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-bishop | Sol 510 |
| Arrivée | f161-leadworks | Sol 510 |
| Cadre | f161-leadworks-gate | X 3828 ; Y 378 ; 44 × 132 |
| Source | template-derived | Géométrie native utilisée si fournie au compilateur. |

### spawn
`f161-spawn` · Points
[Socle V104 conservé] Position X 180, pied Y 510, largeur 260. Section descriptive : Côte et épave. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-eev | Marche ; f161-e01 |

### eev
`f161-eev` · Points
[Socle V104 conservé] Position X 620, pied Y 510, largeur 300. Section descriptive : Côte et épave. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-spawn | Marche ; f161-e01 |
| Voisin | f161-infirmary | Marche ; f161-e02 |
| Voisin | f161-flight-analysis-v94 | Échelle ; f161-e89 |
| Voisin | f161-wreckage-incident-v94 | Échelle ; f161-e91 |

### infirmary
`f161-infirmary` · Points
[Socle V104 conservé] Position X 1120, pied Y 510, largeur 300. Section descriptive : Infirmerie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-eev | Marche ; f161-e02 |
| Voisin | f161-cell-a | Porte ; f161-e03 |
| Voisin | f161-morgue-high | Échelle ; f161-e12 |
| Voisin | f161-service-deep | Conduit ; f161-e19 |
| Voisin | f161-clemens-bed | Marche ; f161-e46 |
| Voisin | f161-wreckage-incident-v94 | Échelle ; f161-e92 |

### morgue high
`f161-morgue-high` · Points
[Socle V104 conservé] Position X 1500, pied Y 350, largeur 260. Section descriptive : Morgue et dossiers. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-infirmary | Échelle ; f161-e12 |
| Voisin | f161-mess-high | Marche ; f161-e13 |
| Voisin | f161-funeral-walk | Échelle ; f161-e48 |
| Voisin | f161-master-archive-node | Marche ; f161-e62 |
| Voisin | f161-flight-analysis-v94 | Marche ; f161-e90 |

### cell a
`f161-cell-a` · Points
[Socle V104 conservé] Position X 1900, pied Y 510, largeur 300. Section descriptive : Cellules ouest. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-infirmary | Porte ; f161-e03 |
| Voisin | f161-mess-high | Échelle ; f161-e23 |
| Voisin | f161-assembly-hall | Marche ; f161-e27 |
| Voisin | f161-shelter-cell-v95 | Échelle ; f161-e104 |

### mess high
`f161-mess-high` · Points
[Socle V104 conservé] Position X 2320, pied Y 350, largeur 280. Section descriptive : Réfectoire. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-morgue-high | Marche ; f161-e13 |
| Voisin | f161-service-high | Marche ; f161-e14 |
| Voisin | f161-cell-a | Échelle ; f161-e23 |
| Voisin | f161-assembly-hall | Échelle ; f161-e29 |
| Voisin | f161-mess-ceiling | Marche ; f161-e49 |
| Voisin | f161-faith-dais-v94 | Échelle ; f161-e93 |

### cell b
`f161-cell-b` · Points
[Socle V104 conservé] Position X 2620, pied Y 510, largeur 300. Section descriptive : Cellules est. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-service-low | Porte ; f161-e05 |
| Voisin | f161-assembly-hall | Marche ; f161-e28 |
| Voisin | f161-shutter-cell-node | Marche ; f161-e63 |

### service low
`f161-service-low` · Points
[Socle V104 conservé] Position X 3070, pied Y 510, largeur 300. Section descriptive : Pompage et secours. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-cell-b | Porte ; f161-e05 |
| Voisin | f161-bishop | Marche ; f161-e06 |
| Voisin | f161-service-high | Échelle ; f161-e24 |
| Voisin | f161-service-deep | Échelle ; f161-e25 |
| Voisin | f161-fuel-manifold-a | Marche ; f161-e35 |
| Voisin | f161-rescue-post-node | Marche ; f161-e67 |

### service high
`f161-service-high` · Points
[Socle V104 conservé] Position X 3070, pied Y 330, largeur 280. Section descriptive : Ventilation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-mess-high | Marche ; f161-e14 |
| Voisin | f161-tunnel-high | Marche ; f161-e15 |
| Voisin | f161-service-low | Échelle ; f161-e24 |
| Voisin | f161-fan-shaft | Marche ; f161-e51 |
| Voisin | f161-steam-service-node | Marche ; f161-e65 |
| Voisin | f161-perch-service-v93 | Échelle ; f161-e80 |
| Voisin | f161-battery-locker-v94 | Marche ; f161-e95 |
| Voisin | f161-hunt-service-v95 | Marche ; f161-e110 |

### service deep
`f161-service-deep` · Points
[Socle V104 conservé] Position X 3070, pied Y 630, largeur 280. Section descriptive : Galeries basses. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-infirmary | Conduit ; f161-e19 |
| Voisin | f161-tunnel-low | Marche ; f161-e20 |
| Voisin | f161-service-low | Échelle ; f161-e25 |
| Voisin | f161-tunnel-shrine | Marche ; f161-e52 |
| Voisin | f161-refuge-service-v95 | Marche ; f161-e108 |

### bishop
`f161-bishop` · Points
[Socle V104 conservé] Position X 3500, pied Y 510, largeur 300. Section descriptive : Pompage et secours. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-service-low | Marche ; f161-e06 |
| Voisin | f161-leadworks | Porte ; f161-e07 |
| Voisin | f161-fuel-manifold-b | Marche ; f161-e37 |
| Voisin | f161-chemical-store | Marche ; f161-e38 |
| Voisin | f161-tunnel-shrine | Échelle ; f161-e53 |
| Voisin | f161-rescue-post-node | Marche ; f161-e68 |
| Voisin | f161-shutter-service-node | Marche ; f161-e69 |

### tunnel high
`f161-tunnel-high` · Points
[Socle V104 conservé] Position X 3820, pied Y 330, largeur 280. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-service-high | Marche ; f161-e15 |
| Voisin | f161-sprinkler | Marche ; f161-e16 |
| Voisin | f161-chemical-store | Échelle ; f161-e39 |
| Voisin | f161-command-post-node | Échelle ; f161-e71 |
| Voisin | f161-battery-locker-v94 | Marche ; f161-e96 |
| Voisin | f161-battery-junction-v94 | Marche ; f161-e99 |

### tunnel low
`f161-tunnel-low` · Points
[Socle V104 conservé] Position X 3820, pied Y 630, largeur 280. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-service-deep | Marche ; f161-e20 |
| Voisin | f161-leadworks | Échelle ; f161-e21 |
| Voisin | f161-waste-tank | Marche ; f161-e30 |
| Voisin | f161-golic-cache-v94 | Marche ; f161-e98 |
| Voisin | f161-hunt-junction-v95 | Marche ; f161-e114 |

### leadworks
`f161-leadworks` · Points
[Socle V104 conservé] Position X 4200, pied Y 510, largeur 340. Section descriptive : Fonderie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-bishop | Porte ; f161-e07 |
| Voisin | f161-mold | Marche ; f161-e08 |
| Voisin | f161-tunnel-low | Échelle ; f161-e21 |
| Voisin | f161-furnace | Conduit ; f161-e22 |
| Voisin | f161-sprinkler | Échelle ; f161-e26 |
| Voisin | f161-sluice-low | Échelle ; f161-e32 |
| Voisin | f161-lead-primer | Marche ; f161-e40 |
| Voisin | f161-piston-a-node | Marche ; f161-e54 |
| Voisin | f161-command-post-node | Marche ; f161-e72 |

### sprinkler
`f161-sprinkler` · Points
[Socle V104 conservé] Position X 4560, pied Y 330, largeur 280. Section descriptive : Collecteur supérieur. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-tunnel-high | Marche ; f161-e16 |
| Voisin | f161-furnace-high | Marche ; f161-e17 |
| Voisin | f161-leadworks | Échelle ; f161-e26 |
| Voisin | f161-water-header | Marche ; f161-e42 |
| Voisin | f161-piston-b-node | Marche ; f161-e56 |
| Voisin | f161-bait-switch-v95 | Marche ; f161-e117 |

### mold
`f161-mold` · Points
[Socle V104 conservé] Position X 4920, pied Y 510, largeur 360. Section descriptive : Moule et pistons. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-leadworks | Marche ; f161-e08 |
| Voisin | f161-furnace | Marche ; f161-e09 |
| Voisin | f161-lead-primer | Marche ; f161-e41 |
| Voisin | f161-water-header | Échelle ; f161-e43 |
| Voisin | f161-piston-a-node | Marche ; f161-e55 |
| Voisin | f161-piston-b-node | Échelle ; f161-e57 |
| Voisin | f161-piston-c-node | Marche ; f161-e58 |
| Voisin | f161-shutter-foundry-node | Marche ; f161-e75 |
| Voisin | f161-chase-reroute-v94 | Échelle ; f161-e101 |

### furnace high
`f161-furnace-high` · Points
[Socle V104 conservé] Position X 5350, pied Y 330, largeur 280. Section descriptive : Passerelles du four. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-sprinkler | Marche ; f161-e17 |
| Voisin | f161-furnace | Échelle ; f161-e18 |
| Voisin | f161-furnace-gantry | Marche ; f161-e33 |
| Voisin | f161-furnace-overlook | Marche ; f161-e44 |
| Voisin | f161-chase-observer-v95 | Marche ; f161-e119 |

### furnace
`f161-furnace` · Points
[Socle V104 conservé] Position X 5480, pied Y 510, largeur 340. Section descriptive : Four principal. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-mold | Marche ; f161-e09 |
| Voisin | f161-company | Marche ; f161-e10 |
| Voisin | f161-furnace-high | Échelle ; f161-e18 |
| Voisin | f161-leadworks | Conduit ; f161-e22 |
| Voisin | f161-piston-c-node | Marche ; f161-e59 |
| Voisin | f161-parley-v93 | Marche ; f161-e85 |
| Voisin | f161-chase-reroute-v94 | Échelle ; f161-e102 |

### company
`f161-company` · Points
[Socle V104 conservé] Position X 5800, pied Y 510, largeur 300. Section descriptive : Approche et plateforme. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-furnace | Marche ; f161-e10 |
| Voisin | f161-extraction | Marche ; f161-e11 |
| Voisin | f161-furnace-gantry | Échelle ; f161-e34 |
| Voisin | f161-furnace-overlook | Échelle ; f161-e45 |
| Voisin | f161-patna-cage-node | Marche ; f161-e60 |
| Voisin | f161-parley-v93 | Marche ; f161-e86 |
| Voisin | f161-witness-v93 | Échelle ; f161-e87 |

### extraction
`f161-extraction` · Points
[Socle V104 conservé] Position X 6040, pied Y 510, largeur 300. Section descriptive : Approche et plateforme. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-company | Marche ; f161-e11 |
| Voisin | f161-patna-cage-node | Marche ; f161-e61 |
| Voisin | f161-witness-v93 | Échelle ; f161-e88 |

### assembly hall
`f161-assembly-hall` · Points
[Socle V104 conservé] Position X 2300, pied Y 510, largeur 300. Section descriptive : Cellules ouest. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-cell-a | Marche ; f161-e27 |
| Voisin | f161-cell-b | Marche ; f161-e28 |
| Voisin | f161-mess-high | Échelle ; f161-e29 |
| Voisin | f161-shelter-cell-v95 | Échelle ; f161-e105 |

### waste tank
`f161-waste-tank` · Points
[Socle V104 conservé] Position X 4070, pied Y 630, largeur 310. Section descriptive : Cuve et évacuation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-tunnel-low | Marche ; f161-e30 |
| Voisin | f161-sluice-low | Marche ; f161-e31 |
| Voisin | f161-hunt-junction-v95 | Marche ; f161-e115 |

### sluice low
`f161-sluice-low` · Points
[Socle V104 conservé] Position X 4500, pied Y 630, largeur 280. Section descriptive : Cuve et évacuation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-waste-tank | Marche ; f161-e31 |
| Voisin | f161-leadworks | Échelle ; f161-e32 |

### furnace gantry
`f161-furnace-gantry` · Points
[Socle V104 conservé] Position X 5740, pied Y 330, largeur 280. Section descriptive : Passerelles du four. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-furnace-high | Marche ; f161-e33 |
| Voisin | f161-company | Échelle ; f161-e34 |

### fuel manifold a
`f161-fuel-manifold-a` · Points
[Socle V104 conservé] Position X 2960, pied Y 510, largeur 180. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-service-low | Marche ; f161-e35 |
| Voisin | f161-fuel-manifold-b | Marche ; f161-e36 |

### fuel manifold b
`f161-fuel-manifold-b` · Points
[Socle V104 conservé] Position X 3240, pied Y 510, largeur 180. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-fuel-manifold-a | Marche ; f161-e36 |
| Voisin | f161-bishop | Marche ; f161-e37 |

### chemical store
`f161-chemical-store` · Points
[Socle V104 conservé] Position X 3670, pied Y 510, largeur 210. Section descriptive : Réserve et supervision. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-bishop | Marche ; f161-e38 |
| Voisin | f161-tunnel-high | Échelle ; f161-e39 |
| Voisin | f161-shutter-service-node | Marche ; f161-e70 |

### lead primer
`f161-lead-primer` · Points
[Socle V104 conservé] Position X 4380, pied Y 510, largeur 190. Section descriptive : Fonderie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-leadworks | Marche ; f161-e40 |
| Voisin | f161-mold | Marche ; f161-e41 |

### water header
`f161-water-header` · Points
[Socle V104 conservé] Position X 4690, pied Y 330, largeur 190. Section descriptive : Collecteur supérieur. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-sprinkler | Marche ; f161-e42 |
| Voisin | f161-mold | Échelle ; f161-e43 |
| Voisin | f161-steam-lead-node | Marche ; f161-e73 |
| Voisin | f161-battery-junction-v94 | Marche ; f161-e100 |

### furnace overlook
`f161-furnace-overlook` · Points
[Socle V104 conservé] Position X 5580, pied Y 330, largeur 220. Section descriptive : Passerelles du four. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-furnace-high | Marche ; f161-e44 |
| Voisin | f161-company | Échelle ; f161-e45 |

### clemens bed
`f161-clemens-bed` · Points
[Socle V104 conservé] Position X 1380, pied Y 510, largeur 180. Section descriptive : Infirmerie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-infirmary | Marche ; f161-e46 |
| Voisin | f161-funeral-walk | Marche ; f161-e47 |

### funeral walk
`f161-funeral-walk` · Points
[Socle V104 conservé] Position X 1580, pied Y 510, largeur 180. Section descriptive : Infirmerie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-clemens-bed | Marche ; f161-e47 |
| Voisin | f161-morgue-high | Échelle ; f161-e48 |

### mess ceiling
`f161-mess-ceiling` · Points
[Socle V104 conservé] Position X 2470, pied Y 350, largeur 190. Section descriptive : Réfectoire. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-mess-high | Marche ; f161-e49 |
| Voisin | f161-comms-high | Marche ; f161-e50 |
| Voisin | f161-perch-cell-v93 | Échelle ; f161-e77 |

### comms high
`f161-comms-high` · Points
[Socle V104 conservé] Position X 2720, pied Y 350, largeur 180. Section descriptive : Communications. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-mess-ceiling | Marche ; f161-e50 |
| Voisin | f161-shutter-cell-node | Échelle ; f161-e64 |
| Voisin | f161-perch-cell-v93 | Échelle ; f161-e78 |
| Voisin | f161-watch-cell-v95 | Échelle ; f161-e107 |

### fan shaft
`f161-fan-shaft` · Points
[Socle V104 conservé] Position X 2940, pied Y 330, largeur 170. Section descriptive : Ventilation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-service-high | Marche ; f161-e51 |
| Voisin | f161-steam-service-node | Marche ; f161-e66 |

### tunnel shrine
`f161-tunnel-shrine` · Points
[Socle V104 conservé] Position X 3420, pied Y 630, largeur 210. Section descriptive : Galeries basses. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-service-deep | Marche ; f161-e52 |
| Voisin | f161-bishop | Échelle ; f161-e53 |
| Voisin | f161-golic-cache-v94 | Marche ; f161-e97 |
| Voisin | f161-refuge-service-v95 | Marche ; f161-e109 |

### piston a node
`f161-piston-a-node` · Points
[Socle V104 conservé] Position X 4480, pied Y 510, largeur 180. Section descriptive : Fonderie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-leadworks | Marche ; f161-e54 |
| Voisin | f161-mold | Marche ; f161-e55 |

### piston b node
`f161-piston-b-node` · Points
[Socle V104 conservé] Position X 4820, pied Y 330, largeur 180. Section descriptive : Collecteur supérieur. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-sprinkler | Marche ; f161-e56 |
| Voisin | f161-mold | Échelle ; f161-e57 |
| Voisin | f161-steam-lead-node | Marche ; f161-e74 |
| Voisin | f161-perch-lead-v93 | Échelle ; f161-e84 |

### piston c node
`f161-piston-c-node` · Points
[Socle V104 conservé] Position X 5140, pied Y 510, largeur 180. Section descriptive : Moule et pistons. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-mold | Marche ; f161-e58 |
| Voisin | f161-furnace | Marche ; f161-e59 |
| Voisin | f161-shutter-foundry-node | Marche ; f161-e76 |

### patna cage node
`f161-patna-cage-node` · Points
[Socle V104 conservé] Position X 5930, pied Y 510, largeur 160. Section descriptive : Approche et plateforme. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-company | Marche ; f161-e60 |
| Voisin | f161-extraction | Marche ; f161-e61 |

### master archive node
`f161-master-archive-node` · Points
[Socle V104 conservé] Position X 1260, pied Y 350, largeur 170. Section descriptive : Morgue et dossiers. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-morgue-high | Marche ; f161-e62 |

### shutter cell node
`f161-shutter-cell-node` · Points
[Socle V104 conservé] Position X 2740, pied Y 510, largeur 160. Section descriptive : Cellules est. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-cell-b | Marche ; f161-e63 |
| Voisin | f161-comms-high | Échelle ; f161-e64 |

### steam service node
`f161-steam-service-node` · Points
[Socle V104 conservé] Position X 3190, pied Y 330, largeur 160. Section descriptive : Ventilation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-service-high | Marche ; f161-e65 |
| Voisin | f161-fan-shaft | Marche ; f161-e66 |
| Voisin | f161-perch-service-v93 | Échelle ; f161-e79 |

### rescue post node
`f161-rescue-post-node` · Points
[Socle V104 conservé] Position X 3330, pied Y 510, largeur 170. Section descriptive : Pompage et secours. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-service-low | Marche ; f161-e67 |
| Voisin | f161-bishop | Marche ; f161-e68 |
| Voisin | f161-triage-v93 | Marche ; f161-e81 |

### shutter service node
`f161-shutter-service-node` · Points
[Socle V104 conservé] Position X 3650, pied Y 510, largeur 160. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-bishop | Marche ; f161-e69 |
| Voisin | f161-chemical-store | Marche ; f161-e70 |
| Voisin | f161-triage-v93 | Marche ; f161-e82 |
| Voisin | f161-triage-overflow-v95 | Marche ; f161-e113 |

### command post node
`f161-command-post-node` · Points
[Socle V104 conservé] Position X 3960, pied Y 510, largeur 180. Section descriptive : Réserve et supervision. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-tunnel-high | Échelle ; f161-e71 |
| Voisin | f161-leadworks | Marche ; f161-e72 |

### steam lead node
`f161-steam-lead-node` · Points
[Socle V104 conservé] Position X 4710, pied Y 330, largeur 160. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-water-header | Marche ; f161-e73 |
| Voisin | f161-piston-b-node | Marche ; f161-e74 |
| Voisin | f161-perch-lead-v93 | Échelle ; f161-e83 |

### shutter foundry node
`f161-shutter-foundry-node` · Points
[Socle V104 conservé] Position X 5050, pied Y 510, largeur 160. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-mold | Marche ; f161-e75 |
| Voisin | f161-piston-c-node | Marche ; f161-e76 |

### perch cell v93
`f161-perch-cell-v93` · Points
[Socle V104 conservé] Position X 2500, pied Y 190, largeur 170. Section descriptive : Recueillement. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-mess-ceiling | Échelle ; f161-e77 |
| Voisin | f161-comms-high | Échelle ; f161-e78 |
| Voisin | f161-faith-dais-v94 | Marche ; f161-e94 |
| Voisin | f161-watch-cell-v95 | Marche ; f161-e106 |

### perch service v93
`f161-perch-service-v93` · Points
[Socle V104 conservé] Position X 3310, pied Y 190, largeur 170. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-steam-service-node | Échelle ; f161-e79 |
| Voisin | f161-service-high | Échelle ; f161-e80 |

### triage v93
`f161-triage-v93` · Points
[Socle V104 conservé] Position X 3490, pied Y 510, largeur 190. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-rescue-post-node | Marche ; f161-e81 |
| Voisin | f161-shutter-service-node | Marche ; f161-e82 |
| Voisin | f161-triage-overflow-v95 | Marche ; f161-e112 |

### perch lead v93
`f161-perch-lead-v93` · Points
[Socle V104 conservé] Position X 4720, pied Y 190, largeur 170. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-steam-lead-node | Échelle ; f161-e83 |
| Voisin | f161-piston-b-node | Échelle ; f161-e84 |

### parley v93
`f161-parley-v93` · Points
[Socle V104 conservé] Position X 5660, pied Y 510, largeur 180. Section descriptive : Four principal. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-furnace | Marche ; f161-e85 |
| Voisin | f161-company | Marche ; f161-e86 |

### witness v93
`f161-witness-v93` · Points
[Socle V104 conservé] Position X 6030, pied Y 330, largeur 170. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-company | Échelle ; f161-e87 |
| Voisin | f161-extraction | Échelle ; f161-e88 |
| Voisin | f161-final-transmission-v94 | Marche ; f161-e103 |
| Voisin | f161-archive-checksum-v95 | Échelle ; f161-e120 |

### flight analysis v94
`f161-flight-analysis-v94` · Points
[Socle V104 conservé] Position X 780, pied Y 330, largeur 220. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-eev | Échelle ; f161-e89 |
| Voisin | f161-morgue-high | Marche ; f161-e90 |

### wreckage incident v94
`f161-wreckage-incident-v94` · Points
[Socle V104 conservé] Position X 820, pied Y 630, largeur 220. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-eev | Échelle ; f161-e91 |
| Voisin | f161-infirmary | Échelle ; f161-e92 |

### faith dais v94
`f161-faith-dais-v94` · Points
[Socle V104 conservé] Position X 2180, pied Y 190, largeur 250. Section descriptive : Recueillement. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-mess-high | Échelle ; f161-e93 |
| Voisin | f161-perch-cell-v93 | Marche ; f161-e94 |

### battery locker v94
`f161-battery-locker-v94` · Points
[Socle V104 conservé] Position X 3500, pied Y 330, largeur 250. Section descriptive : Atelier des batteries. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-service-high | Marche ; f161-e95 |
| Voisin | f161-tunnel-high | Marche ; f161-e96 |
| Voisin | f161-hunt-service-v95 | Marche ; f161-e111 |

### golic cache v94
`f161-golic-cache-v94` · Points
[Socle V104 conservé] Position X 3660, pied Y 630, largeur 230. Section descriptive : Galeries basses. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-tunnel-shrine | Marche ; f161-e97 |
| Voisin | f161-tunnel-low | Marche ; f161-e98 |

### battery junction v94
`f161-battery-junction-v94` · Points
[Socle V104 conservé] Position X 4020, pied Y 330, largeur 250. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-tunnel-high | Marche ; f161-e99 |
| Voisin | f161-water-header | Marche ; f161-e100 |
| Voisin | f161-bait-switch-v95 | Marche ; f161-e116 |

### chase reroute v94
`f161-chase-reroute-v94` · Points
[Socle V104 conservé] Position X 5050, pied Y 630, largeur 250. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-mold | Échelle ; f161-e101 |
| Voisin | f161-furnace | Échelle ; f161-e102 |
| Voisin | f161-pressure-alcove-v95 | Marche ; f161-e118 |

### final transmission v94
`f161-final-transmission-v94` · Points
[Socle V104 conservé] Position X 6100, pied Y 330, largeur 190. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-witness-v93 | Marche ; f161-e103 |

### shelter cell v95
`f161-shelter-cell-v95` · Points
[Socle V104 conservé] Position X 2050, pied Y 630, largeur 220. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-cell-a | Échelle ; f161-e104 |
| Voisin | f161-assembly-hall | Échelle ; f161-e105 |

### watch cell v95
`f161-watch-cell-v95` · Points
[Socle V104 conservé] Position X 2660, pied Y 190, largeur 190. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-perch-cell-v93 | Marche ; f161-e106 |
| Voisin | f161-comms-high | Échelle ; f161-e107 |

### refuge service v95
`f161-refuge-service-v95` · Points
[Socle V104 conservé] Position X 2990, pied Y 630, largeur 230. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-service-deep | Marche ; f161-e108 |
| Voisin | f161-tunnel-shrine | Marche ; f161-e109 |

### hunt service v95
`f161-hunt-service-v95` · Points
[Socle V104 conservé] Position X 3370, pied Y 330, largeur 210. Section descriptive : Atelier des batteries. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-service-high | Marche ; f161-e110 |
| Voisin | f161-battery-locker-v94 | Marche ; f161-e111 |

### triage overflow v95
`f161-triage-overflow-v95` · Points
[Socle V104 conservé] Position X 3600, pied Y 510, largeur 220. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-triage-v93 | Marche ; f161-e112 |
| Voisin | f161-shutter-service-node | Marche ; f161-e113 |

### hunt junction v95
`f161-hunt-junction-v95` · Points
[Socle V104 conservé] Position X 3900, pied Y 630, largeur 210. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-tunnel-low | Marche ; f161-e114 |
| Voisin | f161-waste-tank | Marche ; f161-e115 |

### bait switch v95
`f161-bait-switch-v95` · Points
[Socle V104 conservé] Position X 4320, pied Y 330, largeur 210. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-battery-junction-v94 | Marche ; f161-e116 |
| Voisin | f161-sprinkler | Marche ; f161-e117 |

### pressure alcove v95
`f161-pressure-alcove-v95` · Points
[Socle V104 conservé] Position X 4780, pied Y 630, largeur 220. Section descriptive : Cuve et évacuation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-chase-reroute-v94 | Marche ; f161-e118 |

### chase observer v95
`f161-chase-observer-v95` · Points
[Socle V104 conservé] Position X 5280, pied Y 330, largeur 210. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-furnace-high | Marche ; f161-e119 |

### archive checksum v95
`f161-archive-checksum-v95` · Points
[Socle V104 conservé] Position X 5960, pied Y 190, largeur 190. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

| Élément | Référence | Contrat |
|---|---|---|
| Voisin | f161-witness-v93 | Échelle ; f161-e120 |

### Marche — f161-e01
`f161-e01` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-spawn | (180, 510) |
| Arrivée | f161-eev | (620, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e02
`f161-e02` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-eev | (620, 510) |
| Arrivée | f161-infirmary | (1120, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Porte — f161-e03
`f161-e03` · Connexions
[Socle V104 conservé] Porte entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-infirmary | (1120, 510) |
| Arrivée | f161-cell-a | (1900, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Porte — f161-e05
`f161-e05` · Connexions
[Socle V104 conservé] Porte entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-cell-b | (2620, 510) |
| Arrivée | f161-service-low | (3070, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e06
`f161-e06` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-service-low | (3070, 510) |
| Arrivée | f161-bishop | (3500, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Porte — f161-e07
`f161-e07` · Connexions
[Socle V104 conservé] Porte entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-bishop | (3500, 510) |
| Arrivée | f161-leadworks | (4200, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e08
`f161-e08` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-leadworks | (4200, 510) |
| Arrivée | f161-mold | (4920, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e09
`f161-e09` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-mold | (4920, 510) |
| Arrivée | f161-furnace | (5480, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e10
`f161-e10` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-furnace | (5480, 510) |
| Arrivée | f161-company | (5800, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e11
`f161-e11` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-company | (5800, 510) |
| Arrivée | f161-extraction | (6040, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e12
`f161-e12` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-infirmary | (1120, 510) |
| Arrivée | f161-morgue-high | (1500, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e13
`f161-e13` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-morgue-high | (1500, 350) |
| Arrivée | f161-mess-high | (2320, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e14
`f161-e14` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé -20. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-mess-high | (2320, 350) |
| Arrivée | f161-service-high | (3070, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e15
`f161-e15` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-service-high | (3070, 330) |
| Arrivée | f161-tunnel-high | (3820, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e16
`f161-e16` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-tunnel-high | (3820, 330) |
| Arrivée | f161-sprinkler | (4560, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e17
`f161-e17` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-sprinkler | (4560, 330) |
| Arrivée | f161-furnace-high | (5350, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e18
`f161-e18` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-furnace-high | (5350, 330) |
| Arrivée | f161-furnace | (5480, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Conduit — f161-e19
`f161-e19` · Connexions
[Socle V104 conservé] Conduit entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-infirmary | (1120, 510) |
| Arrivée | f161-service-deep | (3070, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e20
`f161-e20` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-service-deep | (3070, 630) |
| Arrivée | f161-tunnel-low | (3820, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e21
`f161-e21` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-tunnel-low | (3820, 630) |
| Arrivée | f161-leadworks | (4200, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Conduit — f161-e22
`f161-e22` · Connexions
[Socle V104 conservé] Conduit entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-leadworks | (4200, 510) |
| Arrivée | f161-furnace | (5480, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e23
`f161-e23` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-cell-a | (1900, 510) |
| Arrivée | f161-mess-high | (2320, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e24
`f161-e24` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-service-low | (3070, 510) |
| Arrivée | f161-service-high | (3070, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e25
`f161-e25` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-service-low | (3070, 510) |
| Arrivée | f161-service-deep | (3070, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e26
`f161-e26` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-leadworks | (4200, 510) |
| Arrivée | f161-sprinkler | (4560, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e27
`f161-e27` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-cell-a | (1900, 510) |
| Arrivée | f161-assembly-hall | (2300, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e28
`f161-e28` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-assembly-hall | (2300, 510) |
| Arrivée | f161-cell-b | (2620, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e29
`f161-e29` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-assembly-hall | (2300, 510) |
| Arrivée | f161-mess-high | (2320, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e30
`f161-e30` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-tunnel-low | (3820, 630) |
| Arrivée | f161-waste-tank | (4070, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e31
`f161-e31` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-waste-tank | (4070, 630) |
| Arrivée | f161-sluice-low | (4500, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e32
`f161-e32` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-sluice-low | (4500, 630) |
| Arrivée | f161-leadworks | (4200, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e33
`f161-e33` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-furnace-high | (5350, 330) |
| Arrivée | f161-furnace-gantry | (5740, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e34
`f161-e34` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-furnace-gantry | (5740, 330) |
| Arrivée | f161-company | (5800, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e35
`f161-e35` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-service-low | (3070, 510) |
| Arrivée | f161-fuel-manifold-a | (2960, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e36
`f161-e36` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-fuel-manifold-a | (2960, 510) |
| Arrivée | f161-fuel-manifold-b | (3240, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e37
`f161-e37` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-fuel-manifold-b | (3240, 510) |
| Arrivée | f161-bishop | (3500, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e38
`f161-e38` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-bishop | (3500, 510) |
| Arrivée | f161-chemical-store | (3670, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e39
`f161-e39` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-chemical-store | (3670, 510) |
| Arrivée | f161-tunnel-high | (3820, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e40
`f161-e40` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-leadworks | (4200, 510) |
| Arrivée | f161-lead-primer | (4380, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e41
`f161-e41` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-lead-primer | (4380, 510) |
| Arrivée | f161-mold | (4920, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e42
`f161-e42` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-sprinkler | (4560, 330) |
| Arrivée | f161-water-header | (4690, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e43
`f161-e43` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-water-header | (4690, 330) |
| Arrivée | f161-mold | (4920, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e44
`f161-e44` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-furnace-high | (5350, 330) |
| Arrivée | f161-furnace-overlook | (5580, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e45
`f161-e45` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-furnace-overlook | (5580, 330) |
| Arrivée | f161-company | (5800, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e46
`f161-e46` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-infirmary | (1120, 510) |
| Arrivée | f161-clemens-bed | (1380, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e47
`f161-e47` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-clemens-bed | (1380, 510) |
| Arrivée | f161-funeral-walk | (1580, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e48
`f161-e48` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-funeral-walk | (1580, 510) |
| Arrivée | f161-morgue-high | (1500, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e49
`f161-e49` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-mess-high | (2320, 350) |
| Arrivée | f161-mess-ceiling | (2470, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e50
`f161-e50` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-mess-ceiling | (2470, 350) |
| Arrivée | f161-comms-high | (2720, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e51
`f161-e51` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-service-high | (3070, 330) |
| Arrivée | f161-fan-shaft | (2940, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e52
`f161-e52` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-service-deep | (3070, 630) |
| Arrivée | f161-tunnel-shrine | (3420, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e53
`f161-e53` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-tunnel-shrine | (3420, 630) |
| Arrivée | f161-bishop | (3500, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e54
`f161-e54` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-leadworks | (4200, 510) |
| Arrivée | f161-piston-a-node | (4480, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e55
`f161-e55` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-piston-a-node | (4480, 510) |
| Arrivée | f161-mold | (4920, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e56
`f161-e56` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-sprinkler | (4560, 330) |
| Arrivée | f161-piston-b-node | (4820, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e57
`f161-e57` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-piston-b-node | (4820, 330) |
| Arrivée | f161-mold | (4920, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e58
`f161-e58` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-mold | (4920, 510) |
| Arrivée | f161-piston-c-node | (5140, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e59
`f161-e59` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-piston-c-node | (5140, 510) |
| Arrivée | f161-furnace | (5480, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e60
`f161-e60` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-company | (5800, 510) |
| Arrivée | f161-patna-cage-node | (5930, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e61
`f161-e61` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-patna-cage-node | (5930, 510) |
| Arrivée | f161-extraction | (6040, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e62
`f161-e62` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-morgue-high | (1500, 350) |
| Arrivée | f161-master-archive-node | (1260, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e63
`f161-e63` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-cell-b | (2620, 510) |
| Arrivée | f161-shutter-cell-node | (2740, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e64
`f161-e64` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-shutter-cell-node | (2740, 510) |
| Arrivée | f161-comms-high | (2720, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e65
`f161-e65` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-service-high | (3070, 330) |
| Arrivée | f161-steam-service-node | (3190, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e66
`f161-e66` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-steam-service-node | (3190, 330) |
| Arrivée | f161-fan-shaft | (2940, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e67
`f161-e67` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-service-low | (3070, 510) |
| Arrivée | f161-rescue-post-node | (3330, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e68
`f161-e68` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-rescue-post-node | (3330, 510) |
| Arrivée | f161-bishop | (3500, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e69
`f161-e69` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-bishop | (3500, 510) |
| Arrivée | f161-shutter-service-node | (3650, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e70
`f161-e70` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-shutter-service-node | (3650, 510) |
| Arrivée | f161-chemical-store | (3670, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e71
`f161-e71` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-tunnel-high | (3820, 330) |
| Arrivée | f161-command-post-node | (3960, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e72
`f161-e72` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-command-post-node | (3960, 510) |
| Arrivée | f161-leadworks | (4200, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e73
`f161-e73` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-water-header | (4690, 330) |
| Arrivée | f161-steam-lead-node | (4710, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e74
`f161-e74` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-steam-lead-node | (4710, 330) |
| Arrivée | f161-piston-b-node | (4820, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e75
`f161-e75` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-mold | (4920, 510) |
| Arrivée | f161-shutter-foundry-node | (5050, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e76
`f161-e76` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-shutter-foundry-node | (5050, 510) |
| Arrivée | f161-piston-c-node | (5140, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e77
`f161-e77` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-mess-ceiling | (2470, 350) |
| Arrivée | f161-perch-cell-v93 | (2500, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e78
`f161-e78` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-perch-cell-v93 | (2500, 190) |
| Arrivée | f161-comms-high | (2720, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e79
`f161-e79` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-steam-service-node | (3190, 330) |
| Arrivée | f161-perch-service-v93 | (3310, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e80
`f161-e80` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-perch-service-v93 | (3310, 190) |
| Arrivée | f161-service-high | (3070, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e81
`f161-e81` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-rescue-post-node | (3330, 510) |
| Arrivée | f161-triage-v93 | (3490, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e82
`f161-e82` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-triage-v93 | (3490, 510) |
| Arrivée | f161-shutter-service-node | (3650, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e83
`f161-e83` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-steam-lead-node | (4710, 330) |
| Arrivée | f161-perch-lead-v93 | (4720, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e84
`f161-e84` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-perch-lead-v93 | (4720, 190) |
| Arrivée | f161-piston-b-node | (4820, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e85
`f161-e85` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-furnace | (5480, 510) |
| Arrivée | f161-parley-v93 | (5660, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e86
`f161-e86` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-parley-v93 | (5660, 510) |
| Arrivée | f161-company | (5800, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e87
`f161-e87` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-company | (5800, 510) |
| Arrivée | f161-witness-v93 | (6030, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e88
`f161-e88` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-witness-v93 | (6030, 330) |
| Arrivée | f161-extraction | (6040, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e89
`f161-e89` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-eev | (620, 510) |
| Arrivée | f161-flight-analysis-v94 | (780, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e90
`f161-e90` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 20. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-flight-analysis-v94 | (780, 330) |
| Arrivée | f161-morgue-high | (1500, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e91
`f161-e91` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-eev | (620, 510) |
| Arrivée | f161-wreckage-incident-v94 | (820, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e92
`f161-e92` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-wreckage-incident-v94 | (820, 630) |
| Arrivée | f161-infirmary | (1120, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e93
`f161-e93` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-mess-high | (2320, 350) |
| Arrivée | f161-faith-dais-v94 | (2180, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e94
`f161-e94` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-faith-dais-v94 | (2180, 190) |
| Arrivée | f161-perch-cell-v93 | (2500, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e95
`f161-e95` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-service-high | (3070, 330) |
| Arrivée | f161-battery-locker-v94 | (3500, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e96
`f161-e96` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-battery-locker-v94 | (3500, 330) |
| Arrivée | f161-tunnel-high | (3820, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e97
`f161-e97` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-tunnel-shrine | (3420, 630) |
| Arrivée | f161-golic-cache-v94 | (3660, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e98
`f161-e98` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-golic-cache-v94 | (3660, 630) |
| Arrivée | f161-tunnel-low | (3820, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e99
`f161-e99` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-tunnel-high | (3820, 330) |
| Arrivée | f161-battery-junction-v94 | (4020, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e100
`f161-e100` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-battery-junction-v94 | (4020, 330) |
| Arrivée | f161-water-header | (4690, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e101
`f161-e101` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-mold | (4920, 510) |
| Arrivée | f161-chase-reroute-v94 | (5050, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e102
`f161-e102` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-chase-reroute-v94 | (5050, 630) |
| Arrivée | f161-furnace | (5480, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e103
`f161-e103` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-witness-v93 | (6030, 330) |
| Arrivée | f161-final-transmission-v94 | (6100, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e104
`f161-e104` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-cell-a | (1900, 510) |
| Arrivée | f161-shelter-cell-v95 | (2050, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e105
`f161-e105` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-shelter-cell-v95 | (2050, 630) |
| Arrivée | f161-assembly-hall | (2300, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e106
`f161-e106` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-perch-cell-v93 | (2500, 190) |
| Arrivée | f161-watch-cell-v95 | (2660, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e107
`f161-e107` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-watch-cell-v95 | (2660, 190) |
| Arrivée | f161-comms-high | (2720, 350) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e108
`f161-e108` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-service-deep | (3070, 630) |
| Arrivée | f161-refuge-service-v95 | (2990, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e109
`f161-e109` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-refuge-service-v95 | (2990, 630) |
| Arrivée | f161-tunnel-shrine | (3420, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e110
`f161-e110` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-service-high | (3070, 330) |
| Arrivée | f161-hunt-service-v95 | (3370, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e111
`f161-e111` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-hunt-service-v95 | (3370, 330) |
| Arrivée | f161-battery-locker-v94 | (3500, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e112
`f161-e112` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-triage-v93 | (3490, 510) |
| Arrivée | f161-triage-overflow-v95 | (3600, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e113
`f161-e113` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-triage-overflow-v95 | (3600, 510) |
| Arrivée | f161-shutter-service-node | (3650, 510) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e114
`f161-e114` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-tunnel-low | (3820, 630) |
| Arrivée | f161-hunt-junction-v95 | (3900, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e115
`f161-e115` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-hunt-junction-v95 | (3900, 630) |
| Arrivée | f161-waste-tank | (4070, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e116
`f161-e116` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-battery-junction-v94 | (4020, 330) |
| Arrivée | f161-bait-switch-v95 | (4320, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e117
`f161-e117` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-bait-switch-v95 | (4320, 330) |
| Arrivée | f161-sprinkler | (4560, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e118
`f161-e118` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-chase-reroute-v94 | (5050, 630) |
| Arrivée | f161-pressure-alcove-v95 | (4780, 630) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Marche — f161-e119
`f161-e119` · Connexions
[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-furnace-high | (5350, 330) |
| Arrivée | f161-chase-observer-v95 | (5280, 330) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### Échelle — f161-e120
`f161-e120` · Connexions
[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

| Élément | Référence | Contrat |
|---|---|---|
| Départ | f161-witness-v93 | (6030, 330) |
| Arrivée | f161-archive-checksum-v95 | (5960, 190) |
| Direction | Deux sens | Sous réserve des verrous et conditions hérités |

### A3-ANCHOR
`A3-ANCHOR` · Règles
[Socle V104 conservé] Tout décor a un support nommé ; coordonnées indépendantes du joueur.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-FINITE
`A3-FINITE` · Règles
[Socle V104 conservé] Positions et dimensions finies et positives.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-ID
`A3-ID` · Règles
[Socle V104 conservé] Identifiants uniques, parents existants.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-FOOT
`A3-FOOT` · Règles
[Socle V104 conservé] Les meubles reposent sur le plan de pose ; pas sur la caméra.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-BOUND
`A3-BOUND` · Règles
[Socle V104 conservé] Les éléments restent dans la baie de leur assemblage.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-NO_FAKE_COVER
`A3-NO_FAKE_COVER` · Règles
[Socle V104 conservé] Décor d’arrière-plan non collidable et explicitement sans couverture.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-CONDITION
`A3-CONDITION` · Règles
[Socle V104 conservé] Le matériel de récupération dépend de l’arrivée de la Compagnie.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-ROUTE
`A3-ROUTE` · Règles
[Socle V104 conservé] Aucun nœud, verrou ou ordre de mission ajouté pour justifier le décor.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-DRAW_PURE
`A3-DRAW_PURE` · Règles
[Socle V104 conservé] Le rendu ne change ni progression ni sauvegarde.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-TOP
`A3-TOP` · Règles
[Socle V104 conservé] Fond opaque depuis le premier pixel du champ, quelle que soit la caméra.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | browser | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-HUD
`A3-HUD` · Règles
[Socle V104 conservé] Les panneaux ordinaires couvrent moins de 9 % de l’écran.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-READ
`A3-READ` · Règles
[Socle V104 conservé] Les premiers plans s’effacent à proximité des silhouettes.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-PARALLAX
`A3-PARALLAX` · Règles
[Socle V104 conservé] Les machines proches suivent le monde ; seule l’architecture distante dérive.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | browser | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-LUX
`A3-LUX` · Règles
[Socle V104 conservé] Une lumière forte a une source dessinée.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | visual | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-RHYTHM
`A3-RHYTHM` · Règles
[Socle V104 conservé] Alcôves équipées puis respirations, sans tapis uniforme de petits objets.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | visual | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-IDENTITY
`A3-IDENTITY` · Règles
[Socle V104 conservé] Une forme identifiable remplace chaque bloc générique.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | visual | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-FILM
`A3-FILM` · Règles
[Socle V104 conservé] Plans et dimensions de jeu : adaptation, pas relevé certifié des plateaux.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | disclosure | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-ROOMS
`A3-ROOMS` · Règles
[Socle V104 conservé] La pièce, son étage et ses voisins priment sur les limites de caméra.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | disclosure | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-103-SPACE
`A3-103-SPACE` · Règles
[Socle V104 conservé] Une section décrit un lieu et un étage ; elle ne crée pas une nouvelle salle instanciée.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | scope | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-103-PORTAL
`A3-103-PORTAL` · Règles
[Socle V104 conservé] Un cadre de porte provient d’une arête gate/airlock ; la feuille et la collision restent pilotées par la porte native.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-103-GATE-GEOMETRY
`A3-103-GATE-GEOMETRY` · Règles
[Socle V104 conservé] Une porte fournie par le plan compilé est utilisée sans déplacer sa collision.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-103-VERTICAL-PRIORITY
`A3-103-VERTICAL-PRIORITY` · Règles
[Socle V104 conservé] Haut/Bas donnent la priorité à une échelle réellement atteignable, avant un changement de profondeur.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-103-CIRCUIT
`A3-103-CIRCUIT` · Règles
[Socle V104 conservé] Un réseau décoratif possède une source et un récepteur du même ensemble, reliés par un tracé continu.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-103-LIGHT
`A3-103-LIGHT` · Règles
[Socle V104 conservé] Couper un éclairage de service ne coupe ni le feu du four, ni l’eau du piège, ni un objectif.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-103-REACH
`A3-103-REACH` · Règles
[Socle V104 conservé] Une commande exige proximité, niveau, plan médian, personnage vivant et absence de porte fermée entre les deux.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-103-PAUSE
`A3-103-PAUSE` · Règles
[Socle V104 conservé] Le plan et les archives arrêtent la simulation ; la fermeture ne supprime pas une pause préexistante.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-103-MAP
`A3-103-MAP` · Règles
[Socle V104 conservé] Le plan ne montre ni ennemis ni dossiers secrets ; un nœud n’est relevé qu’au voisinage du personnage.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-103-PERSIST
`A3-103-PERSIST` · Règles
[Socle V104 conservé] Les visites et les éclairages sont sauvegardés ; ni la géométrie ni l’ouverture du plan ne sont sérialisées.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-103-REDUCED-MOTION
`A3-103-REDUCED-MOTION` · Règles
[Socle V104 conservé] Le mouvement réduit conserve les états lisibles sans animation de panneaux.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | automated | Contrat documenté ; la méthode est séparée du résultat des tests. |

### A3-103-PROVENANCE
`A3-103-PROVENANCE` · Règles
[Socle V104 conservé] Banc visuel et tests isolés ne constituent pas une validation de la campagne complète.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | scope | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC01
`SC01` · Règles
[Socle V104 conservé] Une scène compilée fournit les appuis, les commandes, les portes et le plan.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | data | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC02
`SC02` · Règles
[Socle V104 conservé] Une coordonnée monde n’est pas retraitée comme une coordonnée écran.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | data | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC03
`SC03` · Règles
[Socle V104 conservé] Le fond couvre le premier pixel ; les particules restent dans leur alcôve.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | browser | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC04
`SC04` · Règles
[Socle V104 conservé] Un saut conserve le nom du lieu jusqu’à la réception.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC05
`SC05` · Règles
[Socle V104 conservé] Un contact exige proximité, hauteur, profondeur et absence de porte fermée.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC06
`SC06` · Règles
[Socle V104 conservé] Les états visuels sont issus des événements, jamais de l’abscisse du joueur.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC07
`SC07` · Règles
[Socle V104 conservé] Le feu, les dépôts de suie, le plomb chaud et le refroidissement restent distincts.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | data | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC08
`SC08` · Règles
[Socle V104 conservé] La Compagnie ne se dessine pas avant son arrivée.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC09
`SC09` · Règles
[Socle V104 conservé] Le HUD normal est temporaire ; les vitales restent visibles en danger.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | browser | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC10
`SC10` · Règles
[Socle V104 conservé] Le plan et les archives suspendent l’horloge de cette couche.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC11
`SC11` · Règles
[Socle V104 conservé] La sauvegarde valide identité et géométrie avant de remplacer l’état.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC12
`SC12` · Règles
[Socle V104 conservé] Un fichier refusé ne détruit ni la partie courante ni sa reprise.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | browser | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC13
`SC13` · Règles
[Socle V104 conservé] Les phases d’attaque, touches et fenêtres ouvertes ne sont pas rejouées à l’import.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | data | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC14
`SC14` · Règles
[Socle V104 conservé] La ronde originale doit être terminée au clavier sans positions injectées.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | browser | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC15
`SC15` · Règles
[Socle V104 conservé] Un mécanisme local d’éclairage ne termine pas une mission du film.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC16
`SC16` · Règles
[Socle V104 conservé] Les captures sont natives du renderer partagé, pas une reconstitution après coup.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | evidence | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC17
`SC17` · Règles
[Socle V104 conservé] Les tests préparés, la ronde et le moteur complet ont des preuves distinctes.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | scope | Contrat documenté ; la méthode est séparée du résultat des tests. |

### SC18
`SC18` · Règles
[Socle V104 conservé] Les options de mouvement et de lisibilité n’altèrent pas la progression.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve attendue | runtime | Contrat documenté ; la méthode est séparée du résultat des tests. |

### Départ du feu
`outbreak` · États du décor
[Socle V104 conservé] Flamme locale et fumée, sans nouveaux dégâts. La consultation ou le dessin seul ne déclenche pas la transition historique.

| Élément | Référence | Contrat |
|---|---|---|
| État source | alien3V90.firePlan.ignited et non accidentResolved ; repli fireMazeIgnited | Les booléens explicites priment sur les raccourcis de phase. |
| Ensemble | service-pump | Pompage des galeries |
| Ensemble | chemical-store | Réserve de produits |

### Après l’incendie
`aftermath` · États du décor
[Socle V104 conservé] Suie conservée après extinction ; aucune flamme ajoutée. La consultation ou le dessin seul ne déclenche pas la transition historique.

| Élément | Référence | Contrat |
|---|---|---|
| État source | Feu observé ou firePlan.accidentResolved | Les booléens explicites priment sur les raccourcis de phase. |
| Ensemble | service-pump | Pompage des galeries |
| Ensemble | chemical-store | Réserve de produits |

### Coulée
`molten` · États du décor
[Socle V104 conservé] Lueur chaude aux récepteurs industriels. La consultation ou le dessin seul ne déclenche pas la transition historique.

| Élément | Référence | Contrat |
|---|---|---|
| État source | alien3V88.moltenLeadApplied ; repli de phase uniquement si absent | Les booléens explicites priment sur les raccourcis de phase. |
| Ensemble | leadworks | Creuset et transfert |
| Ensemble | lead-primer | Alimentation du creuset |
| Ensemble | mold | Moule de coulée |

### Refroidissement
`cooling` · États du décor
[Socle V104 conservé] Vapeur localisée ; pas de changement du débit ou de la victoire. La consultation ou le dessin seul ne déclenche pas la transition historique.

| Élément | Référence | Contrat |
|---|---|---|
| État source | alien3V88.thermalShockApplied ; repli de phase uniquement si absent | Les booléens explicites priment sur les raccourcis de phase. |
| Ensemble | mold | Moule de coulée |
| Ensemble | water-header | Collecteur d’eau supérieur |

### Récupération
`recovery` · États du décor
[Socle V104 conservé] Matériel existant de la Compagnie visible. La consultation ou le dessin seul ne déclenche pas la transition historique.

| Élément | Référence | Contrat |
|---|---|---|
| État source | alien3V89.company.visible === true ou phase company/finale | Les booléens explicites priment sur les raccourcis de phase. |
| Ensemble | patna-kit | Matériel de récupération |

### 1. Rétablir la lampe de soin.
`round-1` · Ronde originale
[Socle V104 conservé] Parcours optionnel de l’aperçu, activé explicitement depuis son bouton. Il n’est pas injecté automatiquement dans la campagne Alien 3. Les trois circuits sont éteints au lancement de ce parcours ; aucune réserve du film n’est donnée. Une importation valide reprend en pause, sans sauter une étape.

| Élément | Référence | Contrat |
|---|---|---|
| Cible | care-light | Appui réel au bon étage |
| Action | I : rallumer | Une étape hors ordre ne se valide pas. |

### 2. Rétablir l’éclairage des cellules ouest.
`round-2` · Ronde originale
[Socle V104 conservé] Parcours optionnel de l’aperçu, activé explicitement depuis son bouton. Il n’est pas injecté automatiquement dans la campagne Alien 3. Les trois circuits sont éteints au lancement de ce parcours ; aucune réserve du film n’est donnée. Une importation valide reprend en pause, sans sauter une étape.

| Élément | Référence | Contrat |
|---|---|---|
| Cible | cell-light | Appui réel au bon étage |
| Action | I : rallumer | Une étape hors ordre ne se valide pas. |

### 3. Monter à l’atelier et rétablir sa lampe.
`round-3` · Ronde originale
[Socle V104 conservé] Parcours optionnel de l’aperçu, activé explicitement depuis son bouton. Il n’est pas injecté automatiquement dans la campagne Alien 3. Les trois circuits sont éteints au lancement de ce parcours ; aucune réserve du film n’est donnée. Une importation valide reprend en pause, sans sauter une étape.

| Élément | Référence | Contrat |
|---|---|---|
| Cible | service-light | Appui réel au bon étage |
| Action | I : rallumer | Une étape hors ordre ne se valide pas. |

### 4. Revenir dans la salle commune.
`round-4` · Ronde originale
[Socle V104 conservé] Parcours optionnel de l’aperçu, activé explicitement depuis son bouton. Il n’est pas injecté automatiquement dans la campagne Alien 3. Les trois circuits sont éteints au lancement de ce parcours ; aucune réserve du film n’est donnée. Une importation valide reprend en pause, sans sauter une étape.

| Élément | Référence | Contrat |
|---|---|---|
| Cible | f161-assembly-hall | Appui réel au bon étage |
| Action | Rejoindre le point de retour | Une étape hors ordre ne se valide pas. |

### Un bruit dans les galeries
`encounter-traque` · Parcours V105
Séquence originale activée explicitement dans le banc ; elle ne termine pas automatiquement une mission de la campagne historique. Aucun équipement militaire ajouté. Aaron appartient au parcours antérieur, pas à la fonderie.

| Élément | Référence | Contrat |
|---|---|---|
| Joueur | f161-infirmary | Départ de la séquence |
| Runner | f161-cell-b | Un objet acteur conservé |
| Étape 1 | objective-traque-0 | Parler à Aaron près de l’infirmerie. |
| Étape 2 | objective-traque-1 | Monter à l’atelier et prendre le relevé de service. |
| Étape 3 | objective-traque-2 | Rapporter le relevé à Aaron. |
| Relevé | operation107-report | E maintenu 1,10 s, ou mode Appuyer, au poste réel. |
| Diversion | input108-throw | Boulon lancé, bruit depuis l’impact ; aucune garantie de l’attirer hors de portée. |

### Parler à Aaron près de l’infirmerie.
`objective-traque-0` · Étapes V105
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Contrat |
|---|---|---|
| Séquence | encounter-traque | Un bruit dans les galeries |
| Ordre | 1 | Une action hors ordre ne donne aucun état final. |

### Monter à l’atelier et prendre le relevé de service.
`objective-traque-1` · Étapes V105
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Contrat |
|---|---|---|
| Séquence | encounter-traque | Un bruit dans les galeries |
| Ordre | 2 | Une action hors ordre ne donne aucun état final. |

### Rapporter le relevé à Aaron.
`objective-traque-2` · Étapes V105
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Contrat |
|---|---|---|
| Séquence | encounter-traque | Un bruit dans les galeries |
| Ordre | 3 | Une action hors ordre ne donne aucun état final. |

### Le dernier rabattage
`encounter-rabattage` · Parcours V105
Séquence originale activée explicitement dans le banc ; elle ne termine pas automatiquement une mission de la campagne historique. Aucun équipement militaire ajouté. Aaron appartient au parcours antérieur, pas à la fonderie.

| Élément | Référence | Contrat |
|---|---|---|
| Joueur | f161-command-post-node | Départ de la séquence |
| Runner | f161-furnace | Un objet acteur conservé |
| Étape 1 | objective-rabattage-0 | Donner le signal à Dillon au poste de commande. |
| Étape 2 | objective-rabattage-1 | Amorcer le réseau d’eau, sur la coursive haute. |
| Étape 3 | objective-rabattage-2 | Attendre Morse et Dillon, puis armer le piège au moule. |
| Étape 4 | objective-rabattage-3 | Attirer le Runner dans le moule ; rejoindre Dillon et lancer la coulée. |
| Étape 5 | objective-rabattage-4 | Remonter au collecteur pour libérer l’eau. |
| Étape 6 | objective-rabattage-5 | Rejoindre Morse près de la salle de coulée. |
| Amorçage | operation107-prime | Durée 1,80 s, annulation par mouvement/blessure/panneau. |
| Verrouillage | operation107-arm | Durée 1,25 s ; Morse et Dillon restent requis. |
| Refroidissement | operation107-cool | Durée 2,00 s après la coulée. |
| Préparation | A3-108-dormant | Les boulons ne réveillent pas la créature durant la phase explicitement dormante. |

### Donner le signal à Dillon au poste de commande.
`objective-rabattage-0` · Étapes V105
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Contrat |
|---|---|---|
| Séquence | encounter-rabattage | Le dernier rabattage |
| Ordre | 1 | Une action hors ordre ne donne aucun état final. |

### Amorcer le réseau d’eau, sur la coursive haute.
`objective-rabattage-1` · Étapes V105
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Contrat |
|---|---|---|
| Séquence | encounter-rabattage | Le dernier rabattage |
| Ordre | 2 | Une action hors ordre ne donne aucun état final. |

### Attendre Morse et Dillon, puis armer le piège au moule.
`objective-rabattage-2` · Étapes V105
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Contrat |
|---|---|---|
| Séquence | encounter-rabattage | Le dernier rabattage |
| Ordre | 3 | Une action hors ordre ne donne aucun état final. |

### Attirer le Runner dans le moule ; rejoindre Dillon et lancer la coulée.
`objective-rabattage-3` · Étapes V105
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Contrat |
|---|---|---|
| Séquence | encounter-rabattage | Le dernier rabattage |
| Ordre | 4 | Une action hors ordre ne donne aucun état final. |

### Remonter au collecteur pour libérer l’eau.
`objective-rabattage-4` · Étapes V105
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Contrat |
|---|---|---|
| Séquence | encounter-rabattage | Le dernier rabattage |
| Ordre | 5 | Une action hors ordre ne donne aucun état final. |

### Rejoindre Morse près de la salle de coulée.
`objective-rabattage-5` · Étapes V105
La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

| Élément | Référence | Contrat |
|---|---|---|
| Séquence | encounter-rabattage | Le dernier rabattage |
| Ordre | 6 | Une action hors ordre ne donne aucun état final. |

### Aaron
`station-aaron` · Postes V105
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-clemens-bed | X 1380, sol 510 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Relevé de service
`station-report` · Postes V105
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105. V107 : certaines étapes exigent une action maintenue, à appui stable. Les gestes et interruptions sont détaillés dans les fiches Manœuvres V107 ; l’ancienne validation instantanée de ces étapes n’est plus active dans le pilote V107.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-service-high | X 3070, sol 330 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Dillon
`station-brief` · Postes V105
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-command-post-node | X 3960, sol 510 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Vanne du collecteur
`station-water` · Postes V105
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105. V107 : certaines étapes exigent une action maintenue, à appui stable. Les gestes et interruptions sont détaillés dans les fiches Manœuvres V107 ; l’ancienne validation instantanée de ces étapes n’est plus active dans le pilote V107.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-water-header | X 4690, sol 330 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Commande du moule
`station-mold` · Postes V105
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105. V107 : certaines étapes exigent une action maintenue, à appui stable. Les gestes et interruptions sont détaillés dans les fiches Manœuvres V107 ; l’ancienne validation instantanée de ces étapes n’est plus active dans le pilote V107.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-mold | X 4920, sol 510 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Commande de coulée
`station-pour` · Postes V105
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105. V107 conserve volontairement la commande de coulée immédiate, au passage réel du Runner. Elle n’immobilise pas la créature avant sa validation et ne lui ajoute aucun déplacement forcé.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-piston-c-node | X 5140, sol 510 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Morse
`station-return` · Postes V105
Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-lead-primer | X 4380, sol 510 |
| Profondeur | 1 | Plan médian de la commande |
| Interaction | E | Priorité à l’étape attendue lorsque sa station est atteinte. |

### Aaron
`participant-aaron` · Participants V105
Donne la consigne et reçoit le relevé. Aucun déplacement ni réapparition dans le final. Les corps sont des silhouettes vectorielles stylisées. Ce test n’est pas la mort filmée de Dillon ni la fin complète du film.

| Élément | Référence | Contrat |
|---|---|---|
| Point de présence | f161-clemens-bed | Position physique vérifiée, vivant et trajet terminé |
| Séquence | encounter-traque | Présence limitée à son parcours |
| Navigation | Graphe commun | Même portes et appuis que la menace |

### Morse
`participant-morse` · Participants V105
Part près de Bishop et rejoint le poste de coulée après le signal. Une porte fermée le fait attendre ; un simple drapeau d’arrivée ne suffit pas. Les corps sont des silhouettes vectorielles stylisées. Ce test n’est pas la mort filmée de Dillon ni la fin complète du film.

| Élément | Référence | Contrat |
|---|---|---|
| Point de présence | f161-lead-primer | Position physique vérifiée, vivant et trajet terminé |
| Séquence | encounter-rabattage | Présence limitée à son parcours |
| Navigation | Graphe commun | Même portes et appuis que la menace |
| Ordre proche | order106-morse | G : attendre/repartir sans effacer destination et segment. Un détenu retenu hors de son poste ne valide pas le piège. |

### Dillon
`participant-dillon` · Participants V105
Reçoit la consigne au poste de commande puis rejoint la fermeture. Sa présence et celle de Morse restent nécessaires pour armer puis couler. Les corps sont des silhouettes vectorielles stylisées. Ce test n’est pas la mort filmée de Dillon ni la fin complète du film.

| Élément | Référence | Contrat |
|---|---|---|
| Point de présence | f161-piston-c-node | Position physique vérifiée, vivant et trajet terminé |
| Séquence | encounter-rabattage | Présence limitée à son parcours |
| Navigation | Graphe commun | Même portes et appuis que la menace |
| Ordre proche | order106-dillon | G : attendre/repartir sans effacer destination et segment. Un détenu retenu hors de son poste ne valide pas le piège. |

### En attente du signal
`runner-dormant` · États du Runner
Le rabattage conserve le prédateur en attente jusqu’à l’armement réel du moule.

| Élément | Référence | Contrat |
|---|---|---|
| Contrat | encounter-rabattage | Un unique acteur |

### Patrouille
`runner-patrol` · États du Runner
Suite de points connus, avec chemins calculés sur les connexions ouvertes. Aucun bond de position vers Ripley.

| Élément | Référence | Contrat |
|---|---|---|
| Contrat | encounter-traque | Un unique acteur |
| patrolSpeed | 94 | Valeur utilisée par le module de poursuite |

### Investigation sonore
`runner-investigate` · États du Runner
V106 : un bruit garde son origine et sa date. Sa portée acoustique est mesurée depuis le corps du Runner sur son segment, avec les détours du graphe et l’atténuation des portes. Chaque numéro d’événement est consommé au plus une fois.

| Élément | Référence | Contrat |
|---|---|---|
| Contrat | encounter-traque | Un unique acteur |
| hearing | 620 | Valeur utilisée par le module de poursuite |
| investigateSpeed | 126 | Valeur utilisée par le module de poursuite |
| Origine réelle | A3-106-sound-edge | Pas de réception depuis l’extrémité lointaine du chemin. |

### Recherche de trace perdue
`runner-search` · États du Runner
V106 : après une trace perdue, le Runner explore au maximum trois points voisins réellement atteignables. Il avance à 110 unités/s pendant un budget de 5,2 secondes, puis reprend la patrouille. Aucun bond vers le joueur invisible.

| Élément | Référence | Contrat |
|---|---|---|
| Durée | 5,2 secondes | La pause et les panneaux suspendent ce délai. |
| Choix | A3-106-search-room | Voisins du point de trace ; une route coupée n’est pas effacée artificiellement. |

### Poursuite
`runner-chase` · États du Runner
V106 : la vue conserve direction, hauteur, profondeur et portes, puis accumule une reconnaissance selon l’éclairage et la posture. La pénombre retarde l’identification mais ne protège pas à courte portée. La dernière trace reste une observation passée.

| Élément | Référence | Contrat |
|---|---|---|
| Contrat | encounter-traque | Un unique acteur |
| sight | 460 | Valeur utilisée par le module de poursuite |
| chaseSpeed | 206 | Valeur utilisée par le module de poursuite |
| Lecture du lieu | A3-106-dark-not-safe | Seules les séquences originales activent ce pilote. |

### Préparation de l’attaque
`runner-windup` · États du Runner
Préparation de 0,85 seconde. Le corps reste sur place, l’orientation montre la cible, puis le contact réel est testé à l’impact.

| Élément | Référence | Contrat |
|---|---|---|
| Contrat | encounter-traque | Un unique acteur |
| windup | 0.85 | Valeur utilisée par le module de poursuite |
| depthSpeed | 1.18 | Valeur utilisée par le module de poursuite |

### Reprise après attaque
`runner-recover` · États du Runner
Après un hit ou une esquive, récupération de 1,30 seconde. Une sauvegarde ne rejoue pas une attaque suspendue.

| Élément | Référence | Contrat |
|---|---|---|
| Contrat | encounter-traque | Un unique acteur |
| recovery | 1.3 | Valeur utilisée par le module de poursuite |
| resumeGrace | 1.25 | Valeur utilisée par le module de poursuite |

### Pris dans le moule
`runner-trapped` · États du Runner
La coulée capture uniquement un Runner présent dans la plage du moule ; elle ne le téléporte pas au centre.

| Élément | Référence | Contrat |
|---|---|---|
| Contrat | encounter-rabattage | Un unique acteur |

### Neutralisé
`runner-dead` · États du Runner
Le refroidissement termine la menace de ce parcours original. Cette neutralisation ne valide pas le final de toute la campagne.

| Élément | Référence | Contrat |
|---|---|---|
| Contrat | encounter-rabattage | Un unique acteur |

### EEV éventré
`art-eev` · Repères visuels V105
Le renderer remplace 1 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

| Élément | Référence | Contrat |
|---|---|---|
| Fonction | drawLandmarkV105 | src/alien3-art-v105.js |
| Export | assets-v105/eev.png | Atlas de référence ; le runtime dessine directement les vecteurs. |

### Grilles du bloc
`art-cell` · Repères visuels V105
Le renderer remplace 2 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

| Élément | Référence | Contrat |
|---|---|---|
| Fonction | drawLandmarkV105 | src/alien3-art-v105.js |
| Export | assets-v105/cell.png | Atlas de référence ; le runtime dessine directement les vecteurs. |

### Pompe à flasques
`art-pump` · Repères visuels V105
Le renderer remplace 5 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

| Élément | Référence | Contrat |
|---|---|---|
| Fonction | drawLandmarkV105 | src/alien3-art-v105.js |
| Export | assets-v105/pump.png | Atlas de référence ; le runtime dessine directement les vecteurs. |

### Moule à vérins
`art-mold` · Repères visuels V105
Le renderer remplace 1 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

| Élément | Référence | Contrat |
|---|---|---|
| Fonction | drawLandmarkV105 | src/alien3-art-v105.js |
| Export | assets-v105/mold.png | Atlas de référence ; le runtime dessine directement les vecteurs. |

### Four maçonné
`art-furnace` · Repères visuels V105
Le renderer remplace 1 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

| Élément | Référence | Contrat |
|---|---|---|
| Fonction | drawLandmarkV105 | src/alien3-art-v105.js |
| Export | assets-v105/furnace.png | Atlas de référence ; le runtime dessine directement les vecteurs. |

### Pas du joueur
`sound-steps` · Audio V105
Le mouvement produit des signaux ; courir augmente le bruit de simulation, se baisser le réduit. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Contrat |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Appuis du Runner
`sound-foot-runner` · Audio V105
Panorama et atténuation utilisent la position du seul acteur. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Contrat |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Heurt métallique
`sound-metal` · Audio V105
F émet depuis la position actuelle, au sol et après un délai de deux secondes. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Contrat |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Préparation d’attaque
`sound-windup` · Audio V105
Indice sonore limité ; aucune carte exacte du prédateur. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Contrat |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Contact
`sound-bite` · Audio V105
Joué uniquement après le contact réellement validé. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Contrat |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Eau
`sound-water` · Audio V105
Associé aux commandes du collecteur. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Contrat |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Coulée
`sound-lead` · Audio V105
Associé à la commande physique de coulée. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Contrat |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Commande
`sound-switch` · Audio V105
Retour court d’interaction. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Contrat |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Bourdonnement
`sound-hum` · Audio V105
Oscillateur grave de 53/68 Hz selon la famille du lieu. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Contrat |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### Ventilation
`sound-vent` · Audio V105
Bruit filtré original, généré localement avec une graine fixe. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

| Élément | Référence | Contrat |
|---|---|---|
| Contrôle | AudioContext | Activation technique vérifiée, pas écoute physique sur matériel |
| Cycle de vie | FiorinaAudioV105 | Pause, désactivation et destruction ne font avancer aucun objectif. |

### PATH
`v105-PATH` · Règles V105
Tout déplacement IA suit une connexion réelle et les mêmes portes.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### NO-SNAP
`v105-NO-SNAP` · Règles V105
Un changement de cible inverse le chemin en cours sans téléporter le corps.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### FLOOR
`v105-FLOOR` · Règles V105
L’attaque exige proximité de hauteur et plan compatibles.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### DOOR
`v105-DOOR` · Règles V105
Un battant fermé bloque passage, vue et contact ; les détenus attendent le passage.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### MEMORY
`v105-MEMORY` · Règles V105
Une trace garde un lieu passé, pas la destination cachée du joueur.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### SERIAL
`v105-SERIAL` · Règles V105
Un bruit déjà consommé ne se réacquiert pas indéfiniment.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### WINDUP
`v105-WINDUP` · Règles V105
Le contact est différé de 0,85 seconde et vérifié au moment de l’impact.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### MISS
`v105-MISS` · Règles V105
Une attaque ratée impose une récupération, sans hit compensatoire.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### PRESENCE
`v105-PRESENCE` · Règles V105
La préparation du moule exige Morse et Dillon aux postes physiques.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### CAPTURE
`v105-CAPTURE` · Règles V105
La coulée ne capture que le Runner réellement dans le volume autorisé.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### AARON
`v105-AARON` · Règles V105
Aaron ne réapparaît pas dans la séquence finale.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### OWNER
`v105-OWNER` · Règles V105
Le pilote V105 et le pilote historique ne causent pas deux attaques du même Runner.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### PAUSE
`v105-PAUSE` · Règles V105
Pause, plan, archives, chargement et mort arrêtent la couche entière.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### SAVE
`v105-SAVE` · Règles V105
Le fichier est validé avant remplacement ; corruption et poses incohérentes sont refusées.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### GRACE
`v105-GRACE` · Règles V105
La reprise n’exécute pas une préparation d’attaque suspendue et laisse une courte grâce.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### FILES
`v105-FILES` · Règles V105
Les exports sont de vrais fichiers ; aucune persistance localStorage native n’est inventée.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### ART
`v105-ART` · Règles V105
Les repères améliorés conservent les appuis historiques ; les sprites natifs restent délégués sans opt-in vectoriel.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### AUDIO
`v105-AUDIO` · Règles V105
L’audio est éteint par défaut et ne produit jamais d’effet de gameplay par lui-même.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### NATIVE
`v105-NATIVE` · Règles V105
La livraison V105 avait constaté une base distante V86 ; cette constatation historique n’est pas une nouvelle vérification du dépôt. V106 exige les octets connus de V105 et n’annonce aucun build natif complet.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### SCOPE
`v105-SCOPE` · Règles V105
Une traversée originale du banc n’est pas une victoire de la campagne du film.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v105 | Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu. |

### Une lampe ne révèle pas un acteur à l’étage voisin.
`A3-106-light-floor` · Règles V106
Une lampe ne révèle pas un acteur à l’étage voisin.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Une porte fermée interrompt la contribution de la lampe.
`A3-106-light-door` · Règles V106
Une porte fermée interrompt la contribution de la lampe.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### La perception et le dessin utilisent les mêmes huit commandes existantes.
`A3-106-light-target` · Règles V106
La perception et le dessin utilisent les mêmes huit commandes existantes.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### La pénombre ralentit la reconnaissance
`A3-106-dark-not-safe` · Règles V106
La pénombre ralentit la reconnaissance ; elle ne rend pas invisible au contact.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Le feu du four et la coulée chaude restent lumineux lorsque la lampe de service est coupée.
`A3-106-light-native` · Règles V106
Le feu du four et la coulée chaude restent lumineux lorsque la lampe de service est coupée.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Le bruit conserve sa position au moment de son émission.
`A3-106-sound-origin` · Règles V106
Le bruit conserve sa position au moment de son émission.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### La distance sonore part de la position réelle du Runner sur son segment.
`A3-106-sound-edge` · Règles V106
La distance sonore part de la position réelle du Runner sur son segment.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Une porte fermée atténue le son
`A3-106-sound-door` · Règles V106
Une porte fermée atténue le son ; elle ne disparaît pas du trajet.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Le détour autorisé est évalué, pas seulement la distance à vol d’oiseau.
`A3-106-sound-route` · Règles V106
Le détour autorisé est évalué, pas seulement la distance à vol d’oiseau.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Un événement sonore ne doit pas déclencher une boucle infinie de recherche.
`A3-106-sound-consume` · Règles V106
Un événement sonore ne doit pas déclencher une boucle infinie de recherche.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### La perte de vue conserve la dernière trace, pas la nouvelle position cachée du joueur.
`A3-106-sight-trace` · Règles V106
La perte de vue conserve la dernière trace, pas la nouvelle position cachée du joueur.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Le Runner explore des connexions proches de la trace
`A3-106-search-room` · Règles V106
Le Runner explore des connexions proches de la trace ; il ne se téléporte pas entre elles.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### La morsure vérifie de nouveau étage, portée, profondeur et porte au moment de l’impact.
`A3-106-attack-recheck` · Règles V106
La morsure vérifie de nouveau étage, portée, profondeur et porte au moment de l’impact.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Une reprise n’exécute pas immédiatement une attaque déjà préparée.
`A3-106-attack-resume` · Règles V106
Une reprise n’exécute pas immédiatement une attaque déjà préparée.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Une fermeture est refusée lorsqu’un corps occupe le seuil.
`A3-106-door-occupant` · Règles V106
Une fermeture est refusée lorsqu’un corps occupe le seuil.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Une manœuvre de porte crée un seul bruit depuis cette porte.
`A3-106-door-noise` · Règles V106
Une manœuvre de porte crée un seul bruit depuis cette porte.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Attendre ne place jamais le détenu à son poste.
`A3-106-hold-physical` · Règles V106
Attendre ne place jamais le détenu à son poste.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Repartir conserve le segment et la destination du détenu.
`A3-106-hold-resume` · Règles V106
Repartir conserve le segment et la destination du détenu.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Pause, plan et archives arrêtent aussi les délais d’attente et la perception.
`A3-106-held-pause` · Règles V106
Pause, plan et archives arrêtent aussi les délais d’attente et la perception.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Un fichier incohérent est refusé avant toute modification de la session.
`A3-106-save-atomic` · Règles V106
Un fichier incohérent est refusé avant toute modification de la session.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Un acteur au repos doit être au point indiqué par sa navigation.
`A3-106-save-nav` · Règles V106
Un acteur au repos doit être au point indiqué par sa navigation.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Les bruits et attaques en transit ne sont pas rejoués à l’import.
`A3-106-save-no-events` · Règles V106
Les bruits et attaques en transit ne sont pas rejoués à l’import.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Une saisie dans un champ ne commande pas un détenu.
`A3-106-input-editing` · Règles V106
Une saisie dans un champ ne commande pas un détenu.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Le dessin ne découvre rien et ne modifie pas l’IA.
`A3-106-visual-pure` · Règles V106
Le dessin ne découvre rien et ne modifie pas l’IA.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | Séquences originales V105–V106 | Pas de remplacement aveugle du pilote de campagne natif. |
| Preuves | qa-v106/unit.json | Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium. |

### Éclairage de la prise d’air
`senses106-shore-light` · Lumière et perception
La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-spawn | X 259.5, sol 510 ; profondeur 1. |
| Influence | 245 unités | Mesure du jeu, pas des mètres relevés sur les décors du film. |
| Étage | 28 unités | Au-delà, la lampe ne contribue pas à la reconnaissance. |
| États | I | Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur. |
| Proche dans l’ombre | 74 unités | La pénombre n’annule pas la reconnaissance à courte distance. |
| Exceptions | A3-106-light-native | Four et coulée chaude gardent leur lumière propre. |

### Lampe de soin
`senses106-care-light` · Lumière et perception
La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-infirmary | X 1225, sol 510 ; profondeur 1. |
| Influence | 245 unités | Mesure du jeu, pas des mètres relevés sur les décors du film. |
| Étage | 28 unités | Au-delà, la lampe ne contribue pas à la reconnaissance. |
| États | I | Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur. |
| Proche dans l’ombre | 74 unités | La pénombre n’annule pas la reconnaissance à courte distance. |
| Exceptions | A3-106-light-native | Four et coulée chaude gardent leur lumière propre. |

### Éclairage de la coursive
`senses106-cell-light` · Lumière et perception
La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-cell-a | X 2020, sol 510 ; profondeur 1. |
| Influence | 245 unités | Mesure du jeu, pas des mètres relevés sur les décors du film. |
| Étage | 28 unités | Au-delà, la lampe ne contribue pas à la reconnaissance. |
| États | I | Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur. |
| Proche dans l’ombre | 74 unités | La pénombre n’annule pas la reconnaissance à courte distance. |
| Exceptions | A3-106-light-native | Four et coulée chaude gardent leur lumière propre. |

### Lampe des communications
`senses106-comms-light` · Lumière et perception
La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-comms-high | X 2785, sol 350 ; profondeur 1. |
| Influence | 245 unités | Mesure du jeu, pas des mètres relevés sur les décors du film. |
| Étage | 28 unités | Au-delà, la lampe ne contribue pas à la reconnaissance. |
| États | I | Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur. |
| Proche dans l’ombre | 74 unités | La pénombre n’annule pas la reconnaissance à courte distance. |
| Exceptions | A3-106-light-native | Four et coulée chaude gardent leur lumière propre. |

### Lampe de l’établi
`senses106-service-light` · Lumière et perception
La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-service-high | X 3110, sol 330 ; profondeur 1. |
| Influence | 245 unités | Mesure du jeu, pas des mètres relevés sur les décors du film. |
| Étage | 28 unités | Au-delà, la lampe ne contribue pas à la reconnaissance. |
| États | I | Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur. |
| Proche dans l’ombre | 74 unités | La pénombre n’annule pas la reconnaissance à courte distance. |
| Exceptions | A3-106-light-native | Four et coulée chaude gardent leur lumière propre. |

### Éclairage du creuset
`senses106-lead-light` · Lumière et perception
La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-leadworks | X 4265, sol 510 ; profondeur 1. |
| Influence | 245 unités | Mesure du jeu, pas des mètres relevés sur les décors du film. |
| Étage | 28 unités | Au-delà, la lampe ne contribue pas à la reconnaissance. |
| États | I | Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur. |
| Proche dans l’ombre | 74 unités | La pénombre n’annule pas la reconnaissance à courte distance. |
| Exceptions | A3-106-light-native | Four et coulée chaude gardent leur lumière propre. |

### Lampe du moule
`senses106-mold-light` · Lumière et perception
La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-mold | X 5043.5, sol 510 ; profondeur 1. |
| Influence | 245 unités | Mesure du jeu, pas des mètres relevés sur les décors du film. |
| Étage | 28 unités | Au-delà, la lampe ne contribue pas à la reconnaissance. |
| États | I | Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur. |
| Proche dans l’ombre | 74 unités | La pénombre n’annule pas la reconnaissance à courte distance. |
| Exceptions | A3-106-light-native | Four et coulée chaude gardent leur lumière propre. |

### Éclairage de la plateforme
`senses106-landing-light` · Lumière et perception
La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-extraction | X 6070, sol 510 ; profondeur 1. |
| Influence | 245 unités | Mesure du jeu, pas des mètres relevés sur les décors du film. |
| Étage | 28 unités | Au-delà, la lampe ne contribue pas à la reconnaissance. |
| États | I | Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur. |
| Proche dans l’ombre | 74 unités | La pénombre n’annule pas la reconnaissance à courte distance. |
| Exceptions | A3-106-light-native | Four et coulée chaude gardent leur lumière propre. |

### Acoustique · f161-infirmary-gate
`hearing106-f161-infirmary-gate` · Portes et acoustique
La porte existante conserve son passage et son état. Sa manœuvre réelle produit un bruit unique ; une fermeture refusée parce qu’un corps occupe le seuil ne produit pas ce bruit. Une porte fermée ajoute de l’atténuation, pas une téléportation sonore.

| Élément | Référence | Contrat |
|---|---|---|
| Connexion | f161-e03 | f161-infirmary → f161-cell-a |
| Amont | f161-infirmary | {'x': 1120, 'y': 510} |
| Aval | f161-cell-a | {'x': 1900, 'y': 510} |
| Atténuation porte | 280 | Coût acoustique abstrait ajouté au trajet. |
| Bruit de manœuvre | 0.78 | Puissance émise depuis la porte ; portée finale évaluée depuis le récepteur. |
| Bruit direct | A3-106-sound-edge | Un corridor de sol continu emploie la distance réelle plutôt qu’un détour artificiel par son point le plus proche. |

### Acoustique · f161-cellblock-gate
`hearing106-f161-cellblock-gate` · Portes et acoustique
La porte existante conserve son passage et son état. Sa manœuvre réelle produit un bruit unique ; une fermeture refusée parce qu’un corps occupe le seuil ne produit pas ce bruit. Une porte fermée ajoute de l’atténuation, pas une téléportation sonore.

| Élément | Référence | Contrat |
|---|---|---|
| Connexion | f161-e05 | f161-cell-b → f161-service-low |
| Amont | f161-cell-b | {'x': 2620, 'y': 510} |
| Aval | f161-service-low | {'x': 3070, 'y': 510} |
| Atténuation porte | 280 | Coût acoustique abstrait ajouté au trajet. |
| Bruit de manœuvre | 0.78 | Puissance émise depuis la porte ; portée finale évaluée depuis le récepteur. |
| Bruit direct | A3-106-sound-edge | Un corridor de sol continu emploie la distance réelle plutôt qu’un détour artificiel par son point le plus proche. |

### Acoustique · f161-leadworks-gate
`hearing106-f161-leadworks-gate` · Portes et acoustique
La porte existante conserve son passage et son état. Sa manœuvre réelle produit un bruit unique ; une fermeture refusée parce qu’un corps occupe le seuil ne produit pas ce bruit. Une porte fermée ajoute de l’atténuation, pas une téléportation sonore.

| Élément | Référence | Contrat |
|---|---|---|
| Connexion | f161-e07 | f161-bishop → f161-leadworks |
| Amont | f161-bishop | {'x': 3500, 'y': 510} |
| Aval | f161-leadworks | {'x': 4200, 'y': 510} |
| Atténuation porte | 280 | Coût acoustique abstrait ajouté au trajet. |
| Bruit de manœuvre | 0.78 | Puissance émise depuis la porte ; portée finale évaluée depuis le récepteur. |
| Bruit direct | A3-106-sound-edge | Un corridor de sol continu emploie la distance réelle plutôt qu’un détour artificiel par son point le plus proche. |

### Morse · présence et consignes
`order106-morse` · Coordination V106
Un ordre d’attente conserve la pose, le segment en cours et la destination. G relance le déplacement normal depuis le même endroit. Une fois son poste atteint, le détenu y reste plutôt que de recevoir une fausse nouvelle destination.

| Élément | Référence | Contrat |
|---|---|---|
| Parcours | encounter-rabattage | Présence limitée à la séquence concernée. |
| Départ | f161-bishop | Point réellement occupé à l’initialisation. |
| Poste | f161-lead-primer | Position vérifiée avant armement/coulée ; ordre et présence ne sont pas interchangeables. |
| Ordre à portée | 106 / 24 / 0,35 | Distance, différence de pieds et profondeur ; une porte fermée bloque la consigne. |
| Reprise | save106-session | L’ordre et la navigation sont validés et conservés par fichier. |

### Dillon · présence et consignes
`order106-dillon` · Coordination V106
Un ordre d’attente conserve la pose, le segment en cours et la destination. G relance le déplacement normal depuis le même endroit. Une fois son poste atteint, le détenu y reste plutôt que de recevoir une fausse nouvelle destination.

| Élément | Référence | Contrat |
|---|---|---|
| Parcours | encounter-rabattage | Présence limitée à la séquence concernée. |
| Départ | f161-command-post-node | Point réellement occupé à l’initialisation. |
| Poste | f161-piston-c-node | Position vérifiée avant armement/coulée ; ordre et présence ne sont pas interchangeables. |
| Ordre à portée | 106 / 24 / 0,35 | Distance, différence de pieds et profondeur ; une porte fermée bloque la consigne. |
| Reprise | save106-session | L’ordre et la navigation sont validés et conservés par fichier. |

### Aaron · présence et consignes
`order106-aaron` · Coordination V106
Aaron reste au poste de la séquence antérieure ; il ne reçoit pas une commande de déplacement et ne réapparaît pas dans la fonderie.

| Élément | Référence | Contrat |
|---|---|---|
| Parcours | encounter-traque | Présence limitée à la séquence concernée. |
| Départ | f161-clemens-bed | Point réellement occupé à l’initialisation. |
| Poste | f161-clemens-bed | Position vérifiée avant armement/coulée ; ordre et présence ne sont pas interchangeables. |
| Ordre à portée | 106 / 24 / 0,35 | Distance, différence de pieds et profondeur ; une porte fermée bloque la consigne. |
| Reprise | save106-session | L’ordre et la navigation sont validés et conservés par fichier. |

### Fichier de partie V106
`save106-session` · Reprises V106
L’enveloppe V106 contient le fichier V105 de base, le registre de perception et un dernier poste sûr séparé. La taille est bornée à 1 Mio et l’empreinte sert à détecter la corruption accidentelle, pas à garantir l’authenticité du joueur.

| Élément | Référence | Contrat |
|---|---|---|
| Migration | 105 → 106 | Une sauvegarde V105 valide reçoit un registre de perception neuf sans démarrer une autre séquence. |
| Vie privée | Local | Aucun téléchargement serveur ni compte ; pas de persistance localStorage annoncée. |
| Panneaux | Pause | L’import reprend en pause, sans relancer une attaque suspendue. |

### Dernier poste sûr
`save106-safe` · Reprises V106
Le poste sûr doit être vivant, actif, de la même séquence et ne pas avoir une progression future. Après échec, l’export fournit ce poste plutôt que de faire passer la pose morte pour une partie sauvegardable.

| Élément | Référence | Contrat |
|---|---|---|
| Reprendre | R | Le poste antérieur est utilisé ; l’attaque en transit est neutralisée en récupération. |
| Intégrité | save106-session | Le poste est validé lui aussi, pas seulement l’enveloppe principale. |
| Limite | Fichier explicite | Le point sûr n’est pas une sauvegarde automatique sur disque. |

### Position et navigation dans les reprises
`save106-navigation` · Reprises V106
Un acteur au repos doit être à son point déclaré ; un acteur en trajet doit appartenir au segment courant. Une pose falsifiée mais placée sur un autre sol valide reste refusée, même si son checksum a été recalculé.

| Élément | Référence | Contrat |
|---|---|---|
| Repos | Tolérance 7 unités | Mesurée au pied central du corps. |
| Mouvement | Segment courant | Conserver les coordonnées, ne pas téléporter pour rendre le fichier acceptable. |
| Événements transitoires | A3-106-save-no-events | Bruits, appels et attaques suspendus ne sont pas rejoués. |

### Examiner le relevé
`operation107-report` · Manœuvres V107
Action de 1,1 s dans la séquence « Un bruit dans les galeries ». L’opération ne donne pas son résultat au début : le propriétaire de progression V105 valide seulement après la durée et la dernière vérification. Le joueur peut s’éloigner sans être bloqué ; il perd alors l’avancement partiel.

| Élément | Référence | Contrat |
|---|---|---|
| Séquence | encounter-traque | Étape 1 → 2, pas une scène supplémentaire du film. |
| Station | station-report | Point f161-service-high ; centre X 3070.0, pied Y 330. |
| Appui | f161-service-high | Sol stable ; pas de saut ni de montée pendant le geste. |
| Accès | A3-107-depth | Portée 85 unités, hauteur 16 unités et profondeur 0,30. La position interpolée compte. |
| Interruption | A3-107-motion | Mouvement, relâchement, blessure, porte ou panneau ; pas d’objectif accordé. |
| Dessin | A3-107-draw-pure | Repère sur la pièce réelle : X 3052.63, Y 303.28. Aucune attache à la tête de Ripley. |
| Bruit | A3-107-machinery | Puissance abstraite 0.16, émission à la station ; cadence minimale 0,55 s même après annulation/reprise. |
| Commande accessible | access107-input | Appuyer conserve la durée, les mêmes vérifications et une annulation explicite. |

### Amorcer le collecteur
`operation107-prime` · Manœuvres V107
Action de 1,8 s dans la séquence « Le dernier rabattage ». L’opération ne donne pas son résultat au début : le propriétaire de progression V105 valide seulement après la durée et la dernière vérification. Le joueur peut s’éloigner sans être bloqué ; il perd alors l’avancement partiel.

| Élément | Référence | Contrat |
|---|---|---|
| Séquence | encounter-rabattage | Étape 1 → 2, pas une scène supplémentaire du film. |
| Station | station-water | Point f161-water-header ; centre X 4690.0, pied Y 330. |
| Appui | f161-water-header | Sol stable ; pas de saut ni de montée pendant le geste. |
| Accès | A3-107-depth | Portée 85 unités, hauteur 16 unités et profondeur 0,30. La position interpolée compte. |
| Interruption | A3-107-motion | Mouvement, relâchement, blessure, porte ou panneau ; pas d’objectif accordé. |
| Dessin | A3-107-draw-pure | Repère sur la pièce réelle : X 4745.00, Y 282.00. Aucune attache à la tête de Ripley. |
| Bruit | A3-107-machinery | Puissance abstraite 0.68, émission à la station ; cadence minimale 0,55 s même après annulation/reprise. |
| Commande accessible | access107-input | Appuyer conserve la durée, les mêmes vérifications et une annulation explicite. |

### Verrouiller le moule
`operation107-arm` · Manœuvres V107
Action de 1,25 s dans la séquence « Le dernier rabattage ». L’opération ne donne pas son résultat au début : le propriétaire de progression V105 valide seulement après la durée et la dernière vérification. Le joueur peut s’éloigner sans être bloqué ; il perd alors l’avancement partiel.

| Élément | Référence | Contrat |
|---|---|---|
| Séquence | encounter-rabattage | Étape 2 → 3, pas une scène supplémentaire du film. |
| Station | station-mold | Point f161-mold ; centre X 4920.0, pied Y 510. |
| Appui | f161-mold | Sol stable ; pas de saut ni de montée pendant le geste. |
| Accès | A3-107-depth | Portée 85 unités, hauteur 16 unités et profondeur 0,30. La position interpolée compte. |
| Interruption | A3-107-motion | Mouvement, relâchement, blessure, porte ou panneau ; pas d’objectif accordé. |
| Dessin | A3-107-draw-pure | Repère sur la pièce réelle : X 5010.50, Y 427.00. Aucune attache à la tête de Ripley. |
| Bruit | A3-107-machinery | Puissance abstraite 0.82, émission à la station ; cadence minimale 0,55 s même après annulation/reprise. |
| Commande accessible | access107-input | Appuyer conserve la durée, les mêmes vérifications et une annulation explicite. |

### Ouvrir l’eau
`operation107-cool` · Manœuvres V107
Action de 2 s dans la séquence « Le dernier rabattage ». L’opération ne donne pas son résultat au début : le propriétaire de progression V105 valide seulement après la durée et la dernière vérification. Le joueur peut s’éloigner sans être bloqué ; il perd alors l’avancement partiel.

| Élément | Référence | Contrat |
|---|---|---|
| Séquence | encounter-rabattage | Étape 4 → 5, pas une scène supplémentaire du film. |
| Station | station-water | Point f161-water-header ; centre X 4690.0, pied Y 330. |
| Appui | f161-water-header | Sol stable ; pas de saut ni de montée pendant le geste. |
| Accès | A3-107-depth | Portée 85 unités, hauteur 16 unités et profondeur 0,30. La position interpolée compte. |
| Interruption | A3-107-motion | Mouvement, relâchement, blessure, porte ou panneau ; pas d’objectif accordé. |
| Dessin | A3-107-draw-pure | Repère sur la pièce réelle : X 4745.00, Y 282.00. Aucune attache à la tête de Ripley. |
| Bruit | A3-107-machinery | Puissance abstraite 0.96, émission à la station ; cadence minimale 0,55 s même après annulation/reprise. |
| Commande accessible | access107-input | Appuyer conserve la durée, les mêmes vérifications et une annulation explicite. |

### Les opérations terminées appellent le propriétaire d’objectif existant, sans valider deux fois la même étape.
`A3-107-one-owner` · Règles V107
Les opérations terminées appellent le propriétaire d’objectif existant, sans valider deux fois la même étape.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### La commande exige un appui stable au bon étage.
`A3-107-floor` · Règles V107
La commande exige un appui stable au bon étage.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### La profondeur réellement interpolée est testée pendant toute la manœuvre.
`A3-107-depth` · Règles V107
La profondeur réellement interpolée est testée pendant toute la manœuvre.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Une porte fermée interrompt la manœuvre comme elle en empêche le début.
`A3-107-door` · Règles V107
Une porte fermée interrompt la manœuvre comme elle en empêche le début.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Relâcher E interrompt la manœuvre en mode maintien.
`A3-107-release` · Règles V107
Relâcher E interrompt la manœuvre en mode maintien.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Le mode Appuyer conserve la durée et les contraintes
`A3-107-toggle` · Règles V107
Le mode Appuyer conserve la durée et les contraintes ; une seconde pression annule.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Marcher, grimper, sauter ou changer de profondeur interrompt sans bloquer le joueur.
`A3-107-motion` · Règles V107
Marcher, grimper, sauter ou changer de profondeur interrompt sans bloquer le joueur.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Une blessure interrompt
`A3-107-damage` · Règles V107
Une blessure interrompt ; les dommages ne sont pas neutralisés par la manœuvre.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Pause, plan, archives et perte de focus interrompent
`A3-107-modal` · Règles V107
Pause, plan, archives et perte de focus interrompent ; aucun objectif ne progresse hors jeu.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Morse et Dillon doivent tenir leur poste pendant tout le verrouillage du moule.
`A3-107-participants` · Règles V107
Morse et Dillon doivent tenir leur poste pendant tout le verrouillage du moule.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### La présence à une station est physique, jamais déduite du nom de la salle.
`A3-107-no-remote` · Règles V107
La présence à une station est physique, jamais déduite du nom de la salle.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Chaque bruit de manœuvre part de sa station, pas de la position future du joueur.
`A3-107-machinery` · Règles V107
Chaque bruit de manœuvre part de sa station, pas de la position future du joueur.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Les sons sont émis à cadence bornée, pas une fois par image.
`A3-107-sound-cadence` · Règles V107
Les sons sont émis à cadence bornée, pas une fois par image.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Un détenu produit des pas seulement lorsque sa position réelle change.
`A3-107-crew-footsteps` · Règles V107
Un détenu produit des pas seulement lorsque sa position réelle change.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Un ordre audible provient du détenu auquel Ripley parle.
`A3-107-crew-order` · Règles V107
Un ordre audible provient du détenu auquel Ripley parle.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Un bruit de matériel peut attirer le Runner, mais ne lui livre pas la position cachée de Ripley.
`A3-107-trace` · Règles V107
Un bruit de matériel peut attirer le Runner, mais ne lui livre pas la position cachée de Ripley.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### La coulée reste une commande brève à utiliser quand le Runner est dans le moule
`A3-107-emergency-lever` · Règles V107
La coulée reste une commande brève à utiliser quand le Runner est dans le moule ; aucun délai arbitraire ne le téléporte ou l’y immobilise.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Une manœuvre partielle n’est jamais reprise automatiquement depuis un fichier.
`A3-107-no-partial-import` · Règles V107
Une manœuvre partielle n’est jamais reprise automatiquement depuis un fichier.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Le dernier poste sûr conserve le mode de commande
`A3-107-safe-settings` · Règles V107
Le dernier poste sûr conserve le mode de commande ; l’import reprend en pause.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Les opérations consignées doivent correspondre aux étapes réellement acquises.
`A3-107-strict-sequence` · Règles V107
Les opérations consignées doivent correspondre aux étapes réellement acquises.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Les fichiers V105/V106 valides migrent sans devoir refaire leurs objectifs déjà terminés.
`A3-107-old-files` · Règles V107
Les fichiers V105/V106 valides migrent sans devoir refaire leurs objectifs déjà terminés.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Le dessin montre l’avancement mais ne change ni les étapes, ni les sons, ni la sauvegarde.
`A3-107-draw-pure` · Règles V107
Le dessin montre l’avancement mais ne change ni les étapes, ni les sons, ni la sauvegarde.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Aucun nouveau rang ni compteur de collecte obligatoire n’est ajouté.
`A3-107-no-score` · Règles V107
Aucun nouveau rang ni compteur de collecte obligatoire n’est ajouté.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | automated/local |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### La couche s’active uniquement dans les deux séquences originales, pas dans toutes les cinématiques historiques.
`A3-107-scope` · Règles V107
La couche s’active uniquement dans les deux séquences originales, pas dans toutes les cinématiques historiques.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | qa-v107/unit.json | scope |
| Périmètre | Séquences originales | Le contrôleur simplifié du banc n’est pas le jeu principal complet. |

### Petit poste du collecteur
`operator107-water` · Postes de commande
Le point de commande historique du collecteur ne possédait pas de petit pupitre propre. V107 place quatre composants sur sa plateforme réelle : boîtier, tige, volant et cadran. Le cadran suit l’avancement de l’amorçage, puis l’état acquis. Ce petit ensemble décoratif n’ajoute aucune collision, nouvelle route ou collecte.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-water-header | La plateforme existante conserve son étendue et sa hauteur. |
| housing | water-housing-107 | X 4733 ; Y 292 ; 26 × 38 ; pose floor, collision none. |
| pipe | water-stem-107 | X 4741 ; Y 246 ; 8 × 84 ; pose floor, collision none. |
| wheel | water-wheel-107 | X 4729 ; Y 266 ; 32 × 32 ; pose bracket, collision none. |
| gauge | water-gauge-107 | X 4734 ; Y 241 ; 22 × 22 ; pose pipe, collision none. |

### Boîtier du collecteur
`water-housing-107` · Composants V107
Composant du petit poste de commande ; position fixée à un appui du niveau, jamais à la caméra ou au personnage.

| Élément | Référence | Contrat |
|---|---|---|
| Ensemble | operator107-water | Raccord visuel, pas nouvelle machine de physique. |
| Appui | f161-water-header | X 4733 ; Y 292 ; largeur 26 ; hauteur 38. |
| Pose | floor | Collision : aucune. |

### Tige et conduite
`water-stem-107` · Composants V107
Composant du petit poste de commande ; position fixée à un appui du niveau, jamais à la caméra ou au personnage.

| Élément | Référence | Contrat |
|---|---|---|
| Ensemble | operator107-water | Raccord visuel, pas nouvelle machine de physique. |
| Appui | f161-water-header | X 4741 ; Y 246 ; largeur 8 ; hauteur 84. |
| Pose | floor | Collision : aucune. |

### Volant de service
`water-wheel-107` · Composants V107
Composant du petit poste de commande ; position fixée à un appui du niveau, jamais à la caméra ou au personnage.

| Élément | Référence | Contrat |
|---|---|---|
| Ensemble | operator107-water | Raccord visuel, pas nouvelle machine de physique. |
| Appui | f161-water-header | X 4729 ; Y 266 ; largeur 32 ; hauteur 32. |
| Pose | bracket | Collision : aucune. |

### Cadran de pression
`water-gauge-107` · Composants V107
Composant du petit poste de commande ; position fixée à un appui du niveau, jamais à la caméra ou au personnage.

| Élément | Référence | Contrat |
|---|---|---|
| Ensemble | operator107-water | Raccord visuel, pas nouvelle machine de physique. |
| Appui | f161-water-header | X 4734 ; Y 241 ; largeur 22 ; hauteur 22. |
| Pose | pipe | Collision : aucune. |

### Maintenir ou appuyer
`access107-input` · Commandes accessibles
Le mode Maintenir demande de garder E. Le mode Appuyer démarre par une pression et s’annule par une autre. Les deux durent le même temps et restent interrompus par mouvement, blessure, porte, pause, plan ou archives. Le bouton tactile Agir reçoit un vrai maintien et libère l’état à l’annulation du pointeur.

| Élément | Référence | Contrat |
|---|---|---|
| Réglage | Options | Choix explicite dans le menu ; sauvegardé par fichier. |
| Sauvegarde | save107-current | Le choix est conservé sans reprendre une commande partielle. |
| Limite | Matériel | Le pointeur a été testé dans Chromium ; aucune manette physique n’a été qualifiée. |

### Fichier V107
`save107-current` · Reprises V107
L’enveloppe contient la session V106 vérifiée, le registre des manœuvres et un dernier poste sûr séparé. Aucune opération active n’est sérialisée. Les tâches consignées doivent correspondre à la progression existante, même si l’empreinte extérieure a été recalculée.

| Élément | Référence | Contrat |
|---|---|---|
| Limite | 1 Mio | La taille est vérifiée avant analyse. |
| Contrat | A3-107-no-partial-import | Une reprise ne valide pas spontanément une commande. |
| Authenticité | Empreinte FNV | Détection de corruption, pas protection anti-triche. |

### Reprendre sans rejouer le geste
`save107-checkpoint` · Reprises V107
Le poste sûr doit rester vivant et actif, dans la même séquence, à un stade non futur. Une fin de manœuvre prépare son registre stable avant le callback de checkpoint ; une manœuvre partielle ne peut pas remplacer le poste sûr.

| Élément | Référence | Contrat |
|---|---|---|
| En cas d’échec | R | Repartir d’un poste antérieur, pas de la pose morte. |
| Options | access107-input | Le réglage Maintenir/Appuyer est conservé dans le poste. |
| Atomicité | save107-current | Le fichier entier est vérifié avant remplacement de la session. |

### Reprendre les fichiers V105 et V106
`save107-migration` · Reprises V107
Les fichiers antérieurs valides gardent leur progression. Les tâches déjà acquises sont dérivées des étapes et ne doivent pas être rejouées. Le poste sûr V106 est migré distinctement de l’état courant, même si sa progression est antérieure.

| Élément | Référence | Contrat |
|---|---|---|
| Héritage | save106-navigation | Position, navigation, portes et présence des participants restent contrôlées. |
| Reprise | Pause | L’import ne reprend ni touche maintenue ni bruit en transit. |
| Pas de cloud | Fichier explicite | Aucune sauvegarde automatique sur disque ni compte externe. |

### La préparation s’entend
`sound107-work` · Bruits de préparation
Les quatre manœuvres émettent depuis leur station. Les pas des détenus dépendent de leur distance réellement parcourue ; un détenu arrêté ne marche pas sur place. Un ordre audible provient du détenu qui répond à Ripley. Ces événements entrent dans le même calcul de portée V106 que les bruits du joueur.

| Élément | Référence | Contrat |
|---|---|---|
| Cadence des machines | 0,55 s | Un nouveau geste n’efface pas la limite anti-rafale. |
| Pas des détenus | 62 unités | Puissance 0,23 ; silence lorsque le corps ne se déplace pas. |
| Consigne | 0,46 | Puissance abstraite ; portée calculée sur les passages et portes. |
| Limite narrative | encounter-rabattage | Pendant les premiers préparatifs, le Runner est volontairement dormant ; l’ambiance sonore ne change pas cette condition de la séquence. |

### Trois identités de boulon, pas un stock abstrait qui se régénère.
`A3-108-stock` · Règles V108
Trois identités de boulon, pas un stock abstrait qui se régénère.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Le lancer commence à la main de Ripley et conserve sa profondeur.
`A3-108-origin` · Règles V108
Le lancer commence à la main de Ripley et conserve sa profondeur.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Le lancer suit la direction du personnage
`A3-108-facing` · Règles V108
Le lancer suit la direction du personnage ; aucune cible distante n’est choisie par téléportation.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Le boulon suit un arc intégré en sous-pas
`A3-108-arc` · Règles V108
Le boulon suit un arc intégré en sous-pas ; les déplacements balayent leur segment.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Le sol, le dessous des plateformes et les portes fermées arrêtent ou font rebondir l’objet.
`A3-108-solid` · Règles V108
Le sol, le dessous des plateformes et les portes fermées arrêtent ou font rebondir l’objet.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Les alcôves et objets du fond ne sont pas des obstacles physiques inventés.
`A3-108-art` · Règles V108
Les alcôves et objets du fond ne sont pas des obstacles physiques inventés.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | scope / automated |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Le bruit est émis au point d’impact, à sa profondeur et son étage.
`A3-108-impact` · Règles V108
Le bruit est émis au point d’impact, à sa profondeur et son étage.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Aucun bruit de diversion n’est émis avant le premier impact.
`A3-108-silent-air` · Règles V108
Aucun bruit de diversion n’est émis avant le premier impact.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Deux rebonds amortis au maximum, puis immobilisation au sol.
`A3-108-bounce` · Règles V108
Deux rebonds amortis au maximum, puis immobilisation au sol.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Un délai empêche un obstacle mince de déclencher une rafale de sons.
`A3-108-voice-limit` · Règles V108
Un délai empêche un obstacle mince de déclencher une rafale de sons.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Le bruit est traité par l’audition existante
`A3-108-attention` · Règles V108
Le bruit est traité par l’audition existante ; il ne force ni reconnaissance ni annulation d’attaque.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Le Runner reçoit la dernière origine du bruit, jamais la position cachée actuelle du joueur.
`A3-108-trace` · Règles V108
Le Runner reçoit la dernière origine du bruit, jamais la position cachée actuelle du joueur.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Le prédateur reste dormant durant la préparation du piège qui le prévoit.
`A3-108-dormant` · Règles V108
Le prédateur reste dormant durant la préparation du piège qui le prévoit.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Un boulon ne blesse et ne fige aucun acteur.
`A3-108-no-damage` · Règles V108
Un boulon ne blesse et ne fige aucun acteur.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | scope / automated |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Ramasser exige appui, même profondeur, même étage et passage dégagé.
`A3-108-near-pickup` · Règles V108
Ramasser exige appui, même profondeur, même étage et passage dégagé.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Le même boulon repasse dans la poche, sans produire de copie.
`A3-108-recover` · Règles V108
Le même boulon repasse dans la poche, sans produire de copie.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Un objet tombé hors du niveau ou dans le plomb chaud est perdu pour ce parcours.
`A3-108-lost` · Règles V108
Un objet tombé hors du niveau ou dans le plomb chaud est perdu pour ce parcours.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Une manœuvre active empêche le lancer
`A3-108-busy` · Règles V108
Une manœuvre active empêche le lancer ; sa durée et son propriétaire ne sont pas modifiés.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### La cadence du lancer ne dépend pas du nombre de répétitions clavier.
`A3-108-limited-rate` · Règles V108
La cadence du lancer ne dépend pas du nombre de répétitions clavier.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Pause, plan, archives, échec et perte de focus suspendent les objets.
`A3-108-modal` · Règles V108
Pause, plan, archives, échec et perte de focus suspendent les objets.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Fermer un panneau ne déclenche pas un lancer qui avait été refusé.
`A3-108-no-autothrow` · Règles V108
Fermer un panneau ne déclenche pas un lancer qui avait été refusé.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Boutons tactiles et clavier appellent les mêmes méthodes de lancer et de récupération.
`A3-108-pointer` · Règles V108
Boutons tactiles et clavier appellent les mêmes méthodes de lancer et de récupération.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Le fichier conserve le mouvement d’un boulon en vol, mais aucun son en attente.
`A3-108-save-air` · Règles V108
Le fichier conserve le mouvement d’un boulon en vol, mais aucun son en attente.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### La position au repos doit correspondre à un support réel.
`A3-108-save-ground` · Règles V108
La position au repos doit correspondre à un support réel.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Les états poche, vol, sol et perdu doivent toujours totaliser trois objets.
`A3-108-save-count` · Règles V108
Les états poche, vol, sol et perdu doivent toujours totaliser trois objets.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Le poste sûr conserve son stock propre, distinct de la situation courante.
`A3-108-safe` · Règles V108
Le poste sûr conserve son stock propre, distinct de la situation courante.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Les fichiers V105, V106 et V107 valides reçoivent une réserve initiale lors de la migration.
`A3-108-migration` · Règles V108
Les fichiers V105, V106 et V107 valides reçoivent une réserve initiale lors de la migration.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### La validation vérifie aussi les positions et les invariants
`A3-108-checksum` · Règles V108
La validation vérifie aussi les positions et les invariants ; l’empreinte seule ne suffit pas.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Dessiner l’arc ou les impacts n’avance ni physique ni audition.
`A3-108-render` · Règles V108
Dessiner l’arc ou les impacts n’avance ni physique ni audition.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | automated / browser |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Mécanique originale du banc et des séquences optionnelles
`A3-108-scope` · Règles V108
Mécanique originale du banc et des séquences optionnelles ; aucun équipement natif de campagne remplacé.

| Élément | Référence | Contrat |
|---|---|---|
| Vérification | qa-v108/unit.json | scope / automated |
| Champ d’application | encounter-traque | Banc à contrôleur simplifié et séquences originales ; pas campagne native complète. |

### Dans la poche
`state108-pocket` · États des boulons
Aucune pose mondiale : X et Y sont nuls, les vitesses valent zéro. Le compteur de lancers reste conservé pour empêcher la copie d’un même objet.

| Élément | Référence | Contrat |
|---|---|---|
| Transition | A3-108-save-count | La touche T prend une identité disponible, jamais un nouvel objet. |
| Limite | A3-108-no-damage | Aucun dégât, étourdissement ou blocage d’acteur. |

### En vol
`state108-flying` · États des boulons
Position, vitesse, profondeur et origine sont conservées. La gravité et les intersections sont calculées en sous-pas ; un événement sonore n’est produit que lors d’un impact réel.

| Élément | Référence | Contrat |
|---|---|---|
| Transition | A3-108-save-count | Un import conserve la trajectoire et attend la reprise explicite. |
| Limite | A3-108-no-damage | Aucun dégât, étourdissement ou blocage d’acteur. |

### Posé au sol
`state108-rest` · États des boulons
Le pied du boulon, y + 3,5, doit coïncider avec la hauteur d’un support identifié. Il ne revient pas automatiquement dans la poche.

| Élément | Référence | Contrat |
|---|---|---|
| Transition | A3-108-save-count | La touche Y exige proximité, appui, même étage, même profondeur et aucun battant fermé interposé. |
| Limite | A3-108-no-damage | Aucun dégât, étourdissement ou blocage d’acteur. |

### Perdu
`state108-lost` · États des boulons
Un boulon hors du niveau ou dans le plomb chaud n’est plus récupérable dans ce parcours. La même identité reste comptée comme perdue.

| Élément | Référence | Contrat |
|---|---|---|
| Transition | A3-108-save-count | Le dernier poste sûr peut contenir un état antérieur distinct ; aucune recharge temporelle n’est ajoutée. |
| Limite | A3-108-no-damage | Aucun dégât, étourdissement ou blocage d’acteur. |

### Support de lancer · support-0
`surface108-support-0` · Surfaces de collision V108
Surface fusionnée à la hauteur Y 190, étendue X 2055 à 2755, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

| Élément | Référence | Contrat |
|---|---|---|
| Coordonnées | A3-108-solid | X 2055, Y 190, largeur 700, hauteur 12 unités du jeu. |
| Repos | state108-rest | Centre du boulon posé à Y 186.5. |
| Balayage | A3-108-arc | Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme. |

### Support de lancer · support-1
`surface108-support-1` · Surfaces de collision V108
Surface fusionnée à la hauteur Y 190, étendue X 3225 à 3395, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

| Élément | Référence | Contrat |
|---|---|---|
| Coordonnées | A3-108-solid | X 3225, Y 190, largeur 170, hauteur 12 unités du jeu. |
| Repos | state108-rest | Centre du boulon posé à Y 186.5. |
| Balayage | A3-108-arc | Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme. |

### Support de lancer · support-2
`surface108-support-2` · Surfaces de collision V108
Surface fusionnée à la hauteur Y 190, étendue X 4635 à 4805, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

| Élément | Référence | Contrat |
|---|---|---|
| Coordonnées | A3-108-solid | X 4635, Y 190, largeur 170, hauteur 12 unités du jeu. |
| Repos | state108-rest | Centre du boulon posé à Y 186.5. |
| Balayage | A3-108-arc | Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme. |

### Support de lancer · support-3
`surface108-support-3` · Surfaces de collision V108
Surface fusionnée à la hauteur Y 190, étendue X 5865 à 6055, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

| Élément | Référence | Contrat |
|---|---|---|
| Coordonnées | A3-108-solid | X 5865, Y 190, largeur 190, hauteur 12 unités du jeu. |
| Repos | state108-rest | Centre du boulon posé à Y 186.5. |
| Balayage | A3-108-arc | Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme. |

### Support de lancer · support-4
`surface108-support-4` · Surfaces de collision V108
Surface fusionnée à la hauteur Y 330, étendue X 670 à 890, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

| Élément | Référence | Contrat |
|---|---|---|
| Coordonnées | A3-108-solid | X 670, Y 330, largeur 220, hauteur 12 unités du jeu. |
| Repos | state108-rest | Centre du boulon posé à Y 326.5. |
| Balayage | A3-108-arc | Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme. |

### Support de lancer · support-5
`surface108-support-5` · Surfaces de collision V108
Surface fusionnée à la hauteur Y 330, étendue X 2855 à 5880, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

| Élément | Référence | Contrat |
|---|---|---|
| Coordonnées | A3-108-solid | X 2855, Y 330, largeur 3025, hauteur 12 unités du jeu. |
| Repos | state108-rest | Centre du boulon posé à Y 326.5. |
| Balayage | A3-108-arc | Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme. |

### Support de lancer · support-6
`surface108-support-6` · Surfaces de collision V108
Surface fusionnée à la hauteur Y 330, étendue X 5945 à 6195, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

| Élément | Référence | Contrat |
|---|---|---|
| Coordonnées | A3-108-solid | X 5945, Y 330, largeur 250, hauteur 12 unités du jeu. |
| Repos | state108-rest | Centre du boulon posé à Y 326.5. |
| Balayage | A3-108-arc | Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme. |

### Support de lancer · support-7
`surface108-support-7` · Surfaces de collision V108
Surface fusionnée à la hauteur Y 350, étendue X 1175 à 2810, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

| Élément | Référence | Contrat |
|---|---|---|
| Coordonnées | A3-108-solid | X 1175, Y 350, largeur 1635, hauteur 12 unités du jeu. |
| Repos | state108-rest | Centre du boulon posé à Y 346.5. |
| Balayage | A3-108-arc | Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme. |

### Support de lancer · support-8
`surface108-support-8` · Surfaces de collision V108
Surface fusionnée à la hauteur Y 510, étendue X 50 à 6190, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

| Élément | Référence | Contrat |
|---|---|---|
| Coordonnées | A3-108-solid | X 50, Y 510, largeur 6140, hauteur 12 unités du jeu. |
| Repos | state108-rest | Centre du boulon posé à Y 506.5. |
| Balayage | A3-108-arc | Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme. |

### Support de lancer · support-9
`surface108-support-9` · Surfaces de collision V108
Surface fusionnée à la hauteur Y 630, étendue X 710 à 930, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

| Élément | Référence | Contrat |
|---|---|---|
| Coordonnées | A3-108-solid | X 710, Y 630, largeur 220, hauteur 12 unités du jeu. |
| Repos | state108-rest | Centre du boulon posé à Y 626.5. |
| Balayage | A3-108-arc | Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme. |

### Support de lancer · support-10
`surface108-support-10` · Surfaces de collision V108
Surface fusionnée à la hauteur Y 630, étendue X 1940 à 2160, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

| Élément | Référence | Contrat |
|---|---|---|
| Coordonnées | A3-108-solid | X 1940, Y 630, largeur 220, hauteur 12 unités du jeu. |
| Repos | state108-rest | Centre du boulon posé à Y 626.5. |
| Balayage | A3-108-arc | Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme. |

### Support de lancer · support-11
`surface108-support-11` · Surfaces de collision V108
Surface fusionnée à la hauteur Y 630, étendue X 2875 à 4640, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

| Élément | Référence | Contrat |
|---|---|---|
| Coordonnées | A3-108-solid | X 2875, Y 630, largeur 1765, hauteur 12 unités du jeu. |
| Repos | state108-rest | Centre du boulon posé à Y 626.5. |
| Balayage | A3-108-arc | Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme. |

### Support de lancer · support-12
`surface108-support-12` · Surfaces de collision V108
Surface fusionnée à la hauteur Y 630, étendue X 4670 à 5175, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

| Élément | Référence | Contrat |
|---|---|---|
| Coordonnées | A3-108-solid | X 4670, Y 630, largeur 505, hauteur 12 unités du jeu. |
| Repos | state108-rest | Centre du boulon posé à Y 626.5. |
| Balayage | A3-108-arc | Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme. |

### Impact sur f161-infirmary-gate
`gate108-f161-infirmary-gate` · Portes et projectiles
Porte existante de Fiorina : X 1488, Y 378, dimensions 44 × 132. Ouverte, elle laisse passer le boulon. Fermée, le segment de vol peut la rencontrer et repartir en sens inverse avec une vitesse amortie.

| Élément | Référence | Contrat |
|---|---|---|
| Porte d’origine | f161-infirmary-gate | Aucun nouveau battant ni verrou de mission. |
| Origine sonore | A3-108-impact | L’événement vient du point touché sur le battant, pas de la position actuelle de Ripley. |
| Sauvegarde | save108-current | La validation reconstruit la géométrie réelle depuis les états de porte sauvegardés. |

### Impact sur f161-cellblock-gate
`gate108-f161-cellblock-gate` · Portes et projectiles
Porte existante de Fiorina : X 2823, Y 378, dimensions 44 × 132. Ouverte, elle laisse passer le boulon. Fermée, le segment de vol peut la rencontrer et repartir en sens inverse avec une vitesse amortie.

| Élément | Référence | Contrat |
|---|---|---|
| Porte d’origine | f161-cellblock-gate | Aucun nouveau battant ni verrou de mission. |
| Origine sonore | A3-108-impact | L’événement vient du point touché sur le battant, pas de la position actuelle de Ripley. |
| Sauvegarde | save108-current | La validation reconstruit la géométrie réelle depuis les états de porte sauvegardés. |

### Impact sur f161-leadworks-gate
`gate108-f161-leadworks-gate` · Portes et projectiles
Porte existante de Fiorina : X 3828, Y 378, dimensions 44 × 132. Ouverte, elle laisse passer le boulon. Fermée, le segment de vol peut la rencontrer et repartir en sens inverse avec une vitesse amortie.

| Élément | Référence | Contrat |
|---|---|---|
| Porte d’origine | f161-leadworks-gate | Aucun nouveau battant ni verrou de mission. |
| Origine sonore | A3-108-impact | L’événement vient du point touché sur le battant, pas de la position actuelle de Ripley. |
| Sauvegarde | save108-current | La validation reconstruit la géométrie réelle depuis les états de porte sauvegardés. |

### Lancer un boulon
`input108-throw` · Commandes V108
T ou le bouton « Lancer » prend l’un des trois boulons en poche. Le départ se fait à la main et suit la direction du corps. Il n’existe pas de paramètre de ciblage distant ni de lancer instantanément matérialisé près du Runner.

| Élément | Référence | Contrat |
|---|---|---|
| Poche | state108-pocket | Réserve maximale 3 ; cadence 0.85 s. |
| Appui | A3-108-origin | Ripley doit être vivante, au sol et hors d’une montée. |
| Conflit | A3-108-busy | Une manœuvre active conserve la priorité. |
| Arc | state108-flying | Vitesse initiale horizontale 345 ; verticale -142 ; gravité 620 en unités du jeu. |

### Ramasser le boulon
`input108-recover` · Commandes V108
Y ou le bouton « Ramasser » récupère une identité posée à portée réelle. Ce n’est ni une aspiration à distance ni un remplissage automatique après un lancer.

| Élément | Référence | Contrat |
|---|---|---|
| Portée | A3-108-near-pickup | 42 unités horizontales, 15 verticales et 0.28 de profondeur. |
| Surface | state108-rest | Le support doit encore justifier le repos. |
| Conservation | A3-108-recover | Un second appui ne produit pas de quatrième objet. |

### Boulon 1
`object108-bolt-1` · Objets persistants V108
Identité persistante d’un objet métallique ordinaire. La forme et les capacités sont les mêmes pour les trois objets ; ces fiches ne correspondent pas à trois nouveaux modèles artistiques.

| Élément | Référence | Contrat |
|---|---|---|
| Au départ | state108-pocket | Dans la poche, jamais déjà posé devant le joueur. |
| En déplacement | state108-flying | Origine et nombre de lancers restent associés à cette identité. |
| Récupération | input108-recover | Le même identifiant est rendu à la poche. |
| Perte | state108-lost | Aucune duplication ni réapparition pendant le parcours. |

### Boulon 2
`object108-bolt-2` · Objets persistants V108
Identité persistante d’un objet métallique ordinaire. La forme et les capacités sont les mêmes pour les trois objets ; ces fiches ne correspondent pas à trois nouveaux modèles artistiques.

| Élément | Référence | Contrat |
|---|---|---|
| Au départ | state108-pocket | Dans la poche, jamais déjà posé devant le joueur. |
| En déplacement | state108-flying | Origine et nombre de lancers restent associés à cette identité. |
| Récupération | input108-recover | Le même identifiant est rendu à la poche. |
| Perte | state108-lost | Aucune duplication ni réapparition pendant le parcours. |

### Boulon 3
`object108-bolt-3` · Objets persistants V108
Identité persistante d’un objet métallique ordinaire. La forme et les capacités sont les mêmes pour les trois objets ; ces fiches ne correspondent pas à trois nouveaux modèles artistiques.

| Élément | Référence | Contrat |
|---|---|---|
| Au départ | state108-pocket | Dans la poche, jamais déjà posé devant le joueur. |
| En déplacement | state108-flying | Origine et nombre de lancers restent associés à cette identité. |
| Récupération | input108-recover | Le même identifiant est rendu à la poche. |
| Perte | state108-lost | Aucune duplication ni réapparition pendant le parcours. |

### Fichier V108
`save108-current` · Reprises V108
La session V107 est validée puis le registre des trois boulons. Un objet en vol conserve sa pose, sa vitesse et sa profondeur ; un objet posé doit coïncider avec un appui réel. L’enveloppe est limitée à 1 Mio.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | A3-108-checksum | L’empreinte FNV détecte une corruption, pas une signature anti-triche. Les invariants et collisions sont vérifiés ensuite. |
| Comptage | A3-108-save-count | Trois états au total, identités uniques, compteurs de lancers et de récupérations cohérents. |
| Import | A3-108-save-air | Reprise en pause, sans refaire l’impact précédent. |

### Poche du dernier poste sûr
`save108-checkpoint` · Reprises V108
Le poste sûr garde sa réserve et ses poses propres, distinctes de la partie courante. Une manœuvre active ne remplace pas ce poste. Il doit être vivant, actif, dans la même séquence et à un stade non futur.

| Élément | Référence | Contrat |
|---|---|---|
| Reprise | save107-checkpoint | Le propriétaire V107 garde son registre de gestes terminés. |
| Atomicité | save108-current | La validation d’un poste corrompu refuse tout le fichier avant de remplacer la session. |

### Migrer un fichier antérieur
`save108-migration` · Reprises V108
Les fichiers V105, V106 et V107 valides reçoivent trois boulons en poche. Le poste sûr antérieur est migré séparément. Aucun état d’attente, lumière ou objectif déjà acquis n’est remplacé par une nouvelle partie.

| Élément | Référence | Contrat |
|---|---|---|
| Sources | save106-navigation | Contrôles historiques de position et navigation conservés. |
| Manœuvres | save107-current | Pas de préparation partielle réactivée. |
| Périmètre | A3-108-scope | Pas de cloud, autosauvegarde sur disque ou certification anti-triche. |

### Enquêter sur un impact
`hearing108-impact` · Perception V108
Le bruit entre dans l’audition V106 avec la position réellement touchée. Le Runner peut conserver la trace de l’impact et rechercher un point atteignable du réseau proche. Il ne reçoit pas la position cachée actuelle de Ripley.

| Élément | Référence | Contrat |
|---|---|---|
| Intensité | A3-108-impact | Premier impact : puissance abstraite 0.82. Rebonds : 0.4264. Cadence minimale 0.12 s. |
| Contraintes | A3-108-attention | Une attaque déjà engagée ou une reconnaissance récente ne sont pas annulées par la diversion. |
| Distance | A3-108-trace | Un détour d’étage ou une porte peuvent rendre le bruit inaudible. |
| Rabattage | A3-108-dormant | Pendant la préparation antérieure à l’armement, le prédateur reste dormant. |

### Petit objet, repère local
`art108-bolt` · Rendu V108
Le boulon est dessiné par le module livré à sa position mondiale avec la même profondeur logique que lors du lancer. Le bref repère d’impact s’efface aussi au repos ; il ne pulse pas indéfiniment.

| Élément | Référence | Contrat |
|---|---|---|
| Pureté | A3-108-render | Dessiner ne fait avancer ni objet, ni perception, ni sauvegarde. |
| Réserve | input108-throw | Le petit panneau affiche seulement la commande utile et le nombre en poche. |
| Art | Silhouettes provisoires | Aucun nouveau sprite officiel ni pack photoréaliste annoncé. |

### Chaque conduite possède sa réserve indépendante
`A3-109-pressure` · Règles V109
Chaque conduite possède sa réserve indépendante. Pas de recharge pendant son souffle.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve | qa-v109/unit.json | Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète. |
| Parcours | encounter-traque | Les ouvertures au clavier sont séparées des comparaisons de porte dirigées. |

### La vanne demande un appui stable, le bon étage, la profondeur et un accès sans porte
`A3-109-distance` · Règles V109
La vanne demande un appui stable, le bon étage, la profondeur et un accès sans porte.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve | qa-v109/unit.json | Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète. |
| Parcours | encounter-traque | Les ouvertures au clavier sont séparées des comparaisons de porte dirigées. |

### Maintenir V pendant 1,40 seconde, ou utiliser le mode Appuyer existant
`A3-109-gesture` · Règles V109
Maintenir V pendant 1,40 seconde, ou utiliser le mode Appuyer existant.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve | qa-v109/unit.json | Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète. |
| Parcours | encounter-traque | Les ouvertures au clavier sont séparées des comparaisons de porte dirigées. |

### Mouvement, saut, dommage, relâchement et ouverture d’un panneau annulent le geste
`A3-109-abort` · Règles V109
Mouvement, saut, dommage, relâchement et ouverture d’un panneau annulent le geste.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve | qa-v109/unit.json | Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète. |
| Parcours | encounter-traque | Les ouvertures au clavier sont séparées des comparaisons de porte dirigées. |

### La vapeur chaude dure 4,8 secondes, suivie de 1,2 seconde de dissipation sans dommage
`A3-109-duration` · Règles V109
La vapeur chaude dure 4,8 secondes, suivie de 1,2 seconde de dissipation sans dommage.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve | qa-v109/unit.json | Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète. |
| Parcours | encounter-traque | Les ouvertures au clavier sont séparées des comparaisons de porte dirigées. |

### Un battant existant fermé tronque le jet ; les petits décors ne créent aucune collision
`A3-109-collision` · Règles V109
Un battant existant fermé tronque le jet ; les petits décors ne créent aucune collision.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve | qa-v109/unit.json | Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète. |
| Parcours | encounter-traque | Les ouvertures au clavier sont séparées des comparaisons de porte dirigées. |

### Le champ coupe la reconnaissance à distance ; il ne cache ni le contact proche ni la dernière trace
`A3-109-sight` · Règles V109
Le champ coupe la reconnaissance à distance ; il ne cache ni le contact proche ni la dernière trace.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve | qa-v109/unit.json | Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète. |
| Parcours | encounter-traque | Les ouvertures au clavier sont séparées des comparaisons de porte dirigées. |

### Le sifflement vient de la buse
`A3-109-sound` · Règles V109
Le sifflement vient de la buse. Les petits bruits proches sont atténués, pas effacés.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve | qa-v109/unit.json | Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète. |
| Parcours | encounter-traque | Les ouvertures au clavier sont séparées des comparaisons de porte dirigées. |

### Traverser le jet chaud peut brûler Ripley
`A3-109-danger` · Règles V109
Traverser le jet chaud peut brûler Ripley. Ni arme anti-Runner ni dommage ajouté aux détenus.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve | qa-v109/unit.json | Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète. |
| Parcours | encounter-traque | Les ouvertures au clavier sont séparées des comparaisons de porte dirigées. |

### Le plan et la pause arrêtent pression, jet, chaleur et bruit
`A3-109-pause` · Règles V109
Le plan et la pause arrêtent pression, jet, chaleur et bruit.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve | qa-v109/unit.json | Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète. |
| Parcours | encounter-traque | Les ouvertures au clavier sont séparées des comparaisons de porte dirigées. |

### Une reprise conserve le jet et la réserve, pas un geste maintenu ou un son en attente
`A3-109-save` · Règles V109
Une reprise conserve le jet et la réserve, pas un geste maintenu ou un son en attente.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve | qa-v109/unit.json | Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète. |
| Parcours | encounter-traque | Les ouvertures au clavier sont séparées des comparaisons de porte dirigées. |

### Aucun objectif natif, débit d’eau du piège, consommation de plomb ou graphe n’est remplacé
`A3-109-scope` · Règles V109
Aucun objectif natif, débit d’eau du piège, consommation de plomb ou graphe n’est remplacé.

| Élément | Référence | Contrat |
|---|---|---|
| Preuve | qa-v109/unit.json | Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète. |
| Parcours | encounter-traque | Les ouvertures au clavier sont séparées des comparaisons de porte dirigées. |

### Purge des galeries
`purge109-gallery-purge` · Conduites de purge
Poste rattaché à f161-service-low, dans l’ensemble service-pump. Une réserve de 100 unités abstraites alimente ce seul jet. Ouvrir coûte 70 unités et ne dépense ni eau du piège ni plomb.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-service-low | Pied Y 510, support node-platform-f161-service-low, profondeur 1. |
| Commande | input109-purge | Centre du volant (3012, 465), portée horizontale 53, tolérance verticale 22, profondeur ±0.4. |
| Buse | field109-gallery-purge | Origine (3128, 452) ; sens 1, portée maximale 156. |
| Réserve | steamstate109-refill | Recharge de 7 unités/s après fin de dissipation ; aucun cumul de jets. |

### Boîtier de vanne · Purge des galeries
`part109-gallery-purge-box` · Composants V109
X 2992, Y 435, 40 × 55 unités. Platine en retrait ; aucun obstacle nouveau.

| Élément | Référence | Contrat |
|---|---|---|
| Ensemble propriétaire | purge109-gallery-purge | Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques. |
| Silhouette | art109-render | L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra. |

### Volant et cadran · Purge des galeries
`part109-gallery-purge-wheel` · Composants V109
Volant de rayon 12 à (3012, 469), cadran de rayon 8 à Y 446. L’aiguille utilise la réserve réelle.

| Élément | Référence | Contrat |
|---|---|---|
| Ensemble propriétaire | purge109-gallery-purge | Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques. |
| Silhouette | art109-render | L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra. |

### Liaison et buse · Purge des galeries
`part109-gallery-purge-line` · Composants V109
Liaison depuis (3030, 446) via X 3113 vers (3128, 452).

| Élément | Référence | Contrat |
|---|---|---|
| Ensemble propriétaire | purge109-gallery-purge | Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques. |
| Silhouette | art109-render | L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra. |

### Jet · Purge des galeries
`field109-gallery-purge` · Volumes de vapeur
Champ de référence X 3128 à 3284, Y 424 à 510, profondeur 1. Le dessin, la reconnaissance et la chaleur consultent ce même volume.

| Élément | Référence | Contrat |
|---|---|---|
| Conduite | purge109-gallery-purge | Une porte fermée tronque ce champ à sa première face ; un battant à l’autre étage ne le tronque pas. |
| Reconnaissance | sense109-vision | Au-delà de 90 unités, le jet dense interrompt la vue à travers son volume. Le contact proche et la trace mémorisée restent possibles. |
| Chaleur | steamstate109-jet | Après 0.6 seconde d’exposition, 3 points toutes les 0.25 seconde tant que Ripley reste dedans. |

### Purge de ventilation
`purge109-ventilation-purge` · Conduites de purge
Poste rattaché à f161-service-high, dans l’ensemble service-shop. Une réserve de 100 unités abstraites alimente ce seul jet. Ouvrir coûte 70 unités et ne dépense ni eau du piège ni plomb.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-service-high | Pied Y 330, support node-platform-f161-service-high, profondeur 1. |
| Commande | input109-purge | Centre du volant (3120, 285), portée horizontale 53, tolérance verticale 22, profondeur ±0.4. |
| Buse | field109-ventilation-purge | Origine (3190, 272) ; sens 1, portée maximale 156. |
| Réserve | steamstate109-refill | Recharge de 7 unités/s après fin de dissipation ; aucun cumul de jets. |

### Boîtier de vanne · Purge de ventilation
`part109-ventilation-purge-box` · Composants V109
X 3100, Y 255, 40 × 55 unités. Platine en retrait ; aucun obstacle nouveau.

| Élément | Référence | Contrat |
|---|---|---|
| Ensemble propriétaire | purge109-ventilation-purge | Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques. |
| Silhouette | art109-render | L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra. |

### Volant et cadran · Purge de ventilation
`part109-ventilation-purge-wheel` · Composants V109
Volant de rayon 12 à (3120, 289), cadran de rayon 8 à Y 266. L’aiguille utilise la réserve réelle.

| Élément | Référence | Contrat |
|---|---|---|
| Ensemble propriétaire | purge109-ventilation-purge | Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques. |
| Silhouette | art109-render | L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra. |

### Liaison et buse · Purge de ventilation
`part109-ventilation-purge-line` · Composants V109
Liaison depuis (3138, 266) via X 3175 vers (3190, 272).

| Élément | Référence | Contrat |
|---|---|---|
| Ensemble propriétaire | purge109-ventilation-purge | Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques. |
| Silhouette | art109-render | L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra. |

### Jet · Purge de ventilation
`field109-ventilation-purge` · Volumes de vapeur
Champ de référence X 3190 à 3346, Y 244 à 330, profondeur 1. Le dessin, la reconnaissance et la chaleur consultent ce même volume.

| Élément | Référence | Contrat |
|---|---|---|
| Conduite | purge109-ventilation-purge | Une porte fermée tronque ce champ à sa première face ; un battant à l’autre étage ne le tronque pas. |
| Reconnaissance | sense109-vision | Au-delà de 90 unités, le jet dense interrompt la vue à travers son volume. Le contact proche et la trace mémorisée restent possibles. |
| Chaleur | steamstate109-jet | Après 0.6 seconde d’exposition, 3 points toutes les 0.25 seconde tant que Ripley reste dedans. |

### Purge de la fonderie
`purge109-foundry-purge` · Conduites de purge
Poste rattaché à f161-leadworks, dans l’ensemble leadworks. Une réserve de 100 unités abstraites alimente ce seul jet. Ouvrir coûte 70 unités et ne dépense ni eau du piège ni plomb.

| Élément | Référence | Contrat |
|---|---|---|
| Appui | f161-leadworks | Pied Y 510, support node-platform-f161-leadworks, profondeur 1. |
| Commande | input109-purge | Centre du volant (4124, 465), portée horizontale 53, tolérance verticale 22, profondeur ±0.4. |
| Buse | field109-foundry-purge | Origine (4270, 452) ; sens 1, portée maximale 156. |
| Réserve | steamstate109-refill | Recharge de 7 unités/s après fin de dissipation ; aucun cumul de jets. |

### Boîtier de vanne · Purge de la fonderie
`part109-foundry-purge-box` · Composants V109
X 4104, Y 435, 40 × 55 unités. Platine en retrait ; aucun obstacle nouveau.

| Élément | Référence | Contrat |
|---|---|---|
| Ensemble propriétaire | purge109-foundry-purge | Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques. |
| Silhouette | art109-render | L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra. |

### Volant et cadran · Purge de la fonderie
`part109-foundry-purge-wheel` · Composants V109
Volant de rayon 12 à (4124, 469), cadran de rayon 8 à Y 446. L’aiguille utilise la réserve réelle.

| Élément | Référence | Contrat |
|---|---|---|
| Ensemble propriétaire | purge109-foundry-purge | Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques. |
| Silhouette | art109-render | L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra. |

### Liaison et buse · Purge de la fonderie
`part109-foundry-purge-line` · Composants V109
Liaison depuis (4142, 446) via X 4255 vers (4270, 452).

| Élément | Référence | Contrat |
|---|---|---|
| Ensemble propriétaire | purge109-foundry-purge | Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques. |
| Silhouette | art109-render | L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra. |

### Jet · Purge de la fonderie
`field109-foundry-purge` · Volumes de vapeur
Champ de référence X 4270 à 4426, Y 424 à 510, profondeur 1. Le dessin, la reconnaissance et la chaleur consultent ce même volume.

| Élément | Référence | Contrat |
|---|---|---|
| Conduite | purge109-foundry-purge | Une porte fermée tronque ce champ à sa première face ; un battant à l’autre étage ne le tronque pas. |
| Reconnaissance | sense109-vision | Au-delà de 90 unités, le jet dense interrompt la vue à travers son volume. Le contact proche et la trace mémorisée restent possibles. |
| Chaleur | steamstate109-jet | Après 0.6 seconde d’exposition, 3 points toutes les 0.25 seconde tant que Ripley reste dedans. |

### Conduite disponible
`steamstate109-ready` · États des conduites
Le cadran présente une réserve suffisante. La conduite n’a aucun jet actif.

| Élément | Référence | Contrat |
|---|---|---|
| Contrat | A3-109-pressure | Au moins 70 unités ; contrôle à portée et présence continue pendant le geste. |
| Fichier | save109-current | État courant exporté explicitement ; aucun son ni geste partiel rejoué. |

### Ouvrir le volant
`steamstate109-opening` · États des conduites
Le geste dure 1,4 seconde. La pression n’est pas retirée avant la fin.

| Élément | Référence | Contrat |
|---|---|---|
| Contrat | A3-109-pressure | Le déplacement reste libre ; mouvement, saut, dégâts, relâchement ou panneau interrompent le geste. |
| Fichier | save109-current | État courant exporté explicitement ; aucun son ni geste partiel rejoué. |

### Souffle chaud
`steamstate109-jet` · États des conduites
Le jet chaud dure 4,8 secondes ; il est bruyant, obscurcissant et dangereux pour Ripley.

| Élément | Référence | Contrat |
|---|---|---|
| Contrat | A3-109-pressure | Il ne blesse pas le Runner et aucun dommage nouveau aux détenus n’est ajouté. La préparation du piège reste dormante. |
| Fichier | save109-current | État courant exporté explicitement ; aucun son ni geste partiel rejoué. |

### Dissipation
`steamstate109-tail` · États des conduites
Une traîne de 1,2 seconde suit le souffle ; sa densité visuelle diminue et elle n’inflige plus de chaleur.

| Élément | Référence | Contrat |
|---|---|---|
| Contrat | A3-109-pressure | La traîne ne recharge pas encore le circuit. Le masquage visuel cesse quand la densité passe sous le seuil. |
| Fichier | save109-current | État courant exporté explicitement ; aucun son ni geste partiel rejoué. |

### Remise en pression
`steamstate109-refill` · États des conduites
La réserve remonte seulement après disparition du jet. Elle ne dépasse pas 100 unités.

| Élément | Référence | Contrat |
|---|---|---|
| Contrat | A3-109-pressure | À partir de 30 unités, il faut environ 5,72 secondes après dissipation pour revenir à 70, dix secondes pour retrouver 100. |
| Fichier | save109-current | État courant exporté explicitement ; aucun son ni geste partiel rejoué. |

### Voir à travers la vapeur
`sense109-vision` · Perception V109
La perception V106 est prolongée avec le champ réel du jet. Le volume dense interrompt la reconnaissance à distance, mais ne supprime ni la dernière trace ni une attaque engagée.

| Élément | Référence | Contrat |
|---|---|---|
| Portée proche | A3-109-sight | À 90 unités ou moins, cette couche ne masque pas la vue. Les portes et contraintes historiques continuent à s’appliquer. |
| Étage | A3-109-collision | Les deux corps doivent se trouver au même étage que le jet et dans sa profondeur pour ce masquage. |
| Parité | qa-v109/unit.json | Sans vapeur, 180 frames de décisions V106/V109 sont comparées directement. |

### Entendre dans le souffle
`sense109-sound` · Perception V109
Le sifflement vient de la buse. Un petit bruit émis dans le jet, ou reçu par le Runner qui le traverse, garde son origine et son identifiant mais sa puissance est multipliée par 0,60.

| Élément | Référence | Contrat |
|---|---|---|
| Intensité | A3-109-sound | Bruit d’ouverture 1,0 ; impulsions de souffle 0,56, au plus une toutes les 0,95 s. Aucune rafale sonore à chaque frame. |
| Boulons | hearing108-impact | Les impacts des boulons restent suivis. Un bruit masqué n’est pas téléporté vers la conduite. |
| Limite | A3-109-danger | Le bruit propre de la purge n’est pas atténué par elle-même et peut attirer le Runner. Pas de silence magique. |

### Actionner une purge
`input109-purge` · Commandes V109
V ou le bouton Purge ouvre le poste accessible. Le mode Maintenir demande une pression continue ; le mode Appuyer partage la durée et permet une annulation par second appui.

| Élément | Référence | Contrat |
|---|---|---|
| Accès | A3-109-distance | Au sol, bon étage, profondeur intermédiaire vérifiée et aucune porte entre le corps et le volant. |
| Conflits | A3-109-abort | Une préparation de piège en cours refuse la purge. Pendant le geste, E, le lancer, le bruit volontaire et les ordres aux détenus sont refusés. Fuir reste autorisé. |
| Pause | A3-109-pause | Plan, archives et perte de focus annulent le geste. La vapeur déjà libérée attend la reprise. |

### Fichier de reprise V109
`save109-current` · Reprises V109
Le fichier V108 valide est enveloppé avec le registre des trois conduites. La pression, la durée restante et les comptes d’utilisation sont conservés. Le geste en cours est retiré, et les événements sonores ne sont pas rejoués.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | A3-109-save | Limite 1 Mio ; empreinte de corruption et invariants de domaine, pas signature anti-triche. |
| Pause | A3-109-pause | Import en pause. Marge de 0,9 seconde à la reprise avant un nouveau dégât de vapeur, pour ne pas exécuter un impact suspendu. |
| Base | save108-current | Les contrôles de position, d’inventaire, de participants et de progression antérieurs restent actifs. |

### Réserves du dernier poste sûr
`save109-checkpoint` · Reprises V109
Le poste sûr possède son propre registre, différent de la situation actuelle. Il ne peut être enregistré pendant un geste. Reprendre après un échec retrouve l’état vivant de ce poste.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | A3-109-save | Limite 1 Mio ; empreinte de corruption et invariants de domaine, pas signature anti-triche. |
| Pause | A3-109-pause | Import en pause. Marge de 0,9 seconde à la reprise avant un nouveau dégât de vapeur, pour ne pas exécuter un impact suspendu. |
| Base | save108-current | Les contrôles de position, d’inventaire, de participants et de progression antérieurs restent actifs. |

### Migration V105 à V108
`save109-migration` · Reprises V109
Les anciennes sauvegardes valides reçoivent trois circuits initialement pleins. Leur poste sûr est migré séparément de leur progression et inventaire actuels.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | A3-109-save | Limite 1 Mio ; empreinte de corruption et invariants de domaine, pas signature anti-triche. |
| Pause | A3-109-pause | Import en pause. Marge de 0,9 seconde à la reprise avant un nouveau dégât de vapeur, pour ne pas exécuter un impact suspendu. |
| Base | save108-current | Les contrôles de position, d’inventaire, de participants et de progression antérieurs restent actifs. |

### Refus d’un état incohérent
`save109-validation` · Reprises V109
Une réserve gratuite pendant un jet actif, une conduite inconnue, une durée infinie, un compte d’utilisation contradictoire ou un fichier trop volumineux sont refusés avant remplacement de la session.

| Élément | Référence | Contrat |
|---|---|---|
| Validation | A3-109-save | Limite 1 Mio ; empreinte de corruption et invariants de domaine, pas signature anti-triche. |
| Pause | A3-109-pause | Import en pause. Marge de 0,9 seconde à la reprise avant un nouveau dégât de vapeur, pour ne pas exécuter un impact suspendu. |
| Base | save108-current | Les contrôles de position, d’inventaire, de participants et de progression antérieurs restent actifs. |

### Vapeur localisée et raccordée
`art109-render` · Rendu V109
Trois postes utilisent les appuis du réseau existant. Le jet visible est découpé exactement sur le volume d’effet. La commande s’efface partiellement si elle recouvre Ripley.

| Élément | Référence | Contrat |
|---|---|---|
| Dessin | A3-109-scope | Les images du rapport viennent du canvas de ces modules ; aucune réillustration ni superposition de screenshot historique. |
| Lisibilité | A3-109-danger | Le repère de progression se trouve sur le volant. Un avertissement de brûlure utilise une phrase courte. |
| Mouvement réduit | A3-109-pause | Ambiances immobiles supprime la translation des bouffées, pas les durées de jeu ni la baisse de densité. |
