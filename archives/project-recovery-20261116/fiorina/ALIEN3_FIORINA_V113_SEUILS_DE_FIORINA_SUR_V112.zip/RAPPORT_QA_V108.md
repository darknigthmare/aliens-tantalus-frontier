# QA — Alien 3 V108

## Portée
Couche incrémentale sur V107. Banc à contrôleur simplifié et personnages provisoires, utilisant les modules livrés. Aucun moteur natif complet ni montage du film entier certifié.

## Résultats
- 59 cas unitaires V108.
- 19 scénarios d’installation, avec scripts npm synthétiques.
- 81 assertions Chromium en 9 groupes ; 61 libellés distincts.
- 10 contrôles du fichier ordinaire sans API QA.
- Régressions séparées : V107 56 cas et 19 installations ; V106 47 et 18 ; V105 65 et 17 ; V104 37 et 15. Ces essais ne qualifient pas la pile native complète.

## Parcours
| Profil automatisé | Résultat | Santé | Attaques / contacts / esquives | Lancers / sons entendus | Temps simulé |
|---|---|---:|---|---|---:|
| rapide | complete | 62 | 2 / 1 / 1 | 0 / 0 | 19.27 s |
| prudent | complete | 62 | 1 / 1 / 0 | 0 / 0 | 20.08 s |
| accessibilite | complete | 82 | 2 / 1 / 1 | 0 / 0 | 19.27 s |
| explorateur-reprise | complete | 82 | 2 / 1 / 1 | 0 / 0 | 19.27 s |
| rabattage-avec-esquive | complete | 100 | 1 / 0 / 1 | 0 / 0 | 26.07 s |
| diversion-reelle | complete | 100 | 0 / 0 / 0 | 1 / 1 | 30.08 s |

Le parcours avec diversion attend un retour réel du Runner au même étage avant le lancer. Un premier essai à l’étage supérieur était hors de portée acoustique ; ce refus n’a pas été transformé en écoute forcée. Les parcours sont au clavier avec horloge contrôlée, sans injection de position ou d’étape. Le robot connaît le chemin et lit l’état pour ses assertions ; ce n’est pas un essai humain.

## Contrôles nouveaux
- Lancer au point de départ réel, aucun son avant impact, trace auditive depuis le boulon.
- Rebond sur une vraie porte fermée ; récupération d’une identité au sol ; aucun quatrième objet.
- Plan et import en pause figent trajectoire et vitesse.
- Export réel en vol, import sur une nouvelle page, réception au sol et récupération.
- Fichier à position impossible refusé malgré recalcul de l’empreinte ; géométrie de porte reconstruite avant validation.
- Le repère d’impact s’efface au repos ; aucun pulse perpétuel après arrêt.
- Contrôle ordinaire requestAnimationFrame et clavier T sans objet d’inspection publié.

## Limites
La diversion n’ajoute aucun dégât ni stun. Le Runner n’écoute pas forcément un bruit hors de portée, durant une attaque ou lorsque sa trace visuelle garde la priorité. Il conserve sa navigation sur le graphe existant, pas un navmesh continu. Le calcul des boulons ne rend pas le décor entier physiquement interactif. Le prédateur reste dormant pendant la préparation antérieure à l’armement.
Son : activation, événements et coupure testés dans Chromium, aucune écoute sur matériel. Manette, Safari, tests humains, sprites définitifs, campagne native entière et performances cibles restent ouverts. Pas de nouvelle lecture GitHub ni erreur de droits revendiquée ce tour.

## Installation
Quatre nouveaux modules et un raccord du moteur. Aucun fichier V107 historique modifié. Les 38 sources connues sont comparées à leurs empreintes avant staging. Les tests npm des fixtures restent synthétiques, pas un build réel de Tantalus. Les sources modifiées, la concurrence et les chemins symboliques gérés sont refusés.