# QA — Alien 3 V110

## Résultats exécutés
- 65 cas unitaires V110 sur une base instrumentée.
- 19 scénarios d’installation à npm synthétique.
- 104 assertions Chromium dans 10 groupes ; 74 libellés distincts.
- 14 contrôles du fichier distribué sans API de test.
- 24 captures natives Chromium.

## Parcours au clavier
| Profil | État | Santé | Contacts | Purges | Fermetures | Attentes thermiques | Temps simulé |
|---|---|---:|---:|---:|---:|---:|---:|
| rapide | complete | 62 | 1 | 0 | 0 | 0 | 19.27 s |
| prudent | complete | 62 | 1 | 0 | 0 | 0 | 20.08 s |
| accessibilite | complete | 82 | 1 | 0 | 0 | 0 | 19.27 s |
| explorateur-reprise | complete | 82 | 1 | 0 | 0 | 0 | 19.27 s |
| rabattage-avec-esquive | complete | 100 | 0 | 0 | 0 | 0 | 26.07 s |
| rabattage-vanne-et-groupe | complete | 100 | 0 | 1 | 1 | 1 | 28.55 s |
| purge-refermee-en-traque | complete | 82 | 1 | 1 | 1 | 0 | 21.30 s |
Les robots connaissent les itinéraires. Les temps ne sont pas des durées de campagne humaine. Les parcours utilisent des gestionnaires clavier et une horloge contrôlée ; les arrivées, poses et étapes ne sont pas injectées. Les reprises utilisent de vrais fichiers téléchargés puis importés dans une nouvelle page.

## Corrections observées pendant cette passe
- Le script de parcours visait d’abord la commande de coulée au lieu du moule pour l’armement : le refus était correct. Le parcours de test a été corrigé pour rejoindre la vraie commande, sans modifier les objectifs.
- Une aide G restait affichée pendant une fermeture alors que cette action était refusée. La consigne indique maintenant que le déplacement interrompt la manœuvre.
- Une référence V109 subsistait dans un script navigateur copié. Tous les scripts V110 passent par un support commun et vérifient le schéma 110 du fichier réellement exécuté avant le parcours.

## Preuves ciblées
Fermeture au même poste et au même coût ; chaleur résiduelle ; pas de recharge avant fin du nuage ; arrêt préventif des détenus ; conservation d’un ordre G ; reprise depuis la pose réelle ; parité sans vapeur avec V109 ; fichier invalide refusé malgré empreinte recalculée ; contrôles de profondeur et d’étage ; bouton pointeur ; pureté du dessin.

## Régressions séparées
V109 : 60 cas et 19 installations. V108 : 59 cas et 19 installations. Les anciennes suites restent indépendantes de la qualification du moteur complet. Les parcours de traque et de rabattage hérités ont également été rejoués dans la composition V110.

## Limites
Le blocage est une attente prudente sur le trajet courant : pas de panique complète, pas de nouveau planificateur de détour, pas de blessure aux détenus. Un personnage déjà dans le volume peut en sortir si son pas réduit sa pénétration ; aucun téléport ni poussée ne sont appliqués.
Le Runner reste dormant pendant la préparation antérieure à l’armement du rabattage. La traque d’Aaron a aussi utilisé une fermeture alors que le prédateur restait actif.
Banc avec contrôleur simplifié et art vectoriel provisoire. Ni campagne native complète, sessions humaines, Safari, manettes matérielles ni écoute physique ne sont certifiés. Aucun nouveau build natif, push, déploiement ou refus de droits n’est prétendu ce tour.

## Installation
Quatre modules nouveaux et un raccord moteur sur 47 sources V109 exactes, aucune source historique modifiée. Staging, validation des mêmes octets, garde contre les changements concurrents et restauration externe. Les npm des fixtures ne sont pas le build natif.
