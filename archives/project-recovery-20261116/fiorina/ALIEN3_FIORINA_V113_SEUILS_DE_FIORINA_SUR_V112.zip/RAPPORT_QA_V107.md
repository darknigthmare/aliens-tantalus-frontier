# QA — Alien 3 V107

## Périmètre
Couche incrémentale sur V106. Banc à contrôleur simplifié utilisant les modules livrés. Aucune campagne native complète ni fidélité artistique 1:1 certifiée.

## Résultats
- 56 cas unitaires V107.
- 19 scénarios d’installation avec npm synthétique.
- 74 assertions Chromium sur sept groupes, 56 noms distincts.
- 8 contrôles du fichier ordinaire sans API QA.

## Régression historique
- V106 : 47 cas unitaires et 18 installations rejoués. V105 : 65 et 17. V104 : 37 et 15. Ces suites restent séparées du nouveau pilote et de la qualification native.

## Parcours
| Profil | Statut | Santé | Attaques / contacts / esquives | Temps simulé |
|---|---|---:|---|---:|
| rapide | complete | 62 | 2 / 1 / 1 | 19.27 s |
| prudent | complete | 62 | 1 / 1 / 0 | 20.08 s |
| accessibilite | complete | 82 | 2 / 1 / 1 | 19.27 s |
| explorateur-reprise | complete | 82 | 2 / 1 / 1 | 19.27 s |
| rabattage-avec-esquive | complete | 100 | 1 / 0 / 1 | 26.07 s |

Les traversées emploient le clavier et une horloge contrôlée, sans injection de position ou d’étape. Les frames de simulation peuvent avancer sans redessiner chacune ; les captures sont natives. Les robots connaissent le chemin ; leurs temps ne sont pas une durée de campagne.

## Corrections pendant la validation
- Les durées nouvelles changent l’ordre d’arrivée aux postes : le premier refus observé au moule concerne Dillon encore en trajet, pas Morse. Le contrôle a été adapté au contrat réel, sans déplacer un participant.
- Le contrôle du HTML ordinaire attend la position lue dans un fichier réellement exporté, plutôt qu’un nombre fixe de millisecondes dépendant de la charge du navigateur.
- Un premier affichage de progression recouvrait le dialogue. Le dessin actif utilise maintenant une vue en lecture seule, sans double panneau.
- Le repère d’action n’est plus centré sur la tête de Ripley ; il est sur le plateau ou le volant concerné.
- Un poste de vanne est ajouté à l’appui historique du collecteur qui n’avait pas de petit pupitre propre.
- Un délai sonore global persiste entre annulation et reprise pour empêcher les rafales de machine.
- Le dernier poste sûr V106 est migré séparément du stade courant.
- Les liens symboliques pendants sont refusés par l’installateur avant toute écriture.

## Portée des tests
Les positions des tests unitaires sont des fixtures dirigées. Les contrôles de poignées et d’états physiques ne valent pas qualification de tout le moteur principal. Les pas et ordres des détenus sont audibles, mais le Runner reste volontairement dormant pendant la préparation antérieure à l’armement du piège.
Les tests d’audio vérifient l’activation, les événements et la pause ; aucune écoute sur matériel physique n’est certifiée. Pas de nouvelle lecture GitHub ni nouvelle erreur de droits revendiquée. Pas de sauvegarde automatique sur disque, cloud, manette physique ou validation Safari.

## Installation
Quatre nouveaux modules, un raccord de moteur : aucune source V106 historique modifiée. Les 34 sources attendues sont vérifiées. Le travail est préparé dans une copie temporaire, puis les octets effectivement validés sont reportés vers la cible après contrôle des modifications concurrentes. Les fixtures emploient des commandes npm synthétiques ; aucun build complet du dépôt n’a été exécuté.

## Restant
Qualification dans la campagne native complète ; montage des anciens objectifs/effets avec le pilote ; sprites définitifs ; sessions humaines ; art final ; performances et son sur les appareils cibles.