# V106 — Traces dans la pénombre

- Lumière et reconnaissance progressive liées aux huit commandes existantes.
- Distance sonore depuis le corps réel du Runner, sol continu et graphe, atténuation des portes.
- Recherche sur les voisins atteignables d’une trace passée.
- Ordres G d’attente/reprise à proximité, sans téléportation ni faux poste occupé.
- Reprises par fichier V106 : registre d’attente/perception, poses de navigation contrôlées et dernier poste sûr indépendant.
- Refus atomique des fichiers incohérents ; migration d’un fichier V105 valide.
- Deux points de délégation dans le propriétaire V105, avec source originale et diff conservés.
- Codex enrichi et captures natives, sans nouveaux composants de décor artificiellement recomptés.

Périmètre : deux séquences originales sur hôte local simplifié ; campagne native complète, art final et déploiement non certifiés.
