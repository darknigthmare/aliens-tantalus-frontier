# QA — Alien 3 V109

## Résultats et portée
- 60 cas unitaires V109 sur base instrumentée.
- 19 scénarios d’installation à npm synthétique.
- 102 assertions Chromium dans 12 groupes ; 76 libellés distincts.
- 11 contrôles du fichier distribué sans API de test.
- 28 captures natives Chromium.
Les deux séquences restent des parcours originaux de validation. Aucun build natif complet ni fidélité 1:1 du film ne sont certifiés.

## Parcours au clavier
| Profil | État | Santé | Contacts | Purges | Brûlures | Durée simulée |
|---|---|---:|---:|---:|---:|---:|
| rapide | complete | 62 | 1 | 0 | 0 | 19.27 s |
| prudent | complete | 62 | 1 | 0 | 0 | 20.08 s |
| accessibilite | complete | 82 | 1 | 0 | 0 | 19.27 s |
| explorateur-reprise | complete | 82 | 1 | 0 | 0 | 19.27 s |
| rabattage-avec-esquive | complete | 100 | 0 | 0 | 0 | 26.07 s |
| purge-en-traque | complete | 97 | 0 | 1 | 3 | 23.08 s |
| purge-ventilation | complete | 64 | 2 | 1 | 0 | 20.93 s |
| diversion-reelle | complete | 100 | 0 | 0 | 0 | 30.08 s |

Les parcours emploient les gestionnaires clavier et une horloge contrôlée ; aucune position, arrivée de détenu ou étape n’est injectée pendant les traversées. Les robots connaissent les itinéraires. Les valeurs de temps ne sont pas des durées de campagne humaine.

## Corrections pendant les contrôles
- Un bruit au niveau du pied était exactement sur la frontière du volume ; son test de masquage utilise maintenant une petite hauteur de référence tout en conservant le pied et l’origine de l’événement.
- Une référence de fichier V108 subsistait dans un script navigateur copié. Le script vérifie maintenant le schéma 109 du fichier exécuté avant le début du parcours ; toutes les preuves finales proviennent de la nouvelle page.
- Les formes de vapeur ont un bord radial adouci et la commande est moins opaque quand elle recouvre Ripley.
- L’essai de recharge attend la fin du souffle puis les dix secondes nécessaires pour passer de 30 à 100, sans demander une recharge artificiellement instantanée.

## Preuves ciblées
- Sans jet, parité des décisions V106/V109 vérifiée sur 180 frames.
- Champ de vapeur commun au rendu, à la vue et à la chaleur ; portes fermées et étages distincts testés.
- Reprise par fichier téléchargé puis importé sur une nouvelle page : jet, pression et pause conservés.
- Geste incomplet non repris ; fichier incohérent refusé malgré empreinte recalculée.
- Appuyer et bouton pointeur utilisent la même durée et le même coût.

## Régressions séparées
V108 : 59 cas unitaires et 19 installations ; V107 : 56 et 19. Les suites historiques restent indépendantes de la qualification du moteur complet. Une route V108 de diversion par boulon a aussi été rejouée dans la composition V109.

## Limites
Les trois réserves sont abstraites et indépendantes ; ce n’est pas une simulation de réseau de pression complet. Les jets n’endommagent pas le Runner ni les détenus, et ne déclenchent ni plomb ni refroidissement. Les anciennes sources restent les propriétaires des objectifs. Le prédateur reste dormant pendant la préparation avant armement.
Banc avec physique de base et acteurs vectoriels provisoires. Pas de campagne native entière, session humaine, manette physique, Safari, écoute matérielle ou tests de performance cibles. Pas de nouvelle lecture GitHub ou refus de droit prétendu ce tour.

## Installation
Cinq nouveaux modules et un raccord du moteur sur les 42 sources V108 exactes. Aucun module antérieur modifié. Travail préparé dans une copie, contrôles npm du projet puis report des octets validés et contrôle de concurrence. Les commandes des fixtures sont synthétiques, pas un build de Tantalus.