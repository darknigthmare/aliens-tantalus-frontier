# Rapport QA — V103 Passages et réseaux

## Résultats exécutés

| Ensemble | Résultat | Périmètre |
|---|---:|---|
| Contrats V103 | 45 cas passés | Données, portée, commandes, sauvegarde, carte, méthode réelle V97 |
| Installation | 16 scénarios passés | Fixtures synthétiques ; aucune certification du build du jeu |
| Chromium | 37 contrôles passés | Banc V101/V102/V103, contrôleur simplifié, captures natives |
| Codex HTML | 8 contrôles passés | Recherche, filtres, liens, mise en page |
| Héritage | 57/57 scripts passés | Suites isolées V88 à V102 sur leurs bases de test |

Ces périmètres ne sont pas additionnés en une certification générale de la campagne.

## Corrections et ajouts

- La méthode de locomotion V97 consommait Haut/Bas en profondeur avant la gestion des échelles. Le correctif V103 transmet ces commandes lorsque l’échelle est à portée et restaure le mode même sur exception.
- Le banc utilisait `depth || 1`, ce qui traitait à tort le plan zéro comme le plan médian. Il utilise désormais une valeur par défaut nulle uniquement.
- Les libellés du plan se chevauchaient dans une première passe. Un placement déterministe à plusieurs rangées et des traits de rappel ont été ajoutés. Les vingt libellés sont testés sans chevauchement.
- Les fonds conservent une couverture opaque depuis y=0 et un fondu de palette sur 192 unités. Le thème lointain ne dépend pas de la hauteur du saut.
- Les trois portes reprennent leur géométrie native lorsqu’elle est disponible. Le rendu de feuille suit l’ouverture ; il n’ajoute pas de nouvelle collision ou serrure.
- Les vingt-deux circuits possèdent des points de source et de réception explicites : 66 segments locaux.
- Huit interrupteurs changent leurs luminaires et halos. Le changement de pixels est mesuré dans Chromium après une vraie commande I. Ils n’altèrent aucune condition de mission ni comportement du Runner.
- Le plan et les archives bloquent l’update et les actions d’équipement. Fermer le plan ne supprime pas une pause antérieure.
- La sauvegarde V103 conserve les visites et les états de lampes, pas la géométrie ni l’ouverture du plan.
- Une modification concurrente détectée entre la préparation et l’écriture annule l’installation au lieu d’écraser les données locales.

## Chiffres du registre

20 sections de description ; 30 assemblages hérités ; 284 composants ; 22 circuits ; 8 commandes ; 3 portes natives ; 72 points ; 119 connexions ; quatre routes héritées. Les vingt sections ne sont pas vingt nouvelles pièces instanciées.

Le codex de conception comprend 304 fiches : 20 sections, 30 assemblages, 22 réseaux, 8 commandes, 3 portes, 72 points, 119 connexions et 30 règles. Les quatre routes et les 90 archives du joueur ne sont pas augmentées pour cette version.

## Captures et preuves

`qa-v103/browser.json` décrit 16 captures natives, leurs états préparés et leurs empreintes. La capture 16 est un état d’exploration avancé obtenu par positionnements de test, pas par un parcours de campagne. Le screenshot 17 du codex est issu de son navigateur séparé. Les fichiers `unit.json`, `installation.json`, `codex-browser.json` et `regressions.json` donnent les assertions et leurs périmètres.

## Limites

Le moteur complet, ses sprites définitifs et le déroulement intégral des V88 à V103 n’ont pas été exécutés. Les tests de franchissement des portes dans le navigateur concernent le contrôleur simplifié du banc. La méthode réelle de gestion des touches V97 est, elle, exécutée dans un test isolé au-dessus d’une base de locomotion instrumentée.

Les rapports d’installation ne prouvent pas un build réel : leurs commandes npm sont des fixtures. Aucun push GitHub ni déploiement n’est annoncé. La superposition avec tous les anciens interactifs, l’art final et la fidélité scène par scène restent à examiner dans la production complète.
