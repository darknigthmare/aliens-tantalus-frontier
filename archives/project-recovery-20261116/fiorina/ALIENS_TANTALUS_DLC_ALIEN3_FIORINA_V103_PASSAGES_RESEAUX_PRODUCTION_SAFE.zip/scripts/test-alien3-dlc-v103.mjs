import assert from 'node:assert/strict';
import * as d from '../src/alien3-dlc-v103.js';
import {layoutAlien3MapLabelsV103} from '../src/alien3-art-v103.js';
import {withAlien3DlcRuntimeV103} from '../src/alien3-dlc-runtime-v103.js';
import {withAlien3DlcRuntimeV97} from '../src/alien3-dlc-runtime-v97.js';
import {createAlien3StateV97} from '../src/alien3-dlc-v97.js';
const results=[],test=(name,fn)=>{fn();results.push({name,ok:true});},clone=structuredClone;
const scene=d.compileAlien3CirculationV103(),u=scene.utilities[0],actor={x:u.x-15,y:u.footY-90,w:32,h:90,alive:true,depth:1};
test('72 nodes and 119 connections inherited unchanged',()=>{assert.deepEqual(scene.nodes,d.ALIEN3_FIORINA_TEMPLATE_V103.nodes);assert.deepEqual(scene.edges,d.ALIEN3_FIORINA_TEMPLATE_V103.edges);});
test('Twenty named sections, three native gates, eight utility panels',()=>{const a=d.auditAlien3CirculationV103(scene);assert.equal(a.ok,true,JSON.stringify(a.errors));assert.equal(a.spaces,20);assert.equal(a.gates,3);assert.equal(a.utilities,8);});
test('Circuits have real shared-assembly endpoints',()=>{assert.equal(scene.circuits.length,22);assert.equal(d.auditAlien3CirculationV103(scene).segments,66);});
test('Circuit with a foreign endpoint is rejected',()=>{const s=clone(scene);s.circuits[0].targetId='missing';assert.equal(d.auditAlien3CirculationV103(s).ok,false);});
test('Duplicate section rejected',()=>{const s=clone(scene);s.spaces[1].id=s.spaces[0].id;assert.equal(d.auditAlien3CirculationV103(s).ok,false);});
test('Utility without physical support rejected',()=>{const s=clone(scene);s.utilities[0].x=-999;assert.equal(d.auditAlien3CirculationV103(s).ok,false);});
test('Native compiled door pose and dimensions retained',()=>{const p={graph:{nodes:scene.nodes,edges:scene.edges},geometry:{doors:[{id:scene.gates[0].id,x:1533,y:345,w:63,h:165}]}};const out=d.compileAlien3CirculationV103(p).gates[0];assert.equal(out.x,1533);assert.equal(out.w,63);assert.equal(out.geometrySource,'compiled');});
test('Template is never mutated by compiling a plan',()=>{const before=JSON.stringify(d.ALIEN3_FIORINA_TEMPLATE_V103);d.compileAlien3CirculationV103();assert.equal(JSON.stringify(d.ALIEN3_FIORINA_TEMPLATE_V103),before);});
test('Same-floor panel can be reached',()=>assert.equal(d.reachableUtilityV103(u,actor),true));
for(const [label,patch,ctx] of [['another floor',{y:actor.y-160},{}],['behind plane',{}, {lane:0}],['front plane',{}, {lane:2}],['far away',{x:actor.x+250},{}],['dead',{alive:false},{}],['downed',{downed:true},{}],['climbing',{climbing:true},{}],['paused',{}, {paused:true}],['map open',{}, {modal:true}],['not running',{}, {running:false}],['mission ended',{}, {missionActive:false}]])test(`Panel refused when ${label}`,()=>assert.equal(d.reachableUtilityV103(u,{...actor,...patch},ctx),false));
test('Closed door prevents interaction through it',()=>{const p={...actor,x:u.x-70};assert.equal(d.reachableUtilityV103(u,p,{doors:[{x:u.x-25,y:400,w:15,h:110,open:false,progress:0}]}),false);});
test('Open door permits reachable interaction',()=>{const p={...actor,x:u.x-70};assert.equal(d.reachableUtilityV103(u,p,{doors:[{x:u.x-25,y:400,w:15,h:110,open:true,progress:1}]}),true);});
test('Opening door still blocks until sufficiently clear',()=>{const p={...actor,x:u.x-70};assert.equal(d.reachableUtilityV103(u,p,{doors:[{x:u.x-25,y:400,w:15,h:110,open:true,progress:.2}]}),false);});
test('Node discovery is local in horizontal and vertical axes',()=>{const s=d.createAlien3StateV103();d.discoverAlien3NodesV103(scene,s,{x:3060,y:420,w:20,h:90,alive:true});assert.ok(s.visitedNodes.includes('f161-service-low'));assert.ok(!s.visitedNodes.includes('f161-service-high'));assert.ok(!s.visitedNodes.includes('f161-service-deep'));});
test('Map excludes all unknown nodes and any enemy coordinate',()=>{const s=d.createAlien3StateV103();s.visitedNodes=[scene.nodes[0].id];const map=d.buildAlien3MapV103(scene,s,actor);assert.equal(map.nodes.length,1);assert.equal(map.edges.length,0);assert.equal('enemies' in map,false);});
test('Discovery is idempotent',()=>{const s=d.createAlien3StateV103();d.discoverAlien3NodesV103(scene,s,actor);const raw=clone(s);d.discoverAlien3NodesV103(scene,s,actor);assert.deepEqual(s,raw);});
test('Save sanitizer rejects unknown IDs and coerced booleans',()=>{const s=d.sanitizeAlien3StateV103({schema:103,visitedNodes:['missing',scene.nodes[0].id,scene.nodes[0].id],lights:{[u.id]:'false'}});assert.equal(s.visitedNodes.length,1);assert.equal(s.lights[u.id],true);assert.deepEqual(d.sanitizeAlien3StateV103({schema:0}),d.createAlien3StateV103());});
test('Space resolution distinguishes floors at the same horizontal location',()=>{assert.notEqual(d.resolveAlien3SpaceV103(scene,{x:3050,y:420,w:30,h:90}).id,d.resolveAlien3SpaceV103(scene,{x:3050,y:240,w:30,h:90}).id);});
class Base{
 constructor(){this.running=true;this.paused=false;this.player={...actor};this.keys=new Set();this.mission={state:'active'};this.missionLevelRuntime={graph:{nodes:scene.nodes,edges:scene.edges}};this.camera={x:0,y:0};this.events=[];this.onEvent=e=>this.events.push(e);this.alien3V88={phase:'wreckage',leadPoured:false};this.alien3V98={codexUi:{open:false}};this.updateCount=0;}
 start(){return {};}stop(){this.running=false;}update(){this.updateCount++;}fire(){return true;}interact(){return true;}reload(){return true;}useEquipment(){return true;}useMedkit(){return true;}
 getInteractionPrompt(){return this.nativePrompt||'';}clearGameplayInput(){this.keys.clear();}captureResumeState(){return {specialOperation:{previous:'kept'}};}applyResumeState(raw){return {applied:!raw.fail};}getSnapshot(){return {};}
 drawWorld(){if(this.explode)throw Error('drawing');}drawHud(){}drawPlatform(){}drawDoor(){}
}
const E=withAlien3DlcRuntimeV103(Base);const e=new E();e.start({campaign:{id:d.ALIEN3_CAMPAIGN_ID_V103}});
test('Light switch changes only local lighting and emits a saveable event',()=>{const old=clone(e.alien3V88);assert.equal(e.useAlien3UtilityV103(),true);assert.equal(e.alien3V103.lights[u.id],false);assert.deepEqual(e.alien3V88,old);assert.equal(e.events.at(-1).type,'objective-action');});
test('Switch spam is rate-limited',()=>assert.equal(e.useAlien3UtilityV103(),false));
test('Main objective interaction keeps its prompt',()=>{e.nativePrompt='E  Examiner le module';assert.equal(e.getInteractionPrompt(),e.nativePrompt);e.nativePrompt='';});
test('Map freezes full ancestor update and every item action',()=>{e.openAlien3MapV103();const before=e.updateCount;e.update(.1);assert.equal(e.updateCount,before);for(const fn of ['fire','interact','reload','useEquipment','useMedkit'])assert.equal(e[fn](),false);});
test('Map closing does not erase a prior pause',()=>{e.paused=true;e.closeAlien3MapV103();assert.equal(e.paused,true);e.paused=false;});
test('Opening map clears held movement',()=>{e.keys.add('ArrowRight');e.openAlien3MapV103();assert.equal(e.keys.size,0);e.closeAlien3MapV103();});
test('Map is unavailable behind archive UI',()=>{e.alien3V98.codexUi.open=true;assert.equal(e.openAlien3MapV103(),false);e.alien3V98.codexUi.open=false;});
test('Map is unavailable after mission completion',()=>{e.mission.state='complete';assert.equal(e.openAlien3MapV103(),false);e.mission.state='active';});
test('Save restores lights and visits, preserves ancestors, never persists modal/geometry',()=>{e.update(.1);const raw=e.captureResumeState(),b=new E();b.start({campaign:{id:d.ALIEN3_CAMPAIGN_ID_V103}});b.applyResumeState(raw);assert.deepEqual(b.alien3V103,e.alien3V103);assert.equal(raw.specialOperation.previous,'kept');assert.equal(raw.specialOperation.alien3V103.mapOpen,undefined);assert.equal(raw.specialOperation.alien3V103.geometry,undefined);assert.equal(b.alien3MapOpenV103,false);});
test('Rejected ancestor restore leaves V103 state unchanged',()=>{const before=clone(e.alien3V103);e.applyResumeState({fail:true});assert.deepEqual(e.alien3V103,before);});
test('Other campaigns keep normal actions',()=>{const b=new E();b.start({campaign:{id:'other'}});assert.equal(b.isAlien3MissionV103(),false);assert.equal(b.fire(),true);assert.equal(b.interact(),true);});
// Directly execute V97's real key-consuming method, not a rewritten stand-in.
class Physical extends Base{updatePlayer(a,dt,controls){if(this.throwMovement)throw Error('movement');this.verticalKeySeen=this.keys.has(controls.up)||this.keys.has('ArrowUp');if(this.verticalKeySeen)a.y-=12;}}
const L=withAlien3DlcRuntimeV103(Physical),l=new L();l.start({campaign:{id:d.ALIEN3_CAMPAIGN_ID_V103}});l.alien3V97=createAlien3StateV97();l.alien3V97.hybrid.mode='depth';l.player={x:100,y:420,w:40,h:90,alive:true};l.ladders=[{x:120,top:330,bottom:510,w:42}];l.keys.add('KeyW');
const LegacyClass=withAlien3DlcRuntimeV97(Physical);const legacyUpdate=LegacyClass.prototype.updatePlayer;
// Insert the genuine V97 method under V103 without invoking unrelated campaign setup.
class WithRealV97 extends Physical{isAlien3MissionV97(){return true;}shiftAlien3DepthLaneV97(){this.shifted=true;}updatePlayer(...args){return legacyUpdate.call(this,...args);}}
const TrueStack=withAlien3DlcRuntimeV103(WithRealV97);const st=new TrueStack();st.start({campaign:{id:d.ALIEN3_CAMPAIGN_ID_V103}});st.alien3V97=createAlien3StateV97();st.alien3V97.hybrid.mode='depth';st.player={...l.player};st.ladders=l.ladders;st.keys.add('KeyW');
test('Real V97 no longer swallows ladder input in depth rooms',()=>{st.updatePlayer(st.player,.016,{up:'KeyW',down:'KeyS'});assert.equal(st.verticalKeySeen,true);assert.equal(st.shifted,undefined);assert.equal(st.alien3V97.hybrid.mode,'depth');assert.ok(st.keys.has('KeyW'));});
test('Away from ladder, real V97 still changes depth',()=>{st.player.x=400;st.updatePlayer(st.player,.016,{up:'KeyW',down:'KeyS'});assert.equal(st.shifted,true);assert.equal(st.verticalKeySeen,false);});
test('Exceptional physical update restores the hybrid mode',()=>{st.player.x=100;st.throwMovement=true;assert.throws(()=>st.updatePlayer(st.player,.016,{up:'KeyW',down:'KeyS'}),/movement/);assert.equal(st.alien3V97.hybrid.mode,'depth');});
test('No climb command at the top when going up',()=>assert.equal(d.relevantLadderV103(l.ladders,{...l.player,y:240},-1),null));
test('Full-map label boxes do not overlap',()=>{const st=d.createAlien3StateV103();st.visitedNodes=scene.nodes.map(n=>n.id);const map=d.buildAlien3MapV103(scene,st,actor),labels=layoutAlien3MapLabelsV103(map,scene);assert.equal(labels.length,20);for(let i=0;i<labels.length;i++)for(let j=i+1;j<labels.length;j++){const a=labels[i],b=labels[j];assert.ok(!(a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y));}});
test('Empty map has no labels for unknown sections',()=>{const map=d.buildAlien3MapV103(scene,d.createAlien3StateV103(),actor);assert.equal(layoutAlien3MapLabelsV103(map,scene).length,0);});
console.log(JSON.stringify({ok:true,scope:'V103 pure contracts, mixin and genuine V97 input method; not full production campaign',cases:results.length,results,audit:d.auditAlien3CirculationV103(scene)},null,2));
