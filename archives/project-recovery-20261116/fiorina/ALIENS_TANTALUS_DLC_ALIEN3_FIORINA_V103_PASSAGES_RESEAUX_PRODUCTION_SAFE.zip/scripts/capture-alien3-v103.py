#!/usr/bin/env python3
"""Native Chromium captures of actual V101/102/103 render modules in the local
movement bench. This is NOT the complete game's campaign or definitive art."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil,subprocess,sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'qa-v103';SHOTS=OUT/'captures';SHOTS.mkdir(parents=True,exist_ok=True)
subprocess.run([sys.executable,str(ROOT/'scripts/build-alien3-preview-v103.py')],check=True)
html=(ROOT/'atelier-v103/FIORINA_V103_APERCU_LOCAL.html').read_text();checks=[];shots=[];errors=[]
def record(name,value,detail=None):
 if not value:raise AssertionError(name+': '+str(detail))
 checks.append({'name':name,'ok':True,**({'details':detail} if detail is not None else {})})
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 version=b.version;page=b.new_page(viewport={'width':1280,'height':720},device_scale_factor=1)
 page.on('pageerror',lambda e:errors.append(str(e)));reqs=[];page.on('request',lambda r:reqs.append(r.url))
 page.set_content('<script>window.__BENCH_QUERY__="capture=1&freeze=1&room=0"</script>'+html,wait_until='load');page.wait_for_function('!!window.fiorinaBench')
 def ev(s):return page.evaluate(s)
 def shot(name,caption):
  file=SHOTS/(name+'.png');page.locator('canvas').screenshot(path=str(file));state=ev('({player:fiorinaBench.engine.player,camera:fiorinaBench.engine.camera,lights:fiorinaBench.engine.alien3V103.lights,known:fiorinaBench.engine.alien3V103.visitedNodes,mapOpen:fiorinaBench.engine.alien3MapOpenV103,drawn:fiorinaBench.engine.alien3RenderStatsV103})');shots.append({'file':'qa-v103/captures/'+file.name,'caption':caption,'state':state})
 record('Actual V103 renderer and runtime loaded',ev('fiorinaBench.engine.isAlien3MissionV103()'))
 for i,(name,label) in enumerate([('01_cote','Côte et prise d’air'),('02_medical','Infirmerie et morgue'),('03_detention','Coursives et cellules'),('04_service','Galeries et ateliers'),('05_supervision','Réserve et supervision'),('06_fonderie','Creuset et alimentation'),('07_moule','Pistons et moule'),('08_four','Approche du four'),('09_arrivee','Équipement conditionnel de la Compagnie')]):
  page.evaluate('(i)=>{fiorinaBench.setLocation(i);fiorinaBench.tick(0);fiorinaBench.render();}',i);shot(name,label)
  record('Sector '+str(i+1)+' renders with a nonempty scenery pass',ev('fiorinaBench.engine.alien3RenderStatsV103.props>0'))
 # Put the player at a real, reachable utility; not directly edit the saved switch state.
 ev("()=>{const b=fiorinaBench,e=b.engine,u=b.circulation.utilities.find(u=>u.id==='care-light');b.setLocation(1);Object.assign(e.player,{x:u.x-23,y:u.footY-90,grounded:true,depth:1});e.camera.x=Math.max(0,e.player.x-465);e.paused=false;e.alien3UtilityCooldownV103=0;b.render();}")
 page.locator('canvas').focus();shot('10_lumiere_allumee','Lampe de soin allumée avant manipulation')
 ev("()=>{const c=document.querySelector('canvas').getContext('2d');window.beforeLightPixels=Array.from(c.getImageData(0,65,1280,560).data);}")
 page.keyboard.press('KeyI');ev('fiorinaBench.render()')
 record('I switches reachable care lamp off',not ev("fiorinaBench.engine.alien3V103.lights['care-light']"))
 pixel_diff=ev("()=>{const a=beforeLightPixels,b=document.querySelector('canvas').getContext('2d').getImageData(0,65,1280,560).data;let n=0;for(let i=0;i<a.length;i+=4)if(Math.abs(a[i]-b[i])+Math.abs(a[i+1]-b[i+1])+Math.abs(a[i+2]-b[i+2])>6)n++;return n;}")
 record('Lamp and local light visibly change on canvas',pixel_diff>100,{'changedPixels':pixel_diff});shot('11_lumiere_eteinte','La même lampe éteinte ; les autres appareils restent présents')
 ev('()=>{fiorinaBench.engine.player.y-=160;fiorinaBench.tick(.24)}');page.keyboard.press('KeyI')
 record('A switch cannot be operated from another floor',not ev("fiorinaBench.engine.alien3V103.lights['care-light']"))
 ev('()=>{fiorinaBench.engine.player.y+=160;fiorinaBench.engine.player.depth=0;fiorinaBench.tick(0)}');page.keyboard.press('KeyI')
 record('A switch cannot be operated from a different depth',not ev("fiorinaBench.engine.alien3V103.lights['care-light']"))
 ev('()=>{fiorinaBench.engine.player.depth=1;fiorinaBench.tick(.24)}');page.keyboard.press('KeyI')
 record('Returning to the reachable position allows relighting',ev("fiorinaBench.engine.alien3V103.lights['care-light']"))
 # Map only displays player-discovered nodes (no debug unlock).
 ev("()=>{const b=fiorinaBench,e=b.engine;for(const id of ['f161-spawn','f161-eev','f161-infirmary','f161-cell-a','f161-cell-b','f161-service-low','f161-bishop']){const n=b.circulation.nodes.find(n=>n.id===id);Object.assign(e.player,{x:n.x-16,y:n.y-90,grounded:true});b.tick(0);}b.setLocation(2);b.tick(0);}")
 page.keyboard.press('KeyM');ev('fiorinaBench.render()');record('M opens the runtime map',ev('fiorinaBench.engine.alien3MapOpenV103'));shot('12_plan','Plan limité aux passages effectivement relevés')
 frozen=ev('JSON.stringify(fiorinaBench.engine.captureResumeState())');old_x=ev('fiorinaBench.engine.player.x');old_time=ev('fiorinaBench.engine.animationTime')
 page.keyboard.down('ArrowRight');ev('fiorinaBench.tick(.2)');page.keyboard.up('ArrowRight')
 record('Map freezes movement and time',ev('fiorinaBench.engine.player.x')==old_x and ev('fiorinaBench.engine.animationTime')==old_time)
 record('Map blocks direct firing and interaction calls',ev('fiorinaBench.engine.fire()===false&&fiorinaBench.engine.interact()===false'))
 page.keyboard.press('KeyC');record('Map prevents simultaneous archive input',not ev('fiorinaBench.engine.alien3V98.codexUi.open'))
 record('Rendering map does not alter persistent data',frozen==ev('JSON.stringify(fiorinaBench.engine.captureResumeState())'))
 page.keyboard.press('Escape');record('Escape closes map without pausing a running game',not ev('fiorinaBench.engine.alien3MapOpenV103') and not ev('fiorinaBench.engine.paused'))
 ev('fiorinaBench.engine.paused=true');page.keyboard.press('KeyM');page.keyboard.press('Escape');record('Map closure retains an existing pause',ev('fiorinaBench.engine.paused'));ev('fiorinaBench.engine.paused=false')
 # Advanced exploration is a reproducible position fixture, not a full playthrough.
 ev("()=>{const b=fiorinaBench,e=b.engine;for(const n of b.circulation.nodes){Object.assign(e.player,{x:n.x-16,y:n.y-90,grounded:true});b.tick(0);}b.setLocation(5);e.openAlien3MapV103();b.render();}")
 layout=ev('fiorinaBench.engine.alien3MapLayoutV103.labels')
 overlap=any(a['x']<bb['x']+bb['w'] and a['x']+a['w']>bb['x'] and a['y']<bb['y']+bb['h'] and a['y']+a['h']>bb['y'] for i,a in enumerate(layout) for bb in layout[i+1:])
 record('All 20 discovered section labels fit without overlap',len(layout)==20 and not overlap,{'labels':len(layout)})
 shot('16_plan_etages','Plan après relevé de tous les points par positionnements de test ; pas un parcours complet')
 page.keyboard.press('Escape')
 # Use normal keyboard movement against real gates in the simplified bench physics.
 ev("()=>{const b=fiorinaBench,e=b.engine,d=e.doors[0];d.open=false;d.progress=0;Object.assign(e.player,{x:d.x-e.player.w-18,y:d.y+d.h-e.player.h,grounded:true,depth:1,vy:0});e.camera.x=e.player.x-465;b.render();}")
 shot('13_porte_fermee','Porte fermée, pilotée par son état physique local')
 page.keyboard.down('ArrowRight');ev('()=>{for(let i=0;i<35;i++)fiorinaBench.tick(1/60)}');page.keyboard.up('ArrowRight')
 record('Closed gate blocks the bench player',ev('fiorinaBench.engine.player.x+fiorinaBench.engine.player.w<=fiorinaBench.engine.doors[0].x+.1'))
 page.keyboard.press('KeyE');record('Native bench E action opens the same gate',ev('fiorinaBench.engine.doors[0].open'));ev('fiorinaBench.render()');shot('14_porte_ouverte','Même porte ouverte, passage libéré sans changer ses coordonnées')
 page.keyboard.down('ArrowRight');ev('()=>{for(let i=0;i<35;i++)fiorinaBench.tick(1/60)}');page.keyboard.up('ArrowRight');record('Open gate allows crossing',ev('fiorinaBench.engine.player.x>fiorinaBench.engine.doors[0].x'))
 after=ev('fiorinaBench.engine.player.x');page.keyboard.down('ArrowLeft');ev('()=>{for(let i=0;i<12;i++)fiorinaBench.tick(1/60)}');page.keyboard.up('ArrowLeft');record('Left key still moves left',ev('fiorinaBench.engine.player.x')<after)
 ev('()=>{fiorinaBench.setLocation(5);fiorinaBench.tick(1/60)}');before=ev('({y:fiorinaBench.engine.player.y,scene:JSON.stringify(fiorinaBench.engine.alien3SceneV103)})')
 page.keyboard.down('Space');ev('fiorinaBench.tick(1/60)');page.keyboard.up('Space');ev('()=>{for(let i=0;i<8;i++)fiorinaBench.tick(1/60)}')
 record('Jump moves the actor but never the scenery or circuits',ev('fiorinaBench.engine.player.y')<before['y'] and ev('JSON.stringify(fiorinaBench.engine.alien3SceneV103)')==before['scene'])
 ev('()=>{const e=fiorinaBench.engine;e.alien3V98.codexUi.open=true;e.alien3V99.codexGraph.query="Runner";const list=e.alien3CodexVisibleEntriesV99();e.alien3V99.codexGraph.currentId=list[0].id;fiorinaBench.render();}');shot('15_archives','Archives existantes, recherche sur les textes reformulés')
 before=ev('JSON.stringify(fiorinaBench.engine.captureResumeState())');ev('()=>{for(let i=0;i<6;i++)fiorinaBench.render()}');record('Archives rendering never marks or unlocks entries',before==ev('JSON.stringify(fiorinaBench.engine.captureResumeState())'));page.keyboard.press('KeyC')
 coverage=ev('''()=>{const e=fiorinaBench.engine,c=document.querySelector('canvas').getContext('2d'),out=[];for(const x of [0,2300,4920])for(const y of [0,55,110]){e.camera={x,y};c.clearRect(0,0,1280,720);e.drawBackdrop(c);const a=c.getImageData(0,0,1280,1).data;out.push([...a].filter((_,i)=>i%4===3).every(v=>v===255));}return out;}''');record('Background covers y=0 at nine camera poses',all(coverage))
 continuity=ev('''()=>{const e=fiorinaBench.engine,c=document.querySelector('canvas').getContext('2d'),pixels=[];for(const x of [207.9,208.1]){e.camera={x,y:0};c.clearRect(0,0,1280,720);e.drawBackdrop(c);pixels.push(c.getImageData(0,0,1280,720).data);}let diff=0;for(let i=0;i<pixels[0].length;i+=4)for(let k=0;k<3;k++)diff+=Math.abs(pixels[0][i+k]-pixels[1][i+k]);return diff/(1280*720*3);}''')
 record('Palette transitions do not abruptly replace the background',continuity<6,{'meanChannelDifference':continuity})
 ev('()=>{const b=fiorinaBench,e=b.engine;b.setLocation(8);e.alien3V88.phase="leadworks";e.alien3V89.company.visible=false;b.render();window.beforeCompany=e.alien3RenderStatsV103.props;e.alien3V89.company.visible=true;b.render();}')
 record('Company equipment remains event-conditional',ev('fiorinaBench.engine.alien3RenderStatsV103.props-beforeCompany')==8)
 # State round trip through actual mixin serialization.
 roundtrip=ev('''()=>{const e=fiorinaBench.engine,raw=JSON.parse(JSON.stringify(e.captureResumeState())),before=JSON.stringify(e.alien3V103);e.alien3V103.visitedNodes=[];e.alien3V103.lights['care-light']=false;e.applyResumeState(raw);return JSON.stringify(e.alien3V103)===before&&!e.alien3MapOpenV103;}''');record('Native mixin save round trip restores lighting and discovery',roundtrip)
 page.set_viewport_size({'width':844,'height':390});ev('fiorinaBench.render()');box=page.locator('canvas').bounding_box();record('Canvas fits mobile landscape',box['width']<=844 and box['height']<=390,box)
 ev('document.body.classList.remove("capture")');page.locator('[data-key="ArrowRight"]').scroll_into_view_if_needed();box=page.locator('[data-key="ArrowRight"]').bounding_box();old_x=ev('fiorinaBench.engine.player.x')
 page.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2);page.mouse.down();ev('fiorinaBench.tick(.15)');page.mouse.up();record('Visible touch button drives movement and releases its held key',ev('fiorinaBench.engine.player.x')>old_x and not ev('fiorinaBench.engine.keys.has("ArrowRight")'))
 record('No JavaScript page errors',not errors,errors);record('No external HTTP requests',not [r for r in reqs if r.startswith(('http:','https:'))]);b.close()
for s in shots:
 raw=(ROOT/s['file']).read_bytes();s.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),width=1280,height=720)
out={'ok':True,'scope':'Native Chromium screenshots of the local V101/V102/V103 renderer bench; simplified controller and placeholder actors. NOT full production campaign.', 'browser':version,'capturedAt':datetime.now(timezone.utc).isoformat(),'tests':len(checks),'results':checks,'screenshots':shots,'sourceHashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'src').glob('*v103.js')},'productionBuildTested':False}
(OUT/'browser.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'tests':len(checks),'captures':len(shots),'browser':version}))
