#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime,timezone
import json,base64,html,hashlib
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4,landscape
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
ROOT=Path(__file__).resolve().parents[1];Q=ROOT/'qa-v103';shots=Q/'captures'
u=json.loads((Q/'unit.json').read_text());inst=json.loads((Q/'installation.json').read_text());browser=json.loads((Q/'browser.json').read_text());reg=json.loads((Q/'regressions.json').read_text());doc=json.loads((Q/'documentation.json').read_text());cb=json.loads((Q/'codex-browser.json').read_text())
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
pdfmetrics.registerFont(TTFont('Body103',font));pdfmetrics.registerFont(TTFont('Bold103',bold))
W,H=landscape(A4);M=38;content=W-2*M
c=canvas.Canvas(str(ROOT/'ALIEN3_RAPPORT_ILLUSTRE_V103.pdf'),pagesize=(W,H));c.setTitle('Alien 3 — Fiorina 161 — V103 Passages et réseaux');c.setAuthor('Atelier du projet Tantalus')
style=ParagraphStyle('body',fontName='Body103',fontSize=10,leading=15,textColor=HexColor('#273c3b'))
small=ParagraphStyle('small',parent=style,fontSize=8.5,leading=12)
page_no=0
scope='Captures natives Chromium du banc local. Contrôleur simplifié et acteurs provisoires ; pas le jeu complet.'
def para(text,x,y,w,sty=style):
 p=Paragraph(text,sty);_,h=p.wrap(w,800);p.drawOn(c,x,y-h);return y-h

def header(title,sub=''):
 global page_no
 page_no+=1;c.setFillColor(HexColor('#f3f2eb'));c.rect(0,0,W,H,fill=1,stroke=0)
 c.setFillColor(HexColor('#334a46'));c.setFont('Bold103',9);c.drawString(M,H-27,'ALIEN 3  /  FIORINA 161')
 c.setFillColor(HexColor('#836e46'));c.drawRightString(W-M,H-27,'V103  ·  PASSAGES ET RÉSEAUX')
 c.setFillColor(HexColor('#1b3434'));c.setFont('Body103',23);c.drawString(M,H-61,title)
 if sub:para(sub,M,H-75,content,small)
 c.setStrokeColor(HexColor('#b8bcae'));c.line(M,32,W-M,32)
 c.setFont('Body103',6.8);c.setFillColor(HexColor('#60706a'));c.drawString(M,21,scope);c.drawRightString(W-M,21,str(page_no))

def image(file,x,y,w,h=None):
 im=ImageReader(str(file));iw,ih=im.getSize();height=h if h is not None else w*ih/iw;c.drawImage(im,x,y,w,height,mask='auto');return height

def full(title,filename,caption,sub=''):
 header(title,sub);height=content*720/1280;image(shots/filename,M,91,content,height);para(caption,M,77,content,small);c.showPage()

def pair(title,left,right,headleft,headright,text,sub=''):
 header(title,sub);gap=16;ww=(content-gap)/2;hh=ww*720/1280;y=245
 c.setFont('Bold103',11);c.setFillColor(HexColor('#35504a'));c.drawString(M,y+hh+13,headleft);c.drawString(M+ww+gap,y+hh+13,headright)
 image(left,M,y,ww,hh);image(right,M+ww+gap,y,ww,hh);para(text,M,223,content);c.showPage()

full('Passages, lumière et repères','06_fonderie.png',
 'Le creuset et son alimentation restent sur leurs supports. La V103 ajoute des raccords électriques locaux et remplace les plaques de fond par des alcôves. Ces images montrent les modules livrés, pas des illustrations séparées du code.',
 'Une passe de circulation et d’interaction, sans nouvelle route ni compteur de collecte.')
pair('De la plaque au lieu',ROOT/'qa-v102/captures/06_fonderie.png',shots/'06_fonderie.png','V102 · état de départ','V103 · même secteur',
 'Les composants ne changent pas de place. Le fond devient plus sombre, les alcôves différencient les ateliers, les sols reçoivent une tranche métallique et les câbles rejoignent des appareils identifiés.<br/><br/>Le jeu de données conserve trente assemblages et 284 composants. Les vingt sections ajoutées servent au nommage et à l’étage des lieux ; elles ne sont pas vingt nouvelles pièces instanciées. La topologie demeure à 72 points, 119 connexions et quatre routes héritées.')
pair('Une commande, un effet visible',shots/'10_lumiere_allumee.png',shots/'11_lumiere_eteinte.png','Lampe de soin allumée','Même lampe éteinte',
 'La touche I agit sur un interrupteur proche. L’état du luminaire et son halo changent réellement. Les huit commandes ne modifient que l’éclairage de service : elles ne coupent pas le four, l’eau du piège ou une condition de mission.<br/><br/>L’action exige le bon étage, le plan médian et une portée limitée. Elle est refusée derrière une porte fermée, pendant la pause, dans les archives ou sur le plan. Les états sont sauvegardés.',
 'Deux captures natives avant et après la commande au clavier.')
pair('La même porte, fermée puis ouverte',shots/'13_porte_fermee.png',shots/'14_porte_ouverte.png','Feuille fermée','Passage ouvert',
 'Les trois cadres correspondent aux trois portes existantes du graphe. Quand le niveau fournit une géométrie compilée, sa position et ses dimensions sont reprises telles quelles. Le dessin suit la progression d’ouverture native.<br/><br/>Dans ces deux essais, le contrôleur simplifié du banc bloque puis autorise le passage. Cela ne certifie pas les collisions du moteur principal. Dans la production, E reste une interaction historique : aucun verrou de mission n’est supprimé.')
full('Un plan qui se découvre','12_plan.png',
 'Le plan normal ne révèle que les points déjà visités et les liaisons dont les extrémités sont connues. Aucun adversaire n’y est placé. M ouvre et ferme le plan ; Échap le ferme sans effacer une pause préexistante.',
 'Les coordonnées de développement et les identifiants techniques restent hors du panneau joueur.')
full('Étages et raccords','16_plan_etages.png',
 'État avancé obtenu par positionnements de test pour relever tous les points. Ce n’est pas un parcours complet de la campagne. Les vingt libellés sont placés sans chevauchement ; les connexions verticales sont distinguées des passages horizontaux.',
 'Le graphe conservé est présenté comme un plan relevé, pas comme une garantie que toutes les portes sont ouvertes.')
pair('Deux fonctions, deux lectures',shots/'02_medical.png',shots/'03_detention.png','Infirmerie et morgue','Cellules et coursives',
 'L’infirmerie regroupe le soin et le lavage ; la morgue reste à son altitude propre. La détention utilise les barreaux, les couchettes et les espaces communs comme repères. Le libellé supérieur peut maintenant indiquer le lieu réel et son étage, plutôt que le seul découpage horizontal de caméra.<br/><br/>Les objets de fond ne sont pas des couvertures invisibles. La nouvelle couche ne crée aucune porte décorative utilisable ni raccourci inventé.')
pair('Le réseau suit ses appareils',shots/'04_service.png',shots/'05_supervision.png','Ventilation et entretien','Réserve et supervision',
 'Vingt-deux alimentations locales relient une source et un luminaire du même ensemble. Le registre conserve les identifiants des deux composants et les quatre points du tracé : 66 segments continus au total.<br/><br/>La priorité d’échelle corrige le conflit de Haut/Bas avec la profondeur dans la méthode V97. À portée d’une échelle, le contrôleur de locomotion reçoit ses touches ; ailleurs, la profondeur reste disponible. La restauration du mode est testée même lorsqu’une exception survient.')
pair('Ne pas perturber la fin de mission',shots/'07_moule.png',shots/'09_arrivee.png','Pistons et moule','Approche de la Compagnie',
 'La nouvelle couche respecte les conditions de la mission. Le matériel de récupération conserve sa condition d’arrivée et les exigences du piège ne sont pas remplacées par les interrupteurs de lumière.<br/><br/>Les tests vérifient que le matériel conditionnel reste absent avant son événement. La campagne complète et la superposition avec tous les anciens postes interactifs restent à tester dans le moteur principal avec ses assets.')
header('Un codex relié aux données','Un document extérieur au jeu, distinct des 90 archives du joueur.')
image(shots/'17_codex_conception.png',M,110,470,326.4)
para(f"<b>{doc['cards']} fiches consultables</b><br/>20 sections<br/>30 assemblages avec leurs composants<br/>22 réseaux et leurs points de raccord<br/>8 commandes et leurs contraintes<br/>3 portes natives<br/>72 points et 119 connexions<br/>30 règles de contrôle",M+488,437,content-488)
para('Recherche accentuée, filtres par catégorie et liens croisés. Les nombres, tailles et relations viennent de l’export des modules. Les limites artistiques et la portée des tests restent explicites.',M,89,content,small);c.showPage()
header('Ce qui a été vérifié','Les nombres suivants décrivent des périmètres différents ; ils ne sont pas additionnés en une certification générale.')
rows=[['Périmètre','Résultat','Portée'],['Contrats V103',str(u['cases'])+' cas passés','Données, interactions, sauvegarde et méthode V97'],['Installation',str(inst['cases'])+' scénarios passés','Fixtures synthétiques, restauration et modifications concurrentes'],['Chromium',str(browser['tests'])+' contrôles passés','Banc jouable local et captures natives'],['Codex HTML',str(cb['tests'])+' contrôles passés','Recherche, filtres et navigation'],['Héritage',str(reg['passed'])+'/'+str(reg['total'])+' scripts passés','Suites isolées V88 à V102 conservées']]
t=Table([[Paragraph(html.escape(v),small) for v in r] for r in rows],colWidths=[130,145,content-275]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#d1d8cb')),('GRID',(0,0),(-1,-1),.4,HexColor('#b1bbae')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9)]));_,th=t.wrap(content,420);t.drawOn(c,M,479-th)
y=458-th
para('<b>Installation :</b> depuis V102, trois modules et le raccord du moteur sont ajoutés. L’installation travaille dans une copie avant validation ; une modification concurrente des fichiers surveillés provoque un refus plutôt qu’un écrasement. La récupération préserve aussi les fichiers locaux et l’ancien dossier de distribution.',M,y,content)
para('<b>Non effectué :</b> build du dépôt complet, exécution intégrale de la campagne, vérification des sprites définitifs, push GitHub ou déploiement. Les résultats npm des fixtures sont simulés pour vérifier le mécanisme d’installation, pas pour annoncer un build du jeu.',M,y-76,content)
para('<b>Preuves :</b> qa-v103/unit.json · installation.json · browser.json · codex-browser.json · regressions.json. Les captures portent leurs empreintes et les états observés dans browser.json.',M,83,content,small);c.showPage();c.save()
# Standalone illustrated HTML uses the original PNG bytes, not redrawn images.
parts=['<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Rapport illustré V103</title><style>body{max-width:1180px;margin:28px auto;padding:0 20px;background:#121c1d;color:#d8dfd4;font:16px/1.6 system-ui}h1,h2{font-weight:500}p{color:#b7c7b8}.scope{border-left:3px solid #b9a174;padding:12px;background:#26312c}img{width:100%;height:auto;border:1px solid #586453}figure{margin:35px 0}figcaption{font-size:13px;color:#bac5b5}code{font-size:12px}header{border-bottom:1px solid #586453;padding-bottom:20px}</style><header><h1>Fiorina 161 — V103</h1><h2>Passages et réseaux</h2><p class="scope">'+html.escape(scope)+' Les états de prise de vue sont préparés pour examiner des situations précises, pas pour prouver un parcours complet.</p><p>45 contrats ciblés, 16 scénarios d’installation, 37 contrôles Chromium, 8 contrôles du codex et 57 scripts historiques passés.</p></header>']
for sh in sorted(browser['screenshots'],key=lambda x:x['file']):
 raw=(ROOT/sh['file']).read_bytes();parts.append('<figure><img alt="'+html.escape(sh['caption'])+'" src="data:image/png;base64,'+base64.b64encode(raw).decode()+'"><figcaption>'+html.escape(sh['caption'])+'<br><code>'+html.escape(sh['file'])+'</code></figcaption></figure>')
parts.append('<footer><p>Modules de rendu réellement exécutés : alien3-art-v103.js, alien3-dlc-runtime-v103.js et héritage V101/V102. Aucune de ces images n’est un concept art généré.</p></footer></html>')
(ROOT/'ALIEN3_RAPPORT_ILLUSTRE_V103.html').write_text(''.join(parts))
(Q/'report.json').write_text(json.dumps({'pages':page_no,'capturesInBrowserReport':len(browser['screenshots']),'scope':scope,'createdAt':datetime.now(timezone.utc).isoformat()},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'pdfPages':page_no,'pdfBytes':(ROOT/'ALIEN3_RAPPORT_ILLUSTRE_V103.pdf').stat().st_size}))
