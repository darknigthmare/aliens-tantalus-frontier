#!/usr/bin/env python3
"""Verify exactly the files listed in the delivered SHA-256 manifest."""
from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
m=json.loads((root/'PATCH_MANIFEST.json').read_text());wanted=m['files'];actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='PATCH_MANIFEST.json'}
missing=[];bad=[]
for rel,info in wanted.items():
 p=root/rel
 if not p.is_file():missing.append(rel)
 elif p.stat().st_size!=info['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=info['sha256']:bad.append(rel)
out={'ok':not(missing or bad or actual-set(wanted)),'files':len(wanted),'missing':missing,'hashErrors':bad,'extra':sorted(actual-set(wanted))}
print(json.dumps(out,indent=2));sys.exit(0 if out['ok'] else 1)
