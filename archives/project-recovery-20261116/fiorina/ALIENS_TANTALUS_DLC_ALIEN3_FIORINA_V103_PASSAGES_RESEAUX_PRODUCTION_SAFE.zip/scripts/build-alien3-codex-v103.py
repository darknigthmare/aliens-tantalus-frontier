#!/usr/bin/env python3
"""Generate the design codex from the exact runtime-exported placements."""
from pathlib import Path
import json,html
ROOT=Path(__file__).resolve().parents[1]
data=json.loads((ROOT/'qa-v103/design-source.json').read_text());s=data['scene'];records=[]
def esc(x):return html.escape(str(x))
def f(x):return f'{x:.2f}'.rstrip('0').rstrip('.') if isinstance(x,(int,float)) else str(x)
def table(headers,rows):return '<table><thead><tr>'+''.join('<th>'+esc(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(f(v))+'</td>' for v in row)+'</tr>' for row in rows)+'</tbody></table>'
def ref(id,title=None):return '<a class="ref" href="#'+esc(id)+'">'+esc(title or id)+'</a>'
def add(id,cat,title,body,plain):records.append({'id':id,'category':cat,'title':title,'body':body,'text':plain})
by_node={n['id']:n for n in s['nodes']};props={p['id']:p for p in s['decor']['props']}
intro='''Cette édition prolonge les trente assemblages ancrés de V102. Elle conserve 72 points, 119 connexions et quatre routes héritées. Les vingt sections servent à décrire les lieux et leurs étages ; elles ne sont pas vingt nouvelles salles instanciées. Les cotes sont des unités de jeu, pas des relevés des plateaux du film. La campagne entière avec ses sprites définitifs n’a pas été exécutée dans cette livraison.'''
md=['# ALIEN 3 — FIORINA 161','## Codex de level design V103 · Passages et réseaux','',intro,'', '## Contrats généraux', '',
'Le décor ne dépend jamais de la hauteur de saut. Les machines restent sur leur support nommé ; seules les masses lointaines sont en parallaxe. Les transitions de vocabulaire sont fondues sur une bande de 192 unités. Les murs de fond et niches sont non collidables. Les trois portes reprennent les mêmes positions et dimensions que les portes natives fournies par le niveau. Aucune arête ni serrure nouvelle ne leur est ajoutée.', '',
'Les vingt-deux circuits ajoutés sont des alimentations électriques locales reliant deux composants du même assemblage. Ils ne simulent ni fluide, ni énergie, ni panne générale. Huit petits interrupteurs sont utilisables : ils modifient uniquement leurs luminaires de service. Ni la coulée de plomb, ni le refroidissement, ni le feu du four, ni l’intelligence du Runner ne dépendent de ces états.', '',
'Le plan est limité aux nœuds visités et aux liaisons dont les deux bouts ont été relevés. Il ne localise aucun adversaire. « Liaison relevée » ne signifie pas « passage garanti ouvert ». Le registre des sections sert de nommage ; les points intermédiaires gardent la désignation Passage relevé.', '',
'La priorité d’échelle est une correction réelle au-dessus de la méthode V97 : pendant une mise à jour de locomotion, le mode profondeur est suspendu si une échelle est à portée, puis restauré même en cas d’exception. Ailleurs, Haut/Bas conserve son rôle de profondeur. La classe de base reste propriétaire des collisions et de la montée.', '',
'## Sections, étages et raccords','']
for room in s['spaces']:
 ns=[by_node[id] for id in room['nodes']];groups=[g for g in s['decor']['groups'] if g['nodeId'] in room['nodeIds']]
 edges=[e for e in s['edges'] if (e['from'] in room['nodeIds']) != (e['to'] in room['nodeIds'])]
 body='<p>'+esc(room['usage'])+'</p><p><b>Repère :</b> '+esc(room['landmark'])+'</p>'
 body+=table(['Limite ouest','Limite est','Sol moyen','Vocabulaire'],[[room['x'],room['right'],room['floor'],room['style']]])
 body+='<h4>Points de rattachement</h4>'+' '.join(ref('node:'+n['id'],n['id']) for n in ns)
 body+='<h4>Assemblages</h4>'+(' '.join(ref('assembly:'+g['id'],g['label']) for g in groups) or '<p>Aucun nouvel ensemble dédié ; section de circulation.</p>')
 body+='<h4>Raccords à vérifier</h4>'+table(['Connexion','Origine','Destination','Passage'],[[e['id'],e['from'],e['to'],e['kind']] for e in edges])
 check=f"Contrôler le dégagement près de {room['landmark'].lower()}. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire {room['style']} est un choix d’adaptation, pas une certification du film."
 body+='<p class="check">'+esc(check)+'</p>'
 add('section:'+room['id'],'Sections',room['label'],body,room['usage']+' '+room['landmark']+' '+check)
 md += ['### '+room['label'],'',room['usage'],f"Repère : {room['landmark']}. X {f(room['x'])}–{f(room['right'])} ; sol moyen {f(room['floor'])}.",'','Points : '+', '.join(room['nodes']),'','Assemblages : '+(', '.join(g['label'] for g in groups) or 'circulation uniquement'),'',check,'','Raccords :']
 for e in edges:md.append(f"- {e['id']} : {e['from']} ↔ {e['to']} ; {e['kind']}.")
 md.append('')
md+=['## Assemblages et composants hérités','', 'Les coordonnées suivantes sont celles réellement exportées par compileAlien3DecorV102. Le nouveau rendu remplace leur plaque rectangulaire par une alcôve, sans déplacer les composants.','']
for g in s['decor']['groups']:
 ps=[p for p in s['decor']['props'] if p['assemblyId']==g['id']];circuits=[c for c in s['circuits'] if c['assemblyId']==g['id']]
 description=f"Support {g['supportId']} ; origine ({f(g['x'])}, {f(g['y'])}) ; largeur {f(g['w'])} ; hauteur {f(g['h'])} ; échelle {f(g['scale'])}. Plan arrière non collidable ; condition {g['condition']}."
 body='<p>'+esc(description)+'</p>'+table(['Composant','Forme','X','Y','L','H','Pose'],[[p['id'],p['kind'],p['x'],p['y'],p['w'],p['h'],p['mount']] for p in ps])
 body+='<p>Alimentation locale : '+(' '.join(ref('circuit:'+c['id'],c['id']) for c in circuits) or 'aucun circuit ajouté sans point source défini.')+'</p>'
 add('assembly:'+g['id'],'Assemblages',g['label'],body,description+' '+' '.join(p['kind'] for p in ps))
 md += ['### '+g['label'],'',description,'','| Forme | X | Y | Largeur | Hauteur | Pose |','|---|---:|---:|---:|---:|---|']
 md += ['| '+' | '.join(f(p[k]) for k in ['kind','x','y','w','h','mount'])+' |' for p in ps];md.append('')
md+=['## Réseaux locaux','', 'Chaque réseau relie un boîtier, une console ou un support électrique à un luminaire du même ensemble. Le trajet comprend quatre points et trois segments continus. Ces câbles sont décoratifs, sans collision. Ils ne représentent pas des conduites de métal ou d’eau.','']
for c in s['circuits']:
 a,b=props[c['sourceId']],props[c['targetId']]
 description=f"{c['kind']} ; ensemble {c['assemblyId']}. Source {c['sourceId']} ({a['kind']}) ; récepteur {c['targetId']} ({b['kind']}). Condition {c['condition']}. Aucun transfert d’énergie calculé."
 body='<p>'+esc(description)+'</p>'+table(['Point','X','Y'],[[i+1,p['x'],p['y']] for i,p in enumerate(c['points'])])+'<p>'+ref('assembly:'+c['assemblyId'],'Ouvrir l’ensemble')+'</p>'
 add('circuit:'+c['id'],'Réseaux',c['id'],body,description)
 md+=['### '+c['id'],'',description,'',' → '.join(f"({f(p['x'])}, {f(p['y'])})" for p in c['points']),'']
md+=['## Commandes physiques','', 'Touche I. L’action ne remplace pas E et ne peut pas consommer une interaction de quête. La cible doit être vivante, non occupée, au plan médian, à moins de 82 unités horizontalement et à moins de 24 unités du même sol. Une porte fermée ou insuffisamment ouverte entre personnage et interrupteur bloque l’action. Le plan, les archives, la pause et la fin de mission refusent également la commande. Temporisation de 0,22 seconde.','']
for u in s['utilities']:
 description=f"{u['label']} ; support {u['supportId']} ; panneau ({f(u['x'])}, {f(u['y'])}), taille {u['w']} × {u['h']}, sol {u['footY']}. État initial allumé. Identifiant sauvegardé : {u['id']}."
 body='<p>'+esc(description)+'</p><p>Récepteurs : '+', '.join(esc(t) for t in u['targets'])+'</p><p>Enregistrement : specialOperation.alien3V103.lights. Une ancienne sauvegarde sans cet état utilise les réglages initiaux. Seuls des booléens vrais ou faux et des identifiants connus sont acceptés.</p>'+ref('assembly:'+u['assemblyId'],'Voir les composants')
 add('utility:'+u['id'],'Commandes',u['label'],body,description)
 md+=['### '+u['label'],'',description,'','Récepteurs : '+', '.join(u['targets']), '']
md+=['## Portes natives','', 'La V103 change le dessin du cadre et de la feuille, pas le verrouillage. La hauteur visible de la feuille suit progress de 0 à 1. Dans le jeu principal, le contrôleur natif continue de décider quand la porte peut s’ouvrir. Les essais de franchissement du banc utilisent son contrôleur simplifié.','']
for g in s['gates']:
 description=f"{g['label']} ; {g['from']} ↔ {g['to']}, connexion {g['edgeId']}. Coordonnées par défaut : X {f(g['x'])}, Y {f(g['y'])}, L {g['w']}, H {g['h']}. Un plan compilé fourni remplace ces valeurs par les positions natives exactes."
 body='<p>'+esc(description)+'</p>'+ref('edge:'+g['edgeId'],'Voir la connexion')
 add('gate:'+g['id'],'Portes',g['label'],body,description);md+=['### '+g['id'],'',description,'']
md+=['## Points du graphe','', 'Les points ci-dessous sont conservés. Un point n’équivaut pas à une pièce complète.','']
for n in s['nodes']:
 es=[e for e in s['edges'] if n['id'] in [e['from'],e['to']]]
 title=n['id'];desc=f"Point ({n['x']}, {n['y']}) ; largeur de support {n['width']} ; zone {n['zoneId']}."
 body='<p>'+esc(desc)+'</p><h4>Voisinage</h4>'+table(['Connexion','Voisin','Type','Écart X','Écart Y'],[[e['id'],(other:=by_node[e['to'] if e['from']==n['id'] else e['from']])['id'],e['kind'],other['x']-n['x'],other['y']-n['y']] for e in es])
 add('node:'+n['id'],'Points',title,body,desc+' '+' '.join(e['id'] for e in es))
 md+=['### '+n['id'],'',desc]+[f"- {e['id']} : {e['to'] if e['from']==n['id'] else e['from']} / {e['kind']}" for e in es]+['']
md+=['## Registre des connexions','', '| Connexion | Origine | Destination | Type | ΔX | ΔY |','|---|---|---|---|---:|---:|']
for e in s['edges']:
 a,b=by_node[e['from']],by_node[e['to']];desc=f"{a['id']} ↔ {b['id']}. Type {e['kind']} ; ΔX {b['x']-a['x']}, ΔY {b['y']-a['y']}. Routes : {', '.join(e.get('routeIds',[]))}."
 add('edge:'+e['id'],'Connexions',e['id'],'<p>'+esc(desc)+'</p>'+ref('node:'+a['id'],a['id'])+' '+ref('node:'+b['id'],b['id']),desc)
 md.append('| '+' | '.join(str(v) for v in [e['id'],a['id'],b['id'],e['kind'],b['x']-a['x'],b['y']-a['y']])+' |')
md+=['','## Grille de contrôle','']
for rule in data['rules']:
 desc=rule['text']+' Vérification : '+rule['validation']+'.'
 add('rule:'+rule['id'],'Règles',rule['id'],'<p>'+esc(desc)+'</p>',desc);md+=['### '+rule['id'],'',desc,'']
md+=['## Validation et limites','', 'Les résultats sont dans qa-v103/unit.json, installation.json, browser.json et regressions.json. Les fixtures d’installation simulent les commandes npm ; elles prouvent le comportement transactionnel, pas le build du dépôt complet. Les captures sont natives Chromium et utilisent les modules de rendu livrés, un contrôleur simplifié et des acteurs provisoires. Elles ne prouvent pas les collisions de la campagne principale avec tous ses anciens interactifs.', '', 'Les règles artistiques et la fidélité aux décors du film restent un examen visuel. L’édition ne prétend pas reconstruire toute la prison en pièces instanciées. Aucun grade, succès ou compteur de collecte supplémentaire n’est ajouté.','']
(ROOT/'docs/ALIEN3_LEVEL_DESIGN_CODEX_V103.md').write_text('\n'.join(md))
payload=json.dumps(records,ensure_ascii=False).replace('</',r'<\/')
page='''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fiorina 161 — Codex de level design V103</title><style>
*{box-sizing:border-box}body{margin:0;background:#10191a;color:#d7dfd8;font:15px/1.6 system-ui,sans-serif}header{padding:32px max(22px,calc((100vw - 1240px)/2));background:linear-gradient(135deg,#29332e,#101c21);border-bottom:1px solid #59695c}h1{font-size:32px;font-weight:500;margin:5px 0}h2{font-size:24px;font-weight:500}h3{font-size:21px;font-weight:500;margin:10px 0}h4{color:#c8c5a3}header p{max-width:1060px;color:#b5c0b4}.eyebrow{letter-spacing:.18em;color:#baa879;font-size:11px}main{max-width:1240px;margin:20px auto;padding:0 20px}nav{position:sticky;top:0;background:#111e20;z-index:2;display:flex;gap:10px;flex-wrap:wrap;padding:14px 0;border-bottom:1px solid #526256}input,select,button{padding:10px 12px;border:1px solid #52695e;background:#20312d;color:#edf0d8;border-radius:4px;font:inherit}input{flex:1;min-width:220px}input:focus-visible,select:focus-visible,button:focus-visible,a:focus-visible{outline:2px solid #dabd85;outline-offset:3px}.count{font-size:12px;display:block;color:#9cae9e;padding:10px 0}article{border:1px solid #3e544d;background:#152320;padding:24px;margin:15px 0;scroll-margin-top:100px}article .tag{color:#c8ae79;font-size:11px;letter-spacing:.1em;text-transform:uppercase}table{width:100%;border-collapse:collapse;font-size:12px;display:block;overflow-x:auto}td,th{padding:8px 11px;border-bottom:1px solid #344e41;text-align:left;white-space:nowrap}th{color:#d1bb8f}.ref{display:inline-block;color:#c0d6b8;padding:3px 8px;margin:3px;border:1px solid #425a48;border-radius:3px;text-decoration:none;font-size:12px}.check{border-left:3px solid #b0986a;padding:12px;background:#28332a}footer{margin:30px 0 60px;font-size:12px;color:#9cab9d}details summary{cursor:pointer;color:#c8b788}@media print{nav,input,select,button{display:none}body{background:white;color:black}article{break-inside:avoid;background:white;border-color:#ccc}td,th{border-color:#ccc}header{background:white;color:black}}
</style><header><span class="eyebrow">ALIEN 3 · FIORINA 161 · DOCUMENT DE CONCEPTION</span><h1>Passages et réseaux</h1><p>V103 · Sections par étage, ensembles ancrés, alimentations locales, commandes et raccords.</p><p>__INTRO__</p></header><main><nav><input id="q" aria-label="Rechercher dans le codex" placeholder="Rechercher une salle, un prop, un point ou une règle…"><select id="category" aria-label="Catégorie"><option value="">Toutes les fiches</option></select><button id="reset">Tout afficher</button></nav><span id="count" class="count"></span><div id="cards"></div><footer>Le codex est extérieur au jeu. Les noms techniques et les cotes ne sont pas des textes du HUD. Tous les chiffres viennent de l’export des modules V103 ; les limites du banc sont conservées dans les rapports.</footer></main><script>
const records=__PAYLOAD__;
const norm=s=>String(s).normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase(),q=document.querySelector('#q'),select=document.querySelector('#category'),cards=document.querySelector('#cards');
for(const cat of [...new Set(records.map(r=>r.category))])select.add(new Option(cat,cat));
const escape=s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function render(){const term=norm(q.value),filtered=records.filter(r=>(!select.value||r.category===select.value)&&(!term||norm(r.title+' '+r.text+' '+r.body.replace(/<[^>]*>/g,' ')).includes(term)));cards.innerHTML=filtered.map(r=>'<article id="'+escape(r.id)+'"><span class="tag">'+escape(r.category)+'</span><h3>'+escape(r.title)+'</h3>'+r.body+'</article>').join('');document.querySelector('#count').textContent=filtered.length+' fiches affichées sur '+records.length;}
q.oninput=render;select.onchange=render;document.querySelector('#reset').onclick=()=>{q.value='';select.value='';render();};
function follow(){let id;try{id=decodeURIComponent(location.hash.slice(1));}catch{return;}if(!records.some(r=>r.id===id))return;q.value='';select.value='';render();document.getElementById(id)?.scrollIntoView({block:'start'});}
addEventListener('hashchange',follow);render();if(location.hash)follow();window.fiorinaCodex={records,render};
</script></html>'''.replace('__INTRO__',esc(intro)).replace('__PAYLOAD__',payload)
(ROOT/'ALIEN3_CODEX_LEVEL_DESIGN_V103.html').write_text(page)
(ROOT/'qa-v103/documentation.json').write_text(json.dumps({'schema':103,'cards':len(records),'categories':{cat:sum(r['category']==cat for r in records) for cat in sorted(set(r['category'] for r in records))},'markdownLines':len(md),'source':'qa-v103/design-source.json'},indent=2)+'\n')
print(json.dumps({'cards':len(records),'markdownLines':len(md),'htmlBytes':len(page.encode())}))
