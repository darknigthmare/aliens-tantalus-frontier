# ALIEN 3 — FIORINA 161
## Codex de level design V103 · Passages et réseaux

Cette édition prolonge les trente assemblages ancrés de V102. Elle conserve 72 points, 119 connexions et quatre routes héritées. Les vingt sections servent à décrire les lieux et leurs étages ; elles ne sont pas vingt nouvelles salles instanciées. Les cotes sont des unités de jeu, pas des relevés des plateaux du film. La campagne entière avec ses sprites définitifs n’a pas été exécutée dans cette livraison.

## Contrats généraux

Le décor ne dépend jamais de la hauteur de saut. Les machines restent sur leur support nommé ; seules les masses lointaines sont en parallaxe. Les transitions de vocabulaire sont fondues sur une bande de 192 unités. Les murs de fond et niches sont non collidables. Les trois portes reprennent les mêmes positions et dimensions que les portes natives fournies par le niveau. Aucune arête ni serrure nouvelle ne leur est ajoutée.

Les vingt-deux circuits ajoutés sont des alimentations électriques locales reliant deux composants du même assemblage. Ils ne simulent ni fluide, ni énergie, ni panne générale. Huit petits interrupteurs sont utilisables : ils modifient uniquement leurs luminaires de service. Ni la coulée de plomb, ni le refroidissement, ni le feu du four, ni l’intelligence du Runner ne dépendent de ces états.

Le plan est limité aux nœuds visités et aux liaisons dont les deux bouts ont été relevés. Il ne localise aucun adversaire. « Liaison relevée » ne signifie pas « passage garanti ouvert ». Le registre des sections sert de nommage ; les points intermédiaires gardent la désignation Passage relevé.

La priorité d’échelle est une correction réelle au-dessus de la méthode V97 : pendant une mise à jour de locomotion, le mode profondeur est suspendu si une échelle est à portée, puis restauré même en cas d’exception. Ailleurs, Haut/Bas conserve son rôle de profondeur. La classe de base reste propriétaire des collisions et de la montée.

## Sections, étages et raccords

### Côte et épave

Approche extérieure ; l’épave conduit vers le complexe.
Repère : Coque éventrée et prise d’air. X 50–770 ; sol moyen 510.

Points : f161-spawn, f161-eev

Assemblages : Prise d’air côtière, Épave et matériel de secours

Contrôler le dégagement près de coque éventrée et prise d’air. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire coast est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e02 : f161-eev ↔ f161-infirmary ; walk.
- f161-e89 : f161-eev ↔ f161-flight-analysis-v94 ; ladder.
- f161-e91 : f161-eev ↔ f161-wreckage-incident-v94 ; ladder.

### Infirmerie

Soins et circulation principale ; le mobilier reste derrière le passage.
Repère : Brancard, lavabo et lampe de soin. X 970–1670 ; sol moyen 510.

Points : f161-infirmary, f161-clemens-bed, f161-funeral-walk

Assemblages : Poste de soin, Chambre médicale

Contrôler le dégagement près de brancard, lavabo et lampe de soin. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire medical est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e02 : f161-eev ↔ f161-infirmary ; walk.
- f161-e03 : f161-infirmary ↔ f161-cell-a ; gate.
- f161-e12 : f161-infirmary ↔ f161-morgue-high ; ladder.
- f161-e19 : f161-infirmary ↔ f161-service-deep ; vent.
- f161-e48 : f161-funeral-walk ↔ f161-morgue-high ; ladder.
- f161-e92 : f161-wreckage-incident-v94 ↔ f161-infirmary ; ladder.

### Morgue et dossiers

Palier supérieur, séparé de l’infirmerie par son altitude.
Repère : Table mortuaire et armoire. X 1175–1630 ; sol moyen 350.

Points : f161-master-archive-node, f161-morgue-high

Assemblages : Baie mortuaire

Contrôler le dégagement près de table mortuaire et armoire. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire medical est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e12 : f161-infirmary ↔ f161-morgue-high ; ladder.
- f161-e13 : f161-morgue-high ↔ f161-mess-high ; walk.
- f161-e48 : f161-funeral-walk ↔ f161-morgue-high ; ladder.
- f161-e90 : f161-flight-analysis-v94 ↔ f161-morgue-high ; walk.

### Cellules ouest

Coursive basse ; les cellules peintes ne sont pas des passages ajoutés.
Repère : Barreaux et couchettes. X 1750–2450 ; sol moyen 510.

Points : f161-cell-a, f161-assembly-hall

Assemblages : Cellules ouest

Contrôler le dégagement près de barreaux et couchettes. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire detention est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e03 : f161-infirmary ↔ f161-cell-a ; gate.
- f161-e23 : f161-cell-a ↔ f161-mess-high ; ladder.
- f161-e28 : f161-assembly-hall ↔ f161-cell-b ; walk.
- f161-e29 : f161-assembly-hall ↔ f161-mess-high ; ladder.
- f161-e104 : f161-cell-a ↔ f161-shelter-cell-v95 ; ladder.
- f161-e105 : f161-shelter-cell-v95 ↔ f161-assembly-hall ; ladder.

### Cellules est

Approche du verrou des galeries ; conserver une sortie identifiable.
Repère : Volet réel à l’est. X 2470–2820 ; sol moyen 510.

Points : f161-cell-b, f161-shutter-cell-node

Assemblages : Cellules est

Contrôler le dégagement près de volet réel à l’est. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire detention est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e05 : f161-cell-b ↔ f161-service-low ; gate.
- f161-e28 : f161-assembly-hall ↔ f161-cell-b ; walk.
- f161-e64 : f161-shutter-cell-node ↔ f161-comms-high ; ladder.

### Réfectoire

Tables regroupées ; accès par les connecteurs déjà présents.
Repère : Longue table et bancs. X 2180–2565 ; sol moyen 350.

Points : f161-mess-high, f161-mess-ceiling

Assemblages : Réfectoire

Contrôler le dégagement près de longue table et bancs. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire detention est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e13 : f161-morgue-high ↔ f161-mess-high ; walk.
- f161-e14 : f161-mess-high ↔ f161-service-high ; walk.
- f161-e23 : f161-cell-a ↔ f161-mess-high ; ladder.
- f161-e29 : f161-assembly-hall ↔ f161-mess-high ; ladder.
- f161-e50 : f161-mess-ceiling ↔ f161-comms-high ; walk.
- f161-e77 : f161-mess-ceiling ↔ f161-perch-cell-v93 ; ladder.
- f161-e93 : f161-mess-high ↔ f161-faith-dais-v94 ; ladder.

### Communications

Poste haut réel, distinct du secteur caméra nommé communications.
Repère : Deux écrans sur console. X 2630–2810 ; sol moyen 350.

Points : f161-comms-high

Assemblages : Poste de communication

Contrôler le dégagement près de deux écrans sur console. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire comms est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e50 : f161-mess-ceiling ↔ f161-comms-high ; walk.
- f161-e64 : f161-shutter-cell-node ↔ f161-comms-high ; ladder.
- f161-e78 : f161-perch-cell-v93 ↔ f161-comms-high ; ladder.
- f161-e107 : f161-watch-cell-v95 ↔ f161-comms-high ; ladder.

### Recueillement

Palier haut austère, sans nouvelle porte au fond.
Repère : Livre et petites flammes. X 2055–2585 ; sol moyen 190.

Points : f161-faith-dais-v94, f161-perch-cell-v93

Assemblages : Lieu de recueillement

Contrôler le dégagement près de livre et petites flammes. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire chapel est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e77 : f161-mess-ceiling ↔ f161-perch-cell-v93 ; ladder.
- f161-e78 : f161-perch-cell-v93 ↔ f161-comms-high ; ladder.
- f161-e93 : f161-mess-high ↔ f161-faith-dais-v94 ; ladder.
- f161-e106 : f161-perch-cell-v93 ↔ f161-watch-cell-v95 ; walk.

### Pompage et secours

Eau, entretien et passage principal ; éclairage de service indépendant des objectifs.
Repère : Pompe sur semelle. X 2920–3650 ; sol moyen 510.

Points : f161-service-low, f161-rescue-post-node, f161-bishop

Assemblages : Pompage des galeries

Contrôler le dégagement près de pompe sur semelle. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire service est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e05 : f161-cell-b ↔ f161-service-low ; gate.
- f161-e07 : f161-bishop ↔ f161-leadworks ; gate.
- f161-e24 : f161-service-low ↔ f161-service-high ; ladder.
- f161-e25 : f161-service-low ↔ f161-service-deep ; ladder.
- f161-e35 : f161-service-low ↔ f161-fuel-manifold-a ; walk.
- f161-e37 : f161-fuel-manifold-b ↔ f161-bishop ; walk.
- f161-e38 : f161-bishop ↔ f161-chemical-store ; walk.
- f161-e53 : f161-tunnel-shrine ↔ f161-bishop ; ladder.
- f161-e69 : f161-bishop ↔ f161-shutter-service-node ; walk.
- f161-e81 : f161-rescue-post-node ↔ f161-triage-v93 ; walk.

### Ventilation

Palier technique supérieur ; une échelle ne doit pas changer la profondeur.
Repère : Ventilateur sous grille. X 2855–3270 ; sol moyen 330.

Points : f161-fan-shaft, f161-service-high, f161-steam-service-node

Assemblages : Ventilateur de maintenance, Entretien des réseaux

Contrôler le dégagement près de ventilateur sous grille. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire service est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e14 : f161-mess-high ↔ f161-service-high ; walk.
- f161-e15 : f161-service-high ↔ f161-tunnel-high ; walk.
- f161-e24 : f161-service-low ↔ f161-service-high ; ladder.
- f161-e79 : f161-steam-service-node ↔ f161-perch-service-v93 ; ladder.
- f161-e80 : f161-perch-service-v93 ↔ f161-service-high ; ladder.
- f161-e95 : f161-service-high ↔ f161-battery-locker-v94 ; walk.
- f161-e110 : f161-service-high ↔ f161-hunt-service-v95 ; walk.

### Atelier des batteries

Établi et rangement au-dessus de la circulation basse.
Repère : Panneau à outils. X 3265–3625 ; sol moyen 330.

Points : f161-hunt-service-v95, f161-battery-locker-v94

Assemblages : Recharge des batteries

Contrôler le dégagement près de panneau à outils. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire service est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e95 : f161-service-high ↔ f161-battery-locker-v94 ; walk.
- f161-e96 : f161-battery-locker-v94 ↔ f161-tunnel-high ; walk.
- f161-e110 : f161-service-high ↔ f161-hunt-service-v95 ; walk.

### Galeries basses

Dessous du complexe ; les regards vers les étages ne constituent pas un accès.
Repère : Alcôve et réseaux. X 2930–3775 ; sol moyen 630.

Points : f161-service-deep, f161-tunnel-shrine, f161-golic-cache-v94

Assemblages : Alcôve des galeries

Contrôler le dégagement près de alcôve et réseaux. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire service est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e19 : f161-infirmary ↔ f161-service-deep ; vent.
- f161-e20 : f161-service-deep ↔ f161-tunnel-low ; walk.
- f161-e25 : f161-service-low ↔ f161-service-deep ; ladder.
- f161-e53 : f161-tunnel-shrine ↔ f161-bishop ; ladder.
- f161-e98 : f161-golic-cache-v94 ↔ f161-tunnel-low ; walk.
- f161-e108 : f161-service-deep ↔ f161-refuge-service-v95 ; walk.
- f161-e109 : f161-refuge-service-v95 ↔ f161-tunnel-shrine ; walk.

### Réserve et supervision

Stockage puis commande industrielle ; respecter la position du portail existant.
Repère : Fûts et console de supervision. X 3565–4050 ; sol moyen 510.

Points : f161-chemical-store, f161-command-post-node

Assemblages : Réserve de produits, Supervision de la fonderie

Contrôler le dégagement près de fûts et console de supervision. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire comms est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e38 : f161-bishop ↔ f161-chemical-store ; walk.
- f161-e39 : f161-chemical-store ↔ f161-tunnel-high ; ladder.
- f161-e70 : f161-shutter-service-node ↔ f161-chemical-store ; walk.
- f161-e71 : f161-tunnel-high ↔ f161-command-post-node ; ladder.
- f161-e72 : f161-command-post-node ↔ f161-leadworks ; walk.

### Fonderie

Regrouper alimentation, creuset et levage, sans ajouter de danger décoratif.
Repère : Creuset sous portique. X 4030–4570 ; sol moyen 510.

Points : f161-leadworks, f161-lead-primer, f161-piston-a-node

Assemblages : Creuset et transfert, Alimentation du creuset

Contrôler le dégagement près de creuset sous portique. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire foundry est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e07 : f161-bishop ↔ f161-leadworks ; gate.
- f161-e08 : f161-leadworks ↔ f161-mold ; walk.
- f161-e21 : f161-tunnel-low ↔ f161-leadworks ; ladder.
- f161-e22 : f161-leadworks ↔ f161-furnace ; vent.
- f161-e26 : f161-leadworks ↔ f161-sprinkler ; ladder.
- f161-e32 : f161-sluice-low ↔ f161-leadworks ; ladder.
- f161-e41 : f161-lead-primer ↔ f161-mold ; walk.
- f161-e55 : f161-piston-a-node ↔ f161-mold ; walk.
- f161-e72 : f161-command-post-node ↔ f161-leadworks ; walk.

### Collecteur supérieur

Conduite d’eau séparée visuellement du transfert de métal.
Repère : Réservoir et vérins. X 4420–4910 ; sol moyen 330.

Points : f161-sprinkler, f161-water-header, f161-piston-b-node

Assemblages : Collecteur d’eau supérieur, Pistons supérieurs

Contrôler le dégagement près de réservoir et vérins. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire service est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e16 : f161-tunnel-high ↔ f161-sprinkler ; walk.
- f161-e17 : f161-sprinkler ↔ f161-furnace-high ; walk.
- f161-e26 : f161-leadworks ↔ f161-sprinkler ; ladder.
- f161-e43 : f161-water-header ↔ f161-mold ; ladder.
- f161-e57 : f161-piston-b-node ↔ f161-mold ; ladder.
- f161-e73 : f161-water-header ↔ f161-steam-lead-node ; walk.
- f161-e74 : f161-steam-lead-node ↔ f161-piston-b-node ; walk.
- f161-e84 : f161-perch-lead-v93 ↔ f161-piston-b-node ; ladder.
- f161-e100 : f161-battery-junction-v94 ↔ f161-water-header ; walk.
- f161-e117 : f161-bait-switch-v95 ↔ f161-sprinkler ; walk.

### Cuve et évacuation

Niveau inférieur : reprise des effluents et retour hydraulique.
Repère : Réservoir bas et caniveau. X 3915–4890 ; sol moyen 630.

Points : f161-waste-tank, f161-sluice-low, f161-pressure-alcove-v95

Assemblages : Collecte des effluents, Retour hydraulique

Contrôler le dégagement près de réservoir bas et caniveau. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire service est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e30 : f161-tunnel-low ↔ f161-waste-tank ; walk.
- f161-e32 : f161-sluice-low ↔ f161-leadworks ; ladder.
- f161-e115 : f161-hunt-junction-v95 ↔ f161-waste-tank ; walk.
- f161-e118 : f161-chase-reroute-v94 ↔ f161-pressure-alcove-v95 ; walk.

### Moule et pistons

Le piège et ses commandes historiques conservent leurs conditions.
Repère : Bac de coulée bas. X 4740–5230 ; sol moyen 510.

Points : f161-mold, f161-piston-c-node

Assemblages : Moule de coulée

Contrôler le dégagement près de bac de coulée bas. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire foundry est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e08 : f161-leadworks ↔ f161-mold ; walk.
- f161-e09 : f161-mold ↔ f161-furnace ; walk.
- f161-e41 : f161-lead-primer ↔ f161-mold ; walk.
- f161-e43 : f161-water-header ↔ f161-mold ; ladder.
- f161-e55 : f161-piston-a-node ↔ f161-mold ; walk.
- f161-e57 : f161-piston-b-node ↔ f161-mold ; ladder.
- f161-e59 : f161-piston-c-node ↔ f161-furnace ; walk.
- f161-e75 : f161-mold ↔ f161-shutter-foundry-node ; walk.
- f161-e76 : f161-shutter-foundry-node ↔ f161-piston-c-node ; walk.
- f161-e101 : f161-mold ↔ f161-chase-reroute-v94 ; ladder.

### Four principal

Approche chaude puis confrontation ; ne pas masquer les personnages.
Repère : Bouche circulaire du four. X 5310–5750 ; sol moyen 510.

Points : f161-furnace, f161-parley-v93

Assemblages : Four principal, Approche de la Compagnie

Contrôler le dégagement près de bouche circulaire du four. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire furnace est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e09 : f161-mold ↔ f161-furnace ; walk.
- f161-e10 : f161-furnace ↔ f161-company ; walk.
- f161-e18 : f161-furnace-high ↔ f161-furnace ; ladder.
- f161-e22 : f161-leadworks ↔ f161-furnace ; vent.
- f161-e59 : f161-piston-c-node ↔ f161-furnace ; walk.
- f161-e86 : f161-parley-v93 ↔ f161-company ; walk.
- f161-e102 : f161-chase-reroute-v94 ↔ f161-furnace ; ladder.

### Passerelles du four

Commande haute avec débouchés d’échelles conservés.
Repère : Treuil et caillebotis. X 5210–5880 ; sol moyen 330.

Points : f161-furnace-high, f161-furnace-overlook, f161-furnace-gantry

Assemblages : Commande de passerelle

Contrôler le dégagement près de treuil et caillebotis. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire foundry est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e17 : f161-sprinkler ↔ f161-furnace-high ; walk.
- f161-e18 : f161-furnace-high ↔ f161-furnace ; ladder.
- f161-e34 : f161-furnace-gantry ↔ f161-company ; ladder.
- f161-e45 : f161-furnace-overlook ↔ f161-company ; ladder.
- f161-e119 : f161-furnace-high ↔ f161-chase-observer-v95 ; walk.

### Approche et plateforme

L’équipement de récupération reste conditionné à l’arrivée de la Compagnie.
Repère : Cage portable et projecteur. X 5650–6190 ; sol moyen 510.

Points : f161-company, f161-patna-cage-node, f161-extraction

Assemblages : Matériel de récupération, Plateforme terminale

Contrôler le dégagement près de cage portable et projecteur. Vérifier le débouché de chaque connexion ci-dessus au bon étage. Une modification de la caméra ne doit déplacer aucun accessoire. Le vocabulaire company est un choix d’adaptation, pas une certification du film.

Raccords :
- f161-e10 : f161-furnace ↔ f161-company ; walk.
- f161-e34 : f161-furnace-gantry ↔ f161-company ; ladder.
- f161-e45 : f161-furnace-overlook ↔ f161-company ; ladder.
- f161-e86 : f161-parley-v93 ↔ f161-company ; walk.
- f161-e87 : f161-company ↔ f161-witness-v93 ; ladder.
- f161-e88 : f161-witness-v93 ↔ f161-extraction ; ladder.

## Assemblages et composants hérités

Les coordonnées suivantes sont celles réellement exportées par compileAlien3DecorV102. Le nouveau rendu remplace leur plaque rectangulaire par une alcôve, sans déplacer les composants.

### Prise d’air côtière

Support node-platform-f161-spawn ; origine (87.5, 510) ; largeur 185 ; hauteur 146 ; échelle 1. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| fan | 87.5 | 398 | 84 | 84 | wall |
| duct | 167.5 | 414 | 105 | 48 | wall |
| junction | 230.5 | 470 | 38 | 38 | wall |
| gauge | 194.5 | 467 | 22 | 22 | wall |
| pipe | 175.5 | 480 | 42 | 10 | wall |
| drain | 94.5 | 503 | 100 | 7 | floor |
| lamp | 127.5 | 364 | 40 | 13 | ceiling |
| cable | 244.5 | 409 | 7 | 52 | wall |
| support | 92.5 | 490 | 6 | 20 | floor |
| stencil | 188.5 | 370 | 77 | 19 | wall |

### Épave et matériel de secours

Support node-platform-f161-eev ; origine (485.5, 510) ; largeur 269 ; hauteur 158 ; échelle 1. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| eev | 485.5 | 396 | 236 | 114 | floor |
| cable | 496.5 | 471 | 80 | 12 | wall |
| case | 664.5 | 476 | 43 | 34 | floor |
| drain | 498.5 | 504 | 139 | 6 | floor |
| lamp | 565.5 | 352 | 41 | 13 | ceiling |
| junction | 728.5 | 461 | 26 | 44 | wall |
| pipe | 726.5 | 405 | 10 | 45 | wall |
| stencil | 660.5 | 367 | 72 | 20 | wall |

### Poste de soin

Support node-platform-f161-infirmary ; origine (1002, 510) ; largeur 236 ; hauteur 131.44 ; échelle 1. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| cabinet | 1002 | 411.42 | 44.81 | 98.58 | floor |
| gurney | 1067.72 | 466.19 | 105.55 | 43.81 | floor |
| monitor | 1110.54 | 408.43 | 51.78 | 38.84 | wall |
| sink | 1186.22 | 452.24 | 51.78 | 57.76 | floor |
| bottle | 1010.96 | 425.36 | 5.97 | 13.94 | wall |
| bottle | 1023.91 | 425.36 | 5.97 | 13.94 | wall |
| bottle | 1194.19 | 435.32 | 5.97 | 14.94 | wall |
| lamp | 1074.69 | 378.56 | 97.59 | 11.95 | ceiling |
| cable | 1159.33 | 446.27 | 7.97 | 54.77 | wall |
| pipe | 1231.03 | 419.38 | 6.97 | 21.91 | wall |
| tray | 1085.65 | 454.24 | 46.8 | 8.96 | wall |
| stencil | 1004.99 | 381.54 | 54.77 | 16.93 | wall |

### Chambre médicale

Support node-platform-f161-clemens-bed ; origine (1302, 510) ; largeur 156 ; hauteur 86.89 ; échelle 0.66. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| cabinet | 1302 | 444.84 | 29.62 | 65.16 | floor |
| gurney | 1345.44 | 481.04 | 69.77 | 28.96 | floor |
| monitor | 1373.75 | 442.86 | 34.23 | 25.67 | wall |
| sink | 1423.77 | 471.82 | 34.23 | 38.18 | floor |
| bottle | 1307.92 | 454.05 | 3.95 | 9.22 | wall |
| bottle | 1316.48 | 454.05 | 3.95 | 9.22 | wall |
| bottle | 1429.04 | 460.63 | 3.95 | 9.87 | wall |
| lamp | 1350.05 | 423.11 | 64.51 | 7.9 | ceiling |
| cable | 1406 | 467.87 | 5.27 | 36.2 | wall |
| pipe | 1453.39 | 450.1 | 4.61 | 14.48 | wall |
| tray | 1357.29 | 473.14 | 30.94 | 5.92 | wall |
| stencil | 1303.97 | 425.09 | 36.2 | 11.19 | wall |

### Baie mortuaire

Support node-platform-f161-morgue-high ; origine (1382, 350) ; largeur 236 ; hauteur 111.27 ; échelle 0.9. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| cabinet | 1382 | 271.03 | 52.05 | 78.97 | floor |
| gurney | 1458.27 | 312.31 | 98.71 | 37.69 | floor |
| sink | 1576.72 | 296.16 | 41.28 | 53.84 | floor |
| lamp | 1463.66 | 238.73 | 77.17 | 10.77 | ceiling |
| drain | 1461.86 | 345.51 | 96.91 | 4.49 | floor |
| tray | 1504.04 | 298.85 | 37.69 | 8.97 | wall |
| junction | 1588.39 | 256.68 | 22.43 | 21.54 | wall |
| stencil | 1384.69 | 239.63 | 52.05 | 14.36 | wall |

### Cellules ouest

Support node-platform-f161-cell-a ; origine (1767, 510) ; largeur 266 ; hauteur 154 ; échelle 1. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| cell | 1767 | 378 | 73 | 132 | floor |
| bunk | 1861 | 407 | 111 | 103 | floor |
| basin | 1990 | 462 | 35 | 48 | floor |
| lamp | 1784 | 356 | 37 | 11 | ceiling |
| blanket | 1880 | 471 | 42 | 8 | wall |
| cup | 1965 | 499 | 8 | 11 | floor |
| stencil | 1874 | 368 | 73 | 19 | wall |
| pipe | 2027 | 401 | 6 | 89 | wall |
| cable | 1779 | 368 | 234 | 5 | wall |
| drain | 1988 | 505 | 36 | 5 | floor |

### Cellules est

Support node-platform-f161-cell-b ; origine (2487, 510) ; largeur 266 ; hauteur 154 ; échelle 1. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| cell | 2487 | 378 | 73 | 132 | floor |
| bunk | 2581 | 407 | 111 | 103 | floor |
| basin | 2710 | 462 | 35 | 48 | floor |
| lamp | 2504 | 356 | 37 | 11 | ceiling |
| blanket | 2600 | 471 | 42 | 8 | wall |
| cup | 2685 | 499 | 8 | 11 | floor |
| stencil | 2594 | 368 | 73 | 19 | wall |
| pipe | 2747 | 401 | 6 | 89 | wall |
| cable | 2499 | 368 | 234 | 5 | wall |
| drain | 2708 | 505 | 36 | 5 | floor |

### Réfectoire

Support node-platform-f161-mess-high ; origine (2198, 350) ; largeur 244 ; hauteur 137 ; échelle 1. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| table | 2212 | 305 | 156 | 45 | floor |
| bench | 2202 | 326 | 65 | 24 | floor |
| bench | 2312 | 326 | 65 | 24 | floor |
| cup | 2244 | 296 | 8 | 10 | wall |
| cup | 2290 | 296 | 8 | 10 | wall |
| bowl | 2324 | 299 | 21 | 7 | wall |
| rack | 2388 | 241 | 53 | 109 | floor |
| lamp | 2246 | 215 | 78 | 12 | ceiling |
| stencil | 2389 | 213 | 53 | 17 | wall |
| cable | 2391 | 227 | 42 | 5 | wall |

### Lieu de recueillement

Support node-platform-f161-faith-dais-v94 ; origine (2067, 190) ; largeur 226 ; hauteur 133.89 ; échelle 0.95. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| altar | 2106.88 | 134.92 | 113.95 | 55.08 | floor |
| bench | 2067 | 166.26 | 54.13 | 23.74 | floor |
| bench | 2238.87 | 166.26 | 54.13 | 23.74 | floor |
| candle | 2138.22 | 111.18 | 5.7 | 23.74 | wall |
| candle | 2198.99 | 114.98 | 5.7 | 19.94 | wall |
| book | 2168.61 | 125.43 | 22.79 | 7.6 | wall |
| lamp | 2155.31 | 56.11 | 22.79 | 10.45 | ceiling |
| stencil | 2108.78 | 76.05 | 112.05 | 20.89 | wall |

### Poste de communication

Support node-platform-f161-comms-high ; origine (2642, 350) ; largeur 156 ; hauteur 96.24 ; échelle 0.63. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| console | 2644.52 | 302.19 | 84.29 | 47.81 | floor |
| rack | 2756.48 | 266.34 | 41.52 | 83.66 | floor |
| monitor | 2652.06 | 272.63 | 32.71 | 23.9 | wall |
| monitor | 2691.69 | 272.63 | 32.71 | 23.9 | wall |
| spool | 2736.98 | 331.76 | 18.24 | 18.24 | floor |
| junction | 2733.21 | 281.44 | 16.98 | 18.24 | wall |
| cable | 2721.26 | 297.79 | 39.63 | 5.03 | wall |
| lamp | 2652.69 | 255.65 | 28.31 | 6.29 | ceiling |
| stencil | 2757.11 | 253.76 | 40.89 | 9.44 | wall |
| stool | 2683.52 | 329.87 | 15.1 | 20.13 | floor |

### Ventilateur de maintenance

Support node-platform-f161-fan-shaft ; origine (2887, 330) ; largeur 106 ; hauteur 61.39 ; échelle 0.41. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| fan | 2890.27 | 277.61 | 47.47 | 47.47 | wall |
| duct | 2937.75 | 292.76 | 52.8 | 23.33 | wall |
| junction | 2969.26 | 275.16 | 13.92 | 12.69 | wall |
| gauge | 2951.66 | 279.66 | 8.59 | 8.59 | wall |
| valve | 2943.48 | 318.95 | 11.05 | 11.05 | wall |
| pipe | 2891.09 | 324.68 | 101.91 | 3.68 | wall |
| drain | 2894.37 | 327.95 | 38.47 | 2.05 | floor |
| lamp | 2899.69 | 268.61 | 18.42 | 4.09 | ceiling |
| grille | 2967.63 | 319.77 | 21.69 | 8.59 | wall |
| cable | 2983.18 | 274.75 | 2.86 | 15.55 | wall |

### Pompage des galeries

Support node-platform-f161-service-low ; origine (2957.5, 510) ; largeur 225 ; hauteur 150 ; échelle 1. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| pump | 2985.5 | 430 | 83 | 80 | floor |
| tank | 3122.5 | 384 | 60 | 126 | floor |
| valve | 3086.5 | 471 | 27 | 27 | wall |
| gauge | 3003.5 | 402 | 24 | 24 | wall |
| pipe | 3056.5 | 481 | 84 | 10 | wall |
| pipe | 3135.5 | 384 | 8 | 19 | wall |
| junction | 2966.5 | 448 | 23 | 25 | wall |
| drain | 2960.5 | 505 | 116 | 5 | floor |
| lamp | 3056.5 | 360 | 37 | 10 | ceiling |
| stencil | 2978.5 | 371 | 72 | 18 | wall |

### Entretien des réseaux

Support node-platform-f161-service-high ; origine (3017, 330) ; largeur 106 ; hauteur 64.58 ; échelle 0.45. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| bench | 3018.78 | 306.84 | 57.9 | 23.16 | floor |
| rack | 3097.17 | 276.11 | 25.83 | 53.89 | floor |
| toolboard | 3024.57 | 280.56 | 47.66 | 22.71 | wall |
| case | 3082.47 | 314.86 | 15.14 | 15.14 | floor |
| lamp | 3029.92 | 268.09 | 35.18 | 4.9 | ceiling |
| junction | 3082.92 | 282.79 | 12.03 | 14.7 | wall |
| spool | 3101.18 | 309.51 | 13.36 | 13.36 | wall |
| pipe | 3021.45 | 272.99 | 96.2 | 2.67 | wall |
| stencil | 3082.03 | 265.42 | 35.63 | 7.57 | wall |
| tray | 3045.5 | 301.05 | 14.25 | 4.45 | wall |

### Alcôve des galeries

Support node-platform-f161-tunnel-shrine ; origine (3327, 630) ; largeur 186 ; hauteur 110.19 ; échelle 0.78. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| altar | 3359.82 | 584.67 | 93.78 | 45.33 | floor |
| bench | 3327 | 610.46 | 44.55 | 19.54 | floor |
| bench | 3468.45 | 610.46 | 44.55 | 19.54 | floor |
| candle | 3385.61 | 565.13 | 4.69 | 19.54 | wall |
| candle | 3435.63 | 568.26 | 4.69 | 16.41 | wall |
| book | 3410.62 | 576.86 | 18.76 | 6.25 | wall |
| lamp | 3399.68 | 519.81 | 18.76 | 8.6 | ceiling |
| stencil | 3361.39 | 536.22 | 92.22 | 17.19 | wall |

### Recharge des batteries

Support node-platform-f161-battery-locker-v94 ; origine (3387, 330) ; largeur 226 ; hauteur 137.69 ; échelle 0.95. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| bench | 3390.8 | 280.62 | 123.45 | 49.38 | floor |
| rack | 3557.92 | 215.1 | 55.08 | 114.9 | floor |
| toolboard | 3403.14 | 224.6 | 101.61 | 48.43 | wall |
| case | 3526.59 | 297.71 | 32.29 | 32.29 | floor |
| lamp | 3414.54 | 198.01 | 75.02 | 10.45 | ceiling |
| junction | 3527.54 | 229.34 | 25.64 | 31.34 | wall |
| spool | 3566.47 | 286.32 | 28.49 | 28.49 | wall |
| pipe | 3396.5 | 208.45 | 205.11 | 5.7 | wall |
| stencil | 3525.64 | 192.31 | 75.97 | 16.14 | wall |
| tray | 3447.77 | 268.28 | 30.39 | 9.5 | wall |

### Réserve de produits

Support node-platform-f161-chemical-store ; origine (3577, 510) ; largeur 186 ; hauteur 106.08 ; échelle 0.71. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| rack | 3577 | 423.01 | 53.04 | 86.99 | floor |
| barrel | 3650.55 | 460.49 | 27.58 | 49.51 | floor |
| barrel | 3687.33 | 460.49 | 27.58 | 49.51 | floor |
| case | 3727.64 | 485.95 | 30.41 | 24.05 | floor |
| lamp | 3644.89 | 403.92 | 31.12 | 7.07 | ceiling |
| grille | 3657.62 | 421.6 | 57.29 | 22.63 | wall |
| valve | 3747.44 | 445.64 | 15.56 | 15.56 | wall |
| pipe | 3627.21 | 437.86 | 30.41 | 4.95 | wall |
| stencil | 3583.37 | 405.33 | 47.38 | 11.32 | wall |
| drain | 3644.89 | 506.46 | 79.21 | 3.54 | floor |

### Supervision de la fonderie

Support node-platform-f161-command-post-node ; origine (3882, 510) ; largeur 156 ; hauteur 96.24 ; échelle 0.63. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| console | 3884.52 | 462.19 | 84.29 | 47.81 | floor |
| rack | 3996.48 | 426.34 | 41.52 | 83.66 | floor |
| monitor | 3892.06 | 432.63 | 32.71 | 23.9 | wall |
| monitor | 3931.69 | 432.63 | 32.71 | 23.9 | wall |
| spool | 3976.98 | 491.76 | 18.24 | 18.24 | floor |
| junction | 3973.21 | 441.44 | 16.98 | 18.24 | wall |
| cable | 3961.26 | 457.79 | 39.63 | 5.03 | wall |
| lamp | 3892.69 | 415.65 | 28.31 | 6.29 | ceiling |
| stencil | 3997.11 | 413.76 | 40.89 | 9.44 | wall |
| stool | 3923.52 | 489.87 | 15.1 | 20.13 | floor |

### Collecte des effluents

Support node-platform-f161-waste-tank ; origine (3957.5, 630) ; largeur 225 ; hauteur 150 ; échelle 1. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| pump | 3985.5 | 550 | 83 | 80 | floor |
| tank | 4122.5 | 504 | 60 | 126 | floor |
| valve | 4086.5 | 591 | 27 | 27 | wall |
| gauge | 4003.5 | 522 | 24 | 24 | wall |
| pipe | 4056.5 | 601 | 84 | 10 | wall |
| pipe | 4135.5 | 504 | 8 | 19 | wall |
| junction | 3966.5 | 568 | 23 | 25 | wall |
| drain | 3960.5 | 625 | 116 | 5 | floor |
| lamp | 4056.5 | 480 | 37 | 10 | ceiling |
| stencil | 3978.5 | 491 | 72 | 18 | wall |

### Creuset et transfert

Support node-platform-f161-leadworks ; origine (4122, 510) ; largeur 156 ; hauteur 118.09 ; échelle 0.62. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| crucible | 4151.83 | 424.85 | 72.1 | 85.15 | floor |
| gantry | 4127.59 | 406.21 | 133.63 | 103.79 | floor |
| hoist | 4174.83 | 414.29 | 29.83 | 40.4 | ceiling |
| ladle | 4242.57 | 441.63 | 35.43 | 68.37 | floor |
| gauge | 4128.22 | 475.2 | 14.29 | 14.29 | wall |
| pipe | 4127.59 | 489.49 | 26.1 | 6.22 | wall |
| slag | 4240.09 | 490.11 | 25.48 | 19.89 | floor |
| lamp | 4241.95 | 391.91 | 19.89 | 7.46 | ceiling |
| stencil | 4150.59 | 397.51 | 49.72 | 11.19 | wall |
| grille | 4194.1 | 505.65 | 26.1 | 4.35 | floor |

### Alimentation du creuset

Support node-platform-f161-lead-primer ; origine (4302, 510) ; largeur 156 ; hauteur 104 ; échelle 0.69. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| pump | 4321.41 | 454.53 | 57.55 | 55.47 | floor |
| tank | 4416.4 | 422.64 | 41.6 | 87.36 | floor |
| valve | 4391.44 | 482.96 | 18.72 | 18.72 | wall |
| gauge | 4333.89 | 435.12 | 16.64 | 16.64 | wall |
| pipe | 4370.64 | 489.89 | 58.24 | 6.93 | wall |
| pipe | 4425.41 | 422.64 | 5.55 | 13.17 | wall |
| junction | 4308.24 | 467.01 | 15.95 | 17.33 | wall |
| drain | 4304.08 | 506.53 | 80.43 | 3.47 | floor |
| lamp | 4370.64 | 406 | 25.65 | 6.93 | ceiling |
| stencil | 4316.56 | 413.63 | 49.92 | 12.48 | wall |

### Collecteur d’eau supérieur

Support node-platform-f161-sprinkler ; origine (4447.5, 330) ; largeur 225 ; hauteur 150 ; échelle 1. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| pump | 4475.5 | 250 | 83 | 80 | floor |
| tank | 4612.5 | 204 | 60 | 126 | floor |
| valve | 4576.5 | 291 | 27 | 27 | wall |
| gauge | 4493.5 | 222 | 24 | 24 | wall |
| pipe | 4546.5 | 301 | 84 | 10 | wall |
| pipe | 4625.5 | 204 | 8 | 19 | wall |
| junction | 4456.5 | 268 | 23 | 25 | wall |
| drain | 4450.5 | 325 | 116 | 5 | floor |
| lamp | 4546.5 | 180 | 37 | 10 | ceiling |
| stencil | 4468.5 | 191 | 72 | 18 | wall |

### Pistons supérieurs

Support node-platform-f161-piston-b-node ; origine (4742, 330) ; largeur 156 ; hauteur 97.05 ; échelle 0.6. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| piston | 4750.34 | 258.55 | 34.53 | 71.45 | floor |
| piston | 4806.9 | 258.55 | 34.53 | 71.45 | floor |
| piston | 4863.47 | 258.55 | 34.53 | 71.45 | floor |
| pipe | 4747.36 | 247.83 | 149.45 | 6.55 | wall |
| gauge | 4848.58 | 288.32 | 13.69 | 13.69 | wall |
| valve | 4787.25 | 298.44 | 14.29 | 14.29 | wall |
| junction | 4789.63 | 265.69 | 13.69 | 16.67 | wall |
| lamp | 4810.47 | 235.33 | 25.01 | 6.55 | ceiling |
| stencil | 4749.15 | 232.95 | 44.66 | 10.72 | wall |
| drain | 4787.85 | 327.02 | 75.02 | 2.98 | floor |

### Moule de coulée

Support node-platform-f161-mold ; origine (4783.5, 510) ; largeur 273 ; hauteur 143 ; échelle 1. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| mold | 4787.5 | 468 | 231 | 42 | floor |
| pipe | 4807.5 | 414 | 195 | 9 | wall |
| valve | 4997.5 | 414 | 26 | 26 | wall |
| gauge | 4793.5 | 421 | 23 | 23 | wall |
| lamp | 4840.5 | 367 | 105 | 12 | ceiling |
| grille | 4787.5 | 501 | 229 | 9 | floor |
| stencil | 4861.5 | 391 | 91 | 20 | wall |
| junction | 5032.5 | 439 | 24 | 37 | wall |

### Retour hydraulique

Support node-platform-f161-pressure-alcove-v95 ; origine (4682, 630) ; largeur 196 ; hauteur 130.67 ; échelle 0.87. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| pump | 4706.39 | 560.31 | 72.3 | 69.69 | floor |
| tank | 4825.73 | 520.24 | 52.27 | 109.76 | floor |
| valve | 4794.37 | 596.03 | 23.52 | 23.52 | wall |
| gauge | 4722.07 | 535.92 | 20.91 | 20.91 | wall |
| pipe | 4768.24 | 604.74 | 73.17 | 8.71 | wall |
| pipe | 4837.06 | 520.24 | 6.97 | 16.55 | wall |
| junction | 4689.84 | 575.99 | 20.04 | 21.78 | wall |
| drain | 4684.61 | 625.64 | 101.05 | 4.36 | floor |
| lamp | 4768.24 | 499.33 | 32.23 | 8.71 | ceiling |
| stencil | 4700.29 | 508.92 | 62.72 | 15.68 | wall |

### Four principal

Support node-platform-f161-furnace ; origine (5402, 510) ; largeur 156 ; hauteur 110.29 ; échelle 0.57. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| furnace | 5414.57 | 406 | 101.71 | 104 | floor |
| pipe | 5524.86 | 437.43 | 8 | 65.71 | wall |
| gauge | 5522.57 | 454 | 14.29 | 14.29 | wall |
| slag | 5538 | 490 | 20 | 20 | floor |
| lamp | 5408.86 | 399.71 | 20.57 | 6.29 | ceiling |
| stencil | 5526.57 | 418.57 | 27.43 | 10.86 | wall |
| grille | 5412.29 | 503.14 | 105.71 | 6.86 | floor |
| junction | 5539.71 | 459.14 | 13.14 | 20.57 | wall |

### Commande de passerelle

Support node-platform-f161-furnace-high ; origine (5232.5, 330) ; largeur 235 ; hauteur 154 ; échelle 1. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| winch | 5270.5 | 262 | 80 | 68 | floor |
| junction | 5381.5 | 231 | 36 | 51 | wall |
| pipe | 5255.5 | 214 | 210 | 9 | wall |
| valve | 5441.5 | 215 | 26 | 26 | wall |
| lamp | 5371.5 | 176 | 38 | 11 | ceiling |
| grille | 5256.5 | 322 | 139 | 8 | floor |
| stencil | 5258.5 | 180 | 74 | 19 | wall |
| support | 5355.5 | 306 | 12 | 24 | floor |

### Approche de la Compagnie

Support node-platform-f161-parley-v93 ; origine (5582, 510) ; largeur 156 ; hauteur 102.23 ; échelle 0.66. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| winch | 5607.23 | 464.86 | 53.11 | 45.14 | floor |
| junction | 5680.91 | 444.28 | 23.9 | 33.86 | wall |
| pipe | 5597.27 | 433 | 139.4 | 5.97 | wall |
| valve | 5720.74 | 433.66 | 17.26 | 17.26 | wall |
| lamp | 5674.27 | 407.77 | 25.23 | 7.3 | ceiling |
| grille | 5597.93 | 504.69 | 92.27 | 5.31 | floor |
| stencil | 5599.26 | 410.43 | 49.12 | 12.61 | wall |
| support | 5663.65 | 494.07 | 7.97 | 15.93 | floor |

### Matériel de récupération

Support node-platform-f161-patna-cage-node ; origine (5887, 510) ; largeur 86 ; hauteur 42.85 ; échelle 0.31. Plan arrière non collidable ; condition company.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| recovery | 5893.16 | 467.15 | 39.76 | 42.85 | floor |
| case | 5939.4 | 497.98 | 20.65 | 12.02 | floor |
| lampstand | 5964.68 | 467.15 | 8.32 | 42.85 | floor |
| monitor | 5941.25 | 486.27 | 13.25 | 9.25 | wall |
| cable | 5930.15 | 505.99 | 14.8 | 2.47 | wall |
| stencil | 5939.09 | 475.78 | 23.43 | 6.16 | wall |
| case | 5887.31 | 499.83 | 10.79 | 10.17 | floor |
| clamp | 5908.89 | 485.65 | 8.01 | 8.32 | wall |

### Plateforme terminale

Support node-platform-f161-extraction ; origine (5997, 510) ; largeur 86 ; hauteur 56.36 ; échelle 0.37. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| winch | 6010.91 | 485.11 | 29.28 | 24.89 | floor |
| junction | 6051.53 | 473.77 | 13.17 | 18.66 | wall |
| pipe | 6005.42 | 467.55 | 76.85 | 3.29 | wall |
| valve | 6073.49 | 467.91 | 9.51 | 9.51 | wall |
| lamp | 6047.87 | 453.64 | 13.91 | 4.03 | ceiling |
| grille | 6005.78 | 507.07 | 50.87 | 2.93 | floor |
| stencil | 6006.51 | 455.11 | 27.08 | 6.95 | wall |
| support | 6042.01 | 501.22 | 4.39 | 8.78 | floor |

### Émetteur de service

Support node-platform-f161-final-transmission-v94 ; origine (6017, 330) ; largeur 166 ; hauteur 102.41 ; échelle 0.67. Plan arrière non collidable ; condition always.

| Forme | X | Y | Largeur | Hauteur | Pose |
|---|---:|---:|---:|---:|---|
| console | 6019.68 | 279.13 | 89.69 | 50.87 | floor |
| rack | 6138.82 | 240.98 | 44.18 | 89.02 | floor |
| monitor | 6027.71 | 247.67 | 34.81 | 25.44 | wall |
| monitor | 6069.88 | 247.67 | 34.81 | 25.44 | wall |
| spool | 6118.07 | 310.59 | 19.41 | 19.41 | floor |
| junction | 6114.06 | 257.04 | 18.07 | 19.41 | wall |
| cable | 6101.34 | 274.44 | 42.17 | 5.35 | wall |
| lamp | 6028.38 | 229.6 | 30.12 | 6.69 | ceiling |
| stencil | 6139.49 | 227.59 | 43.51 | 10.04 | wall |
| stool | 6061.18 | 308.58 | 16.06 | 21.42 | floor |

## Réseaux locaux

Chaque réseau relie un boîtier, une console ou un support électrique à un luminaire du même ensemble. Le trajet comprend quatre points et trois segments continus. Ces câbles sont décoratifs, sans collision. Ils ne représentent pas des conduites de métal ou d’eau.

### coast-intake-lighting-run

electrical ; ensemble coast-intake. Source coast-intake/2 (junction) ; récepteur coast-intake/6 (lamp). Condition always. Aucun transfert d’énergie calculé.

(249.5, 489) → (249.5, 359) → (147.5, 359) → (147.5, 370.5)

### coast-wreck-lighting-run

electrical ; ensemble coast-wreck. Source coast-wreck/5 (junction) ; récepteur coast-wreck/4 (lamp). Condition always. Aucun transfert d’énergie calculé.

(741.5, 483) → (741.5, 347) → (586, 347) → (586, 358.5)

### morgue-bay-lighting-run

electrical ; ensemble morgue-bay. Source morgue-bay/6 (junction) ; récepteur morgue-bay/3 (lamp). Condition always. Aucun transfert d’énergie calculé.

(1599.6, 267.44) → (1599.6, 233.73) → (1502.24, 233.73) → (1502.24, 244.11)

### mess-lighting-run

electrical ; ensemble mess. Source mess/6 (rack) ; récepteur mess/7 (lamp). Condition always. Aucun transfert d’énergie calculé.

(2414.5, 295.5) → (2414.5, 210) → (2285, 210) → (2285, 221)

### actual-comms-lighting-run

electrical ; ensemble actual-comms. Source actual-comms/5 (junction) ; récepteur actual-comms/7 (lamp). Condition always. Aucun transfert d’énergie calculé.

(2741.7, 290.56) → (2741.7, 250.65) → (2666.85, 250.65) → (2666.85, 258.79)

### murphy-fan-lighting-run

electrical ; ensemble murphy-fan. Source murphy-fan/2 (junction) ; récepteur murphy-fan/7 (lamp). Condition always. Aucun transfert d’énergie calculé.

(2976.22, 281.5) → (2976.22, 263.61) → (2908.9, 263.61) → (2908.9, 270.66)

### service-pump-lighting-run

electrical ; ensemble service-pump. Source service-pump/6 (junction) ; récepteur service-pump/8 (lamp). Condition always. Aucun transfert d’énergie calculé.

(2978, 460.5) → (2978, 355) → (3075, 355) → (3075, 365)

### service-shop-lighting-run

electrical ; ensemble service-shop. Source service-shop/5 (junction) ; récepteur service-shop/4 (lamp). Condition always. Aucun transfert d’énergie calculé.

(3088.93, 290.14) → (3088.93, 263.09) → (3047.51, 263.09) → (3047.51, 270.54)

### battery-store-lighting-run

electrical ; ensemble battery-store. Source battery-store/5 (junction) ; récepteur battery-store/4 (lamp). Condition always. Aucun transfert d’énergie calculé.

(3540.36, 245.01) → (3540.36, 193.01) → (3452.05, 193.01) → (3452.05, 203.23)

### chemical-store-lighting-run

electrical ; ensemble chemical-store. Source chemical-store/0 (rack) ; récepteur chemical-store/4 (lamp). Condition always. Aucun transfert d’énergie calculé.

(3603.52, 466.51) → (3603.52, 398.92) → (3660.45, 398.92) → (3660.45, 407.45)

### command-lighting-run

electrical ; ensemble command. Source command/5 (junction) ; récepteur command/7 (lamp). Condition always. Aucun transfert d’énergie calculé.

(3981.7, 450.56) → (3981.7, 410.65) → (3906.85, 410.65) → (3906.85, 418.79)

### waste-lighting-run

electrical ; ensemble waste. Source waste/6 (junction) ; récepteur waste/8 (lamp). Condition always. Aucun transfert d’énergie calculé.

(3978, 580.5) → (3978, 475) → (4075, 475) → (4075, 485)

### lead-primer-lighting-run

electrical ; ensemble lead-primer. Source lead-primer/6 (junction) ; récepteur lead-primer/8 (lamp). Condition always. Aucun transfert d’énergie calculé.

(4316.21, 475.68) → (4316.21, 401) → (4383.47, 401) → (4383.47, 409.47)

### water-header-lighting-run

electrical ; ensemble water-header. Source water-header/6 (junction) ; récepteur water-header/8 (lamp). Condition always. Aucun transfert d’énergie calculé.

(4468, 280.5) → (4468, 175) → (4565, 175) → (4565, 185)

### piston-upper-lighting-run

electrical ; ensemble piston-upper. Source piston-upper/6 (junction) ; récepteur piston-upper/7 (lamp). Condition always. Aucun transfert d’énergie calculé.

(4796.48, 274.03) → (4796.48, 230.33) → (4822.98, 230.33) → (4822.98, 238.6)

### mold-lighting-run

electrical ; ensemble mold. Source mold/7 (junction) ; récepteur mold/4 (lamp). Condition always. Aucun transfert d’énergie calculé.

(5044.5, 457.5) → (5044.5, 362) → (4893, 362) → (4893, 373)

### lower-pressure-lighting-run

electrical ; ensemble lower-pressure. Source lower-pressure/6 (junction) ; récepteur lower-pressure/8 (lamp). Condition always. Aucun transfert d’énergie calculé.

(4699.86, 586.88) → (4699.86, 494.33) → (4784.36, 494.33) → (4784.36, 503.69)

### main-furnace-lighting-run

electrical ; ensemble main-furnace. Source main-furnace/7 (junction) ; récepteur main-furnace/4 (lamp). Condition always. Aucun transfert d’énergie calculé.

(5546.29, 469.43) → (5546.29, 394.71) → (5419.14, 394.71) → (5419.14, 402.86)

### furnace-gantry-lighting-run

electrical ; ensemble furnace-gantry. Source furnace-gantry/1 (junction) ; récepteur furnace-gantry/4 (lamp). Condition always. Aucun transfert d’énergie calculé.

(5399.5, 256.5) → (5399.5, 171) → (5390.5, 171) → (5390.5, 181.5)

### parley-lighting-run

electrical ; ensemble parley. Source parley/1 (junction) ; récepteur parley/4 (lamp). Condition always. Aucun transfert d’énergie calculé.

(5692.86, 461.21) → (5692.86, 402.77) → (5686.89, 402.77) → (5686.89, 411.42)

### final-landing-lighting-run

electrical ; ensemble final-landing. Source final-landing/1 (junction) ; récepteur final-landing/4 (lamp). Condition always. Aucun transfert d’énergie calculé.

(6058.11, 483.1) → (6058.11, 448.64) → (6054.82, 448.64) → (6054.82, 455.66)

### final-transmitter-lighting-run

electrical ; ensemble final-transmitter. Source final-transmitter/5 (junction) ; récepteur final-transmitter/7 (lamp). Condition always. Aucun transfert d’énergie calculé.

(6123.09, 266.75) → (6123.09, 224.6) → (6043.44, 224.6) → (6043.44, 232.94)

## Commandes physiques

Touche I. L’action ne remplace pas E et ne peut pas consommer une interaction de quête. La cible doit être vivante, non occupée, au plan médian, à moins de 82 unités horizontalement et à moins de 24 unités du même sol. Une porte fermée ou insuffisamment ouverte entre personnage et interrupteur bloque l’action. Le plan, les archives, la pause et la fin de mission refusent également la commande. Temporisation de 0,22 seconde.

### Éclairage de la prise d’air

Éclairage de la prise d’air ; support node-platform-f161-spawn ; panneau (259.5, 456), taille 13 × 29, sol 510. État initial allumé. Identifiant sauvegardé : shore-light.

Récepteurs : coast-intake/6

### Lampe de soin

Lampe de soin ; support node-platform-f161-infirmary ; panneau (1225, 456), taille 13 × 29, sol 510. État initial allumé. Identifiant sauvegardé : care-light.

Récepteurs : medical-care/7

### Éclairage de la coursive

Éclairage de la coursive ; support node-platform-f161-cell-a ; panneau (2020, 456), taille 13 × 29, sol 510. État initial allumé. Identifiant sauvegardé : cell-light.

Récepteurs : cell-a/3

### Lampe des communications

Lampe des communications ; support node-platform-f161-comms-high ; panneau (2785, 296), taille 13 × 29, sol 350. État initial allumé. Identifiant sauvegardé : comms-light.

Récepteurs : actual-comms/7

### Lampe de l’établi

Lampe de l’établi ; support node-platform-f161-service-high ; panneau (3110, 276), taille 13 × 29, sol 330. État initial allumé. Identifiant sauvegardé : service-light.

Récepteurs : service-shop/4

### Éclairage du creuset

Éclairage du creuset ; support node-platform-f161-leadworks ; panneau (4265, 456), taille 13 × 29, sol 510. État initial allumé. Identifiant sauvegardé : lead-light.

Récepteurs : leadworks/7

### Lampe du moule

Lampe du moule ; support node-platform-f161-mold ; panneau (5043.5, 456), taille 13 × 29, sol 510. État initial allumé. Identifiant sauvegardé : mold-light.

Récepteurs : mold/4

### Éclairage de la plateforme

Éclairage de la plateforme ; support node-platform-f161-extraction ; panneau (6070, 456), taille 13 × 29, sol 510. État initial allumé. Identifiant sauvegardé : landing-light.

Récepteurs : final-landing/4

## Portes natives

La V103 change le dessin du cadre et de la feuille, pas le verrouillage. La hauteur visible de la feuille suit progress de 0 à 1. Dans le jeu principal, le contrôleur natif continue de décider quand la porte peut s’ouvrir. Les essais de franchissement du banc utilisent son contrôleur simplifié.

### f161-infirmary-gate

Accès aux cellules ; f161-infirmary ↔ f161-cell-a, connexion f161-e03. Coordonnées par défaut : X 1488, Y 378, L 44, H 132. Un plan compilé fourni remplace ces valeurs par les positions natives exactes.

### f161-cellblock-gate

Galeries de service ; f161-cell-b ↔ f161-service-low, connexion f161-e05. Coordonnées par défaut : X 2823, Y 378, L 44, H 132. Un plan compilé fourni remplace ces valeurs par les positions natives exactes.

### f161-leadworks-gate

Accès à la fonderie ; f161-bishop ↔ f161-leadworks, connexion f161-e07. Coordonnées par défaut : X 3828, Y 378, L 44, H 132. Un plan compilé fourni remplace ces valeurs par les positions natives exactes.

## Points du graphe

Les points ci-dessous sont conservés. Un point n’équivaut pas à une pièce complète.

### f161-spawn

Point (180, 510) ; largeur de support 260 ; zone f161-coast.
- f161-e01 : f161-eev / walk

### f161-eev

Point (620, 510) ; largeur de support 300 ; zone f161-coast.
- f161-e01 : f161-spawn / walk
- f161-e02 : f161-infirmary / walk
- f161-e89 : f161-flight-analysis-v94 / ladder
- f161-e91 : f161-wreckage-incident-v94 / ladder

### f161-infirmary

Point (1120, 510) ; largeur de support 300 ; zone f161-infirmary.
- f161-e02 : f161-eev / walk
- f161-e03 : f161-cell-a / gate
- f161-e12 : f161-morgue-high / ladder
- f161-e19 : f161-service-deep / vent
- f161-e46 : f161-clemens-bed / walk
- f161-e92 : f161-wreckage-incident-v94 / ladder

### f161-morgue-high

Point (1500, 350) ; largeur de support 260 ; zone f161-infirmary.
- f161-e12 : f161-infirmary / ladder
- f161-e13 : f161-mess-high / walk
- f161-e48 : f161-funeral-walk / ladder
- f161-e62 : f161-master-archive-node / walk
- f161-e90 : f161-flight-analysis-v94 / walk

### f161-cell-a

Point (1900, 510) ; largeur de support 300 ; zone f161-cellblock.
- f161-e03 : f161-infirmary / gate
- f161-e23 : f161-mess-high / ladder
- f161-e27 : f161-assembly-hall / walk
- f161-e104 : f161-shelter-cell-v95 / ladder

### f161-mess-high

Point (2320, 350) ; largeur de support 280 ; zone f161-cellblock.
- f161-e13 : f161-morgue-high / walk
- f161-e14 : f161-service-high / walk
- f161-e23 : f161-cell-a / ladder
- f161-e29 : f161-assembly-hall / ladder
- f161-e49 : f161-mess-ceiling / walk
- f161-e93 : f161-faith-dais-v94 / ladder

### f161-cell-b

Point (2620, 510) ; largeur de support 300 ; zone f161-cellblock.
- f161-e05 : f161-service-low / gate
- f161-e28 : f161-assembly-hall / walk
- f161-e63 : f161-shutter-cell-node / walk

### f161-service-low

Point (3070, 510) ; largeur de support 300 ; zone f161-service.
- f161-e05 : f161-cell-b / gate
- f161-e06 : f161-bishop / walk
- f161-e24 : f161-service-high / ladder
- f161-e25 : f161-service-deep / ladder
- f161-e35 : f161-fuel-manifold-a / walk
- f161-e67 : f161-rescue-post-node / walk

### f161-service-high

Point (3070, 330) ; largeur de support 280 ; zone f161-service.
- f161-e14 : f161-mess-high / walk
- f161-e15 : f161-tunnel-high / walk
- f161-e24 : f161-service-low / ladder
- f161-e51 : f161-fan-shaft / walk
- f161-e65 : f161-steam-service-node / walk
- f161-e80 : f161-perch-service-v93 / ladder
- f161-e95 : f161-battery-locker-v94 / walk
- f161-e110 : f161-hunt-service-v95 / walk

### f161-service-deep

Point (3070, 630) ; largeur de support 280 ; zone f161-service.
- f161-e19 : f161-infirmary / vent
- f161-e20 : f161-tunnel-low / walk
- f161-e25 : f161-service-low / ladder
- f161-e52 : f161-tunnel-shrine / walk
- f161-e108 : f161-refuge-service-v95 / walk

### f161-bishop

Point (3500, 510) ; largeur de support 300 ; zone f161-service.
- f161-e06 : f161-service-low / walk
- f161-e07 : f161-leadworks / gate
- f161-e37 : f161-fuel-manifold-b / walk
- f161-e38 : f161-chemical-store / walk
- f161-e53 : f161-tunnel-shrine / ladder
- f161-e68 : f161-rescue-post-node / walk
- f161-e69 : f161-shutter-service-node / walk

### f161-tunnel-high

Point (3820, 330) ; largeur de support 280 ; zone f161-leadworks.
- f161-e15 : f161-service-high / walk
- f161-e16 : f161-sprinkler / walk
- f161-e39 : f161-chemical-store / ladder
- f161-e71 : f161-command-post-node / ladder
- f161-e96 : f161-battery-locker-v94 / walk
- f161-e99 : f161-battery-junction-v94 / walk

### f161-tunnel-low

Point (3820, 630) ; largeur de support 280 ; zone f161-leadworks.
- f161-e20 : f161-service-deep / walk
- f161-e21 : f161-leadworks / ladder
- f161-e30 : f161-waste-tank / walk
- f161-e98 : f161-golic-cache-v94 / walk
- f161-e114 : f161-hunt-junction-v95 / walk

### f161-leadworks

Point (4200, 510) ; largeur de support 340 ; zone f161-leadworks.
- f161-e07 : f161-bishop / gate
- f161-e08 : f161-mold / walk
- f161-e21 : f161-tunnel-low / ladder
- f161-e22 : f161-furnace / vent
- f161-e26 : f161-sprinkler / ladder
- f161-e32 : f161-sluice-low / ladder
- f161-e40 : f161-lead-primer / walk
- f161-e54 : f161-piston-a-node / walk
- f161-e72 : f161-command-post-node / walk

### f161-sprinkler

Point (4560, 330) ; largeur de support 280 ; zone f161-leadworks.
- f161-e16 : f161-tunnel-high / walk
- f161-e17 : f161-furnace-high / walk
- f161-e26 : f161-leadworks / ladder
- f161-e42 : f161-water-header / walk
- f161-e56 : f161-piston-b-node / walk
- f161-e117 : f161-bait-switch-v95 / walk

### f161-mold

Point (4920, 510) ; largeur de support 360 ; zone f161-leadworks.
- f161-e08 : f161-leadworks / walk
- f161-e09 : f161-furnace / walk
- f161-e41 : f161-lead-primer / walk
- f161-e43 : f161-water-header / ladder
- f161-e55 : f161-piston-a-node / walk
- f161-e57 : f161-piston-b-node / ladder
- f161-e58 : f161-piston-c-node / walk
- f161-e75 : f161-shutter-foundry-node / walk
- f161-e101 : f161-chase-reroute-v94 / ladder

### f161-furnace-high

Point (5350, 330) ; largeur de support 280 ; zone f161-furnace.
- f161-e17 : f161-sprinkler / walk
- f161-e18 : f161-furnace / ladder
- f161-e33 : f161-furnace-gantry / walk
- f161-e44 : f161-furnace-overlook / walk
- f161-e119 : f161-chase-observer-v95 / walk

### f161-furnace

Point (5480, 510) ; largeur de support 340 ; zone f161-furnace.
- f161-e09 : f161-mold / walk
- f161-e10 : f161-company / walk
- f161-e18 : f161-furnace-high / ladder
- f161-e22 : f161-leadworks / vent
- f161-e59 : f161-piston-c-node / walk
- f161-e85 : f161-parley-v93 / walk
- f161-e102 : f161-chase-reroute-v94 / ladder

### f161-company

Point (5800, 510) ; largeur de support 300 ; zone f161-furnace.
- f161-e10 : f161-furnace / walk
- f161-e11 : f161-extraction / walk
- f161-e34 : f161-furnace-gantry / ladder
- f161-e45 : f161-furnace-overlook / ladder
- f161-e60 : f161-patna-cage-node / walk
- f161-e86 : f161-parley-v93 / walk
- f161-e87 : f161-witness-v93 / ladder

### f161-extraction

Point (6040, 510) ; largeur de support 300 ; zone f161-furnace.
- f161-e11 : f161-company / walk
- f161-e61 : f161-patna-cage-node / walk
- f161-e88 : f161-witness-v93 / ladder

### f161-assembly-hall

Point (2300, 510) ; largeur de support 300 ; zone f161-cellblock.
- f161-e27 : f161-cell-a / walk
- f161-e28 : f161-cell-b / walk
- f161-e29 : f161-mess-high / ladder
- f161-e105 : f161-shelter-cell-v95 / ladder

### f161-waste-tank

Point (4070, 630) ; largeur de support 310 ; zone f161-leadworks.
- f161-e30 : f161-tunnel-low / walk
- f161-e31 : f161-sluice-low / walk
- f161-e115 : f161-hunt-junction-v95 / walk

### f161-sluice-low

Point (4500, 630) ; largeur de support 280 ; zone f161-leadworks.
- f161-e31 : f161-waste-tank / walk
- f161-e32 : f161-leadworks / ladder

### f161-furnace-gantry

Point (5740, 330) ; largeur de support 280 ; zone f161-furnace.
- f161-e33 : f161-furnace-high / walk
- f161-e34 : f161-company / ladder

### f161-fuel-manifold-a

Point (2960, 510) ; largeur de support 180 ; zone f161-service.
- f161-e35 : f161-service-low / walk
- f161-e36 : f161-fuel-manifold-b / walk

### f161-fuel-manifold-b

Point (3240, 510) ; largeur de support 180 ; zone f161-service.
- f161-e36 : f161-fuel-manifold-a / walk
- f161-e37 : f161-bishop / walk

### f161-chemical-store

Point (3670, 510) ; largeur de support 210 ; zone f161-service.
- f161-e38 : f161-bishop / walk
- f161-e39 : f161-tunnel-high / ladder
- f161-e70 : f161-shutter-service-node / walk

### f161-lead-primer

Point (4380, 510) ; largeur de support 190 ; zone f161-leadworks.
- f161-e40 : f161-leadworks / walk
- f161-e41 : f161-mold / walk

### f161-water-header

Point (4690, 330) ; largeur de support 190 ; zone f161-leadworks.
- f161-e42 : f161-sprinkler / walk
- f161-e43 : f161-mold / ladder
- f161-e73 : f161-steam-lead-node / walk
- f161-e100 : f161-battery-junction-v94 / walk

### f161-furnace-overlook

Point (5580, 330) ; largeur de support 220 ; zone f161-furnace.
- f161-e44 : f161-furnace-high / walk
- f161-e45 : f161-company / ladder

### f161-clemens-bed

Point (1380, 510) ; largeur de support 180 ; zone f161-infirmary.
- f161-e46 : f161-infirmary / walk
- f161-e47 : f161-funeral-walk / walk

### f161-funeral-walk

Point (1580, 510) ; largeur de support 180 ; zone f161-infirmary.
- f161-e47 : f161-clemens-bed / walk
- f161-e48 : f161-morgue-high / ladder

### f161-mess-ceiling

Point (2470, 350) ; largeur de support 190 ; zone f161-cellblock.
- f161-e49 : f161-mess-high / walk
- f161-e50 : f161-comms-high / walk
- f161-e77 : f161-perch-cell-v93 / ladder

### f161-comms-high

Point (2720, 350) ; largeur de support 180 ; zone f161-cellblock.
- f161-e50 : f161-mess-ceiling / walk
- f161-e64 : f161-shutter-cell-node / ladder
- f161-e78 : f161-perch-cell-v93 / ladder
- f161-e107 : f161-watch-cell-v95 / ladder

### f161-fan-shaft

Point (2940, 330) ; largeur de support 170 ; zone f161-service.
- f161-e51 : f161-service-high / walk
- f161-e66 : f161-steam-service-node / walk

### f161-tunnel-shrine

Point (3420, 630) ; largeur de support 210 ; zone f161-service.
- f161-e52 : f161-service-deep / walk
- f161-e53 : f161-bishop / ladder
- f161-e97 : f161-golic-cache-v94 / walk
- f161-e109 : f161-refuge-service-v95 / walk

### f161-piston-a-node

Point (4480, 510) ; largeur de support 180 ; zone f161-leadworks.
- f161-e54 : f161-leadworks / walk
- f161-e55 : f161-mold / walk

### f161-piston-b-node

Point (4820, 330) ; largeur de support 180 ; zone f161-leadworks.
- f161-e56 : f161-sprinkler / walk
- f161-e57 : f161-mold / ladder
- f161-e74 : f161-steam-lead-node / walk
- f161-e84 : f161-perch-lead-v93 / ladder

### f161-piston-c-node

Point (5140, 510) ; largeur de support 180 ; zone f161-leadworks.
- f161-e58 : f161-mold / walk
- f161-e59 : f161-furnace / walk
- f161-e76 : f161-shutter-foundry-node / walk

### f161-patna-cage-node

Point (5930, 510) ; largeur de support 160 ; zone f161-furnace.
- f161-e60 : f161-company / walk
- f161-e61 : f161-extraction / walk

### f161-master-archive-node

Point (1260, 350) ; largeur de support 170 ; zone f161-infirmary.
- f161-e62 : f161-morgue-high / walk

### f161-shutter-cell-node

Point (2740, 510) ; largeur de support 160 ; zone f161-cellblock.
- f161-e63 : f161-cell-b / walk
- f161-e64 : f161-comms-high / ladder

### f161-steam-service-node

Point (3190, 330) ; largeur de support 160 ; zone f161-service.
- f161-e65 : f161-service-high / walk
- f161-e66 : f161-fan-shaft / walk
- f161-e79 : f161-perch-service-v93 / ladder

### f161-rescue-post-node

Point (3330, 510) ; largeur de support 170 ; zone f161-service.
- f161-e67 : f161-service-low / walk
- f161-e68 : f161-bishop / walk
- f161-e81 : f161-triage-v93 / walk

### f161-shutter-service-node

Point (3650, 510) ; largeur de support 160 ; zone f161-service.
- f161-e69 : f161-bishop / walk
- f161-e70 : f161-chemical-store / walk
- f161-e82 : f161-triage-v93 / walk
- f161-e113 : f161-triage-overflow-v95 / walk

### f161-command-post-node

Point (3960, 510) ; largeur de support 180 ; zone f161-leadworks.
- f161-e71 : f161-tunnel-high / ladder
- f161-e72 : f161-leadworks / walk

### f161-steam-lead-node

Point (4710, 330) ; largeur de support 160 ; zone f161-leadworks.
- f161-e73 : f161-water-header / walk
- f161-e74 : f161-piston-b-node / walk
- f161-e83 : f161-perch-lead-v93 / ladder

### f161-shutter-foundry-node

Point (5050, 510) ; largeur de support 160 ; zone f161-leadworks.
- f161-e75 : f161-mold / walk
- f161-e76 : f161-piston-c-node / walk

### f161-perch-cell-v93

Point (2500, 190) ; largeur de support 170 ; zone f161-cellblock.
- f161-e77 : f161-mess-ceiling / ladder
- f161-e78 : f161-comms-high / ladder
- f161-e94 : f161-faith-dais-v94 / walk
- f161-e106 : f161-watch-cell-v95 / walk

### f161-perch-service-v93

Point (3310, 190) ; largeur de support 170 ; zone f161-service.
- f161-e79 : f161-steam-service-node / ladder
- f161-e80 : f161-service-high / ladder

### f161-triage-v93

Point (3490, 510) ; largeur de support 190 ; zone f161-service.
- f161-e81 : f161-rescue-post-node / walk
- f161-e82 : f161-shutter-service-node / walk
- f161-e112 : f161-triage-overflow-v95 / walk

### f161-perch-lead-v93

Point (4720, 190) ; largeur de support 170 ; zone f161-leadworks.
- f161-e83 : f161-steam-lead-node / ladder
- f161-e84 : f161-piston-b-node / ladder

### f161-parley-v93

Point (5660, 510) ; largeur de support 180 ; zone f161-furnace.
- f161-e85 : f161-furnace / walk
- f161-e86 : f161-company / walk

### f161-witness-v93

Point (6030, 330) ; largeur de support 170 ; zone f161-furnace.
- f161-e87 : f161-company / ladder
- f161-e88 : f161-extraction / ladder
- f161-e103 : f161-final-transmission-v94 / walk
- f161-e120 : f161-archive-checksum-v95 / ladder

### f161-flight-analysis-v94

Point (780, 330) ; largeur de support 220 ; zone f161-coast.
- f161-e89 : f161-eev / ladder
- f161-e90 : f161-morgue-high / walk

### f161-wreckage-incident-v94

Point (820, 630) ; largeur de support 220 ; zone f161-coast.
- f161-e91 : f161-eev / ladder
- f161-e92 : f161-infirmary / ladder

### f161-faith-dais-v94

Point (2180, 190) ; largeur de support 250 ; zone f161-cellblock.
- f161-e93 : f161-mess-high / ladder
- f161-e94 : f161-perch-cell-v93 / walk

### f161-battery-locker-v94

Point (3500, 330) ; largeur de support 250 ; zone f161-service.
- f161-e95 : f161-service-high / walk
- f161-e96 : f161-tunnel-high / walk
- f161-e111 : f161-hunt-service-v95 / walk

### f161-golic-cache-v94

Point (3660, 630) ; largeur de support 230 ; zone f161-service.
- f161-e97 : f161-tunnel-shrine / walk
- f161-e98 : f161-tunnel-low / walk

### f161-battery-junction-v94

Point (4020, 330) ; largeur de support 250 ; zone f161-leadworks.
- f161-e99 : f161-tunnel-high / walk
- f161-e100 : f161-water-header / walk
- f161-e116 : f161-bait-switch-v95 / walk

### f161-chase-reroute-v94

Point (5050, 630) ; largeur de support 250 ; zone f161-leadworks.
- f161-e101 : f161-mold / ladder
- f161-e102 : f161-furnace / ladder
- f161-e118 : f161-pressure-alcove-v95 / walk

### f161-final-transmission-v94

Point (6100, 330) ; largeur de support 190 ; zone f161-furnace.
- f161-e103 : f161-witness-v93 / walk

### f161-shelter-cell-v95

Point (2050, 630) ; largeur de support 220 ; zone f161-cellblock.
- f161-e104 : f161-cell-a / ladder
- f161-e105 : f161-assembly-hall / ladder

### f161-watch-cell-v95

Point (2660, 190) ; largeur de support 190 ; zone f161-cellblock.
- f161-e106 : f161-perch-cell-v93 / walk
- f161-e107 : f161-comms-high / ladder

### f161-refuge-service-v95

Point (2990, 630) ; largeur de support 230 ; zone f161-service.
- f161-e108 : f161-service-deep / walk
- f161-e109 : f161-tunnel-shrine / walk

### f161-hunt-service-v95

Point (3370, 330) ; largeur de support 210 ; zone f161-service.
- f161-e110 : f161-service-high / walk
- f161-e111 : f161-battery-locker-v94 / walk

### f161-triage-overflow-v95

Point (3600, 510) ; largeur de support 220 ; zone f161-service.
- f161-e112 : f161-triage-v93 / walk
- f161-e113 : f161-shutter-service-node / walk

### f161-hunt-junction-v95

Point (3900, 630) ; largeur de support 210 ; zone f161-leadworks.
- f161-e114 : f161-tunnel-low / walk
- f161-e115 : f161-waste-tank / walk

### f161-bait-switch-v95

Point (4320, 330) ; largeur de support 210 ; zone f161-leadworks.
- f161-e116 : f161-battery-junction-v94 / walk
- f161-e117 : f161-sprinkler / walk

### f161-pressure-alcove-v95

Point (4780, 630) ; largeur de support 220 ; zone f161-leadworks.
- f161-e118 : f161-chase-reroute-v94 / walk

### f161-chase-observer-v95

Point (5280, 330) ; largeur de support 210 ; zone f161-furnace.
- f161-e119 : f161-furnace-high / walk

### f161-archive-checksum-v95

Point (5960, 190) ; largeur de support 190 ; zone f161-furnace.
- f161-e120 : f161-witness-v93 / ladder

## Registre des connexions

| Connexion | Origine | Destination | Type | ΔX | ΔY |
|---|---|---|---|---:|---:|
| f161-e01 | f161-spawn | f161-eev | walk | 440 | 0 |
| f161-e02 | f161-eev | f161-infirmary | walk | 500 | 0 |
| f161-e03 | f161-infirmary | f161-cell-a | gate | 780 | 0 |
| f161-e05 | f161-cell-b | f161-service-low | gate | 450 | 0 |
| f161-e06 | f161-service-low | f161-bishop | walk | 430 | 0 |
| f161-e07 | f161-bishop | f161-leadworks | gate | 700 | 0 |
| f161-e08 | f161-leadworks | f161-mold | walk | 720 | 0 |
| f161-e09 | f161-mold | f161-furnace | walk | 560 | 0 |
| f161-e10 | f161-furnace | f161-company | walk | 320 | 0 |
| f161-e11 | f161-company | f161-extraction | walk | 240 | 0 |
| f161-e12 | f161-infirmary | f161-morgue-high | ladder | 380 | -160 |
| f161-e13 | f161-morgue-high | f161-mess-high | walk | 820 | 0 |
| f161-e14 | f161-mess-high | f161-service-high | walk | 750 | -20 |
| f161-e15 | f161-service-high | f161-tunnel-high | walk | 750 | 0 |
| f161-e16 | f161-tunnel-high | f161-sprinkler | walk | 740 | 0 |
| f161-e17 | f161-sprinkler | f161-furnace-high | walk | 790 | 0 |
| f161-e18 | f161-furnace-high | f161-furnace | ladder | 130 | 180 |
| f161-e19 | f161-infirmary | f161-service-deep | vent | 1950 | 120 |
| f161-e20 | f161-service-deep | f161-tunnel-low | walk | 750 | 0 |
| f161-e21 | f161-tunnel-low | f161-leadworks | ladder | 380 | -120 |
| f161-e22 | f161-leadworks | f161-furnace | vent | 1280 | 0 |
| f161-e23 | f161-cell-a | f161-mess-high | ladder | 420 | -160 |
| f161-e24 | f161-service-low | f161-service-high | ladder | 0 | -180 |
| f161-e25 | f161-service-low | f161-service-deep | ladder | 0 | 120 |
| f161-e26 | f161-leadworks | f161-sprinkler | ladder | 360 | -180 |
| f161-e27 | f161-cell-a | f161-assembly-hall | walk | 400 | 0 |
| f161-e28 | f161-assembly-hall | f161-cell-b | walk | 320 | 0 |
| f161-e29 | f161-assembly-hall | f161-mess-high | ladder | 20 | -160 |
| f161-e30 | f161-tunnel-low | f161-waste-tank | walk | 250 | 0 |
| f161-e31 | f161-waste-tank | f161-sluice-low | walk | 430 | 0 |
| f161-e32 | f161-sluice-low | f161-leadworks | ladder | -300 | -120 |
| f161-e33 | f161-furnace-high | f161-furnace-gantry | walk | 390 | 0 |
| f161-e34 | f161-furnace-gantry | f161-company | ladder | 60 | 180 |
| f161-e35 | f161-service-low | f161-fuel-manifold-a | walk | -110 | 0 |
| f161-e36 | f161-fuel-manifold-a | f161-fuel-manifold-b | walk | 280 | 0 |
| f161-e37 | f161-fuel-manifold-b | f161-bishop | walk | 260 | 0 |
| f161-e38 | f161-bishop | f161-chemical-store | walk | 170 | 0 |
| f161-e39 | f161-chemical-store | f161-tunnel-high | ladder | 150 | -180 |
| f161-e40 | f161-leadworks | f161-lead-primer | walk | 180 | 0 |
| f161-e41 | f161-lead-primer | f161-mold | walk | 540 | 0 |
| f161-e42 | f161-sprinkler | f161-water-header | walk | 130 | 0 |
| f161-e43 | f161-water-header | f161-mold | ladder | 230 | 180 |
| f161-e44 | f161-furnace-high | f161-furnace-overlook | walk | 230 | 0 |
| f161-e45 | f161-furnace-overlook | f161-company | ladder | 220 | 180 |
| f161-e46 | f161-infirmary | f161-clemens-bed | walk | 260 | 0 |
| f161-e47 | f161-clemens-bed | f161-funeral-walk | walk | 200 | 0 |
| f161-e48 | f161-funeral-walk | f161-morgue-high | ladder | -80 | -160 |
| f161-e49 | f161-mess-high | f161-mess-ceiling | walk | 150 | 0 |
| f161-e50 | f161-mess-ceiling | f161-comms-high | walk | 250 | 0 |
| f161-e51 | f161-service-high | f161-fan-shaft | walk | -130 | 0 |
| f161-e52 | f161-service-deep | f161-tunnel-shrine | walk | 350 | 0 |
| f161-e53 | f161-tunnel-shrine | f161-bishop | ladder | 80 | -120 |
| f161-e54 | f161-leadworks | f161-piston-a-node | walk | 280 | 0 |
| f161-e55 | f161-piston-a-node | f161-mold | walk | 440 | 0 |
| f161-e56 | f161-sprinkler | f161-piston-b-node | walk | 260 | 0 |
| f161-e57 | f161-piston-b-node | f161-mold | ladder | 100 | 180 |
| f161-e58 | f161-mold | f161-piston-c-node | walk | 220 | 0 |
| f161-e59 | f161-piston-c-node | f161-furnace | walk | 340 | 0 |
| f161-e60 | f161-company | f161-patna-cage-node | walk | 130 | 0 |
| f161-e61 | f161-patna-cage-node | f161-extraction | walk | 110 | 0 |
| f161-e62 | f161-morgue-high | f161-master-archive-node | walk | -240 | 0 |
| f161-e63 | f161-cell-b | f161-shutter-cell-node | walk | 120 | 0 |
| f161-e64 | f161-shutter-cell-node | f161-comms-high | ladder | -20 | -160 |
| f161-e65 | f161-service-high | f161-steam-service-node | walk | 120 | 0 |
| f161-e66 | f161-steam-service-node | f161-fan-shaft | walk | -250 | 0 |
| f161-e67 | f161-service-low | f161-rescue-post-node | walk | 260 | 0 |
| f161-e68 | f161-rescue-post-node | f161-bishop | walk | 170 | 0 |
| f161-e69 | f161-bishop | f161-shutter-service-node | walk | 150 | 0 |
| f161-e70 | f161-shutter-service-node | f161-chemical-store | walk | 20 | 0 |
| f161-e71 | f161-tunnel-high | f161-command-post-node | ladder | 140 | 180 |
| f161-e72 | f161-command-post-node | f161-leadworks | walk | 240 | 0 |
| f161-e73 | f161-water-header | f161-steam-lead-node | walk | 20 | 0 |
| f161-e74 | f161-steam-lead-node | f161-piston-b-node | walk | 110 | 0 |
| f161-e75 | f161-mold | f161-shutter-foundry-node | walk | 130 | 0 |
| f161-e76 | f161-shutter-foundry-node | f161-piston-c-node | walk | 90 | 0 |
| f161-e77 | f161-mess-ceiling | f161-perch-cell-v93 | ladder | 30 | -160 |
| f161-e78 | f161-perch-cell-v93 | f161-comms-high | ladder | 220 | 160 |
| f161-e79 | f161-steam-service-node | f161-perch-service-v93 | ladder | 120 | -140 |
| f161-e80 | f161-perch-service-v93 | f161-service-high | ladder | -240 | 140 |
| f161-e81 | f161-rescue-post-node | f161-triage-v93 | walk | 160 | 0 |
| f161-e82 | f161-triage-v93 | f161-shutter-service-node | walk | 160 | 0 |
| f161-e83 | f161-steam-lead-node | f161-perch-lead-v93 | ladder | 10 | -140 |
| f161-e84 | f161-perch-lead-v93 | f161-piston-b-node | ladder | 100 | 140 |
| f161-e85 | f161-furnace | f161-parley-v93 | walk | 180 | 0 |
| f161-e86 | f161-parley-v93 | f161-company | walk | 140 | 0 |
| f161-e87 | f161-company | f161-witness-v93 | ladder | 230 | -180 |
| f161-e88 | f161-witness-v93 | f161-extraction | ladder | 10 | 180 |
| f161-e89 | f161-eev | f161-flight-analysis-v94 | ladder | 160 | -180 |
| f161-e90 | f161-flight-analysis-v94 | f161-morgue-high | walk | 720 | 20 |
| f161-e91 | f161-eev | f161-wreckage-incident-v94 | ladder | 200 | 120 |
| f161-e92 | f161-wreckage-incident-v94 | f161-infirmary | ladder | 300 | -120 |
| f161-e93 | f161-mess-high | f161-faith-dais-v94 | ladder | -140 | -160 |
| f161-e94 | f161-faith-dais-v94 | f161-perch-cell-v93 | walk | 320 | 0 |
| f161-e95 | f161-service-high | f161-battery-locker-v94 | walk | 430 | 0 |
| f161-e96 | f161-battery-locker-v94 | f161-tunnel-high | walk | 320 | 0 |
| f161-e97 | f161-tunnel-shrine | f161-golic-cache-v94 | walk | 240 | 0 |
| f161-e98 | f161-golic-cache-v94 | f161-tunnel-low | walk | 160 | 0 |
| f161-e99 | f161-tunnel-high | f161-battery-junction-v94 | walk | 200 | 0 |
| f161-e100 | f161-battery-junction-v94 | f161-water-header | walk | 670 | 0 |
| f161-e101 | f161-mold | f161-chase-reroute-v94 | ladder | 130 | 120 |
| f161-e102 | f161-chase-reroute-v94 | f161-furnace | ladder | 430 | -120 |
| f161-e103 | f161-witness-v93 | f161-final-transmission-v94 | walk | 70 | 0 |
| f161-e104 | f161-cell-a | f161-shelter-cell-v95 | ladder | 150 | 120 |
| f161-e105 | f161-shelter-cell-v95 | f161-assembly-hall | ladder | 250 | -120 |
| f161-e106 | f161-perch-cell-v93 | f161-watch-cell-v95 | walk | 160 | 0 |
| f161-e107 | f161-watch-cell-v95 | f161-comms-high | ladder | 60 | 160 |
| f161-e108 | f161-service-deep | f161-refuge-service-v95 | walk | -80 | 0 |
| f161-e109 | f161-refuge-service-v95 | f161-tunnel-shrine | walk | 430 | 0 |
| f161-e110 | f161-service-high | f161-hunt-service-v95 | walk | 300 | 0 |
| f161-e111 | f161-hunt-service-v95 | f161-battery-locker-v94 | walk | 130 | 0 |
| f161-e112 | f161-triage-v93 | f161-triage-overflow-v95 | walk | 110 | 0 |
| f161-e113 | f161-triage-overflow-v95 | f161-shutter-service-node | walk | 50 | 0 |
| f161-e114 | f161-tunnel-low | f161-hunt-junction-v95 | walk | 80 | 0 |
| f161-e115 | f161-hunt-junction-v95 | f161-waste-tank | walk | 170 | 0 |
| f161-e116 | f161-battery-junction-v94 | f161-bait-switch-v95 | walk | 300 | 0 |
| f161-e117 | f161-bait-switch-v95 | f161-sprinkler | walk | 240 | 0 |
| f161-e118 | f161-chase-reroute-v94 | f161-pressure-alcove-v95 | walk | -270 | 0 |
| f161-e119 | f161-furnace-high | f161-chase-observer-v95 | walk | -70 | 0 |
| f161-e120 | f161-witness-v93 | f161-archive-checksum-v95 | ladder | -70 | -140 |

## Grille de contrôle

### A3-ANCHOR

Tout décor a un support nommé ; coordonnées indépendantes du joueur. Vérification : automated.

### A3-FINITE

Positions et dimensions finies et positives. Vérification : automated.

### A3-ID

Identifiants uniques, parents existants. Vérification : automated.

### A3-FOOT

Les meubles reposent sur le plan de pose ; pas sur la caméra. Vérification : automated.

### A3-BOUND

Les éléments restent dans la baie de leur assemblage. Vérification : automated.

### A3-NO_FAKE_COVER

Décor d’arrière-plan non collidable et explicitement sans couverture. Vérification : automated.

### A3-CONDITION

Le matériel de récupération dépend de l’arrivée de la Compagnie. Vérification : automated.

### A3-ROUTE

Aucun nœud, verrou ou ordre de mission ajouté pour justifier le décor. Vérification : automated.

### A3-DRAW_PURE

Le rendu ne change ni progression ni sauvegarde. Vérification : automated.

### A3-TOP

Fond opaque depuis le premier pixel du champ, quelle que soit la caméra. Vérification : browser.

### A3-HUD

Les panneaux ordinaires couvrent moins de 9 % de l’écran. Vérification : automated.

### A3-READ

Les premiers plans s’effacent à proximité des silhouettes. Vérification : automated.

### A3-PARALLAX

Les machines proches suivent le monde ; seule l’architecture distante dérive. Vérification : browser.

### A3-LUX

Une lumière forte a une source dessinée. Vérification : visual.

### A3-RHYTHM

Alcôves équipées puis respirations, sans tapis uniforme de petits objets. Vérification : visual.

### A3-IDENTITY

Une forme identifiable remplace chaque bloc générique. Vérification : visual.

### A3-FILM

Plans et dimensions de jeu : adaptation, pas relevé certifié des plateaux. Vérification : disclosure.

### A3-ROOMS

La pièce, son étage et ses voisins priment sur les limites de caméra. Vérification : disclosure.

### A3-103-SPACE

Une section décrit un lieu et un étage ; elle ne crée pas une nouvelle salle instanciée. Vérification : scope.

### A3-103-PORTAL

Un cadre de porte provient d’une arête gate/airlock ; la feuille et la collision restent pilotées par la porte native. Vérification : automated.

### A3-103-GATE-GEOMETRY

Une porte fournie par le plan compilé est utilisée sans déplacer sa collision. Vérification : automated.

### A3-103-VERTICAL-PRIORITY

Haut/Bas donnent la priorité à une échelle réellement atteignable, avant un changement de profondeur. Vérification : automated.

### A3-103-CIRCUIT

Un réseau décoratif possède une source et un récepteur du même ensemble, reliés par un tracé continu. Vérification : automated.

### A3-103-LIGHT

Couper un éclairage de service ne coupe ni le feu du four, ni l’eau du piège, ni un objectif. Vérification : automated.

### A3-103-REACH

Une commande exige proximité, niveau, plan médian, personnage vivant et absence de porte fermée entre les deux. Vérification : automated.

### A3-103-PAUSE

Le plan et les archives arrêtent la simulation ; la fermeture ne supprime pas une pause préexistante. Vérification : automated.

### A3-103-MAP

Le plan ne montre ni ennemis ni dossiers secrets ; un nœud n’est relevé qu’au voisinage du personnage. Vérification : automated.

### A3-103-PERSIST

Les visites et les éclairages sont sauvegardés ; ni la géométrie ni l’ouverture du plan ne sont sérialisées. Vérification : automated.

### A3-103-REDUCED-MOTION

Le mouvement réduit conserve les états lisibles sans animation de panneaux. Vérification : automated.

### A3-103-PROVENANCE

Banc visuel et tests isolés ne constituent pas une validation de la campagne complète. Vérification : scope.

## Validation et limites

Les résultats sont dans qa-v103/unit.json, installation.json, browser.json et regressions.json. Les fixtures d’installation simulent les commandes npm ; elles prouvent le comportement transactionnel, pas le build du dépôt complet. Les captures sont natives Chromium et utilisent les modules de rendu livrés, un contrôleur simplifié et des acteurs provisoires. Elles ne prouvent pas les collisions de la campagne principale avec tous ses anciens interactifs.

Les règles artistiques et la fidélité aux décors du film restent un examen visuel. L’édition ne prétend pas reconstruire toute la prison en pièces instanciées. Aucun grade, succès ou compteur de collecte supplémentaire n’est ajouté.
