# Alien 3 — Fiorina 161 — V103 « Passages et réseaux »

Correctif cumulatif V88 à V103 pour Aliens: Tantalus Frontier. Ce paquet n’est pas le jeu principal : il conserve les modules du DLC, les installateurs, les tests et les rapports. Les sprites et gros assets du jeu principal ne sont pas inclus.

## Livrables à ouvrir

- `atelier-v103/FIORINA_V103_APERCU_LOCAL.html` : banc jouable autonome, sans téléchargement. Il exécute les nouveaux modules de rendu avec un contrôleur simplifié et des personnages provisoires. Ce n’est pas la campagne complète.
- `ALIEN3_RAPPORT_ILLUSTRE_V103.pdf` : rapport illustré de 11 pages.
- `ALIEN3_RAPPORT_ILLUSTRE_V103.html` : rapport autonome avec les 16 captures natives de Chromium intégrées.
- `ALIEN3_CODEX_LEVEL_DESIGN_V103.html` : 304 fiches de conception, recherche, filtres et liens croisés.
- `docs/ALIEN3_LEVEL_DESIGN_CODEX_V103.md` : version texte détaillée.

## Changements V103

Trois modules ajoutent vingt sections nommées par étage, trois habillages de portes natives, vingt-deux alimentations électriques locales et huit commandes d’éclairage de service. Le plan se remplit uniquement à proximité des points visités, sans localiser le Runner. Haut/Bas donne la priorité à une échelle atteignable plutôt qu’au changement de profondeur. Aucun nouvel objectif, grade ou succès n’est ajouté.

La topologie est conservée : 72 points, 119 connexions et quatre routes. Les vingt sections ne sont pas vingt nouvelles salles instanciées. Les trente assemblages V102 et leurs 284 composants gardent leurs supports.

Les interrupteurs changent les lampes et leurs halos ; ils ne changent ni la furtivité, ni la logique du piège, ni le feu du four. Les portes du jeu principal conservent leurs conditions d’ouverture natives.

## Commandes

Flèches : déplacement ; Haut/Bas : échelle ou profondeur ; Espace : saut ; E : interaction native ; I : éclairage de service proche ; M : plan ; C : archives ; Échap : fermeture du plan ou pause. Le banc propose aussi des boutons tactiles. Le menu de lieux et le bouton d’arrivée de la Compagnie servent à examiner des situations de test, pas à valider un parcours de campagne.

## Installation dans une copie du jeu principal

Décompresser le paquet à l’extérieur du dossier du jeu, puis lancer avec Node.js :

```bash
node scripts/install-alien3-dlc-v103.mjs "/chemin/vers/aliens-tantalus-frontier"
```

L’installateur prépare une copie temporaire, applique la chaîne nécessaire, lance `npm run check` puis `npm run build` dans cette copie, et ne remplace que les fichiers autorisés lorsque les commandes réussissent. Depuis une V102 compatible non modifiée, seuls les trois modules V103 et le raccord de `game-production-runtime.js` changent. Les modifications locales des anciens modules sont refusées, pas écrasées.

Un contrôle préliminaire sans écriture est possible avec `--dry-run`. Ce contrôle ne lance pas le build et ne garantit pas à lui seul le succès de l’installation.

Une modification des fichiers surveillés ou de `dist` pendant les vérifications fait annuler l’installation. Le reçu de récupération est écrit hors du dossier public et son emplacement est affiché. Pour restaurer :

```bash
node scripts/install-alien3-dlc-v103.mjs --restore "/chemin/du/recovery/receipt.json"
```

La restauration refuse les fichiers modifiés après installation. L’option de diagnostic `--no-build` n’exécute pas npm et ne constitue pas une validation du jeu ; les fixtures l’utilisent explicitement pour tester les écritures.

## Vérifications reproductibles

```bash
node scripts/test-alien3-dlc-v103.mjs
node scripts/test-alien3-installation-v103.mjs
python scripts/capture-alien3-v103.py
python scripts/run-alien3-regressions-v103.py
```

Les captures nécessitent Python Playwright et Chromium. La création du PDF nécessite ReportLab. Le jeu et les modules V103 ne dépendent pas de ces outils de rapport.

Résultats exécutés : 45 cas ciblés V103, 16 scénarios d’installation synthétiques, 37 contrôles du banc Chromium, 8 contrôles du codex HTML et 57 scripts historiques isolés passés. Les résultats détaillés et les états des captures sont dans `qa-v103/`.

## Portée

Aucun build du dépôt complet, parcours intégral de la campagne, push GitHub ou déploiement V103 n’a été effectué. Les tests npm de l’installation sont des fixtures, pas le jeu. Les captures montrent les modules livrés dans le banc local ; elles ne sont ni un rendu final avec les assets de production, ni une reconstitution 1:1 des plateaux du film. Les rapports des anciennes versions sont conservés comme historique et leurs déclarations ne remplacent pas le périmètre de validation explicite de cette édition.
