# Portée V114 — Atlas de continuité

| Sujet | Livré et vérifié | Non revendiqué |
|---|---|---|
| Montages | Séparation cinéma / Assembly ; chien et bovin mutuellement exclusifs | Deux campagnes film intégrales terminées |
| Monde | 29 espaces documentés ; 25/28 actifs selon montage ; liens logiques audités sur 72 points / 119 connexions | Relevé métrique 1:1 des décors du film |
| Lieux manquants | Bureau Andrews, abattoir, confinement Golic, chenil/bovin et intérieur récupération rendus comme shells d’inspection | Pièces traversables de campagne ou nouveaux objectifs |
| Morgue | Présence conservée et marquée provisoire | Raccord vertical certifié conforme au film |
| Personnages | 5 silhouettes d’inspection supplémentaires ; apparence séparée de la collision | Ressemblance photographique / scan des acteurs |
| Équipement | Hache Dillon, casque commando, Pulse Rifle noir et équipements de shells avec propriétaires explicites | Arsenal donné à Ripley |
| Sauvegarde | Changement de montage et rendu sans mutation du schéma V112 | Persistance native du choix de montage dans la campagne complète |
| Régression | Traque héritée terminée dans le banc V114 ; V113 unitaire rejoué | Qualification intégrale de tous les parcours historiques dans le moteur natif |
| Installation | Installateur incrémental V113→V114 sur fixtures exactes, rollback et refus des modifications | Build natif complet Tantalus, push GitHub ou déploiement Vercel |
