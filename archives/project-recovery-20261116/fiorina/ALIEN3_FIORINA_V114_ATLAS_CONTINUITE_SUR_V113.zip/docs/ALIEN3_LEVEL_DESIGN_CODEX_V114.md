# ALIEN 3 — FIORINA 161 · CODEX DE LEVEL DESIGN V113

## Périmètre
Codex de conception hors jeu. V113 relie les portes à une architecture, reprend quatre silhouettes et ajoute quatre objets ancrés. Le registre distingue référence, dessin, gameplay et manque : 19 repères de lieux liés sur 25 entrées, six non liés. Aucune pièce n’est certifiée 1:1. Les deux colonnes de montage ne sont pas deux campagnes terminées.
770 fiches, dont 85 nouveaux contrats. Les 284 composants historiques restent dans leurs assemblages ; les quatre objets de V113 sont identifiés séparément. Les trois portes restent à leur emplacement de gameplay hérité : la passe leur donne des appuis et des retours de cloison, sans en déduire une position film certifiée.

## Couverture mesurée
| Lieu ou scène | Montage | Repères liés | Reste à vérifier |
|---|---|---:|---|
| Sulaco : départ de l’EEV | both | 0 | Prologue absent du banc ; pas de scène validée ici. |
| Côte et épave | both | 2 | Architecture stylisée, approche à comparer selon montage. |
| Approche avec le bovin | assembly | 0 | Ne pas utiliser l’hôte canin dans cette continuité ; scène non intégrée ici. |
| Chenil / présence de Spike | theatrical | 0 | Pas de chenil jouable qualifié ; ne pas déclarer le point EEV équivalent. |
| Infirmerie et alcôve de Clemens | both | 2 | Appuis et mobilier présents ; proportions non mesurées. |
| Morgue et examen des corps | both | 1 | Palier supérieur hérité ; descente du montage étendu à comparer avant refonte. |
| Cérémonie et crémation | both | 2 | Points présents ne prouvent pas la mise en scène complète. |
| Bureau d’Andrews | both | 0 | Pas de pièce dédiée liée dans le modèle actuel. |
| Cellules et coursives | both | 2 | Façades arrière : pas toutes les cellules visitables. |
| Réfectoire et rassemblement | both | 2 | Deux étages de gameplay ; continuité film à qualifier. |
| Recueillement | both | 1 | Identification narrative à rapprocher des scènes, pas chapelle neuve inventée. |
| Poste de communications | both | 1 | Équipements localisés, décor haut hérité. |
| Ventilation de Murphy | both | 1 | Ventilateur visible ; séquence entière non rejouée par ce patch. |
| Couloirs et galeries de chasse | both | 4 | Graphe dense mais métrique et raccords non certifiés à l’image. |
| Raccordement de Bishop | both | 1 | Fragment visible ajouté, dialogue intégral non reproduit. |
| Réserve et préparation incendiaire | both | 1 | État de feu hérité, récipients et torche ancrés ; aucun nouveau combat. |
| Piège de la cuve à déchets | assembly | 1 | Point hérité ; capture et libération à qualifier dans la campagne native. |
| Confinement de Golic | assembly | 0 | Cache inférieure héritée ne remplace pas le lieu de confinement à l’écran. |
| Analyse diagnostique de l’EEV | both | 2 | Ne pas inventer un appareil mobile accessible partout. |
| Salle de coulée | both | 2 | Moule et portique présents ; parcours de test original distinct du film. |
| Rabattage, pistons et moule | both | 4 | Le retour vivant de Dillon du banc n’est pas le dénouement du film. |
| Commande haute du refroidissement | both | 2 | Hauteurs validées pour le jeu ; parcours exact à comparer. |
| Four et plateforme finale | both | 2 | Graphisme et fin de Ripley non qualifiés 1:1. |
| Arrivée de la Compagnie | both | 2 | Agents et arme représentés à l’arrivée seulement ; pas de nouvel échange de tirs. |
| Intérieur de la navette de récupération | both | 0 | Aucun intérieur complet lié ; ne pas le confondre avec la plateforme extérieure. |

## Équipement : statut indépendant du catalogue
| Objet | Propriétaire | État réel | Éléments liés |
|---|---|---|---|
| Enregistreur de l’EEV | ripley | bound-rendering | 1 |
| Module de secours | environment | bound-rendering | 1 |
| Trousse et plateau médical | clemens | bound-rendering | 9 |
| Diagnostic de l’EEV | environment | missing-binding | 0 |
| Bishop endommagé | environment | bound-rendering | 1 |
| Émetteur des communications | environment | bound-rendering | 3 |
| Lampe portative | prisoners | not-integrated | 0 |
| Torche incendiaire | prisoners | bound-rendering | 1 |
| Récipients du plan incendiaire | prisoners | bound-rendering | 2 |
| Outil lourd improvisé | prisoners | not-integrated | 0 |
| Clé de maintenance | prisoners | bound-rendering | 1 |
| Ventilateur de galerie | environment | bound-rendering | 1 |
| Plomb de la fonderie | environment | bound-rendering | 1 |
| Moule industriel | environment | bound-rendering | 1 |
| Portique et poche de transfert | environment | bound-rendering | 3 |
| Réseau de refroidissement | environment | bound-rendering | 2 |
| Fusil à impulsion noir | company-guard | conditional-visual | 0 |
| Matériel de récupération | company | conditional-visual | 3 |
| Bottes de Ripley | ripley | shared-renderer | 0 |
| Manteau carcéral | ripley | shared-renderer | 0 |
| Trois boulons de diversion | ripley | inherited | 0 |
| Trois purges locales | environment | inherited | 1 |
| Détecteur de mouvement | none | intentionally-absent | 0 |
| Arsenal de Marines pour Ripley | none | intentionally-absent | 0 |

## Méthode de validation
Une porte doit être reliée à un rectangle réel, un lien existant et un appui. Les retours de cloison sont en retrait, sans nouvelle collision cachée. Le même état de porte gouverne le verrou, le dessin, les interactions et les anciens systèmes. Les tests de cette version ne remplacent pas un nouveau parcours exhaustif de chacun des 119 liens.
Les personnages dessinés conservent leurs collisions, positions, vitesse, destinations, ordres et sauvegardes. Les agents de récupération sont des visuels conditionnels, pas de nouveaux combattants. Le changement du propriétaire V105 est limité à deux délégations de dessin facultatives ; ses autres méthodes restent inchangées.
La fidélité scène par scène reste ouverte : prologue du Sulaco, hôtes selon montage, bureau d’Andrews, confinement de Golic, intérieur de récupération et raccord de la morgue font partie des manques signalés. Les parcours de traque et rabattage du banc sont originaux, pas une reconstitution intégrale du film.

## Registre détaillé

### Côte et épave
`section-shore` · Sections

[Socle V104 conservé] Approche extérieure ; l’épave conduit vers le complexe. Repère : Coque éventrée et prise d’air. Étendue descriptive X 50–770 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-spawn` : X 180 ; pied Y 510 ; largeur 260

**Appui** — `f161-eev` : X 620 ; pied Y 510 ; largeur 300

**Ensemble** — `coast-intake` : X 87.5 ; Y 510 ; 185 × 146

**Ensemble** — `coast-wreck` : X 485.5 ; Y 510 ; 269 × 158

### Infirmerie
`section-medical` · Sections

[Socle V104 conservé] Soins et circulation principale ; le mobilier reste derrière le passage. Repère : Brancard, lavabo et lampe de soin. Étendue descriptive X 970–1670 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-infirmary` : X 1120 ; pied Y 510 ; largeur 300

**Appui** — `f161-clemens-bed` : X 1380 ; pied Y 510 ; largeur 180

**Appui** — `f161-funeral-walk` : X 1580 ; pied Y 510 ; largeur 180

**Ensemble** — `medical-care` : X 1002 ; Y 510 ; 236 × 131.44

**Ensemble** — `clemens-room` : X 1302 ; Y 510 ; 156 × 86.89

### Morgue et dossiers
`section-morgue` · Sections

[Socle V104 conservé] Palier supérieur, séparé de l’infirmerie par son altitude. Repère : Table mortuaire et armoire. Étendue descriptive X 1175–1630 ; sol représentatif Y 350. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-master-archive-node` : X 1260 ; pied Y 350 ; largeur 170

**Appui** — `f161-morgue-high` : X 1500 ; pied Y 350 ; largeur 260

**Ensemble** — `morgue-bay` : X 1382 ; Y 350 ; 236 × 111.27

### Cellules ouest
`section-west-cells` · Sections

[Socle V104 conservé] Coursive basse ; les cellules peintes ne sont pas des passages ajoutés. Repère : Barreaux et couchettes. Étendue descriptive X 1750–2450 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-cell-a` : X 1900 ; pied Y 510 ; largeur 300

**Appui** — `f161-assembly-hall` : X 2300 ; pied Y 510 ; largeur 300

**Ensemble** — `cell-a` : X 1767 ; Y 510 ; 266 × 154

### Cellules est
`section-east-cells` · Sections

[Socle V104 conservé] Approche du verrou des galeries ; conserver une sortie identifiable. Repère : Volet réel à l’est. Étendue descriptive X 2470–2820 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-cell-b` : X 2620 ; pied Y 510 ; largeur 300

**Appui** — `f161-shutter-cell-node` : X 2740 ; pied Y 510 ; largeur 160

**Ensemble** — `cell-b` : X 2487 ; Y 510 ; 266 × 154

### Réfectoire
`section-refectory` · Sections

[Socle V104 conservé] Tables regroupées ; accès par les connecteurs déjà présents. Repère : Longue table et bancs. Étendue descriptive X 2180–2565 ; sol représentatif Y 350. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-mess-high` : X 2320 ; pied Y 350 ; largeur 280

**Appui** — `f161-mess-ceiling` : X 2470 ; pied Y 350 ; largeur 190

**Ensemble** — `mess` : X 2198 ; Y 350 ; 244 × 137

### Communications
`section-comms` · Sections

[Socle V104 conservé] Poste haut réel, distinct du secteur caméra nommé communications. Repère : Deux écrans sur console. Étendue descriptive X 2630–2810 ; sol représentatif Y 350. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-comms-high` : X 2720 ; pied Y 350 ; largeur 180

**Ensemble** — `actual-comms` : X 2642 ; Y 350 ; 156 × 96.24

### Recueillement
`section-prayer` · Sections

[Socle V104 conservé] Palier haut austère, sans nouvelle porte au fond. Repère : Livre et petites flammes. Étendue descriptive X 2055–2585 ; sol représentatif Y 190. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-faith-dais-v94` : X 2180 ; pied Y 190 ; largeur 250

**Appui** — `f161-perch-cell-v93` : X 2500 ; pied Y 190 ; largeur 170

**Ensemble** — `faith` : X 2067 ; Y 190 ; 226 × 133.89

### Pompage et secours
`section-service` · Sections

[Socle V104 conservé] Eau, entretien et passage principal ; éclairage de service indépendant des objectifs. Repère : Pompe sur semelle. Étendue descriptive X 2920–3650 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-service-low` : X 3070 ; pied Y 510 ; largeur 300

**Appui** — `f161-rescue-post-node` : X 3330 ; pied Y 510 ; largeur 170

**Appui** — `f161-bishop` : X 3500 ; pied Y 510 ; largeur 300

**Ensemble** — `service-pump` : X 2957.5 ; Y 510 ; 225 × 150

### Ventilation
`section-ventilation` · Sections

[Socle V104 conservé] Palier technique supérieur ; une échelle ne doit pas changer la profondeur. Repère : Ventilateur sous grille. Étendue descriptive X 2855–3270 ; sol représentatif Y 330. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-fan-shaft` : X 2940 ; pied Y 330 ; largeur 170

**Appui** — `f161-service-high` : X 3070 ; pied Y 330 ; largeur 280

**Appui** — `f161-steam-service-node` : X 3190 ; pied Y 330 ; largeur 160

**Ensemble** — `murphy-fan` : X 2887 ; Y 330 ; 106 × 61.39

**Ensemble** — `service-shop` : X 3017 ; Y 330 ; 106 × 64.58

### Atelier des batteries
`section-batteries` · Sections

[Socle V104 conservé] Établi et rangement au-dessus de la circulation basse. Repère : Panneau à outils. Étendue descriptive X 3265–3625 ; sol représentatif Y 330. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-hunt-service-v95` : X 3370 ; pied Y 330 ; largeur 210

**Appui** — `f161-battery-locker-v94` : X 3500 ; pied Y 330 ; largeur 250

**Ensemble** — `battery-store` : X 3387 ; Y 330 ; 226 × 137.69

### Galeries basses
`section-lower-service` · Sections

[Socle V104 conservé] Dessous du complexe ; les regards vers les étages ne constituent pas un accès. Repère : Alcôve et réseaux. Étendue descriptive X 2930–3775 ; sol représentatif Y 630. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-service-deep` : X 3070 ; pied Y 630 ; largeur 280

**Appui** — `f161-tunnel-shrine` : X 3420 ; pied Y 630 ; largeur 210

**Appui** — `f161-golic-cache-v94` : X 3660 ; pied Y 630 ; largeur 230

**Ensemble** — `deep-shrine` : X 3327 ; Y 630 ; 186 × 110.19

### Réserve et supervision
`section-supply` · Sections

[Socle V104 conservé] Stockage puis commande industrielle ; respecter la position du portail existant. Repère : Fûts et console de supervision. Étendue descriptive X 3565–4050 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-chemical-store` : X 3670 ; pied Y 510 ; largeur 210

**Appui** — `f161-command-post-node` : X 3960 ; pied Y 510 ; largeur 180

**Ensemble** — `chemical-store` : X 3577 ; Y 510 ; 186 × 106.08

**Ensemble** — `command` : X 3882 ; Y 510 ; 156 × 96.24

### Fonderie
`section-leadworks` · Sections

[Socle V104 conservé] Regrouper alimentation, creuset et levage, sans ajouter de danger décoratif. Repère : Creuset sous portique. Étendue descriptive X 4030–4570 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-leadworks` : X 4200 ; pied Y 510 ; largeur 340

**Appui** — `f161-lead-primer` : X 4380 ; pied Y 510 ; largeur 190

**Appui** — `f161-piston-a-node` : X 4480 ; pied Y 510 ; largeur 180

**Ensemble** — `leadworks` : X 4122 ; Y 510 ; 156 × 118.09

**Ensemble** — `lead-primer` : X 4302 ; Y 510 ; 156 × 104

### Collecteur supérieur
`section-water` · Sections

[Socle V104 conservé] Conduite d’eau séparée visuellement du transfert de métal. Repère : Réservoir et vérins. Étendue descriptive X 4420–4910 ; sol représentatif Y 330. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-sprinkler` : X 4560 ; pied Y 330 ; largeur 280

**Appui** — `f161-water-header` : X 4690 ; pied Y 330 ; largeur 190

**Appui** — `f161-piston-b-node` : X 4820 ; pied Y 330 ; largeur 180

**Ensemble** — `water-header` : X 4447.5 ; Y 330 ; 225 × 150

**Ensemble** — `piston-upper` : X 4742 ; Y 330 ; 156 × 97.05

### Cuve et évacuation
`section-waste` · Sections

[Socle V104 conservé] Niveau inférieur : reprise des effluents et retour hydraulique. Repère : Réservoir bas et caniveau. Étendue descriptive X 3915–4890 ; sol représentatif Y 630. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-waste-tank` : X 4070 ; pied Y 630 ; largeur 310

**Appui** — `f161-sluice-low` : X 4500 ; pied Y 630 ; largeur 280

**Appui** — `f161-pressure-alcove-v95` : X 4780 ; pied Y 630 ; largeur 220

**Ensemble** — `waste` : X 3957.5 ; Y 630 ; 225 × 150

**Ensemble** — `lower-pressure` : X 4682 ; Y 630 ; 196 × 130.67

### Moule et pistons
`section-mold` · Sections

[Socle V104 conservé] Le piège et ses commandes historiques conservent leurs conditions. Repère : Bac de coulée bas. Étendue descriptive X 4740–5230 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-mold` : X 4920 ; pied Y 510 ; largeur 360

**Appui** — `f161-piston-c-node` : X 5140 ; pied Y 510 ; largeur 180

**Ensemble** — `mold` : X 4783.5 ; Y 510 ; 273 × 143

### Four principal
`section-furnace` · Sections

[Socle V104 conservé] Approche chaude puis confrontation ; ne pas masquer les personnages. Repère : Bouche circulaire du four. Étendue descriptive X 5310–5750 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-furnace` : X 5480 ; pied Y 510 ; largeur 340

**Appui** — `f161-parley-v93` : X 5660 ; pied Y 510 ; largeur 180

**Ensemble** — `main-furnace` : X 5402 ; Y 510 ; 156 × 110.29

**Ensemble** — `parley` : X 5582 ; Y 510 ; 156 × 102.23

### Passerelles du four
`section-gantries` · Sections

[Socle V104 conservé] Commande haute avec débouchés d’échelles conservés. Repère : Treuil et caillebotis. Étendue descriptive X 5210–5880 ; sol représentatif Y 330. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-furnace-high` : X 5350 ; pied Y 330 ; largeur 280

**Appui** — `f161-furnace-overlook` : X 5580 ; pied Y 330 ; largeur 220

**Appui** — `f161-furnace-gantry` : X 5740 ; pied Y 330 ; largeur 280

**Ensemble** — `furnace-gantry` : X 5232.5 ; Y 330 ; 235 × 154

### Approche et plateforme
`section-arrival` · Sections

[Socle V104 conservé] L’équipement de récupération reste conditionné à l’arrivée de la Compagnie. Repère : Cage portable et projecteur. Étendue descriptive X 5650–6190 ; sol représentatif Y 510. La section ne crée ni pièce instanciée, ni mur physique, ni nouvelle route. Un saut conserve son identité de départ.

**Appui** — `f161-company` : X 5800 ; pied Y 510 ; largeur 300

**Appui** — `f161-patna-cage-node` : X 5930 ; pied Y 510 ; largeur 160

**Appui** — `f161-extraction` : X 6040 ; pied Y 510 ; largeur 300

**Ensemble** — `patna-kit` : X 5887 ; Y 510 ; 86 × 42.85

**Ensemble** — `final-landing` : X 5997 ; Y 510 ; 86 × 56.36

### Prise d’air côtière
`coast-intake` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-spawn ; point f161-spawn ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant fan** — `coast-intake/0` : X 87.5 ; Y 398 ; 84 × 84 ; pose wall

**Composant duct** — `coast-intake/1` : X 167.5 ; Y 414 ; 105 × 48 ; pose wall

**Composant junction** — `coast-intake/2` : X 230.5 ; Y 470 ; 38 × 38 ; pose wall

**Composant gauge** — `coast-intake/3` : X 194.5 ; Y 467 ; 22 × 22 ; pose wall

**Composant pipe** — `coast-intake/4` : X 175.5 ; Y 480 ; 42 × 10 ; pose wall

**Composant drain** — `coast-intake/5` : X 94.5 ; Y 503 ; 100 × 7 ; pose floor

**Composant lamp** — `coast-intake/6` : X 127.5 ; Y 364 ; 40 × 13 ; pose ceiling

**Composant cable** — `coast-intake/7` : X 244.5 ; Y 409 ; 7 × 52 ; pose wall

**Composant support** — `coast-intake/8` : X 92.5 ; Y 490 ; 6 × 20 ; pose floor

**Composant stencil** — `coast-intake/9` : X 188.5 ; Y 370 ; 77 × 19 ; pose wall

**Raccord** — `coast-intake-lighting-run` : coast-intake/2 → coast-intake/6

### Épave et matériel de secours
`coast-wreck` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-eev ; point f161-eev ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant eev** — `coast-wreck/0` : X 485.5 ; Y 396 ; 236 × 114 ; pose floor

**Composant cable** — `coast-wreck/1` : X 496.5 ; Y 471 ; 80 × 12 ; pose wall

**Composant case** — `coast-wreck/2` : X 664.5 ; Y 476 ; 43 × 34 ; pose floor

**Composant drain** — `coast-wreck/3` : X 498.5 ; Y 504 ; 139 × 6 ; pose floor

**Composant lamp** — `coast-wreck/4` : X 565.5 ; Y 352 ; 41 × 13 ; pose ceiling

**Composant junction** — `coast-wreck/5` : X 728.5 ; Y 461 ; 26 × 44 ; pose wall

**Composant pipe** — `coast-wreck/6` : X 726.5 ; Y 405 ; 10 × 45 ; pose wall

**Composant stencil** — `coast-wreck/7` : X 660.5 ; Y 367 ; 72 × 20 ; pose wall

**Raccord** — `coast-wreck-lighting-run` : coast-wreck/5 → coast-wreck/4

### Poste de soin
`medical-care` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-infirmary ; point f161-infirmary ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant cabinet** — `medical-care/0` : X 1002 ; Y 411.42 ; 44.81 × 98.58 ; pose floor

**Composant gurney** — `medical-care/1` : X 1067.72 ; Y 466.19 ; 105.55 × 43.81 ; pose floor

**Composant monitor** — `medical-care/2` : X 1110.54 ; Y 408.43 ; 51.78 × 38.84 ; pose wall

**Composant sink** — `medical-care/3` : X 1186.22 ; Y 452.24 ; 51.78 × 57.76 ; pose floor

**Composant bottle** — `medical-care/4` : X 1010.96 ; Y 425.36 ; 5.97 × 13.94 ; pose wall

**Composant bottle** — `medical-care/5` : X 1023.91 ; Y 425.36 ; 5.97 × 13.94 ; pose wall

**Composant bottle** — `medical-care/6` : X 1194.19 ; Y 435.32 ; 5.97 × 14.94 ; pose wall

**Composant lamp** — `medical-care/7` : X 1074.69 ; Y 378.56 ; 97.59 × 11.95 ; pose ceiling

**Composant cable** — `medical-care/8` : X 1159.33 ; Y 446.27 ; 7.97 × 54.77 ; pose wall

**Composant pipe** — `medical-care/9` : X 1231.03 ; Y 419.38 ; 6.97 × 21.91 ; pose wall

**Composant tray** — `medical-care/10` : X 1085.65 ; Y 454.24 ; 46.8 × 8.96 ; pose wall

**Composant stencil** — `medical-care/11` : X 1004.99 ; Y 381.54 ; 54.77 × 16.93 ; pose wall

### Chambre médicale
`clemens-room` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-clemens-bed ; point f161-clemens-bed ; échelle uniforme 0.66 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant cabinet** — `clemens-room/0` : X 1302 ; Y 444.84 ; 29.62 × 65.16 ; pose floor

**Composant gurney** — `clemens-room/1` : X 1345.44 ; Y 481.04 ; 69.77 × 28.96 ; pose floor

**Composant monitor** — `clemens-room/2` : X 1373.75 ; Y 442.86 ; 34.23 × 25.67 ; pose wall

**Composant sink** — `clemens-room/3` : X 1423.77 ; Y 471.82 ; 34.23 × 38.18 ; pose floor

**Composant bottle** — `clemens-room/4` : X 1307.92 ; Y 454.05 ; 3.95 × 9.22 ; pose wall

**Composant bottle** — `clemens-room/5` : X 1316.48 ; Y 454.05 ; 3.95 × 9.22 ; pose wall

**Composant bottle** — `clemens-room/6` : X 1429.04 ; Y 460.63 ; 3.95 × 9.87 ; pose wall

**Composant lamp** — `clemens-room/7` : X 1350.05 ; Y 423.11 ; 64.51 × 7.9 ; pose ceiling

**Composant cable** — `clemens-room/8` : X 1406 ; Y 467.87 ; 5.27 × 36.2 ; pose wall

**Composant pipe** — `clemens-room/9` : X 1453.39 ; Y 450.1 ; 4.61 × 14.48 ; pose wall

**Composant tray** — `clemens-room/10` : X 1357.29 ; Y 473.14 ; 30.94 × 5.92 ; pose wall

**Composant stencil** — `clemens-room/11` : X 1303.97 ; Y 425.09 ; 36.2 × 11.19 ; pose wall

### Baie mortuaire
`morgue-bay` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-morgue-high ; point f161-morgue-high ; échelle uniforme 0.9 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant cabinet** — `morgue-bay/0` : X 1382 ; Y 271.03 ; 52.05 × 78.97 ; pose floor

**Composant gurney** — `morgue-bay/1` : X 1458.27 ; Y 312.31 ; 98.71 × 37.69 ; pose floor

**Composant sink** — `morgue-bay/2` : X 1576.72 ; Y 296.16 ; 41.28 × 53.84 ; pose floor

**Composant lamp** — `morgue-bay/3` : X 1463.66 ; Y 238.73 ; 77.17 × 10.77 ; pose ceiling

**Composant drain** — `morgue-bay/4` : X 1461.86 ; Y 345.51 ; 96.91 × 4.49 ; pose floor

**Composant tray** — `morgue-bay/5` : X 1504.04 ; Y 298.85 ; 37.69 × 8.97 ; pose wall

**Composant junction** — `morgue-bay/6` : X 1588.39 ; Y 256.68 ; 22.43 × 21.54 ; pose wall

**Composant stencil** — `morgue-bay/7` : X 1384.69 ; Y 239.63 ; 52.05 × 14.36 ; pose wall

**Raccord** — `morgue-bay-lighting-run` : morgue-bay/6 → morgue-bay/3

### Cellules ouest
`cell-a` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-cell-a ; point f161-cell-a ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant cell** — `cell-a/0` : X 1767 ; Y 378 ; 73 × 132 ; pose floor

**Composant bunk** — `cell-a/1` : X 1861 ; Y 407 ; 111 × 103 ; pose floor

**Composant basin** — `cell-a/2` : X 1990 ; Y 462 ; 35 × 48 ; pose floor

**Composant lamp** — `cell-a/3` : X 1784 ; Y 356 ; 37 × 11 ; pose ceiling

**Composant blanket** — `cell-a/4` : X 1880 ; Y 471 ; 42 × 8 ; pose wall

**Composant cup** — `cell-a/5` : X 1965 ; Y 499 ; 8 × 11 ; pose floor

**Composant stencil** — `cell-a/6` : X 1874 ; Y 368 ; 73 × 19 ; pose wall

**Composant pipe** — `cell-a/7` : X 2027 ; Y 401 ; 6 × 89 ; pose wall

**Composant cable** — `cell-a/8` : X 1779 ; Y 368 ; 234 × 5 ; pose wall

**Composant drain** — `cell-a/9` : X 1988 ; Y 505 ; 36 × 5 ; pose floor

### Cellules est
`cell-b` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-cell-b ; point f161-cell-b ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant cell** — `cell-b/0` : X 2487 ; Y 378 ; 73 × 132 ; pose floor

**Composant bunk** — `cell-b/1` : X 2581 ; Y 407 ; 111 × 103 ; pose floor

**Composant basin** — `cell-b/2` : X 2710 ; Y 462 ; 35 × 48 ; pose floor

**Composant lamp** — `cell-b/3` : X 2504 ; Y 356 ; 37 × 11 ; pose ceiling

**Composant blanket** — `cell-b/4` : X 2600 ; Y 471 ; 42 × 8 ; pose wall

**Composant cup** — `cell-b/5` : X 2685 ; Y 499 ; 8 × 11 ; pose floor

**Composant stencil** — `cell-b/6` : X 2594 ; Y 368 ; 73 × 19 ; pose wall

**Composant pipe** — `cell-b/7` : X 2747 ; Y 401 ; 6 × 89 ; pose wall

**Composant cable** — `cell-b/8` : X 2499 ; Y 368 ; 234 × 5 ; pose wall

**Composant drain** — `cell-b/9` : X 2708 ; Y 505 ; 36 × 5 ; pose floor

### Réfectoire
`mess` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-mess-high ; point f161-mess-high ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant table** — `mess/0` : X 2212 ; Y 305 ; 156 × 45 ; pose floor

**Composant bench** — `mess/1` : X 2202 ; Y 326 ; 65 × 24 ; pose floor

**Composant bench** — `mess/2` : X 2312 ; Y 326 ; 65 × 24 ; pose floor

**Composant cup** — `mess/3` : X 2244 ; Y 296 ; 8 × 10 ; pose wall

**Composant cup** — `mess/4` : X 2290 ; Y 296 ; 8 × 10 ; pose wall

**Composant bowl** — `mess/5` : X 2324 ; Y 299 ; 21 × 7 ; pose wall

**Composant rack** — `mess/6` : X 2388 ; Y 241 ; 53 × 109 ; pose floor

**Composant lamp** — `mess/7` : X 2246 ; Y 215 ; 78 × 12 ; pose ceiling

**Composant stencil** — `mess/8` : X 2389 ; Y 213 ; 53 × 17 ; pose wall

**Composant cable** — `mess/9` : X 2391 ; Y 227 ; 42 × 5 ; pose wall

**Raccord** — `mess-lighting-run` : mess/6 → mess/7

### Lieu de recueillement
`faith` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-faith-dais-v94 ; point f161-faith-dais-v94 ; échelle uniforme 0.95 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant altar** — `faith/0` : X 2106.88 ; Y 134.92 ; 113.95 × 55.08 ; pose floor

**Composant bench** — `faith/1` : X 2067 ; Y 166.26 ; 54.13 × 23.74 ; pose floor

**Composant bench** — `faith/2` : X 2238.87 ; Y 166.26 ; 54.13 × 23.74 ; pose floor

**Composant candle** — `faith/3` : X 2138.22 ; Y 111.18 ; 5.7 × 23.74 ; pose wall

**Composant candle** — `faith/4` : X 2198.99 ; Y 114.98 ; 5.7 × 19.94 ; pose wall

**Composant book** — `faith/5` : X 2168.61 ; Y 125.43 ; 22.79 × 7.6 ; pose wall

**Composant lamp** — `faith/6` : X 2155.31 ; Y 56.11 ; 22.79 × 10.45 ; pose ceiling

**Composant stencil** — `faith/7` : X 2108.78 ; Y 76.05 ; 112.05 × 20.89 ; pose wall

### Poste de communication
`actual-comms` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-comms-high ; point f161-comms-high ; échelle uniforme 0.63 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant console** — `actual-comms/0` : X 2644.52 ; Y 302.19 ; 84.29 × 47.81 ; pose floor

**Composant rack** — `actual-comms/1` : X 2756.48 ; Y 266.34 ; 41.52 × 83.66 ; pose floor

**Composant monitor** — `actual-comms/2` : X 2652.06 ; Y 272.63 ; 32.71 × 23.9 ; pose wall

**Composant monitor** — `actual-comms/3` : X 2691.69 ; Y 272.63 ; 32.71 × 23.9 ; pose wall

**Composant spool** — `actual-comms/4` : X 2736.98 ; Y 331.76 ; 18.24 × 18.24 ; pose floor

**Composant junction** — `actual-comms/5` : X 2733.21 ; Y 281.44 ; 16.98 × 18.24 ; pose wall

**Composant cable** — `actual-comms/6` : X 2721.26 ; Y 297.79 ; 39.63 × 5.03 ; pose wall

**Composant lamp** — `actual-comms/7` : X 2652.69 ; Y 255.65 ; 28.31 × 6.29 ; pose ceiling

**Composant stencil** — `actual-comms/8` : X 2757.11 ; Y 253.76 ; 40.89 × 9.44 ; pose wall

**Composant stool** — `actual-comms/9` : X 2683.52 ; Y 329.87 ; 15.1 × 20.13 ; pose floor

**Raccord** — `actual-comms-lighting-run` : actual-comms/5 → actual-comms/7

### Ventilateur de maintenance
`murphy-fan` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-fan-shaft ; point f161-fan-shaft ; échelle uniforme 0.41 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant fan** — `murphy-fan/0` : X 2890.27 ; Y 277.61 ; 47.47 × 47.47 ; pose wall

**Composant duct** — `murphy-fan/1` : X 2937.75 ; Y 292.76 ; 52.8 × 23.33 ; pose wall

**Composant junction** — `murphy-fan/2` : X 2969.26 ; Y 275.16 ; 13.92 × 12.69 ; pose wall

**Composant gauge** — `murphy-fan/3` : X 2951.66 ; Y 279.66 ; 8.59 × 8.59 ; pose wall

**Composant valve** — `murphy-fan/4` : X 2943.48 ; Y 318.95 ; 11.05 × 11.05 ; pose wall

**Composant pipe** — `murphy-fan/5` : X 2891.09 ; Y 324.68 ; 101.91 × 3.68 ; pose wall

**Composant drain** — `murphy-fan/6` : X 2894.37 ; Y 327.95 ; 38.47 × 2.05 ; pose floor

**Composant lamp** — `murphy-fan/7` : X 2899.69 ; Y 268.61 ; 18.42 × 4.09 ; pose ceiling

**Composant grille** — `murphy-fan/8` : X 2967.63 ; Y 319.77 ; 21.69 × 8.59 ; pose wall

**Composant cable** — `murphy-fan/9` : X 2983.18 ; Y 274.75 ; 2.86 × 15.55 ; pose wall

**Raccord** — `murphy-fan-lighting-run` : murphy-fan/2 → murphy-fan/7

### Pompage des galeries
`service-pump` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-service-low ; point f161-service-low ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant pump** — `service-pump/0` : X 2985.5 ; Y 430 ; 83 × 80 ; pose floor

**Composant tank** — `service-pump/1` : X 3122.5 ; Y 384 ; 60 × 126 ; pose floor

**Composant valve** — `service-pump/2` : X 3086.5 ; Y 471 ; 27 × 27 ; pose wall

**Composant gauge** — `service-pump/3` : X 3003.5 ; Y 402 ; 24 × 24 ; pose wall

**Composant pipe** — `service-pump/4` : X 3056.5 ; Y 481 ; 84 × 10 ; pose wall

**Composant pipe** — `service-pump/5` : X 3135.5 ; Y 384 ; 8 × 19 ; pose wall

**Composant junction** — `service-pump/6` : X 2966.5 ; Y 448 ; 23 × 25 ; pose wall

**Composant drain** — `service-pump/7` : X 2960.5 ; Y 505 ; 116 × 5 ; pose floor

**Composant lamp** — `service-pump/8` : X 3056.5 ; Y 360 ; 37 × 10 ; pose ceiling

**Composant stencil** — `service-pump/9` : X 2978.5 ; Y 371 ; 72 × 18 ; pose wall

**Raccord** — `service-pump-lighting-run` : service-pump/6 → service-pump/8

### Entretien des réseaux
`service-shop` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-service-high ; point f161-service-high ; échelle uniforme 0.45 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant bench** — `service-shop/0` : X 3018.78 ; Y 306.84 ; 57.9 × 23.16 ; pose floor

**Composant rack** — `service-shop/1` : X 3097.17 ; Y 276.11 ; 25.83 × 53.89 ; pose floor

**Composant toolboard** — `service-shop/2` : X 3024.57 ; Y 280.56 ; 47.66 × 22.71 ; pose wall

**Composant case** — `service-shop/3` : X 3082.47 ; Y 314.86 ; 15.14 × 15.14 ; pose floor

**Composant lamp** — `service-shop/4` : X 3029.92 ; Y 268.09 ; 35.18 × 4.9 ; pose ceiling

**Composant junction** — `service-shop/5` : X 3082.92 ; Y 282.79 ; 12.03 × 14.7 ; pose wall

**Composant spool** — `service-shop/6` : X 3101.18 ; Y 309.51 ; 13.36 × 13.36 ; pose wall

**Composant pipe** — `service-shop/7` : X 3021.45 ; Y 272.99 ; 96.2 × 2.67 ; pose wall

**Composant stencil** — `service-shop/8` : X 3082.03 ; Y 265.42 ; 35.63 × 7.57 ; pose wall

**Composant tray** — `service-shop/9` : X 3045.5 ; Y 301.05 ; 14.25 × 4.45 ; pose wall

**Raccord** — `service-shop-lighting-run` : service-shop/5 → service-shop/4

### Alcôve des galeries
`deep-shrine` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-tunnel-shrine ; point f161-tunnel-shrine ; échelle uniforme 0.78 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant altar** — `deep-shrine/0` : X 3359.82 ; Y 584.67 ; 93.78 × 45.33 ; pose floor

**Composant bench** — `deep-shrine/1` : X 3327 ; Y 610.46 ; 44.55 × 19.54 ; pose floor

**Composant bench** — `deep-shrine/2` : X 3468.45 ; Y 610.46 ; 44.55 × 19.54 ; pose floor

**Composant candle** — `deep-shrine/3` : X 3385.61 ; Y 565.13 ; 4.69 × 19.54 ; pose wall

**Composant candle** — `deep-shrine/4` : X 3435.63 ; Y 568.26 ; 4.69 × 16.41 ; pose wall

**Composant book** — `deep-shrine/5` : X 3410.62 ; Y 576.86 ; 18.76 × 6.25 ; pose wall

**Composant lamp** — `deep-shrine/6` : X 3399.68 ; Y 519.81 ; 18.76 × 8.6 ; pose ceiling

**Composant stencil** — `deep-shrine/7` : X 3361.39 ; Y 536.22 ; 92.22 × 17.19 ; pose wall

### Recharge des batteries
`battery-store` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-battery-locker-v94 ; point f161-battery-locker-v94 ; échelle uniforme 0.95 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant bench** — `battery-store/0` : X 3390.8 ; Y 280.62 ; 123.45 × 49.38 ; pose floor

**Composant rack** — `battery-store/1` : X 3557.92 ; Y 215.1 ; 55.08 × 114.9 ; pose floor

**Composant toolboard** — `battery-store/2` : X 3403.14 ; Y 224.6 ; 101.61 × 48.43 ; pose wall

**Composant case** — `battery-store/3` : X 3526.59 ; Y 297.71 ; 32.29 × 32.29 ; pose floor

**Composant lamp** — `battery-store/4` : X 3414.54 ; Y 198.01 ; 75.02 × 10.45 ; pose ceiling

**Composant junction** — `battery-store/5` : X 3527.54 ; Y 229.34 ; 25.64 × 31.34 ; pose wall

**Composant spool** — `battery-store/6` : X 3566.47 ; Y 286.32 ; 28.49 × 28.49 ; pose wall

**Composant pipe** — `battery-store/7` : X 3396.5 ; Y 208.45 ; 205.11 × 5.7 ; pose wall

**Composant stencil** — `battery-store/8` : X 3525.64 ; Y 192.31 ; 75.97 × 16.14 ; pose wall

**Composant tray** — `battery-store/9` : X 3447.77 ; Y 268.28 ; 30.39 × 9.5 ; pose wall

**Raccord** — `battery-store-lighting-run` : battery-store/5 → battery-store/4

### Réserve de produits
`chemical-store` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-chemical-store ; point f161-chemical-store ; échelle uniforme 0.71 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant rack** — `chemical-store/0` : X 3577 ; Y 423.01 ; 53.04 × 86.99 ; pose floor

**Composant barrel** — `chemical-store/1` : X 3650.55 ; Y 460.49 ; 27.58 × 49.51 ; pose floor

**Composant barrel** — `chemical-store/2` : X 3687.33 ; Y 460.49 ; 27.58 × 49.51 ; pose floor

**Composant case** — `chemical-store/3` : X 3727.64 ; Y 485.95 ; 30.41 × 24.05 ; pose floor

**Composant lamp** — `chemical-store/4` : X 3644.89 ; Y 403.92 ; 31.12 × 7.07 ; pose ceiling

**Composant grille** — `chemical-store/5` : X 3657.62 ; Y 421.6 ; 57.29 × 22.63 ; pose wall

**Composant valve** — `chemical-store/6` : X 3747.44 ; Y 445.64 ; 15.56 × 15.56 ; pose wall

**Composant pipe** — `chemical-store/7` : X 3627.21 ; Y 437.86 ; 30.41 × 4.95 ; pose wall

**Composant stencil** — `chemical-store/8` : X 3583.37 ; Y 405.33 ; 47.38 × 11.32 ; pose wall

**Composant drain** — `chemical-store/9` : X 3644.89 ; Y 506.46 ; 79.21 × 3.54 ; pose floor

**Raccord** — `chemical-store-lighting-run` : chemical-store/0 → chemical-store/4

### Supervision de la fonderie
`command` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-command-post-node ; point f161-command-post-node ; échelle uniforme 0.63 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant console** — `command/0` : X 3884.52 ; Y 462.19 ; 84.29 × 47.81 ; pose floor

**Composant rack** — `command/1` : X 3996.48 ; Y 426.34 ; 41.52 × 83.66 ; pose floor

**Composant monitor** — `command/2` : X 3892.06 ; Y 432.63 ; 32.71 × 23.9 ; pose wall

**Composant monitor** — `command/3` : X 3931.69 ; Y 432.63 ; 32.71 × 23.9 ; pose wall

**Composant spool** — `command/4` : X 3976.98 ; Y 491.76 ; 18.24 × 18.24 ; pose floor

**Composant junction** — `command/5` : X 3973.21 ; Y 441.44 ; 16.98 × 18.24 ; pose wall

**Composant cable** — `command/6` : X 3961.26 ; Y 457.79 ; 39.63 × 5.03 ; pose wall

**Composant lamp** — `command/7` : X 3892.69 ; Y 415.65 ; 28.31 × 6.29 ; pose ceiling

**Composant stencil** — `command/8` : X 3997.11 ; Y 413.76 ; 40.89 × 9.44 ; pose wall

**Composant stool** — `command/9` : X 3923.52 ; Y 489.87 ; 15.1 × 20.13 ; pose floor

**Raccord** — `command-lighting-run` : command/5 → command/7

### Collecte des effluents
`waste` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-waste-tank ; point f161-waste-tank ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant pump** — `waste/0` : X 3985.5 ; Y 550 ; 83 × 80 ; pose floor

**Composant tank** — `waste/1` : X 4122.5 ; Y 504 ; 60 × 126 ; pose floor

**Composant valve** — `waste/2` : X 4086.5 ; Y 591 ; 27 × 27 ; pose wall

**Composant gauge** — `waste/3` : X 4003.5 ; Y 522 ; 24 × 24 ; pose wall

**Composant pipe** — `waste/4` : X 4056.5 ; Y 601 ; 84 × 10 ; pose wall

**Composant pipe** — `waste/5` : X 4135.5 ; Y 504 ; 8 × 19 ; pose wall

**Composant junction** — `waste/6` : X 3966.5 ; Y 568 ; 23 × 25 ; pose wall

**Composant drain** — `waste/7` : X 3960.5 ; Y 625 ; 116 × 5 ; pose floor

**Composant lamp** — `waste/8` : X 4056.5 ; Y 480 ; 37 × 10 ; pose ceiling

**Composant stencil** — `waste/9` : X 3978.5 ; Y 491 ; 72 × 18 ; pose wall

**Raccord** — `waste-lighting-run` : waste/6 → waste/8

### Creuset et transfert
`leadworks` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-leadworks ; point f161-leadworks ; échelle uniforme 0.62 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant crucible** — `leadworks/0` : X 4151.83 ; Y 424.85 ; 72.1 × 85.15 ; pose floor

**Composant gantry** — `leadworks/1` : X 4127.59 ; Y 406.21 ; 133.63 × 103.79 ; pose floor

**Composant hoist** — `leadworks/2` : X 4174.83 ; Y 414.29 ; 29.83 × 40.4 ; pose ceiling

**Composant ladle** — `leadworks/3` : X 4242.57 ; Y 441.63 ; 35.43 × 68.37 ; pose floor

**Composant gauge** — `leadworks/4` : X 4128.22 ; Y 475.2 ; 14.29 × 14.29 ; pose wall

**Composant pipe** — `leadworks/5` : X 4127.59 ; Y 489.49 ; 26.1 × 6.22 ; pose wall

**Composant slag** — `leadworks/6` : X 4240.09 ; Y 490.11 ; 25.48 × 19.89 ; pose floor

**Composant lamp** — `leadworks/7` : X 4241.95 ; Y 391.91 ; 19.89 × 7.46 ; pose ceiling

**Composant stencil** — `leadworks/8` : X 4150.59 ; Y 397.51 ; 49.72 × 11.19 ; pose wall

**Composant grille** — `leadworks/9` : X 4194.1 ; Y 505.65 ; 26.1 × 4.35 ; pose floor

### Alimentation du creuset
`lead-primer` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-lead-primer ; point f161-lead-primer ; échelle uniforme 0.69 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant pump** — `lead-primer/0` : X 4321.41 ; Y 454.53 ; 57.55 × 55.47 ; pose floor

**Composant tank** — `lead-primer/1` : X 4416.4 ; Y 422.64 ; 41.6 × 87.36 ; pose floor

**Composant valve** — `lead-primer/2` : X 4391.44 ; Y 482.96 ; 18.72 × 18.72 ; pose wall

**Composant gauge** — `lead-primer/3` : X 4333.89 ; Y 435.12 ; 16.64 × 16.64 ; pose wall

**Composant pipe** — `lead-primer/4` : X 4370.64 ; Y 489.89 ; 58.24 × 6.93 ; pose wall

**Composant pipe** — `lead-primer/5` : X 4425.41 ; Y 422.64 ; 5.55 × 13.17 ; pose wall

**Composant junction** — `lead-primer/6` : X 4308.24 ; Y 467.01 ; 15.95 × 17.33 ; pose wall

**Composant drain** — `lead-primer/7` : X 4304.08 ; Y 506.53 ; 80.43 × 3.47 ; pose floor

**Composant lamp** — `lead-primer/8` : X 4370.64 ; Y 406 ; 25.65 × 6.93 ; pose ceiling

**Composant stencil** — `lead-primer/9` : X 4316.56 ; Y 413.63 ; 49.92 × 12.48 ; pose wall

**Raccord** — `lead-primer-lighting-run` : lead-primer/6 → lead-primer/8

### Collecteur d’eau supérieur
`water-header` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-sprinkler ; point f161-sprinkler ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant pump** — `water-header/0` : X 4475.5 ; Y 250 ; 83 × 80 ; pose floor

**Composant tank** — `water-header/1` : X 4612.5 ; Y 204 ; 60 × 126 ; pose floor

**Composant valve** — `water-header/2` : X 4576.5 ; Y 291 ; 27 × 27 ; pose wall

**Composant gauge** — `water-header/3` : X 4493.5 ; Y 222 ; 24 × 24 ; pose wall

**Composant pipe** — `water-header/4` : X 4546.5 ; Y 301 ; 84 × 10 ; pose wall

**Composant pipe** — `water-header/5` : X 4625.5 ; Y 204 ; 8 × 19 ; pose wall

**Composant junction** — `water-header/6` : X 4456.5 ; Y 268 ; 23 × 25 ; pose wall

**Composant drain** — `water-header/7` : X 4450.5 ; Y 325 ; 116 × 5 ; pose floor

**Composant lamp** — `water-header/8` : X 4546.5 ; Y 180 ; 37 × 10 ; pose ceiling

**Composant stencil** — `water-header/9` : X 4468.5 ; Y 191 ; 72 × 18 ; pose wall

**Raccord** — `water-header-lighting-run` : water-header/6 → water-header/8

### Pistons supérieurs
`piston-upper` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-piston-b-node ; point f161-piston-b-node ; échelle uniforme 0.6 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant piston** — `piston-upper/0` : X 4750.34 ; Y 258.55 ; 34.53 × 71.45 ; pose floor

**Composant piston** — `piston-upper/1` : X 4806.9 ; Y 258.55 ; 34.53 × 71.45 ; pose floor

**Composant piston** — `piston-upper/2` : X 4863.47 ; Y 258.55 ; 34.53 × 71.45 ; pose floor

**Composant pipe** — `piston-upper/3` : X 4747.36 ; Y 247.83 ; 149.45 × 6.55 ; pose wall

**Composant gauge** — `piston-upper/4` : X 4848.58 ; Y 288.32 ; 13.69 × 13.69 ; pose wall

**Composant valve** — `piston-upper/5` : X 4787.25 ; Y 298.44 ; 14.29 × 14.29 ; pose wall

**Composant junction** — `piston-upper/6` : X 4789.63 ; Y 265.69 ; 13.69 × 16.67 ; pose wall

**Composant lamp** — `piston-upper/7` : X 4810.47 ; Y 235.33 ; 25.01 × 6.55 ; pose ceiling

**Composant stencil** — `piston-upper/8` : X 4749.15 ; Y 232.95 ; 44.66 × 10.72 ; pose wall

**Composant drain** — `piston-upper/9` : X 4787.85 ; Y 327.02 ; 75.02 × 2.98 ; pose floor

**Raccord** — `piston-upper-lighting-run` : piston-upper/6 → piston-upper/7

### Moule de coulée
`mold` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-mold ; point f161-mold ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant mold** — `mold/0` : X 4787.5 ; Y 468 ; 231 × 42 ; pose floor

**Composant pipe** — `mold/1` : X 4807.5 ; Y 414 ; 195 × 9 ; pose wall

**Composant valve** — `mold/2` : X 4997.5 ; Y 414 ; 26 × 26 ; pose wall

**Composant gauge** — `mold/3` : X 4793.5 ; Y 421 ; 23 × 23 ; pose wall

**Composant lamp** — `mold/4` : X 4840.5 ; Y 367 ; 105 × 12 ; pose ceiling

**Composant grille** — `mold/5` : X 4787.5 ; Y 501 ; 229 × 9 ; pose floor

**Composant stencil** — `mold/6` : X 4861.5 ; Y 391 ; 91 × 20 ; pose wall

**Composant junction** — `mold/7` : X 5032.5 ; Y 439 ; 24 × 37 ; pose wall

**Raccord** — `mold-lighting-run` : mold/7 → mold/4

### Retour hydraulique
`lower-pressure` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-pressure-alcove-v95 ; point f161-pressure-alcove-v95 ; échelle uniforme 0.87 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant pump** — `lower-pressure/0` : X 4706.39 ; Y 560.31 ; 72.3 × 69.69 ; pose floor

**Composant tank** — `lower-pressure/1` : X 4825.73 ; Y 520.24 ; 52.27 × 109.76 ; pose floor

**Composant valve** — `lower-pressure/2` : X 4794.37 ; Y 596.03 ; 23.52 × 23.52 ; pose wall

**Composant gauge** — `lower-pressure/3` : X 4722.07 ; Y 535.92 ; 20.91 × 20.91 ; pose wall

**Composant pipe** — `lower-pressure/4` : X 4768.24 ; Y 604.74 ; 73.17 × 8.71 ; pose wall

**Composant pipe** — `lower-pressure/5` : X 4837.06 ; Y 520.24 ; 6.97 × 16.55 ; pose wall

**Composant junction** — `lower-pressure/6` : X 4689.84 ; Y 575.99 ; 20.04 × 21.78 ; pose wall

**Composant drain** — `lower-pressure/7` : X 4684.61 ; Y 625.64 ; 101.05 × 4.36 ; pose floor

**Composant lamp** — `lower-pressure/8` : X 4768.24 ; Y 499.33 ; 32.23 × 8.71 ; pose ceiling

**Composant stencil** — `lower-pressure/9` : X 4700.29 ; Y 508.92 ; 62.72 × 15.68 ; pose wall

**Raccord** — `lower-pressure-lighting-run` : lower-pressure/6 → lower-pressure/8

### Four principal
`main-furnace` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-furnace ; point f161-furnace ; échelle uniforme 0.57 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant furnace** — `main-furnace/0` : X 5414.57 ; Y 406 ; 101.71 × 104 ; pose floor

**Composant pipe** — `main-furnace/1` : X 5524.86 ; Y 437.43 ; 8 × 65.71 ; pose wall

**Composant gauge** — `main-furnace/2` : X 5522.57 ; Y 454 ; 14.29 × 14.29 ; pose wall

**Composant slag** — `main-furnace/3` : X 5538 ; Y 490 ; 20 × 20 ; pose floor

**Composant lamp** — `main-furnace/4` : X 5408.86 ; Y 399.71 ; 20.57 × 6.29 ; pose ceiling

**Composant stencil** — `main-furnace/5` : X 5526.57 ; Y 418.57 ; 27.43 × 10.86 ; pose wall

**Composant grille** — `main-furnace/6` : X 5412.29 ; Y 503.14 ; 105.71 × 6.86 ; pose floor

**Composant junction** — `main-furnace/7` : X 5539.71 ; Y 459.14 ; 13.14 × 20.57 ; pose wall

**Raccord** — `main-furnace-lighting-run` : main-furnace/7 → main-furnace/4

### Commande de passerelle
`furnace-gantry` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-furnace-high ; point f161-furnace-high ; échelle uniforme 1 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant winch** — `furnace-gantry/0` : X 5270.5 ; Y 262 ; 80 × 68 ; pose floor

**Composant junction** — `furnace-gantry/1` : X 5381.5 ; Y 231 ; 36 × 51 ; pose wall

**Composant pipe** — `furnace-gantry/2` : X 5255.5 ; Y 214 ; 210 × 9 ; pose wall

**Composant valve** — `furnace-gantry/3` : X 5441.5 ; Y 215 ; 26 × 26 ; pose wall

**Composant lamp** — `furnace-gantry/4` : X 5371.5 ; Y 176 ; 38 × 11 ; pose ceiling

**Composant grille** — `furnace-gantry/5` : X 5256.5 ; Y 322 ; 139 × 8 ; pose floor

**Composant stencil** — `furnace-gantry/6` : X 5258.5 ; Y 180 ; 74 × 19 ; pose wall

**Composant support** — `furnace-gantry/7` : X 5355.5 ; Y 306 ; 12 × 24 ; pose floor

**Raccord** — `furnace-gantry-lighting-run` : furnace-gantry/1 → furnace-gantry/4

### Approche de la Compagnie
`parley` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-parley-v93 ; point f161-parley-v93 ; échelle uniforme 0.66 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant winch** — `parley/0` : X 5607.23 ; Y 464.86 ; 53.11 × 45.14 ; pose floor

**Composant junction** — `parley/1` : X 5680.91 ; Y 444.28 ; 23.9 × 33.86 ; pose wall

**Composant pipe** — `parley/2` : X 5597.27 ; Y 433 ; 139.4 × 5.97 ; pose wall

**Composant valve** — `parley/3` : X 5720.74 ; Y 433.66 ; 17.26 × 17.26 ; pose wall

**Composant lamp** — `parley/4` : X 5674.27 ; Y 407.77 ; 25.23 × 7.3 ; pose ceiling

**Composant grille** — `parley/5` : X 5597.93 ; Y 504.69 ; 92.27 × 5.31 ; pose floor

**Composant stencil** — `parley/6` : X 5599.26 ; Y 410.43 ; 49.12 × 12.61 ; pose wall

**Composant support** — `parley/7` : X 5663.65 ; Y 494.07 ; 7.97 × 15.93 ; pose floor

**Raccord** — `parley-lighting-run` : parley/1 → parley/4

### Matériel de récupération
`patna-kit` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-patna-cage-node ; point f161-patna-cage-node ; échelle uniforme 0.31 ; condition company. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant recovery** — `patna-kit/0` : X 5893.16 ; Y 467.15 ; 39.76 × 42.85 ; pose floor

**Composant case** — `patna-kit/1` : X 5939.4 ; Y 497.98 ; 20.65 × 12.02 ; pose floor

**Composant lampstand** — `patna-kit/2` : X 5964.68 ; Y 467.15 ; 8.32 × 42.85 ; pose floor

**Composant monitor** — `patna-kit/3` : X 5941.25 ; Y 486.27 ; 13.25 × 9.25 ; pose wall

**Composant cable** — `patna-kit/4` : X 5930.15 ; Y 505.99 ; 14.8 × 2.47 ; pose wall

**Composant stencil** — `patna-kit/5` : X 5939.09 ; Y 475.78 ; 23.43 × 6.16 ; pose wall

**Composant case** — `patna-kit/6` : X 5887.31 ; Y 499.83 ; 10.79 × 10.17 ; pose floor

**Composant clamp** — `patna-kit/7` : X 5908.89 ; Y 485.65 ; 8.01 × 8.32 ; pose wall

### Plateforme terminale
`final-landing` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-extraction ; point f161-extraction ; échelle uniforme 0.37 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant winch** — `final-landing/0` : X 6010.91 ; Y 485.11 ; 29.28 × 24.89 ; pose floor

**Composant junction** — `final-landing/1` : X 6051.53 ; Y 473.77 ; 13.17 × 18.66 ; pose wall

**Composant pipe** — `final-landing/2` : X 6005.42 ; Y 467.55 ; 76.85 × 3.29 ; pose wall

**Composant valve** — `final-landing/3` : X 6073.49 ; Y 467.91 ; 9.51 × 9.51 ; pose wall

**Composant lamp** — `final-landing/4` : X 6047.87 ; Y 453.64 ; 13.91 × 4.03 ; pose ceiling

**Composant grille** — `final-landing/5` : X 6005.78 ; Y 507.07 ; 50.87 × 2.93 ; pose floor

**Composant stencil** — `final-landing/6` : X 6006.51 ; Y 455.11 ; 27.08 × 6.95 ; pose wall

**Composant support** — `final-landing/7` : X 6042.01 ; Y 501.22 ; 4.39 × 8.78 ; pose floor

**Raccord** — `final-landing-lighting-run` : final-landing/1 → final-landing/4

### Émetteur de service
`final-transmitter` · Assemblages

[Socle V104 conservé] Appui node-platform-f161-final-transmission-v94 ; point f161-final-transmission-v94 ; échelle uniforme 0.67 ; condition always. L’ensemble est en retrait derrière les acteurs, sans collision ajoutée. Son placement ne dépend pas de la hauteur du joueur. Les composants ci-dessous sont des formes du renderer conservé, pas autant de nouveaux assets photographiques.

**Composant console** — `final-transmitter/0` : X 6019.68 ; Y 279.13 ; 89.69 × 50.87 ; pose floor

**Composant rack** — `final-transmitter/1` : X 6138.82 ; Y 240.98 ; 44.18 × 89.02 ; pose floor

**Composant monitor** — `final-transmitter/2` : X 6027.71 ; Y 247.67 ; 34.81 × 25.44 ; pose wall

**Composant monitor** — `final-transmitter/3` : X 6069.88 ; Y 247.67 ; 34.81 × 25.44 ; pose wall

**Composant spool** — `final-transmitter/4` : X 6118.07 ; Y 310.59 ; 19.41 × 19.41 ; pose floor

**Composant junction** — `final-transmitter/5` : X 6114.06 ; Y 257.04 ; 18.07 × 19.41 ; pose wall

**Composant cable** — `final-transmitter/6` : X 6101.34 ; Y 274.44 ; 42.17 × 5.35 ; pose wall

**Composant lamp** — `final-transmitter/7` : X 6028.38 ; Y 229.6 ; 30.12 × 6.69 ; pose ceiling

**Composant stencil** — `final-transmitter/8` : X 6139.49 ; Y 227.59 ; 43.51 × 10.04 ; pose wall

**Composant stool** — `final-transmitter/9` : X 6061.18 ; Y 308.58 ; 16.06 × 21.42 ; pose floor

**Raccord** — `final-transmitter-lighting-run` : final-transmitter/5 → final-transmitter/7

### Raccord — Prise d’air côtière
`coast-intake-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `coast-intake/2` : coast-intake

**Réception** — `coast-intake/6` : always

**Sommet** — `1` : X 249.5 ; Y 489

**Sommet** — `2` : X 249.5 ; Y 359

**Sommet** — `3` : X 147.5 ; Y 359

**Sommet** — `4` : X 147.5 ; Y 370.5

### Raccord — Épave et matériel de secours
`coast-wreck-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `coast-wreck/5` : coast-wreck

**Réception** — `coast-wreck/4` : always

**Sommet** — `1` : X 741.5 ; Y 483

**Sommet** — `2` : X 741.5 ; Y 347

**Sommet** — `3` : X 586 ; Y 347

**Sommet** — `4` : X 586 ; Y 358.5

### Raccord — Baie mortuaire
`morgue-bay-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `morgue-bay/6` : morgue-bay

**Réception** — `morgue-bay/3` : always

**Sommet** — `1` : X 1599.6 ; Y 267.44

**Sommet** — `2` : X 1599.6 ; Y 233.73

**Sommet** — `3` : X 1502.24 ; Y 233.73

**Sommet** — `4` : X 1502.24 ; Y 244.11

### Raccord — Réfectoire
`mess-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `mess/6` : mess

**Réception** — `mess/7` : always

**Sommet** — `1` : X 2414.5 ; Y 295.5

**Sommet** — `2` : X 2414.5 ; Y 210

**Sommet** — `3` : X 2285 ; Y 210

**Sommet** — `4` : X 2285 ; Y 221

### Raccord — Poste de communication
`actual-comms-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `actual-comms/5` : actual-comms

**Réception** — `actual-comms/7` : always

**Sommet** — `1` : X 2741.7 ; Y 290.56

**Sommet** — `2` : X 2741.7 ; Y 250.65

**Sommet** — `3` : X 2666.85 ; Y 250.65

**Sommet** — `4` : X 2666.85 ; Y 258.79

### Raccord — Ventilateur de maintenance
`murphy-fan-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `murphy-fan/2` : murphy-fan

**Réception** — `murphy-fan/7` : always

**Sommet** — `1` : X 2976.22 ; Y 281.5

**Sommet** — `2` : X 2976.22 ; Y 263.61

**Sommet** — `3` : X 2908.9 ; Y 263.61

**Sommet** — `4` : X 2908.9 ; Y 270.66

### Raccord — Pompage des galeries
`service-pump-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `service-pump/6` : service-pump

**Réception** — `service-pump/8` : always

**Sommet** — `1` : X 2978 ; Y 460.5

**Sommet** — `2` : X 2978 ; Y 355

**Sommet** — `3` : X 3075 ; Y 355

**Sommet** — `4` : X 3075 ; Y 365

### Raccord — Entretien des réseaux
`service-shop-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `service-shop/5` : service-shop

**Réception** — `service-shop/4` : always

**Sommet** — `1` : X 3088.93 ; Y 290.14

**Sommet** — `2` : X 3088.93 ; Y 263.09

**Sommet** — `3` : X 3047.51 ; Y 263.09

**Sommet** — `4` : X 3047.51 ; Y 270.54

### Raccord — Recharge des batteries
`battery-store-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `battery-store/5` : battery-store

**Réception** — `battery-store/4` : always

**Sommet** — `1` : X 3540.36 ; Y 245.01

**Sommet** — `2` : X 3540.36 ; Y 193.01

**Sommet** — `3` : X 3452.05 ; Y 193.01

**Sommet** — `4` : X 3452.05 ; Y 203.23

### Raccord — Réserve de produits
`chemical-store-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `chemical-store/0` : chemical-store

**Réception** — `chemical-store/4` : always

**Sommet** — `1` : X 3603.52 ; Y 466.51

**Sommet** — `2` : X 3603.52 ; Y 398.92

**Sommet** — `3` : X 3660.45 ; Y 398.92

**Sommet** — `4` : X 3660.45 ; Y 407.45

### Raccord — Supervision de la fonderie
`command-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `command/5` : command

**Réception** — `command/7` : always

**Sommet** — `1` : X 3981.7 ; Y 450.56

**Sommet** — `2` : X 3981.7 ; Y 410.65

**Sommet** — `3` : X 3906.85 ; Y 410.65

**Sommet** — `4` : X 3906.85 ; Y 418.79

### Raccord — Collecte des effluents
`waste-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `waste/6` : waste

**Réception** — `waste/8` : always

**Sommet** — `1` : X 3978 ; Y 580.5

**Sommet** — `2` : X 3978 ; Y 475

**Sommet** — `3` : X 4075 ; Y 475

**Sommet** — `4` : X 4075 ; Y 485

### Raccord — Alimentation du creuset
`lead-primer-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `lead-primer/6` : lead-primer

**Réception** — `lead-primer/8` : always

**Sommet** — `1` : X 4316.21 ; Y 475.68

**Sommet** — `2` : X 4316.21 ; Y 401

**Sommet** — `3` : X 4383.47 ; Y 401

**Sommet** — `4` : X 4383.47 ; Y 409.47

### Raccord — Collecteur d’eau supérieur
`water-header-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `water-header/6` : water-header

**Réception** — `water-header/8` : always

**Sommet** — `1` : X 4468 ; Y 280.5

**Sommet** — `2` : X 4468 ; Y 175

**Sommet** — `3` : X 4565 ; Y 175

**Sommet** — `4` : X 4565 ; Y 185

### Raccord — Pistons supérieurs
`piston-upper-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `piston-upper/6` : piston-upper

**Réception** — `piston-upper/7` : always

**Sommet** — `1` : X 4796.48 ; Y 274.03

**Sommet** — `2` : X 4796.48 ; Y 230.33

**Sommet** — `3` : X 4822.98 ; Y 230.33

**Sommet** — `4` : X 4822.98 ; Y 238.6

### Raccord — Moule de coulée
`mold-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `mold/7` : mold

**Réception** — `mold/4` : always

**Sommet** — `1` : X 5044.5 ; Y 457.5

**Sommet** — `2` : X 5044.5 ; Y 362

**Sommet** — `3` : X 4893 ; Y 362

**Sommet** — `4` : X 4893 ; Y 373

### Raccord — Retour hydraulique
`lower-pressure-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `lower-pressure/6` : lower-pressure

**Réception** — `lower-pressure/8` : always

**Sommet** — `1` : X 4699.86 ; Y 586.88

**Sommet** — `2` : X 4699.86 ; Y 494.33

**Sommet** — `3` : X 4784.36 ; Y 494.33

**Sommet** — `4` : X 4784.36 ; Y 503.69

### Raccord — Four principal
`main-furnace-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `main-furnace/7` : main-furnace

**Réception** — `main-furnace/4` : always

**Sommet** — `1` : X 5546.29 ; Y 469.43

**Sommet** — `2` : X 5546.29 ; Y 394.71

**Sommet** — `3` : X 5419.14 ; Y 394.71

**Sommet** — `4` : X 5419.14 ; Y 402.86

### Raccord — Commande de passerelle
`furnace-gantry-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `furnace-gantry/1` : furnace-gantry

**Réception** — `furnace-gantry/4` : always

**Sommet** — `1` : X 5399.5 ; Y 256.5

**Sommet** — `2` : X 5399.5 ; Y 171

**Sommet** — `3` : X 5390.5 ; Y 171

**Sommet** — `4` : X 5390.5 ; Y 181.5

### Raccord — Approche de la Compagnie
`parley-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `parley/1` : parley

**Réception** — `parley/4` : always

**Sommet** — `1` : X 5692.86 ; Y 461.21

**Sommet** — `2` : X 5692.86 ; Y 402.77

**Sommet** — `3` : X 5686.89 ; Y 402.77

**Sommet** — `4` : X 5686.89 ; Y 411.42

### Raccord — Plateforme terminale
`final-landing-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `final-landing/1` : final-landing

**Réception** — `final-landing/4` : always

**Sommet** — `1` : X 6058.11 ; Y 483.1

**Sommet** — `2` : X 6058.11 ; Y 448.64

**Sommet** — `3` : X 6054.82 ; Y 448.64

**Sommet** — `4` : X 6054.82 ; Y 455.66

### Raccord — Émetteur de service
`final-transmitter-lighting-run` · Réseaux

[Socle V104 conservé] Liaison électrique locale, décorative. Les extrémités référencent des composants existants du même ensemble. Le tracé suit les points ci-dessous. Aucune consommation, panne globale ou modification de mission n’est simulée par ce raccord.

**Source** — `final-transmitter/5` : final-transmitter

**Réception** — `final-transmitter/7` : always

**Sommet** — `1` : X 6123.09 ; Y 266.75

**Sommet** — `2` : X 6123.09 ; Y 224.6

**Sommet** — `3` : X 6043.44 ; Y 224.6

**Sommet** — `4` : X 6043.44 ; Y 232.94

### Éclairage de la prise d’air
`shore-light` · Commandes

[Socle V104 conservé] Action I ; support node-platform-f161-spawn, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

**Commande** — `shore-light` : X 259.5 ; Y 456 ; 13 × 29

**Lampe** — `coast-intake/6` : Récepteur réellement dessiné

### Lampe de soin
`care-light` · Commandes

[Socle V104 conservé] Action I ; support node-platform-f161-infirmary, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

**Commande** — `care-light` : X 1225 ; Y 456 ; 13 × 29

**Lampe** — `medical-care/7` : Récepteur réellement dessiné

**Ronde originale** — `1` : Doit être rallumée à son tour. La même commande hors ronde ne termine aucune quête.

### Éclairage de la coursive
`cell-light` · Commandes

[Socle V104 conservé] Action I ; support node-platform-f161-cell-a, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

**Commande** — `cell-light` : X 2020 ; Y 456 ; 13 × 29

**Lampe** — `cell-a/3` : Récepteur réellement dessiné

**Ronde originale** — `2` : Doit être rallumée à son tour. La même commande hors ronde ne termine aucune quête.

### Lampe des communications
`comms-light` · Commandes

[Socle V104 conservé] Action I ; support node-platform-f161-comms-high, pied Y 350 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

**Commande** — `comms-light` : X 2785 ; Y 296 ; 13 × 29

**Lampe** — `actual-comms/7` : Récepteur réellement dessiné

### Lampe de l’établi
`service-light` · Commandes

[Socle V104 conservé] Action I ; support node-platform-f161-service-high, pied Y 330 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

**Commande** — `service-light` : X 3110 ; Y 276 ; 13 × 29

**Lampe** — `service-shop/4` : Récepteur réellement dessiné

**Ronde originale** — `3` : Doit être rallumée à son tour. La même commande hors ronde ne termine aucune quête.

### Éclairage du creuset
`lead-light` · Commandes

[Socle V104 conservé] Action I ; support node-platform-f161-leadworks, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

**Commande** — `lead-light` : X 4265 ; Y 456 ; 13 × 29

**Lampe** — `leadworks/7` : Récepteur réellement dessiné

### Lampe du moule
`mold-light` · Commandes

[Socle V104 conservé] Action I ; support node-platform-f161-mold, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

**Commande** — `mold-light` : X 5043.5 ; Y 456 ; 13 × 29

**Lampe** — `mold/4` : Récepteur réellement dessiné

### Éclairage de la plateforme
`landing-light` · Commandes

[Socle V104 conservé] Action I ; support node-platform-f161-extraction, pied Y 510 et profondeur 1. La portée, l’étage, la profondeur courante et les portes fermées conditionnent l’interaction. V104 refuse aussi le déclenchement depuis une profondeur encore en transition. Le changement touche ses luminaires et halos, pas la furtivité ni le réseau de coulée. Les états allumé/éteint sont sauvegardés. Extension V106 : dans une séquence de chasse originale active, l’éclairage participe aussi à la reconnaissance du Runner. Hors de ce pilote, le comportement de base reste inchangé.

**Commande** — `landing-light` : X 6070 ; Y 456 ; 13 × 29

**Lampe** — `final-landing/4` : Récepteur réellement dessiné

### Accès aux cellules
`f161-infirmary-gate` · Portes

[Socle V104 conservé] Porte historique. Cadre, feuille et seuil suivent ses dimensions ; le dessin ne crée ni nouveau verrou ni nouvelle condition d’ouverture. Une feuille ouverte ne reste pas opaque devant le chemin. La fermeture peut refuser un contact du Runner et l’accès à une commande située derrière.

**Départ** — `f161-infirmary` : Sol 510

**Arrivée** — `f161-cell-a` : Sol 510

**Cadre** — `f161-infirmary-gate` : X 1488 ; Y 378 ; 44 × 132

**Source** — `template-derived` : Géométrie native utilisée si fournie au compilateur.

### Galeries de service
`f161-cellblock-gate` · Portes

[Socle V104 conservé] Porte historique. Cadre, feuille et seuil suivent ses dimensions ; le dessin ne crée ni nouveau verrou ni nouvelle condition d’ouverture. Une feuille ouverte ne reste pas opaque devant le chemin. La fermeture peut refuser un contact du Runner et l’accès à une commande située derrière.

**Départ** — `f161-cell-b` : Sol 510

**Arrivée** — `f161-service-low` : Sol 510

**Cadre** — `f161-cellblock-gate` : X 2823 ; Y 378 ; 44 × 132

**Source** — `template-derived` : Géométrie native utilisée si fournie au compilateur.

### Accès à la fonderie
`f161-leadworks-gate` · Portes

[Socle V104 conservé] Porte historique. Cadre, feuille et seuil suivent ses dimensions ; le dessin ne crée ni nouveau verrou ni nouvelle condition d’ouverture. Une feuille ouverte ne reste pas opaque devant le chemin. La fermeture peut refuser un contact du Runner et l’accès à une commande située derrière.

**Départ** — `f161-bishop` : Sol 510

**Arrivée** — `f161-leadworks` : Sol 510

**Cadre** — `f161-leadworks-gate` : X 3828 ; Y 378 ; 44 × 132

**Source** — `template-derived` : Géométrie native utilisée si fournie au compilateur.

### spawn
`f161-spawn` · Points

[Socle V104 conservé] Position X 180, pied Y 510, largeur 260. Section descriptive : Côte et épave. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-eev` : Marche ; f161-e01

### eev
`f161-eev` · Points

[Socle V104 conservé] Position X 620, pied Y 510, largeur 300. Section descriptive : Côte et épave. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-spawn` : Marche ; f161-e01

**Voisin** — `f161-infirmary` : Marche ; f161-e02

**Voisin** — `f161-flight-analysis-v94` : Échelle ; f161-e89

**Voisin** — `f161-wreckage-incident-v94` : Échelle ; f161-e91

### infirmary
`f161-infirmary` · Points

[Socle V104 conservé] Position X 1120, pied Y 510, largeur 300. Section descriptive : Infirmerie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-eev` : Marche ; f161-e02

**Voisin** — `f161-cell-a` : Porte ; f161-e03

**Voisin** — `f161-morgue-high` : Échelle ; f161-e12

**Voisin** — `f161-service-deep` : Conduit ; f161-e19

**Voisin** — `f161-clemens-bed` : Marche ; f161-e46

**Voisin** — `f161-wreckage-incident-v94` : Échelle ; f161-e92

### morgue high
`f161-morgue-high` · Points

[Socle V104 conservé] Position X 1500, pied Y 350, largeur 260. Section descriptive : Morgue et dossiers. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-infirmary` : Échelle ; f161-e12

**Voisin** — `f161-mess-high` : Marche ; f161-e13

**Voisin** — `f161-funeral-walk` : Échelle ; f161-e48

**Voisin** — `f161-master-archive-node` : Marche ; f161-e62

**Voisin** — `f161-flight-analysis-v94` : Marche ; f161-e90

### cell a
`f161-cell-a` · Points

[Socle V104 conservé] Position X 1900, pied Y 510, largeur 300. Section descriptive : Cellules ouest. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-infirmary` : Porte ; f161-e03

**Voisin** — `f161-mess-high` : Échelle ; f161-e23

**Voisin** — `f161-assembly-hall` : Marche ; f161-e27

**Voisin** — `f161-shelter-cell-v95` : Échelle ; f161-e104

### mess high
`f161-mess-high` · Points

[Socle V104 conservé] Position X 2320, pied Y 350, largeur 280. Section descriptive : Réfectoire. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-morgue-high` : Marche ; f161-e13

**Voisin** — `f161-service-high` : Marche ; f161-e14

**Voisin** — `f161-cell-a` : Échelle ; f161-e23

**Voisin** — `f161-assembly-hall` : Échelle ; f161-e29

**Voisin** — `f161-mess-ceiling` : Marche ; f161-e49

**Voisin** — `f161-faith-dais-v94` : Échelle ; f161-e93

### cell b
`f161-cell-b` · Points

[Socle V104 conservé] Position X 2620, pied Y 510, largeur 300. Section descriptive : Cellules est. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-service-low` : Porte ; f161-e05

**Voisin** — `f161-assembly-hall` : Marche ; f161-e28

**Voisin** — `f161-shutter-cell-node` : Marche ; f161-e63

### service low
`f161-service-low` · Points

[Socle V104 conservé] Position X 3070, pied Y 510, largeur 300. Section descriptive : Pompage et secours. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-cell-b` : Porte ; f161-e05

**Voisin** — `f161-bishop` : Marche ; f161-e06

**Voisin** — `f161-service-high` : Échelle ; f161-e24

**Voisin** — `f161-service-deep` : Échelle ; f161-e25

**Voisin** — `f161-fuel-manifold-a` : Marche ; f161-e35

**Voisin** — `f161-rescue-post-node` : Marche ; f161-e67

### service high
`f161-service-high` · Points

[Socle V104 conservé] Position X 3070, pied Y 330, largeur 280. Section descriptive : Ventilation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-mess-high` : Marche ; f161-e14

**Voisin** — `f161-tunnel-high` : Marche ; f161-e15

**Voisin** — `f161-service-low` : Échelle ; f161-e24

**Voisin** — `f161-fan-shaft` : Marche ; f161-e51

**Voisin** — `f161-steam-service-node` : Marche ; f161-e65

**Voisin** — `f161-perch-service-v93` : Échelle ; f161-e80

**Voisin** — `f161-battery-locker-v94` : Marche ; f161-e95

**Voisin** — `f161-hunt-service-v95` : Marche ; f161-e110

### service deep
`f161-service-deep` · Points

[Socle V104 conservé] Position X 3070, pied Y 630, largeur 280. Section descriptive : Galeries basses. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-infirmary` : Conduit ; f161-e19

**Voisin** — `f161-tunnel-low` : Marche ; f161-e20

**Voisin** — `f161-service-low` : Échelle ; f161-e25

**Voisin** — `f161-tunnel-shrine` : Marche ; f161-e52

**Voisin** — `f161-refuge-service-v95` : Marche ; f161-e108

### bishop
`f161-bishop` · Points

[Socle V104 conservé] Position X 3500, pied Y 510, largeur 300. Section descriptive : Pompage et secours. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-service-low` : Marche ; f161-e06

**Voisin** — `f161-leadworks` : Porte ; f161-e07

**Voisin** — `f161-fuel-manifold-b` : Marche ; f161-e37

**Voisin** — `f161-chemical-store` : Marche ; f161-e38

**Voisin** — `f161-tunnel-shrine` : Échelle ; f161-e53

**Voisin** — `f161-rescue-post-node` : Marche ; f161-e68

**Voisin** — `f161-shutter-service-node` : Marche ; f161-e69

### tunnel high
`f161-tunnel-high` · Points

[Socle V104 conservé] Position X 3820, pied Y 330, largeur 280. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-service-high` : Marche ; f161-e15

**Voisin** — `f161-sprinkler` : Marche ; f161-e16

**Voisin** — `f161-chemical-store` : Échelle ; f161-e39

**Voisin** — `f161-command-post-node` : Échelle ; f161-e71

**Voisin** — `f161-battery-locker-v94` : Marche ; f161-e96

**Voisin** — `f161-battery-junction-v94` : Marche ; f161-e99

### tunnel low
`f161-tunnel-low` · Points

[Socle V104 conservé] Position X 3820, pied Y 630, largeur 280. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-service-deep` : Marche ; f161-e20

**Voisin** — `f161-leadworks` : Échelle ; f161-e21

**Voisin** — `f161-waste-tank` : Marche ; f161-e30

**Voisin** — `f161-golic-cache-v94` : Marche ; f161-e98

**Voisin** — `f161-hunt-junction-v95` : Marche ; f161-e114

### leadworks
`f161-leadworks` · Points

[Socle V104 conservé] Position X 4200, pied Y 510, largeur 340. Section descriptive : Fonderie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-bishop` : Porte ; f161-e07

**Voisin** — `f161-mold` : Marche ; f161-e08

**Voisin** — `f161-tunnel-low` : Échelle ; f161-e21

**Voisin** — `f161-furnace` : Conduit ; f161-e22

**Voisin** — `f161-sprinkler` : Échelle ; f161-e26

**Voisin** — `f161-sluice-low` : Échelle ; f161-e32

**Voisin** — `f161-lead-primer` : Marche ; f161-e40

**Voisin** — `f161-piston-a-node` : Marche ; f161-e54

**Voisin** — `f161-command-post-node` : Marche ; f161-e72

### sprinkler
`f161-sprinkler` · Points

[Socle V104 conservé] Position X 4560, pied Y 330, largeur 280. Section descriptive : Collecteur supérieur. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-tunnel-high` : Marche ; f161-e16

**Voisin** — `f161-furnace-high` : Marche ; f161-e17

**Voisin** — `f161-leadworks` : Échelle ; f161-e26

**Voisin** — `f161-water-header` : Marche ; f161-e42

**Voisin** — `f161-piston-b-node` : Marche ; f161-e56

**Voisin** — `f161-bait-switch-v95` : Marche ; f161-e117

### mold
`f161-mold` · Points

[Socle V104 conservé] Position X 4920, pied Y 510, largeur 360. Section descriptive : Moule et pistons. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-leadworks` : Marche ; f161-e08

**Voisin** — `f161-furnace` : Marche ; f161-e09

**Voisin** — `f161-lead-primer` : Marche ; f161-e41

**Voisin** — `f161-water-header` : Échelle ; f161-e43

**Voisin** — `f161-piston-a-node` : Marche ; f161-e55

**Voisin** — `f161-piston-b-node` : Échelle ; f161-e57

**Voisin** — `f161-piston-c-node` : Marche ; f161-e58

**Voisin** — `f161-shutter-foundry-node` : Marche ; f161-e75

**Voisin** — `f161-chase-reroute-v94` : Échelle ; f161-e101

### furnace high
`f161-furnace-high` · Points

[Socle V104 conservé] Position X 5350, pied Y 330, largeur 280. Section descriptive : Passerelles du four. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-sprinkler` : Marche ; f161-e17

**Voisin** — `f161-furnace` : Échelle ; f161-e18

**Voisin** — `f161-furnace-gantry` : Marche ; f161-e33

**Voisin** — `f161-furnace-overlook` : Marche ; f161-e44

**Voisin** — `f161-chase-observer-v95` : Marche ; f161-e119

### furnace
`f161-furnace` · Points

[Socle V104 conservé] Position X 5480, pied Y 510, largeur 340. Section descriptive : Four principal. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-mold` : Marche ; f161-e09

**Voisin** — `f161-company` : Marche ; f161-e10

**Voisin** — `f161-furnace-high` : Échelle ; f161-e18

**Voisin** — `f161-leadworks` : Conduit ; f161-e22

**Voisin** — `f161-piston-c-node` : Marche ; f161-e59

**Voisin** — `f161-parley-v93` : Marche ; f161-e85

**Voisin** — `f161-chase-reroute-v94` : Échelle ; f161-e102

### company
`f161-company` · Points

[Socle V104 conservé] Position X 5800, pied Y 510, largeur 300. Section descriptive : Approche et plateforme. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-furnace` : Marche ; f161-e10

**Voisin** — `f161-extraction` : Marche ; f161-e11

**Voisin** — `f161-furnace-gantry` : Échelle ; f161-e34

**Voisin** — `f161-furnace-overlook` : Échelle ; f161-e45

**Voisin** — `f161-patna-cage-node` : Marche ; f161-e60

**Voisin** — `f161-parley-v93` : Marche ; f161-e86

**Voisin** — `f161-witness-v93` : Échelle ; f161-e87

### extraction
`f161-extraction` · Points

[Socle V104 conservé] Position X 6040, pied Y 510, largeur 300. Section descriptive : Approche et plateforme. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-company` : Marche ; f161-e11

**Voisin** — `f161-patna-cage-node` : Marche ; f161-e61

**Voisin** — `f161-witness-v93` : Échelle ; f161-e88

### assembly hall
`f161-assembly-hall` · Points

[Socle V104 conservé] Position X 2300, pied Y 510, largeur 300. Section descriptive : Cellules ouest. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-cell-a` : Marche ; f161-e27

**Voisin** — `f161-cell-b` : Marche ; f161-e28

**Voisin** — `f161-mess-high` : Échelle ; f161-e29

**Voisin** — `f161-shelter-cell-v95` : Échelle ; f161-e105

### waste tank
`f161-waste-tank` · Points

[Socle V104 conservé] Position X 4070, pied Y 630, largeur 310. Section descriptive : Cuve et évacuation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-tunnel-low` : Marche ; f161-e30

**Voisin** — `f161-sluice-low` : Marche ; f161-e31

**Voisin** — `f161-hunt-junction-v95` : Marche ; f161-e115

### sluice low
`f161-sluice-low` · Points

[Socle V104 conservé] Position X 4500, pied Y 630, largeur 280. Section descriptive : Cuve et évacuation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-waste-tank` : Marche ; f161-e31

**Voisin** — `f161-leadworks` : Échelle ; f161-e32

### furnace gantry
`f161-furnace-gantry` · Points

[Socle V104 conservé] Position X 5740, pied Y 330, largeur 280. Section descriptive : Passerelles du four. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-furnace-high` : Marche ; f161-e33

**Voisin** — `f161-company` : Échelle ; f161-e34

### fuel manifold a
`f161-fuel-manifold-a` · Points

[Socle V104 conservé] Position X 2960, pied Y 510, largeur 180. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-service-low` : Marche ; f161-e35

**Voisin** — `f161-fuel-manifold-b` : Marche ; f161-e36

### fuel manifold b
`f161-fuel-manifold-b` · Points

[Socle V104 conservé] Position X 3240, pied Y 510, largeur 180. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-fuel-manifold-a` : Marche ; f161-e36

**Voisin** — `f161-bishop` : Marche ; f161-e37

### chemical store
`f161-chemical-store` · Points

[Socle V104 conservé] Position X 3670, pied Y 510, largeur 210. Section descriptive : Réserve et supervision. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-bishop` : Marche ; f161-e38

**Voisin** — `f161-tunnel-high` : Échelle ; f161-e39

**Voisin** — `f161-shutter-service-node` : Marche ; f161-e70

### lead primer
`f161-lead-primer` · Points

[Socle V104 conservé] Position X 4380, pied Y 510, largeur 190. Section descriptive : Fonderie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-leadworks` : Marche ; f161-e40

**Voisin** — `f161-mold` : Marche ; f161-e41

### water header
`f161-water-header` · Points

[Socle V104 conservé] Position X 4690, pied Y 330, largeur 190. Section descriptive : Collecteur supérieur. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-sprinkler` : Marche ; f161-e42

**Voisin** — `f161-mold` : Échelle ; f161-e43

**Voisin** — `f161-steam-lead-node` : Marche ; f161-e73

**Voisin** — `f161-battery-junction-v94` : Marche ; f161-e100

### furnace overlook
`f161-furnace-overlook` · Points

[Socle V104 conservé] Position X 5580, pied Y 330, largeur 220. Section descriptive : Passerelles du four. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-furnace-high` : Marche ; f161-e44

**Voisin** — `f161-company` : Échelle ; f161-e45

### clemens bed
`f161-clemens-bed` · Points

[Socle V104 conservé] Position X 1380, pied Y 510, largeur 180. Section descriptive : Infirmerie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-infirmary` : Marche ; f161-e46

**Voisin** — `f161-funeral-walk` : Marche ; f161-e47

### funeral walk
`f161-funeral-walk` · Points

[Socle V104 conservé] Position X 1580, pied Y 510, largeur 180. Section descriptive : Infirmerie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-clemens-bed` : Marche ; f161-e47

**Voisin** — `f161-morgue-high` : Échelle ; f161-e48

### mess ceiling
`f161-mess-ceiling` · Points

[Socle V104 conservé] Position X 2470, pied Y 350, largeur 190. Section descriptive : Réfectoire. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-mess-high` : Marche ; f161-e49

**Voisin** — `f161-comms-high` : Marche ; f161-e50

**Voisin** — `f161-perch-cell-v93` : Échelle ; f161-e77

### comms high
`f161-comms-high` · Points

[Socle V104 conservé] Position X 2720, pied Y 350, largeur 180. Section descriptive : Communications. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-mess-ceiling` : Marche ; f161-e50

**Voisin** — `f161-shutter-cell-node` : Échelle ; f161-e64

**Voisin** — `f161-perch-cell-v93` : Échelle ; f161-e78

**Voisin** — `f161-watch-cell-v95` : Échelle ; f161-e107

### fan shaft
`f161-fan-shaft` · Points

[Socle V104 conservé] Position X 2940, pied Y 330, largeur 170. Section descriptive : Ventilation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-service-high` : Marche ; f161-e51

**Voisin** — `f161-steam-service-node` : Marche ; f161-e66

### tunnel shrine
`f161-tunnel-shrine` · Points

[Socle V104 conservé] Position X 3420, pied Y 630, largeur 210. Section descriptive : Galeries basses. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-service-deep` : Marche ; f161-e52

**Voisin** — `f161-bishop` : Échelle ; f161-e53

**Voisin** — `f161-golic-cache-v94` : Marche ; f161-e97

**Voisin** — `f161-refuge-service-v95` : Marche ; f161-e109

### piston a node
`f161-piston-a-node` · Points

[Socle V104 conservé] Position X 4480, pied Y 510, largeur 180. Section descriptive : Fonderie. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-leadworks` : Marche ; f161-e54

**Voisin** — `f161-mold` : Marche ; f161-e55

### piston b node
`f161-piston-b-node` · Points

[Socle V104 conservé] Position X 4820, pied Y 330, largeur 180. Section descriptive : Collecteur supérieur. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-sprinkler` : Marche ; f161-e56

**Voisin** — `f161-mold` : Échelle ; f161-e57

**Voisin** — `f161-steam-lead-node` : Marche ; f161-e74

**Voisin** — `f161-perch-lead-v93` : Échelle ; f161-e84

### piston c node
`f161-piston-c-node` · Points

[Socle V104 conservé] Position X 5140, pied Y 510, largeur 180. Section descriptive : Moule et pistons. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-mold` : Marche ; f161-e58

**Voisin** — `f161-furnace` : Marche ; f161-e59

**Voisin** — `f161-shutter-foundry-node` : Marche ; f161-e76

### patna cage node
`f161-patna-cage-node` · Points

[Socle V104 conservé] Position X 5930, pied Y 510, largeur 160. Section descriptive : Approche et plateforme. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-company` : Marche ; f161-e60

**Voisin** — `f161-extraction` : Marche ; f161-e61

### master archive node
`f161-master-archive-node` · Points

[Socle V104 conservé] Position X 1260, pied Y 350, largeur 170. Section descriptive : Morgue et dossiers. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-morgue-high` : Marche ; f161-e62

### shutter cell node
`f161-shutter-cell-node` · Points

[Socle V104 conservé] Position X 2740, pied Y 510, largeur 160. Section descriptive : Cellules est. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-cell-b` : Marche ; f161-e63

**Voisin** — `f161-comms-high` : Échelle ; f161-e64

### steam service node
`f161-steam-service-node` · Points

[Socle V104 conservé] Position X 3190, pied Y 330, largeur 160. Section descriptive : Ventilation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-service-high` : Marche ; f161-e65

**Voisin** — `f161-fan-shaft` : Marche ; f161-e66

**Voisin** — `f161-perch-service-v93` : Échelle ; f161-e79

### rescue post node
`f161-rescue-post-node` · Points

[Socle V104 conservé] Position X 3330, pied Y 510, largeur 170. Section descriptive : Pompage et secours. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-service-low` : Marche ; f161-e67

**Voisin** — `f161-bishop` : Marche ; f161-e68

**Voisin** — `f161-triage-v93` : Marche ; f161-e81

### shutter service node
`f161-shutter-service-node` · Points

[Socle V104 conservé] Position X 3650, pied Y 510, largeur 160. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-bishop` : Marche ; f161-e69

**Voisin** — `f161-chemical-store` : Marche ; f161-e70

**Voisin** — `f161-triage-v93` : Marche ; f161-e82

**Voisin** — `f161-triage-overflow-v95` : Marche ; f161-e113

### command post node
`f161-command-post-node` · Points

[Socle V104 conservé] Position X 3960, pied Y 510, largeur 180. Section descriptive : Réserve et supervision. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-tunnel-high` : Échelle ; f161-e71

**Voisin** — `f161-leadworks` : Marche ; f161-e72

### steam lead node
`f161-steam-lead-node` · Points

[Socle V104 conservé] Position X 4710, pied Y 330, largeur 160. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-water-header` : Marche ; f161-e73

**Voisin** — `f161-piston-b-node` : Marche ; f161-e74

**Voisin** — `f161-perch-lead-v93` : Échelle ; f161-e83

### shutter foundry node
`f161-shutter-foundry-node` · Points

[Socle V104 conservé] Position X 5050, pied Y 510, largeur 160. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-mold` : Marche ; f161-e75

**Voisin** — `f161-piston-c-node` : Marche ; f161-e76

### perch cell v93
`f161-perch-cell-v93` · Points

[Socle V104 conservé] Position X 2500, pied Y 190, largeur 170. Section descriptive : Recueillement. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-mess-ceiling` : Échelle ; f161-e77

**Voisin** — `f161-comms-high` : Échelle ; f161-e78

**Voisin** — `f161-faith-dais-v94` : Marche ; f161-e94

**Voisin** — `f161-watch-cell-v95` : Marche ; f161-e106

### perch service v93
`f161-perch-service-v93` · Points

[Socle V104 conservé] Position X 3310, pied Y 190, largeur 170. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-steam-service-node` : Échelle ; f161-e79

**Voisin** — `f161-service-high` : Échelle ; f161-e80

### triage v93
`f161-triage-v93` · Points

[Socle V104 conservé] Position X 3490, pied Y 510, largeur 190. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-rescue-post-node` : Marche ; f161-e81

**Voisin** — `f161-shutter-service-node` : Marche ; f161-e82

**Voisin** — `f161-triage-overflow-v95` : Marche ; f161-e112

### perch lead v93
`f161-perch-lead-v93` · Points

[Socle V104 conservé] Position X 4720, pied Y 190, largeur 170. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-steam-lead-node` : Échelle ; f161-e83

**Voisin** — `f161-piston-b-node` : Échelle ; f161-e84

### parley v93
`f161-parley-v93` · Points

[Socle V104 conservé] Position X 5660, pied Y 510, largeur 180. Section descriptive : Four principal. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-furnace` : Marche ; f161-e85

**Voisin** — `f161-company` : Marche ; f161-e86

### witness v93
`f161-witness-v93` · Points

[Socle V104 conservé] Position X 6030, pied Y 330, largeur 170. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-company` : Échelle ; f161-e87

**Voisin** — `f161-extraction` : Échelle ; f161-e88

**Voisin** — `f161-final-transmission-v94` : Marche ; f161-e103

**Voisin** — `f161-archive-checksum-v95` : Échelle ; f161-e120

### flight analysis v94
`f161-flight-analysis-v94` · Points

[Socle V104 conservé] Position X 780, pied Y 330, largeur 220. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-eev` : Échelle ; f161-e89

**Voisin** — `f161-morgue-high` : Marche ; f161-e90

### wreckage incident v94
`f161-wreckage-incident-v94` · Points

[Socle V104 conservé] Position X 820, pied Y 630, largeur 220. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-eev` : Échelle ; f161-e91

**Voisin** — `f161-infirmary` : Échelle ; f161-e92

### faith dais v94
`f161-faith-dais-v94` · Points

[Socle V104 conservé] Position X 2180, pied Y 190, largeur 250. Section descriptive : Recueillement. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-mess-high` : Échelle ; f161-e93

**Voisin** — `f161-perch-cell-v93` : Marche ; f161-e94

### battery locker v94
`f161-battery-locker-v94` · Points

[Socle V104 conservé] Position X 3500, pied Y 330, largeur 250. Section descriptive : Atelier des batteries. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-service-high` : Marche ; f161-e95

**Voisin** — `f161-tunnel-high` : Marche ; f161-e96

**Voisin** — `f161-hunt-service-v95` : Marche ; f161-e111

### golic cache v94
`f161-golic-cache-v94` · Points

[Socle V104 conservé] Position X 3660, pied Y 630, largeur 230. Section descriptive : Galeries basses. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-tunnel-shrine` : Marche ; f161-e97

**Voisin** — `f161-tunnel-low` : Marche ; f161-e98

### battery junction v94
`f161-battery-junction-v94` · Points

[Socle V104 conservé] Position X 4020, pied Y 330, largeur 250. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-tunnel-high` : Marche ; f161-e99

**Voisin** — `f161-water-header` : Marche ; f161-e100

**Voisin** — `f161-bait-switch-v95` : Marche ; f161-e116

### chase reroute v94
`f161-chase-reroute-v94` · Points

[Socle V104 conservé] Position X 5050, pied Y 630, largeur 250. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-mold` : Échelle ; f161-e101

**Voisin** — `f161-furnace` : Échelle ; f161-e102

**Voisin** — `f161-pressure-alcove-v95` : Marche ; f161-e118

### final transmission v94
`f161-final-transmission-v94` · Points

[Socle V104 conservé] Position X 6100, pied Y 330, largeur 190. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-witness-v93` : Marche ; f161-e103

### shelter cell v95
`f161-shelter-cell-v95` · Points

[Socle V104 conservé] Position X 2050, pied Y 630, largeur 220. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-cell-a` : Échelle ; f161-e104

**Voisin** — `f161-assembly-hall` : Échelle ; f161-e105

### watch cell v95
`f161-watch-cell-v95` · Points

[Socle V104 conservé] Position X 2660, pied Y 190, largeur 190. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-perch-cell-v93` : Marche ; f161-e106

**Voisin** — `f161-comms-high` : Échelle ; f161-e107

### refuge service v95
`f161-refuge-service-v95` · Points

[Socle V104 conservé] Position X 2990, pied Y 630, largeur 230. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-service-deep` : Marche ; f161-e108

**Voisin** — `f161-tunnel-shrine` : Marche ; f161-e109

### hunt service v95
`f161-hunt-service-v95` · Points

[Socle V104 conservé] Position X 3370, pied Y 330, largeur 210. Section descriptive : Atelier des batteries. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-service-high` : Marche ; f161-e110

**Voisin** — `f161-battery-locker-v94` : Marche ; f161-e111

### triage overflow v95
`f161-triage-overflow-v95` · Points

[Socle V104 conservé] Position X 3600, pied Y 510, largeur 220. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-triage-v93` : Marche ; f161-e112

**Voisin** — `f161-shutter-service-node` : Marche ; f161-e113

### hunt junction v95
`f161-hunt-junction-v95` · Points

[Socle V104 conservé] Position X 3900, pied Y 630, largeur 210. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-tunnel-low` : Marche ; f161-e114

**Voisin** — `f161-waste-tank` : Marche ; f161-e115

### bait switch v95
`f161-bait-switch-v95` · Points

[Socle V104 conservé] Position X 4320, pied Y 330, largeur 210. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-battery-junction-v94` : Marche ; f161-e116

**Voisin** — `f161-sprinkler` : Marche ; f161-e117

### pressure alcove v95
`f161-pressure-alcove-v95` · Points

[Socle V104 conservé] Position X 4780, pied Y 630, largeur 220. Section descriptive : Cuve et évacuation. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-chase-reroute-v94` : Marche ; f161-e118

### chase observer v95
`f161-chase-observer-v95` · Points

[Socle V104 conservé] Position X 5280, pied Y 330, largeur 210. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-furnace-high` : Marche ; f161-e119

### archive checksum v95
`f161-archive-checksum-v95` · Points

[Socle V104 conservé] Position X 5960, pied Y 190, largeur 190. Section descriptive : point de liaison du graphe, hors section nommée. La découverte exige une proximité physique au bon niveau ; l’ouverture du plan seule n’ajoute aucune visite.

**Voisin** — `f161-witness-v93` : Échelle ; f161-e120

### Marche — f161-e01
`f161-e01` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-spawn` : (180, 510)

**Arrivée** — `f161-eev` : (620, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e02
`f161-e02` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-eev` : (620, 510)

**Arrivée** — `f161-infirmary` : (1120, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Porte — f161-e03
`f161-e03` · Connexions

[Socle V104 conservé] Porte entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-infirmary` : (1120, 510)

**Arrivée** — `f161-cell-a` : (1900, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Porte — f161-e05
`f161-e05` · Connexions

[Socle V104 conservé] Porte entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-cell-b` : (2620, 510)

**Arrivée** — `f161-service-low` : (3070, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e06
`f161-e06` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-service-low` : (3070, 510)

**Arrivée** — `f161-bishop` : (3500, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Porte — f161-e07
`f161-e07` · Connexions

[Socle V104 conservé] Porte entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-bishop` : (3500, 510)

**Arrivée** — `f161-leadworks` : (4200, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

**Groupe V111** — `v111-doors` : Longueur canonique 700.00 unités avec approches d’échelle. La géométrie physique des portes est testée sur chaque segment.

### Marche — f161-e08
`f161-e08` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-leadworks` : (4200, 510)

**Arrivée** — `f161-mold` : (4920, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e09
`f161-e09` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-mold` : (4920, 510)

**Arrivée** — `f161-furnace` : (5480, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e10
`f161-e10` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-furnace` : (5480, 510)

**Arrivée** — `f161-company` : (5800, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e11
`f161-e11` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-company` : (5800, 510)

**Arrivée** — `f161-extraction` : (6040, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e12
`f161-e12` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-infirmary` : (1120, 510)

**Arrivée** — `f161-morgue-high` : (1500, 350)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e13
`f161-e13` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-morgue-high` : (1500, 350)

**Arrivée** — `f161-mess-high` : (2320, 350)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e14
`f161-e14` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé -20. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-mess-high` : (2320, 350)

**Arrivée** — `f161-service-high` : (3070, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e15
`f161-e15` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-service-high` : (3070, 330)

**Arrivée** — `f161-tunnel-high` : (3820, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e16
`f161-e16` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-tunnel-high` : (3820, 330)

**Arrivée** — `f161-sprinkler` : (4560, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e17
`f161-e17` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-sprinkler` : (4560, 330)

**Arrivée** — `f161-furnace-high` : (5350, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e18
`f161-e18` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-furnace-high` : (5350, 330)

**Arrivée** — `f161-furnace` : (5480, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Conduit — f161-e19
`f161-e19` · Connexions

[Socle V104 conservé] Conduit entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-infirmary` : (1120, 510)

**Arrivée** — `f161-service-deep` : (3070, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e20
`f161-e20` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-service-deep` : (3070, 630)

**Arrivée** — `f161-tunnel-low` : (3820, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e21
`f161-e21` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-tunnel-low` : (3820, 630)

**Arrivée** — `f161-leadworks` : (4200, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

**Groupe V111** — `v111-doors` : Longueur canonique 500.00 unités avec approches d’échelle. La géométrie physique des portes est testée sur chaque segment.

### Conduit — f161-e22
`f161-e22` · Connexions

[Socle V104 conservé] Conduit entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-leadworks` : (4200, 510)

**Arrivée** — `f161-furnace` : (5480, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e23
`f161-e23` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-cell-a` : (1900, 510)

**Arrivée** — `f161-mess-high` : (2320, 350)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e24
`f161-e24` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-service-low` : (3070, 510)

**Arrivée** — `f161-service-high` : (3070, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e25
`f161-e25` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-service-low` : (3070, 510)

**Arrivée** — `f161-service-deep` : (3070, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e26
`f161-e26` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-leadworks` : (4200, 510)

**Arrivée** — `f161-sprinkler` : (4560, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e27
`f161-e27` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-cell-a` : (1900, 510)

**Arrivée** — `f161-assembly-hall` : (2300, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e28
`f161-e28` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-assembly-hall` : (2300, 510)

**Arrivée** — `f161-cell-b` : (2620, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e29
`f161-e29` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-assembly-hall` : (2300, 510)

**Arrivée** — `f161-mess-high` : (2320, 350)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e30
`f161-e30` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-tunnel-low` : (3820, 630)

**Arrivée** — `f161-waste-tank` : (4070, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e31
`f161-e31` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-waste-tank` : (4070, 630)

**Arrivée** — `f161-sluice-low` : (4500, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e32
`f161-e32` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-sluice-low` : (4500, 630)

**Arrivée** — `f161-leadworks` : (4200, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e33
`f161-e33` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-furnace-high` : (5350, 330)

**Arrivée** — `f161-furnace-gantry` : (5740, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e34
`f161-e34` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-furnace-gantry` : (5740, 330)

**Arrivée** — `f161-company` : (5800, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e35
`f161-e35` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-service-low` : (3070, 510)

**Arrivée** — `f161-fuel-manifold-a` : (2960, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e36
`f161-e36` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-fuel-manifold-a` : (2960, 510)

**Arrivée** — `f161-fuel-manifold-b` : (3240, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e37
`f161-e37` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-fuel-manifold-b` : (3240, 510)

**Arrivée** — `f161-bishop` : (3500, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e38
`f161-e38` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-bishop` : (3500, 510)

**Arrivée** — `f161-chemical-store` : (3670, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e39
`f161-e39` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-chemical-store` : (3670, 510)

**Arrivée** — `f161-tunnel-high` : (3820, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e40
`f161-e40` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-leadworks` : (4200, 510)

**Arrivée** — `f161-lead-primer` : (4380, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

**Groupe V111** — `v111-doors` : Longueur canonique 180.00 unités avec approches d’échelle. La géométrie physique des portes est testée sur chaque segment.

### Marche — f161-e41
`f161-e41` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-lead-primer` : (4380, 510)

**Arrivée** — `f161-mold` : (4920, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e42
`f161-e42` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-sprinkler` : (4560, 330)

**Arrivée** — `f161-water-header` : (4690, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e43
`f161-e43` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-water-header` : (4690, 330)

**Arrivée** — `f161-mold` : (4920, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e44
`f161-e44` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-furnace-high` : (5350, 330)

**Arrivée** — `f161-furnace-overlook` : (5580, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e45
`f161-e45` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-furnace-overlook` : (5580, 330)

**Arrivée** — `f161-company` : (5800, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e46
`f161-e46` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-infirmary` : (1120, 510)

**Arrivée** — `f161-clemens-bed` : (1380, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e47
`f161-e47` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-clemens-bed` : (1380, 510)

**Arrivée** — `f161-funeral-walk` : (1580, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e48
`f161-e48` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-funeral-walk` : (1580, 510)

**Arrivée** — `f161-morgue-high` : (1500, 350)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e49
`f161-e49` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-mess-high` : (2320, 350)

**Arrivée** — `f161-mess-ceiling` : (2470, 350)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e50
`f161-e50` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-mess-ceiling` : (2470, 350)

**Arrivée** — `f161-comms-high` : (2720, 350)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e51
`f161-e51` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-service-high` : (3070, 330)

**Arrivée** — `f161-fan-shaft` : (2940, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e52
`f161-e52` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-service-deep` : (3070, 630)

**Arrivée** — `f161-tunnel-shrine` : (3420, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e53
`f161-e53` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-tunnel-shrine` : (3420, 630)

**Arrivée** — `f161-bishop` : (3500, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

**Groupe V111** — `v111-doors` : Longueur canonique 200.00 unités avec approches d’échelle. La géométrie physique des portes est testée sur chaque segment.

### Marche — f161-e54
`f161-e54` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-leadworks` : (4200, 510)

**Arrivée** — `f161-piston-a-node` : (4480, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e55
`f161-e55` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-piston-a-node` : (4480, 510)

**Arrivée** — `f161-mold` : (4920, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e56
`f161-e56` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-sprinkler` : (4560, 330)

**Arrivée** — `f161-piston-b-node` : (4820, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e57
`f161-e57` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-piston-b-node` : (4820, 330)

**Arrivée** — `f161-mold` : (4920, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e58
`f161-e58` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-mold` : (4920, 510)

**Arrivée** — `f161-piston-c-node` : (5140, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e59
`f161-e59` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-piston-c-node` : (5140, 510)

**Arrivée** — `f161-furnace` : (5480, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e60
`f161-e60` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-company` : (5800, 510)

**Arrivée** — `f161-patna-cage-node` : (5930, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e61
`f161-e61` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-patna-cage-node` : (5930, 510)

**Arrivée** — `f161-extraction` : (6040, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e62
`f161-e62` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-morgue-high` : (1500, 350)

**Arrivée** — `f161-master-archive-node` : (1260, 350)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e63
`f161-e63` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-cell-b` : (2620, 510)

**Arrivée** — `f161-shutter-cell-node` : (2740, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e64
`f161-e64` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-shutter-cell-node` : (2740, 510)

**Arrivée** — `f161-comms-high` : (2720, 350)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e65
`f161-e65` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-service-high` : (3070, 330)

**Arrivée** — `f161-steam-service-node` : (3190, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e66
`f161-e66` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-steam-service-node` : (3190, 330)

**Arrivée** — `f161-fan-shaft` : (2940, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e67
`f161-e67` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-service-low` : (3070, 510)

**Arrivée** — `f161-rescue-post-node` : (3330, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e68
`f161-e68` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-rescue-post-node` : (3330, 510)

**Arrivée** — `f161-bishop` : (3500, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e69
`f161-e69` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-bishop` : (3500, 510)

**Arrivée** — `f161-shutter-service-node` : (3650, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e70
`f161-e70` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-shutter-service-node` : (3650, 510)

**Arrivée** — `f161-chemical-store` : (3670, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e71
`f161-e71` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-tunnel-high` : (3820, 330)

**Arrivée** — `f161-command-post-node` : (3960, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e72
`f161-e72` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-command-post-node` : (3960, 510)

**Arrivée** — `f161-leadworks` : (4200, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e73
`f161-e73` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-water-header` : (4690, 330)

**Arrivée** — `f161-steam-lead-node` : (4710, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e74
`f161-e74` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-steam-lead-node` : (4710, 330)

**Arrivée** — `f161-piston-b-node` : (4820, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e75
`f161-e75` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-mold` : (4920, 510)

**Arrivée** — `f161-shutter-foundry-node` : (5050, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e76
`f161-e76` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-shutter-foundry-node` : (5050, 510)

**Arrivée** — `f161-piston-c-node` : (5140, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e77
`f161-e77` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-mess-ceiling` : (2470, 350)

**Arrivée** — `f161-perch-cell-v93` : (2500, 190)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e78
`f161-e78` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-perch-cell-v93` : (2500, 190)

**Arrivée** — `f161-comms-high` : (2720, 350)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e79
`f161-e79` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-steam-service-node` : (3190, 330)

**Arrivée** — `f161-perch-service-v93` : (3310, 190)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e80
`f161-e80` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-perch-service-v93` : (3310, 190)

**Arrivée** — `f161-service-high` : (3070, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e81
`f161-e81` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-rescue-post-node` : (3330, 510)

**Arrivée** — `f161-triage-v93` : (3490, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e82
`f161-e82` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-triage-v93` : (3490, 510)

**Arrivée** — `f161-shutter-service-node` : (3650, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e83
`f161-e83` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-steam-lead-node` : (4710, 330)

**Arrivée** — `f161-perch-lead-v93` : (4720, 190)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e84
`f161-e84` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-perch-lead-v93` : (4720, 190)

**Arrivée** — `f161-piston-b-node` : (4820, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e85
`f161-e85` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-furnace` : (5480, 510)

**Arrivée** — `f161-parley-v93` : (5660, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e86
`f161-e86` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-parley-v93` : (5660, 510)

**Arrivée** — `f161-company` : (5800, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e87
`f161-e87` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-company` : (5800, 510)

**Arrivée** — `f161-witness-v93` : (6030, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e88
`f161-e88` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-witness-v93` : (6030, 330)

**Arrivée** — `f161-extraction` : (6040, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e89
`f161-e89` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -180. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-eev` : (620, 510)

**Arrivée** — `f161-flight-analysis-v94` : (780, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e90
`f161-e90` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 20. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-flight-analysis-v94` : (780, 330)

**Arrivée** — `f161-morgue-high` : (1500, 350)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e91
`f161-e91` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-eev` : (620, 510)

**Arrivée** — `f161-wreckage-incident-v94` : (820, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e92
`f161-e92` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-wreckage-incident-v94` : (820, 630)

**Arrivée** — `f161-infirmary` : (1120, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e93
`f161-e93` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-mess-high` : (2320, 350)

**Arrivée** — `f161-faith-dais-v94` : (2180, 190)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e94
`f161-e94` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-faith-dais-v94` : (2180, 190)

**Arrivée** — `f161-perch-cell-v93` : (2500, 190)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e95
`f161-e95` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-service-high` : (3070, 330)

**Arrivée** — `f161-battery-locker-v94` : (3500, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e96
`f161-e96` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-battery-locker-v94` : (3500, 330)

**Arrivée** — `f161-tunnel-high` : (3820, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e97
`f161-e97` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-tunnel-shrine` : (3420, 630)

**Arrivée** — `f161-golic-cache-v94` : (3660, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

**Groupe V111** — `v111-doors` : Longueur canonique 240.00 unités avec approches d’échelle. La géométrie physique des portes est testée sur chaque segment.

### Marche — f161-e98
`f161-e98` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-golic-cache-v94` : (3660, 630)

**Arrivée** — `f161-tunnel-low` : (3820, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

**Groupe V111** — `v111-doors` : Longueur canonique 160.00 unités avec approches d’échelle. La géométrie physique des portes est testée sur chaque segment.

### Marche — f161-e99
`f161-e99` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-tunnel-high` : (3820, 330)

**Arrivée** — `f161-battery-junction-v94` : (4020, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e100
`f161-e100` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-battery-junction-v94` : (4020, 330)

**Arrivée** — `f161-water-header` : (4690, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e101
`f161-e101` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-mold` : (4920, 510)

**Arrivée** — `f161-chase-reroute-v94` : (5050, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e102
`f161-e102` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-chase-reroute-v94` : (5050, 630)

**Arrivée** — `f161-furnace` : (5480, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e103
`f161-e103` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-witness-v93` : (6030, 330)

**Arrivée** — `f161-final-transmission-v94` : (6100, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e104
`f161-e104` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-cell-a` : (1900, 510)

**Arrivée** — `f161-shelter-cell-v95` : (2050, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e105
`f161-e105` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -120. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-shelter-cell-v95` : (2050, 630)

**Arrivée** — `f161-assembly-hall` : (2300, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e106
`f161-e106` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-perch-cell-v93` : (2500, 190)

**Arrivée** — `f161-watch-cell-v95` : (2660, 190)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e107
`f161-e107` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé 160. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-watch-cell-v95` : (2660, 190)

**Arrivée** — `f161-comms-high` : (2720, 350)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e108
`f161-e108` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-service-deep` : (3070, 630)

**Arrivée** — `f161-refuge-service-v95` : (2990, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e109
`f161-e109` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-refuge-service-v95` : (2990, 630)

**Arrivée** — `f161-tunnel-shrine` : (3420, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e110
`f161-e110` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-service-high` : (3070, 330)

**Arrivée** — `f161-hunt-service-v95` : (3370, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e111
`f161-e111` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-hunt-service-v95` : (3370, 330)

**Arrivée** — `f161-battery-locker-v94` : (3500, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e112
`f161-e112` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-triage-v93` : (3490, 510)

**Arrivée** — `f161-triage-overflow-v95` : (3600, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e113
`f161-e113` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-triage-overflow-v95` : (3600, 510)

**Arrivée** — `f161-shutter-service-node` : (3650, 510)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e114
`f161-e114` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-tunnel-low` : (3820, 630)

**Arrivée** — `f161-hunt-junction-v95` : (3900, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e115
`f161-e115` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-hunt-junction-v95` : (3900, 630)

**Arrivée** — `f161-waste-tank` : (4070, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e116
`f161-e116` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-battery-junction-v94` : (4020, 330)

**Arrivée** — `f161-bait-switch-v95` : (4320, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e117
`f161-e117` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-bait-switch-v95` : (4320, 330)

**Arrivée** — `f161-sprinkler` : (4560, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e118
`f161-e118` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-chase-reroute-v94` : (5050, 630)

**Arrivée** — `f161-pressure-alcove-v95` : (4780, 630)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Marche — f161-e119
`f161-e119` · Connexions

[Socle V104 conservé] Marche entre deux points historiques ; dénivelé 0. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-furnace-high` : (5350, 330)

**Arrivée** — `f161-chase-observer-v95` : (5280, 330)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### Échelle — f161-e120
`f161-e120` · Connexions

[Socle V104 conservé] Échelle entre deux points historiques ; dénivelé -140. Les profils de décor n’ajoutent pas d’arête et ne rendent pas ce passage instantané. La carte n’en montre le lien que si ses deux extrémités sont visitées.

**Départ** — `f161-witness-v93` : (6030, 330)

**Arrivée** — `f161-archive-checksum-v95` : (5960, 190)

**Direction** — `Deux sens` : Sous réserve des verrous et conditions hérités

### A3-ANCHOR
`A3-ANCHOR` · Règles

[Socle V104 conservé] Tout décor a un support nommé ; coordonnées indépendantes du joueur.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-FINITE
`A3-FINITE` · Règles

[Socle V104 conservé] Positions et dimensions finies et positives.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-ID
`A3-ID` · Règles

[Socle V104 conservé] Identifiants uniques, parents existants.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-FOOT
`A3-FOOT` · Règles

[Socle V104 conservé] Les meubles reposent sur le plan de pose ; pas sur la caméra.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-BOUND
`A3-BOUND` · Règles

[Socle V104 conservé] Les éléments restent dans la baie de leur assemblage.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-NO_FAKE_COVER
`A3-NO_FAKE_COVER` · Règles

[Socle V104 conservé] Décor d’arrière-plan non collidable et explicitement sans couverture.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-CONDITION
`A3-CONDITION` · Règles

[Socle V104 conservé] Le matériel de récupération dépend de l’arrivée de la Compagnie.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-ROUTE
`A3-ROUTE` · Règles

[Socle V104 conservé] Aucun nœud, verrou ou ordre de mission ajouté pour justifier le décor.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-DRAW_PURE
`A3-DRAW_PURE` · Règles

[Socle V104 conservé] Le rendu ne change ni progression ni sauvegarde.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-TOP
`A3-TOP` · Règles

[Socle V104 conservé] Fond opaque depuis le premier pixel du champ, quelle que soit la caméra.

**Preuve attendue** — `browser` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-HUD
`A3-HUD` · Règles

[Socle V104 conservé] Les panneaux ordinaires couvrent moins de 9 % de l’écran.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-READ
`A3-READ` · Règles

[Socle V104 conservé] Les premiers plans s’effacent à proximité des silhouettes.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-PARALLAX
`A3-PARALLAX` · Règles

[Socle V104 conservé] Les machines proches suivent le monde ; seule l’architecture distante dérive.

**Preuve attendue** — `browser` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-LUX
`A3-LUX` · Règles

[Socle V104 conservé] Une lumière forte a une source dessinée.

**Preuve attendue** — `visual` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-RHYTHM
`A3-RHYTHM` · Règles

[Socle V104 conservé] Alcôves équipées puis respirations, sans tapis uniforme de petits objets.

**Preuve attendue** — `visual` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-IDENTITY
`A3-IDENTITY` · Règles

[Socle V104 conservé] Une forme identifiable remplace chaque bloc générique.

**Preuve attendue** — `visual` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-FILM
`A3-FILM` · Règles

[Socle V104 conservé] Plans et dimensions de jeu : adaptation, pas relevé certifié des plateaux.

**Preuve attendue** — `disclosure` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-ROOMS
`A3-ROOMS` · Règles

[Socle V104 conservé] La pièce, son étage et ses voisins priment sur les limites de caméra.

**Preuve attendue** — `disclosure` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-103-SPACE
`A3-103-SPACE` · Règles

[Socle V104 conservé] Une section décrit un lieu et un étage ; elle ne crée pas une nouvelle salle instanciée.

**Preuve attendue** — `scope` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-103-PORTAL
`A3-103-PORTAL` · Règles

[Socle V104 conservé] Un cadre de porte provient d’une arête gate/airlock ; la feuille et la collision restent pilotées par la porte native.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-103-GATE-GEOMETRY
`A3-103-GATE-GEOMETRY` · Règles

[Socle V104 conservé] Une porte fournie par le plan compilé est utilisée sans déplacer sa collision.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-103-VERTICAL-PRIORITY
`A3-103-VERTICAL-PRIORITY` · Règles

[Socle V104 conservé] Haut/Bas donnent la priorité à une échelle réellement atteignable, avant un changement de profondeur.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-103-CIRCUIT
`A3-103-CIRCUIT` · Règles

[Socle V104 conservé] Un réseau décoratif possède une source et un récepteur du même ensemble, reliés par un tracé continu.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-103-LIGHT
`A3-103-LIGHT` · Règles

[Socle V104 conservé] Couper un éclairage de service ne coupe ni le feu du four, ni l’eau du piège, ni un objectif.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-103-REACH
`A3-103-REACH` · Règles

[Socle V104 conservé] Une commande exige proximité, niveau, plan médian, personnage vivant et absence de porte fermée entre les deux.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-103-PAUSE
`A3-103-PAUSE` · Règles

[Socle V104 conservé] Le plan et les archives arrêtent la simulation ; la fermeture ne supprime pas une pause préexistante.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-103-MAP
`A3-103-MAP` · Règles

[Socle V104 conservé] Le plan ne montre ni ennemis ni dossiers secrets ; un nœud n’est relevé qu’au voisinage du personnage.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-103-PERSIST
`A3-103-PERSIST` · Règles

[Socle V104 conservé] Les visites et les éclairages sont sauvegardés ; ni la géométrie ni l’ouverture du plan ne sont sérialisées.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-103-REDUCED-MOTION
`A3-103-REDUCED-MOTION` · Règles

[Socle V104 conservé] Le mouvement réduit conserve les états lisibles sans animation de panneaux.

**Preuve attendue** — `automated` : Contrat documenté ; la méthode est séparée du résultat des tests.

### A3-103-PROVENANCE
`A3-103-PROVENANCE` · Règles

[Socle V104 conservé] Banc visuel et tests isolés ne constituent pas une validation de la campagne complète.

**Preuve attendue** — `scope` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC01
`SC01` · Règles

[Socle V104 conservé] Une scène compilée fournit les appuis, les commandes, les portes et le plan.

**Preuve attendue** — `data` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC02
`SC02` · Règles

[Socle V104 conservé] Une coordonnée monde n’est pas retraitée comme une coordonnée écran.

**Preuve attendue** — `data` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC03
`SC03` · Règles

[Socle V104 conservé] Le fond couvre le premier pixel ; les particules restent dans leur alcôve.

**Preuve attendue** — `browser` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC04
`SC04` · Règles

[Socle V104 conservé] Un saut conserve le nom du lieu jusqu’à la réception.

**Preuve attendue** — `runtime` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC05
`SC05` · Règles

[Socle V104 conservé] Un contact exige proximité, hauteur, profondeur et absence de porte fermée.

**Preuve attendue** — `runtime` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC06
`SC06` · Règles

[Socle V104 conservé] Les états visuels sont issus des événements, jamais de l’abscisse du joueur.

**Preuve attendue** — `runtime` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC07
`SC07` · Règles

[Socle V104 conservé] Le feu, les dépôts de suie, le plomb chaud et le refroidissement restent distincts.

**Preuve attendue** — `data` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC08
`SC08` · Règles

[Socle V104 conservé] La Compagnie ne se dessine pas avant son arrivée.

**Preuve attendue** — `runtime` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC09
`SC09` · Règles

[Socle V104 conservé] Le HUD normal est temporaire ; les vitales restent visibles en danger.

**Preuve attendue** — `browser` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC10
`SC10` · Règles

[Socle V104 conservé] Le plan et les archives suspendent l’horloge de cette couche.

**Preuve attendue** — `runtime` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC11
`SC11` · Règles

[Socle V104 conservé] La sauvegarde valide identité et géométrie avant de remplacer l’état.

**Preuve attendue** — `runtime` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC12
`SC12` · Règles

[Socle V104 conservé] Un fichier refusé ne détruit ni la partie courante ni sa reprise.

**Preuve attendue** — `browser` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC13
`SC13` · Règles

[Socle V104 conservé] Les phases d’attaque, touches et fenêtres ouvertes ne sont pas rejouées à l’import.

**Preuve attendue** — `data` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC14
`SC14` · Règles

[Socle V104 conservé] La ronde originale doit être terminée au clavier sans positions injectées.

**Preuve attendue** — `browser` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC15
`SC15` · Règles

[Socle V104 conservé] Un mécanisme local d’éclairage ne termine pas une mission du film.

**Preuve attendue** — `runtime` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC16
`SC16` · Règles

[Socle V104 conservé] Les captures sont natives du renderer partagé, pas une reconstitution après coup.

**Preuve attendue** — `evidence` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC17
`SC17` · Règles

[Socle V104 conservé] Les tests préparés, la ronde et le moteur complet ont des preuves distinctes.

**Preuve attendue** — `scope` : Contrat documenté ; la méthode est séparée du résultat des tests.

### SC18
`SC18` · Règles

[Socle V104 conservé] Les options de mouvement et de lisibilité n’altèrent pas la progression.

**Preuve attendue** — `runtime` : Contrat documenté ; la méthode est séparée du résultat des tests.

### Départ du feu
`outbreak` · États du décor

[Socle V104 conservé] Flamme locale et fumée, sans nouveaux dégâts. La consultation ou le dessin seul ne déclenche pas la transition historique.

**État source** — `alien3V90.firePlan.ignited et non accidentResolved ; repli fireMazeIgnited` : Les booléens explicites priment sur les raccourcis de phase.

**Ensemble** — `service-pump` : Pompage des galeries

**Ensemble** — `chemical-store` : Réserve de produits

### Après l’incendie
`aftermath` · États du décor

[Socle V104 conservé] Suie conservée après extinction ; aucune flamme ajoutée. La consultation ou le dessin seul ne déclenche pas la transition historique.

**État source** — `Feu observé ou firePlan.accidentResolved` : Les booléens explicites priment sur les raccourcis de phase.

**Ensemble** — `service-pump` : Pompage des galeries

**Ensemble** — `chemical-store` : Réserve de produits

### Coulée
`molten` · États du décor

[Socle V104 conservé] Lueur chaude aux récepteurs industriels. La consultation ou le dessin seul ne déclenche pas la transition historique.

**État source** — `alien3V88.moltenLeadApplied ; repli de phase uniquement si absent` : Les booléens explicites priment sur les raccourcis de phase.

**Ensemble** — `leadworks` : Creuset et transfert

**Ensemble** — `lead-primer` : Alimentation du creuset

**Ensemble** — `mold` : Moule de coulée

### Refroidissement
`cooling` · États du décor

[Socle V104 conservé] Vapeur localisée ; pas de changement du débit ou de la victoire. La consultation ou le dessin seul ne déclenche pas la transition historique.

**État source** — `alien3V88.thermalShockApplied ; repli de phase uniquement si absent` : Les booléens explicites priment sur les raccourcis de phase.

**Ensemble** — `mold` : Moule de coulée

**Ensemble** — `water-header` : Collecteur d’eau supérieur

### Récupération
`recovery` · États du décor

[Socle V104 conservé] Matériel existant de la Compagnie visible. La consultation ou le dessin seul ne déclenche pas la transition historique.

**État source** — `alien3V89.company.visible === true ou phase company/finale` : Les booléens explicites priment sur les raccourcis de phase.

**Ensemble** — `patna-kit` : Matériel de récupération

### 1. Rétablir la lampe de soin.
`round-1` · Ronde originale

[Socle V104 conservé] Parcours optionnel de l’aperçu, activé explicitement depuis son bouton. Il n’est pas injecté automatiquement dans la campagne Alien 3. Les trois circuits sont éteints au lancement de ce parcours ; aucune réserve du film n’est donnée. Une importation valide reprend en pause, sans sauter une étape.

**Cible** — `care-light` : Appui réel au bon étage

**Action** — `I : rallumer` : Une étape hors ordre ne se valide pas.

### 2. Rétablir l’éclairage des cellules ouest.
`round-2` · Ronde originale

[Socle V104 conservé] Parcours optionnel de l’aperçu, activé explicitement depuis son bouton. Il n’est pas injecté automatiquement dans la campagne Alien 3. Les trois circuits sont éteints au lancement de ce parcours ; aucune réserve du film n’est donnée. Une importation valide reprend en pause, sans sauter une étape.

**Cible** — `cell-light` : Appui réel au bon étage

**Action** — `I : rallumer` : Une étape hors ordre ne se valide pas.

### 3. Monter à l’atelier et rétablir sa lampe.
`round-3` · Ronde originale

[Socle V104 conservé] Parcours optionnel de l’aperçu, activé explicitement depuis son bouton. Il n’est pas injecté automatiquement dans la campagne Alien 3. Les trois circuits sont éteints au lancement de ce parcours ; aucune réserve du film n’est donnée. Une importation valide reprend en pause, sans sauter une étape.

**Cible** — `service-light` : Appui réel au bon étage

**Action** — `I : rallumer` : Une étape hors ordre ne se valide pas.

### 4. Revenir dans la salle commune.
`round-4` · Ronde originale

[Socle V104 conservé] Parcours optionnel de l’aperçu, activé explicitement depuis son bouton. Il n’est pas injecté automatiquement dans la campagne Alien 3. Les trois circuits sont éteints au lancement de ce parcours ; aucune réserve du film n’est donnée. Une importation valide reprend en pause, sans sauter une étape.

**Cible** — `f161-assembly-hall` : Appui réel au bon étage

**Action** — `Rejoindre le point de retour` : Une étape hors ordre ne se valide pas.

### Un bruit dans les galeries
`encounter-traque` · Parcours V105

Séquence originale activée explicitement dans le banc ; elle ne termine pas automatiquement une mission de la campagne historique. Aucun équipement militaire ajouté. Aaron appartient au parcours antérieur, pas à la fonderie.

**Joueur** — `f161-infirmary` : Départ de la séquence

**Runner** — `f161-cell-b` : Un objet acteur conservé

**Étape 1** — `objective-traque-0` : Parler à Aaron près de l’infirmerie.

**Étape 2** — `objective-traque-1` : Monter à l’atelier et prendre le relevé de service.

**Étape 3** — `objective-traque-2` : Rapporter le relevé à Aaron.

**Relevé** — `operation107-report` : E maintenu 1,10 s, ou mode Appuyer, au poste réel.

**Diversion** — `input108-throw` : Boulon lancé, bruit depuis l’impact ; aucune garantie de l’attirer hors de portée.

### Parler à Aaron près de l’infirmerie.
`objective-traque-0` · Étapes V105

La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

**Séquence** — `encounter-traque` : Un bruit dans les galeries

**Ordre** — `1` : Une action hors ordre ne donne aucun état final.

### Monter à l’atelier et prendre le relevé de service.
`objective-traque-1` · Étapes V105

La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

**Séquence** — `encounter-traque` : Un bruit dans les galeries

**Ordre** — `2` : Une action hors ordre ne donne aucun état final.

### Rapporter le relevé à Aaron.
`objective-traque-2` · Étapes V105

La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

**Séquence** — `encounter-traque` : Un bruit dans les galeries

**Ordre** — `3` : Une action hors ordre ne donne aucun état final.

### Le dernier rabattage
`encounter-rabattage` · Parcours V105

Séquence originale activée explicitement dans le banc ; elle ne termine pas automatiquement une mission de la campagne historique. Aucun équipement militaire ajouté. Aaron appartient au parcours antérieur, pas à la fonderie.

**Joueur** — `f161-command-post-node` : Départ de la séquence

**Runner** — `f161-furnace` : Un objet acteur conservé

**Étape 1** — `objective-rabattage-0` : Donner le signal à Dillon au poste de commande.

**Étape 2** — `objective-rabattage-1` : Amorcer le réseau d’eau, sur la coursive haute.

**Étape 3** — `objective-rabattage-2` : Attendre Morse et Dillon, puis armer le piège au moule.

**Étape 4** — `objective-rabattage-3` : Attirer le Runner dans le moule ; rejoindre Dillon et lancer la coulée.

**Étape 5** — `objective-rabattage-4` : Remonter au collecteur pour libérer l’eau.

**Étape 6** — `objective-rabattage-5` : Rejoindre Morse près de la salle de coulée.

**Amorçage** — `operation107-prime` : Durée 1,80 s, annulation par mouvement/blessure/panneau.

**Verrouillage** — `operation107-arm` : Durée 1,25 s ; Morse et Dillon restent requis.

**Refroidissement** — `operation107-cool` : Durée 2,00 s après la coulée.

**Préparation** — `A3-108-dormant` : Les boulons ne réveillent pas la créature durant la phase explicitement dormante.

### Donner le signal à Dillon au poste de commande.
`objective-rabattage-0` · Étapes V105

La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

**Séquence** — `encounter-rabattage` : Le dernier rabattage

**Ordre** — `1` : Une action hors ordre ne donne aucun état final.

### Amorcer le réseau d’eau, sur la coursive haute.
`objective-rabattage-1` · Étapes V105

La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

**Séquence** — `encounter-rabattage` : Le dernier rabattage

**Ordre** — `2` : Une action hors ordre ne donne aucun état final.

### Attendre Morse et Dillon, puis armer le piège au moule.
`objective-rabattage-2` · Étapes V105

La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

**Séquence** — `encounter-rabattage` : Le dernier rabattage

**Ordre** — `3` : Une action hors ordre ne donne aucun état final.

### Attirer le Runner dans le moule ; rejoindre Dillon et lancer la coulée.
`objective-rabattage-3` · Étapes V105

La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

**Séquence** — `encounter-rabattage` : Le dernier rabattage

**Ordre** — `4` : Une action hors ordre ne donne aucun état final.

### Remonter au collecteur pour libérer l’eau.
`objective-rabattage-4` · Étapes V105

La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

**Séquence** — `encounter-rabattage` : Le dernier rabattage

**Ordre** — `5` : Une action hors ordre ne donne aucun état final.

### Rejoindre Morse près de la salle de coulée.
`objective-rabattage-5` · Étapes V105

La validation exige l’action réelle à portée, sur le bon étage et le bon plan, sans porte fermée entre l’acteur et le poste. Aucune lecture du codex ne valide une étape.

**Séquence** — `encounter-rabattage` : Le dernier rabattage

**Ordre** — `6` : Une action hors ordre ne donne aucun état final.

### Aaron
`station-aaron` · Postes V105

Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105.

**Appui** — `f161-clemens-bed` : X 1380, sol 510

**Profondeur** — `1` : Plan médian de la commande

**Interaction** — `E` : Priorité à l’étape attendue lorsque sa station est atteinte.

### Relevé de service
`station-report` · Postes V105

Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105. V107 : certaines étapes exigent une action maintenue, à appui stable. Les gestes et interruptions sont détaillés dans les fiches Manœuvres V107 ; l’ancienne validation instantanée de ces étapes n’est plus active dans le pilote V107.

**Appui** — `f161-service-high` : X 3070, sol 330

**Profondeur** — `1` : Plan médian de la commande

**Interaction** — `E` : Priorité à l’étape attendue lorsque sa station est atteinte.

### Dillon
`station-brief` · Postes V105

Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105.

**Appui** — `f161-command-post-node` : X 3960, sol 510

**Profondeur** — `1` : Plan médian de la commande

**Interaction** — `E` : Priorité à l’étape attendue lorsque sa station est atteinte.

### Vanne du collecteur
`station-water` · Postes V105

Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105. V107 : certaines étapes exigent une action maintenue, à appui stable. Les gestes et interruptions sont détaillés dans les fiches Manœuvres V107 ; l’ancienne validation instantanée de ces étapes n’est plus active dans le pilote V107.

**Appui** — `f161-water-header` : X 4690, sol 330

**Profondeur** — `1` : Plan médian de la commande

**Interaction** — `E` : Priorité à l’étape attendue lorsque sa station est atteinte.

### Commande du moule
`station-mold` · Postes V105

Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105. V107 : certaines étapes exigent une action maintenue, à appui stable. Les gestes et interruptions sont détaillés dans les fiches Manœuvres V107 ; l’ancienne validation instantanée de ces étapes n’est plus active dans le pilote V107.

**Appui** — `f161-mold` : X 4920, sol 510

**Profondeur** — `1` : Plan médian de la commande

**Interaction** — `E` : Priorité à l’étape attendue lorsque sa station est atteinte.

### Commande de coulée
`station-pour` · Postes V105

Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105. V107 conserve volontairement la commande de coulée immédiate, au passage réel du Runner. Elle n’immobilise pas la créature avant sa validation et ne lui ajoute aucun déplacement forcé.

**Appui** — `f161-piston-c-node` : X 5140, sol 510

**Profondeur** — `1` : Plan médian de la commande

**Interaction** — `E` : Priorité à l’étape attendue lorsque sa station est atteinte.

### Morse
`station-return` · Postes V105

Portée de 85 unités autour du poste, différence de pied ≤22, différence de profondeur ≤0,40, segment libre de porte fermée. Les commandes natives ne sont pas remplacées en dehors d’une séquence V105.

**Appui** — `f161-lead-primer` : X 4380, sol 510

**Profondeur** — `1` : Plan médian de la commande

**Interaction** — `E` : Priorité à l’étape attendue lorsque sa station est atteinte.

### Aaron
`participant-aaron` · Participants V105

Donne la consigne et reçoit le relevé. Aucun déplacement ni réapparition dans le final. Les corps sont des silhouettes vectorielles stylisées. Ce test n’est pas la mort filmée de Dillon ni la fin complète du film.

**Point de présence** — `f161-clemens-bed` : Position physique vérifiée, vivant et trajet terminé

**Séquence** — `encounter-traque` : Présence limitée à son parcours

**Navigation** — `Graphe commun` : Même portes et appuis que la menace

### Morse
`participant-morse` · Participants V105

Part près de Bishop et rejoint le poste de coulée après le signal. Une porte fermée le fait attendre ; un simple drapeau d’arrivée ne suffit pas. Les corps sont des silhouettes vectorielles stylisées. Ce test n’est pas la mort filmée de Dillon ni la fin complète du film.

**Point de présence** — `f161-lead-primer` : Position physique vérifiée, vivant et trajet terminé

**Séquence** — `encounter-rabattage` : Présence limitée à son parcours

**Navigation** — `Graphe commun` : Même portes et appuis que la menace

**Ordre proche** — `order106-morse` : G : attendre/repartir sans effacer destination et segment. Un détenu retenu hors de son poste ne valide pas le piège.

### Dillon
`participant-dillon` · Participants V105

Reçoit la consigne au poste de commande puis rejoint la fermeture. Sa présence et celle de Morse restent nécessaires pour armer puis couler. Les corps sont des silhouettes vectorielles stylisées. Ce test n’est pas la mort filmée de Dillon ni la fin complète du film.

**Point de présence** — `f161-piston-c-node` : Position physique vérifiée, vivant et trajet terminé

**Séquence** — `encounter-rabattage` : Présence limitée à son parcours

**Navigation** — `Graphe commun` : Même portes et appuis que la menace

**Ordre proche** — `order106-dillon` : G : attendre/repartir sans effacer destination et segment. Un détenu retenu hors de son poste ne valide pas le piège.

**Ordre conservé** — `queue112-held` : Un autre détenu ne traverse plus son corps lorsqu’il attend volontairement.

### En attente du signal
`runner-dormant` · États du Runner

Le rabattage conserve le prédateur en attente jusqu’à l’armement réel du moule.

**Contrat** — `encounter-rabattage` : Un unique acteur

### Patrouille
`runner-patrol` · États du Runner

Suite de points connus, avec chemins calculés sur les connexions ouvertes. Aucun bond de position vers Ripley.

**Contrat** — `encounter-traque` : Un unique acteur

**patrolSpeed** — `94` : Valeur utilisée par le module de poursuite

### Investigation sonore
`runner-investigate` · États du Runner

V106 : un bruit garde son origine et sa date. Sa portée acoustique est mesurée depuis le corps du Runner sur son segment, avec les détours du graphe et l’atténuation des portes. Chaque numéro d’événement est consommé au plus une fois.

**Contrat** — `encounter-traque` : Un unique acteur

**hearing** — `620` : Valeur utilisée par le module de poursuite

**investigateSpeed** — `126` : Valeur utilisée par le module de poursuite

**Origine réelle** — `A3-106-sound-edge` : Pas de réception depuis l’extrémité lointaine du chemin.

### Recherche de trace perdue
`runner-search` · États du Runner

V106 : après une trace perdue, le Runner explore au maximum trois points voisins réellement atteignables. Il avance à 110 unités/s pendant un budget de 5,2 secondes, puis reprend la patrouille. Aucun bond vers le joueur invisible.

**Durée** — `5,2 secondes` : La pause et les panneaux suspendent ce délai.

**Choix** — `A3-106-search-room` : Voisins du point de trace ; une route coupée n’est pas effacée artificiellement.

### Poursuite
`runner-chase` · États du Runner

V106 : la vue conserve direction, hauteur, profondeur et portes, puis accumule une reconnaissance selon l’éclairage et la posture. La pénombre retarde l’identification mais ne protège pas à courte portée. La dernière trace reste une observation passée.

**Contrat** — `encounter-traque` : Un unique acteur

**sight** — `460` : Valeur utilisée par le module de poursuite

**chaseSpeed** — `206` : Valeur utilisée par le module de poursuite

**Lecture du lieu** — `A3-106-dark-not-safe` : Seules les séquences originales activent ce pilote.

### Préparation de l’attaque
`runner-windup` · États du Runner

Préparation de 0,85 seconde. Le corps reste sur place, l’orientation montre la cible, puis le contact réel est testé à l’impact.

**Contrat** — `encounter-traque` : Un unique acteur

**windup** — `0.85` : Valeur utilisée par le module de poursuite

**depthSpeed** — `1.18` : Valeur utilisée par le module de poursuite

### Reprise après attaque
`runner-recover` · États du Runner

Après un hit ou une esquive, récupération de 1,30 seconde. Une sauvegarde ne rejoue pas une attaque suspendue.

**Contrat** — `encounter-traque` : Un unique acteur

**recovery** — `1.3` : Valeur utilisée par le module de poursuite

**resumeGrace** — `1.25` : Valeur utilisée par le module de poursuite

### Pris dans le moule
`runner-trapped` · États du Runner

La coulée capture uniquement un Runner présent dans la plage du moule ; elle ne le téléporte pas au centre.

**Contrat** — `encounter-rabattage` : Un unique acteur

### Neutralisé
`runner-dead` · États du Runner

Le refroidissement termine la menace de ce parcours original. Cette neutralisation ne valide pas le final de toute la campagne.

**Contrat** — `encounter-rabattage` : Un unique acteur

### EEV éventré
`art-eev` · Repères visuels V105

Le renderer remplace 1 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

**Fonction** — `drawLandmarkV105` : src/alien3-art-v105.js

**Export** — `assets-v105/eev.png` : Atlas de référence ; le runtime dessine directement les vecteurs.

### Grilles du bloc
`art-cell` · Repères visuels V105

Le renderer remplace 2 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

**Fonction** — `drawLandmarkV105` : src/alien3-art-v105.js

**Export** — `assets-v105/cell.png` : Atlas de référence ; le runtime dessine directement les vecteurs.

### Pompe à flasques
`art-pump` · Repères visuels V105

Le renderer remplace 5 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

**Fonction** — `drawLandmarkV105` : src/alien3-art-v105.js

**Export** — `assets-v105/pump.png` : Atlas de référence ; le runtime dessine directement les vecteurs.

### Moule à vérins
`art-mold` · Repères visuels V105

Le renderer remplace 1 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

**Fonction** — `drawLandmarkV105` : src/alien3-art-v105.js

**Export** — `assets-v105/mold.png` : Atlas de référence ; le runtime dessine directement les vecteurs.

### Four maçonné
`art-furnace` · Repères visuels V105

Le renderer remplace 1 occurrence(s) de ce type au même appui et dans le même rectangle que la base. Aucune nouvelle collision ajoutée. Art vectoriel provisoire, non photoréaliste et non certifié 1:1. Un PNG transparent de référence est exporté par les mêmes fonctions.

**Fonction** — `drawLandmarkV105` : src/alien3-art-v105.js

**Export** — `assets-v105/furnace.png` : Atlas de référence ; le runtime dessine directement les vecteurs.

### Pas du joueur
`sound-steps` · Audio V105

Le mouvement produit des signaux ; courir augmente le bruit de simulation, se baisser le réduit. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

**Contrôle** — `AudioContext` : Activation technique vérifiée, pas écoute physique sur matériel

**Cycle de vie** — `FiorinaAudioV105` : Pause, désactivation et destruction ne font avancer aucun objectif.

### Appuis du Runner
`sound-foot-runner` · Audio V105

Panorama et atténuation utilisent la position du seul acteur. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

**Contrôle** — `AudioContext` : Activation technique vérifiée, pas écoute physique sur matériel

**Cycle de vie** — `FiorinaAudioV105` : Pause, désactivation et destruction ne font avancer aucun objectif.

### Heurt métallique
`sound-metal` · Audio V105

F émet depuis la position actuelle, au sol et après un délai de deux secondes. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

**Contrôle** — `AudioContext` : Activation technique vérifiée, pas écoute physique sur matériel

**Cycle de vie** — `FiorinaAudioV105` : Pause, désactivation et destruction ne font avancer aucun objectif.

### Préparation d’attaque
`sound-windup` · Audio V105

Indice sonore limité ; aucune carte exacte du prédateur. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

**Contrôle** — `AudioContext` : Activation technique vérifiée, pas écoute physique sur matériel

**Cycle de vie** — `FiorinaAudioV105` : Pause, désactivation et destruction ne font avancer aucun objectif.

### Contact
`sound-bite` · Audio V105

Joué uniquement après le contact réellement validé. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

**Contrôle** — `AudioContext` : Activation technique vérifiée, pas écoute physique sur matériel

**Cycle de vie** — `FiorinaAudioV105` : Pause, désactivation et destruction ne font avancer aucun objectif.

### Eau
`sound-water` · Audio V105

Associé aux commandes du collecteur. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

**Contrôle** — `AudioContext` : Activation technique vérifiée, pas écoute physique sur matériel

**Cycle de vie** — `FiorinaAudioV105` : Pause, désactivation et destruction ne font avancer aucun objectif.

### Coulée
`sound-lead` · Audio V105

Associé à la commande physique de coulée. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

**Contrôle** — `AudioContext` : Activation technique vérifiée, pas écoute physique sur matériel

**Cycle de vie** — `FiorinaAudioV105` : Pause, désactivation et destruction ne font avancer aucun objectif.

### Commande
`sound-switch` · Audio V105

Retour court d’interaction. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

**Contrôle** — `AudioContext` : Activation technique vérifiée, pas écoute physique sur matériel

**Cycle de vie** — `FiorinaAudioV105` : Pause, désactivation et destruction ne font avancer aucun objectif.

### Bourdonnement
`sound-hum` · Audio V105

Oscillateur grave de 53/68 Hz selon la famille du lieu. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

**Contrôle** — `AudioContext` : Activation technique vérifiée, pas écoute physique sur matériel

**Cycle de vie** — `FiorinaAudioV105` : Pause, désactivation et destruction ne font avancer aucun objectif.

### Ventilation
`sound-vent` · Audio V105

Bruit filtré original, généré localement avec une graine fixe. Sons synthétisés optionnels, sans téléchargement externe. Activation par geste utilisateur ; gain ramené à zéro durant la pause ; au plus douze voix ponctuelles.

**Contrôle** — `AudioContext` : Activation technique vérifiée, pas écoute physique sur matériel

**Cycle de vie** — `FiorinaAudioV105` : Pause, désactivation et destruction ne font avancer aucun objectif.

### PATH
`v105-PATH` · Règles V105

Tout déplacement IA suit une connexion réelle et les mêmes portes.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### NO-SNAP
`v105-NO-SNAP` · Règles V105

Un changement de cible inverse le chemin en cours sans téléporter le corps.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### FLOOR
`v105-FLOOR` · Règles V105

L’attaque exige proximité de hauteur et plan compatibles.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### DOOR
`v105-DOOR` · Règles V105

Un battant fermé bloque passage, vue et contact ; les détenus attendent le passage.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### MEMORY
`v105-MEMORY` · Règles V105

Une trace garde un lieu passé, pas la destination cachée du joueur.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### SERIAL
`v105-SERIAL` · Règles V105

Un bruit déjà consommé ne se réacquiert pas indéfiniment.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### WINDUP
`v105-WINDUP` · Règles V105

Le contact est différé de 0,85 seconde et vérifié au moment de l’impact.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### MISS
`v105-MISS` · Règles V105

Une attaque ratée impose une récupération, sans hit compensatoire.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### PRESENCE
`v105-PRESENCE` · Règles V105

La préparation du moule exige Morse et Dillon aux postes physiques.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### CAPTURE
`v105-CAPTURE` · Règles V105

La coulée ne capture que le Runner réellement dans le volume autorisé.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### AARON
`v105-AARON` · Règles V105

Aaron ne réapparaît pas dans la séquence finale.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### OWNER
`v105-OWNER` · Règles V105

Le pilote V105 et le pilote historique ne causent pas deux attaques du même Runner.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### PAUSE
`v105-PAUSE` · Règles V105

Pause, plan, archives, chargement et mort arrêtent la couche entière.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### SAVE
`v105-SAVE` · Règles V105

Le fichier est validé avant remplacement ; corruption et poses incohérentes sont refusées.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### GRACE
`v105-GRACE` · Règles V105

La reprise n’exécute pas une préparation d’attaque suspendue et laisse une courte grâce.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### FILES
`v105-FILES` · Règles V105

Les exports sont de vrais fichiers ; aucune persistance localStorage native n’est inventée.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### ART
`v105-ART` · Règles V105

Les repères améliorés conservent les appuis historiques ; les sprites natifs restent délégués sans opt-in vectoriel.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### AUDIO
`v105-AUDIO` · Règles V105

L’audio est éteint par défaut et ne produit jamais d’effet de gameplay par lui-même.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### NATIVE
`v105-NATIVE` · Règles V105

La livraison V105 avait constaté une base distante V86 ; cette constatation historique n’est pas une nouvelle vérification du dépôt. V106 exige les octets connus de V105 et n’annonce aucun build natif complet.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### SCOPE
`v105-SCOPE` · Règles V105

Une traversée originale du banc n’est pas une victoire de la campagne du film.

**Vérification** — `qa-v105` : Tests unitaires, navigation, navigateur ou préflight selon le cas. Les scopes ne s’additionnent pas en certification du jeu.

### Une lampe ne révèle pas un acteur à l’étage voisin.
`A3-106-light-floor` · Règles V106

Une lampe ne révèle pas un acteur à l’étage voisin.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Une porte fermée interrompt la contribution de la lampe.
`A3-106-light-door` · Règles V106

Une porte fermée interrompt la contribution de la lampe.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### La perception et le dessin utilisent les mêmes huit commandes existantes.
`A3-106-light-target` · Règles V106

La perception et le dessin utilisent les mêmes huit commandes existantes.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### La pénombre ralentit la reconnaissance
`A3-106-dark-not-safe` · Règles V106

La pénombre ralentit la reconnaissance ; elle ne rend pas invisible au contact.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Le feu du four et la coulée chaude restent lumineux lorsque la lampe de service est coupée.
`A3-106-light-native` · Règles V106

Le feu du four et la coulée chaude restent lumineux lorsque la lampe de service est coupée.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Le bruit conserve sa position au moment de son émission.
`A3-106-sound-origin` · Règles V106

Le bruit conserve sa position au moment de son émission.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### La distance sonore part de la position réelle du Runner sur son segment.
`A3-106-sound-edge` · Règles V106

La distance sonore part de la position réelle du Runner sur son segment.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Une porte fermée atténue le son
`A3-106-sound-door` · Règles V106

Une porte fermée atténue le son ; elle ne disparaît pas du trajet.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Le détour autorisé est évalué, pas seulement la distance à vol d’oiseau.
`A3-106-sound-route` · Règles V106

Le détour autorisé est évalué, pas seulement la distance à vol d’oiseau.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Un événement sonore ne doit pas déclencher une boucle infinie de recherche.
`A3-106-sound-consume` · Règles V106

Un événement sonore ne doit pas déclencher une boucle infinie de recherche.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### La perte de vue conserve la dernière trace, pas la nouvelle position cachée du joueur.
`A3-106-sight-trace` · Règles V106

La perte de vue conserve la dernière trace, pas la nouvelle position cachée du joueur.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Le Runner explore des connexions proches de la trace
`A3-106-search-room` · Règles V106

Le Runner explore des connexions proches de la trace ; il ne se téléporte pas entre elles.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### La morsure vérifie de nouveau étage, portée, profondeur et porte au moment de l’impact.
`A3-106-attack-recheck` · Règles V106

La morsure vérifie de nouveau étage, portée, profondeur et porte au moment de l’impact.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Une reprise n’exécute pas immédiatement une attaque déjà préparée.
`A3-106-attack-resume` · Règles V106

Une reprise n’exécute pas immédiatement une attaque déjà préparée.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Une fermeture est refusée lorsqu’un corps occupe le seuil.
`A3-106-door-occupant` · Règles V106

Une fermeture est refusée lorsqu’un corps occupe le seuil.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Une manœuvre de porte crée un seul bruit depuis cette porte.
`A3-106-door-noise` · Règles V106

Une manœuvre de porte crée un seul bruit depuis cette porte.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Attendre ne place jamais le détenu à son poste.
`A3-106-hold-physical` · Règles V106

Attendre ne place jamais le détenu à son poste.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Repartir conserve le segment et la destination du détenu.
`A3-106-hold-resume` · Règles V106

Repartir conserve le segment et la destination du détenu.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Pause, plan et archives arrêtent aussi les délais d’attente et la perception.
`A3-106-held-pause` · Règles V106

Pause, plan et archives arrêtent aussi les délais d’attente et la perception.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Un fichier incohérent est refusé avant toute modification de la session.
`A3-106-save-atomic` · Règles V106

Un fichier incohérent est refusé avant toute modification de la session.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Un acteur au repos doit être au point indiqué par sa navigation.
`A3-106-save-nav` · Règles V106

Un acteur au repos doit être au point indiqué par sa navigation.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Les bruits et attaques en transit ne sont pas rejoués à l’import.
`A3-106-save-no-events` · Règles V106

Les bruits et attaques en transit ne sont pas rejoués à l’import.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Une saisie dans un champ ne commande pas un détenu.
`A3-106-input-editing` · Règles V106

Une saisie dans un champ ne commande pas un détenu.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Le dessin ne découvre rien et ne modifie pas l’IA.
`A3-106-visual-pure` · Règles V106

Le dessin ne découvre rien et ne modifie pas l’IA.

**Portée** — `Séquences originales V105–V106` : Pas de remplacement aveugle du pilote de campagne natif.

**Preuves** — `qa-v106/unit.json` : Contrat testé sur base instrumentée ; cas de rendu et parcours séparés dans les rapports Chromium.

### Éclairage de la prise d’air
`senses106-shore-light` · Lumière et perception

La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

**Appui** — `f161-spawn` : X 259.5, sol 510 ; profondeur 1.

**Influence** — `245 unités` : Mesure du jeu, pas des mètres relevés sur les décors du film.

**Étage** — `28 unités` : Au-delà, la lampe ne contribue pas à la reconnaissance.

**États** — `I` : Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur.

**Proche dans l’ombre** — `74 unités` : La pénombre n’annule pas la reconnaissance à courte distance.

**Exceptions** — `A3-106-light-native` : Four et coulée chaude gardent leur lumière propre.

### Lampe de soin
`senses106-care-light` · Lumière et perception

La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

**Appui** — `f161-infirmary` : X 1225, sol 510 ; profondeur 1.

**Influence** — `245 unités` : Mesure du jeu, pas des mètres relevés sur les décors du film.

**Étage** — `28 unités` : Au-delà, la lampe ne contribue pas à la reconnaissance.

**États** — `I` : Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur.

**Proche dans l’ombre** — `74 unités` : La pénombre n’annule pas la reconnaissance à courte distance.

**Exceptions** — `A3-106-light-native` : Four et coulée chaude gardent leur lumière propre.

### Éclairage de la coursive
`senses106-cell-light` · Lumière et perception

La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

**Appui** — `f161-cell-a` : X 2020, sol 510 ; profondeur 1.

**Influence** — `245 unités` : Mesure du jeu, pas des mètres relevés sur les décors du film.

**Étage** — `28 unités` : Au-delà, la lampe ne contribue pas à la reconnaissance.

**États** — `I` : Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur.

**Proche dans l’ombre** — `74 unités` : La pénombre n’annule pas la reconnaissance à courte distance.

**Exceptions** — `A3-106-light-native` : Four et coulée chaude gardent leur lumière propre.

### Lampe des communications
`senses106-comms-light` · Lumière et perception

La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

**Appui** — `f161-comms-high` : X 2785, sol 350 ; profondeur 1.

**Influence** — `245 unités` : Mesure du jeu, pas des mètres relevés sur les décors du film.

**Étage** — `28 unités` : Au-delà, la lampe ne contribue pas à la reconnaissance.

**États** — `I` : Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur.

**Proche dans l’ombre** — `74 unités` : La pénombre n’annule pas la reconnaissance à courte distance.

**Exceptions** — `A3-106-light-native` : Four et coulée chaude gardent leur lumière propre.

### Lampe de l’établi
`senses106-service-light` · Lumière et perception

La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

**Appui** — `f161-service-high` : X 3110, sol 330 ; profondeur 1.

**Influence** — `245 unités` : Mesure du jeu, pas des mètres relevés sur les décors du film.

**Étage** — `28 unités` : Au-delà, la lampe ne contribue pas à la reconnaissance.

**États** — `I` : Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur.

**Proche dans l’ombre** — `74 unités` : La pénombre n’annule pas la reconnaissance à courte distance.

**Exceptions** — `A3-106-light-native` : Four et coulée chaude gardent leur lumière propre.

### Éclairage du creuset
`senses106-lead-light` · Lumière et perception

La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

**Appui** — `f161-leadworks` : X 4265, sol 510 ; profondeur 1.

**Influence** — `245 unités` : Mesure du jeu, pas des mètres relevés sur les décors du film.

**Étage** — `28 unités` : Au-delà, la lampe ne contribue pas à la reconnaissance.

**États** — `I` : Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur.

**Proche dans l’ombre** — `74 unités` : La pénombre n’annule pas la reconnaissance à courte distance.

**Exceptions** — `A3-106-light-native` : Four et coulée chaude gardent leur lumière propre.

### Lampe du moule
`senses106-mold-light` · Lumière et perception

La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

**Appui** — `f161-mold` : X 5043.5, sol 510 ; profondeur 1.

**Influence** — `245 unités` : Mesure du jeu, pas des mètres relevés sur les décors du film.

**Étage** — `28 unités` : Au-delà, la lampe ne contribue pas à la reconnaissance.

**États** — `I` : Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur.

**Proche dans l’ombre** — `74 unités` : La pénombre n’annule pas la reconnaissance à courte distance.

**Exceptions** — `A3-106-light-native` : Four et coulée chaude gardent leur lumière propre.

### Éclairage de la plateforme
`senses106-landing-light` · Lumière et perception

La même commande physique alimente le luminaire visible et la lecture de lumière de V106. Son influence diminue avec la distance horizontale ; une autre lampe active peut prendre le dessus. Le rendu ne remplace pas la collision et n’invente pas de couverture.

**Appui** — `f161-extraction` : X 6070, sol 510 ; profondeur 1.

**Influence** — `245 unités` : Mesure du jeu, pas des mètres relevés sur les décors du film.

**Étage** — `28 unités` : Au-delà, la lampe ne contribue pas à la reconnaissance.

**États** — `I` : Allumer et éteindre à portée, avec les contraintes historiques de porte et de profondeur.

**Proche dans l’ombre** — `74 unités` : La pénombre n’annule pas la reconnaissance à courte distance.

**Exceptions** — `A3-106-light-native` : Four et coulée chaude gardent leur lumière propre.

### Acoustique · f161-infirmary-gate
`hearing106-f161-infirmary-gate` · Portes et acoustique

La porte existante conserve son passage et son état. Sa manœuvre réelle produit un bruit unique ; une fermeture refusée parce qu’un corps occupe le seuil ne produit pas ce bruit. Une porte fermée ajoute de l’atténuation, pas une téléportation sonore.

**Connexion** — `f161-e03` : f161-infirmary → f161-cell-a

**Amont** — `f161-infirmary` : {'x': 1120, 'y': 510}

**Aval** — `f161-cell-a` : {'x': 1900, 'y': 510}

**Atténuation porte** — `280` : Coût acoustique abstrait ajouté au trajet.

**Bruit de manœuvre** — `0.78` : Puissance émise depuis la porte ; portée finale évaluée depuis le récepteur.

**Bruit direct** — `A3-106-sound-edge` : Un corridor de sol continu emploie la distance réelle plutôt qu’un détour artificiel par son point le plus proche.

### Acoustique · f161-cellblock-gate
`hearing106-f161-cellblock-gate` · Portes et acoustique

La porte existante conserve son passage et son état. Sa manœuvre réelle produit un bruit unique ; une fermeture refusée parce qu’un corps occupe le seuil ne produit pas ce bruit. Une porte fermée ajoute de l’atténuation, pas une téléportation sonore.

**Connexion** — `f161-e05` : f161-cell-b → f161-service-low

**Amont** — `f161-cell-b` : {'x': 2620, 'y': 510}

**Aval** — `f161-service-low` : {'x': 3070, 'y': 510}

**Atténuation porte** — `280` : Coût acoustique abstrait ajouté au trajet.

**Bruit de manœuvre** — `0.78` : Puissance émise depuis la porte ; portée finale évaluée depuis le récepteur.

**Bruit direct** — `A3-106-sound-edge` : Un corridor de sol continu emploie la distance réelle plutôt qu’un détour artificiel par son point le plus proche.

### Acoustique · f161-leadworks-gate
`hearing106-f161-leadworks-gate` · Portes et acoustique

La porte existante conserve son passage et son état. Sa manœuvre réelle produit un bruit unique ; une fermeture refusée parce qu’un corps occupe le seuil ne produit pas ce bruit. Une porte fermée ajoute de l’atténuation, pas une téléportation sonore.

**Connexion** — `f161-e07` : f161-bishop → f161-leadworks

**Amont** — `f161-bishop` : {'x': 3500, 'y': 510}

**Aval** — `f161-leadworks` : {'x': 4200, 'y': 510}

**Atténuation porte** — `280` : Coût acoustique abstrait ajouté au trajet.

**Bruit de manœuvre** — `0.78` : Puissance émise depuis la porte ; portée finale évaluée depuis le récepteur.

**Bruit direct** — `A3-106-sound-edge` : Un corridor de sol continu emploie la distance réelle plutôt qu’un détour artificiel par son point le plus proche.

### Morse · présence et consignes
`order106-morse` · Coordination V106

Un ordre d’attente conserve la pose, le segment en cours et la destination. G relance le déplacement normal depuis le même endroit. Une fois son poste atteint, le détenu y reste plutôt que de recevoir une fausse nouvelle destination.

**Parcours** — `encounter-rabattage` : Présence limitée à la séquence concernée.

**Départ** — `f161-bishop` : Point réellement occupé à l’initialisation.

**Poste** — `f161-lead-primer` : Position vérifiée avant armement/coulée ; ordre et présence ne sont pas interchangeables.

**Ordre à portée** — `106 / 24 / 0,35` : Distance, différence de pieds et profondeur ; une porte fermée bloque la consigne.

**Reprise** — `save106-session` : L’ordre et la navigation sont validés et conservés par fichier.

### Dillon · présence et consignes
`order106-dillon` · Coordination V106

Un ordre d’attente conserve la pose, le segment en cours et la destination. G relance le déplacement normal depuis le même endroit. Une fois son poste atteint, le détenu y reste plutôt que de recevoir une fausse nouvelle destination.

**Parcours** — `encounter-rabattage` : Présence limitée à la séquence concernée.

**Départ** — `f161-command-post-node` : Point réellement occupé à l’initialisation.

**Poste** — `f161-piston-c-node` : Position vérifiée avant armement/coulée ; ordre et présence ne sont pas interchangeables.

**Ordre à portée** — `106 / 24 / 0,35` : Distance, différence de pieds et profondeur ; une porte fermée bloque la consigne.

**Reprise** — `save106-session` : L’ordre et la navigation sont validés et conservés par fichier.

### Aaron · présence et consignes
`order106-aaron` · Coordination V106

Aaron reste au poste de la séquence antérieure ; il ne reçoit pas une commande de déplacement et ne réapparaît pas dans la fonderie.

**Parcours** — `encounter-traque` : Présence limitée à la séquence concernée.

**Départ** — `f161-clemens-bed` : Point réellement occupé à l’initialisation.

**Poste** — `f161-clemens-bed` : Position vérifiée avant armement/coulée ; ordre et présence ne sont pas interchangeables.

**Ordre à portée** — `106 / 24 / 0,35` : Distance, différence de pieds et profondeur ; une porte fermée bloque la consigne.

**Reprise** — `save106-session` : L’ordre et la navigation sont validés et conservés par fichier.

### Fichier de partie V106
`save106-session` · Reprises V106

L’enveloppe V106 contient le fichier V105 de base, le registre de perception et un dernier poste sûr séparé. La taille est bornée à 1 Mio et l’empreinte sert à détecter la corruption accidentelle, pas à garantir l’authenticité du joueur.

**Migration** — `105 → 106` : Une sauvegarde V105 valide reçoit un registre de perception neuf sans démarrer une autre séquence.

**Vie privée** — `Local` : Aucun téléchargement serveur ni compte ; pas de persistance localStorage annoncée.

**Panneaux** — `Pause` : L’import reprend en pause, sans relancer une attaque suspendue.

### Dernier poste sûr
`save106-safe` · Reprises V106

Le poste sûr doit être vivant, actif, de la même séquence et ne pas avoir une progression future. Après échec, l’export fournit ce poste plutôt que de faire passer la pose morte pour une partie sauvegardable.

**Reprendre** — `R` : Le poste antérieur est utilisé ; l’attaque en transit est neutralisée en récupération.

**Intégrité** — `save106-session` : Le poste est validé lui aussi, pas seulement l’enveloppe principale.

**Limite** — `Fichier explicite` : Le point sûr n’est pas une sauvegarde automatique sur disque.

### Position et navigation dans les reprises
`save106-navigation` · Reprises V106

Un acteur au repos doit être à son point déclaré ; un acteur en trajet doit appartenir au segment courant. Une pose falsifiée mais placée sur un autre sol valide reste refusée, même si son checksum a été recalculé.

**Repos** — `Tolérance 7 unités` : Mesurée au pied central du corps.

**Mouvement** — `Segment courant` : Conserver les coordonnées, ne pas téléporter pour rendre le fichier acceptable.

**Événements transitoires** — `A3-106-save-no-events` : Bruits, appels et attaques suspendus ne sont pas rejoués.

### Examiner le relevé
`operation107-report` · Manœuvres V107

Action de 1,1 s dans la séquence « Un bruit dans les galeries ». L’opération ne donne pas son résultat au début : le propriétaire de progression V105 valide seulement après la durée et la dernière vérification. Le joueur peut s’éloigner sans être bloqué ; il perd alors l’avancement partiel.

**Séquence** — `encounter-traque` : Étape 1 → 2, pas une scène supplémentaire du film.

**Station** — `station-report` : Point f161-service-high ; centre X 3070.0, pied Y 330.

**Appui** — `f161-service-high` : Sol stable ; pas de saut ni de montée pendant le geste.

**Accès** — `A3-107-depth` : Portée 85 unités, hauteur 16 unités et profondeur 0,30. La position interpolée compte.

**Interruption** — `A3-107-motion` : Mouvement, relâchement, blessure, porte ou panneau ; pas d’objectif accordé.

**Dessin** — `A3-107-draw-pure` : Repère sur la pièce réelle : X 3052.63, Y 303.28. Aucune attache à la tête de Ripley.

**Bruit** — `A3-107-machinery` : Puissance abstraite 0.16, émission à la station ; cadence minimale 0,55 s même après annulation/reprise.

**Commande accessible** — `access107-input` : Appuyer conserve la durée, les mêmes vérifications et une annulation explicite.

### Amorcer le collecteur
`operation107-prime` · Manœuvres V107

Action de 1,8 s dans la séquence « Le dernier rabattage ». L’opération ne donne pas son résultat au début : le propriétaire de progression V105 valide seulement après la durée et la dernière vérification. Le joueur peut s’éloigner sans être bloqué ; il perd alors l’avancement partiel.

**Séquence** — `encounter-rabattage` : Étape 1 → 2, pas une scène supplémentaire du film.

**Station** — `station-water` : Point f161-water-header ; centre X 4690.0, pied Y 330.

**Appui** — `f161-water-header` : Sol stable ; pas de saut ni de montée pendant le geste.

**Accès** — `A3-107-depth` : Portée 85 unités, hauteur 16 unités et profondeur 0,30. La position interpolée compte.

**Interruption** — `A3-107-motion` : Mouvement, relâchement, blessure, porte ou panneau ; pas d’objectif accordé.

**Dessin** — `A3-107-draw-pure` : Repère sur la pièce réelle : X 4745.00, Y 282.00. Aucune attache à la tête de Ripley.

**Bruit** — `A3-107-machinery` : Puissance abstraite 0.68, émission à la station ; cadence minimale 0,55 s même après annulation/reprise.

**Commande accessible** — `access107-input` : Appuyer conserve la durée, les mêmes vérifications et une annulation explicite.

### Verrouiller le moule
`operation107-arm` · Manœuvres V107

Action de 1,25 s dans la séquence « Le dernier rabattage ». L’opération ne donne pas son résultat au début : le propriétaire de progression V105 valide seulement après la durée et la dernière vérification. Le joueur peut s’éloigner sans être bloqué ; il perd alors l’avancement partiel.

**Séquence** — `encounter-rabattage` : Étape 2 → 3, pas une scène supplémentaire du film.

**Station** — `station-mold` : Point f161-mold ; centre X 4920.0, pied Y 510.

**Appui** — `f161-mold` : Sol stable ; pas de saut ni de montée pendant le geste.

**Accès** — `A3-107-depth` : Portée 85 unités, hauteur 16 unités et profondeur 0,30. La position interpolée compte.

**Interruption** — `A3-107-motion` : Mouvement, relâchement, blessure, porte ou panneau ; pas d’objectif accordé.

**Dessin** — `A3-107-draw-pure` : Repère sur la pièce réelle : X 5010.50, Y 427.00. Aucune attache à la tête de Ripley.

**Bruit** — `A3-107-machinery` : Puissance abstraite 0.82, émission à la station ; cadence minimale 0,55 s même après annulation/reprise.

**Commande accessible** — `access107-input` : Appuyer conserve la durée, les mêmes vérifications et une annulation explicite.

### Ouvrir l’eau
`operation107-cool` · Manœuvres V107

Action de 2 s dans la séquence « Le dernier rabattage ». L’opération ne donne pas son résultat au début : le propriétaire de progression V105 valide seulement après la durée et la dernière vérification. Le joueur peut s’éloigner sans être bloqué ; il perd alors l’avancement partiel.

**Séquence** — `encounter-rabattage` : Étape 4 → 5, pas une scène supplémentaire du film.

**Station** — `station-water` : Point f161-water-header ; centre X 4690.0, pied Y 330.

**Appui** — `f161-water-header` : Sol stable ; pas de saut ni de montée pendant le geste.

**Accès** — `A3-107-depth` : Portée 85 unités, hauteur 16 unités et profondeur 0,30. La position interpolée compte.

**Interruption** — `A3-107-motion` : Mouvement, relâchement, blessure, porte ou panneau ; pas d’objectif accordé.

**Dessin** — `A3-107-draw-pure` : Repère sur la pièce réelle : X 4745.00, Y 282.00. Aucune attache à la tête de Ripley.

**Bruit** — `A3-107-machinery` : Puissance abstraite 0.96, émission à la station ; cadence minimale 0,55 s même après annulation/reprise.

**Commande accessible** — `access107-input` : Appuyer conserve la durée, les mêmes vérifications et une annulation explicite.

### Les opérations terminées appellent le propriétaire d’objectif existant, sans valider deux fois la même étape.
`A3-107-one-owner` · Règles V107

Les opérations terminées appellent le propriétaire d’objectif existant, sans valider deux fois la même étape.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### La commande exige un appui stable au bon étage.
`A3-107-floor` · Règles V107

La commande exige un appui stable au bon étage.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### La profondeur réellement interpolée est testée pendant toute la manœuvre.
`A3-107-depth` · Règles V107

La profondeur réellement interpolée est testée pendant toute la manœuvre.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Une porte fermée interrompt la manœuvre comme elle en empêche le début.
`A3-107-door` · Règles V107

Une porte fermée interrompt la manœuvre comme elle en empêche le début.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Relâcher E interrompt la manœuvre en mode maintien.
`A3-107-release` · Règles V107

Relâcher E interrompt la manœuvre en mode maintien.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Le mode Appuyer conserve la durée et les contraintes
`A3-107-toggle` · Règles V107

Le mode Appuyer conserve la durée et les contraintes ; une seconde pression annule.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Marcher, grimper, sauter ou changer de profondeur interrompt sans bloquer le joueur.
`A3-107-motion` · Règles V107

Marcher, grimper, sauter ou changer de profondeur interrompt sans bloquer le joueur.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Une blessure interrompt
`A3-107-damage` · Règles V107

Une blessure interrompt ; les dommages ne sont pas neutralisés par la manœuvre.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Pause, plan, archives et perte de focus interrompent
`A3-107-modal` · Règles V107

Pause, plan, archives et perte de focus interrompent ; aucun objectif ne progresse hors jeu.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Morse et Dillon doivent tenir leur poste pendant tout le verrouillage du moule.
`A3-107-participants` · Règles V107

Morse et Dillon doivent tenir leur poste pendant tout le verrouillage du moule.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### La présence à une station est physique, jamais déduite du nom de la salle.
`A3-107-no-remote` · Règles V107

La présence à une station est physique, jamais déduite du nom de la salle.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Chaque bruit de manœuvre part de sa station, pas de la position future du joueur.
`A3-107-machinery` · Règles V107

Chaque bruit de manœuvre part de sa station, pas de la position future du joueur.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Les sons sont émis à cadence bornée, pas une fois par image.
`A3-107-sound-cadence` · Règles V107

Les sons sont émis à cadence bornée, pas une fois par image.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Un détenu produit des pas seulement lorsque sa position réelle change.
`A3-107-crew-footsteps` · Règles V107

Un détenu produit des pas seulement lorsque sa position réelle change.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Un ordre audible provient du détenu auquel Ripley parle.
`A3-107-crew-order` · Règles V107

Un ordre audible provient du détenu auquel Ripley parle.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Un bruit de matériel peut attirer le Runner, mais ne lui livre pas la position cachée de Ripley.
`A3-107-trace` · Règles V107

Un bruit de matériel peut attirer le Runner, mais ne lui livre pas la position cachée de Ripley.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### La coulée reste une commande brève à utiliser quand le Runner est dans le moule
`A3-107-emergency-lever` · Règles V107

La coulée reste une commande brève à utiliser quand le Runner est dans le moule ; aucun délai arbitraire ne le téléporte ou l’y immobilise.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Une manœuvre partielle n’est jamais reprise automatiquement depuis un fichier.
`A3-107-no-partial-import` · Règles V107

Une manœuvre partielle n’est jamais reprise automatiquement depuis un fichier.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Le dernier poste sûr conserve le mode de commande
`A3-107-safe-settings` · Règles V107

Le dernier poste sûr conserve le mode de commande ; l’import reprend en pause.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Les opérations consignées doivent correspondre aux étapes réellement acquises.
`A3-107-strict-sequence` · Règles V107

Les opérations consignées doivent correspondre aux étapes réellement acquises.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Les fichiers V105/V106 valides migrent sans devoir refaire leurs objectifs déjà terminés.
`A3-107-old-files` · Règles V107

Les fichiers V105/V106 valides migrent sans devoir refaire leurs objectifs déjà terminés.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Le dessin montre l’avancement mais ne change ni les étapes, ni les sons, ni la sauvegarde.
`A3-107-draw-pure` · Règles V107

Le dessin montre l’avancement mais ne change ni les étapes, ni les sons, ni la sauvegarde.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Aucun nouveau rang ni compteur de collecte obligatoire n’est ajouté.
`A3-107-no-score` · Règles V107

Aucun nouveau rang ni compteur de collecte obligatoire n’est ajouté.

**Validation** — `qa-v107/unit.json` : automated/local

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### La couche s’active uniquement dans les deux séquences originales, pas dans toutes les cinématiques historiques.
`A3-107-scope` · Règles V107

La couche s’active uniquement dans les deux séquences originales, pas dans toutes les cinématiques historiques.

**Validation** — `qa-v107/unit.json` : scope

**Périmètre** — `Séquences originales` : Le contrôleur simplifié du banc n’est pas le jeu principal complet.

### Petit poste du collecteur
`operator107-water` · Postes de commande

Le point de commande historique du collecteur ne possédait pas de petit pupitre propre. V107 place quatre composants sur sa plateforme réelle : boîtier, tige, volant et cadran. Le cadran suit l’avancement de l’amorçage, puis l’état acquis. Ce petit ensemble décoratif n’ajoute aucune collision, nouvelle route ou collecte.

**Appui** — `f161-water-header` : La plateforme existante conserve son étendue et sa hauteur.

**housing** — `water-housing-107` : X 4733 ; Y 292 ; 26 × 38 ; pose floor, collision none.

**pipe** — `water-stem-107` : X 4741 ; Y 246 ; 8 × 84 ; pose floor, collision none.

**wheel** — `water-wheel-107` : X 4729 ; Y 266 ; 32 × 32 ; pose bracket, collision none.

**gauge** — `water-gauge-107` : X 4734 ; Y 241 ; 22 × 22 ; pose pipe, collision none.

### Boîtier du collecteur
`water-housing-107` · Composants V107

Composant du petit poste de commande ; position fixée à un appui du niveau, jamais à la caméra ou au personnage.

**Ensemble** — `operator107-water` : Raccord visuel, pas nouvelle machine de physique.

**Appui** — `f161-water-header` : X 4733 ; Y 292 ; largeur 26 ; hauteur 38.

**Pose** — `floor` : Collision : aucune.

### Tige et conduite
`water-stem-107` · Composants V107

Composant du petit poste de commande ; position fixée à un appui du niveau, jamais à la caméra ou au personnage.

**Ensemble** — `operator107-water` : Raccord visuel, pas nouvelle machine de physique.

**Appui** — `f161-water-header` : X 4741 ; Y 246 ; largeur 8 ; hauteur 84.

**Pose** — `floor` : Collision : aucune.

### Volant de service
`water-wheel-107` · Composants V107

Composant du petit poste de commande ; position fixée à un appui du niveau, jamais à la caméra ou au personnage.

**Ensemble** — `operator107-water` : Raccord visuel, pas nouvelle machine de physique.

**Appui** — `f161-water-header` : X 4729 ; Y 266 ; largeur 32 ; hauteur 32.

**Pose** — `bracket` : Collision : aucune.

### Cadran de pression
`water-gauge-107` · Composants V107

Composant du petit poste de commande ; position fixée à un appui du niveau, jamais à la caméra ou au personnage.

**Ensemble** — `operator107-water` : Raccord visuel, pas nouvelle machine de physique.

**Appui** — `f161-water-header` : X 4734 ; Y 241 ; largeur 22 ; hauteur 22.

**Pose** — `pipe` : Collision : aucune.

### Maintenir ou appuyer
`access107-input` · Commandes accessibles

Le mode Maintenir demande de garder E. Le mode Appuyer démarre par une pression et s’annule par une autre. Les deux durent le même temps et restent interrompus par mouvement, blessure, porte, pause, plan ou archives. Le bouton tactile Agir reçoit un vrai maintien et libère l’état à l’annulation du pointeur.

**Réglage** — `Options` : Choix explicite dans le menu ; sauvegardé par fichier.

**Sauvegarde** — `save107-current` : Le choix est conservé sans reprendre une commande partielle.

**Limite** — `Matériel` : Le pointeur a été testé dans Chromium ; aucune manette physique n’a été qualifiée.

### Fichier V107
`save107-current` · Reprises V107

L’enveloppe contient la session V106 vérifiée, le registre des manœuvres et un dernier poste sûr séparé. Aucune opération active n’est sérialisée. Les tâches consignées doivent correspondre à la progression existante, même si l’empreinte extérieure a été recalculée.

**Limite** — `1 Mio` : La taille est vérifiée avant analyse.

**Contrat** — `A3-107-no-partial-import` : Une reprise ne valide pas spontanément une commande.

**Authenticité** — `Empreinte FNV` : Détection de corruption, pas protection anti-triche.

### Reprendre sans rejouer le geste
`save107-checkpoint` · Reprises V107

Le poste sûr doit rester vivant et actif, dans la même séquence, à un stade non futur. Une fin de manœuvre prépare son registre stable avant le callback de checkpoint ; une manœuvre partielle ne peut pas remplacer le poste sûr.

**En cas d’échec** — `R` : Repartir d’un poste antérieur, pas de la pose morte.

**Options** — `access107-input` : Le réglage Maintenir/Appuyer est conservé dans le poste.

**Atomicité** — `save107-current` : Le fichier entier est vérifié avant remplacement de la session.

### Reprendre les fichiers V105 et V106
`save107-migration` · Reprises V107

Les fichiers antérieurs valides gardent leur progression. Les tâches déjà acquises sont dérivées des étapes et ne doivent pas être rejouées. Le poste sûr V106 est migré distinctement de l’état courant, même si sa progression est antérieure.

**Héritage** — `save106-navigation` : Position, navigation, portes et présence des participants restent contrôlées.

**Reprise** — `Pause` : L’import ne reprend ni touche maintenue ni bruit en transit.

**Pas de cloud** — `Fichier explicite` : Aucune sauvegarde automatique sur disque ni compte externe.

### La préparation s’entend
`sound107-work` · Bruits de préparation

Les quatre manœuvres émettent depuis leur station. Les pas des détenus dépendent de leur distance réellement parcourue ; un détenu arrêté ne marche pas sur place. Un ordre audible provient du détenu qui répond à Ripley. Ces événements entrent dans le même calcul de portée V106 que les bruits du joueur.

**Cadence des machines** — `0,55 s` : Un nouveau geste n’efface pas la limite anti-rafale.

**Pas des détenus** — `62 unités` : Puissance 0,23 ; silence lorsque le corps ne se déplace pas.

**Consigne** — `0,46` : Puissance abstraite ; portée calculée sur les passages et portes.

**Limite narrative** — `encounter-rabattage` : Pendant les premiers préparatifs, le Runner est volontairement dormant ; l’ambiance sonore ne change pas cette condition de la séquence.

### Trois identités de boulon, pas un stock abstrait qui se régénère.
`A3-108-stock` · Règles V108

Trois identités de boulon, pas un stock abstrait qui se régénère.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Le lancer commence à la main de Ripley et conserve sa profondeur.
`A3-108-origin` · Règles V108

Le lancer commence à la main de Ripley et conserve sa profondeur.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Le lancer suit la direction du personnage
`A3-108-facing` · Règles V108

Le lancer suit la direction du personnage ; aucune cible distante n’est choisie par téléportation.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Le boulon suit un arc intégré en sous-pas
`A3-108-arc` · Règles V108

Le boulon suit un arc intégré en sous-pas ; les déplacements balayent leur segment.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Le sol, le dessous des plateformes et les portes fermées arrêtent ou font rebondir l’objet.
`A3-108-solid` · Règles V108

Le sol, le dessous des plateformes et les portes fermées arrêtent ou font rebondir l’objet.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Les alcôves et objets du fond ne sont pas des obstacles physiques inventés.
`A3-108-art` · Règles V108

Les alcôves et objets du fond ne sont pas des obstacles physiques inventés.

**Vérification** — `qa-v108/unit.json` : scope / automated

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Le bruit est émis au point d’impact, à sa profondeur et son étage.
`A3-108-impact` · Règles V108

Le bruit est émis au point d’impact, à sa profondeur et son étage.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Aucun bruit de diversion n’est émis avant le premier impact.
`A3-108-silent-air` · Règles V108

Aucun bruit de diversion n’est émis avant le premier impact.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Deux rebonds amortis au maximum, puis immobilisation au sol.
`A3-108-bounce` · Règles V108

Deux rebonds amortis au maximum, puis immobilisation au sol.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Un délai empêche un obstacle mince de déclencher une rafale de sons.
`A3-108-voice-limit` · Règles V108

Un délai empêche un obstacle mince de déclencher une rafale de sons.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Le bruit est traité par l’audition existante
`A3-108-attention` · Règles V108

Le bruit est traité par l’audition existante ; il ne force ni reconnaissance ni annulation d’attaque.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Le Runner reçoit la dernière origine du bruit, jamais la position cachée actuelle du joueur.
`A3-108-trace` · Règles V108

Le Runner reçoit la dernière origine du bruit, jamais la position cachée actuelle du joueur.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Le prédateur reste dormant durant la préparation du piège qui le prévoit.
`A3-108-dormant` · Règles V108

Le prédateur reste dormant durant la préparation du piège qui le prévoit.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Un boulon ne blesse et ne fige aucun acteur.
`A3-108-no-damage` · Règles V108

Un boulon ne blesse et ne fige aucun acteur.

**Vérification** — `qa-v108/unit.json` : scope / automated

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Ramasser exige appui, même profondeur, même étage et passage dégagé.
`A3-108-near-pickup` · Règles V108

Ramasser exige appui, même profondeur, même étage et passage dégagé.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Le même boulon repasse dans la poche, sans produire de copie.
`A3-108-recover` · Règles V108

Le même boulon repasse dans la poche, sans produire de copie.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Un objet tombé hors du niveau ou dans le plomb chaud est perdu pour ce parcours.
`A3-108-lost` · Règles V108

Un objet tombé hors du niveau ou dans le plomb chaud est perdu pour ce parcours.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Une manœuvre active empêche le lancer
`A3-108-busy` · Règles V108

Une manœuvre active empêche le lancer ; sa durée et son propriétaire ne sont pas modifiés.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### La cadence du lancer ne dépend pas du nombre de répétitions clavier.
`A3-108-limited-rate` · Règles V108

La cadence du lancer ne dépend pas du nombre de répétitions clavier.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Pause, plan, archives, échec et perte de focus suspendent les objets.
`A3-108-modal` · Règles V108

Pause, plan, archives, échec et perte de focus suspendent les objets.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Fermer un panneau ne déclenche pas un lancer qui avait été refusé.
`A3-108-no-autothrow` · Règles V108

Fermer un panneau ne déclenche pas un lancer qui avait été refusé.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Boutons tactiles et clavier appellent les mêmes méthodes de lancer et de récupération.
`A3-108-pointer` · Règles V108

Boutons tactiles et clavier appellent les mêmes méthodes de lancer et de récupération.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Le fichier conserve le mouvement d’un boulon en vol, mais aucun son en attente.
`A3-108-save-air` · Règles V108

Le fichier conserve le mouvement d’un boulon en vol, mais aucun son en attente.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### La position au repos doit correspondre à un support réel.
`A3-108-save-ground` · Règles V108

La position au repos doit correspondre à un support réel.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Les états poche, vol, sol et perdu doivent toujours totaliser trois objets.
`A3-108-save-count` · Règles V108

Les états poche, vol, sol et perdu doivent toujours totaliser trois objets.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Le poste sûr conserve son stock propre, distinct de la situation courante.
`A3-108-safe` · Règles V108

Le poste sûr conserve son stock propre, distinct de la situation courante.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Les fichiers V105, V106 et V107 valides reçoivent une réserve initiale lors de la migration.
`A3-108-migration` · Règles V108

Les fichiers V105, V106 et V107 valides reçoivent une réserve initiale lors de la migration.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### La validation vérifie aussi les positions et les invariants
`A3-108-checksum` · Règles V108

La validation vérifie aussi les positions et les invariants ; l’empreinte seule ne suffit pas.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Dessiner l’arc ou les impacts n’avance ni physique ni audition.
`A3-108-render` · Règles V108

Dessiner l’arc ou les impacts n’avance ni physique ni audition.

**Vérification** — `qa-v108/unit.json` : automated / browser

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Mécanique originale du banc et des séquences optionnelles
`A3-108-scope` · Règles V108

Mécanique originale du banc et des séquences optionnelles ; aucun équipement natif de campagne remplacé.

**Vérification** — `qa-v108/unit.json` : scope / automated

**Champ d’application** — `encounter-traque` : Banc à contrôleur simplifié et séquences originales ; pas campagne native complète.

### Dans la poche
`state108-pocket` · États des boulons

Aucune pose mondiale : X et Y sont nuls, les vitesses valent zéro. Le compteur de lancers reste conservé pour empêcher la copie d’un même objet.

**Transition** — `A3-108-save-count` : La touche T prend une identité disponible, jamais un nouvel objet.

**Limite** — `A3-108-no-damage` : Aucun dégât, étourdissement ou blocage d’acteur.

### En vol
`state108-flying` · États des boulons

Position, vitesse, profondeur et origine sont conservées. La gravité et les intersections sont calculées en sous-pas ; un événement sonore n’est produit que lors d’un impact réel.

**Transition** — `A3-108-save-count` : Un import conserve la trajectoire et attend la reprise explicite.

**Limite** — `A3-108-no-damage` : Aucun dégât, étourdissement ou blocage d’acteur.

### Posé au sol
`state108-rest` · États des boulons

Le pied du boulon, y + 3,5, doit coïncider avec la hauteur d’un support identifié. Il ne revient pas automatiquement dans la poche.

**Transition** — `A3-108-save-count` : La touche Y exige proximité, appui, même étage, même profondeur et aucun battant fermé interposé.

**Limite** — `A3-108-no-damage` : Aucun dégât, étourdissement ou blocage d’acteur.

### Perdu
`state108-lost` · États des boulons

Un boulon hors du niveau ou dans le plomb chaud n’est plus récupérable dans ce parcours. La même identité reste comptée comme perdue.

**Transition** — `A3-108-save-count` : Le dernier poste sûr peut contenir un état antérieur distinct ; aucune recharge temporelle n’est ajoutée.

**Limite** — `A3-108-no-damage` : Aucun dégât, étourdissement ou blocage d’acteur.

### Support de lancer · support-0
`surface108-support-0` · Surfaces de collision V108

Surface fusionnée à la hauteur Y 190, étendue X 2055 à 2755, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

**Coordonnées** — `A3-108-solid` : X 2055, Y 190, largeur 700, hauteur 12 unités du jeu.

**Repos** — `state108-rest` : Centre du boulon posé à Y 186.5.

**Balayage** — `A3-108-arc` : Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme.

### Support de lancer · support-1
`surface108-support-1` · Surfaces de collision V108

Surface fusionnée à la hauteur Y 190, étendue X 3225 à 3395, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

**Coordonnées** — `A3-108-solid` : X 3225, Y 190, largeur 170, hauteur 12 unités du jeu.

**Repos** — `state108-rest` : Centre du boulon posé à Y 186.5.

**Balayage** — `A3-108-arc` : Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme.

### Support de lancer · support-2
`surface108-support-2` · Surfaces de collision V108

Surface fusionnée à la hauteur Y 190, étendue X 4635 à 4805, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

**Coordonnées** — `A3-108-solid` : X 4635, Y 190, largeur 170, hauteur 12 unités du jeu.

**Repos** — `state108-rest` : Centre du boulon posé à Y 186.5.

**Balayage** — `A3-108-arc` : Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme.

### Support de lancer · support-3
`surface108-support-3` · Surfaces de collision V108

Surface fusionnée à la hauteur Y 190, étendue X 5865 à 6055, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

**Coordonnées** — `A3-108-solid` : X 5865, Y 190, largeur 190, hauteur 12 unités du jeu.

**Repos** — `state108-rest` : Centre du boulon posé à Y 186.5.

**Balayage** — `A3-108-arc` : Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme.

### Support de lancer · support-4
`surface108-support-4` · Surfaces de collision V108

Surface fusionnée à la hauteur Y 330, étendue X 670 à 890, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

**Coordonnées** — `A3-108-solid` : X 670, Y 330, largeur 220, hauteur 12 unités du jeu.

**Repos** — `state108-rest` : Centre du boulon posé à Y 326.5.

**Balayage** — `A3-108-arc` : Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme.

### Support de lancer · support-5
`surface108-support-5` · Surfaces de collision V108

Surface fusionnée à la hauteur Y 330, étendue X 2855 à 5880, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

**Coordonnées** — `A3-108-solid` : X 2855, Y 330, largeur 3025, hauteur 12 unités du jeu.

**Repos** — `state108-rest` : Centre du boulon posé à Y 326.5.

**Balayage** — `A3-108-arc` : Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme.

### Support de lancer · support-6
`surface108-support-6` · Surfaces de collision V108

Surface fusionnée à la hauteur Y 330, étendue X 5945 à 6195, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

**Coordonnées** — `A3-108-solid` : X 5945, Y 330, largeur 250, hauteur 12 unités du jeu.

**Repos** — `state108-rest` : Centre du boulon posé à Y 326.5.

**Balayage** — `A3-108-arc` : Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme.

### Support de lancer · support-7
`surface108-support-7` · Surfaces de collision V108

Surface fusionnée à la hauteur Y 350, étendue X 1175 à 2810, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

**Coordonnées** — `A3-108-solid` : X 1175, Y 350, largeur 1635, hauteur 12 unités du jeu.

**Repos** — `state108-rest` : Centre du boulon posé à Y 346.5.

**Balayage** — `A3-108-arc` : Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme.

### Support de lancer · support-8
`surface108-support-8` · Surfaces de collision V108

Surface fusionnée à la hauteur Y 510, étendue X 50 à 6190, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

**Coordonnées** — `A3-108-solid` : X 50, Y 510, largeur 6140, hauteur 12 unités du jeu.

**Repos** — `state108-rest` : Centre du boulon posé à Y 506.5.

**Balayage** — `A3-108-arc` : Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme.

### Support de lancer · support-9
`surface108-support-9` · Surfaces de collision V108

Surface fusionnée à la hauteur Y 630, étendue X 710 à 930, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

**Coordonnées** — `A3-108-solid` : X 710, Y 630, largeur 220, hauteur 12 unités du jeu.

**Repos** — `state108-rest` : Centre du boulon posé à Y 626.5.

**Balayage** — `A3-108-arc` : Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme.

### Support de lancer · support-10
`surface108-support-10` · Surfaces de collision V108

Surface fusionnée à la hauteur Y 630, étendue X 1940 à 2160, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

**Coordonnées** — `A3-108-solid` : X 1940, Y 630, largeur 220, hauteur 12 unités du jeu.

**Repos** — `state108-rest` : Centre du boulon posé à Y 626.5.

**Balayage** — `A3-108-arc` : Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme.

### Support de lancer · support-11
`surface108-support-11` · Surfaces de collision V108

Surface fusionnée à la hauteur Y 630, étendue X 2875 à 4640, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

**Coordonnées** — `A3-108-solid` : X 2875, Y 630, largeur 1765, hauteur 12 unités du jeu.

**Repos** — `state108-rest` : Centre du boulon posé à Y 626.5.

**Balayage** — `A3-108-arc` : Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme.

### Support de lancer · support-12
`surface108-support-12` · Surfaces de collision V108

Surface fusionnée à la hauteur Y 630, étendue X 4670 à 5175, épaisseur de collision 12. Elle provient des appuis du contrôleur partagé ; ce n’est pas un objet décoratif rendu solide.

**Coordonnées** — `A3-108-solid` : X 4670, Y 630, largeur 505, hauteur 12 unités du jeu.

**Repos** — `state108-rest` : Centre du boulon posé à Y 626.5.

**Balayage** — `A3-108-arc` : Intégration en sous-pas de 0.008333 seconde au plus ; collision également sous la plateforme.

### Impact sur f161-infirmary-gate
`gate108-f161-infirmary-gate` · Portes et projectiles

Porte existante de Fiorina : X 1488, Y 378, dimensions 44 × 132. Ouverte, elle laisse passer le boulon. Fermée, le segment de vol peut la rencontrer et repartir en sens inverse avec une vitesse amortie.

**Porte d’origine** — `f161-infirmary-gate` : Aucun nouveau battant ni verrou de mission.

**Origine sonore** — `A3-108-impact` : L’événement vient du point touché sur le battant, pas de la position actuelle de Ripley.

**Sauvegarde** — `save108-current` : La validation reconstruit la géométrie réelle depuis les états de porte sauvegardés.

### Impact sur f161-cellblock-gate
`gate108-f161-cellblock-gate` · Portes et projectiles

Porte existante de Fiorina : X 2823, Y 378, dimensions 44 × 132. Ouverte, elle laisse passer le boulon. Fermée, le segment de vol peut la rencontrer et repartir en sens inverse avec une vitesse amortie.

**Porte d’origine** — `f161-cellblock-gate` : Aucun nouveau battant ni verrou de mission.

**Origine sonore** — `A3-108-impact` : L’événement vient du point touché sur le battant, pas de la position actuelle de Ripley.

**Sauvegarde** — `save108-current` : La validation reconstruit la géométrie réelle depuis les états de porte sauvegardés.

### Impact sur f161-leadworks-gate
`gate108-f161-leadworks-gate` · Portes et projectiles

Porte existante de Fiorina : X 3828, Y 378, dimensions 44 × 132. Ouverte, elle laisse passer le boulon. Fermée, le segment de vol peut la rencontrer et repartir en sens inverse avec une vitesse amortie.

**Porte d’origine** — `f161-leadworks-gate` : Aucun nouveau battant ni verrou de mission.

**Origine sonore** — `A3-108-impact` : L’événement vient du point touché sur le battant, pas de la position actuelle de Ripley.

**Sauvegarde** — `save108-current` : La validation reconstruit la géométrie réelle depuis les états de porte sauvegardés.

### Lancer un boulon
`input108-throw` · Commandes V108

T ou le bouton « Lancer » prend l’un des trois boulons en poche. Le départ se fait à la main et suit la direction du corps. Il n’existe pas de paramètre de ciblage distant ni de lancer instantanément matérialisé près du Runner.

**Poche** — `state108-pocket` : Réserve maximale 3 ; cadence 0.85 s.

**Appui** — `A3-108-origin` : Ripley doit être vivante, au sol et hors d’une montée.

**Conflit** — `A3-108-busy` : Une manœuvre active conserve la priorité.

**Arc** — `state108-flying` : Vitesse initiale horizontale 345 ; verticale -142 ; gravité 620 en unités du jeu.

### Ramasser le boulon
`input108-recover` · Commandes V108

Y ou le bouton « Ramasser » récupère une identité posée à portée réelle. Ce n’est ni une aspiration à distance ni un remplissage automatique après un lancer.

**Portée** — `A3-108-near-pickup` : 42 unités horizontales, 15 verticales et 0.28 de profondeur.

**Surface** — `state108-rest` : Le support doit encore justifier le repos.

**Conservation** — `A3-108-recover` : Un second appui ne produit pas de quatrième objet.

### Boulon 1
`object108-bolt-1` · Objets persistants V108

Identité persistante d’un objet métallique ordinaire. La forme et les capacités sont les mêmes pour les trois objets ; ces fiches ne correspondent pas à trois nouveaux modèles artistiques.

**Au départ** — `state108-pocket` : Dans la poche, jamais déjà posé devant le joueur.

**En déplacement** — `state108-flying` : Origine et nombre de lancers restent associés à cette identité.

**Récupération** — `input108-recover` : Le même identifiant est rendu à la poche.

**Perte** — `state108-lost` : Aucune duplication ni réapparition pendant le parcours.

### Boulon 2
`object108-bolt-2` · Objets persistants V108

Identité persistante d’un objet métallique ordinaire. La forme et les capacités sont les mêmes pour les trois objets ; ces fiches ne correspondent pas à trois nouveaux modèles artistiques.

**Au départ** — `state108-pocket` : Dans la poche, jamais déjà posé devant le joueur.

**En déplacement** — `state108-flying` : Origine et nombre de lancers restent associés à cette identité.

**Récupération** — `input108-recover` : Le même identifiant est rendu à la poche.

**Perte** — `state108-lost` : Aucune duplication ni réapparition pendant le parcours.

### Boulon 3
`object108-bolt-3` · Objets persistants V108

Identité persistante d’un objet métallique ordinaire. La forme et les capacités sont les mêmes pour les trois objets ; ces fiches ne correspondent pas à trois nouveaux modèles artistiques.

**Au départ** — `state108-pocket` : Dans la poche, jamais déjà posé devant le joueur.

**En déplacement** — `state108-flying` : Origine et nombre de lancers restent associés à cette identité.

**Récupération** — `input108-recover` : Le même identifiant est rendu à la poche.

**Perte** — `state108-lost` : Aucune duplication ni réapparition pendant le parcours.

### Fichier V108
`save108-current` · Reprises V108

La session V107 est validée puis le registre des trois boulons. Un objet en vol conserve sa pose, sa vitesse et sa profondeur ; un objet posé doit coïncider avec un appui réel. L’enveloppe est limitée à 1 Mio.

**Validation** — `A3-108-checksum` : L’empreinte FNV détecte une corruption, pas une signature anti-triche. Les invariants et collisions sont vérifiés ensuite.

**Comptage** — `A3-108-save-count` : Trois états au total, identités uniques, compteurs de lancers et de récupérations cohérents.

**Import** — `A3-108-save-air` : Reprise en pause, sans refaire l’impact précédent.

### Poche du dernier poste sûr
`save108-checkpoint` · Reprises V108

Le poste sûr garde sa réserve et ses poses propres, distinctes de la partie courante. Une manœuvre active ne remplace pas ce poste. Il doit être vivant, actif, dans la même séquence et à un stade non futur.

**Reprise** — `save107-checkpoint` : Le propriétaire V107 garde son registre de gestes terminés.

**Atomicité** — `save108-current` : La validation d’un poste corrompu refuse tout le fichier avant de remplacer la session.

### Migrer un fichier antérieur
`save108-migration` · Reprises V108

Les fichiers V105, V106 et V107 valides reçoivent trois boulons en poche. Le poste sûr antérieur est migré séparément. Aucun état d’attente, lumière ou objectif déjà acquis n’est remplacé par une nouvelle partie.

**Sources** — `save106-navigation` : Contrôles historiques de position et navigation conservés.

**Manœuvres** — `save107-current` : Pas de préparation partielle réactivée.

**Périmètre** — `A3-108-scope` : Pas de cloud, autosauvegarde sur disque ou certification anti-triche.

### Enquêter sur un impact
`hearing108-impact` · Perception V108

Le bruit entre dans l’audition V106 avec la position réellement touchée. Le Runner peut conserver la trace de l’impact et rechercher un point atteignable du réseau proche. Il ne reçoit pas la position cachée actuelle de Ripley.

**Intensité** — `A3-108-impact` : Premier impact : puissance abstraite 0.82. Rebonds : 0.4264. Cadence minimale 0.12 s.

**Contraintes** — `A3-108-attention` : Une attaque déjà engagée ou une reconnaissance récente ne sont pas annulées par la diversion.

**Distance** — `A3-108-trace` : Un détour d’étage ou une porte peuvent rendre le bruit inaudible.

**Rabattage** — `A3-108-dormant` : Pendant la préparation antérieure à l’armement, le prédateur reste dormant.

### Petit objet, repère local
`art108-bolt` · Rendu V108

Le boulon est dessiné par le module livré à sa position mondiale avec la même profondeur logique que lors du lancer. Le bref repère d’impact s’efface aussi au repos ; il ne pulse pas indéfiniment.

**Pureté** — `A3-108-render` : Dessiner ne fait avancer ni objet, ni perception, ni sauvegarde.

**Réserve** — `input108-throw` : Le petit panneau affiche seulement la commande utile et le nombre en poche.

**Art** — `Silhouettes provisoires` : Aucun nouveau sprite officiel ni pack photoréaliste annoncé.

### Chaque conduite possède sa réserve indépendante
`A3-109-pressure` · Règles V109

Chaque conduite possède sa réserve indépendante. Pas de recharge pendant son souffle.

**Preuve** — `qa-v109/unit.json` : Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète.

**Parcours** — `encounter-traque` : Les ouvertures au clavier sont séparées des comparaisons de porte dirigées.

### La vanne demande un appui stable, le bon étage, la profondeur et un accès sans porte
`A3-109-distance` · Règles V109

La vanne demande un appui stable, le bon étage, la profondeur et un accès sans porte.

**Preuve** — `qa-v109/unit.json` : Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète.

**Parcours** — `encounter-traque` : Les ouvertures au clavier sont séparées des comparaisons de porte dirigées.

### Maintenir V pendant 1,40 seconde, ou utiliser le mode Appuyer existant
`A3-109-gesture` · Règles V109

Maintenir V pendant 1,40 seconde, ou utiliser le mode Appuyer existant.

**Preuve** — `qa-v109/unit.json` : Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète.

**Parcours** — `encounter-traque` : Les ouvertures au clavier sont séparées des comparaisons de porte dirigées.

### Mouvement, saut, dommage, relâchement et ouverture d’un panneau annulent le geste
`A3-109-abort` · Règles V109

Mouvement, saut, dommage, relâchement et ouverture d’un panneau annulent le geste.

**Preuve** — `qa-v109/unit.json` : Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète.

**Parcours** — `encounter-traque` : Les ouvertures au clavier sont séparées des comparaisons de porte dirigées.

### La vapeur chaude dure 4,8 secondes, suivie de 1,2 seconde de dissipation sans dommage
`A3-109-duration` · Règles V109

La vapeur chaude dure 4,8 secondes, suivie de 1,2 seconde de dissipation sans dommage.

**Preuve** — `qa-v109/unit.json` : Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète.

**Parcours** — `encounter-traque` : Les ouvertures au clavier sont séparées des comparaisons de porte dirigées.

### Un battant existant fermé tronque le jet ; les petits décors ne créent aucune collision
`A3-109-collision` · Règles V109

Un battant existant fermé tronque le jet ; les petits décors ne créent aucune collision.

**Preuve** — `qa-v109/unit.json` : Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète.

**Parcours** — `encounter-traque` : Les ouvertures au clavier sont séparées des comparaisons de porte dirigées.

### Le champ coupe la reconnaissance à distance ; il ne cache ni le contact proche ni la dernière trace
`A3-109-sight` · Règles V109

Le champ coupe la reconnaissance à distance ; il ne cache ni le contact proche ni la dernière trace.

**Preuve** — `qa-v109/unit.json` : Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète.

**Parcours** — `encounter-traque` : Les ouvertures au clavier sont séparées des comparaisons de porte dirigées.

### Le sifflement vient de la buse
`A3-109-sound` · Règles V109

Le sifflement vient de la buse. Les petits bruits proches sont atténués, pas effacés.

**Preuve** — `qa-v109/unit.json` : Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète.

**Parcours** — `encounter-traque` : Les ouvertures au clavier sont séparées des comparaisons de porte dirigées.

### Traverser le jet chaud peut brûler Ripley
`A3-109-danger` · Règles V109

Traverser le jet chaud peut brûler Ripley. Ni arme anti-Runner ni dommage ajouté aux détenus.

**Preuve** — `qa-v109/unit.json` : Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète.

**Parcours** — `encounter-traque` : Les ouvertures au clavier sont séparées des comparaisons de porte dirigées.

### Le plan et la pause arrêtent pression, jet, chaleur et bruit
`A3-109-pause` · Règles V109

Le plan et la pause arrêtent pression, jet, chaleur et bruit.

**Preuve** — `qa-v109/unit.json` : Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète.

**Parcours** — `encounter-traque` : Les ouvertures au clavier sont séparées des comparaisons de porte dirigées.

### Une reprise conserve le jet et la réserve, pas un geste maintenu ou un son en attente
`A3-109-save` · Règles V109

Une reprise conserve le jet et la réserve, pas un geste maintenu ou un son en attente.

**Preuve** — `qa-v109/unit.json` : Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète.

**Parcours** — `encounter-traque` : Les ouvertures au clavier sont séparées des comparaisons de porte dirigées.

### Aucun objectif natif, débit d’eau du piège, consommation de plomb ou graphe n’est remplacé
`A3-109-scope` · Règles V109

Aucun objectif natif, débit d’eau du piège, consommation de plomb ou graphe n’est remplacé.

**Preuve** — `qa-v109/unit.json` : Contrats purs et couches réelles sur une base instrumentée. Pas la campagne native complète.

**Parcours** — `encounter-traque` : Les ouvertures au clavier sont séparées des comparaisons de porte dirigées.

### Purge des galeries
`purge109-gallery-purge` · Conduites de purge

Poste rattaché à f161-service-low, dans l’ensemble service-pump. Une réserve de 100 unités abstraites alimente ce seul jet. Ouvrir coûte 70 unités et ne dépense ni eau du piège ni plomb.

**Appui** — `f161-service-low` : Pied Y 510, support node-platform-f161-service-low, profondeur 1.

**Commande** — `input109-purge` : Centre du volant (3012, 465), portée horizontale 53, tolérance verticale 22, profondeur ±0.4.

**Buse** — `field109-gallery-purge` : Origine (3128, 452) ; sens 1, portée maximale 156.

**Réserve** — `steamstate109-refill` : Recharge de 7 unités/s après fin de dissipation ; aucun cumul de jets.

### Boîtier de vanne · Purge des galeries
`part109-gallery-purge-box` · Composants V109

X 2992, Y 435, 40 × 55 unités. Platine en retrait ; aucun obstacle nouveau.

**Ensemble propriétaire** — `purge109-gallery-purge` : Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques.

**Silhouette** — `art109-render` : L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra.

### Volant et cadran · Purge des galeries
`part109-gallery-purge-wheel` · Composants V109

Volant de rayon 12 à (3012, 469), cadran de rayon 8 à Y 446. L’aiguille utilise la réserve réelle.

**Ensemble propriétaire** — `purge109-gallery-purge` : Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques.

**Silhouette** — `art109-render` : L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra.

### Liaison et buse · Purge des galeries
`part109-gallery-purge-line` · Composants V109

Liaison depuis (3030, 446) via X 3113 vers (3128, 452).

**Ensemble propriétaire** — `purge109-gallery-purge` : Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques.

**Silhouette** — `art109-render` : L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra.

### Jet · Purge des galeries
`field109-gallery-purge` · Volumes de vapeur

Champ de référence X 3128 à 3284, Y 424 à 510, profondeur 1. Le dessin, la reconnaissance et la chaleur consultent ce même volume.

**Conduite** — `purge109-gallery-purge` : Une porte fermée tronque ce champ à sa première face ; un battant à l’autre étage ne le tronque pas.

**Reconnaissance** — `sense109-vision` : Au-delà de 90 unités, le jet dense interrompt la vue à travers son volume. Le contact proche et la trace mémorisée restent possibles.

**Chaleur** — `steamstate109-jet` : Après 0.6 seconde d’exposition, 3 points toutes les 0.25 seconde tant que Ripley reste dedans.

### Purge de ventilation
`purge109-ventilation-purge` · Conduites de purge

Poste rattaché à f161-service-high, dans l’ensemble service-shop. Une réserve de 100 unités abstraites alimente ce seul jet. Ouvrir coûte 70 unités et ne dépense ni eau du piège ni plomb.

**Appui** — `f161-service-high` : Pied Y 330, support node-platform-f161-service-high, profondeur 1.

**Commande** — `input109-purge` : Centre du volant (3120, 285), portée horizontale 53, tolérance verticale 22, profondeur ±0.4.

**Buse** — `field109-ventilation-purge` : Origine (3190, 272) ; sens 1, portée maximale 156.

**Réserve** — `steamstate109-refill` : Recharge de 7 unités/s après fin de dissipation ; aucun cumul de jets.

### Boîtier de vanne · Purge de ventilation
`part109-ventilation-purge-box` · Composants V109

X 3100, Y 255, 40 × 55 unités. Platine en retrait ; aucun obstacle nouveau.

**Ensemble propriétaire** — `purge109-ventilation-purge` : Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques.

**Silhouette** — `art109-render` : L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra.

### Volant et cadran · Purge de ventilation
`part109-ventilation-purge-wheel` · Composants V109

Volant de rayon 12 à (3120, 289), cadran de rayon 8 à Y 266. L’aiguille utilise la réserve réelle.

**Ensemble propriétaire** — `purge109-ventilation-purge` : Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques.

**Silhouette** — `art109-render` : L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra.

### Liaison et buse · Purge de ventilation
`part109-ventilation-purge-line` · Composants V109

Liaison depuis (3138, 266) via X 3175 vers (3190, 272).

**Ensemble propriétaire** — `purge109-ventilation-purge` : Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques.

**Silhouette** — `art109-render` : L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra.

### Jet · Purge de ventilation
`field109-ventilation-purge` · Volumes de vapeur

Champ de référence X 3190 à 3346, Y 244 à 330, profondeur 1. Le dessin, la reconnaissance et la chaleur consultent ce même volume.

**Conduite** — `purge109-ventilation-purge` : Une porte fermée tronque ce champ à sa première face ; un battant à l’autre étage ne le tronque pas.

**Reconnaissance** — `sense109-vision` : Au-delà de 90 unités, le jet dense interrompt la vue à travers son volume. Le contact proche et la trace mémorisée restent possibles.

**Chaleur** — `steamstate109-jet` : Après 0.6 seconde d’exposition, 3 points toutes les 0.25 seconde tant que Ripley reste dedans.

### Purge de la fonderie
`purge109-foundry-purge` · Conduites de purge

Poste rattaché à f161-leadworks, dans l’ensemble leadworks. Une réserve de 100 unités abstraites alimente ce seul jet. Ouvrir coûte 70 unités et ne dépense ni eau du piège ni plomb.

**Appui** — `f161-leadworks` : Pied Y 510, support node-platform-f161-leadworks, profondeur 1.

**Commande** — `input109-purge` : Centre du volant (4124, 465), portée horizontale 53, tolérance verticale 22, profondeur ±0.4.

**Buse** — `field109-foundry-purge` : Origine (4270, 452) ; sens 1, portée maximale 156.

**Réserve** — `steamstate109-refill` : Recharge de 7 unités/s après fin de dissipation ; aucun cumul de jets.

### Boîtier de vanne · Purge de la fonderie
`part109-foundry-purge-box` · Composants V109

X 4104, Y 435, 40 × 55 unités. Platine en retrait ; aucun obstacle nouveau.

**Ensemble propriétaire** — `purge109-foundry-purge` : Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques.

**Silhouette** — `art109-render` : L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra.

### Volant et cadran · Purge de la fonderie
`part109-foundry-purge-wheel` · Composants V109

Volant de rayon 12 à (4124, 469), cadran de rayon 8 à Y 446. L’aiguille utilise la réserve réelle.

**Ensemble propriétaire** — `purge109-foundry-purge` : Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques.

**Silhouette** — `art109-render` : L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra.

### Liaison et buse · Purge de la fonderie
`part109-foundry-purge-line` · Composants V109

Liaison depuis (4142, 446) via X 4255 vers (4270, 452).

**Ensemble propriétaire** — `purge109-foundry-purge` : Trois groupes dessinés par conduite, neuf au total ; pas neuf nouveaux modèles artistiques.

**Silhouette** — `art109-render` : L’opacité de la commande baisse en cas de superposition avec Ripley. Le poste ne suit ni son saut ni la caméra.

### Jet · Purge de la fonderie
`field109-foundry-purge` · Volumes de vapeur

Champ de référence X 4270 à 4426, Y 424 à 510, profondeur 1. Le dessin, la reconnaissance et la chaleur consultent ce même volume.

**Conduite** — `purge109-foundry-purge` : Une porte fermée tronque ce champ à sa première face ; un battant à l’autre étage ne le tronque pas.

**Reconnaissance** — `sense109-vision` : Au-delà de 90 unités, le jet dense interrompt la vue à travers son volume. Le contact proche et la trace mémorisée restent possibles.

**Chaleur** — `steamstate109-jet` : Après 0.6 seconde d’exposition, 3 points toutes les 0.25 seconde tant que Ripley reste dedans.

### Conduite disponible
`steamstate109-ready` · États des conduites

Le cadran présente une réserve suffisante. La conduite n’a aucun jet actif.

**Contrat** — `A3-109-pressure` : Au moins 70 unités ; contrôle à portée et présence continue pendant le geste.

**Fichier** — `save109-current` : État courant exporté explicitement ; aucun son ni geste partiel rejoué.

### Ouvrir le volant
`steamstate109-opening` · États des conduites

Le geste dure 1,4 seconde. La pression n’est pas retirée avant la fin.

**Contrat** — `A3-109-pressure` : Le déplacement reste libre ; mouvement, saut, dégâts, relâchement ou panneau interrompent le geste.

**Fichier** — `save109-current` : État courant exporté explicitement ; aucun son ni geste partiel rejoué.

### Souffle chaud
`steamstate109-jet` · États des conduites

Le jet chaud dure 4,8 secondes ; il est bruyant, obscurcissant et dangereux pour Ripley.

**Contrat** — `A3-109-pressure` : Il ne blesse pas le Runner et aucun dommage nouveau aux détenus n’est ajouté. La préparation du piège reste dormante.

**Fichier** — `save109-current` : État courant exporté explicitement ; aucun son ni geste partiel rejoué.

**Groupe** — `v110-crew-margin` : À partir de V110, les déplacements des détenus peuvent attendre devant ce volume chaud. Aucun nouveau dégât ne leur est appliqué.

### Dissipation
`steamstate109-tail` · États des conduites

Une traîne de 1,2 seconde suit le souffle ; sa densité visuelle diminue et elle n’inflige plus de chaleur.

**Contrat** — `A3-109-pressure` : La traîne ne recharge pas encore le circuit. Le masquage visuel cesse quand la densité passe sous le seuil.

**Fichier** — `save109-current` : État courant exporté explicitement ; aucun son ni geste partiel rejoué.

### Remise en pression
`steamstate109-refill` · États des conduites

La réserve remonte seulement après disparition du jet. Elle ne dépasse pas 100 unités.

**Contrat** — `A3-109-pressure` : À partir de 30 unités, il faut environ 5,72 secondes après dissipation pour revenir à 70, dix secondes pour retrouver 100.

**Fichier** — `save109-current` : État courant exporté explicitement ; aucun son ni geste partiel rejoué.

### Voir à travers la vapeur
`sense109-vision` · Perception V109

La perception V106 est prolongée avec le champ réel du jet. Le volume dense interrompt la reconnaissance à distance, mais ne supprime ni la dernière trace ni une attaque engagée.

**Portée proche** — `A3-109-sight` : À 90 unités ou moins, cette couche ne masque pas la vue. Les portes et contraintes historiques continuent à s’appliquer.

**Étage** — `A3-109-collision` : Les deux corps doivent se trouver au même étage que le jet et dans sa profondeur pour ce masquage.

**Parité** — `qa-v109/unit.json` : Sans vapeur, 180 frames de décisions V106/V109 sont comparées directement.

### Entendre dans le souffle
`sense109-sound` · Perception V109

Le sifflement vient de la buse. Un petit bruit émis dans le jet, ou reçu par le Runner qui le traverse, garde son origine et son identifiant mais sa puissance est multipliée par 0,60.

**Intensité** — `A3-109-sound` : Bruit d’ouverture 1,0 ; impulsions de souffle 0,56, au plus une toutes les 0,95 s. Aucune rafale sonore à chaque frame.

**Boulons** — `hearing108-impact` : Les impacts des boulons restent suivis. Un bruit masqué n’est pas téléporté vers la conduite.

**Limite** — `A3-109-danger` : Le bruit propre de la purge n’est pas atténué par elle-même et peut attirer le Runner. Pas de silence magique.

### Actionner une purge
`input109-purge` · Commandes V109

V ou le bouton Purge ouvre le poste accessible. Le mode Maintenir demande une pression continue ; le mode Appuyer partage la durée et permet une annulation par second appui. À partir de V110, la même touche peut aussi refermer une vanne encore chaude ; consulter input110-close.

**Accès** — `A3-109-distance` : Au sol, bon étage, profondeur intermédiaire vérifiée et aucune porte entre le corps et le volant.

**Conflits** — `A3-109-abort` : Une préparation de piège en cours refuse la purge. Pendant le geste, E, le lancer, le bruit volontaire et les ordres aux détenus sont refusés. Fuir reste autorisé.

**Pause** — `A3-109-pause` : Plan, archives et perte de focus annulent le geste. La vapeur déjà libérée attend la reprise.

**Fermeture** — `input110-close` : Même emplacement, consommation d’ouverture conservée.

### Fichier de reprise V109
`save109-current` · Reprises V109

Le fichier V108 valide est enveloppé avec le registre des trois conduites. La pression, la durée restante et les comptes d’utilisation sont conservés. Le geste en cours est retiré, et les événements sonores ne sont pas rejoués.

**Validation** — `A3-109-save` : Limite 1 Mio ; empreinte de corruption et invariants de domaine, pas signature anti-triche.

**Pause** — `A3-109-pause` : Import en pause. Marge de 0,9 seconde à la reprise avant un nouveau dégât de vapeur, pour ne pas exécuter un impact suspendu.

**Base** — `save108-current` : Les contrôles de position, d’inventaire, de participants et de progression antérieurs restent actifs.

### Réserves du dernier poste sûr
`save109-checkpoint` · Reprises V109

Le poste sûr possède son propre registre, différent de la situation actuelle. Il ne peut être enregistré pendant un geste. Reprendre après un échec retrouve l’état vivant de ce poste.

**Validation** — `A3-109-save` : Limite 1 Mio ; empreinte de corruption et invariants de domaine, pas signature anti-triche.

**Pause** — `A3-109-pause` : Import en pause. Marge de 0,9 seconde à la reprise avant un nouveau dégât de vapeur, pour ne pas exécuter un impact suspendu.

**Base** — `save108-current` : Les contrôles de position, d’inventaire, de participants et de progression antérieurs restent actifs.

### Migration V105 à V108
`save109-migration` · Reprises V109

Les anciennes sauvegardes valides reçoivent trois circuits initialement pleins. Leur poste sûr est migré séparément de leur progression et inventaire actuels.

**Validation** — `A3-109-save` : Limite 1 Mio ; empreinte de corruption et invariants de domaine, pas signature anti-triche.

**Pause** — `A3-109-pause` : Import en pause. Marge de 0,9 seconde à la reprise avant un nouveau dégât de vapeur, pour ne pas exécuter un impact suspendu.

**Base** — `save108-current` : Les contrôles de position, d’inventaire, de participants et de progression antérieurs restent actifs.

### Refus d’un état incohérent
`save109-validation` · Reprises V109

Une réserve gratuite pendant un jet actif, une conduite inconnue, une durée infinie, un compte d’utilisation contradictoire ou un fichier trop volumineux sont refusés avant remplacement de la session.

**Validation** — `A3-109-save` : Limite 1 Mio ; empreinte de corruption et invariants de domaine, pas signature anti-triche.

**Pause** — `A3-109-pause` : Import en pause. Marge de 0,9 seconde à la reprise avant un nouveau dégât de vapeur, pour ne pas exécuter un impact suspendu.

**Base** — `save108-current` : Les contrôles de position, d’inventaire, de participants et de progression antérieurs restent actifs.

### Vapeur localisée et raccordée
`art109-render` · Rendu V109

Trois postes utilisent les appuis du réseau existant. Le jet visible est découpé exactement sur le volume d’effet. La commande s’efface partiellement si elle recouvre Ripley.

**Dessin** — `A3-109-scope` : Les images du rapport viennent du canvas de ces modules ; aucune réillustration ni superposition de screenshot historique.

**Lisibilité** — `A3-109-danger` : Le repère de progression se trouve sur le volant. Un avertissement de brûlure utilise une phrase courte.

**Mouvement réduit** — `A3-109-pause` : Ambiances immobiles supprime la translation des bouffées, pas les durées de jeu ni la baisse de densité.

### Fermer la purge
`v110-valve-close` · Règles V110

La même touche V referme une vanne en 0,85 seconde ; proximité, appui, étage et profondeur restent obligatoires.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Chaleur résiduelle
`v110-valve-residual` · Règles V110

Une fermeture conserve au plus 0,30 seconde chaude et 1,20 seconde de dissipation ; le nuage ne disparaît pas d’un coup.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Pas de remboursement
`v110-valve-reserve` · Règles V110

Fermer tôt ne rend pas les 70 unités consommées. La recharge n’avance pas tant que le nuage existe.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Lâcher la commande
`v110-valve-interrupt` · Règles V110

Mouvement, dégâts, pause, archive, plan, relâchement en mode maintien et perte de focus annulent le geste incomplet.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Appuyer au lieu de maintenir
`v110-valve-toggle` · Règles V110

Le mode accessible conserve exactement la même durée. Un second appui annule au lieu de valider.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Pas d’actions concurrentes
`v110-valve-order` · Règles V110

Une fermeture active refuse E, G, une lampe, un bruit métallique et les boulons ; la fuite reste possible.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Dissipation seule
`v110-valve-tail` · Règles V110

Si le jet se termine de lui-même pendant le geste, la fermeture ne fabrique ni résultat ni crédit.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Un vrai pas avant chaque décision
`v110-crew-step` · Règles V110

Le trajet V105 est calculé sur une copie de pose. Seuls les champs de navigation sont validés lorsque le pas reste sûr.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Marge devant le jet
`v110-crew-margin` · Règles V110

Le corps s’arrête avec une marge de 12 unités devant la vapeur chaude, pas après l’avoir traversée.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Respect des étages
`v110-crew-floor` · Règles V110

Le jet ne bloque pas une coursive supérieure sans recouvrement physique. Une arrivée d’échelle dans le jet reste contrôlée.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Respect de la profondeur
`v110-crew-depth` · Règles V110

Un détenu sur une autre profondeur n’est pas bloqué par une vapeur qui ne l’atteint pas.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Porte et volume communs
`v110-crew-gate` · Règles V110

La même plume tronquée par une porte fermée sert au rendu, à la chaleur et au choix de passage du groupe.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Repartir au bon moment
`v110-crew-resume` · Règles V110

La destination et le segment sont conservés. Quand le passage n’est plus chaud, le déplacement reprend depuis la position réelle.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Votre ordre reste prioritaire
`v110-crew-order` · Règles V110

G maintient un ordre d’attente volontaire, même après la dissipation. La vapeur ne le transforme pas en ordre de départ.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Ne pas inventer une arrivée
`v110-crew-arrival` · Règles V110

Attendre devant un jet ne signifie pas tenir la commande. L’armement du moule reste refusé si le poste n’est pas atteint.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Sortir d’un jet apparu autour du corps
`v110-crew-inside` · Règles V110

Une sortie qui réduit la pénétration est autorisée. Aucun personnage n’est repoussé ni téléporté.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Pas de faux bruit de pas
`v110-crew-steps` · Règles V110

Les bruits hérités suivent uniquement la distance réellement commitée. Un détenu qui attend reste immobile.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Prévenir sans saturer
`v110-crew-notice` · Règles V110

Un message proche et au bon étage explique l’attente ; son délai évite de répéter le même avertissement à chaque frame.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Compte de fermetures
`v110-save-ledger` · Règles V110

Chaque fermeture appartient à une purge déjà utilisée. Un fichier ne peut pas en déclarer plus que d’ouvertures.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### État courant indépendant
`v110-save-current` · Règles V110

Les réserves et durées viennent de V109 ; le nouveau registre ne crée pas de deuxième pression.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Poste sûr distinct
`v110-save-safe` · Règles V110

Le dernier poste sûr conserve son propre registre, ses réserves et ses ordres.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Pas de commande suspendue
`v110-save-transient` · Règles V110

Ni fermeture en cours, ni alerte différée, ni obstacle périmé ne sont repris depuis un fichier.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Recalcul du danger
`v110-save-recompute` · Règles V110

Après import en pause, l’attente du groupe est recalculée depuis la vraie plume, sa position et les portes.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Migration sans rétro-invention
`v110-save-migration` · Règles V110

Un fichier V105 à V109 reçoit un registre vide de fermetures, sans prétendre qu’un geste ancien a été réalisé.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Rendu partagé
`v110-draw-shared` · Règles V110

Les captures utilisent les modules de dessin livrés, sans illustration indépendante ni décor rajouté aux captures.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

### Périmètre
`v110-scope` · Règles V110

Attente prudente, pas simulation de panique, nouvelles blessures des détenus, invulnérabilité ou remplacement complet de l’IA. La V111 ajoute un choix de détour séparé ; ce contrat décrit seulement le périmètre V110.

**Contrôle** — `qa-v110/unit.json` : Données pures et vraie composition de modules sur base instrumentée. Les cas dirigés ne sont pas des traversées de campagne.

**Parcours** — `encounter-rabattage` : Le parcours au clavier attend devant la vapeur, ferme la vanne et garde les postes et objectifs historiques.

**Extension** — `v111-choice` : Navigation adaptative sans nouvel objectif.

### Refermer · Purge des galeries
`close110-gallery-purge` · Fermetures locales

La fermeture exige 0.85 seconde à ce même volant. Elle conserve au plus 0.3 seconde de chaleur résiduelle puis la traîne de 1.2 seconde. Les 70 unités dépensées à l’ouverture ne sont jamais remboursées.

**Conduite propriétaire** — `purge109-gallery-purge` : Les coordonnées et le circuit de V109 restent les seules références ; aucune nouvelle machine ni réserve.

**Appui** — `f161-service-low` : Support node-platform-f161-service-low, pied Y 510, profondeur 1.

**Commande** — `input110-close` : Volant (3012, 465), portée 53, hauteur ±22, profondeur ±0.4. Même test à chaque pas de temps.

**Jet partagé** — `field109-gallery-purge` : Origine (3128, 452) ; portée maximale 156. Fermé ou non, les portes coupent le même volume pour le rendu et les décisions.

**Recharge** — `steamstate109-refill` : La réserve recommence à monter seulement après disparition totale. Fermer peut avancer le début de recharge, pas rendre du stock immédiatement.

### Refermer · Purge de ventilation
`close110-ventilation-purge` · Fermetures locales

La fermeture exige 0.85 seconde à ce même volant. Elle conserve au plus 0.3 seconde de chaleur résiduelle puis la traîne de 1.2 seconde. Les 70 unités dépensées à l’ouverture ne sont jamais remboursées.

**Conduite propriétaire** — `purge109-ventilation-purge` : Les coordonnées et le circuit de V109 restent les seules références ; aucune nouvelle machine ni réserve.

**Appui** — `f161-service-high` : Support node-platform-f161-service-high, pied Y 330, profondeur 1.

**Commande** — `input110-close` : Volant (3120, 285), portée 53, hauteur ±22, profondeur ±0.4. Même test à chaque pas de temps.

**Jet partagé** — `field109-ventilation-purge` : Origine (3190, 272) ; portée maximale 156. Fermé ou non, les portes coupent le même volume pour le rendu et les décisions.

**Recharge** — `steamstate109-refill` : La réserve recommence à monter seulement après disparition totale. Fermer peut avancer le début de recharge, pas rendre du stock immédiatement.

### Refermer · Purge de la fonderie
`close110-foundry-purge` · Fermetures locales

La fermeture exige 0.85 seconde à ce même volant. Elle conserve au plus 0.3 seconde de chaleur résiduelle puis la traîne de 1.2 seconde. Les 70 unités dépensées à l’ouverture ne sont jamais remboursées.

**Conduite propriétaire** — `purge109-foundry-purge` : Les coordonnées et le circuit de V109 restent les seules références ; aucune nouvelle machine ni réserve.

**Appui** — `f161-leadworks` : Support node-platform-f161-leadworks, pied Y 510, profondeur 1.

**Commande** — `input110-close` : Volant (4124, 465), portée 53, hauteur ±22, profondeur ±0.4. Même test à chaque pas de temps.

**Jet partagé** — `field109-foundry-purge` : Origine (4270, 452) ; portée maximale 156. Fermé ou non, les portes coupent le même volume pour le rendu et les décisions.

**Recharge** — `steamstate109-refill` : La réserve recommence à monter seulement après disparition totale. Fermer peut avancer le début de recharge, pas rendre du stock immédiatement.

### Morse face à une purge
`crew110-morse` · Passages du groupe

Chaque prochain déplacement est calculé avec le moteur de navigation V105 sur une copie de pose. Les seuls champs de mouvement sont reportés si le pas reste sûr. L’identité, le but, la santé et l’ordre du joueur ne sont pas remplacés.

**Participant** — `participant-morse` : Un seul corps conserve son segment courant et sa destination. Aucun téléport, nouvelle vie ou arrivée anticipée.

**Départ** — `f161-bishop` : Le point initial appartient au parcours de rabattage existant.

**Poste** — `f161-lead-primer` : Le propriétaire du piège vérifie encore présence physique, fin de segment et bonne commande.

**Obstacle** — `close110-foundry-purge` : Marge 12 unités plus demi-largeur du corps ; même étage, même profondeur, champ chaud réellement tronqué par les portes.

**Ordres** — `v110-crew-order` : G reste prioritaire. Un ordre volontaire survit à la fin de vapeur ; G doit être redonné pour repartir.

**Limite** — `v110-scope` : Cette passe ne crée ni blessures aux détenus, ni panique complète, ni changement automatique de destination.

### Dillon face à une purge
`crew110-dillon` · Passages du groupe

Chaque prochain déplacement est calculé avec le moteur de navigation V105 sur une copie de pose. Les seuls champs de mouvement sont reportés si le pas reste sûr. L’identité, le but, la santé et l’ordre du joueur ne sont pas remplacés.

**Participant** — `participant-dillon` : Un seul corps conserve son segment courant et sa destination. Aucun téléport, nouvelle vie ou arrivée anticipée.

**Départ** — `f161-command-post-node` : Le point initial appartient au parcours de rabattage existant.

**Poste** — `f161-piston-c-node` : Le propriétaire du piège vérifie encore présence physique, fin de segment et bonne commande.

**Obstacle** — `close110-foundry-purge` : Marge 12 unités plus demi-largeur du corps ; même étage, même profondeur, champ chaud réellement tronqué par les portes.

**Ordres** — `v110-crew-order` : G reste prioritaire. Un ordre volontaire survit à la fin de vapeur ; G doit être redonné pour repartir.

**Limite** — `v110-scope` : Cette passe ne crée ni blessures aux détenus, ni panique complète, ni changement automatique de destination.

### En route
`crewstate110-moving` · États de passage

Le personnage suit son itinéraire et produit des pas seulement sur la distance réellement parcourue.

**Contrat** — `v110-crew-resume` : Le rendu n’avance ni le chemin, ni les compteurs.

**Groupe** — `crew110-dillon` : Même mécanisme pour Morse et Dillon ; Aaron n’est pas introduit dans la fonderie.

### Attente devant le jet
`crewstate110-hot-wait` · États de passage

Le pas est refusé avant d’entrer dans la partie chaude ; la pose courante et le segment restent valides.

**Contrat** — `v110-crew-resume` : Le temps continue hors menus. La vapeur peut se dissiper d’elle-même ou être refermée par le joueur.

**Groupe** — `crew110-dillon` : Même mécanisme pour Morse et Dillon ; Aaron n’est pas introduit dans la fonderie.

**Choix ultérieur** — `route111-wait-short` : En V111, la durée résiduelle peut rendre cette attente préférable à un détour.

**Autre attente** — `state112-wait` : Une attente thermique et une attente devant un compagnon ne sont pas affichées comme le même obstacle.

### Attente sur ordre
`crewstate110-order-wait` · États de passage

Une consigne d’attente est distincte du danger de la conduite.

**Contrat** — `v110-crew-resume` : Même si le jet a cessé, l’ordre volontaire reste vrai et la commande du piège n’est pas considérée comme occupée.

**Groupe** — `crew110-dillon` : Même mécanisme pour Morse et Dillon ; Aaron n’est pas introduit dans la fonderie.

### Poste tenu
`crewstate110-station` · États de passage

Seule l’arrivée réelle au bon point termine le déplacement.

**Contrat** — `v110-crew-resume` : L’armement du moule conserve les conditions et les étapes de V105/V107.

**Groupe** — `crew110-dillon` : Même mécanisme pour Morse et Dillon ; Aaron n’est pas introduit dans la fonderie.

### Registre courant V110
`save110-current` · Reprises V110

Le registre ajoute uniquement les fermetures par vanne et les mesures bornées du passage du groupe. Pression et jet restent ceux de V109. Ni fermeture partielle ni ancien indicateur de blocage ne sont importés.

**Base** — `save109-current` : La validation antérieure des poses, du piège, des boulons et des jets reste active.

**Sécurité** — `v110-save-ledger` : Empreinte de corruption et invariants de domaine, pas authentification anti-triche.

**Pause** — `v110-save-recompute` : La reprise est en pause. Au premier déplacement, l’attente thermique est recalculée, sans rejouer le geste ou le son de fermeture.

### Dernier poste sûr indépendant
`save110-checkpoint` · Reprises V110

Le poste sûr possède ses propres compteurs, ses réserves et ses ordres. Il ne peut pas être stocké pendant une fermeture active.

**Base** — `save109-current` : La validation antérieure des poses, du piège, des boulons et des jets reste active.

**Sécurité** — `v110-save-ledger` : Empreinte de corruption et invariants de domaine, pas authentification anti-triche.

**Pause** — `v110-save-recompute` : La reprise est en pause. Au premier déplacement, l’attente thermique est recalculée, sans rejouer le geste ou le son de fermeture.

### Migration V105 à V109
`save110-migration` · Reprises V110

Une ancienne partie valide reçoit zéro fermeture supplémentaire. Son poste sûr est migré indépendamment de son état courant ; aucun usage ancien n’est inventé.

**Base** — `save109-current` : La validation antérieure des poses, du piège, des boulons et des jets reste active.

**Sécurité** — `v110-save-ledger` : Empreinte de corruption et invariants de domaine, pas authentification anti-triche.

**Pause** — `v110-save-recompute` : La reprise est en pause. Au premier déplacement, l’attente thermique est recalculée, sans rejouer le geste ou le son de fermeture.

### Rejet des contradictions
`save110-validation` · Reprises V110

Une fermeture doit appartenir à un circuit utilisé : pas plus de fermetures que d’ouvertures. Les doublons, réserves falsifiées, statistiques incohérentes et fichiers dépassant 1 Mio sont refusés avant application.

**Base** — `save109-current` : La validation antérieure des poses, du piège, des boulons et des jets reste active.

**Sécurité** — `v110-save-ledger` : Empreinte de corruption et invariants de domaine, pas authentification anti-triche.

**Pause** — `v110-save-recompute` : La reprise est en pause. Au premier déplacement, l’attente thermique est recalculée, sans rejouer le geste ou le son de fermeture.

### V · Ouvrir ou refermer
`input110-close` · Commandes V110

La touche V choisit la fermeture lorsque la conduite libère encore de la vapeur chaude. Sinon, elle conserve l’ouverture de V109 ou attend la fin du nuage. Aucun nouveau raccourci supplémentaire.

**Maintenir** — `v110-valve-interrupt` : Relâcher, bouger, sauter, prendre une échelle, subir des dégâts, ouvrir un menu ou perdre le focus annule le geste.

**Appuyer** — `v110-valve-toggle` : Un seul appui démarre le même travail ; un deuxième l’annule. Le bouton pointeur utilise les mêmes méthodes.

**Concurrence** — `v110-valve-order` : E, G, I, F et les boulons sont temporairement refusés pendant le geste. L’interface ne propose pas un ordre devenu indisponible.

**Sortie** — `v110-valve-tail` : Si la vapeur devient tiède avant la fin du travail, aucune fausse fermeture n’est comptée.

### Choisir un passage
`v111-choice` · Règles V111

Les détenus peuvent comparer un détour praticable à l’attente devant un jet bref. Ni une nouvelle route ni un ordre de réussite ne sont créés.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Partir du corps réel
`v111-position` · Règles V111

Au milieu d’un segment, continuer ou revenir est évalué depuis la position courante. Les coordonnées ne sont jamais replacées sur un nœud.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Sens de passage
`v111-one-way` · Règles V111

Un segment à sens unique ne peut pas être inversé, même pour éviter une porte.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Conduits interdits au groupe
`v111-vents` · Règles V111

Les détenus n’empruntent pas les conduits du Runner.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Même porte pour le corps et le trajet
`v111-doors` · Règles V111

La géométrie du battant et son état coupent les segments praticables, pas seulement son identifiant de graphe.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Volume commun
`v111-plume` · Règles V111

Le volume chaud de V109 et la marge corporelle de V110 servent au choix comme au pas final.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Attendre peut rester le meilleur choix
`v111-wait` · Règles V111

Une courte purge peut finir avant qu’un grand détour soit terminé. L’algorithme garde alors l’attente prudente.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Ne pas faire le tour du complexe
`v111-ratio` · Règles V111

Un détour disproportionné est refusé au lieu d’envoyer le groupe à l’autre bout du niveau.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Revoir à cadence bornée
`v111-review` · Règles V111

Un changement de porte ou de volume déclenche une révision ; un état stable est réévalué au plus toutes les 0,45 secondes.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### G reste prioritaire
`v111-hold` · Règles V111

Un ordre volontaire arrête immédiatement le déplacement et son choix de route. Repartir réévalue la situation sans oublier la pose.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Tenir son poste physiquement
`v111-arrival` · Règles V111

L’arrivée reste constatée par le propriétaire historique, au point réel et sans segment restant.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Pas de calcul actif dans les menus
`v111-pause` · Règles V111

Pause, plan, archives et chargement suspendent la navigation et ses alertes.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Sauver la position, pas une ancienne route
`v111-save` · Règles V111

Les poses et segments sont sauvegardés par V105 ; les caches de détour sont recalculés après import en pause.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Poste sûr indépendant
`v111-safe` · Règles V111

Le poste sûr conserve son registre propre et ne récupère pas les décisions de l’état courant.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Bruit de pas réel
`v111-sound` · Règles V111

La distance réellement parcourue alimente les pas ; réfléchir ou attendre reste silencieux.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Portée de cette passe
`v111-scope` · Règles V111

Navigation prudente des deux détenus, pas de panique, blessure, arme ou remplacement de l’IA du Runner.

**Base** — `v110-crew-step` : La décision de chemin complète le contrôle corporel existant, pas l’identité ou le rôle du participant.

**Preuve** — `qa-v111/unit.json` : Cas instrumentés sur le vrai graphe ; leur réussite ne valide pas le moteur principal complet.

### Morse devant la porte fermée
`route111-closed-gate` · Choix de parcours

Le trajet est évalué depuis la position réelle au milieu de f161-e07. Continuer est bloqué par le battant. Revenir au carrefour puis prendre les passages inférieurs reste possible. Ce calcul n’ouvre pas la porte et ne remplace pas l’arrivée à la coulée.

**Participant** — `participant-morse` : Le personnage conserve sa vitesse et son but.

**Porte** — `f161-e07` : Pose de calcul : X 3773.20 ; pied Y 510.00. Le corps ne peut pas pénétrer dans le battant.

**Retour** — `f161-bishop` : Retour le long du segment déjà parcouru, sans changement de coordonnées brusque.

**Itinéraire** — `f161-tunnel-shrine` : f161-bishop → f161-tunnel-shrine → f161-golic-cache-v94 → f161-tunnel-low → f161-leadworks → f161-lead-primer

**Destination** — `f161-lead-primer` : La commande est occupée seulement après la fin de segment et l’arrivée physique.

### Attendre la fin d’un jet bref
`route111-wait-short` · Choix de parcours

Un détour praticable n’est pas forcément plus rapide. Le choix compare sa longueur physique, y compris les approches d’échelles, à la route ordinaire avec le temps chaud restant. Ce sont des temps estimés, pas une promesse de durée.

**Conduite** — `purge109-foundry-purge` : Cas dirigé de calcul : attente et trajet estimés à 13.75 s ; détour à 19.62 s. Le jet n’est pas prolongé pour fabriquer une préférence.

**Pas réel** — `v110-crew-margin` : Le personnage peut approcher, puis attend devant le vrai volume avec la marge corporelle.

**Révision** — `v111-review` : Une nouvelle ouverture ou la fin du danger déclenche une réévaluation.

### Bishop
`route111-junction-f161-bishop` · Carrefours de détour

Point existant (3500, 510), support de largeur 300. Ce point n’est pas une nouvelle salle : il sert à vérifier qu’une décision de détour revient à une vraie jonction plutôt qu’à un emplacement inventé.

**Appui** — `f161-bishop` : Le point appartient déjà au graphe V105.

**f161-e07** — `f161-e07` : Approches successives : (4200, 510). Longueur physique canonique : 700.00.

**f161-e53** — `f161-e53` : Approches successives : (3460, 630) → (3460, 510) → (3500, 510). Longueur physique canonique : 200.00.

### Leadworks
`route111-junction-f161-leadworks` · Carrefours de détour

Point existant (4200, 510), support de largeur 340. Ce point n’est pas une nouvelle salle : il sert à vérifier qu’une décision de détour revient à une vraie jonction plutôt qu’à un emplacement inventé.

**Appui** — `f161-leadworks` : Le point appartient déjà au graphe V105.

**f161-e07** — `f161-e07` : Approches successives : (4200, 510). Longueur physique canonique : 700.00.

**f161-e21** — `f161-e21` : Approches successives : (4010, 630) → (4010, 510) → (4200, 510). Longueur physique canonique : 500.00.

**f161-e40** — `f161-e40` : Approches successives : (4380, 510). Longueur physique canonique : 180.00.

### Tunnel shrine
`route111-junction-f161-tunnel-shrine` · Carrefours de détour

Point existant (3420, 630), support de largeur 210. Ce point n’est pas une nouvelle salle : il sert à vérifier qu’une décision de détour revient à une vraie jonction plutôt qu’à un emplacement inventé.

**Appui** — `f161-tunnel-shrine` : Le point appartient déjà au graphe V105.

**f161-e53** — `f161-e53` : Approches successives : (3460, 630) → (3460, 510) → (3500, 510). Longueur physique canonique : 200.00.

**f161-e97** — `f161-e97` : Approches successives : (3660, 630). Longueur physique canonique : 240.00.

### Golic cache v94
`route111-junction-f161-golic-cache-v94` · Carrefours de détour

Point existant (3660, 630), support de largeur 230. Ce point n’est pas une nouvelle salle : il sert à vérifier qu’une décision de détour revient à une vraie jonction plutôt qu’à un emplacement inventé.

**Appui** — `f161-golic-cache-v94` : Le point appartient déjà au graphe V105.

**f161-e97** — `f161-e97` : Approches successives : (3660, 630). Longueur physique canonique : 240.00.

**f161-e98** — `f161-e98` : Approches successives : (3820, 630). Longueur physique canonique : 160.00.

### Tunnel low
`route111-junction-f161-tunnel-low` · Carrefours de détour

Point existant (3820, 630), support de largeur 280. Ce point n’est pas une nouvelle salle : il sert à vérifier qu’une décision de détour revient à une vraie jonction plutôt qu’à un emplacement inventé.

**Appui** — `f161-tunnel-low` : Le point appartient déjà au graphe V105.

**f161-e98** — `f161-e98` : Approches successives : (3820, 630). Longueur physique canonique : 160.00.

**f161-e21** — `f161-e21` : Approches successives : (4010, 630) → (4010, 510) → (4200, 510). Longueur physique canonique : 500.00.

### Lead primer
`route111-junction-f161-lead-primer` · Carrefours de détour

Point existant (4380, 510), support de largeur 190. Ce point n’est pas une nouvelle salle : il sert à vérifier qu’une décision de détour revient à une vraie jonction plutôt qu’à un emplacement inventé.

**Appui** — `f161-lead-primer` : Le point appartient déjà au graphe V105.

**f161-e40** — `f161-e40` : Approches successives : (4380, 510). Longueur physique canonique : 180.00.

### Morse conserve sa mission
`route111-morse` · Conduite du groupe

Le détour change le chemin, jamais l’objectif. G impose toujours une attente volontaire. Les bruits de pas comptent uniquement la distance réellement parcourue ; une décision ou une attente ne produit pas de faux pas.

**Participant** — `participant-morse` : Identité, santé, ordre et destination restent propriétaires des systèmes antérieurs.

**Poste** — `f161-lead-primer` : Aucun succès ni armement n’est accordé parce qu’un trajet a été calculé.

**Reprise** — `save111-cache` : Les caches ne survivent pas à un import. La pose et son segment, eux, sont conservés.

**Circulation** — `crew112-morse` : Le trajet V111 reste proposé puis soumis à la marge corporelle V112.

### Dillon conserve sa mission
`route111-dillon` · Conduite du groupe

Le détour change le chemin, jamais l’objectif. G impose toujours une attente volontaire. Les bruits de pas comptent uniquement la distance réellement parcourue ; une décision ou une attente ne produit pas de faux pas.

**Participant** — `participant-dillon` : Identité, santé, ordre et destination restent propriétaires des systèmes antérieurs.

**Poste** — `f161-piston-c-node` : Aucun succès ni armement n’est accordé parce qu’un trajet a été calculé.

**Reprise** — `save111-cache` : Les caches ne survivent pas à un import. La pose et son segment, eux, sont conservés.

### Poursuivre
`routestate111-forward` · Décisions V111

Un passage déjà libre conserve le déplacement historique. Hors obstacle et vapeur, la parité a été vérifiée pas par pas.

**Navigation** — `v111-position` : Le budget de vitesse est consommé une seule fois par pas de simulation.

**Sécurité** — `v111-plume` : Une porte qui se ferme ou un jet qui apparaît peut interrompre la route choisie.

### Revenir au carrefour
`routestate111-return` · Décisions V111

Le personnage inverse seulement un segment réversible et le parcourt dans l’autre sens. Un sens unique reste interdit.

**Navigation** — `v111-position` : Le budget de vitesse est consommé une seule fois par pas de simulation.

**Sécurité** — `v111-plume` : Une porte qui se ferme ou un jet qui apparaît peut interrompre la route choisie.

### Prendre l’autre voie
`routestate111-detour` · Décisions V111

La route choisie ne contient que des connexions existantes, sans conduit réservé au Runner. Chaque nouveau pas est encore vérifié.

**Navigation** — `v111-position` : Le budget de vitesse est consommé une seule fois par pas de simulation.

**Sécurité** — `v111-plume` : Une porte qui se ferme ou un jet qui apparaît peut interrompre la route choisie.

### Attendre ou rester sur ordre
`routestate111-wait` · Décisions V111

Un trajet absent ou disproportionné conserve une attente sûre. Une consigne volontaire reste prioritaire même si le passage se libère.

**Navigation** — `v111-position` : Le budget de vitesse est consommé une seule fois par pas de simulation.

**Sécurité** — `v111-plume` : Une porte qui se ferme ou un jet qui apparaît peut interrompre la route choisie.

### Position et registre courant
`save111-current` · Reprises V111

Les coordonnées et les segments canoniques viennent de la sauvegarde V105. V111 ajoute seulement un registre borné de décisions.

**Base** — `save110-current` : Les validations antérieures continuent à vérifier poses, participants, piège, jets, boulons et ordres.

**Faits** — `v111-save` : Les données temporaires ne peuvent pas imposer une route depuis un fichier.

### Ne pas reprendre un trajet périmé
`save111-cache` · Reprises V111

Le graphe filtré, les décisions provisoires, les temporisations de recherche et alertes sont jetés à l’import. Après reprise en pause, les portes et jets actuels sont réévalués.

**Base** — `save110-current` : Les validations antérieures continuent à vérifier poses, participants, piège, jets, boulons et ordres.

**Faits** — `v111-save` : Les données temporaires ne peuvent pas imposer une route depuis un fichier.

### Dernier poste sûr distinct
`save111-safe` · Reprises V111

Le poste sûr possède son propre registre. Une décision tardive dans la partie courante ne remplace pas cet état antérieur.

**Base** — `save110-current` : Les validations antérieures continuent à vérifier poses, participants, piège, jets, boulons et ordres.

**Faits** — `v111-save` : Les données temporaires ne peuvent pas imposer une route depuis un fichier.

### Migration et refus
`save111-migration` · Reprises V111

Les fichiers V105 à V110 valides reçoivent un registre vide. Une arrivée après détour ne peut pas dépasser le nombre de détours ; les identités et signatures doivent correspondre. L’empreinte protège contre la corruption, pas contre la triche.

**Base** — `save110-current` : Les validations antérieures continuent à vérifier poses, participants, piège, jets, boulons et ordres.

**Faits** — `v111-save` : Les données temporaires ne peuvent pas imposer une route depuis un fichier.

### Garder une distance
`v112-gap` · Règles V112

Les détenus conservent une marge horizontale de 14 unités et une marge verticale de 10 ; le décor n’est pas modifié.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Le corps entier
`v112-body` · Règles V112

Le test de déplacement porte sur la largeur et la hauteur du corps, pas seulement sur son centre.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Contrôler le pas proposé
`v112-sweep` · Règles V112

Le volume balayé par le pas est testé avant de reporter des coordonnées dans l’acteur.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Laisser avancer celui de devant
`v112-leader` · Règles V112

Sur un même niveau et dans la même direction, le meneur avance avant le suivant. L’ordre original des participants est conservé.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Un ordre reste un ordre
`v112-held` · Règles V112

G fait attendre un détenu ; son voisin ne le traverse pas pour rattraper sa destination.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Repartir sans déplacement instantané
`v112-resume` · Règles V112

La position et le segment sont conservés ; la marche reprend quand le prochain pas retrouve sa marge.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Séparer les étages
`v112-floor` · Règles V112

Un détenu dans une galerie inférieure ne bloque pas celui sur la coursive haute.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### La profondeur zéro existe
`v112-depth` · Règles V112

Un acteur sur le plan arrière ne retombe pas sur le médian à cause d’une valeur zéro.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Un seul entrant sur la liaison verticale
`v112-vertical` · Règles V112

L’entrée sur une échelle ou un élévateur déjà utilisé attend sa libération. Les acteurs déjà engagés peuvent poursuivre dans leurs marges.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Sortir d’un chevauchement hérité
`v112-inside` · Règles V112

Un déplacement qui réduit une superposition préexistante reste possible ; aucun acteur n’est repoussé ou téléporté.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Un budget de vitesse
`v112-one-budget` · Règles V112

Le pas proposé et le pas accepté partagent le même budget. Un refus ne consomme pas un second déplacement.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Ne pas changer le propriétaire des étapes
`v112-ownership` · Règles V112

L’attente n’attribue ni arrivée, ni santé, ni objectif ; les conditions du piège restent celles du parcours.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Attendre sans faux pas
`v112-no-sound` · Règles V112

Aucun son de marche ni compteur de distance n’est ajouté pour un déplacement refusé.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Conserver les détours
`v112-plans` · Règles V112

La proposition utilise V111 et ses vrais segments ; pas de nouveau raccourci ni d’ouverture automatique.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Reprise sans réservation périmée
`v112-no-cache` · Règles V112

Les poses viennent de la sauvegarde existante ; la file d’attente est reconstruite à partir des corps après import.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Un poste sûr indépendant
`v112-safe` · Règles V112

Le registre de circulation du dernier poste sûr reste distinct de la partie courante.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Suspendre les files
`v112-pause` · Règles V112

Pause, plan, archives et chargement ne font ni bouger le groupe ni avancer son attente.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Une remarque au bon endroit
`v112-notice` · Règles V112

Le message est bref, à proximité, au même étage et sans porte fermée entre les personnages.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Pas de mur humain pour Ripley
`v112-player` · Règles V112

Cette couche régule les détenus entre eux ; elle ne transforme ni Ripley ni le Runner en nouvel obstacle de navigation.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Portée limitée
`v112-deadlock` · Règles V112

Ce n’est pas un planificateur multi-agent global. Deux acteurs face à face sans espace de dégagement attendent ; aucun passage forcé ni poussée ne sont simulés.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Pas d’assertion de campagne native
`v112-legacy` · Règles V112

Le banc exécute les modules livrés avec une physique simplifiée. La campagne entière et ses sprites définitifs restent à qualifier.

**Propriété** — `route111-morse` : Les buts, arrivées et segments sont ceux des propriétaires précédents. Le nouveau contrôle n’attribue aucune étape.

**Échelle** — `v112-gap` : Les distances sont des unités du graphe, pas des mesures relevées sur le plateau du film.

**Validation** — `qa-v112/unit.json` : Contrats exécutés sur une base instrumentée. Les essais clavier restent décrits séparément dans le rapport navigateur.

### Morse devant Dillon retenu
`queue112-held` · Cas de circulation

Comparaison dirigée de 600 pas à 1/60 s : portes ouvertes, destinations existantes, Dillon retenu par G. La V111 présente 38 pas où les rectangles corporels se superposent. La V112 n’en présente aucun dans ce même cas. Cette comparaison instrumentée n’est pas présentée comme une traversée de campagne.

**Obstacle** — `participant-dillon` : Dillon attend en X 3942.0000, pied Y 510.00. Il n’est ni repoussé ni réassigné.

**Suivant** — `participant-morse` : Morse reste en X 3892.0000. Sa largeur 36 et la marge 14 sont prises en compte.

**Ordre** — `v112-held` : La consigne G reste volontaire ; une file d’attente ne la lève pas.

**Destination** — `f161-lead-primer` : Le poste de coulée ne peut être occupé à distance.

### Marcher derrière un détenu plus lent
`queue112-follow` · Cas de circulation

Au départ, le meneur engagé vers le même côté est mis à jour avant le suivant. Si un pas complet rattrape son corps, un budget plus court est recalculé depuis la pose initiale. Seule une proposition est reportée. On conserve ainsi la marge sans alterner inutilement un pas rapide et un arrêt complet.

**Budget** — `v112-one-budget` : Le déplacement accepté ne dépasse jamais vitesse × durée. Le moteur ne reporte pas un déplacement complet puis une correction inverse.

**Constat dirigé** — `queue112-held` : Après le départ donné à Dillon : 1 attente et 1 reprise ; 269 pas réduits dans le cas instrumenté.

**Écoute** — `v112-no-sound` : La cadence de marche est alimentée seulement par la distance réellement parcourue.

### Morse dans la circulation
`crew112-morse` · Participants V112

Vitesse nominale 112 unités/s. Le personnage conserve sa destination historique. Sa position n’est pas une réservation abstraite : le corps voisin et son propre déplacement sont réexaminés à chaque pas, au même étage et à la même profondeur.

**Identité** — `participant-morse` : Le même acteur est utilisé ; aucune copie créée pour contourner un blocage.

**Commande** — `f161-lead-primer` : L’arrivée est encore attribuée par le propriétaire du parcours.

**Obstacle temporaire** — `queue112-held` : Une attente devant un autre corps n’est pas une arrivée et n’est pas une nouvelle consigne G.

### Dillon dans la circulation
`crew112-dillon` · Participants V112

Vitesse nominale 105 unités/s. Le personnage conserve sa destination historique. Sa position n’est pas une réservation abstraite : le corps voisin et son propre déplacement sont réexaminés à chaque pas, au même étage et à la même profondeur.

**Identité** — `participant-dillon` : Le même acteur est utilisé ; aucune copie créée pour contourner un blocage.

**Commande** — `f161-piston-c-node` : L’arrivée est encore attribuée par le propriétaire du parcours.

**Obstacle temporaire** — `queue112-held` : Une attente devant un autre corps n’est pas une arrivée et n’est pas une nouvelle consigne G.

### Attendre le passage
`state112-wait` · États de circulation

Le prochain pas entrerait dans le corps d’un autre détenu. La pose et le segment sont conservés ; la vitesse tombe à zéro, sans son de pas. Le message n’est montré que près du joueur au même étage, sans porte fermée entre eux.

**Contrôle** — `v112-sweep` : La décision porte sur un pas, pas sur une nouvelle route complète.

**Limite** — `v112-deadlock` : Aucune résolution multi-agent générale d’un face-à-face sans place de dégagement.

### Suivre à distance
`state112-follow` · États de circulation

Le pas complet serait trop grand mais une partie de son budget est disponible. Le suivant avance à allure réduite depuis sa pose initiale ; le meneur n’est pas freiné artificiellement.

**Contrôle** — `v112-sweep` : La décision porte sur un pas, pas sur une nouvelle route complète.

**Limite** — `v112-deadlock` : Aucune résolution multi-agent générale d’un face-à-face sans place de dégagement.

### Laisser finir une traversée verticale
`state112-connector` · États de circulation

Un nouvel entrant attend devant une échelle ou un élévateur déjà emprunté. Un acteur déjà engagé n’est pas expulsé ; ses prochains pas restent soumis aux marges corporelles.

**Contrôle** — `v112-sweep` : La décision porte sur un pas, pas sur une nouvelle route complète.

**Limite** — `v112-deadlock` : Aucune résolution multi-agent générale d’un face-à-face sans place de dégagement.

### Sortir d’une superposition héritée
`state112-exit-overlap` · États de circulation

Une ancienne sauvegarde ou une scène préparée peut contenir deux corps superposés. Un pas qui réduit leur pénétration est autorisé ; on ne les sépare pas par une poussée ou une téléportation.

**Contrôle** — `v112-sweep` : La décision porte sur un pas, pas sur une nouvelle route complète.

**Limite** — `v112-deadlock` : Aucune résolution multi-agent générale d’un face-à-face sans place de dégagement.

### Partie courante
`save112-current` · Reprises V112

Le fichier V112 enveloppe le propriétaire V111 sans le remplacer. Les positions, segments, destinations et ordres restent dans leur partie historique. Le nouveau registre conserve seulement l’identité du modèle et les compteurs bornés.

**Base** — `save111-cache` : Le cache de chemin V111 reste lui aussi transitoire.

**Migration** — `v112-safe` : Les fichiers valides V105 à V111 peuvent migrer avec un registre V112 neuf, sans attente ancienne inventée.

**Pause** — `v112-pause` : La pause, le plan et les archives figent la circulation comme le reste de cette séquence.

### Recalculer la file après import
`save112-cache` · Reprises V112

Aucune file, priorité ou réservation active n’est sérialisée. L’import reste en pause ; au premier pas, les corps, portes et jets présents déterminent ce qui est possible.

**Base** — `save111-cache` : Le cache de chemin V111 reste lui aussi transitoire.

**Migration** — `v112-safe` : Les fichiers valides V105 à V111 peuvent migrer avec un registre V112 neuf, sans attente ancienne inventée.

**Pause** — `v112-pause` : La pause, le plan et les archives figent la circulation comme le reste de cette séquence.

### Dernier poste sûr
`save112-safe` · Reprises V112

Un poste sûr conserve son propre registre, distinct de celui de la partie courante. Une attente, une manœuvre ou une attaque n’est pas relancée automatiquement à la reprise.

**Base** — `save111-cache` : Le cache de chemin V111 reste lui aussi transitoire.

**Migration** — `v112-safe` : Les fichiers valides V105 à V111 peuvent migrer avec un registre V112 neuf, sans attente ancienne inventée.

**Pause** — `v112-pause` : La pause, le plan et les archives figent la circulation comme le reste de cette séquence.

### Refuser un registre contradictoire
`save112-validate` · Reprises V112

Les compteurs doivent être des entiers bornés ; reprises ≤ attentes ≤ pas bloqués. La durée d’attente ne peut pas dépasser la somme des durées maximales des pas comptés. L’empreinte est un contrôle d’intégrité, pas une preuve anti-triche.

**Base** — `save111-cache` : Le cache de chemin V111 reste lui aussi transitoire.

**Migration** — `v112-safe` : Les fichiers valides V105 à V111 peuvent migrer avec un registre V112 neuf, sans attente ancienne inventée.

**Pause** — `v112-pause` : La pause, le plan et les archives figent la circulation comme le reste de cette séquence.

### Priorité sur f161-e21
`queue112-f161-e21` · Liaisons verticales V112

Liaison ladder déjà présente : (3820, 630) → (4200, 510). Le contrôle ne crée aucune nouvelle échelle ni nouvelle animation. La réservation de fait est portée par le segment canonique du détenu engagé, puis abandonnée naturellement à sa sortie.

**Origine** — `f161-tunnel-low` : Le corps rejoint l’approche existante.

**Destination** — `f161-leadworks` : L’arrivée requiert la traversée, pas le calcul d’une route.

**Contrat** — `v112-vertical` : Un nouvel entrant attend tant que la liaison est occupée. Test isolé ; pas de parcours navigateur spécifique de croisement sur cette échelle.

### Priorité sur f161-e53
`queue112-f161-e53` · Liaisons verticales V112

Liaison ladder déjà présente : (3420, 630) → (3500, 510). Le contrôle ne crée aucune nouvelle échelle ni nouvelle animation. La réservation de fait est portée par le segment canonique du détenu engagé, puis abandonnée naturellement à sa sortie.

**Origine** — `f161-tunnel-shrine` : Le corps rejoint l’approche existante.

**Destination** — `f161-bishop` : L’arrivée requiert la traversée, pas le calcul d’une route.

**Contrat** — `v112-vertical` : Un nouvel entrant attend tant que la liaison est occupée. Test isolé ; pas de parcours navigateur spécifique de croisement sur cette échelle.

### Priorité sur f161-e12
`queue112-f161-e12` · Liaisons verticales V112

Liaison ladder déjà présente : (1120, 510) → (1500, 350). Le contrôle ne crée aucune nouvelle échelle ni nouvelle animation. La réservation de fait est portée par le segment canonique du détenu engagé, puis abandonnée naturellement à sa sortie.

**Origine** — `f161-infirmary` : Le corps rejoint l’approche existante.

**Destination** — `f161-morgue-high` : L’arrivée requiert la traversée, pas le calcul d’une route.

**Contrat** — `v112-vertical` : Un nouvel entrant attend tant que la liaison est occupée. Test isolé ; pas de parcours navigateur spécifique de croisement sur cette échelle.

### American Cinematographer — entretien Alex Thomson, juillet 1992, republication 2019
`ref113-asc-1992` · Références V113

Cadrages bas, plafonds travaillés, acteurs lisibles dans la pénombre ; grande installation de coulée et portique. Type de preuve : production-interview. Consultation le 29 septembre 2026 ; les pages de vente servent uniquement de description de pièces de production. Aucun média du film n’est inclus.

**Source** — `https://theasc.com/article/alien3-in-space-they-039-re-still-screaming/` : Description de production ou piste secondaire identifiée. Ni prix ni disponibilité commerciale ne sont utilisés.

### Propstore — costume carcéral de Ripley, lot de production
`ref113-ripley-uniform` · Références V113

Veste brune matelassée, haut et pantalon assortis ; manteau vert avec insignes ; marquage au dos. Type de preuve : production-object. Consultation le 29 septembre 2026 ; les pages de vente servent uniquement de description de pièces de production. Aucun média du film n’est inclus.

**Source** — `https://propstore.com/product/alien-1992/ripleys-sigourney-weaver-prison-uniform-2/` : Description de production ou piste secondaire identifiée. Ni prix ni disponibilité commerciale ne sont utilisés.

### Propstore — éléments de costume du crash
`ref113-ripley-crash` · Références V113

Haut gris côtelé et tenue courte de la scène du crash ; salissures de production. Type de preuve : production-object. Consultation le 29 septembre 2026 ; les pages de vente servent uniquement de description de pièces de production. Aucun média du film n’est inclus.

**Source** — `https://propstoreauction.com/lot-details/index/catalog/386/lot/126096/Lot-8-Ellen-Ripley-Sigourney-Weaver-Dummy-Paint-and-Hair-Test-Bust-with-Bloodied-Crash-Costume-Components-ALIEN3-1992` : Description de production ou piste secondaire identifiée. Ni prix ni disponibilité commerciale ne sont utilisés.

### Propstore — costume complet de Dillon, lot 25
`ref113-dillon-uniform` · Références V113

Ensemble superposé : manteau, veste, capuche, gilet, pantalon et bottes volontairement usés. Type de preuve : production-object. Consultation le 29 septembre 2026 ; les pages de vente servent uniquement de description de pièces de production. Aucun média du film n’est inclus.

**Source** — `https://ukm.propstoreauction.com/lot-details/index/catalog/244/lot/66284/Lot-25-ALIEN3-1992-Dillon-s-Charles-S-Dutton-Complete-Costume` : Description de production ou piste secondaire identifiée. Ni prix ni disponibilité commerciale ne sont utilisés.

### Propstore — tenue de détenu de Fiorina 161
`ref113-inmate-uniform` · Références V113

Vêtements de coton, manteau de toile et capuche imperméable ; manteaux portés dehors. Type de preuve : production-object. Consultation le 29 septembre 2026 ; les pages de vente servent uniquement de description de pièces de production. Aucun média du film n’est inclus.

**Source** — `https://propstoreauction.com/lot-details/index/catalog/318/lot/95525` : Description de production ou piste secondaire identifiée. Ni prix ni disponibilité commerciale ne sont utilisés.

### Propstore — fusil à impulsion de production Alien 3
`ref113-pulse-film` · Références V113

Arme de l’équipe de récupération de fin de film ; finition noire. Ne constitue pas un équipement initial de Ripley. Type de preuve : production-object. Consultation le 29 septembre 2026 ; les pages de vente servent uniquement de description de pièces de production. Aucun média du film n’est inclus.

**Source** — `https://propstore.com/product/alien-1992/lot-18-hero-pulse-rifle/` : Description de production ou piste secondaire identifiée. Ni prix ni disponibilité commerciale ne sont utilisés.

### 20th Century Studios — Alien 3
`ref113-studio-film` · Références V113

La colonie pénitentiaire est vulnérable face à la créature ; ne pas importer un arsenal de Marines pour Ripley. Type de preuve : official-synopsis. Consultation le 29 septembre 2026 ; les pages de vente servent uniquement de description de pièces de production. Aucun média du film n’est inclus.

**Source** — `https://www.20thcenturystudios.jp/movies/alien3` : Description de production ou piste secondaire identifiée. Ni prix ni disponibilité commerciale ne sont utilisés.

### AVP Galaxy — scènes alternatives / supprimées, repérage secondaire
`ref113-cut-register` · Références V113

Piste de comparaison pour les montages. À confirmer scène par scène sur une copie autorisée ; aucun minutage ou plan mesuré inventé. Type de preuve : secondary-locator. Consultation le 29 septembre 2026 ; les pages de vente servent uniquement de description de pièces de production. Aucun média du film n’est inclus.

**Source** — `https://www.avpgalaxy.net/alien-movies/alien-3/deleted-scenes/` : Description de production ou piste secondaire identifiée. Ni prix ni disponibilité commerciale ne sont utilisés.

### Séparation entre soins et détention
`portal113-f161-infirmary-gate` · Seuils V113

Fermeture de circulation, encastrée dans une travée qui prolonge les alcôves médicales. Le passage utilise toujours la collision et le verrou existants. Le volet segmenté se replie vers son coffre ; ouvert, il ne laisse pas de masse opaque. Ces retours de cloison améliorent la cohérence locale, pas la preuve d’un emplacement identique à celui du film.

**Connexion** — `f161-e03` : Propriétaire unique du verrou : f161-infirmary-gate

**Depuis** — `f161-infirmary` : Appui conservé.

**Vers** — `f161-cell-a` : Appui conservé.

**Ouverture** — `f161-infirmary-gate` : X 1488, Y 378, 44 × 132 ; pied Y 510

**Coffre** — `rule113-volet-rangement` : X 1477, Y 351, 66 × 20

**Montant gauche** — `rule113-seuil-proprietaire` : X 1476, Y 371, 12 × 139

**Montant droit** — `rule113-seuil-proprietaire` : X 1532, Y 371, 12 × 139

**Retour gauche** — `rule113-seuil-proprietaire` : X 1422, Y 359, 54 × 151

**Retour droit** — `rule113-seuil-proprietaire` : X 1544, Y 359, 54 × 151

**Seuil** — `rule113-seuil-proprietaire` : X 1476, Y 510, 68 × 4

**Fidélité** — `rule113-absence-visible` : Position héritée, non comparée à une géométrie mesurée du film. Aucun changement de topologie.

### Fermeture des galeries
`portal113-f161-cellblock-gate` · Seuils V113

Volet de service repris par des montants, avec retours maçonnés et mécanisme supérieur. Le passage utilise toujours la collision et le verrou existants. Le volet segmenté se replie vers son coffre ; ouvert, il ne laisse pas de masse opaque. Ces retours de cloison améliorent la cohérence locale, pas la preuve d’un emplacement identique à celui du film.

**Connexion** — `f161-e05` : Propriétaire unique du verrou : f161-cellblock-gate

**Depuis** — `f161-cell-b` : Appui conservé.

**Vers** — `f161-service-low` : Appui conservé.

**Ouverture** — `f161-cellblock-gate` : X 2823, Y 378, 44 × 132 ; pied Y 510

**Coffre** — `rule113-volet-rangement` : X 2812, Y 351, 66 × 20

**Montant gauche** — `rule113-seuil-proprietaire` : X 2811, Y 371, 12 × 139

**Montant droit** — `rule113-seuil-proprietaire` : X 2867, Y 371, 12 × 139

**Retour gauche** — `rule113-seuil-proprietaire` : X 2757, Y 359, 54 × 151

**Retour droit** — `rule113-seuil-proprietaire` : X 2879, Y 359, 54 × 151

**Seuil** — `rule113-seuil-proprietaire` : X 2811, Y 510, 68 × 4

**Fidélité** — `rule113-absence-visible` : Position héritée, non comparée à une géométrie mesurée du film. Aucun changement de topologie.

### Seuil de la fonderie
`portal113-f161-leadworks-gate` · Seuils V113

Fermeture industrielle sous une traverse de reprise et une gaine de volet repliable. Le passage utilise toujours la collision et le verrou existants. Le volet segmenté se replie vers son coffre ; ouvert, il ne laisse pas de masse opaque. Ces retours de cloison améliorent la cohérence locale, pas la preuve d’un emplacement identique à celui du film.

**Connexion** — `f161-e07` : Propriétaire unique du verrou : f161-leadworks-gate

**Depuis** — `f161-bishop` : Appui conservé.

**Vers** — `f161-leadworks` : Appui conservé.

**Ouverture** — `f161-leadworks-gate` : X 3828, Y 378, 44 × 132 ; pied Y 510

**Coffre** — `rule113-volet-rangement` : X 3817, Y 351, 66 × 20

**Montant gauche** — `rule113-seuil-proprietaire` : X 3816, Y 371, 12 × 139

**Montant droit** — `rule113-seuil-proprietaire` : X 3872, Y 371, 12 × 139

**Retour gauche** — `rule113-seuil-proprietaire` : X 3762, Y 359, 54 × 151

**Retour droit** — `rule113-seuil-proprietaire` : X 3884, Y 359, 54 × 151

**Seuil** — `rule113-seuil-proprietaire` : X 3816, Y 510, 68 × 4

**Fidélité** — `rule113-absence-visible` : Position héritée, non comparée à une géométrie mesurée du film. Aucun changement de topologie.

### Ellen Ripley
`cast113-ripley` · Personnages V113

Silhouette utilisée par un participant existant. Modèle slender. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié. Le rig distingue arrivée en gris, tenue carcérale brune avec coutures croisées et manteau extérieur vert. Le changement dépend d’un état explicite, pas du dessin.

**Référence** — `ref113-ripley-uniform` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Référence** — `ref113-ripley-crash` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Silhouette utilisée par un participant existant

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : Aucun nouvel équipement attribué.

### Dillon
`cast113-dillon` · Personnages V113

Silhouette utilisée par un participant existant. Modèle broad. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié. Corps plus large, manteau, gilet et capuche distincts ; aucune taille de collision modifiée.

**Référence** — `ref113-dillon-uniform` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Silhouette utilisée par un participant existant

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : Aucun nouvel équipement attribué.

### Morse
`cast113-morse` · Personnages V113

Silhouette utilisée par un participant existant. Modèle lean. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié. Morphologie et couche de vêtements distinctes. Référence précise de costume encore à compléter.

**Référence** — `ref113-inmate-uniform` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Silhouette utilisée par un participant existant

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : Aucun nouvel équipement attribué.

### Aaron
`cast113-aaron` · Personnages V113

Silhouette utilisée par un participant existant. Modèle stocky. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié. Morphologie et couche de vêtements distinctes. Référence précise de costume encore à compléter.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Silhouette utilisée par un participant existant

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : Aucun nouvel équipement attribué.

### Clemens
`cast113-clemens` · Personnages V113

Fiche seulement, pas de personnage jouable ajouté. Modèle tall. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Fiche seulement, pas de personnage jouable ajouté

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : medical-kit

### Andrews
`cast113-andrews` · Personnages V113

Fiche seulement, pas de personnage jouable ajouté. Modèle stocky. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Fiche seulement, pas de personnage jouable ajouté

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : Aucun nouvel équipement attribué.

### Golic
`cast113-golic` · Personnages V113

Fiche seulement, pas de personnage jouable ajouté. Modèle lean. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.

**Référence** — `ref113-cut-register` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Fiche seulement, pas de personnage jouable ajouté

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : Aucun nouvel équipement attribué.

### Junior
`cast113-junior` · Personnages V113

Fiche seulement, pas de personnage jouable ajouté. Modèle lean. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.

**Référence** — `ref113-cut-register` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Fiche seulement, pas de personnage jouable ajouté

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : Aucun nouvel équipement attribué.

### Murphy
`cast113-murphy` · Personnages V113

Fiche seulement, pas de personnage jouable ajouté. Modèle stocky. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.

**Référence** — `ref113-cut-register` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Fiche seulement, pas de personnage jouable ajouté

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : hand-lamp

### Boggs
`cast113-boggs` · Personnages V113

Fiche seulement, pas de personnage jouable ajouté. Modèle lean. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.

**Référence** — `ref113-cut-register` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Fiche seulement, pas de personnage jouable ajouté

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : Aucun nouvel équipement attribué.

### Rains
`cast113-rains` · Personnages V113

Fiche seulement, pas de personnage jouable ajouté. Modèle stocky. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.

**Référence** — `ref113-cut-register` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Fiche seulement, pas de personnage jouable ajouté

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : Aucun nouvel équipement attribué.

### Bishop endommagé
`cast113-bishop-damaged` · Personnages V113

Élément de décor sur appui. Modèle damaged. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Élément de décor sur appui

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : recorder

### Représentant de la Compagnie
`cast113-bishop-representative` · Personnages V113

Fiche seulement, pas de personnage jouable ajouté. Modèle tall. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.

**Référence** — `ref113-cut-register` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Fiche seulement, pas de personnage jouable ajouté

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : Aucun nouvel équipement attribué.

### Agent de récupération
`cast113-company-guard` · Personnages V113

Visuel conditionnel à l’arrivée, sans nouvelle IA. Modèle armoured. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.

**Référence** — `ref113-pulse-film` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Visuel conditionnel à l’arrivée, sans nouvelle IA

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : pulse-rifle

### Runner
`cast113-runner` · Personnages V113

Comportement et dessin historiques conservés. Modèle quadruped. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Comportement et dessin historiques conservés

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : Aucun nouvel équipement attribué.

### Hicks
`cast113-hicks` · Personnages V113

Fiche seulement, pas de personnage jouable ajouté. Modèle resting. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.

**Référence** — `ref113-studio-film` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Fiche seulement, pas de personnage jouable ajouté

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : Aucun nouvel équipement attribué.

### Newt
`cast113-newt` · Personnages V113

Fiche seulement, pas de personnage jouable ajouté. Modèle resting. Les proportions, teintes et vêtements forment une interprétation vectorielle : aucun visage photoréaliste ni ressemblance 1:1 n’est certifié.

**Référence** — `ref113-studio-film` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Statut** — `rule113-absence-visible` : Fiche seulement, pas de personnage jouable ajouté

**Rendu** — `rule113-dessin-pur` : Le dessin ne crée ni arrivée, ni inventaire, ni participant.

**Équipement** — `rule113-arme-proprietaire` : Aucun nouvel équipement attribué.

### Enregistreur de l’EEV
`item113-recorder` · Équipement V113

Console héritée ; nouvel accessoire visuel. Ne crée pas une nouvelle étape du film. Propriétaire : ripley. Usage : fixed-interaction. Preuve : scene-to-verify. État réel : bound-rendering. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `cast113-ripley` : ripley

**Appui** — `f161-flight-analysis-v94` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : flight-recorder-v113

### Module de secours
`item113-eev` · Équipement V113

Coque déjà présente. Le plan et les dimensions exacts ne sont pas certifiés. Propriétaire : environment. Usage : scenery. Preuve : production-reference. État réel : bound-rendering. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-ripley-crash` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : environment

**Appui** — `f161-eev` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : coast-wreck/0

### Trousse et plateau médical
`item113-medical-kit` · Équipement V113

Matériel de soin, pas réserve de soins illimitée pour Ripley. Propriétaire : clemens. Usage : scenery. Preuve : scene-to-verify. État réel : bound-rendering. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `cast113-clemens` : clemens

**Appui** — `f161-infirmary` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Appui** — `f161-clemens-bed` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : medical-care/4, medical-care/5, medical-care/6, medical-care/10, clemens-room/4, clemens-room/5, clemens-room/6, clemens-room/10, medical-kit-v113

### Diagnostic de l’EEV
`item113-scanner` · Équipement V113

Écran et éléments diagnostiques, couverture visuelle seulement dans cette passe. Propriétaire : environment. Usage : fixed-interaction. Preuve : scene-to-verify. État réel : missing-binding. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : environment

**Appui** — `f161-eev` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Appui** — `f161-flight-analysis-v94` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : Aucun objet de décor lié : garder le manque visible.

### Bishop endommagé
`item113-bishop` · Équipement V113

Nouveau fragment de synthétique sur son support ; aucune nouvelle interaction narrative. Propriétaire : environment. Usage : scenery. Preuve : scene-to-verify. État réel : bound-rendering. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : environment

**Appui** — `f161-bishop` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : bishop-remains-v113

### Émetteur des communications
`item113-comms` · Équipement V113

Équipement fixe raccordé à l’étage existant. Propriétaire : environment. Usage : fixed-interaction. Preuve : scene-to-verify. État réel : bound-rendering. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : environment

**Appui** — `f161-comms-high` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : actual-comms/0, actual-comms/2, actual-comms/3

### Lampe portative
`item113-hand-lamp` · Équipement V113

Forme et porteur à relever ; ne pas confondre avec les huit interrupteurs locaux. Propriétaire : prisoners. Usage : catalogue. Preuve : scene-to-verify. État réel : not-integrated. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : prisoners

**Appui** — `f161-fan-shaft` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : Aucun objet de décor lié : garder le manque visible.

### Torche incendiaire
`item113-flare` · Équipement V113

Présence visuelle liée au plan de feu ; pas de nouvelle arme ou de recette réelle. Propriétaire : prisoners. Usage : visual-state. Preuve : production-reference. État réel : bound-rendering. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : prisoners

**Appui** — `f161-chemical-store` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : fire-flare-v113

### Récipients du plan incendiaire
`item113-fuel` · Équipement V113

Pas de recette chimique ; les règles historiques restent propriétaires. Propriétaire : prisoners. Usage : scenery. Preuve : production-reference. État réel : bound-rendering. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : prisoners

**Appui** — `f161-chemical-store` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : chemical-store/1, chemical-store/2

### Outil lourd improvisé
`item113-axe` · Équipement V113

Porteur, scène et silhouette doivent être confirmés avant intégration. Propriétaire : prisoners. Usage : catalogue. Preuve : unverified. État réel : not-integrated. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Porteur** — `rule113-arme-proprietaire` : prisoners

**Objets liés** — `rule113-absence-visible` : Aucun objet de décor lié : garder le manque visible.

### Clé de maintenance
`item113-wrench` · Équipement V113

Outils déjà dessinés dans l’atelier ; leur disponibilité combat n’est pas affirmée. Propriétaire : prisoners. Usage : scenery. Preuve : scene-to-verify. État réel : bound-rendering. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : prisoners

**Appui** — `f161-battery-locker-v94` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : battery-store/2

### Ventilateur de galerie
`item113-fan` · Équipement V113

Installation fixe avec protection, pas objet d’inventaire. Propriétaire : environment. Usage : fixed-interaction. Preuve : scene-to-verify. État réel : bound-rendering. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : environment

**Appui** — `f161-fan-shaft` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : murphy-fan/0

### Plomb de la fonderie
`item113-lead` · Équipement V113

La coulée exige le déroulement et le volume hérités. Propriétaire : environment. Usage : fixed-interaction. Preuve : production-reference. État réel : bound-rendering. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : environment

**Appui** — `f161-leadworks` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : leadworks/0

### Moule industriel
`item113-mold` · Équipement V113

Les commandes ne déplacent pas automatiquement le Runner. Propriétaire : environment. Usage : fixed-interaction. Preuve : production-reference. État réel : bound-rendering. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : environment

**Appui** — `f161-mold` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : mold/0

### Portique et poche de transfert
`item113-hoist` · Équipement V113

Mécanisme visible ; dimensions de jeu, pas relevé 1:1. Propriétaire : environment. Usage : scenery. Preuve : production-reference. État réel : bound-rendering. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : environment

**Appui** — `f161-leadworks` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : leadworks/1, leadworks/2, leadworks/3

### Réseau de refroidissement
`item113-water` · Équipement V113

Ne pas confondre la commande de piège avec les purges facultatives. Propriétaire : environment. Usage : fixed-interaction. Preuve : scene-to-verify. État réel : bound-rendering. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-asc-1992` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : environment

**Appui** — `f161-water-header` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Appui** — `f161-sprinkler` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : water-header/1, water-header/2

### Fusil à impulsion noir
`item113-pulse-rifle` · Équipement V113

Sur un agent de récupération à l’arrivée seulement. Aucun transfert à Ripley, aucun tir nouveau. Propriétaire : company-guard. Usage : arrival-render-only. Preuve : production-reference. État réel : conditional-visual. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-pulse-film` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `cast113-company-guard` : company-guard

**Appui** — `f161-company` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : Aucun objet de décor lié : garder le manque visible.

### Matériel de récupération
`item113-recovery` · Équipement V113

Doit rester absent avant l’arrivée ; échelle et forme à comparer au film. Propriétaire : company. Usage : arrival-render-only. Preuve : scene-to-verify. État réel : conditional-visual. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-pulse-film` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : company

**Appui** — `f161-patna-cage-node` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : patna-kit/0, patna-kit/1, patna-kit/6

### Bottes de Ripley
`item113-boots` · Équipement V113

Semelle sombre et tige distincte dans le rig ; géométrie stylisée. Propriétaire : ripley. Usage : costume. Preuve : production-reference. État réel : shared-renderer. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-ripley-uniform` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `cast113-ripley` : ripley

**Objets liés** — `rule113-absence-visible` : Aucun objet de décor lié : garder le manque visible.

### Manteau carcéral
`item113-prison-coat` · Équipement V113

Vert délavé, insigne simplifié et état extérieur explicite. Propriétaire : ripley. Usage : costume. Preuve : production-reference. État réel : shared-renderer. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-ripley-uniform` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `cast113-ripley` : ripley

**Objets liés** — `rule113-absence-visible` : Aucun objet de décor lié : garder le manque visible.

### Trois boulons de diversion
`item113-bolts` · Équipement V113

Mécanique V108 conservée dans les essais de survie ; non déclarée conforme à une scène du film. Propriétaire : ripley. Usage : gameplay-original. Preuve : game-original. État réel : inherited. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Porteur** — `cast113-ripley` : ripley

**Objets liés** — `rule113-absence-visible` : Aucun objet de décor lié : garder le manque visible.

### Trois purges locales
`item113-purges` · Équipement V113

Règles V109–V112, pas réseau thermodynamique intégral du film. Propriétaire : environment. Usage : gameplay-original. Preuve : game-original. État réel : inherited. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Porteur** — `rule113-arme-proprietaire` : environment

**Appui** — `f161-service-low` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Appui** — `f161-service-high` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Appui** — `f161-leadworks` : Appui hérité ; aucun déplacement arbitraire de l’objet.

**Objets liés** — `rule113-absence-visible` : service-pump/2

### Détecteur de mouvement
`item113-tracker` · Équipement V113

Aucun ajout à l’inventaire de Ripley dans cette passe. Propriétaire : none. Usage : excluded. Preuve : not-granted. État réel : intentionally-absent. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Porteur** — `rule113-arme-proprietaire` : none

**Objets liés** — `rule113-absence-visible` : Aucun objet de décor lié : garder le manque visible.

### Arsenal de Marines pour Ripley
`item113-marine-rifle` · Équipement V113

L’arme visible de la Compagnie ne justifie pas un arsenal initial de Marines. Propriétaire : none. Usage : excluded. Preuve : excluded-by-design. État réel : intentionally-absent. Le registre n’est pas une certification d’exhaustivité de l’équipement à l’écran.

**Référence** — `ref113-studio-film` : Source de comparaison, indépendante du statut de dessin ou de simulation.

**Porteur** — `rule113-arme-proprietaire` : none

**Objets liés** — `rule113-absence-visible` : Aucun objet de décor lié : garder le manque visible.

### Sulaco : départ de l’EEV
`place113-sulaco` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Prologue absent du banc ; pas de scène validée ici. Statut : aucune géométrie dédiée liée dans le modèle actuel. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

### Côte et épave
`place113-shore` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Architecture stylisée, approche à comparer selon montage. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-spawn` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-eev` : Coordonnée du jeu, pas une mesure du film.

### Approche avec le bovin
`place113-ox` · Lieux et scènes V113

Assembly seulement dans ce registre. Ne pas utiliser l’hôte canin dans cette continuité ; scène non intégrée ici. Statut : aucune géométrie dédiée liée dans le modèle actuel. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Assembly seulement dans ce registre

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Repérage secondaire** — `ref113-cut-register` : Différences à rapprocher d’une copie autorisée ; pas de séquence native entière validée.

### Chenil / présence de Spike
`place113-dog` · Lieux et scènes V113

Cinéma seulement dans ce registre. Pas de chenil jouable qualifié ; ne pas déclarer le point EEV équivalent. Statut : aucune géométrie dédiée liée dans le modèle actuel. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma seulement dans ce registre

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Repérage secondaire** — `ref113-cut-register` : Différences à rapprocher d’une copie autorisée ; pas de séquence native entière validée.

### Infirmerie et alcôve de Clemens
`place113-infirmary` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Appuis et mobilier présents ; proportions non mesurées. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-infirmary` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-clemens-bed` : Coordonnée du jeu, pas une mesure du film.

### Morgue et examen des corps
`place113-morgue` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Palier supérieur hérité ; descente du montage étendu à comparer avant refonte. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-morgue-high` : Coordonnée du jeu, pas une mesure du film.

**Repérage secondaire** — `ref113-cut-register` : Différences à rapprocher d’une copie autorisée ; pas de séquence native entière validée.

### Cérémonie et crémation
`place113-funeral` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Points présents ne prouvent pas la mise en scène complète. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-funeral-walk` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-furnace` : Coordonnée du jeu, pas une mesure du film.

### Bureau d’Andrews
`place113-office` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Pas de pièce dédiée liée dans le modèle actuel. Statut : aucune géométrie dédiée liée dans le modèle actuel. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

### Cellules et coursives
`place113-cells` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Façades arrière : pas toutes les cellules visitables. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-cell-a` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-cell-b` : Coordonnée du jeu, pas une mesure du film.

### Réfectoire et rassemblement
`place113-mess` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Deux étages de gameplay ; continuité film à qualifier. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-assembly-hall` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-mess-high` : Coordonnée du jeu, pas une mesure du film.

### Recueillement
`place113-prayer` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Identification narrative à rapprocher des scènes, pas chapelle neuve inventée. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-faith-dais-v94` : Coordonnée du jeu, pas une mesure du film.

### Poste de communications
`place113-comms` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Équipements localisés, décor haut hérité. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-comms-high` : Coordonnée du jeu, pas une mesure du film.

### Ventilation de Murphy
`place113-fan` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Ventilateur visible ; séquence entière non rejouée par ce patch. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-fan-shaft` : Coordonnée du jeu, pas une mesure du film.

### Couloirs et galeries de chasse
`place113-tunnels` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Graphe dense mais métrique et raccords non certifiés à l’image. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-service-low` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-service-high` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-tunnel-low` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-tunnel-high` : Coordonnée du jeu, pas une mesure du film.

### Raccordement de Bishop
`place113-bishop` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Fragment visible ajouté, dialogue intégral non reproduit. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-bishop` : Coordonnée du jeu, pas une mesure du film.

### Réserve et préparation incendiaire
`place113-fuel` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. État de feu hérité, récipients et torche ancrés ; aucun nouveau combat. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-chemical-store` : Coordonnée du jeu, pas une mesure du film.

### Piège de la cuve à déchets
`place113-waste` · Lieux et scènes V113

Assembly seulement dans ce registre. Point hérité ; capture et libération à qualifier dans la campagne native. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Assembly seulement dans ce registre

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-waste-tank` : Coordonnée du jeu, pas une mesure du film.

**Repérage secondaire** — `ref113-cut-register` : Différences à rapprocher d’une copie autorisée ; pas de séquence native entière validée.

### Confinement de Golic
`place113-golic` · Lieux et scènes V113

Assembly seulement dans ce registre. Cache inférieure héritée ne remplace pas le lieu de confinement à l’écran. Statut : aucune géométrie dédiée liée dans le modèle actuel. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Assembly seulement dans ce registre

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Repérage secondaire** — `ref113-cut-register` : Différences à rapprocher d’une copie autorisée ; pas de séquence native entière validée.

### Analyse diagnostique de l’EEV
`place113-scanner` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Ne pas inventer un appareil mobile accessible partout. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-flight-analysis-v94` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-eev` : Coordonnée du jeu, pas une mesure du film.

### Salle de coulée
`place113-lead` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Moule et portique présents ; parcours de test original distinct du film. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-leadworks` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-lead-primer` : Coordonnée du jeu, pas une mesure du film.

### Rabattage, pistons et moule
`place113-pistons` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Le retour vivant de Dillon du banc n’est pas le dénouement du film. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-piston-a-node` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-piston-b-node` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-piston-c-node` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-mold` : Coordonnée du jeu, pas une mesure du film.

### Commande haute du refroidissement
`place113-water` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Hauteurs validées pour le jeu ; parcours exact à comparer. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-water-header` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-sprinkler` : Coordonnée du jeu, pas une mesure du film.

### Four et plateforme finale
`place113-furnace` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Graphisme et fin de Ripley non qualifiés 1:1. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-furnace` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-extraction` : Coordonnée du jeu, pas une mesure du film.

### Arrivée de la Compagnie
`place113-patna` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Agents et arme représentés à l’arrivée seulement ; pas de nouvel échange de tirs. Statut : repère(s) existant(s) lié(s), pas une pièce certifiée conforme au film. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

**Point** — `f161-company` : Coordonnée du jeu, pas une mesure du film.

**Point** — `f161-patna-cage-node` : Coordonnée du jeu, pas une mesure du film.

### Intérieur de la navette de récupération
`place113-ship` · Lieux et scènes V113

Cinéma et Assembly, comparaison séparée requise. Aucun intérieur complet lié ; ne pas le confondre avec la plateforme extérieure. Statut : aucune géométrie dédiée liée dans le modèle actuel. Aucun minutage, plan de plateau ou taux de fidélité n’est inventé.

**Montage** — `rule113-chronologie` : Cinéma et Assembly, comparaison séparée requise

**Preuve** — `rule113-absence-visible` : Présence d’un point, scène jouée et conformité à l’image sont trois validations distinctes.

### Seuil proprietaire
`rule113-seuil-proprietaire` · Règles V113

Une porte est rattachée à une connexion, à son seuil et à son état réel. Les retours de mur ne modifient pas la collision.

**Contrôle** — `qa-v113/unit.json` : Contrats instrumentés, puis comparaison de captures et parcours clavier séparés.

### Volet rangement
`rule113-volet-rangement` · Règles V113

La feuille se replie vers son coffre, dans l’ouverture ; un volet ouvert ne laisse pas un rectangle opaque devant le passage.

**Contrôle** — `qa-v113/unit.json` : Contrats instrumentés, puis comparaison de captures et parcours clavier séparés.

### Arme proprietaire
`rule113-arme-proprietaire` · Règles V113

L’arme de récupération appartient à son porteur. Le même visuel ne permet jamais de l’ajouter à l’inventaire de Ripley.

**Contrôle** — `qa-v113/unit.json` : Contrats instrumentés, puis comparaison de captures et parcours clavier séparés.

### Scene condition
`rule113-scene-condition` · Règles V113

L’arrivée de la Compagnie et la tenue d’extérieur sont des états explicites. Dessiner une image ne change ni l’un ni l’autre.

**Contrôle** — `qa-v113/unit.json` : Contrats instrumentés, puis comparaison de captures et parcours clavier séparés.

### Absence visible
`rule113-absence-visible` · Règles V113

Une fiche sans pièce ou acteur lié reste marquée non intégrée. Un nom dans le registre ne remplit pas une scène.

**Contrôle** — `qa-v113/unit.json` : Contrats instrumentés, puis comparaison de captures et parcours clavier séparés.

### Chronologie
`rule113-chronologie` · Règles V113

Montage cinéma et version étendue sont deux colonnes de couverture, pas deux campagnes annoncées terminées.

**Contrôle** — `qa-v113/unit.json` : Contrats instrumentés, puis comparaison de captures et parcours clavier séparés.

### Dessin pur
`rule113-dessin-pur` · Règles V113

La couche de fidélité est calculée à la demande ; aucune progression, arme, lumière ou position ne change au dessin.

**Contrôle** — `qa-v113/unit.json` : Contrats instrumentés, puis comparaison de captures et parcours clavier séparés.

### Sources pas label
`rule113-sources-pas-label` · Règles V113

Les références de costume guident la silhouette ; elles ne prouvent pas une ressemblance photographique du visage.

**Contrôle** — `qa-v113/unit.json` : Contrats instrumentés, puis comparaison de captures et parcours clavier séparés.

# EXTENSION V114 — ATLAS DE CONTINUITÉ

Codex de conception hors jeu. V114 formalise deux montages, 29 espaces, 25 raccords logiques et cinq nouveaux équipements documentés. Les shells d’inspection rendent visibles des lieux manquants sans les présenter comme des pièces traversables. Le graphe reste 72 points / 119 connexions et la morgue demeure provisoire.

## Propstore — Dillon fire axe / production archive
`ref114-propstore-axe` · Références V114

Une hache de Dillon est documentée ; elle reste un objet de personnage, pas un arsenal distribué. Source de production utilisée comme repère de conception ; aucun média du film n’est redistribué.

**Source** — `https://propstore.com/movie/alien-1992/` : production-object

## Propstore — Weyland-Yutani commando helmet
`ref114-propstore-commando` · Références V114

Casque gris, masque aluminium, lunettes teintées ; commandos armés de pulse rifles. Source de production utilisée comme repère de conception ; aucun média du film n’est redistribué.

**Source** — `https://content.propstore.com/auction/emlaus25-2/catalog/EMLA-US_SUMMER25_Catalog_WEB_LO.pdf` : production-object

## Montage cinéma
`cut114-theatrical` · Montages V114

Registre séparé : 25 espaces actifs, 20 reliés au graphe, 3 shells d’inspection et 1 lieu(x) provisoire(s). Le choix du montage ne modifie pas la sauvegarde V112.

**Graphe** — `rule114-base-graph` : 72 points / 119 connexions

**Inspection** — `rule114-shells` : andrews-office, dog-kennel, patna-interior

**Provisoire** — `rule114-morgue` : morgue

## Assembly Cut
`cut114-assembly` · Montages V114

Registre séparé : 28 espaces actifs, 21 reliés au graphe, 5 shells d’inspection et 1 lieu(x) provisoire(s). Le choix du montage ne modifie pas la sauvegarde V112.

**Graphe** — `rule114-base-graph` : 72 points / 119 connexions

**Inspection** — `rule114-shells` : andrews-office, slaughterhouse, golic-confinement, ox-approach, patna-interior

**Provisoire** — `rule114-morgue` : morgue

## Côte / EEV
`room114-shore` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Zone extérieure et épave.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-spawn` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-eev` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Analyse EEV
`room114-flight-analysis` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Lecture et diagnostic de l’EEV.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-flight-analysis-v94` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Infirmerie / alcôve Clemens
`room114-infirmary` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Soins, lits et circulation médicale.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-infirmary` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-clemens-bed` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Morgue
`room114-morgue` · Lieux V114

Montage : both. Statut : Présent mais raccord non certifié. Altitude héritée : raccord à reconstruire avant certification 1:1.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-morgue-high` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Chemin de crémation
`room114-funeral` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Séquence funéraire distincte de la fonderie finale.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-funeral-walk` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-furnace` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Cellules ouest
`room114-cells-west` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Coursive et fronts de cellules.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-cell-a` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Cellules est
`room114-cells-east` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Coursive et verrou de service.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-cell-b` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-shutter-cell-node` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Salle commune / assemblée
`room114-assembly-hall` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Rassemblements et briefings.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-assembly-hall` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-mess-high` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Recueillement
`room114-prayer` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Espace spirituel, sans porte fictive au fond.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-faith-dais-v94` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Communications
`room114-comms` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Console et message de la Compagnie.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-comms-high` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Service / pompage
`room114-service` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Entretien et raccordement Bishop.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-service-low` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-rescue-post-node` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-bishop` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Ventilation
`room114-ventilation` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Verticalité et ventilateur.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-fan-shaft` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-service-high` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-steam-service-node` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Atelier batteries
`room114-batteries` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Établi et stockage technique.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-battery-locker-v94` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-hunt-service-v95` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Galeries basses
`room114-lower-service` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Dessous du complexe.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-service-deep` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-tunnel-shrine` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Tunnels minerai
`room114-ore-tunnels` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Réseau de chasse.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-tunnel-low` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-tunnel-high` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-hunt-junction-v95` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Réserve chimique
`room114-fuel` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Préparation du plan incendiaire.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-chemical-store` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-fuel-manifold-a` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-fuel-manifold-b` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Cuve déchets
`room114-waste` · Lieux V114

Montage : assembly. Statut : Lié au graphe existant. Piège de la version étendue.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-waste-tank` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Leadworks / coulée
`room114-leadworks` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Installation de plomb et portique.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-leadworks` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-lead-primer` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Moule / pistons
`room114-mold` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Zone du rabattage final.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-mold` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-piston-a-node` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-piston-b-node` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-piston-c-node` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Refroidissement
`room114-water` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Commande haute de refroidissement.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-water-header` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-sprinkler` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Passerelles fonderie
`room114-foundry-overlook` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Passerelles et vue haute.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-furnace-overlook` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-furnace-gantry` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Arrivée Compagnie
`room114-company` · Lieux V114

Montage : both. Statut : Lié au graphe existant. Plateforme d’arrivée et confrontation.

**Type** — `rule114-base-graph` : existing

**Point** — `f161-company` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-patna-cage-node` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

**Point** — `f161-extraction` : Point du graphe historique ; sa présence ne prouve pas une correspondance 1:1 au plateau.

## Bureau d’Andrews
`room114-andrews-office` · Lieux V114

Montage : both. Statut : Shell d’inspection ; non traversable dans la campagne. Pièce manquante : shell d’inspection ancré près de l’administration.

**Type** — `rule114-shells` : inspection-shell

**Ancrage** — `f161-assembly-hall` : Point de jeu utilisé uniquement pour positionner le shell.

## Abattoir
`room114-slaughterhouse` · Lieux V114

Montage : assembly. Statut : Shell d’inspection ; non traversable dans la campagne. Shell d’inspection avec rail, crochets et treuil ; aucun passage de campagne ajouté.

**Type** — `rule114-shells` : inspection-shell

**Ancrage** — `f161-waste-tank` : Point de jeu utilisé uniquement pour positionner le shell.

## Confinement de Golic
`room114-golic-confinement` · Lieux V114

Montage : assembly. Statut : Shell d’inspection ; non traversable dans la campagne. Shell d’inspection distinct du cache technique.

**Type** — `rule114-shells` : inspection-shell

**Ancrage** — `f161-golic-cache-v94` : Point de jeu utilisé uniquement pour positionner le shell.

## Chenil / Spike
`room114-dog-kennel` · Lieux V114

Montage : theatrical. Statut : Shell d’inspection ; non traversable dans la campagne. Variante cinéma seulement ; aucun chien en Assembly.

**Type** — `rule114-shells` : inspection-shell

**Ancrage** — `f161-eev` : Point de jeu utilisé uniquement pour positionner le shell.

## Bovin / approche
`room114-ox-approach` · Lieux V114

Montage : assembly. Statut : Shell d’inspection ; non traversable dans la campagne. Variante Assembly seulement ; aucun hôte canin simultané.

**Type** — `rule114-shells` : inspection-shell

**Ancrage** — `f161-eev` : Point de jeu utilisé uniquement pour positionner le shell.

## Intérieur récupération
`room114-patna-interior` · Lieux V114

Montage : both. Statut : Shell d’inspection ; non traversable dans la campagne. Aperçu de l’intérieur, sans route ni objectif ajoutés.

**Type** — `rule114-shells` : inspection-shell

**Ancrage** — `f161-company` : Point de jeu utilisé uniquement pour positionner le shell.

## Sulaco / départ EEV
`room114-sulaco-prologue` · Lieux V114

Montage : both. Statut : Documenté hors monde jouable. Hors Fiorina ; conservé dans la matrice mais jamais compté comme pièce de la prison.

**Type** — `rule114-base-graph` : offworld

## Shore analysis
`link114-shore-analysis` · Raccords V114

shore ↔ flight-analysis. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-shore` : Espace source

**Vers** — `room114-flight-analysis` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Shore infirmary
`link114-shore-infirmary` · Raccords V114

shore ↔ infirmary. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-shore` : Espace source

**Vers** — `room114-infirmary` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Medical morgue
`link114-medical-morgue` · Raccords V114

infirmary ↔ morgue. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-infirmary` : Espace source

**Vers** — `room114-morgue` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Medical cells
`link114-medical-cells` · Raccords V114

infirmary ↔ cells-west. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-infirmary` : Espace source

**Vers** — `room114-cells-west` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Cells assembly
`link114-cells-assembly` · Raccords V114

cells-west ↔ assembly-hall. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-cells-west` : Espace source

**Vers** — `room114-assembly-hall` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Cells service
`link114-cells-service` · Raccords V114

cells-east ↔ service. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-cells-east` : Espace source

**Vers** — `room114-service` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Assembly prayer
`link114-assembly-prayer` · Raccords V114

assembly-hall ↔ prayer. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-assembly-hall` : Espace source

**Vers** — `room114-prayer` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Assembly comms
`link114-assembly-comms` · Raccords V114

assembly-hall ↔ comms. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-assembly-hall` : Espace source

**Vers** — `room114-comms` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Service vent
`link114-service-vent` · Raccords V114

service ↔ ventilation. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-service` : Espace source

**Vers** — `room114-ventilation` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Service batteries
`link114-service-batteries` · Raccords V114

service ↔ batteries. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-service` : Espace source

**Vers** — `room114-batteries` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Service lower
`link114-service-lower` · Raccords V114

service ↔ lower-service. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-service` : Espace source

**Vers** — `room114-lower-service` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Lower tunnels
`link114-lower-tunnels` · Raccords V114

lower-service ↔ ore-tunnels. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-lower-service` : Espace source

**Vers** — `room114-ore-tunnels` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Service fuel
`link114-service-fuel` · Raccords V114

service ↔ fuel. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-service` : Espace source

**Vers** — `room114-fuel` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Tunnels waste
`link114-tunnels-waste` · Raccords V114

ore-tunnels ↔ waste. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-ore-tunnels` : Espace source

**Vers** — `room114-waste` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Service lead
`link114-service-lead` · Raccords V114

service ↔ leadworks. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-service` : Espace source

**Vers** — `room114-leadworks` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Lead mold
`link114-lead-mold` · Raccords V114

leadworks ↔ mold. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-leadworks` : Espace source

**Vers** — `room114-mold` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Lead water
`link114-lead-water` · Raccords V114

leadworks ↔ water. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-leadworks` : Espace source

**Vers** — `room114-water` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Mold overlook
`link114-mold-overlook` · Raccords V114

mold ↔ foundry-overlook. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-mold` : Espace source

**Vers** — `room114-foundry-overlook` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Mold company
`link114-mold-company` · Raccords V114

mold ↔ company. Mode : graph. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-mold` : Espace source

**Vers** — `room114-company` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Office annex
`link114-office-annex` · Raccords V114

assembly-hall ↔ andrews-office. Mode : inspection. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-assembly-hall` : Espace source

**Vers** — `room114-andrews-office` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Slaughter annex
`link114-slaughter-annex` · Raccords V114

lower-service ↔ slaughterhouse. Mode : inspection. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-lower-service` : Espace source

**Vers** — `room114-slaughterhouse` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Golic annex
`link114-golic-annex` · Raccords V114

lower-service ↔ golic-confinement. Mode : inspection. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-lower-service` : Espace source

**Vers** — `room114-golic-confinement` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Dog variant
`link114-dog-variant` · Raccords V114

shore ↔ dog-kennel. Mode : inspection. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-shore` : Espace source

**Vers** — `room114-dog-kennel` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Ox variant
`link114-ox-variant` · Raccords V114

shore ↔ ox-approach. Mode : inspection. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-shore` : Espace source

**Vers** — `room114-ox-approach` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Patna annex
`link114-patna-annex` · Raccords V114

company ↔ patna-interior. Mode : inspection. Les raccords 'graph' doivent être réellement atteignables dans les 119 connexions ; les raccords 'inspection' n’ajoutent aucune route.

**Depuis** — `room114-company` : Espace source

**Vers** — `room114-patna-interior` : Espace destination

**Règle** — `rule114-no-hidden-route` : Aucun passage invisible n’est créé par le registre.

## Murphy
`cast114-murphy` · Personnages V114

Silhouette vectorielle d’inspection : stocky. Statut inspection-npc. Aucun visage 1:1 certifié et aucune collision de gameplay modifiée.

**Règle** — `rule114-cast` : L’apparence est séparée de la collision et de la navigation.

**Référence** — `ref113-inmate-uniform` : Repère de costume / production.

## Golic
`cast114-golic` · Personnages V114

Silhouette vectorielle d’inspection : lean. Statut inspection-npc. Aucun visage 1:1 certifié et aucune collision de gameplay modifiée.

**Règle** — `rule114-cast` : L’apparence est séparée de la collision et de la navigation.

**Référence** — `ref113-inmate-uniform` : Repère de costume / production.

**Référence** — `ref113-cut-register` : Repère de costume / production.

## Andrews
`cast114-andrews` · Personnages V114

Silhouette vectorielle d’inspection : stocky. Statut inspection-npc. Aucun visage 1:1 certifié et aucune collision de gameplay modifiée.

**Règle** — `rule114-cast` : L’apparence est séparée de la collision et de la navigation.

**Référence** — `ref113-asc-1992` : Repère de costume / production.

## Clemens
`cast114-clemens` · Personnages V114

Silhouette vectorielle d’inspection : tall. Statut inspection-npc. Aucun visage 1:1 certifié et aucune collision de gameplay modifiée.

**Règle** — `rule114-cast` : L’apparence est séparée de la collision et de la navigation.

**Référence** — `ref113-asc-1992` : Repère de costume / production.

## Bishop II / représentant
`cast114-company-rep` · Personnages V114

Silhouette vectorielle d’inspection : tall. Statut inspection-npc. Aucun visage 1:1 certifié et aucune collision de gameplay modifiée.

**Règle** — `rule114-cast` : L’apparence est séparée de la collision et de la navigation.

**Référence** — `ref114-propstore-commando` : Repère de costume / production.

## Hache de Dillon
`item114-dillon-axe` · Équipement V114

Propriétaire : dillon. Usage : character-prop. État : visual-inspection. Présente avec Dillon dans les scènes d’inspection ; jamais ajoutée à l’inventaire de Ripley.

**Règle** — `rule114-owner` : Un équipement visible n’est jamais attribué à Ripley sans propriétaire explicite.

**Point** — `f161-leadworks` : Ancrage de jeu.

## Casque de commando Weyland-Yutani
`item114-commando-helmet` · Équipement V114

Propriétaire : company-guard. Usage : worn-equipment. État : arrival-render. Masque et lunettes intégrés au porteur.

**Règle** — `rule114-owner` : Un équipement visible n’est jamais attribué à Ripley sans propriétaire explicite.

**Point** — `f161-company` : Ancrage de jeu.

## Pulse Rifle Alien 3
`item114-pulse-rifle-black` · Équipement V114

Propriétaire : company-guard. Usage : weapon-carried. État : arrival-render. Finition noire ; aucun spawn d’arme pour Ripley.

**Règle** — `rule114-owner` : Un équipement visible n’est jamais attribué à Ripley sans propriétaire explicite.

**Point** — `f161-company` : Ancrage de jeu.

## Rail / treuil d’abattoir
`item114-slaughter-rail` · Équipement V114

Propriétaire : environment. Usage : fixed-equipment. État : inspection-shell. Présent uniquement dans le shell Assembly de l’abattoir.

**Règle** — `rule114-owner` : Un équipement visible n’est jamais attribué à Ripley sans propriétaire explicite.

## Confinement de Golic
`item114-golic-restraint` · Équipement V114

Propriétaire : environment. Usage : fixed-equipment. État : inspection-shell. Grille et couchette dans le shell d’inspection.

**Règle** — `rule114-owner` : Un équipement visible n’est jamais attribué à Ripley sans propriétaire explicite.

## Base graph
`rule114-base-graph` · Règles V114

Le socle reste 72 points / 119 connexions. Un shell d’inspection ne modifie jamais ce graphe.

**Contrôle** — `qa-v114/browser.json` : Contrôle Chromium ou contrat unitaire V114.

## No hidden route
`rule114-no-hidden-route` · Règles V114

Aucun lieu ajouté pour fidélité ne crée de raccourci, porte invisible ou téléportation.

**Contrôle** — `qa-v114/browser.json` : Contrôle Chromium ou contrat unitaire V114.

## Shells
`rule114-shells` · Règles V114

Un shell d’inspection rend un lieu visible et vérifiable mais ne doit pas être présenté comme traversable tant qu’un vrai raccord n’existe pas.

**Contrôle** — `qa-v114/browser.json` : Contrôle Chromium ou contrat unitaire V114.

## Cuts
`rule114-cuts` · Règles V114

Cinéma et Assembly sont mutuellement exclusifs pour les variantes d’hôte ; chien et bovin ne sont jamais affichés ensemble dans un même montage.

**Contrôle** — `qa-v114/browser.json` : Contrôle Chromium ou contrat unitaire V114.

## Morgue
`rule114-morgue` · Règles V114

La morgue reste provisoire tant que son raccord vertical n’est pas reconstruit et validé.

**Contrôle** — `qa-v114/browser.json` : Contrôle Chromium ou contrat unitaire V114.

## Owner
`rule114-owner` · Règles V114

Armes et outils gardent un propriétaire ; le Pulse Rifle noir appartient aux agents de récupération.

**Contrôle** — `qa-v114/browser.json` : Contrôle Chromium ou contrat unitaire V114.

## Cast
`rule114-cast` · Règles V114

Les silhouettes de personnages ne changent ni collisions, ni vitesses, ni sauvegardes.

**Contrôle** — `qa-v114/browser.json` : Contrôle Chromium ou contrat unitaire V114.

## Save purity
`rule114-save-purity` · Règles V114

Changer de montage ou redessiner vingt fois ne modifie pas le fichier V112.

**Contrôle** — `qa-v114/browser.json` : Contrôle Chromium ou contrat unitaire V114.

## Matrice de continuité Fiorina
`audit114-world` · Audit V114

Audit théâtre et Assembly : erreurs structurantes 0/0. La matrice conserve explicitement les shells d’inspection et la morgue provisoire ; elle n’invente aucun taux de fidélité 1:1.

**Cinéma** — `cut114-theatrical` : Voir couverture

**Assembly** — `cut114-assembly` : Voir couverture

**QA** — `qa-v114/unit.json` : Contrats de structure

