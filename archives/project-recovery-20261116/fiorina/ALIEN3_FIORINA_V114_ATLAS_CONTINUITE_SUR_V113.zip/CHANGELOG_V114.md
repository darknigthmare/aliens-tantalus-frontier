# V114 — Atlas de continuité

- Séparation exécutable des inspections `theatrical` et `assembly`.
- Registre de 29 espaces et 25 raccords logiques sur le graphe historique 72/119.
- Shells d’inspection explicites : bureau Andrews, abattoir, confinement Golic, chenil/Spike, approche bovine, intérieur récupération.
- Morgue conservée mais marquée provisoire jusqu’à refonte du raccord vertical.
- Cinq silhouettes supplémentaires d’inspection : Andrews, Clemens, Golic, Murphy, représentant de la Compagnie.
- Cinq entrées d’équipement supplémentaires, dont hache de Dillon, casque commando et Pulse Rifle noir avec propriétaire.
- Codex porté à 847 fiches.
- Choix de montage et rendu purs : aucune migration de sauvegarde V112.
- Installateur V113→V114 : quatre modules nouveaux, un seul raccord du moteur, rollback externe.
