# QA — Alien 3 V114 · Atlas de continuité

## Périmètre
Couche de fidélité incrémentale au-dessus de V113. Elle ne modifie pas les 72 points ni les 119 connexions du graphe historique. Les nouveaux lieux manquants sont des shells d’inspection explicitement non traversables tant qu’un vrai raccord n’existe pas. La campagne native complète n’a pas été construite ni exécutée.

## Résultats exécutés
- 14 contrats unitaires V114 : montages, topologie, propriétaires d’équipement et statuts de lieux.
- 14 scénarios d’installation V113→V114 sur fixtures exactes, avec check/build synthétiques, rollback, concurrence et liens symboliques.
- 14 contrôles Chromium V114, 9 captures natives : séparation des montages, shells d’inspection, propriété des armes, pureté de sauvegarde, responsive et une traque complète.
- 18 contrôles du codex interactif : 847 fiches, catégories V114, références et affichage mobile.
- 32 contrats unitaires V113 rejoués séparément.

## Monde et montages
- Montage cinéma : 25 espaces actifs dans la matrice, 20 liés au graphe, 3 shells d’inspection (bureau Andrews, chenil, intérieur récupération), morgue provisoire.
- Assembly Cut : 28 espaces actifs, 21 liés au graphe, 5 shells d’inspection (bureau Andrews, abattoir, confinement Golic, approche bovin, intérieur récupération), morgue provisoire.
- Le chien/chenil est absent du registre Assembly ; le bovin est absent du registre cinéma.
- Les shells ne créent aucun node, aucune arête, aucun seuil caché et aucune téléportation.

## Équipement et personnages
Le Pulse Rifle noir est associé exclusivement au `company-guard`. La hache de Dillon reste un prop de Dillon. Les nouveaux visuels d’Andrews, Clemens, Golic, Murphy et du représentant de la Compagnie n’altèrent ni collisions, ni positions, ni vitesse, ni sauvegarde. Les silhouettes sont des interprétations vectorielles : aucune ressemblance photographique 1:1 n’est certifiée.

## Sauvegarde et pureté
Le choix de montage est une couche d’inspection V114 et n’est pas sérialisé dans la sauvegarde V112. Passer cinéma→Assembly et redessiner vingt fois laisse l’export V112 strictement identique. Cela évite une migration artificielle sans propriétaire de campagne natif.

## Parcours navigateur
Une traque héritée a été terminée au clavier et à 60 Hz contrôlés avec la couche V114 active. Aucun placement ou objectif n’a été injecté. Les neuf scènes d’inspection sont préparées et séparées de ce parcours continu.

## Installation
L’installateur ajoute quatre modules V114 et raccorde uniquement le moteur de production à `withAlien3DlcRuntimeV114`. Il vérifie 62 sources V113 par SHA-256 avant toute écriture. Les essais de fixtures ne constituent pas le build natif de Tantalus.

## Limites ouvertes
La morgue doit encore être reconstruite avec un raccord vertical qualifié. Les shells d’inspection doivent devenir de vraies pièces uniquement après conception de leurs accès. Le prologue Sulaco reste hors monde Fiorina. Il reste à qualifier l’ensemble des lieux, équipements, castes et variantes sur une campagne native complète, avec assets définitifs, tests humains, manette physique, Safari/mobile et performances cibles.
