# Alien 3 — Fiorina 161 V114 · Atlas de continuité

Correctif incrémental à appliquer sur une base V113 exacte. La V114 ne prétend pas être une campagne 1:1 achevée : elle transforme l’audit de fidélité en registre exécutable et en scènes d’inspection, tout en gardant visibles les manques.

## Contenu
- `FIORINA_V114_JOUER.html` : aperçu autonome.
- `ALIEN3_CODEX_LEVEL_DESIGN_V114.html` : 847 fiches de conception.
- `RAPPORT_ILLUSTRE_V114.html/.pdf` : captures natives Chromium et limites.
- `RAPPORT_QA_V114.md` : résultats exécutés.
- `docs/PORTEE_V114.md` : périmètre exact.
- `src/*v114.js` : quatre modules V114.
- `scripts/install-v114.mjs` : installation / restauration incrémentale.
- `sources-v113-verified.json` : empreintes attendues des sources V113.

## Installation
Extraire ce correctif hors du projet puis exécuter :

`node scripts/install-v114.mjs /chemin/du/projet`

Pour un contrôle sans écriture :

`node scripts/install-v114.mjs /chemin/du/projet --dry-run`

La restauration utilise le reçu externe renvoyé après installation :

`node scripts/install-v114.mjs --restore /chemin/du/receipt.json`

Aucun push GitHub ni déploiement Vercel n’est réalisé par ce paquet.
