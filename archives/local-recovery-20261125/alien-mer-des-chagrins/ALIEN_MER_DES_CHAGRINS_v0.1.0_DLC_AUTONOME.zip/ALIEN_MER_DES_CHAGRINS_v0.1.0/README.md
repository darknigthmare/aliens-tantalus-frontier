# ALIEN : LA MER DES CHAGRINS
## Les voix sous le sable — v0.1.0

**Première version jouable autonome, non officielle.** Sources du DLC et codex inclus. Ce n’est pas l’archive du jeu principal Tantalus Frontier ; aucun enregistrement natif dans ses menus, push GitHub ou déploiement Vercel n’est compris dans cette livraison.

## Jouer

Décompresser l’archive, puis ouvrir **MER_DES_CHAGRINS_JOUABLE.html** dans un navigateur de bureau récent. Ce fichier contient le jeu, les graphismes vectoriels et les données ; il ne télécharge rien. Sous Windows, `LANCER_WINDOWS.bat` ouvre ce même fichier.

Si le navigateur bloque le stockage d’un fichier local, utiliser le serveur local facultatif : `python tools/server.py`. Il n’écoute que sur 127.0.0.1. Le jeu dispose aussi de boutons Exporter / Importer dans Pause. Garder une exportation avant de déplacer le fichier ou de changer de navigateur.

Le test navigateur de l’environnement de création a dû charger le HTML directement dans le DOM : sa politique bloque les navigations file:// et localhost. Le rendu et les commandes ont été vérifiés, mais l’ouverture native par double-clic et les permissions de stockage de votre navigateur ne sont pas certifiées par ce test.

## Commandes

Flèches, ZQSD ou WASD pour marcher. Haut / bas changent de profondeur dans les salles qui le permettent. E pour interagir. Souris + clic pour tirer ; en profondeur, viser le sol sous les pieds de l’ennemi. R pour recharger. 1 / 2 / 3 sélectionnent pistolet, mousse et lance-flammes lorsqu’ils sont disponibles. Espace maintenu déclenche l’empathie. C réduit le bruit ; Majuscule permet de courir. V fait suivre Manning ou lui demande de tenir une position. Tab ouvre la carte, J les dossiers, Échap la pause, F6 change de présentation.

Le tactile fournit seulement les actions de base. Le parcours complet est conçu pour clavier et souris. La manette n’est pas implémentée.

## Contenu présent

18 chapitres de jeu, 40 salles, 45 liaisons, 33 objectifs, 64 dossiers, 87 obstacles de profondeur, 22 profils d’environnement, 3 équipements offensifs / de capture, 3 difficultés, 2 présentations globales. 38 présences hostiles initiales réparties entre 34 adultes, 2 facehuggers, 1 reine et 1 adulte dédié à la capture ; pas de horde infinie.

Les salles, les dialogues courts et le graphisme sont des créations d’adaptation. L’ambiance et les effets sonores facultatifs sont synthétisés. Les images sont stylisées, pas photoréalistes, et ne reproduisent pas des assets officiels. Les cinématiques sont pour l’instant des scènes de lecture ; les brancards et la plupart des mercenaires ne disposent pas d’une simulation complète.

## Documents

- `docs/CODEX_DLC_MER_DES_CHAGRINS.md` : narration, mécaniques, séparation de continuité, limites.
- `docs/CODEX_LEVEL_DESIGN_40_SALLES.md` : une fiche détaillée par salle, connexions, positions, obstacles et objectifs.
- `docs/SOURCES_CONTINUITE.md` : références publiques et distinction canon / ajout de jeu.
- `reports/RAPPORT_QA.md` et `reports/RAPPORT_ILLUSTRE.html` : contrôles réalisés et captures du prototype.
- `integration/host-descriptor.json` : correspondance documentaire, pas un adaptateur automatique.

## Sources et vérification

Le moteur fonctionne sans dépendance externe. `src/core.js` contient la simulation, `src/render.js` le rendu, `src/main.js` l’interface et `src/data.js` les données embarquées. `data/campaign.json` est leur version éditable. Après modification du JSON, exécuter `python tools/sync_data.py`, puis reconstruire le HTML. Le compilateur du HTML n’effectue pas cette conversion implicitement.

Node 20 ou plus permet `npm run check` sans installer de paquets. Python permet `python tools/build_standalone.py` puis `python tools/generate_docs.py`. Les tests du navigateur nécessitent Playwright et Chromium déjà disponibles : `python qa/browser_check.py --chromium CHEMIN_CHROMIUM`.

Les contrôles de progression parcourent les objectifs et les portes avec des mises en situation automatisées. Ils ne représentent pas une partie humaine intégrale équilibrée sur trois difficultés.

## Copie locale facultative dans un projet

`node integration/install.cjs CHEMIN_DU_PROJET` copie une route indépendante sous `dlc/sea-of-sorrows/`. Le projet cible doit posséder un index.html. Aucune modification de l’index, du catalogue, du moteur, du service worker ou des sauvegardes du jeu principal n’est faite.

`node integration/install.cjs CHEMIN_DU_PROJET --uninstall` enlève cette copie uniquement si ses empreintes correspondent et qu’aucun fichier additionnel n’est présent. Le script refuse de détruire vos changements.

La compatibilité avec les règles de routage, de CSP, de cache et de déploiement de Tantalus reste à valider. L’installation locale n’est pas un déploiement et ne lance aucune commande Git.
