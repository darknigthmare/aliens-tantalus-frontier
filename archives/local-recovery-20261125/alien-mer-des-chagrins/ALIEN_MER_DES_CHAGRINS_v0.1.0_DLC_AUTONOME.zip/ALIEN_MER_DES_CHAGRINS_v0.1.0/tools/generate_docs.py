#!/usr/bin/env python3
"""Document the actual campaign graph; no unverified asset or playtime claims."""
from pathlib import Path
import json,collections
ROOT=Path(__file__).resolve().parents[1];D=json.loads((ROOT/'data/campaign.json').read_text());R={r['id']:r for r in D['rooms']};O={o['id']:o for r in D['rooms'] for o in r['interactables']}
modes={'SIDE':'Bande latérale ; profondeur verrouillée.','DEPTH':'Surface de déplacement en profondeur ; obstacles contournables.','HYBRID':'Volume de transition ; profondeur resserrée.'}
types={'crate':'caisse industrielle','rack':'rayonnage','pipe':'faisceau de conduites','resin':'masse de résine','silica-rubble':'débris de silice','rib':'structure organique côtelée'}
lines=['# Codex de level design — La Mer des Chagrins','## v0.1.0 · 40 salles / 45 liaisons','',
'Ce document est généré à partir des données réellement lues par le moteur. Les dimensions sont des unités de jeu, pas des mesures du roman. Les noms détaillés de salles sont des créations d’adaptation. La carte ne prétend pas reproduire un plan canonique.','',
'## Doctrine et lecture des fiches','',
'Chaque porte porte une paire de liaison. Le retour utilise cette même paire et restaure une position d’arrivée voisine du seuil ; les états de la salle persistent. Les coordonnées `x` sont horizontales, `z` indique la profondeur du sol. Les cadres du HUD restent hors du canvas.','',
'Le mode global CLASSIC ramène toutes les profondeurs à 0,55 et ignore les couvertures déclarées non bloquantes pour cette vue. Les conditions d’objectif ne changent pas. Les cages, escaliers, vols et transferts sont des changements de salle explicites, pas une physique verticale continue.','',
'Les « intentions de décor » reprises du champ `propNotes` constituent une direction de fabrication. Elles ne signifient pas que chaque accessoire nommé possède déjà un sprite dédié. Les tableaux de collision ci-dessous, eux, correspondent à des objets rendus et bloquants dans le prototype.','',
'La sauvegarde de reprise est créée à chaque entrée de salle par le moteur. Le champ historique `checkpoint` des données ne filtre pas ce comportement dans la version 0.1.0.','',
'## Parcours des chapitres','', '| Chapitre du jeu | Objectifs jouables | Note de mise en scène |','|---|---|---|']
for c in D['chapters']:
 lines.append(f"| {c['number']:02d} — {c['title']} | "+' ; '.join(O[o]['label']+' ('+O[o]['room']+')' for o in c['objectives'])+f" | {c['designNote']} |")
lines+=['','## Fiches de salles','']
for r in D['rooms']:
 lines += [f"### {r['id'].upper()} — {r['name']}",'',f"**Secteur : {r['zone']} · Profil : {r['kind']} · Vue hybride : {r['mode']} · Largeur : {r['width']} unités.**",'',r['description'],'',f"**Lecture spatiale.** {modes[r['mode']]} La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.",'',f"**Intentions de décor.** {r['propNotes']}",'','**Liaisons physiques et conditions initiales**','', '| Seuil | Destination | Nature | Position (x ; z) | Condition |','|---|---|---|---|---|']
 for d in r['doors']:
  cond=d.get('gate')or'accès ouvert selon la progression';extra=''
  if d['kind']=='lift':extra=' ; condamné après lift_lost'
  if {r['id'],d['to']}=={'s28','s29'}:extra=' ; fermé après maze_known'
  lines.append(f"| {d['pair']} | {d['to']} — {R[d['to']]['name']} | {d['kind']} | {d['x']} ; {d['z']:.2f} | {cond}{extra} |")
 lines+=['','**Actions et ressources**','']
 if r['interactables']:
  for o in r['interactables']:
   lines.append(f"- `{o['id']}` : **{o['label']}**, à x = {o['x']}, z = {o['z']:.2f}. Déclenche `{o['flag']}` après validation des conditions du type `{o['type']}`. La validation n’est possible que lorsque cette étape est l’objectif courant.")
 else:lines.append('Cette salle assure un trajet, une respiration ou une rencontre ; elle ne déclenche pas de nouvel objectif principal. Sa visite et ses seuils persistent néanmoins.')
 a=r['archive'];lines += ['',f"Relevé facultatif `{a['id']}` : x = {a['x']}, z = {a['z']:.2f}. "+('Un poste de ravitaillement est disponible à x = 320, z = 0,55 ; sa consommation est définitive.' if r['supply'] else 'Aucun ravitaillement automatique dans cette salle.'),'','**Obstacles jouables**','']
 if r['obstacles']:
  lines+=['| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |','|---|---|---|---|']
  for b in r['obstacles']:lines.append(f"| {b['id']} — {types[b['kind']]} | {b['x']} ; {b['z']:.2f} | {b['w']} ; {b['d']:.2f} | {b['h']} |")
 else:lines.append('Pas de barrière de profondeur. La silhouette architecturale et les accessoires de fond ne sont pas des murs invisibles traversant la bande latérale.')
 lines+=['','**Présences et rythme**','']
 if r['enemySpawns']:
  lines.append('Rencontre finie, sans réapparition automatique : '+', '.join(f"{e['kind']} à ({e['x']} ; {e['z']:.2f})" for e in r['enemySpawns'])+'.')
 else:lines.append('Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.')
 if r['id']=='s11':lines+=['','**Retour structurant.** Cette salle est réutilisée après le ravin s36. Le départ final vers la soute s37 attend la balise. Ne pas créer un duplicata de cette aire au retour.']
 if r['id']=='s26':lines+=['','**Perception.** L’objectif demande une pression minimale obtenue par Espace. Le message de direction est un indice de salle, pas une connaissance de toute la ruche.']
 if r['id']=='s33':lines+=['','**Rencontre dédiée.** Trois attaches à (980 ; 0,50), (1510 ; 0,38), (2220 ; 0,59). Le feu les détruit avant que la reine devienne vulnérable. Ces attaches et la règle d’invulnérabilité sont originales au jeu.']
 if r['id']=='s34':lines+=['','**Porteurs.** Deux validations distinctes, sans guérison implicite. Le transport est abstrait par la progression : les brancards ne suivent pas physiquement l’IA dans la version livrée.']
 if r['id']=='s37':lines+=['','**Capture.** Le caisson est à x = 1910. Seuil : immobilisation ≥ 0,95, cible vivante et distance de la cible au caisson ≤ 255 unités, joueur à portée d’interaction. L’allié exclut cet adulte de ses cibles. La mousse et le caisson doivent fonctionner avant l’accès à s38.']
 lines+=['','**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.','']
lines+=['## Registre des 64 dossiers','', '| Identifiant | Titre | Catégorie | Statut de contenu |','|---|---|---|---|']
for c in D['codex']:lines.append(f"| {c['id']} | {c['title']} | {c['category']} | {c.get('classification','adaptation')} |")
(ROOT/'docs/CODEX_LEVEL_DESIGN_40_SALLES.md').write_text('\n'.join(lines)+'\n')
print('Level codex:',len(lines),'lines')
