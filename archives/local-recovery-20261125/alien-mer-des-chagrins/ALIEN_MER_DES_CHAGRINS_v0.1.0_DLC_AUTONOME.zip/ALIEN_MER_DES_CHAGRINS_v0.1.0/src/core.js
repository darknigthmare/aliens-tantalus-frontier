/* Sea of Sorrows — deterministic campaign model, collision, combat and save format.
 * No DOM, no remote dependency. Browser and Node share the exact same simulation. */
(function(root){
'use strict';
const D=typeof module!=='undefined'&&module.exports?require('./data.js'):root.SoSData;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const copy=x=>JSON.parse(JSON.stringify(x));
const R=Object.fromEntries(D.rooms.map(x=>[x.id,x]));
const O=Object.fromEntries(D.rooms.flatMap(r=>r.interactables).map(x=>[x.id,x]));
const objectives=D.chapters.flatMap(c=>c.objectives);
const dist=(a,b)=>Math.hypot(a.x-b.x,(a.z-b.z)*420);
function crossed(a,b,box,pad=0){
 let t0=0,t1=1; const dx=b.x-a.x,dz=b.z-a.z;
 const xmin=box.x-box.w/2-pad,xmax=box.x+box.w/2+pad;
 const zmin=box.z-box.d/2-pad/650,zmax=box.z+box.d/2+pad/650;
 for(const [p,q] of [[-dx,a.x-xmin],[dx,xmax-a.x],[-dz,a.z-zmin],[dz,zmax-a.z]]){
  if(Math.abs(p)<1e-8){if(q<0)return false;continue;}
  const t=q/p;if(p<0)t0=Math.max(t0,t);else t1=Math.min(t1,t);if(t0>t1)return false;
 }return true;
}
class Game{
 constructor(options={}){this.events=[];this.time=0;this.cooldowns={fire:0,interaction:0};this.checkpoint=null;this.newGame(options);}
 newGame({difficulty='survival',presentation='HYBRID'}={}){
  this.state={schema:1,campaign:D.meta.id,version:D.meta.version,difficulty:D.difficulties[difficulty]?difficulty:'survival',presentation:presentation==='CLASSIC'?'CLASSIC':'HYBRID',room:'s01',objectiveIndex:0,flags:{},visited:[],completed:[],archives:['dossier-decker','dossier-icc'],roomStates:{},player:{x:220,z:.55,hp:100,stamina:100,stress:0,filter:100,facing:1,weapon:'pistol',ammo:12,reserve:60,foam:14,fuel:110,crouch:false,noise:0,invulnerable:1.5},companion:{x:100,z:.55,order:'follow',cooldown:0},inventory:{pistol:false,foam:false,flame:false,tracker:false},stats:{time:0,shots:0,kills:0,archives:0,doors:0,empathySeconds:0,damage:0,deaths:0},finished:false,failed:null};
  this.events=[];this.time=0;this.cooldowns={fire:0,interaction:0};this.enter('s01');return this;
 }
 get room(){return R[this.state.room];}
 get current(){return O[objectives[this.state.objectiveIndex]]||null;}
 get chapter(){return this.current?D.chapters[this.current.chapter-1]:D.chapters[17];}
 get p(){return this.state.player;}
 get rs(){return this.state.roomStates[this.state.room];}
 get mode(){return this.state.presentation==='CLASSIC'?'SIDE':this.room.mode;}
 zFor(p){return this.mode==='SIDE'?.55:p.z;}
 distance(a,b){return Math.hypot(a.x-b.x,(this.zFor(a)-this.zFor(b))*420);}
 limits(){return this.mode==='SIDE'?[.55,.55]:this.mode==='HYBRID'?[.15,.85]:[.13,.89];}
 boxes(){return this.room.obstacles.filter(b=>this.mode!=='SIDE'||b.blocksClassic);}
 emit(type,text,extra={}){this.events.push({type,text,...extra});}
 drainEvents(){return this.events.splice(0);}
 enter(id,via=null){
  if(!R[id])throw Error('Unknown room: '+id);
  this.state.room=id;
  if(!this.state.visited.includes(id))this.state.visited.push(id);
  const dest=via?R[id].doors.find(d=>d.pair===via):null;
  const start=dest?dest.x<220?dest.x+92:dest.x>R[id].width-220?dest.x-92:dest.x+80:180;
  this.p.x=clamp(start,50,R[id].width-50);this.p.z=this.mode==='SIDE'?.55:(dest?.z??.55);this.p.invulnerable=1.6;this.p.noise=0;
  this.state.companion.x=Math.max(45,this.p.x-70);this.state.companion.z=this.p.z;this.state.companion.cooldown=.5;
  if(!this.state.roomStates[id]){
   this.state.roomStates[id]={supplyUsed:false,corpses:[],acid:[],weakpoints:id==='s33'?[{x:980,z:.50,hp:24},{x:1510,z:.38,hp:24},{x:2220,z:.59,hp:24}]:[],enemies:R[id].enemySpawns.map(e=>({...e,hp:e.kind==='queen'?340:e.kind==='facehugger'?22:68,homeX:e.x,homeZ:e.z,mode:'patrol',memory:0,cooldown:.6,foam:0,path:[],pathTime:0,patrol:1,alert:0}))};
  }
  this.ensureSafePosition(this.p);this.cooldowns.interaction=.7;
  if(id==='s33'&&!this.state.flags.queen_down){this.state.inventory.flame=true;this.p.fuel=Math.max(this.p.fuel,110);this.p.weapon='flame';}
  if(id==='s37'&&!this.state.flags.live_capture){this.state.inventory.foam=true;this.p.foam=Math.max(this.p.foam,14);this.p.weapon='foam';}
  if(this.mode==='SIDE')for(const e of this.rs.enemies)e.z=.55;
  this.checkpoint=copy(this.state);this.emit('room',R[id].name);return true;
 }
 ensureSafePosition(actor){
  const [lo,hi]=this.limits();actor.z=clamp(actor.z,lo,hi);actor.x=clamp(actor.x,35,this.room.width-35);
  if(this.blocked(actor.x,actor.z)){actor.z=.55;}
 }
 blocked(x,z,padding=16){
  const [lo,hi]=this.limits();if(x<30||x>this.room.width-30||z<lo-.001||z>hi+.001)return true;
  return this.boxes().some(b=>Math.abs(x-b.x)<b.w/2+padding&&Math.abs(z-b.z)<b.d/2+.028);
 }
 move(actor,dx,dz){
  if(this.mode==='SIDE')dz=0;
  const oldX=actor.x,oldZ=actor.z;
  if(!this.blocked(actor.x+dx,actor.z))actor.x+=dx;
  if(!this.blocked(actor.x,actor.z+dz))actor.z+=dz;
  if(this.mode==='SIDE')actor.z=.55;
  return Math.hypot(actor.x-oldX,(actor.z-oldZ)*420);
 }
 visible(a,b){
  if(this.mode==='SIDE')return !this.boxes().some(box=>crossed({x:a.x,z:.55},{x:b.x,z:.55},box));
  return !this.boxes().some(box=>crossed(a,b,box));
 }
 // Grid A*: the same colliders gate humans, xenomorphs and aiming.
 pathTo(from,to){
  if(this.mode==='SIDE'||this.visible(from,to))return [{x:to.x,z:this.zFor(to)}];
  const [lo,hi]=this.limits(),W=Math.ceil(this.room.width/70),H=9;
  const cell=p=>[clamp(Math.floor(p.x/70),0,W-1),clamp(Math.round((p.z-lo)/(hi-lo)*(H-1)),0,H-1)];
  const point=(x,y)=>({x:clamp(x*70+35,36,this.room.width-36),z:lo+(hi-lo)*y/(H-1)});
  const s=cell(from),end=cell(to),key=(x,y)=>x+','+y;
  let open=[{x:s[0],y:s[1],g:0,f:0}],came=new Map(),cost=new Map([[key(...s),0]]),closed=new Set();
  let found=null;
  for(let n=0;open.length&&n<850;n++){
   open.sort((a,b)=>a.f-b.f);const q=open.shift(),k=key(q.x,q.y);if(closed.has(k))continue;closed.add(k);
   if(q.x===end[0]&&q.y===end[1]){found=k;break;}
   for(const [dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){
    const x=q.x+dx,y=q.y+dy;if(x<0||x>=W||y<0||y>=H)continue;
    const p=point(x,y);if(this.blocked(p.x,p.z,19))continue;
    const nk=key(x,y),g=q.g+1;if(g>=(cost.get(nk)??Infinity))continue;
    cost.set(nk,g);came.set(nk,k);open.push({x,y,g,f:g+Math.abs(x-end[0])+Math.abs(y-end[1])});
   }
  }
  if(!found)return [{x:from.x,z:.55},{x:to.x,z:.55},{x:to.x,z:this.zFor(to)}];
  const out=[];for(let k=found;k&&k!==key(...s);k=came.get(k)){const [x,y]=k.split(',').map(Number);out.push(point(x,y));}return out.reverse();
 }
 doorStatus(door){
  if(door.gate&&!this.state.flags[door.gate])return {open:false,reason:'Accès en attente — '+this.requirementText(door.gate)};
  if(this.state.flags.lift_lost&&door.kind==='lift')return {open:false,reason:'Le puits principal est condamné.'};
  if(this.state.flags.maze_known&&((this.state.room==='s28'&&door.to==='s29')||(this.state.room==='s29'&&door.to==='s28')))return {open:false,reason:'La membrane a fermé ce passage. Prenez la dérivation.'};
  return {open:true,reason:''};
 }
 requirementText(flag){return ({accident:'terminer le relevé',report_sent:'transmettre le rapport',earth_done:'régler les démarches à terre',contract:'rencontrer Rollins',equipped:'prendre l’équipement',filters_ready:'contrôler les filtres',lift_ready:'activer la cage',power_on:'rétablir la desserte',tracker_ready:'reprendre le détecteur',survey_complete:'terminer le relevé',maze_known:'retrouver la dérivation',lift_lost:'examiner les commandes',stairs_known:'repérer l’itinéraire',brood_seen:'étudier le passage',queen_down:'dégager la chambre',hosts_secured:'préparer les deux brancards',winch_ready:'mettre le treuil en marche',route_open:'ouvrir le passage',beacon_lit:'allumer la balise',live_capture:'capturer le spécimen vivant',specimens_delivered:'transférer la cargaison',strike_seen:'observer la surface'})[flag]||'poursuivre la mission';}
 nearby(){
  const candidates=[];const o=this.current;
  if(o?.room===this.state.room)candidates.push({...o,action:'objective',priority:0});
  for(const door of this.room.doors)candidates.push({...door,action:'door',priority:2});
  const arc=this.room.archive;if(!this.state.archives.includes(arc.id))candidates.push({...arc,action:'archive',label:'Consulter le relevé',priority:1});
  if(this.room.supply)candidates.push({id:'supply',x:320,z:.55,action:'supply',label:this.rs.supplyUsed?'Réserve vide':'Prendre les réserves',priority:3});
  return candidates.filter(x=>this.distance(x,this.p)<96).sort((a,b)=>(a.priority-b.priority)||(this.distance(a,this.p)-this.distance(b,this.p)))[0]||null;
 }
 interact(){
  if(this.state.failed||this.state.finished||this.cooldowns.interaction>0)return false;
  const n=this.nearby();if(!n)return false;this.cooldowns.interaction=.30;
  if(n.action==='objective')return this.completeObjective();
  if(n.action==='door'){
   const st=this.doorStatus(n);if(!st.open){this.emit('toast',st.reason);return false;}
   this.state.stats.doors++;if(['flight','travel','tram','story','lift','stairs','climb'].includes(n.kind))this.emit('transition',n.label,{kind:n.kind});
   this.enter(n.to,n.pair);return true;
  }
  if(n.action==='archive'){
   this.state.archives.push(n.id);this.state.stats.archives++;this.emit('archive',D.codex.find(x=>x.id===n.id).title,{id:n.id});return true;
  }
  if(n.action==='supply'){
   if(this.rs.supplyUsed){this.emit('toast','Le poste a déjà été vidé.');return false;}
   this.rs.supplyUsed=true;const mult=D.difficulties[this.state.difficulty].supply;
   this.p.hp=Math.min(100,this.p.hp+45);this.p.filter=100;this.p.reserve+=Math.round(30*mult);this.p.foam+=Math.round(8*mult);this.p.fuel+=Math.round(55*mult);
   this.emit('toast','Réserves récupérées. Filtre remplacé.');return true;
  }return false;
 }
 completeObjective(){
  const o=this.current;if(!o||o.room!==this.state.room||this.distance(this.p,o)>96)return false;
  if(o.type==='sense'&&this.p.stress<7){this.emit('toast','Maintenez Espace pour vous concentrer.');return false;}
  if(o.type==='boss'&&!this.rs.enemies.some(e=>e.kind==='queen'&&e.hp<=0)){this.emit('toast','Brûlez les trois attaches. Manning pourra ouvrir le feu.');return false;}
  if(o.type==='capture'){
   const e=this.rs.enemies.find(e=>e.kind==='captureAdult');
   if(!e||e.hp<=0){this.fail('Le spécimen n’a pas survécu. Reprenez la capture.');return false;}
   if(e.foam<.95||this.distance(e,o)>255){this.emit('toast','Attirez l’adulte près du caisson, puis immobilisez-le avec la mousse.');return false;}
   e.mode='captured';e.foam=1.2;
  }
  this.state.flags[o.flag]=true;this.state.completed.push(o.id);this.state.objectiveIndex++;
  if(o.flag==='equipped'){this.state.inventory.pistol=true;this.p.weapon='pistol';}
  if(o.flag==='filters_ready')this.p.filter=100;
  if(o.flag==='tracker_ready')this.state.inventory.tracker=true;
  if(o.flag==='finished'){this.state.finished=true;}
  this.unlockDossiers();this.emit('story',o.reply,{title:this.chapter.title,completed:o.label,finished:this.state.finished});return true;
 }
 unlockDossiers(){
  const c=this.chapter.number,stages={4:['rollins','lineage','company'],5:['manning','rand','filter','lamp','pistol'],6:['cho','map'],8:['silas','detector'],9:['adult','empathy','memory'],12:['parasite'],13:['queen','flame'],14:['adams','elway'],16:['foam'],18:['survivors']};
  for(const [n,ids]of Object.entries(stages))if(c>=+n)for(const id of ids){const k='dossier-'+id;if(!this.state.archives.includes(k))this.state.archives.push(k);}
 }
 setPresentation(mode){
  this.state.presentation=mode==='CLASSIC'?'CLASSIC':'HYBRID';this.ensureSafePosition(this.p);this.ensureSafePosition(this.state.companion);
  for(const e of this.rs.enemies){if(this.mode==='SIDE')e.z=.55;this.ensureSafePosition(e);e.path=[];}
  this.emit('toast',mode==='CLASSIC'?'Vue latérale':'Vue hybride');
 }
 setWeapon(weapon){if(this.state.inventory[weapon]){this.p.weapon=weapon;this.emit('weapon',weapon);return true;}this.emit('toast','Cet équipement n’est pas disponible.');return false;}
 reload(){
  if(!this.state.inventory.pistol||this.p.ammo>=12||this.p.reserve<=0)return false;
  const q=Math.min(12-this.p.ammo,this.p.reserve);this.p.ammo+=q;this.p.reserve-=q;this.cooldowns.fire=1.1;this.emit('sound','reload');return true;
 }
 shoot(target){
  if(this.cooldowns.fire>0||this.state.failed||!this.state.inventory[this.p.weapon])return false;
  const p=this.p,kind=p.weapon;if(kind==='pistol'&&p.ammo<1){this.emit('toast','Rechargez votre arme.');this.cooldowns.fire=.4;return false;}
  if((kind==='foam'&&p.foam<1)||(kind==='flame'&&p.fuel<2)){this.emit('toast','Réserve épuisée.');this.cooldowns.fire=.4;return false;}
  const aim={x:target.x,z:this.mode==='SIDE'?.55:target.z};p.facing=aim.x>=p.x?1:-1;
  const len=this.distance(p,aim),range=kind==='flame'?390:kind==='foam'?790:1100;
  const ratio=len?Math.min(1,range/len):1;
  const end={x:p.x+(aim.x-p.x)*ratio,z:this.zFor(p)+(this.zFor(aim)-this.zFor(p))*ratio};
  p.noise=kind==='foam'?45:kind==='flame'?55:100;this.state.stats.shots++;
  if(kind==='pistol')p.ammo--;if(kind==='foam')p.foam--;if(kind==='flame')p.fuel-=2;
  this.cooldowns.fire=kind==='flame'?.13:kind==='foam'?.35:.27;
  this.emit('shot','',{from:{x:p.x,z:p.z},to:end,weapon:kind});
  const lineDistance=e=>{const A={x:p.x,y:this.zFor(p)*420},B={x:end.x,y:end.z*420},P={x:e.x,y:this.zFor(e)*420};const vx=B.x-A.x,vy=B.y-A.y,t=clamp(((P.x-A.x)*vx+(P.y-A.y)*vy)/(vx*vx+vy*vy||1),0,1);return Math.hypot(P.x-(A.x+t*vx),P.y-(A.y+t*vy));};
  if(kind==='flame')for(const w of this.rs.weakpoints)if(w.hp>0&&this.distance(p,w)<390&&lineDistance(w)<65&&this.visible(p,w)){w.hp=Math.max(0,w.hp-14);this.emit('spark','',{x:w.x,z:w.z});}
  const targets=this.rs.enemies.filter(e=>e.hp>0&&e.mode!=='captured'&&this.distance(p,e)<=range&&lineDistance(e)<(e.kind==='queen'?88:e.kind==='facehugger'?32:42)&&this.visible(p,e)).sort((a,b)=>this.distance(p,a)-this.distance(p,b));
  if(targets.length){const e=targets[0];e.memory=9;e.mode='hunt';
   if(kind==='foam'){e.foam=clamp(e.foam+.38,0,1.2);if(e.foam>=.95)e.mode='stunned';}
   else {const shield=e.kind==='queen'&&this.rs.weakpoints.some(w=>w.hp>0);this.hurtEnemy(e,shield?0:kind==='flame'?17:24);}
  }return true;
 }
 hurtEnemy(e,damage){
  if(e.hp<=0||e.mode==='captured')return;e.hp=Math.max(0,e.hp-damage);if(damage>0)this.emit('hit','',{x:e.x,z:e.z});
  if(e.hp<=0){e.mode='dead';this.state.stats.kills++;this.rs.corpses.push({x:e.x,z:e.z,kind:e.kind});this.rs.acid.push({x:e.x,z:e.z,time:7});
   if(e.kind==='captureAdult')this.fail('Le spécimen est mort. La compagnie exige une capture vivante.');
   if(e.kind==='queen')this.emit('toast','La voie est libre. Rassemblez le groupe.');
  }
 }
 damage(amount){
  if(this.p.invulnerable>0||this.state.failed)return;
  amount*=D.difficulties[this.state.difficulty].damage;this.p.hp=Math.max(0,this.p.hp-amount);this.state.stats.damage+=amount;this.p.invulnerable=.65;this.emit('damage','');if(this.p.hp<=0)this.fail('Vous n’avez pas atteint l’abri.');
 }
 fail(message){if(this.state.failed)return;this.state.failed=message;this.state.stats.deaths++;this.emit('failed',message);}
 retry(){
  const deaths=this.state.stats.deaths;this.state=copy(this.checkpoint);this.state.failed=null;this.state.stats.deaths=deaths;this.p.hp=Math.max(70,this.p.hp);this.p.invulnerable=2.5;this.events=[];this.emit('room',this.room.name);
 }
 step(dt,input={}){
  dt=clamp(Number.isFinite(dt)?dt:0,0,.05);if(!dt||this.state.failed||this.state.finished)return;
  this.time+=dt;this.state.stats.time+=dt;this.cooldowns.fire=Math.max(0,this.cooldowns.fire-dt);this.cooldowns.interaction=Math.max(0,this.cooldowns.interaction-dt);
  const p=this.p;p.invulnerable=Math.max(0,p.invulnerable-dt);p.crouch=!!input.crouch;
  let dx=(input.right?1:0)-(input.left?1:0),dz=(input.down?1:0)-(input.up?1:0);
  const moving=dx||dz,run=!!input.run&&p.stamina>3&&!p.crouch;
  const speed=p.crouch?110:run?310:205;
  if(dx&&dz){dx*=.7071;dz*=.7071;}
  this.move(p,dx*speed*dt,dz*speed*dt/470);if(dx)p.facing=dx>0?1:-1;
  p.stamina=clamp(p.stamina+(run&&moving?-21:14)*dt,0,100);
  p.noise=clamp(p.noise-55*dt,0,100);if(moving)p.noise=Math.max(p.noise,p.crouch?6:run?58:20);
  if(input.focus){p.stress=clamp(p.stress+20*dt,0,100);this.state.stats.empathySeconds+=dt;}else p.stress=Math.max(0,p.stress-8*dt);
  if(this.room.kind==='sand'&&this.state.flags.equipped){p.filter=Math.max(0,p.filter-1.1*dt);if(p.filter<=0)this.damage(3);}
  for(const a of this.rs.acid){a.time-=dt;if(a.time>0&&this.distance(a,p)<38)this.damage(8);}
  this.rs.acid=this.rs.acid.filter(a=>a.time>0);
  for(const e of this.rs.enemies){
   if(e.hp<=0||e.mode==='captured')continue;
   e.cooldown=Math.max(0,e.cooldown-dt);e.foam=Math.max(0,e.foam-.013*dt);
   if(e.foam>=.95){e.mode='stunned';continue;}
   const d=this.distance(e,p),los=this.visible(e,p);
   const sense=d<((p.crouch?200:380))&&los||d<p.noise*7||input.focus&&p.stress>45&&d<1000;
   if(sense){e.mode='hunt';e.memory=7;e.alert=Math.min(1,e.alert+dt*2);}else e.memory=Math.max(0,e.memory-dt);
   if(e.memory<=0)e.mode='patrol';
   if(e.kind==='queen'){
    if(d<190&&e.cooldown<=0){this.damage(28);e.cooldown=1.5;}continue;
   }
   let dest=e.mode==='hunt'?p:{x:e.homeX+e.patrol*160,z:e.homeZ};
   if(e.mode==='patrol'&&this.distance(e,dest)<40)e.patrol*=-1;
   e.pathTime-=dt;if(e.pathTime<=0||!e.path.length){e.path=this.pathTo(e,dest);e.pathTime=.55;}
   let point=e.path[0]||dest;if(this.distance(e,point)<30){e.path.shift();point=e.path[0]||dest;}
   const ex=point.x-e.x,ez=(this.zFor(point)-this.zFor(e))*470,norm=Math.hypot(ex,ez)||1;
   const v=(e.kind==='facehugger'?190:e.mode==='hunt'?155:58)*(1-e.foam*.8);
   this.move(e,ex/norm*v*dt,ez/norm*v*dt/470);
   if(d<(e.kind==='facehugger'?42:60)&&los&&e.cooldown<=0){this.damage(e.kind==='facehugger'?13:18);e.cooldown=e.kind==='facehugger'?.9:1.2;this.emit('attack','',{x:e.x,z:e.z});}
  }
  const ally=this.state.companion;ally.cooldown=Math.max(0,ally.cooldown-dt);
  if(this.state.flags.equipped&&this.chapter.number<17){
   if(ally.order==='follow'){
    const target={x:clamp(p.x-p.facing*100,40,this.room.width-40),z:this.zFor(p)};
    const pts=this.pathTo(ally,target),t=pts[0]||target,dx=t.x-ally.x,dz=(this.zFor(t)-this.zFor(ally))*470,n=Math.hypot(dx,dz)||1;
    if(n>35)this.move(ally,dx/n*220*dt,dz/n*220*dt/470);
   }
   if(ally.cooldown<=0){
    const t=this.rs.enemies.find(e=>e.hp>0&&e.kind!=='captureAdult'&&this.distance(e,ally)<950&&this.visible(ally,e)&&Math.abs(this.zFor(e)-this.zFor(ally))<.24);
    if(t&&!(t.kind==='queen'&&this.rs.weakpoints.some(w=>w.hp>0))){this.hurtEnemy(t,14);ally.cooldown=.65;this.emit('shot','',{from:{x:ally.x,z:ally.z},to:{x:t.x,z:t.z},weapon:'ally'});}
   }
  }
  if(input.fire&&input.target)this.shoot(input.target);
 }
 empathyHint(){
  if(this.p.stress<3)return null;
  const foes=this.rs.enemies.filter(e=>e.hp>0&&e.mode!=='captured').sort((a,b)=>this.distance(a,this.p)-this.distance(b,this.p));
  const e=foes[0];if(!e)return {direction:0,text:'Un silence trop dense. Rien de précis.'};
  const dir=e.x>=this.p.x?1:-1;return {direction:dir,text:this.p.stress>75?'Elle vous reconnaît. Coupez le lien.':this.distance(e,this.p)<400?'Une présence proche. Elle vous cherche.':'Une hostilité lointaine, dans cette direction.'};
 }
 exportSave(){return JSON.stringify({format:'sos-save',schema:1,state:this.state,checkpoint:this.checkpoint});}
 importSave(raw){
  let data;try{if(typeof raw!=='string'||raw.length>2000000)throw Error();data=JSON.parse(raw);}catch(e){throw Error('Sauvegarde illisible.');}
  if(data.format!=='sos-save'||data.schema!==1||!data.state||data.state.campaign!==D.meta.id)throw Error('Sauvegarde incompatible.');
  const validate=s=>{
   if(!s||s.campaign!==D.meta.id||s.schema!==1||!R[s.room]||!D.difficulties[s.difficulty]||!['CLASSIC','HYBRID'].includes(s.presentation))return false;
   if(!Number.isInteger(s.objectiveIndex)||s.objectiveIndex<0||s.objectiveIndex>objectives.length)return false;
   if(!s.player||!['x','z','hp','ammo','reserve','foam','fuel','stamina','stress','filter'].every(k=>Number.isFinite(s.player[k])))return false;
   if(s.player.hp<0||s.player.hp>100||s.player.x<0||s.player.x>R[s.room].width||s.player.z<0||s.player.z>1)return false;
   if(!s.flags||Array.isArray(s.flags)||typeof s.flags!=='object'||!s.inventory||!s.stats||!s.companion)return false;
   const finite=(o,ks)=>o&&ks.every(k=>Number.isFinite(o[k]));
   const flags=new Set(Object.values(O).map(o=>o.flag));
   if(Object.entries(s.flags).some(([k,v])=>!flags.has(k)||typeof v!=='boolean'))return false;
   if(!['pistol','foam','flame'].includes(s.player.weapon)||!finite(s.player,['invulnerable','facing','noise']))return false;
   if(['ammo','reserve','foam','fuel','stamina','stress','filter','invulnerable'].some(k=>s.player[k]<0))return false;
   if(['stamina','stress','filter'].some(k=>s.player[k]>100)||s.player.ammo>12)return false;
   if(!['pistol','foam','flame','tracker'].every(k=>typeof s.inventory[k]==='boolean'))return false;
   if(!finite(s.stats,['time','shots','kills','archives','doors','empathySeconds','damage','deaths'])||Object.values(s.stats).some(v=>typeof v!=='number'||v<0))return false;
   if(!finite(s.companion,['x','z','cooldown'])||!['hold','follow'].includes(s.companion.order))return false;
   if(typeof s.finished!=='boolean'||s.finished!==(s.objectiveIndex===objectives.length)||!(s.failed===null||typeof s.failed==='string'))return false;
   if(!Array.isArray(s.completed)||s.completed.length!==s.objectiveIndex||s.completed.some((id,i)=>id!==objectives[i]))return false;
   if(s.completed.some(id=>!s.flags[O[id].flag]))return false;
   if(!Array.isArray(s.archives)||s.archives.some(id=>!D.codex.some(c=>c.id===id))||!Array.isArray(s.visited)||s.visited.some(id=>!R[id]))return false;
   if(new Set(s.archives).size!==s.archives.length||new Set(s.visited).size!==s.visited.length||s.archives.length>D.codex.length||s.visited.length>D.rooms.length)return false;
   if(!s.roomStates||!s.roomStates[s.room])return false;
   for(const [id,rs]of Object.entries(s.roomStates)){
    if(!R[id]||!Array.isArray(rs.enemies)||!Array.isArray(rs.acid)||!Array.isArray(rs.corpses)||!Array.isArray(rs.weakpoints))return false;
    if(rs.enemies.length!==R[id].enemySpawns.length)return false;
    if(rs.enemies.some((e,i)=>!e||e.id!==R[id].enemySpawns[i].id||e.kind!==R[id].enemySpawns[i].kind||!finite(e,['x','z','hp','foam','cooldown','memory','homeX','homeZ','pathTime','patrol','alert'])||e.hp<0||e.hp>(e.kind==='queen'?340:e.kind==='facehugger'?22:68)||e.x<0||e.x>R[id].width||e.z<0||e.z>1||!['patrol','hunt','stunned','captured','dead'].includes(e.mode)||!Array.isArray(e.path)||e.path.length>850||e.path.some(t=>!finite(t,['x','z']))))return false;
    if(rs.weakpoints.length>(id==='s33'?3:0)||rs.weakpoints.some(w=>!finite(w,['x','z','hp'])||w.hp<0||w.hp>24))return false;
    if(rs.acid.length>rs.enemies.length||rs.corpses.length>rs.enemies.length||rs.acid.some(a=>!finite(a,['x','z','time']))||rs.corpses.some(a=>!finite(a,['x','z'])))return false;
   }return true;
  };
  if(!validate(data.state)||!validate(data.checkpoint))throw Error('La sauvegarde contient un état invalide.');
  this.state=copy(data.state);this.checkpoint=copy(data.checkpoint);this.ensureSafePosition(this.p);this.events=[];this.time=this.state.stats.time;this.cooldowns={fire:.2,interaction:.4};this.emit('room',this.room.name);return true;
 }
}
const API={Game,DATA:D,ROOMS:R,OBJECTIVES:O,objectiveOrder:objectives,clamp,crossed};
if(typeof module!=='undefined'&&module.exports)module.exports=API;root.SoSCore=API;
})(typeof globalThis!=='undefined'?globalThis:this);
