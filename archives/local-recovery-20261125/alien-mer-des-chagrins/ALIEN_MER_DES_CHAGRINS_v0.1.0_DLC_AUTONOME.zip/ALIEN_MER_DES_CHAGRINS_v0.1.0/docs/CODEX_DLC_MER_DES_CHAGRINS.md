# ALIEN : LA MER DES CHAGRINS
## Les voix sous le sable — Codex de campagne, v0.1.0

**Statut : première version jouable autonome.** Ce dossier décrit le contenu de cette archive, pas un DLC déjà intégré dans le moteur de Tantalus Frontier. Les chiffres de contenu sont issus de `data/campaign.json`. Les contrôles réalisés et leurs limites se trouvent dans `RAPPORT_QA.md`.

## 1. Intention

Il ne faut pas transformer Decker en un commando envoyé nettoyer une mine. L’entrée en matière est civile : inspection, constat, rapport et pression de la compagnie. L’équipement arrive ensuite. La descente doit faire sentir que les voies d’accès humaines se terminent à l’intérieur de structures qui n’ont pas été construites pour elles.

La proposition de jeu repose sur trois tensions originales d’adaptation. Entendre la présence évite l’aveuglement mais augmente l’exposition. Tuer peut assurer la sécurité immédiate mais contredit l’ordre final de capture. Une issue connue peut être condamnée, à condition que le joueur dispose d’un autre chemin réel et lisible.

Le jeu livré contient 18 chapitres, 33 objectifs séquentiels et 40 salles reliées par 45 liaisons. Il conserve une présentation latérale globale et une présentation hybride qui choisit le mouvement approprié à la salle. Ce n’est pas une campagne de 40 arènes interchangeables ni un simple catalogue de fiches : portes, conditions d’accès, captures, armes et sauvegardes sont exécutées par le moteur fourni. Cela reste un prototype : plusieurs salles partagent une famille graphique et les séquences narratives passent par des fenêtres de texte.

## 2. Trame et degrés de fidélité

La référence est le roman de James A. Moore, selon les limites documentées dans `SOURCES_CONTINUITE.md`. On conserve le cadre, Decker, l’expédition contrainte et l’enjeu de récupération. On ne prétend pas restituer mot pour mot les échanges, reproduire tous les figurants ou montrer chaque décès exactement comme dans l’œuvre.

Les textes joués sont nouveaux. Par exemple, l’instruction de concentration n’explique pas au joueur des variables de programmation ; elle lui demande d’écouter ce qui approche. L’instruction de capture indique un geste à accomplir dans la soute. Le vocabulaire technique n’apparaît que dans ces documents de production et dans le format de données.

La rencontre avec la reine est une adaptation fonctionnelle : trois attaches destructibles doivent être brûlées, puis les tirs deviennent efficaces. La division en trois attaches et la vulnérabilité conditionnelle sont des règles de jeu originales, pas des faits revendiqués du livre. De même, le joueur manie la mousse lors de la capture, alors que la source attribue le geste à Manning. La fin ne transforme pas les deux porteurs en personnes guéries par une simple interaction.

## 3. Déroulement spatial

L’inspection se déroule au bord de la zone toxique, près d’un carottier. Le transfert sanitaire, les démarches sur Terre et l’entretien imposé sont des changements de lieu explicitement identifiés. Ils ne sont pas représentés comme trois portes adjacentes dans le même couloir.

Le retour sur New Galveston établit une aire d’atterrissage, un abri, une décontamination et une tête de puits. La mine comprend une recette inférieure, un relais, un atelier et une desserte électrique. La transition suivante traverse une carène enfouie, une brèche, une tranchée de fouille et des vestiges. Les tubes puis la zone de ponte se trouvent au-delà de ce réseau.

La remontée n’introduit pas une seconde aire d’atterrissage sous un autre nom : le graphe rejoint `s11`, déjà visitée à l’arrivée. Ce retour est l’un des tests structurants. Les cages condamnées restent condamnées. La membrane ne doit jamais exiger de traverser une collision invisible : une dérivation repérée permet de revenir vers la suite.

Les étages sont des transitions de salles par cages ou escaliers. Le prototype ne simule pas des étages superposés simultanément ni une physique de saut. La coupe et les paliers représentés sont une traduction spatiale simplifiée.

## 4. Présentation et collision

Le mode HYBRID global utilise 11 salles SIDE, 16 salles DEPTH et 13 salles HYBRID. SIDE impose une seule bande ; DEPTH offre une plage de profondeur plus large ; HYBRID resserre légèrement cette plage. Le mode CLASSIC ramène toute la campagne à une bande latérale et n’applique pas les obstacles de profondeur déclarés non bloquants pour cette présentation.

Un point de monde possède une abscisse `x` et une profondeur normalisée `z`. Une unité n’équivaut pas à un mètre canonique. Les couverts occupent une surface ; changer de bande dans leur volume est interdit. Le tir teste sa trajectoire et les obstacles. Deux silhouettes superposées à l’écran ne suffisent pas pour garantir une touche.

Les personnages, les ennemis, les objets et les couverts sont triés par profondeur. Un couvert au premier plan peut devenir partiellement transparent lorsqu’il masque le joueur, sans perdre sa collision. Les bandes de déplacement ne sont pas affichées comme un quadrillage de débogage.

La caméra se déplace horizontalement. Les fonds lointains, les volumes intermédiaires et les éléments proches utilisent des décalages distincts. Le décor commence au sommet du canvas, immédiatement sous le bandeau d’état. Le HUD principal et l’objectif sont à l’extérieur du champ de jeu.

Le mode SETPIECE des autres documents du projet n’a pas été implémenté ici : la navette et le combat final utilisent les systèmes de profondeur et leurs objectifs propres, sans quatrième contrôleur de caméra.

## 5. Empathie

Maintenir Espace augmente la pression de 20 unités par seconde, jusqu’à 100. Relâcher permet une récupération de 8 unités par seconde. La perception donne une orientation grossière et un message de proximité dans la salle courante ; elle n’affiche pas une carte de toutes les créatures ni des coordonnées à travers les niveaux.

Au-dessus de 45 de pression, maintenir le lien peut alerter les ennemis à moins de 1 000 unités. Le message devient plus menaçant à haute pression. Le système n’accorde ni possession, ni ordre télépathique, ni sort offensif. Son objectif pédagogique exige un bref usage réel de la concentration.

Cette version utilise un indice déterministe. Elle ne contient pas encore de faux souvenirs jouables, de visions alternatives, de réponses vocales adaptatives ou de lecture psychologique complexe de chaque mercenaire.

## 6. Combat et ressources

Le pistolet dispose d’un chargeur de 12 coups. Recharger transfère les munitions disponibles et impose un délai de tir. Le lance-flammes a une portée plus courte et brûle les attaches de la chambre. La mousse consomme des charges distinctes et accumule un degré d’immobilisation sans infliger de dégâts.

Les trois armes n’emploient pas le même effet visuel. Les tirs respectent les couverts et la profondeur. Les adultes morts laissent un corps et une zone acide temporaire. Revenir dans la salle ne les fait pas réapparaître. Il n’existe pas de générateur infini de vagues dans cette livraison.

Les huit postes de ravitaillement se vident une fois. Ils restaurent une partie de la santé, remplacent le filtre et donnent des réserves. Le filtre ne baisse dans le périmètre extérieur contaminé qu’après l’équipement. La difficulté modifie les dégâts reçus et les ressources distribuées, pas la topologie des objectifs.

Exploration applique 45 % des dégâts de référence et 140 % des ravitaillements. Survie utilise les valeurs de référence. Oppression applique 135 % des dégâts et 80 % des ravitaillements. Ces réglages ont des tests fonctionnels ; leur agrément et leur durée n’ont pas fait l’objet d’une campagne de playtest humain.

## 7. Manning et les autres personnages

Manning est l’unique compagnon tactique simulé. Il peut suivre ou tenir une position. Il contourne les obstacles et tire lorsqu’une cible remplit les conditions de visibilité, de distance et de profondeur. Il ne tire pas sur l’adulte réservé à la capture. Il ne tire pas sur la reine avant la destruction des attaches.

Les autres personnes interviennent par leurs fonctions narratives, quelques silhouettes de situation et des dossiers. La présence d’un nom dans le codex ne signifie pas qu’il possède déjà un acteur complet avec tous ses dialogues, comportements et animations. Le roster exhaustif de l’expédition et ses morts individuelles ne sont pas simulés.

Decker ne contrôle pas à distance tous les mercenaires. Les deux porteurs de la phase d’évacuation correspondent à des interactions de brancards conservant leur état ; ils ne sont pas une IA d’escorte transportant physiquement chaque brancard à travers toutes les salles. C’est une simplification explicitement inscrite dans cette version.

## 8. Capture finale

L’adulte entre par un point défini de la soute. Le joueur doit le garder vivant, l’amener à proximité du caisson et appliquer assez de mousse. Trois impacts directs rapprochés suffisent à atteindre le seuil initial, mais l’immobilisation décroît lentement.

Le caisson refuse la capture si la cible est trop loin, insuffisamment immobilisée ou morte. En cas de mort, l’expédition échoue à ce point et la reprise restaure la salle. Une fois capturé, l’adulte sort de la simulation hostile et le caisson est marqué verrouillé. La phase de quarantaine ne peut être atteinte avant la capture.

Le test de navigateur prépare les positions d’un scénario de capture, effectue les tirs du moteur et active ensuite le caisson au clavier. Il ne se contente pas d’écrire le drapeau de réussite. Cette vérification ne remplace pas un parcours humain complet depuis l’inspection.

## 9. Carte et dossiers

La carte montre les salles visitées et les seuils voisins identifiés. Ses secteurs sont séparés par onglets. Elle représente les connexions, pas des coordonnées géographiques officielles. Les conditions et les fermetures dynamiques alimentent la lisibilité des liaisons ; la porte réelle demeure la référence pour entrer.

Quarante relevés de terrain sont placés physiquement dans les salles. Vingt-quatre dossiers thématiques se débloquent selon la progression. Leur recherche filtre uniquement les entrées déjà disponibles. Une fiche sur une créature décrit ce que cette adaptation utilise, pas une certification exhaustive de la xénobiologie de la franchise.

Les lectures, la carte, la pause et les courts passages narratifs arrêtent la simulation. Un passage de récit ne laisse pas un xénomorphe tuer le joueur derrière une fenêtre. La perte de focus neutralise les entrées pour éviter une course ou un tir bloqué.

## 10. Sauvegarde et reprise

La clé est `tantalus.dlc.sea-of-sorrows.v1`. Elle ne contient pas le solde de crédits, l’inventaire de Tantalus ou les récompenses des autres campagnes. L’état conserve les objectifs ordonnés, les drapeaux, les salles visitées, les dossiers, l’équipement, les ennemis, les corps, les caisses et un point de reprise.

Chaque entrée de salle crée actuellement un point de reprise. Une mort puis une reprise restaurent ce point, pas un état intermédiaire arbitraire. L’import valide l’identité du DLC, les données numériques, les listes, les types de personnages, les objectifs et le point de reprise avant de modifier l’instance active. La taille acceptée est limitée.

La sauvegarde automatique s’effectue aux événements importants, avec export et import manuels dans Pause. Le navigateur peut refuser son stockage, notamment selon le contexte d’ouverture d’un fichier. L’interface indique alors la nécessité d’exporter. Les tests de ce conteneur ont validé le contrat de stockage avec une fixture en mémoire ; ils ne certifient pas les permissions natives du navigateur de l’utilisateur.

## 11. Fabrication visuelle et sonore

Tous les décors et personnages de cette version sont des dessins vectoriels exécutés dans Canvas. Aucune capture du film, image promotionnelle, planche trouvée sur Internet ou musique extraite n’a été embarquée. Il n’y a pas de moteur de téléchargement d’assets caché.

Les familles humaines utilisent structures, consoles, cages, postes de soins et équipements. Les obstacles des vestiges et de la ruche utilisent résine, débris de silice et côtes organiques plutôt que des caisses militaires répétées. Les passages organiques ont une silhouette propre. Les éclairages extérieurs reposent sur des poteaux, pas sur des fils flottant dans le ciel.

Les graphismes restent stylisés et provisoires. Le générateur de dessin est livré dans `src/render.js` : chaque famille, acteur et effet peut être remplacé indépendamment. Il ne s’agit pas d’un pack de sprites de production avec toutes les animations. Les échelles expriment une hiérarchie visuelle de jeu, pas une mesure physique validée sur un modèle officiel.

L’ambiance facultative et les sons de tir sont synthétisés avec Web Audio. Aucune voix du roman audio n’est incluse. Le mode de mouvements réduits limite les animations décoratives et supprime les transitions CSS ; ce n’est pas une certification d’accessibilité médicale ou une prise en charge de toutes les aides techniques.

## 12. Intégration : ce qui existe et ce qui n’existe pas

`integration/install.cjs` copie le module dans un sous-dossier `dlc/sea-of-sorrows` d’un projet local et contrôle les empreintes. Il n’importe pas le moteur principal, ne modifie pas son index et n’enregistre pas automatiquement ce DLC dans un menu. Son désinstallateur refuse de supprimer un dossier modifié ou contenant des fichiers additionnels.

Le descripteur contient un ancien identifiant de campagne pour aider un futur rapprochement. Ce n’est pas un adaptateur natif. Les règles de session, de rendu, de sauvegarde et de pause du dépôt courant doivent être auditées avant le raccordement. Aucun push GitHub et aucun déploiement Vercel n’ont été effectués pour cette livraison.

## 13. Conditions de passage à une version intégrée

Le raccordement devra d’abord préserver la séparation de sauvegarde et des récompenses. Ensuite, les 40 salles devront être traversées dans le moteur hôte sans téléportation de test. Le combat de la reine et la capture devront être réussis dans les trois difficultés par des joueurs. Les états de clavier, manette, tactile, son et focus devront être repris par les réglages communs du projet.

Une passe de fidélité approfondie demandera une confrontation au roman complet : ordre des séquences, armes réellement confiées à Decker, survivants, rôle exact de chaque intervenant et limites des versions audio. Les ajouts graphiques doivent suivre les plans et les collisions, pas déplacer les issues pour arranger une illustration.

Ces travaux ne sont pas annoncés comme réalisés. La livraison présente constitue une base jouable documentée et testée au niveau indiqué dans son rapport.
