# Codex de level design — La Mer des Chagrins
## v0.1.0 · 40 salles / 45 liaisons

Ce document est généré à partir des données réellement lues par le moteur. Les dimensions sont des unités de jeu, pas des mesures du roman. Les noms détaillés de salles sont des créations d’adaptation. La carte ne prétend pas reproduire un plan canonique.

## Doctrine et lecture des fiches

Chaque porte porte une paire de liaison. Le retour utilise cette même paire et restaure une position d’arrivée voisine du seuil ; les états de la salle persistent. Les coordonnées `x` sont horizontales, `z` indique la profondeur du sol. Les cadres du HUD restent hors du canvas.

Le mode global CLASSIC ramène toutes les profondeurs à 0,55 et ignore les couvertures déclarées non bloquantes pour cette vue. Les conditions d’objectif ne changent pas. Les cages, escaliers, vols et transferts sont des changements de salle explicites, pas une physique verticale continue.

Les « intentions de décor » reprises du champ `propNotes` constituent une direction de fabrication. Elles ne signifient pas que chaque accessoire nommé possède déjà un sprite dédié. Les tableaux de collision ci-dessous, eux, correspondent à des objets rendus et bloquants dans le prototype.

La sauvegarde de reprise est créée à chaque entrée de salle par le moteur. Le champ historique `checkpoint` des données ne filtre pas ce comportement dans la version 0.1.0.

## Parcours des chapitres

| Chapitre du jeu | Objectifs jouables | Note de mise en scène |
|---|---|---|
| 01 — La mer noire | Relever le carottier (s02) | Inspection civile. Aucun arsenal, aucun xénomorphe en patrouille sur le chantier. |
| 02 — Le rapport | Transmettre les résultats (s03) | Une traversée sanitaire relie explicitement les deux planètes. Le rapport devient un objet de l’intrigue. |
| 03 — Un rapport de trop | Déposer les conclusions (s04) ; Passer les examens (s06) ; Écouter le message familial (s05) | L’appartement et la Commission sont reliés par le tram, pas par un couloir de vaisseau. |
| 04 — La dette | Écouter Rollins (s08) ; Récupérer l’équipement (s09) | La pression de la compagnie reste institutionnelle. Pas de combat de boss contre Rollins. |
| 05 — Retour à Galveston | Rejoindre le briefing (s12) ; Vérifier les filtres (s13) ; Mettre la cage en service (s14) | Le camp de surface conserve son identité jusqu’au retour final. |
| 06 — Sous les installations | Établir le relais (s16) ; Rétablir la desserte (s18) | Premier raccourci permanent, atelier facultatif et retour lisible au relais. |
| 07 — La carène | Examiner la brèche (s20) ; Retrouver le balisage de fouille (s21) | Ne pas rebaptiser la coque en vaisseau d’Ingénieur sans source ; le relevé décrit ce qui est visible. |
| 08 — La ville muette | Examiner les restes (s23) ; Récupérer le détecteur (s24) | Les vestiges ne deviennent pas une faction ennemie vivante inventée. |
| 09 — Trois signaux | Écouter ce qui approche (s26) ; Retrouver la balise perdue (s28) | L’empathie est directionnelle et incertaine. Elle ne donne ni carte complète ni contrôle des créatures. |
| 10 — Un chemin qui change | Marquer la dérivation (s27) ; Vérifier le passage fermé (s29) | Une fermeture scénarisée modifie un lien précis, jamais le graphe au hasard. |
| 11 — La sortie perdue | Examiner le second ascenseur (s30) | La perte du puits est un événement du récit. Elle ne peut enfermer le joueur sans issue. |
| 12 — L’autre escalier | Repérer la voie de secours (s31) ; Repérer un passage entre les œufs (s32) | Les œufs occupent des îlots contournables ; les parasites proviennent de points identifiables. |
| 13 — La pondeuse | Ouvrir la voie au groupe (s33) | Affrontement collectif : Decker brûle les attaches et ouvre les angles de tir de Manning. |
| 14 — Ceux qu’on emporte | Mettre Adams à l’abri (s34) ; Mettre Elway à l’abri (s34) | Aucun soin ne supprime une implantation ; la mise à l’abri n’équivaut pas à une guérison. |
| 15 — Remonter | Actionner le treuil (s35) ; Ouvrir le passage du ravin (s36) ; Rallumer la balise d’approche (s11) | Retour à la vraie salle s11, recontextualisée ; aucune copie sans correspondance spatiale. |
| 16 — Un spécimen vivant | Immobiliser puis enfermer l’adulte (s37) | Utiliser le moussoir pour immobiliser l’adulte dans la soute. Le tuer impose de reprendre la séquence. |
| 17 — Réception de cargaison | Confirmer le transfert (s38) ; Observer la surface (s39) | La fin n’est pas réécrite en victoire parfaite de Decker. Le récit conserve le succès de la récupération. |
| 18 — Les voix persistent | Entrer en hypersommeil (s40) | Épilogue contemplatif. Aucun nouveau boss psychique ; aucun bonus ramenant les spécimens dans la campagne 2204. |

## Fiches de salles

### S01 — Poste de contrôle

**Secteur : Surface · Profil : sand · Vue hybride : DEPTH · Largeur : 1960 unités.**

Des herbes rases butent sur une bande de sable noir. Le poste reste relié à la voie de service.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Portique de surveillance ; bornes météo ; clôture ouverte ; câbles enterrés ; traces de chenilles.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-01 | s02 — Le carottier | door | 1860 ; 0.55 | accès ouvert selon la progression |

**Actions et ressources**

Cette salle assure un trajet, une respiration ou une rencontre ; elle ne déclenche pas de nouvel objectif principal. Sa visite et ses seuils persistent néanmoins.

Relevé facultatif `field-s01` : x = 706, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s01-block-0 — caisse industrielle | 588 ; 0.22 | 140 ; 0.12 | 75 |
| s01-block-1 — rayonnage | 1098 ; 0.77 | 140 ; 0.12 | 75 |
| s01-block-2 — faisceau de conduites | 1490 ; 0.22 | 140 ; 0.12 | 75 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S02 — Le carottier

**Secteur : Surface · Profil : sand · Vue hybride : DEPTH · Largeur : 2240 unités.**

Le forage repose sur une plateforme dissymétrique au-dessus des tubes de silice. Une passerelle permet de contourner la machine.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Carottier ancré ; vérins ; caisse de prélèvement ; manche à air ; balises de périmètre.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-01 | s01 — Poste de contrôle | door | 2140 ; 0.55 | accès ouvert selon la progression |
| link-02 | s03 — Transport sanitaire | travel | 100 ; 0.55 | accident |

**Actions et ressources**

- `o01-01` : **Relever le carottier**, à x = 1142, z = 0.55. Déclenche `accident` après validation des conditions du type `sample`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s02` : x = 806, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s02-block-0 — caisse industrielle | 672 ; 0.22 | 164 ; 0.12 | 90 |
| s02-block-1 — rayonnage | 1254 ; 0.77 | 164 ; 0.12 | 90 |
| s02-block-2 — faisceau de conduites | 1702 ; 0.22 | 164 ; 0.12 | 90 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S03 — Transport sanitaire

**Secteur : Transit · Profil : medical · Vue hybride : SIDE · Largeur : 1580 unités.**

Une courte cabine pressurisée : couchette à gauche, terminal médical au centre, sas à droite.

**Lecture spatiale.** Bande latérale ; profondeur verrouillée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Couchette ; moniteur ; écran de télémétrie ; rangement mural ; hublot oblong.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-03 | s04 — Bureau de la Commission | travel | 1480 ; 0.55 | report_sent |

**Actions et ressources**

- `o02-01` : **Transmettre les résultats**, à x = 806, z = 0.55. Déclenche `report_sent` après validation des conditions du type `analyse`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s03` : x = 569, z = 0.55. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

Pas de barrière de profondeur. La silhouette architecturale et les accessoires de fond ne sont pas des murs invisibles traversant la bande latérale.

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S04 — Bureau de la Commission

**Secteur : Terre · Profil : office · Vue hybride : HYBRID · Largeur : 1960 unités.**

Les guichets ouvrent sur une salle de consultation. Les fenêtres montrent la ville et non le chantier minier.

**Lecture spatiale.** Volume de transition ; profondeur resserrée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Bureaux ; imprimante ; casiers ; rangements documentaires ; baie sur les voies urbaines.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-04 | s05 — Appartement de Decker | tram | 1860 ; 0.55 | accès ouvert selon la progression |
| link-05 | s06 — Consultation | door | 100 ; 0.55 | accès ouvert selon la progression |

**Actions et ressources**

- `o03-01` : **Déposer les conclusions**, à x = 1000, z = 0.55. Déclenche `report_filed` après validation des conditions du type `terminal`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s04` : x = 706, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s04-block-0 — caisse industrielle | 588 ; 0.22 | 140 ; 0.12 | 120 |
| s04-block-1 — rayonnage | 1098 ; 0.77 | 140 ; 0.12 | 120 |
| s04-block-2 — faisceau de conduites | 1490 ; 0.22 | 140 ; 0.12 | 120 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S05 — Appartement de Decker

**Secteur : Terre · Profil : home · Vue hybride : SIDE · Largeur : 1800 unités.**

Un logement habité, pas une arène. Des affaires familiales occupent le fond ; une circulation libre mène au terminal personnel.

**Lecture spatiale.** Bande latérale ; profondeur verrouillée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Table ; assises ; rangement bas ; dessins ; terminal familial ; fenêtre sur la rue.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-04 | s04 — Bureau de la Commission | tram | 1700 ; 0.55 | accès ouvert selon la progression |
| link-06 | s07 — Coursive sous garde | story | 100 ; 0.55 | earth_done |

**Actions et ressources**

- `o03-03` : **Écouter le message familial**, à x = 918, z = 0.55. Déclenche `earth_done` après validation des conditions du type `message`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s05` : x = 648, z = 0.55. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

Pas de barrière de profondeur. La silhouette architecturale et les accessoires de fond ne sont pas des murs invisibles traversant la bande latérale.

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S06 — Consultation

**Secteur : Terre · Profil : medical · Vue hybride : HYBRID · Largeur : 1660 unités.**

Le cabinet médical est relié à la Commission par la circulation publique. Un écran isole la table d’examen.

**Lecture spatiale.** Volume de transition ; profondeur resserrée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Table d’examen ; rideau ; analyseur ; lave-mains ; dossier patient.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-05 | s04 — Bureau de la Commission | door | 1560 ; 0.55 | accès ouvert selon la progression |

**Actions et ressources**

- `o03-02` : **Passer les examens**, à x = 1112, z = 0.55. Déclenche `exam_done` après validation des conditions du type `medical`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s06` : x = 664, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s06-block-0 — caisse industrielle | 498 ; 0.22 | 188 ; 0.12 | 90 |
| s06-block-1 — rayonnage | 930 ; 0.77 | 188 ; 0.12 | 90 |
| s06-block-2 — faisceau de conduites | 1262 ; 0.22 | 188 ; 0.12 | 90 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S07 — Coursive sous garde

**Secteur : Vaisseau · Profil : ship · Vue hybride : SIDE · Largeur : 1720 unités.**

Une coursive surveillée relie l’infirmerie à la salle d’entretien. Les portes de service ne mènent pas à un autre monde.

**Lecture spatiale.** Bande latérale ; profondeur verrouillée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Caméra ; grille de ventilation ; banc fixé ; canalisation ; voyant de verrou.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-07 | s08 — La salle d’entretien | door | 1620 ; 0.55 | accès ouvert selon la progression |

**Actions et ressources**

Cette salle assure un trajet, une respiration ou une rencontre ; elle ne déclenche pas de nouvel objectif principal. Sa visite et ses seuils persistent néanmoins.

Relevé facultatif `field-s07` : x = 619, z = 0.55. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

Pas de barrière de profondeur. La silhouette architecturale et les accessoires de fond ne sont pas des murs invisibles traversant la bande latérale.

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S08 — La salle d’entretien

**Secteur : Vaisseau · Profil : office · Vue hybride : HYBRID · Largeur : 1760 unités.**

Deux sièges se font face, séparés par une console. Le vitrage laisse voir les coursives du bord.

**Lecture spatiale.** Volume de transition ; profondeur resserrée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Console ; deux fauteuils ; écran dossier ; armoire scellée ; vitrage technique.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-07 | s07 — Coursive sous garde | door | 1660 ; 0.55 | accès ouvert selon la progression |
| link-08 | s09 — Réserve d’équipement | door | 100 ; 0.55 | contract |

**Actions et ressources**

- `o04-01` : **Écouter Rollins**, à x = 898, z = 0.55. Déclenche `contract` après validation des conditions du type `talk`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s08` : x = 634, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s08-block-0 — caisse industrielle | 528 ; 0.22 | 164 ; 0.12 | 120 |
| s08-block-1 — rayonnage | 986 ; 0.77 | 164 ; 0.12 | 120 |
| s08-block-2 — faisceau de conduites | 1338 ; 0.22 | 164 ; 0.12 | 120 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S09 — Réserve d’équipement

**Secteur : Vaisseau · Profil : armory · Vue hybride : DEPTH · Largeur : 2080 unités.**

Trois travées stockent l’équipement de l’expédition. Les passages entre les racks permettent de changer de profondeur.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Racks ancrés ; combinaisons ; chargeurs ; malle de filtres ; casiers numérotés.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-08 | s08 — La salle d’entretien | door | 1980 ; 0.55 | accès ouvert selon la progression |
| link-09 | s10 — Baie d’embarquement | door | 100 ; 0.55 | equipped |

**Actions et ressources**

- `o04-02` : **Récupérer l’équipement**, à x = 1394, z = 0.55. Déclenche `equipped` après validation des conditions du type `equipment`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s09` : x = 749, z = 0.25. Un poste de ravitaillement est disponible à x = 320, z = 0,55 ; sa consommation est définitive.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s09-block-0 — caisse industrielle | 624 ; 0.22 | 188 ; 0.12 | 75 |
| s09-block-1 — rayonnage | 1165 ; 0.77 | 188 ; 0.12 | 75 |
| s09-block-2 — faisceau de conduites | 1581 ; 0.22 | 188 ; 0.12 | 75 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S10 — Baie d’embarquement

**Secteur : Vaisseau · Profil : hangar · Vue hybride : DEPTH · Largeur : 2480 unités.**

Une rampe et un couloir de sécurité conduisent à la navette. Les volumes au fond ne sont pas jouables.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Navette ; câbles ombilicaux ; treuil ; chariots ; balises de rampe.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-09 | s09 — Réserve d’équipement | door | 2380 ; 0.55 | accès ouvert selon la progression |
| link-10 | s11 — Aire d’atterrissage | flight | 100 ; 0.55 | equipped |

**Actions et ressources**

Cette salle assure un trajet, une respiration ou une rencontre ; elle ne déclenche pas de nouvel objectif principal. Sa visite et ses seuils persistent néanmoins.

Relevé facultatif `field-s10` : x = 893, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s10-block-0 — caisse industrielle | 744 ; 0.22 | 140 ; 0.12 | 90 |
| s10-block-1 — rayonnage | 1389 ; 0.77 | 140 ; 0.12 | 90 |
| s10-block-2 — faisceau de conduites | 1885 ; 0.22 | 140 ; 0.12 | 90 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S11 — Aire d’atterrissage

**Secteur : Camp · Profil : sand · Vue hybride : DEPTH · Largeur : 2560 unités.**

La même aire sera retrouvée au retour. Le camp reste à l’est et le ravin d’accès au nord.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Dalles prises dans le sable ; balises ; réservoir ; abri radio ; traces de moteurs.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-11 | s12 — Abri d’expédition | door | 2460 ; 0.55 | accès ouvert selon la progression |
| link-41 | s36 — Ravin de service | door | 100 ; 0.55 | accès ouvert selon la progression |
| link-42 | s37 — Soute de la navette | ramp | 1178 ; 0.15 | beacon_lit |

**Actions et ressources**

- `o15-03` : **Rallumer la balise d’approche**, à x = 1306, z = 0.55. Déclenche `beacon_lit` après validation des conditions du type `beacon`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s11` : x = 922, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s11-block-0 — caisse industrielle | 768 ; 0.22 | 164 ; 0.12 | 105 |
| s11-block-1 — rayonnage | 1434 ; 0.77 | 164 ; 0.12 | 105 |
| s11-block-2 — faisceau de conduites | 1946 ; 0.22 | 164 ; 0.12 | 105 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Retour structurant.** Cette salle est réutilisée après le ravin s36. Le départ final vers la soute s37 attend la balise. Ne pas créer un duplicata de cette aire au retour.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S12 — Abri d’expédition

**Secteur : Camp · Profil : camp · Vue hybride : HYBRID · Largeur : 1940 unités.**

L’abri possède une entrée, une zone de briefing et un passage vers la décontamination.

**Lecture spatiale.** Volume de transition ; profondeur resserrée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Table de mission ; bancs ; cartes ; thermos ; casiers ; filtre d’air.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-11 | s11 — Aire d’atterrissage | door | 1840 ; 0.55 | accès ouvert selon la progression |
| link-12 | s13 — Décontamination | door | 100 ; 0.55 | accès ouvert selon la progression |

**Actions et ressources**

- `o05-01` : **Rejoindre le briefing**, à x = 989, z = 0.55. Déclenche `briefed` après validation des conditions du type `brief`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s12` : x = 698, z = 0.25. Un poste de ravitaillement est disponible à x = 320, z = 0,55 ; sa consommation est définitive.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s12-block-0 — caisse industrielle | 582 ; 0.22 | 188 ; 0.12 | 120 |
| s12-block-1 — rayonnage | 1086 ; 0.77 | 188 ; 0.12 | 120 |
| s12-block-2 — faisceau de conduites | 1474 ; 0.22 | 188 ; 0.12 | 120 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S13 — Décontamination

**Secteur : Camp · Profil : decon · Vue hybride : SIDE · Largeur : 1760 unités.**

Deux portes encadrent les buses de nettoyage. Les équipements humides restent dans la partie sale.

**Lecture spatiale.** Bande latérale ; profondeur verrouillée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Buses ; caillebotis ; cuve de collecte ; combinaisons ; râtelier de bottes.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-12 | s12 — Abri d’expédition | door | 1660 ; 0.55 | accès ouvert selon la progression |
| link-13 | s14 — Tête de puits | door | 100 ; 0.55 | filters_ready |

**Actions et ressources**

- `o05-02` : **Vérifier les filtres**, à x = 1179, z = 0.55. Déclenche `filters_ready` après validation des conditions du type `filter`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s13` : x = 634, z = 0.55. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

Pas de barrière de profondeur. La silhouette architecturale et les accessoires de fond ne sont pas des murs invisibles traversant la bande latérale.

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S14 — Tête de puits

**Secteur : Camp · Profil : lift · Vue hybride : DEPTH · Largeur : 2240 unités.**

Une cage d’ascenseur occupe le centre d’un chevalement. La rambarde laisse seulement deux passages balisés.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Cage ; poulies ; commandes ; garde-corps ; câble principal ; barrières de bord.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-13 | s13 — Décontamination | door | 2140 ; 0.55 | accès ouvert selon la progression |
| link-14 | s15 — Recette inférieure | lift | 100 ; 0.55 | lift_ready ; condamné après lift_lost |

**Actions et ressources**

- `o05-03` : **Mettre la cage en service**, à x = 1142, z = 0.55. Déclenche `lift_ready` après validation des conditions du type `power`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s14` : x = 806, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s14-block-0 — caisse industrielle | 672 ; 0.22 | 164 ; 0.12 | 90 |
| s14-block-1 — rayonnage | 1254 ; 0.77 | 164 ; 0.12 | 90 |
| s14-block-2 — faisceau de conduites | 1702 ; 0.22 | 164 ; 0.12 | 90 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S15 — Recette inférieure

**Secteur : Mine · Profil : lift · Vue hybride : HYBRID · Largeur : 2120 unités.**

La cage arrive dans une recette protégée. Les rails sortent vers le relais, loin du bord du puits.

**Lecture spatiale.** Volume de transition ; profondeur resserrée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Cage ; rails ; butoir ; boulonnage ; tuyauteries ; éclairage de secours.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-14 | s14 — Tête de puits | lift | 2020 ; 0.55 | accès ouvert selon la progression ; condamné après lift_lost |
| link-15 | s16 — Relais de Cho | door | 100 ; 0.55 | accès ouvert selon la progression |

**Actions et ressources**

Cette salle assure un trajet, une respiration ou une rencontre ; elle ne déclenche pas de nouvel objectif principal. Sa visite et ses seuils persistent néanmoins.

Relevé facultatif `field-s15` : x = 763, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s15-block-0 — caisse industrielle | 636 ; 0.22 | 188 ; 0.12 | 105 |
| s15-block-1 — rayonnage | 1187 ; 0.77 | 188 ; 0.12 | 105 |
| s15-block-2 — faisceau de conduites | 1611 ; 0.22 | 188 ; 0.12 | 105 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S16 — Relais de Cho

**Secteur : Mine · Profil : relay · Vue hybride : DEPTH · Largeur : 2280 unités.**

Le relais distribue les voies de la mine. La radio se trouve contre un mur, sans bloquer les circulations.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Table radio ; touret ; casiers ; antenne filaire ; lampe ; repères de secteur.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-15 | s15 — Recette inférieure | door | 2180 ; 0.55 | accès ouvert selon la progression |
| link-16 | s17 — Atelier de maintenance | door | 100 ; 0.55 | accès ouvert selon la progression |
| link-19 | s19 — La carène enfouie | shortcut | 1049 ; 0.15 | power_on |

**Actions et ressources**

- `o06-01` : **Établir le relais**, à x = 1163, z = 0.55. Déclenche `relay_ready` après validation des conditions du type `radio`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s16` : x = 821, z = 0.25. Un poste de ravitaillement est disponible à x = 320, z = 0,55 ; sa consommation est définitive.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s16-block-0 — caisse industrielle | 684 ; 0.22 | 140 ; 0.12 | 120 |
| s16-block-1 — rayonnage | 1277 ; 0.77 | 140 ; 0.12 | 120 |
| s16-block-2 — faisceau de conduites | 1733 ; 0.22 | 140 ; 0.12 | 120 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S17 — Atelier de maintenance

**Secteur : Mine · Profil : workshop · Vue hybride : HYBRID · Largeur : 1960 unités.**

Un établi, un passage central libre et une remise arrière. Le matériel lourd reste appuyé au sol.

**Lecture spatiale.** Volume de transition ; profondeur resserrée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Établi ; outils ; bouteilles ; chariot ; caisses ; crochets ; établi secondaire.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-16 | s16 — Relais de Cho | door | 1860 ; 0.55 | accès ouvert selon la progression |
| link-17 | s18 — Galerie d’alimentation | door | 100 ; 0.55 | accès ouvert selon la progression |

**Actions et ressources**

Cette salle assure un trajet, une respiration ou une rencontre ; elle ne déclenche pas de nouvel objectif principal. Sa visite et ses seuils persistent néanmoins.

Relevé facultatif `field-s17` : x = 706, z = 0.25. Un poste de ravitaillement est disponible à x = 320, z = 0,55 ; sa consommation est définitive.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s17-block-0 — caisse industrielle | 588 ; 0.22 | 164 ; 0.12 | 75 |
| s17-block-1 — rayonnage | 1098 ; 0.77 | 164 ; 0.12 | 75 |
| s17-block-2 — faisceau de conduites | 1490 ; 0.22 | 164 ; 0.12 | 75 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S18 — Galerie d’alimentation

**Secteur : Mine · Profil : power · Vue hybride : SIDE · Largeur : 2420 unités.**

Les câbles longent le plafond. Le chemin de service évite les armoires haute tension.

**Lecture spatiale.** Bande latérale ; profondeur verrouillée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Armoires ; câbles ; disjoncteurs ; isolateurs ; tuyaux ; porte coupe-feu.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-17 | s17 — Atelier de maintenance | door | 2320 ; 0.55 | accès ouvert selon la progression |
| link-18 | s19 — La carène enfouie | door | 100 ; 0.55 | power_on |

**Actions et ressources**

- `o06-02` : **Rétablir la desserte**, à x = 1621, z = 0.55. Déclenche `power_on` après validation des conditions du type `power`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s18` : x = 871, z = 0.55. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

Pas de barrière de profondeur. La silhouette architecturale et les accessoires de fond ne sont pas des murs invisibles traversant la bande latérale.

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S19 — La carène enfouie

**Secteur : Vestiges · Profil : derelict · Vue hybride : DEPTH · Largeur : 2880 unités.**

La coque apparaît dans une caverne bien plus vaste que le champ de déplacement. La zone de fouille se poursuit en contrebas.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Coque courbe ; échafaudage ; passerelle ; roche fracturée ; balises humaines.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-18 | s18 — Galerie d’alimentation | door | 2780 ; 0.55 | accès ouvert selon la progression |
| link-19 | s16 — Relais de Cho | shortcut | 100 ; 0.55 | accès ouvert selon la progression |
| link-20 | s20 — Brèche de coque | door | 1325 ; 0.15 | accès ouvert selon la progression |
| link-21 | s21 — Tranchée de fouille | stairs | 1958 ; 0.85 | accès ouvert selon la progression |

**Actions et ressources**

Cette salle assure un trajet, une respiration ou une rencontre ; elle ne déclenche pas de nouvel objectif principal. Sa visite et ses seuils persistent néanmoins.

Relevé facultatif `field-s19` : x = 1037, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s19-block-0 — masse de résine | 864 ; 0.22 | 140 ; 0.12 | 105 |
| s19-block-1 — débris de silice | 1613 ; 0.77 | 140 ; 0.12 | 105 |
| s19-block-2 — structure organique côtelée | 2189 ; 0.22 | 140 ; 0.12 | 105 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1814 ; 0.35).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S20 — Brèche de coque

**Secteur : Vestiges · Profil : alien · Vue hybride : HYBRID · Largeur : 2120 unités.**

Une ouverture irrégulière suit la peau du vaisseau. Les ajouts humains s’arrêtent aux premiers renflements.

**Lecture spatiale.** Volume de transition ; profondeur resserrée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Arches non humaines ; peau nervurée ; jauges de relevé ; câbles humains temporaires.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-20 | s19 — La carène enfouie | door | 2020 ; 0.55 | accès ouvert selon la progression |
| link-28 | s26 — Entrée des tubes | shortcut | 100 ; 0.55 | tracker_ready |

**Actions et ressources**

- `o07-01` : **Examiner la brèche**, à x = 1081, z = 0.55. Déclenche `hull_seen` après validation des conditions du type `scan`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s20` : x = 763, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s20-block-0 — masse de résine | 636 ; 0.22 | 164 ; 0.12 | 120 |
| s20-block-1 — débris de silice | 1187 ; 0.77 | 164 ; 0.12 | 120 |
| s20-block-2 — structure organique côtelée | 1611 ; 0.22 | 164 ; 0.12 | 120 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1336 ; 0.35).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S21 — Tranchée de fouille

**Secteur : Vestiges · Profil : ruins · Vue hybride : DEPTH · Largeur : 2560 unités.**

La fouille descend vers la ville ruinée. Les cordes, grilles et repères racontent le travail des chercheurs.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Strates rocheuses ; tamis ; cordes ; boîtes d’échantillons ; piquets ; passerelle.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-21 | s19 — La carène enfouie | stairs | 2460 ; 0.55 | accès ouvert selon la progression |
| link-22 | s22 — Esplanade ensevelie | door | 100 ; 0.55 | accès ouvert selon la progression |

**Actions et ressources**

- `o07-02` : **Retrouver le balisage de fouille**, à x = 1715, z = 0.55. Déclenche `dig_seen` après validation des conditions du type `survey`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s21` : x = 922, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s21-block-0 — masse de résine | 768 ; 0.22 | 188 ; 0.12 | 75 |
| s21-block-1 — débris de silice | 1434 ; 0.77 | 188 ; 0.12 | 75 |
| s21-block-2 — structure organique côtelée | 1946 ; 0.22 | 188 ; 0.12 | 75 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1613 ; 0.35).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S22 — Esplanade ensevelie

**Secteur : Vestiges · Profil : ruins · Vue hybride : DEPTH · Largeur : 2860 unités.**

Des bâtiments non humains entourent une place partiellement dégagée. Les portes visibles ont des destinations cohérentes.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Contreforts ; arches effondrées ; pierres ; éclairages sur trépied ; instruments.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-22 | s21 — Tranchée de fouille | door | 2760 ; 0.55 | accès ouvert selon la progression |
| link-23 | s23 — Salle des restes | door | 100 ; 0.55 | accès ouvert selon la progression |
| link-24 | s24 — Poste de relevés | door | 1316 ; 0.15 | accès ouvert selon la progression |

**Actions et ressources**

Cette salle assure un trajet, une respiration ou une rencontre ; elle ne déclenche pas de nouvel objectif principal. Sa visite et ses seuils persistent néanmoins.

Relevé facultatif `field-s22` : x = 1030, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s22-block-0 — masse de résine | 858 ; 0.22 | 140 ; 0.12 | 90 |
| s22-block-1 — débris de silice | 1602 ; 0.77 | 140 ; 0.12 | 90 |
| s22-block-2 — structure organique côtelée | 2174 ; 0.22 | 140 ; 0.12 | 90 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1802 ; 0.35), adult à (2016 ; 0.71).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S23 — Salle des restes

**Secteur : Vestiges · Profil : ossuary · Vue hybride : SIDE · Largeur : 1860 unités.**

Les restes sont des témoins archéologiques, pas des ennemis ressuscités. Le joueur traverse un passage balisé.

**Lecture spatiale.** Bande latérale ; profondeur verrouillée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Tables de relevé ; fragments protégés ; toile ; scanner ; jalons ; niches.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-23 | s22 — Esplanade ensevelie | door | 1760 ; 0.55 | accès ouvert selon la progression |
| link-25 | s24 — Poste de relevés | crawl | 100 ; 0.55 | survey_complete |

**Actions et ressources**

- `o08-01` : **Examiner les restes**, à x = 949, z = 0.55. Déclenche `survey_complete` après validation des conditions du type `scan`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s23` : x = 670, z = 0.55. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

Pas de barrière de profondeur. La silhouette architecturale et les accessoires de fond ne sont pas des murs invisibles traversant la bande latérale.

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1172 ; 0.55).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S24 — Poste de relevés

**Secteur : Vestiges · Profil : relay · Vue hybride : HYBRID · Largeur : 2120 unités.**

Une implantation humaine fragile occupe un seuil de la cité. La radio et le matériel restent visibles depuis l’entrée.

**Lecture spatiale.** Volume de transition ; profondeur resserrée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Console portable ; caisses de capteurs ; panneaux ; fil guide ; bouteilles d’air.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-24 | s22 — Esplanade ensevelie | door | 2020 ; 0.55 | accès ouvert selon la progression |
| link-25 | s23 — Salle des restes | crawl | 100 ; 0.55 | accès ouvert selon la progression |
| link-26 | s25 — Passerelle suspendue | door | 975 ; 0.15 | accès ouvert selon la progression |

**Actions et ressources**

- `o08-02` : **Récupérer le détecteur**, à x = 1420, z = 0.55. Déclenche `tracker_ready` après validation des conditions du type `equipment`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s24` : x = 763, z = 0.25. Un poste de ravitaillement est disponible à x = 320, z = 0,55 ; sa consommation est définitive.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s24-block-0 — caisse industrielle | 636 ; 0.22 | 188 ; 0.12 | 120 |
| s24-block-1 — rayonnage | 1187 ; 0.77 | 188 ; 0.12 | 120 |
| s24-block-2 — faisceau de conduites | 1611 ; 0.22 | 188 ; 0.12 | 120 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1336 ; 0.35), adult à (1495 ; 0.71).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S25 — Passerelle suspendue

**Secteur : Vestiges · Profil : bridge · Vue hybride : SIDE · Largeur : 2680 unités.**

Une passerelle suit la paroi ; des volumes descendent sous le plan jouable. Le vide n’est pas une seconde route.

**Lecture spatiale.** Bande latérale ; profondeur verrouillée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Platelage ; ancrages ; câble latéral ; contreventement ; balises cassées.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-26 | s24 — Poste de relevés | door | 2580 ; 0.55 | accès ouvert selon la progression |
| link-27 | s26 — Entrée des tubes | door | 100 ; 0.55 | tracker_ready |

**Actions et ressources**

Cette salle assure un trajet, une respiration ou une rencontre ; elle ne déclenche pas de nouvel objectif principal. Sa visite et ses seuils persistent néanmoins.

Relevé facultatif `field-s25` : x = 965, z = 0.55. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

Pas de barrière de profondeur. La silhouette architecturale et les accessoires de fond ne sont pas des murs invisibles traversant la bande latérale.

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1688 ; 0.55), adult à (1889 ; 0.55).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S26 — Entrée des tubes

**Secteur : Ruche · Profil : silica · Vue hybride : HYBRID · Largeur : 2120 unités.**

La mine humaine rejoint des tubes de silice. La transition architecturale est visible avant le changement de salle.

**Lecture spatiale.** Volume de transition ; profondeur resserrée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Silice ; roche ; repères arrachés ; lampe tombée ; peau translucide ; résine.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-27 | s25 — Passerelle suspendue | door | 2020 ; 0.55 | accès ouvert selon la progression |
| link-28 | s20 — Brèche de coque | shortcut | 100 ; 0.55 | accès ouvert selon la progression |
| link-29 | s27 — Le nœud ambré | door | 975 ; 0.15 | accès ouvert selon la progression |

**Actions et ressources**

- `o09-01` : **Écouter ce qui approche**, à x = 1081, z = 0.55. Déclenche `hive_sensed` après validation des conditions du type `sense`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s26` : x = 763, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s26-block-0 — masse de résine | 636 ; 0.22 | 164 ; 0.12 | 90 |
| s26-block-1 — débris de silice | 1187 ; 0.77 | 164 ; 0.12 | 90 |
| s26-block-2 — structure organique côtelée | 1611 ; 0.22 | 164 ; 0.12 | 90 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1336 ; 0.35), adult à (1495 ; 0.71).

**Perception.** L’objectif demande une pression minimale obtenue par Espace. Le message de direction est un indice de salle, pas une connaissance de toute la ruche.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S27 — Le nœud ambré

**Secteur : Ruche · Profil : silica · Vue hybride : DEPTH · Largeur : 2680 unités.**

Trois passages composent une boucle. Les piliers de silice délimitent les bandes sans former un mur infranchissable.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Piliers ; gouttes minérales ; membranes ; débris d’équipement ; trace de traînée.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-29 | s26 — Entrée des tubes | door | 2580 ; 0.55 | accès ouvert selon la progression |
| link-30 | s28 — Alcôve des disparus | door | 100 ; 0.55 | accès ouvert selon la progression |
| link-32 | s29 — Le retour fermé | shortcut | 1233 ; 0.15 | accès ouvert selon la progression |

**Actions et ressources**

- `o10-01` : **Marquer la dérivation**, à x = 1367, z = 0.55. Déclenche `route_marked` après validation des conditions du type `route`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s27` : x = 965, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s27-block-0 — masse de résine | 804 ; 0.22 | 188 ; 0.12 | 105 |
| s27-block-1 — débris de silice | 1501 ; 0.77 | 188 ; 0.12 | 105 |
| s27-block-2 — structure organique côtelée | 2037 ; 0.22 | 188 ; 0.12 | 105 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1688 ; 0.35), adult à (1889 ; 0.71), adult à (2090 ; 0.50).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S28 — Alcôve des disparus

**Secteur : Ruche · Profil : hive · Vue hybride : SIDE · Largeur : 1960 unités.**

Une alcôve accessible par un boyau étroit. Les cocons occupent le fond, le passage reste latéral.

**Lecture spatiale.** Bande latérale ; profondeur verrouillée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Cocons ; casque ; balise ; arme vide ; résine ; réseaux organiques.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-30 | s27 — Le nœud ambré | door | 1860 ; 0.55 | accès ouvert selon la progression |
| link-31 | s29 — Le retour fermé | door | 100 ; 0.55 | accès ouvert selon la progression ; fermé après maze_known |

**Actions et ressources**

- `o09-02` : **Retrouver la balise perdue**, à x = 1313, z = 0.55. Déclenche `tags_found` après validation des conditions du type `recover`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s28` : x = 706, z = 0.55. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

Pas de barrière de profondeur. La silhouette architecturale et les accessoires de fond ne sont pas des murs invisibles traversant la bande latérale.

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1235 ; 0.55), adult à (1382 ; 0.55).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S29 — Le retour fermé

**Secteur : Ruche · Profil : silica · Vue hybride : HYBRID · Largeur : 2220 unités.**

Le retour se bouche après le relevé. Une dérivation identifiée existe avant le changement d’état.

**Lecture spatiale.** Volume de transition ; profondeur resserrée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Membrane de fermeture ; ancien repère ; fissure latérale ; tube de ventilation.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-31 | s28 — Alcôve des disparus | door | 2120 ; 0.55 | accès ouvert selon la progression ; fermé après maze_known |
| link-32 | s27 — Le nœud ambré | shortcut | 100 ; 0.55 | accès ouvert selon la progression |
| link-33 | s30 — Ascenseur secondaire | door | 1021 ; 0.15 | maze_known |

**Actions et ressources**

- `o10-02` : **Vérifier le passage fermé**, à x = 1487, z = 0.55. Déclenche `maze_known` après validation des conditions du type `seal`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s29` : x = 799, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s29-block-0 — masse de résine | 666 ; 0.22 | 164 ; 0.12 | 75 |
| s29-block-1 — débris de silice | 1243 ; 0.77 | 164 ; 0.12 | 75 |
| s29-block-2 — structure organique côtelée | 1687 ; 0.22 | 164 ; 0.12 | 75 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1399 ; 0.35), adult à (1565 ; 0.71), adult à (1732 ; 0.50).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S30 — Ascenseur secondaire

**Secteur : Ruche · Profil : lift · Vue hybride : DEPTH · Largeur : 2300 unités.**

La seconde installation ne garantit plus de sortie. Les commandes restent accessibles malgré les dommages.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Cage inclinée ; câbles rompus ; supports tordus ; panneau défaut ; rambardes.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-33 | s29 — Le retour fermé | door | 2200 ; 0.55 | accès ouvert selon la progression |
| link-34 | s31 — Pied de l’escalier | door | 100 ; 0.55 | lift_lost |

**Actions et ressources**

- `o11-01` : **Examiner le second ascenseur**, à x = 1173, z = 0.55. Déclenche `lift_lost` après validation des conditions du type `inspect`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s30` : x = 828, z = 0.25. Un poste de ravitaillement est disponible à x = 320, z = 0,55 ; sa consommation est définitive.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s30-block-0 — caisse industrielle | 690 ; 0.22 | 188 ; 0.12 | 90 |
| s30-block-1 — rayonnage | 1288 ; 0.77 | 188 ; 0.12 | 90 |
| s30-block-2 — faisceau de conduites | 1748 ; 0.22 | 188 ; 0.12 | 90 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1449 ; 0.35), adult à (1622 ; 0.71).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S31 — Pied de l’escalier

**Secteur : Ruche · Profil : stairs · Vue hybride : HYBRID · Largeur : 2420 unités.**

La cage d’escalier possède des paliers lisibles et un itinéraire de maintenance, sans téléportation entre étages.

**Lecture spatiale.** Volume de transition ; profondeur resserrée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Volées ; paliers ; échelle de secours ; numérotation ; main courante ; conduites.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-34 | s30 — Ascenseur secondaire | door | 2320 ; 0.55 | accès ouvert selon la progression |
| link-35 | s32 — Chambre des œufs | door | 100 ; 0.55 | stairs_known |
| link-38 | s34 — Dérivation de secours | shortcut | 1113 ; 0.15 | queen_down |

**Actions et ressources**

- `o12-01` : **Repérer la voie de secours**, à x = 1234, z = 0.55. Déclenche `stairs_known` après validation des conditions du type `route`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s31` : x = 871, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s31-block-0 — caisse industrielle | 726 ; 0.22 | 140 ; 0.12 | 105 |
| s31-block-1 — rayonnage | 1355 ; 0.77 | 140 ; 0.12 | 105 |
| s31-block-2 — faisceau de conduites | 1839 ; 0.22 | 140 ; 0.12 | 105 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1525 ; 0.35), adult à (1706 ; 0.71), adult à (1888 ; 0.50).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S32 — Chambre des œufs

**Secteur : Ruche · Profil : hive · Vue hybride : DEPTH · Largeur : 2820 unités.**

Les œufs forment des îlots, jamais une grille décorative. Deux passages continus permettent de se replier.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Œufs ; résine ; condensation ; carcasses minérales ; creux sombres ; gaines.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-35 | s31 — Pied de l’escalier | door | 2720 ; 0.55 | accès ouvert selon la progression |
| link-36 | s33 — La pondeuse | door | 100 ; 0.55 | brood_seen |

**Actions et ressources**

- `o12-02` : **Repérer un passage entre les œufs**, à x = 1889, z = 0.55. Déclenche `brood_seen` après validation des conditions du type `brood`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s32` : x = 1015, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s32-block-0 — masse de résine | 846 ; 0.22 | 164 ; 0.12 | 120 |
| s32-block-1 — débris de silice | 1579 ; 0.77 | 164 ; 0.12 | 120 |
| s32-block-2 — structure organique côtelée | 2143 ; 0.22 | 164 ; 0.12 | 120 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : facehugger à (1777 ; 0.35), adult à (1988 ; 0.71), facehugger à (2200 ; 0.50), adult à (2411 ; 0.78).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S33 — La pondeuse

**Secteur : Ruche · Profil : queen · Vue hybride : DEPTH · Largeur : 3040 unités.**

Une grande chambre distribue trois ancrages de résine autour d’un axe d’évacuation. Le boss ne remplit pas l’écran.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Reine ; attaches ; ovipositeur stylisé ; œufs périphériques ; arches ; sol corrodé.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-36 | s32 — Chambre des œufs | door | 2940 ; 0.55 | accès ouvert selon la progression |
| link-37 | s34 — Dérivation de secours | door | 100 ; 0.55 | queen_down |

**Actions et ressources**

- `o13-01` : **Ouvrir la voie au groupe**, à x = 2620, z = 0.55. Déclenche `queen_down` après validation des conditions du type `boss`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s33` : x = 1094, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s33-block-0 — masse de résine | 912 ; 0.22 | 188 ; 0.12 | 75 |
| s33-block-1 — débris de silice | 1702 ; 0.77 | 188 ; 0.12 | 75 |
| s33-block-2 — structure organique côtelée | 2310 ; 0.22 | 188 ; 0.12 | 75 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : queen à (1915 ; 0.35).

**Rencontre dédiée.** Trois attaches à (980 ; 0,50), (1510 ; 0,38), (2220 ; 0,59). Le feu les détruit avant que la reine devienne vulnérable. Ces attaches et la règle d’invulnérabilité sont originales au jeu.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S34 — Dérivation de secours

**Secteur : Ruche · Profil : power · Vue hybride : HYBRID · Largeur : 2140 unités.**

Le retour vers l’escalier passe par une galerie industrielle partiellement envahie. Une zone de soins improvisée ne promet aucune guérison.

**Lecture spatiale.** Volume de transition ; profondeur resserrée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Civière ; couvertures ; éclairage mobile ; caisses ; conduites ; fermeture coupe-feu.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-37 | s33 — La pondeuse | door | 2040 ; 0.55 | accès ouvert selon la progression |
| link-38 | s31 — Pied de l’escalier | shortcut | 100 ; 0.55 | accès ouvert selon la progression |
| link-39 | s35 — Paliers supérieurs | stairs | 984 ; 0.15 | hosts_secured |

**Actions et ressources**

- `o14-01` : **Mettre Adams à l’abri**, à x = 920, z = 0.55. Déclenche `adams_secured` après validation des conditions du type `rescue`. La validation n’est possible que lorsque cette étape est l’objectif courant.
- `o14-02` : **Mettre Elway à l’abri**, à x = 1450, z = 0.55. Déclenche `hosts_secured` après validation des conditions du type `rescue`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s34` : x = 770, z = 0.25. Un poste de ravitaillement est disponible à x = 320, z = 0,55 ; sa consommation est définitive.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s34-block-0 — caisse industrielle | 642 ; 0.22 | 140 ; 0.12 | 90 |
| s34-block-1 — rayonnage | 1198 ; 0.77 | 140 ; 0.12 | 90 |
| s34-block-2 — faisceau de conduites | 1626 ; 0.22 | 140 ; 0.12 | 90 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1348 ; 0.35), adult à (1509 ; 0.71).

**Porteurs.** Deux validations distinctes, sans guérison implicite. Le transport est abstrait par la progression : les brancards ne suivent pas physiquement l’IA dans la version livrée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S35 — Paliers supérieurs

**Secteur : Sortie · Profil : stairs · Vue hybride : SIDE · Largeur : 2660 unités.**

Une succession de paliers comprimée pour le jeu, reliée explicitement au bas de la cage. Les marches sont une animation de liaison.

**Lecture spatiale.** Bande latérale ; profondeur verrouillée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Treuil ; paliers ; câble de levage ; mains courantes ; bouche de surface.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-39 | s34 — Dérivation de secours | stairs | 2560 ; 0.55 | accès ouvert selon la progression |
| link-40 | s36 — Ravin de service | climb | 100 ; 0.55 | winch_ready |

**Actions et ressources**

- `o15-01` : **Actionner le treuil**, à x = 1357, z = 0.55. Déclenche `winch_ready` après validation des conditions du type `winch`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s35` : x = 958, z = 0.55. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

Pas de barrière de profondeur. La silhouette architecturale et les accessoires de fond ne sont pas des murs invisibles traversant la bande latérale.

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1676 ; 0.55), adult à (1875 ; 0.55).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S36 — Ravin de service

**Secteur : Sortie · Profil : sand · Vue hybride : DEPTH · Largeur : 2700 unités.**

Le ravin rejoint le nord de l’aire initiale. Les mêmes tours et balises permettent de reconnaître le lieu.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Talus ; antenne ; câble enterré ; talweg sec ; route de service ; sable en mouvement.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-40 | s35 — Paliers supérieurs | climb | 2600 ; 0.55 | accès ouvert selon la progression |
| link-41 | s11 — Aire d’atterrissage | door | 100 ; 0.55 | route_open |

**Actions et ressources**

- `o15-02` : **Ouvrir le passage du ravin**, à x = 1809, z = 0.55. Déclenche `route_open` après validation des conditions du type `route`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s36` : x = 972, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s36-block-0 — caisse industrielle | 810 ; 0.22 | 188 ; 0.12 | 120 |
| s36-block-1 — rayonnage | 1512 ; 0.77 | 188 ; 0.12 | 120 |
| s36-block-2 — faisceau de conduites | 2052 ; 0.22 | 188 ; 0.12 | 120 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : adult à (1701 ; 0.35), adult à (1904 ; 0.71), adult à (2106 ; 0.50).

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S37 — Soute de la navette

**Secteur : Sortie · Profil : hangar · Vue hybride : DEPTH · Largeur : 2400 unités.**

La rampe débouche sur une soute assez large pour l’opération de capture. Le caisson est ancré, et non posé devant une porte.

**Lecture spatiale.** Surface de déplacement en profondeur ; obstacles contournables. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Caisson ; moussoir ; treuil ; sangles ; rampes ; rails de chargement ; banquettes.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-42 | s11 — Aire d’atterrissage | ramp | 2300 ; 0.55 | accès ouvert selon la progression |
| link-43 | s38 — Quarantaine orbitale | flight | 100 ; 0.55 | live_capture |

**Actions et ressources**

- `o16-01` : **Immobiliser puis enfermer l’adulte**, à x = 1910, z = 0.55. Déclenche `live_capture` après validation des conditions du type `capture`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s37` : x = 864, z = 0.25. Un poste de ravitaillement est disponible à x = 320, z = 0,55 ; sa consommation est définitive.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s37-block-0 — caisse industrielle | 720 ; 0.22 | 140 ; 0.12 | 75 |
| s37-block-1 — rayonnage | 1344 ; 0.77 | 140 ; 0.12 | 75 |
| s37-block-2 — faisceau de conduites | 1824 ; 0.22 | 140 ; 0.12 | 75 |

**Présences et rythme**

Rencontre finie, sans réapparition automatique : captureAdult à (1512 ; 0.35).

**Capture.** Le caisson est à x = 1910. Seuil : immobilisation ≥ 0,95, cible vivante et distance de la cible au caisson ≤ 255 unités, joueur à portée d’interaction. L’allié exclut cet adulte de ses cibles. La mousse et le caisson doivent fonctionner avant l’accès à s38.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S38 — Quarantaine orbitale

**Secteur : Épilogue · Profil : medical · Vue hybride : SIDE · Largeur : 1840 unités.**

Une vitre sépare le personnel des spécimens. Les hôtes ne sont pas soignés par une interaction magique.

**Lecture spatiale.** Bande latérale ; profondeur verrouillée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Vitrage ; cryocuves ; dossier transfert ; caméra ; clapets ; sas sécurisé.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-44 | s39 — Poste d’observation | door | 1740 ; 0.55 | specimens_delivered |

**Actions et ressources**

- `o17-01` : **Confirmer le transfert**, à x = 938, z = 0.55. Déclenche `specimens_delivered` après validation des conditions du type `transfer`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s38` : x = 662, z = 0.55. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

Pas de barrière de profondeur. La silhouette architecturale et les accessoires de fond ne sont pas des murs invisibles traversant la bande latérale.

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S39 — Poste d’observation

**Secteur : Épilogue · Profil : ship · Vue hybride : HYBRID · Largeur : 2080 unités.**

La baie montre la planète, pas une ville terrestre. La frappe est une séquence orbitale non jouable comme arme.

**Lecture spatiale.** Volume de transition ; profondeur resserrée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Baie ; console ; écran de mission ; sièges fixés ; éclairage de veille.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-44 | s38 — Quarantaine orbitale | door | 1980 ; 0.55 | accès ouvert selon la progression |
| link-45 | s40 — Hypersommeil | door | 100 ; 0.55 | strike_seen |

**Actions et ressources**

- `o17-02` : **Observer la surface**, à x = 1394, z = 0.55. Déclenche `strike_seen` après validation des conditions du type `observe`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s39` : x = 749, z = 0.25. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

| Objet | Position (x ; z) | Emprise (largeur ; profondeur) | Hauteur visuelle |
|---|---|---|---|
| s39-block-0 — caisse industrielle | 624 ; 0.22 | 188 ; 0.12 | 105 |
| s39-block-1 — rayonnage | 1165 ; 0.77 | 188 ; 0.12 | 105 |
| s39-block-2 — faisceau de conduites | 1581 ; 0.22 | 188 ; 0.12 | 105 |

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

### S40 — Hypersommeil

**Secteur : Épilogue · Profil : medical · Vue hybride : SIDE · Largeur : 1820 unités.**

La dernière salle referme le récit. Des couchettes et des moniteurs encadrent un couloir presque vide.

**Lecture spatiale.** Bande latérale ; profondeur verrouillée. La ligne de desserte principale se situe autour de z = 0,55. Les interactions actives s’affichent dans le bandeau de mission, sans panneau central permanent.

**Intentions de décor.** Couchettes ; casiers ; terminal ; lumière de veille ; hublot ; tubulures.

**Liaisons physiques et conditions initiales**

| Seuil | Destination | Nature | Position (x ; z) | Condition |
|---|---|---|---|---|
| link-45 | s39 — Poste d’observation | door | 1720 ; 0.55 | accès ouvert selon la progression |

**Actions et ressources**

- `o18-01` : **Entrer en hypersommeil**, à x = 928, z = 0.55. Déclenche `finished` après validation des conditions du type `sleep`. La validation n’est possible que lorsque cette étape est l’objectif courant.

Relevé facultatif `field-s40` : x = 655, z = 0.55. Aucun ravitaillement automatique dans cette salle.

**Obstacles jouables**

Pas de barrière de profondeur. La silhouette architecturale et les accessoires de fond ne sont pas des murs invisibles traversant la bande latérale.

**Présences et rythme**

Aucun ennemi initial. Ne pas remplir cette salle de patrouilles pour augmenter artificiellement la durée.

**Contrôle de salle.** Vérifier le point d’entrée, les deux directions de chaque liaison réversible, la collision des objectifs, la lisibilité du personnage derrière le premier plan et la restauration de cet état. Le rapport détaille les contrôles automatisés effectivement réalisés ; cette fiche ne constitue pas un procès-verbal de playtest humain.

## Registre des 64 dossiers

| Identifiant | Titre | Catégorie | Statut de contenu |
|---|---|---|---|
| field-s01 | Poste de contrôle | Terrain | adaptation_originale |
| field-s02 | Le carottier | Terrain | adaptation_originale |
| field-s03 | Transport sanitaire | Terrain | adaptation_originale |
| field-s04 | Bureau de la Commission | Terrain | adaptation_originale |
| field-s05 | Appartement de Decker | Terrain | adaptation_originale |
| field-s06 | Consultation | Terrain | adaptation_originale |
| field-s07 | Coursive sous garde | Terrain | adaptation_originale |
| field-s08 | La salle d’entretien | Terrain | adaptation_originale |
| field-s09 | Réserve d’équipement | Terrain | adaptation_originale |
| field-s10 | Baie d’embarquement | Terrain | adaptation_originale |
| field-s11 | Aire d’atterrissage | Terrain | adaptation_originale |
| field-s12 | Abri d’expédition | Terrain | adaptation_originale |
| field-s13 | Décontamination | Terrain | adaptation_originale |
| field-s14 | Tête de puits | Terrain | adaptation_originale |
| field-s15 | Recette inférieure | Terrain | adaptation_originale |
| field-s16 | Relais de Cho | Terrain | adaptation_originale |
| field-s17 | Atelier de maintenance | Terrain | adaptation_originale |
| field-s18 | Galerie d’alimentation | Terrain | adaptation_originale |
| field-s19 | La carène enfouie | Terrain | adaptation_originale |
| field-s20 | Brèche de coque | Terrain | adaptation_originale |
| field-s21 | Tranchée de fouille | Terrain | adaptation_originale |
| field-s22 | Esplanade ensevelie | Terrain | adaptation_originale |
| field-s23 | Salle des restes | Terrain | adaptation_originale |
| field-s24 | Poste de relevés | Terrain | adaptation_originale |
| field-s25 | Passerelle suspendue | Terrain | adaptation_originale |
| field-s26 | Entrée des tubes | Terrain | adaptation_originale |
| field-s27 | Le nœud ambré | Terrain | adaptation_originale |
| field-s28 | Alcôve des disparus | Terrain | adaptation_originale |
| field-s29 | Le retour fermé | Terrain | adaptation_originale |
| field-s30 | Ascenseur secondaire | Terrain | adaptation_originale |
| field-s31 | Pied de l’escalier | Terrain | adaptation_originale |
| field-s32 | Chambre des œufs | Terrain | adaptation_originale |
| field-s33 | La pondeuse | Terrain | adaptation_originale |
| field-s34 | Dérivation de secours | Terrain | adaptation_originale |
| field-s35 | Paliers supérieurs | Terrain | adaptation_originale |
| field-s36 | Ravin de service | Terrain | adaptation_originale |
| field-s37 | Soute de la navette | Terrain | adaptation_originale |
| field-s38 | Quarantaine orbitale | Terrain | adaptation_originale |
| field-s39 | Poste d’observation | Terrain | adaptation_originale |
| field-s40 | Hypersommeil | Terrain | adaptation_originale |
| dossier-decker | Alan Decker | Personnel | adaptation_fondee_sur_roman |
| dossier-rollins | Andrea Rollins | Personnel | adaptation_fondee_sur_roman |
| dossier-manning | Manning | Personnel | adaptation_fondee_sur_roman |
| dossier-cho | Dae Cho | Personnel | adaptation_fondee_sur_roman |
| dossier-adams | Adams | Personnel | adaptation_fondee_sur_roman |
| dossier-elway | Elway | Personnel | adaptation_fondee_sur_roman |
| dossier-rand | Lucas Rand | Personnel | adaptation_fondee_sur_roman |
| dossier-silas | Nigel Silas | Personnel | adaptation_fondee_sur_roman |
| dossier-icc | La Commission | Dossiers | adaptation_fondee_sur_roman |
| dossier-company | L’ordre de mission | Dossiers | adaptation_fondee_sur_roman |
| dossier-lineage | La lignée | Dossiers | adaptation_fondee_sur_roman |
| dossier-memory | Une haine qui reconnaît | Dossiers | regle_de_jeu_originale |
| dossier-empathy | Se concentrer | Équipement | regle_de_jeu_originale |
| dossier-detector | Détecteur | Équipement | regle_de_jeu_originale |
| dossier-filter | Filtration | Équipement | regle_de_jeu_originale |
| dossier-lamp | Éclairage | Équipement | regle_de_jeu_originale |
| dossier-pistol | Arme de secours | Équipement | regle_de_jeu_originale |
| dossier-flame | Lance-flammes | Équipement | regle_de_jeu_originale |
| dossier-foam | Moussoir de capture | Équipement | regle_de_jeu_originale |
| dossier-adult | Adulte | Menaces | regle_de_jeu_originale |
| dossier-parasite | Parasite | Menaces | regle_de_jeu_originale |
| dossier-queen | La pondeuse | Menaces | regle_de_jeu_originale |
| dossier-map | Lire le réseau | Terrain | regle_de_jeu_originale |
| dossier-survivors | Une extraction incomplète | Dossiers | adaptation_fondee_sur_roman |
